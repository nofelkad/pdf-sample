#!/bin/sh
# Creates the two IAM database roles (P1-2.3). Runs once, on first start of an empty data directory.
#   iam_migrator - owns the database and every object in it; Flyway connects as this role (DDL)
#   iam_app      - the application datasource; DML only (privileges granted by migration V4)
set -eu

psql -v ON_ERROR_STOP=1 --username "$POSTGRES_USER" --dbname "$POSTGRES_DB" \
  -v db="$POSTGRES_DB" \
  -v migrator_pw="${IAM_MIGRATOR_PASSWORD:-iam_migrator}" \
  -v app_pw="${IAM_APP_PASSWORD:-iam_app}" <<'EOSQL'
CREATE ROLE iam_migrator LOGIN PASSWORD :'migrator_pw';
CREATE ROLE iam_app LOGIN PASSWORD :'app_pw' NOSUPERUSER NOCREATEDB NOCREATEROLE NOINHERIT;
ALTER DATABASE :"db" OWNER TO iam_migrator;
REVOKE ALL ON DATABASE :"db" FROM PUBLIC;
GRANT CONNECT, TEMPORARY ON DATABASE :"db" TO iam_app;
EOSQL
