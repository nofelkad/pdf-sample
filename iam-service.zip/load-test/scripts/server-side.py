#!/usr/bin/env python3
"""Prints the server-side latency quantiles (ms) and gauges from the *.after.prom snapshots written by smoke.sh.

    load-test/scripts/server-side.py load-test/build/smoke/*.after.prom

The quantiles are the Micrometer client-side percentiles over a sliding window of about two minutes, so a snapshot
taken right after a run describes that run (and is empty for meters the run did not exercise).
"""
import re
import sys

SERIES = re.compile(r'^(iam_[a-z_]+?)(?:_seconds)?\{([^}]*)\} ([0-9.eE+-]+|NaN)$')
INTERESTING = ("iam_auth_login_duration", "iam_auth_refresh_duration", "iam_auth_tenant_switch_duration",
               "iam_permission_resolve_duration")


def labels(text):
    return dict(re.findall(r'(\w+)="([^"]*)"', text))


def main(paths):
    print("| snapshot | meter | op | p50 ms | p95 ms | p99 ms | count |")
    print("|---|---|---|---:|---:|---:|---:|")
    for path in paths:
        quantiles, counts = {}, {}
        for line in open(path):
            line = line.strip()
            m = SERIES.match(line)
            if m and 'quantile="' in m.group(2) and m.group(1) in INTERESTING and 'outcome="success"' in m.group(2):
                lab = labels(m.group(2))
                quantiles.setdefault((m.group(1), lab.get("op", "")), {})[lab["quantile"]] = float(m.group(3)) * 1000
            c = re.match(r'^(iam_[a-z_]+)_seconds_count\{([^}]*)\} ([0-9.]+)$', line)
            if c and c.group(1) in INTERESTING and 'outcome="success"' in c.group(2):
                counts[(c.group(1), labels(c.group(2)).get("op", ""))] = float(c.group(3))
        for (meter, op), q in sorted(quantiles.items()):
            print(f"| {path.split('/')[-1].replace('.after.prom', '')} | {meter} | {op} | {q.get('0.5', 0):.2f} | "
                  f"{q.get('0.95', 0):.2f} | {q.get('0.99', 0):.2f} | {counts.get((meter, op), 0):.0f} |")


if __name__ == "__main__":
    main(sys.argv[1:])
