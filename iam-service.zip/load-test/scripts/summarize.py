#!/usr/bin/env python3
"""Prints the request statistics of Gatling reports as a markdown table (Gatling 3.14 only ships them inside index.html).

    load-test/scripts/summarize.py                      # the newest report in load-test/build/gatling-results
    load-test/scripts/summarize.py <report dir> ...     # specific reports
"""
import glob
import os
import re
import sys

COLUMNS = ["total", "ok", "ko", "pct_ko", "rps", "min", "p50", "p75", "p95", "p99", "max", "mean", "stddev"]


def rows(html):
    body = html[html.find('id="container_statistics_body"'):]
    for tr in re.findall(r'<tr id="req_[^"]*".*?</tr>', body, re.S):
        name = re.search(r'class="ellipsed-name">([^<]*)<', tr).group(1)
        values = [float(v.replace(",", "")) for v in re.findall(r'<td class="value[^"]*">([\d,.]+)</td>', tr)]
        yield name, dict(zip(COLUMNS, values))


def main(paths):
    print("| report | request | requests | KO | req/s (whole run) | p50 ms | p75 ms | p95 ms | p99 ms | max ms | mean ms |")
    print("|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|")
    for path in paths:
        with open(os.path.join(path, "index.html"), encoding="utf-8", errors="replace") as handle:
            html = handle.read()
        for name, s in rows(html):
            print(f"| {os.path.basename(os.path.normpath(path))} | {name} | {s['total']:.0f} | {s['ko']:.0f} | {s['rps']:.1f} | {s['p50']:.0f} | {s['p75']:.0f} | {s['p95']:.0f} | "
                  f"{s['p99']:.0f} | {s['max']:.0f} | {s['mean']:.0f} |")


if __name__ == "__main__":
    reports = sys.argv[1:] or sorted(glob.glob(os.path.join(os.path.dirname(__file__), "..", "build", "gatling-results", "*")))[-1:]
    main(reports)
