#!/usr/bin/env bash
# Runs the four simulations one after the other against an already running iam-service (see start-iam.sh) and stores,
# next to every Gatling report, the iam_* meters scraped from /actuator/prometheus right after the run.
#
#   load-test/scripts/smoke.sh                         # smoke rates: login 25, refresh 150, admin 50, explain 25 rps
#   SCALE=1 load-test/scripts/smoke.sh                 # the spec rates: 50 / 300 / 100 / 50 rps (one instance!)
#   SIMS="LoginSimulation" load-test/scripts/smoke.sh  # a subset
#
# Environment: BASE_URL (default http://localhost:8080), MANAGEMENT_URL (actuator, default http://localhost:8081), DURATION seconds (120), RAMP seconds (20), SCALE (0.5),
# EXTRA (further -Plt.x=y arguments, e.g. the data-set shape when it is not the smoke profile).
set -uo pipefail

root="$(cd "$(dirname "$0")/../.." && pwd)"
base="${BASE_URL:-http://localhost:8080}"
management="${MANAGEMENT_URL:-http://localhost:8081}"   # ruling R36: actuator is on the management port
duration="${DURATION:-120}"
ramp="${RAMP:-20}"
scale="${SCALE:-0.5}"
sims="${SIMS:-LoginSimulation RefreshSimulation AdminApiSimulation EffectivePermissionSimulation}"
out="$root/load-test/build/smoke"
mkdir -p "$out"

rate() { python3 -c "print(round($1 * $scale))"; }

for sim in $sims; do
  case "$sim" in
    LoginSimulation)               rps="$(rate 50)" ;;
    RefreshSimulation)             rps="$(rate 300)" ;;
    AdminApiSimulation)            rps="$(rate 100)" ;;
    EffectivePermissionSimulation) rps="$(rate 50)" ;;
    *) echo "unknown simulation $sim" >&2; exit 2 ;;
  esac
  echo "=== $sim at $rps rps for ${duration}s (ramp ${ramp}s)"
  curl -s "$management/actuator/prometheus" | grep -E '^iam_' > "$out/$sim.before.prom" || true
  "$root/gradlew" -q :load-test:gatlingRun -Plt.simulation="$sim" -Plt.rps="$rps" -Plt.durationSeconds="$duration" \
      -Plt.rampSeconds="$ramp" -Plt.baseUrl="$base" -Plt.assert=false ${EXTRA:-} --console=plain > "$out/$sim.log" 2>&1
  echo "gradle exit: $?"
  curl -s "$management/actuator/prometheus" | grep -E '^iam_' > "$out/$sim.after.prom" || true
done
"$root/load-test/scripts/summarize.py" $(ls -d "$root"/load-test/build/gatling-results/*/ | tail -n "$(echo $sims | wc -w)")
