#!/usr/bin/env bash
# Starts ONE iam-service instance configured for a load test, in the foreground (Ctrl-C stops it).
#
#   IAM_DB_PORT=5452 docker compose up -d
#   ./gradlew :iam-service:bootJar
#   load-test/scripts/start-iam.sh            # database on localhost:${IAM_DB_PORT:-5442}
#
# Deviations from production defaults, and why (they are repeated in docs/perf/README.md):
#   - rate limits raised to 100000: the load generator sends from one host. Each virtual user sends its own
#     X-Forwarded-For (127.0.0.1 is a trusted proxy), so the limiter still runs and still does its database round trip
#     per request (its cost stays in the numbers), it just never rejects.
#   - root log level WARN and plain (non-JSON) logs: logging 300 requests per second to a terminal would be measured.
#   - dev issuer and master key (nothing here is a secret; do not use them anywhere shared).
#   - profile `local`: the docker-compose database passwords (application-local.yml), which DatabaseCredentialsGuard
#     accepts only in the dev/local/test profiles.
# Everything else (Hikari pool, Tomcat threads, JVM ergonomics apart from -Xmx) is the application default.
set -euo pipefail

root="$(cd "$(dirname "$0")/../.." && pwd)"
jar="${IAM_JAR:-$root/iam-service/build/libs/iam-service-0.1.0-SNAPSHOT.jar}"
port="${IAM_DB_PORT:-5442}"

export IAM_DB_URL="${IAM_DB_URL:-jdbc:postgresql://localhost:${port}/iam_db}"
export IAM_ISSUER="${IAM_ISSUER:-http://localhost:8080}"
export IAM_MASTER_KEY="${IAM_MASTER_KEY:-BZwX9oth03bY6AechDvxAl7UBuczd3M8GY4Dm2LZcvc=}"

exec java "${JAVA_OPTS:--Xmx1g}" -jar "$jar" \
  --spring.profiles.active=local,plain-logs \
  --logging.level.root=WARN \
  --iam.security.trusted-proxies=127.0.0.1 \
  --iam.auth.rate-limit.per-ip=100000 \
  --iam.auth.rate-limit.per-email=100000 \
  --iam.auth.rate-limit.refresh-per-ip=100000 \
  "$@"
