package com.acme.iam.loadtest;

import static io.gatling.javaapi.core.CoreDsl.StringBody;
import static io.gatling.javaapi.core.CoreDsl.details;
import static io.gatling.javaapi.core.CoreDsl.doIf;
import static io.gatling.javaapi.core.CoreDsl.exec;
import static io.gatling.javaapi.core.CoreDsl.global;
import static io.gatling.javaapi.core.CoreDsl.jmesPath;
import static io.gatling.javaapi.core.CoreDsl.jsonPath;
import static io.gatling.javaapi.core.CoreDsl.pace;
import static io.gatling.javaapi.core.CoreDsl.rampUsers;
import static io.gatling.javaapi.core.CoreDsl.randomSwitch;
import static io.gatling.javaapi.core.CoreDsl.scenario;
import static io.gatling.javaapi.http.HttpDsl.http;
import static io.gatling.javaapi.http.HttpDsl.status;

import io.gatling.javaapi.core.Assertion;
import io.gatling.javaapi.core.Choice;
import io.gatling.javaapi.core.ScenarioBuilder;
import io.gatling.javaapi.core.Simulation;
import java.time.Duration;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Stream;

/**
 * Admin APIs (spec target: 100 rps) as an account administrator would use them: user list, role list, audit search
 * (one tenant, 30 days; target p95 below 500 ms) and assignment create followed by delete.
 *
 * <p>Virtual users are account administrators ({@code admin<n>}, system role Account Admin at account scope), spread
 * over the accounts. Each logs in once, looks up the Auditor role and its account's tenants, then performs one
 * operation per second for {@code -Plt.durationSeconds}: users 30 %, roles 15 %, audit search 25 %, assignment
 * create+delete 30 % (two requests), about 1.3 requests per user and second, so {@code -Plt.rps} requests per second
 * need {@code rps / 1.3} users. Assignments grant the system role Auditor at TENANT scope to a random user of the
 * account (revoking that user's tokens, as in production); a duplicate (409) or an already deleted one (404) is
 * accepted, other users may race on the same pair.
 */
public class AdminApiSimulation extends Simulation {

  private static final double REQUESTS_PER_ITERATION = 1.3;
  private static final int USERS = (int) Math.max(1, Math.round(Settings.decimal("rps", 100) / REQUESTS_PER_ITERATION));
  private static final AtomicInteger NEXT = new AtomicInteger();

  private final ScenarioBuilder admins = scenario("admin")
      .feed(Stream.generate(() -> {
        int account = (NEXT.getAndIncrement() % Settings.LAYOUT.accounts()) + 1;
        return Map.<String, Object>of("account", account, "email", Settings.LAYOUT.adminEmail(account));
      }).iterator())
      .exec(Flows.identify())
      .exec(Flows.login("setup login"))
      .exec(http("setup roles").get("/api/roles?limit=200")
          .header("Authorization", Flows.bearer())
          .check(status().is(200), jmesPath("items[?name=='Auditor'].id | [0]").saveAs("auditorRole")))
      .exec(http("setup tenants").get("/api/tenants?limit=50")
          .header("Authorization", Flows.bearer())
          .check(status().is(200), jsonPath("$.items[*].id").findAll().saveAs("tenantIds")))
      .during(Settings.DURATION).on(
          pace(Duration.ofSeconds(1))
              .exec(session -> {
                var layout = Settings.LAYOUT;
                int account = session.getInt("account");
                int members = (layout.users() - account) / layout.accounts() + 1;
                int user = account + layout.accounts() * Settings.randomInt(0, members - 1);
                List<String> tenants = session.getList("tenantIds");
                return session.set("targetUser", layout.userId(user).toString())
                    .set("targetTenant", layout.primaryTenantId(user).toString())
                    .set("searchTenant", tenants.get(Settings.randomInt(0, tenants.size() - 1)))
                    .set("from", Instant.now().minus(30, ChronoUnit.DAYS).toString())
                    .set("to", Instant.now().toString());
              })
              .randomSwitch().on(
                  new Choice.WithWeight(30.0, exec(http("users list").get("/api/users?limit=50")
                      .header("Authorization", Flows.bearer())
                      .check(status().is(200)))),
                  new Choice.WithWeight(15.0, exec(http("roles list").get("/api/roles?limit=50")
                      .header("Authorization", Flows.bearer())
                      .check(status().is(200)))),
                  new Choice.WithWeight(25.0, exec(http("audit search")
                      .get("/api/audit/events?tenantId=#{searchTenant}&from=#{from}&to=#{to}&limit=50")
                      .header("Authorization", Flows.bearer())
                      .check(status().is(200)))),
                  new Choice.WithWeight(30.0, exec(session -> session.remove("assignmentId"))
                      .exec(http("assignment create").post("/api/users/#{targetUser}/assignments")
                          .header("Authorization", Flows.bearer())
                          .body(StringBody("{\"roleId\":\"#{auditorRole}\",\"scopeType\":\"TENANT\","
                              + "\"scopeId\":\"#{targetTenant}\"}"))
                          .check(status().in(201, 409), jsonPath("$.id").optional().saveAs("assignmentId")))
                      .exec(doIf(session -> session.contains("assignmentId")).then(
                          exec(http("assignment delete").delete("/api/assignments/#{assignmentId}")
                              .header("Authorization", Flows.bearer())
                              .check(status().in(204, 404))))))));

  {
    List<Assertion> assertions = Settings.ASSERT
        ? List.of(details("audit search").responseTime().percentile(95.0).lt(500),
            global().failedRequests().percent().lt(1.0))
        : List.of();
    setUp(admins.injectOpen(rampUsers(USERS).during(Settings.RAMP)))
        .protocols(Flows.protocol())
        .assertions(assertions);
  }
}
