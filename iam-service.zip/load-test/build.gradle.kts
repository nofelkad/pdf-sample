// Load test of iam-service (spec P1-11.2, Ruling R6): bulk data generator + Gatling simulations.
//
//   ./gradlew :load-test:generateData -Plt.users=20000 -Plt.assignments=100000 -Plt.auditRows=500000   (see docs/perf/README.md)
//   ./gradlew :load-test:gatlingRun   -Plt.simulation=LoginSimulation -Plt.rps=10 ...
//
// Nothing here runs as part of `./gradlew build`: the module has no tests, and `build` only compiles the generator and
// the simulations (so they cannot rot). Gatling is driven through plain JavaExec tasks (no Gradle plugin) from its own
// `gatling` source set, whose classpath is kept apart from the Spring Boot BOM that the root build applies to the
// other source sets: Gatling needs its own Netty/Jackson/Akka versions.

description = "Gatling load test and bulk data generator for iam-service (not part of the default test run)"

val gatling: SourceSet by sourceSets.creating

dependencies {
    // data generator (main source set): JDBC + the same Argon2 encoder iam-service uses for passwords
    implementation(libs.postgresql)
    implementation(libs.spring.security.crypto)
    implementation(libs.bouncycastle.bcprov)
    runtimeOnly("org.springframework:spring-jcl")   // commons-logging API used by spring-security-crypto

    // simulations (gatling source set): Gatling, plus the shared id scheme of the generator
    "gatlingImplementation"(libs.gatling.charts.highcharts)
    "gatlingImplementation"(sourceSets.main.get().output)
}

/** Every {@code -Plt.name=value} project property, as {@code name -> value}. */
fun ltProperties(): Map<String, String> =
    project.properties.filterKeys { it.startsWith("lt.") }.mapKeys { it.key.removePrefix("lt.") }
        .mapValues { it.value.toString() }

tasks.register<JavaExec>("generateData") {
    group = "load test"
    description = "Fills a migrated IAM database with accounts, users, assignments and audit rows (-Plt.users=... see docs/perf/README.md)"
    classpath = sourceSets.main.get().runtimeClasspath
    mainClass.set("com.acme.iam.loadtest.DataGenerator")
    args(ltProperties().map { (k, v) -> "--$k=$v" })
}

tasks.register<JavaExec>("gatlingRun") {
    group = "load test"
    description = "Runs one Gatling simulation: -Plt.simulation=LoginSimulation|RefreshSimulation|AdminApiSimulation|EffectivePermissionSimulation"
    dependsOn("gatlingClasses")
    classpath = gatling.runtimeClasspath
    mainClass.set("io.gatling.app.Gatling")
    val simulation = project.findProperty("lt.simulation")?.toString() ?: "LoginSimulation"
    val results = layout.buildDirectory.dir("gatling-results")
    args("--simulation", "com.acme.iam.loadtest.$simulation",
        "--results-folder", results.get().asFile.absolutePath,
        "--run-description", project.findProperty("lt.description")?.toString() ?: simulation)
    ltProperties().forEach { (k, v) -> systemProperty("lt.$k", v) }
    jvmArgs("-Xmx1g", "--add-opens=java.base/java.lang=ALL-UNNAMED", "--add-opens=java.base/java.nio=ALL-UNNAMED",
        "--add-opens=java.base/sun.nio.ch=ALL-UNNAMED")   // what the Gatling Gradle plugin passes on JDK 17+
}

// `build` compiles the simulations (they must not rot) but never runs them.
tasks.named("build") { dependsOn("gatlingClasses") }
