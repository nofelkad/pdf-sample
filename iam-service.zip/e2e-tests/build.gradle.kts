// Phase 1 exit criteria (spec section 10) as an executable suite (Task 9): the real iam-service and sample-app boot jars
// run as separate processes (two iam-service instances) against one PostgreSQL Testcontainer. Part of `./gradlew build`.
description = "End-to-end exit-criteria and failure-mode suite (iam-service + sample-app processes)"

evaluationDependsOn(":iam-service")
evaluationDependsOn(":sample-app")

dependencies {
    testImplementation(libs.bundles.testcontainers)
    testImplementation(libs.postgresql)
    testImplementation(libs.jackson.databind)
    testImplementation(libs.awaitility)
}

tasks.named<Test>("test") {
    val iamJar = project(":iam-service").tasks.named("bootJar")
    val sampleJar = project(":sample-app").tasks.named("bootJar")
    dependsOn(iamJar, sampleJar)
    inputs.files(iamJar, sampleJar).withPropertyName("bootJars")
    val logDir = layout.buildDirectory.dir("e2e-logs")
    outputs.dir(logDir).withPropertyName("e2eLogs")
    doFirst {
        systemProperty("e2e.iamJar", iamJar.get().outputs.files.singleFile.absolutePath)
        systemProperty("e2e.sampleJar", sampleJar.get().outputs.files.singleFile.absolutePath)
        systemProperty("e2e.logDir", logDir.get().asFile.absolutePath)
    }
}
