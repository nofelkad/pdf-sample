-- E2E database: the IAM role model of docker/postgres/init/01-roles.sh (real, non-default passwords: the services run
-- without the dev/test profiles, so DatabaseCredentialsGuard is active) plus the sample application's own database.
CREATE ROLE iam_migrator LOGIN PASSWORD 'iam_migrator_e2e';
CREATE ROLE iam_app LOGIN PASSWORD 'iam_app_e2e' NOSUPERUSER NOCREATEDB NOCREATEROLE NOINHERIT;
ALTER DATABASE iam_db OWNER TO iam_migrator;
REVOKE ALL ON DATABASE iam_db FROM PUBLIC;
GRANT CONNECT, TEMPORARY ON DATABASE iam_db TO iam_app;
CREATE ROLE sample LOGIN PASSWORD 'sample_e2e';
CREATE DATABASE sample_db OWNER sample;
