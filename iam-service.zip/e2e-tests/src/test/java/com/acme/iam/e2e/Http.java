package com.acme.iam.e2e;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.MissingNode;
import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.Base64;
import java.util.HashSet;
import java.util.Set;

/** Tiny JSON-over-HTTP helper; every request times out after 20 s, so a hanging server fails the test. */
final class Http {

  static final ObjectMapper JSON = new ObjectMapper();
  static final Duration TIMEOUT = Duration.ofSeconds(20);
  private static final HttpClient CLIENT = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(5)).build();

  record Response(int status, String raw, HttpResponse<String> http) {
    JsonNode json() {
      try {
        return raw == null || raw.isBlank() ? MissingNode.getInstance() : JSON.readTree(raw);
      } catch (IOException e) {
        throw new IllegalStateException("Not JSON (" + status + "): " + raw, e);
      }
    }

    String text(String pointer) {
      return json().at(pointer).asText();
    }

    String header(String name) {
      return http.headers().firstValue(name).orElse(null);
    }

    @Override
    public String toString() {
      return status + " " + raw;
    }
  }

  private Http() {}

  static Response get(String url, String bearer) {
    return send(request(url, bearer).GET());
  }

  static Response delete(String url, String bearer) {
    return send(request(url, bearer).DELETE());
  }

  static Response post(String url, String bearer, Object body) {
    return send(request(url, bearer).header("Content-Type", "application/json")
        .POST(HttpRequest.BodyPublishers.ofString(json(body))));
  }

  static Response put(String url, String bearer, Object body) {
    return send(request(url, bearer).header("Content-Type", "application/json")
        .PUT(HttpRequest.BodyPublishers.ofString(json(body))));
  }

  static Response postForm(String url, String basicUser, String basicSecret, String form) {
    String basic = Base64.getEncoder().encodeToString((basicUser + ":" + basicSecret).getBytes(StandardCharsets.UTF_8));
    return send(HttpRequest.newBuilder(URI.create(url)).timeout(TIMEOUT)
        .header("Authorization", "Basic " + basic)
        .header("Content-Type", "application/x-www-form-urlencoded")
        .POST(HttpRequest.BodyPublishers.ofString(form)));
  }

  /** The {@code perms} claim of a JWT (payload decoded, signature not checked: the servers do that). */
  static Set<String> perms(String jwt) {
    try {
      JsonNode claims = JSON.readTree(Base64.getUrlDecoder().decode(jwt.split("\\.")[1]));
      Set<String> perms = new HashSet<>();
      claims.path("perms").forEach(p -> perms.add(p.asText()));
      return perms;
    } catch (IOException e) {
      throw new IllegalStateException(e);
    }
  }

  private static HttpRequest.Builder request(String url, String bearer) {
    HttpRequest.Builder builder = HttpRequest.newBuilder(URI.create(url)).timeout(TIMEOUT);
    if (bearer != null) {
      builder.header("Authorization", "Bearer " + bearer);
    }
    return builder;
  }

  private static String json(Object body) {
    try {
      return body instanceof String s ? s : JSON.writeValueAsString(body);
    } catch (IOException e) {
      throw new IllegalStateException(e);
    }
  }

  private static Response send(HttpRequest.Builder request) {
    try {
      HttpResponse<String> response = CLIENT.send(request.build(), HttpResponse.BodyHandlers.ofString());
      return new Response(response.statusCode(), response.body(), response);
    } catch (IOException e) {
      throw new IllegalStateException(e);
    } catch (InterruptedException e) {
      Thread.currentThread().interrupt();
      throw new IllegalStateException(e);
    }
  }
}
