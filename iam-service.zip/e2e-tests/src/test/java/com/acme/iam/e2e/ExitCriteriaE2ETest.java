package com.acme.iam.e2e;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

import com.acme.iam.e2e.Http.Response;
import com.fasterxml.jackson.databind.JsonNode;
import java.nio.file.Path;
import java.security.SecureRandom;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.Duration;
import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneOffset;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Base64;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.function.Supplier;
import org.awaitility.Awaitility;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.TestMethodOrder;
import org.testcontainers.containers.PostgreSQLContainer;
import org.testcontainers.utility.DockerImageName;

/**
 * Phase 1 exit criteria (spec section 10) against the real artefacts (Task 9, deliverable C), plus the process-level
 * failure modes of P1-11.4. Everything runs as separate processes against one PostgreSQL container:
 *
 * <ul>
 *   <li>{@code iam-a} and {@code iam-b}: two iam-service instances (the boot jar, no dev/test profile, real passwords,
 *       SMTP notifications into {@link SmtpSink}); both use {@code iam-a}'s address as issuer;
 *   <li>the bootstrap CLI ({@code --bootstrap-platform-admin});
 *   <li>{@code sample-app}: the iam-client sample application with a client registered through the platform API; it
 *       uploads its manifest, validates IAM JWTs with {@code iam-a}'s JWKS, polls {@code iam-a}'s revocation feed and
 *       relays its audit outbox to {@code iam-a}.
 * </ul>
 *
 * The steps build on each other (ordered); revocation polling runs with the shipped defaults (2 s on both sides, ruling
 * R41), so "within 5 s" is proven for the default configuration. Criterion 5 (authorization matrix) is
 * {@code AuthorizationMatrixIT} in iam-service; criterion 6 (load test) is Task 10's.
 */
@TestInstance(TestInstance.Lifecycle.PER_CLASS)
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
class ExitCriteriaE2ETest {

  private static final String PASSWORD = "Correct-Horse-42!";
  private static final String OPS = "ops@e2e.test";
  private static final String ADMIN = "admin@acme.e2e";
  private static final String CLIENT_ID = "sample-billing";
  private static final Duration REVOCATION_SLA = Duration.ofSeconds(5);
  private static final String READINESS = "/actuator/health/readiness";

  private static final PostgreSQLContainer<?> POSTGRES =
      new PostgreSQLContainer<>(DockerImageName.parse("postgres:16-alpine"))
          .withDatabaseName("iam_db")
          .withUsername("e2e_admin")
          .withPassword("e2e_admin_pw")
          .withInitScript("e2e-init.sql");

  private SmtpSink smtp;
  private JarProcess iamA;
  private JarProcess iamB;
  private JarProcess bootstrapCli;
  private JarProcess sample;
  private int managementA;
  private String a;
  private String b;
  private String s;

  // state shared by the ordered steps
  private String platformToken;
  private String clientSecret;
  private UUID account;
  private UUID t1;
  private UUID t2;
  private UUID admin;
  private String adminToken;
  private UUID alice;
  private UUID bob;
  private UUID auditorGrantOfAlice;
  private String aliceToken;
  private Map<String, Object> alreadyIngested;

  @BeforeAll
  void startTheSystem() throws Exception {
    POSTGRES.start();
    smtp = new SmtpSink();
    int portA = JarProcess.freePort();
    int portB = JarProcess.freePort();
    String issuer = "http://localhost:" + portA;
    Path iamJar = Path.of(System.getProperty("e2e.iamJar"));
    byte[] masterKey = new byte[32];
    new SecureRandom().nextBytes(masterKey);

    Map<String, String> env = new HashMap<>();
    env.put("IAM_DB_URL", jdbcUrl("iam_db"));
    env.put("IAM_DB_APP_USER", "iam_app");
    env.put("IAM_DB_APP_PASSWORD", "iam_app_e2e");
    env.put("IAM_DB_MIGRATOR_USER", "iam_migrator");
    env.put("IAM_DB_MIGRATOR_PASSWORD", "iam_migrator_e2e");
    env.put("IAM_ISSUER", issuer);
    env.put("IAM_MASTER_KEY", Base64.getEncoder().encodeToString(masterKey));
    List<String> common = List.of(
        "--iam.notification.mode=smtp",
        "--spring.mail.host=localhost",
        "--spring.mail.port=" + smtp.port(),
        "--iam.notification.invitation-url=http://e2e.test/accept?token={token}",
        "--iam.notification.password-reset-url=http://e2e.test/reset?token={token}",
        "--iam.auth.rate-limit.enabled=false");

    managementA = JarProcess.freePort();
    iamA = new JarProcess("iam-a", iamJar, portA, READINESS, env,
        with(with(common, "--server.port=" + portA), "--management.server.port=" + managementA)).start();
    iamB = new JarProcess("iam-b", iamJar, portB, READINESS, env,
        with(with(common, "--server.port=" + portB), "--management.server.port=" + JarProcess.freePort())).start();
    bootstrapCli = new JarProcess("iam-bootstrap-cli", iamJar, 0, env, common);
    a = iamA.baseUrl();
    b = iamB.baseUrl();
  }

  @AfterAll
  void stopTheSystem() throws Exception {
    for (JarProcess process : new JarProcess[] {sample, iamB, iamA}) {
      if (process != null) {
        process.stop();
      }
    }
    if (smtp != null) {
      smtp.close();
    }
    POSTGRES.stop();
  }

  // ======================================================================== 1. fresh install → organisation

  @Test
  @Order(1)
  void freshInstallBootstrapsThePlatformAdmin() {
    int exit = bootstrapCli.run(List.of("--spring.main.web-application-type=none",
        "--bootstrap-platform-admin=email=" + OPS));
    assertThat(exit).as("bootstrap CLI exit code, see " + bootstrapCli.log()).isZero();

    platformToken = accept(OPS);
    assertThat(Http.perms(platformToken)).contains("platform.account.manage");
    assertThat(bootstrapCli.run(List.of("--spring.main.web-application-type=none",
        "--bootstrap-platform-admin=email=" + OPS))).as("runs once").isEqualTo(2);
  }

  @Test
  @Order(2)
  void thePlatformRegistersTheSampleAppWhichUploadsItsManifest() {
    Response registered = Http.post(a + "/api/platform/app-clients", platformToken,
        Map.of("clientId", CLIENT_ID, "productCode", "BILLING"));
    assertThat(registered.status()).as(registered.toString()).isEqualTo(201);
    clientSecret = registered.text("/clientSecret");

    int port = JarProcess.freePort();
    Map<String, String> env = Map.of(
        "SAMPLE_DB_URL", jdbcUrl("sample_db"), "SAMPLE_DB_USER", "sample", "SAMPLE_DB_PASSWORD", "sample_e2e",
        "SAMPLE_PORT", String.valueOf(port), "IAM_ISSUER_URI", a, "IAM_CLIENT_ID", CLIENT_ID,
        "IAM_CLIENT_SECRET", clientSecret);
    sample = new JarProcess("sample-app", Path.of(System.getProperty("e2e.sampleJar")), port, env, List.of(
        "--iam.client.audit.relay.interval=200ms",
        "--iam.client.audit.relay.max-backoff=2s")).start();
    s = sample.baseUrl();

    Awaitility.await("BILLING manifest uploaded").atMost(Duration.ofSeconds(30)).pollInterval(Duration.ofMillis(250))
        .until(() -> Http.get(a + "/api/products/BILLING/permissions", platformToken).status() == 200);
    assertThat(Http.get(a + "/api/products/BILLING/permissions", platformToken).raw())
        .contains("billing.invoice.approve", "billing.invoice.read.account");
  }

  @Test
  @Order(3)
  void thePlatformAdminCreatesAnAccountWhoseAdminAccepts() {
    Response created = Http.post(a + "/api/platform/accounts", platformToken, Map.of(
        "name", "Acme", "slug", "acme",
        "defaultTenant", Map.of("name", "Acme HQ", "slug", "hq"),
        "defaultUser", Map.of("email", ADMIN, "displayName", "Ada"),
        "products", List.of(Map.of("code", "BILLING", "status", "ACTIVE",
            "startsAt", LocalDate.now(ZoneOffset.UTC).minusDays(1).toString()))));
    assertThat(created.status()).as(created.toString()).isEqualTo(201);
    account = UUID.fromString(created.text("/account/id"));
    t1 = UUID.fromString(created.text("/defaultTenant/id"));
    admin = UUID.fromString(created.text("/defaultUser/id"));

    // R46: the admin activates through the link returned by the create call
    String link = created.text("/activation/link");
    adminToken = acceptToken(link.substring(link.indexOf("token=") + "token=".length()), ADMIN);
    assertThat(Http.perms(adminToken)).contains("iam.tenant.manage", "iam.role.assign").doesNotContain(
        "platform.account.manage");
  }

  @Test
  @Order(4)
  void thePlatformCreatesASecondTenantAndTheAccountAdminInvitesSharesCreatesARoleAndAssignsAtBothScopes()
      throws Exception {
    Response tenant = Http.post(a + "/api/platform/accounts/" + account + "/tenants", platformToken,
        Map.of("name", "Europe", "slug", "europe", "products", List.of(Map.of("code", "BILLING", "enabled", true))));
    assertThat(tenant.status()).as(tenant.toString()).isEqualTo(201);
    t2 = UUID.fromString(tenant.text("/id"));
    assertThat(Http.post(a + "/api/tenants", adminToken, Map.of("name", "X", "slug", "x")).status())
        .as("customers no longer create tenants (R46)").isEqualTo(405);

    alice = invite(t1, "alice@acme.e2e");
    accept("alice@acme.e2e");
    bob = invite(t2, "bob@acme.e2e");
    accept("bob@acme.e2e");

    Response shared = Http.post(a + "/api/users/" + alice + "/memberships", adminToken, Map.of("tenantId", t2));
    assertThat(shared.status()).as(shared.toString()).isEqualTo(201);
    assertThat(shared.json().get("memberships").findValuesAsText("tenantId"))
        .containsExactlyInAnyOrder(t1.toString(), t2.toString());

    Response helpdesk = Http.post(a + "/api/roles", adminToken, Map.of("productCode", "IAM", "name", "Helpdesk",
        "description", "First line support", "permissionCodes", List.of("iam.user.read.tenant", "iam.audit.read")));
    assertThat(helpdesk.status()).as(helpdesk.toString()).isEqualTo(201);
    UUID helpdeskRole = UUID.fromString(helpdesk.text("/id"));
    Map<String, UUID> system = systemRoles("IAM");

    assign(alice, helpdeskRole, "TENANT", t1);
    auditorGrantOfAlice = assign(alice, system.get("Auditor"), "ACCOUNT", account);
    assign(alice, system.get("Tenant Admin"), "TENANT", t2);
    assign(bob, helpdeskRole, "TENANT", t2);

    // Product SYSTEM roles (ruling R40): the account admin holds iam.role.assign at ACCOUNT scope and the account
    // subscribes to BILLING, so it may grant "Billing Admin" without holding billing.* itself
    assign(alice, systemRoles("BILLING").get("Billing Admin"), "ACCOUNT", account);

    JsonNode assignments = Http.get(a + "/api/users/" + alice + "/assignments", adminToken).json().get("items");
    Set<String> scopes = new HashSet<>();
    assignments.forEach(x -> scopes.add(x.get("roleName").asText() + "@" + x.get("scopeType").asText()));
    assertThat(scopes).containsExactlyInAnyOrder("Helpdesk@TENANT", "Auditor@ACCOUNT", "Tenant Admin@TENANT",
        "Billing Admin@ACCOUNT");
  }

  // ============================================================================ 2. login: perms == explain

  @Test
  @Order(5)
  void loginTokenPermsEqualTheExplainEndpointInEveryTenant() {
    Response login = login("alice@acme.e2e");
    assertThat(login.text("/activeTenantId")).isEqualTo(t1.toString());
    aliceToken = login.text("/accessToken");
    assertThat(Http.perms(aliceToken)).isEqualTo(explain(alice, t1))
        .contains("iam.audit.read", "iam.user.read.tenant", "billing.invoice.approve");

    Response switched = Http.post(a + "/auth/switch-tenant", aliceToken, Map.of("tenantId", t2));
    assertThat(switched.status()).as(switched.toString()).isEqualTo(200);
    Set<String> inT2 = Http.perms(switched.text("/accessToken"));
    assertThat(inT2).isEqualTo(explain(alice, t2)).contains("iam.user.manage").isNotEqualTo(Http.perms(aliceToken));
    aliceToken = login("alice@acme.e2e").text("/accessToken");
    assertThat(Http.perms(aliceToken)).as("Billing Admin at ACCOUNT scope").contains("billing.invoice.read.account");

    // ruling R42: a .account DATA permission granted at TENANT scope grants nothing, in the token and in explain alike
    assign(bob, systemRoles("BILLING").get("Billing Admin"), "TENANT", t2);
    Set<String> bobPerms = Http.perms(login("bob@acme.e2e").text("/accessToken"));
    assertThat(bobPerms).isEqualTo(explain(bob, t2))
        .contains("billing.invoice.read.tenant", "billing.invoice.approve")
        .doesNotContain("billing.invoice.read.account");
  }

  // ===================================================================== 3. revocation on every instance ≤ 5 s

  @Test
  @Order(6)
  void disablingAUserIsEnforcedOnTheOtherInstanceWithinFiveSeconds() {
    String bobToken = login("bob@acme.e2e").text("/accessToken");
    assertThat(Http.get(b + "/api/me", bobToken).status()).isEqualTo(200);

    assertThat(Http.post(a + "/api/users/" + bob + "/disable", adminToken, "").status()).isEqualTo(200);

    Duration took = awaitStatus(() -> Http.get(b + "/api/me", bobToken), 401);
    observed("user disabled on iam-a -> rejected by iam-b", took);
    assertThat(took).as("revocation latency on the second instance").isLessThanOrEqualTo(REVOCATION_SLA);
    assertThat(Http.get(b + "/api/me", bobToken).text("/code")).isEqualTo("token_revoked");
    assertThat(awaitStatus(() -> Http.get(a + "/api/me", bobToken), 401)).as("and on the instance that disabled him")
        .isLessThanOrEqualTo(REVOCATION_SLA);
  }

  @Test
  @Order(7)
  void revokingARoleIsEnforcedOnTheOtherInstanceWithinFiveSeconds() {
    String window = window();
    assertThat(Http.get(b + "/api/audit/events?" + window, aliceToken).status()).isEqualTo(200);

    assertThat(Http.delete(a + "/api/assignments/" + auditorGrantOfAlice, adminToken).status()).isEqualTo(204);

    String revoked = aliceToken;
    Duration took = awaitStatus(() -> Http.get(b + "/api/audit/events?" + window, revoked), 401);
    observed("role assignment revoked on iam-a -> rejected by iam-b", took);
    assertThat(took).as("revocation latency on the second instance").isLessThanOrEqualTo(REVOCATION_SLA);
    aliceToken = login("alice@acme.e2e").text("/accessToken");
    assertThat(Http.perms(aliceToken)).isEqualTo(explain(alice, t1));
  }

  // ================================================================================== 4. everything audited

  @Test
  @Order(8)
  void everyRowChangeAuthEventDenialAndSensitiveReadIsInTheAuditLogWhichTheAppRoleCannotChange() throws Exception {
    assertThat(Http.get(a + "/api/platform/accounts", aliceToken).status()).isEqualTo(403);
    Response export = Http.get(a + "/api/audit/exports.csv?" + window(), adminToken);
    assertThat(export.status()).as(export.toString()).isEqualTo(200);

    assertThat(auditCount("action = 'iam.tenant.insert' AND target_id = ?", t2.toString())).as("row change")
        .isEqualTo(1);
    assertThat(auditCount("action = 'iam.role_assignment.insert' AND account_id = ?", account)).isGreaterThanOrEqualTo(4);
    assertThat(auditCount("action = 'iam.role_assignment.delete' AND target_id = ?", auditorGrantOfAlice.toString()))
        .isEqualTo(1);
    assertThat(auditCount("action = 'iam.app_user.update' AND target_id = ?", bob.toString()))
        .as("bob disabled").isGreaterThanOrEqualTo(1);
    assertThat(auditCount("action = 'auth.login.success' AND actor_user_id = ?", alice)).as("auth event")
        .isGreaterThanOrEqualTo(2);
    assertThat(auditCount("action = 'auth.invitation.accepted' AND account_id = ?", account)).isEqualTo(3);
    assertThat(auditCount("action = 'auth.sessions.revoked' AND account_id = ?", account)).isGreaterThanOrEqualTo(2);
    assertThat(auditCount("action = 'authz.denied' AND actor_user_id = ? AND outcome = 'DENIED'", alice))
        .as("denial").isGreaterThanOrEqualTo(1);
    Awaitility.await("export audited").atMost(Duration.ofSeconds(10)).until(() ->
        auditCount("action = 'iam.audit.exported' AND actor_user_id = ?", admin) == 1);
    assertThat(auditCount("action = 'iam.audit.export.started' AND actor_user_id = ?", admin)).as("sensitive read")
        .isEqualTo(1);

    try (Connection app = DriverManager.getConnection(jdbcUrl("iam_db"), "iam_app", "iam_app_e2e")) {
      for (String sql : List.of("UPDATE audit_event SET action = 'tampered' WHERE account_id = '" + account + "'",
          "DELETE FROM audit_event WHERE account_id = '" + account + "'", "TRUNCATE audit_event")) {
        assertThatThrownBy(() -> app.createStatement().execute(sql)).as(sql)
            .isInstanceOfSatisfying(SQLException.class, e -> assertThat(e.getSQLState()).isEqualTo("42501"));
      }
    }
  }

  // ======================================================== 5. sample app: authorize, audit, react to revocation

  @Test
  @Order(9)
  void theSampleAppAuthorizesFromARealJwtAndAuditsThroughTheRelay() throws Exception {
    Response invoices = Http.get(s + "/invoices", aliceToken);
    assertThat(invoices.status()).as(invoices.toString()).isEqualTo(200);
    assertThat(invoices.text("/scope")).isEqualTo("ACCOUNT");
    assertThat(Http.get(s + "/invoices", null).status()).isEqualTo(401);

    UUID invoice = UUID.randomUUID();
    try (Connection c = DriverManager.getConnection(jdbcUrl("sample_db"), "sample", "sample_e2e");
         PreparedStatement insert = c.prepareStatement(
             "INSERT INTO invoice (id, account_id, tenant_id, owner_id, number, amount) VALUES (?, ?, ?, ?, 'E2E-1', 42)")) {
      insert.setObject(1, invoice);
      insert.setObject(2, account);
      insert.setObject(3, t1);
      insert.setObject(4, alice);
      insert.executeUpdate();
    }
    Response approved = Http.post(s + "/invoices/" + invoice + "/approve", aliceToken, "");
    assertThat(approved.status()).as(approved.toString()).isEqualTo(204);

    Awaitility.await("invoice.approved relayed into IAM").atMost(Duration.ofSeconds(20))
        .pollInterval(Duration.ofMillis(200)).until(() -> auditCount(
            "action = 'invoice.approved' AND target_id = ? AND source = 'BILLING'", invoice.toString()) == 1);
    assertThat(auditCount("action = 'invoice.approved' AND target_id = ? AND actor_user_id = ? AND tenant_id = ?",
        invoice.toString(), alice, t1)).isEqualTo(1);
    Awaitility.await("outbox drained").atMost(Duration.ofSeconds(10)).until(() -> sampleOutbox() == 0);
  }

  @Test
  @Order(10)
  void theIngestApiAccountsForEveryEventOfABatch() {
    Response token = Http.postForm(a + "/internal/token", CLIENT_ID, clientSecret, "grant_type=client_credentials");
    assertThat(token.status()).as(token.toString()).isEqualTo(200);
    String app = token.text("/access_token");
    // a retried event is byte-for-byte the same (the relay re-sends the outbox payload): same eventId and occurredAt
    Map<String, Object> first = event(UUID.randomUUID(), "e2e.relay.check");
    alreadyIngested = first;
    List<Map<String, Object>> events = List.of(first, first, event(UUID.randomUUID(), "Not A Valid Action!"),
        event(UUID.randomUUID(), "e2e.relay.check"));
    Map<String, Object> batch = Map.of("events", events);

    Response once = Http.post(a + "/internal/audit/events", app, batch);
    assertThat(once.status()).as(once.toString()).isEqualTo(200);
    assertThat(accounted(once.json())).as("accepted + duplicates + rejected == batch").isEqualTo(events.size());
    assertThat(once.json().get("accepted").asInt()).isEqualTo(2);
    assertThat(once.json().get("rejected")).hasSize(1);

    Response again = Http.post(a + "/internal/audit/events", app, batch);
    assertThat(accounted(again.json())).isEqualTo(events.size());
    assertThat(again.json().get("accepted").asInt()).isZero();
    assertThat(again.json().get("duplicates").asInt()).isEqualTo(3);
  }

  /**
   * The real sample-app relay with a mixed batch: a new event, an invalid one and one IAM already has. The relay deletes
   * a batch only when IAM's answer accounts for every event (accepted + duplicates + rejected == batch) and keeps it
   * otherwise, so a drained outbox proves the accounting held against the real ingest; the invalid event is dropped
   * (logged), the duplicate is not stored twice.
   */
  @Test
  @Order(11)
  void theSampleAppRelayDrainsAMixedBatchThroughTheRealIngest() throws Exception {
    UUID fresh = UUID.randomUUID();
    UUID invalid = UUID.randomUUID();
    Map<String, Object> bad = event(invalid, "Not A Valid Action!");
    try (Connection c = DriverManager.getConnection(jdbcUrl("sample_db"), "sample", "sample_e2e")) {
      c.setAutoCommit(false); // one transaction: the relay sees the three rows together, as one batch
      for (Map<String, Object> e : List.of(event(fresh, "e2e.relay.mixed"), bad, alreadyIngested)) {
        try (PreparedStatement insert = c.prepareStatement("""
            INSERT INTO iam_audit_outbox (event_id, occurred_at, payload)
            VALUES (CAST(? AS uuid), CAST(? AS timestamptz), CAST(? AS jsonb))""")) {
          insert.setString(1, (String) e.get("eventId"));
          insert.setString(2, (String) e.get("occurredAt"));
          insert.setString(3, Http.JSON.writeValueAsString(e));
          insert.executeUpdate();
        }
      }
      c.commit();
    }

    Awaitility.await("mixed batch relayed").atMost(Duration.ofSeconds(20)).pollInterval(Duration.ofMillis(200))
        .until(() -> sampleOutbox() == 0);
    assertThat(auditCount("event_id = ? AND source = 'BILLING'", fresh)).isEqualTo(1);
    assertThat(auditCount("event_id = ?", invalid)).isZero();
    assertThat(auditCount("event_id = ?", UUID.fromString((String) alreadyIngested.get("eventId")))).isEqualTo(1);
    assertThat(java.nio.file.Files.readString(sample.log()))
        .contains("IAM rejected audit event " + invalid);
  }

  @Test
  @Order(12)
  void theSampleAppRejectsARevokedTokenWithinFiveSeconds() {
    String token = aliceToken;
    assertThat(Http.get(s + "/invoices", token).status()).isEqualTo(200);

    assertThat(Http.post(a + "/api/users/" + alice + "/disable", adminToken, "").status()).isEqualTo(200);

    Duration took = awaitStatus(() -> Http.get(s + "/invoices", token), 401);
    observed("user disabled on iam-a -> rejected by sample-app", took);
    assertThat(took).as("revocation latency in the sample application").isLessThanOrEqualTo(REVOCATION_SLA);
  }

  /** Ruling R36: actuator on the management port only; the application port answers just the probes. */
  @Test
  @Order(13)
  void actuatorIsOnTheManagementPortOnly() {
    String management = "http://localhost:" + managementA;
    assertThat(Http.get(a + "/actuator/health/liveness", null).status()).isEqualTo(200);
    assertThat(Http.get(a + READINESS, null).status()).isEqualTo(200);
    assertThat(Http.get(a + "/actuator/prometheus", null).status()).isIn(401, 404);
    assertThat(Http.get(a + "/actuator/health", null).status()).isIn(401, 404);
    Response metrics = Http.get(management + "/actuator/prometheus", null);
    assertThat(metrics.status()).isEqualTo(200);
    assertThat(metrics.raw()).contains("iam_");
    assertThat(Http.get(management + "/actuator/health", null).status()).isEqualTo(200);
  }

  // ======================================================================== P1-11.4 failure modes (processes)

  @Test
  @Order(20)
  void aPostgresOutageFailsRequestsFastWith503AndHikariRecovers() throws InterruptedException {
    assertThat(Http.get(a + "/api/me", adminToken).status()).isEqualTo(200);
    String container = POSTGRES.getContainerId();
    POSTGRES.getDockerClient().pauseContainerCmd(container).exec();
    try {
      // past Hikari's 500 ms "recently used, skip validation" window: the next borrow validates the connection.
      // A request that is already running (or borrows within that window) waits for the pgjdbc socketTimeout (30 s)
      // instead, then also fails with 503 (docs/failure-modes.md).
      Thread.sleep(1_500);
      Instant start = Instant.now();
      Response during = Http.get(a + "/api/me", adminToken);
      Duration took = Duration.between(start, Instant.now());
      observed("request during the database outage answered " + during.status(), took);
      assertThat(during.status()).as(during.toString()).isEqualTo(503);
      assertThat(during.text("/code")).isEqualTo("database_unavailable");
      assertThat(during.header("Retry-After")).isEqualTo("5");
      assertThat(during.header("Content-Type")).contains("application/problem+json");
      assertThat(took).as("fails within the pool timeout instead of hanging").isLessThan(Duration.ofSeconds(15));
      // token validation needs no database: JWKS is served from memory
      assertThat(Http.get(a + "/.well-known/jwks.json", null).status()).isEqualTo(200);
    } finally {
      POSTGRES.getDockerClient().unpauseContainerCmd(container).exec();
    }
    Duration recovered = awaitStatus(() -> Http.get(a + "/api/me", adminToken), 200, Duration.ofSeconds(30));
    observed("database resumed -> first 200 from iam-a", recovered);
    assertThat(recovered).isLessThan(Duration.ofSeconds(30));
    assertThat(Http.get(b + "/api/me", adminToken).status()).isEqualTo(200);
  }

  @Test
  @Order(21)
  void aRestartedIamInstanceRejectsEarlierRevocationsFromItsFirstRequest() {
    UUID dave = invite(t1, "dave@acme.e2e");
    String daveToken = accept("dave@acme.e2e");
    assertThat(Http.get(b + "/api/me", daveToken).status()).isEqualTo(200);

    iamB.stop();
    assertThat(Http.post(a + "/api/users/" + dave + "/disable", adminToken, "").status()).isEqualTo(200);
    iamB.start();

    Response first = Http.get(b + "/api/me", daveToken);
    assertThat(first.status()).as("first request after the restart: " + first).isEqualTo(401);
    assertThat(first.text("/code")).isEqualTo("token_revoked");
  }

  @Test
  @Order(22)
  void theClientPollerKeepsItsStateAndCursorAcrossAnIamRestart() throws Exception {
    UUID erin = invite(t1, "erin@acme.e2e");
    String erinToken = accept("erin@acme.e2e");
    assertThat(Http.get(s + "/invoices", erinToken).status()).as("authenticated, no billing permission").isEqualTo(403);
    String aliceRevoked = aliceToken;

    iamA.stop();
    Thread.sleep(4_000); // at least one failed revocation poll and audit relay attempt in the sample app
    assertThat(Http.get(s + "/invoices", aliceRevoked).status()).as("revocations survive IAM being down").isEqualTo(401);
    iamA.start();

    assertThat(Http.post(a + "/api/users/" + erin + "/disable", adminToken, "").status()).isEqualTo(200);
    Duration took = awaitStatus(() -> Http.get(s + "/invoices", erinToken), 401);
    observed("after an iam-a restart: user disabled -> rejected by sample-app", took);
    assertThat(took).as("the client resumes from its cursor after IAM restarts").isLessThanOrEqualTo(REVOCATION_SLA);
    assertThat(Http.get(s + "/invoices", aliceRevoked).status()).isEqualTo(401);
  }

  // ================================================================================================ helpers

  /** Printed to the test report (system-out) and quoted in docs/failure-modes.md. */
  private static void observed(String what, Duration took) {
    System.out.printf("E2E-OBSERVED %-70s %5d ms%n", what, took.toMillis());
  }

  private static List<String> with(List<String> base, String extra) {
    List<String> all = new ArrayList<>(base);
    all.add(extra);
    return all;
  }

  private static String jdbcUrl(String database) {
    return "jdbc:postgresql://" + POSTGRES.getHost() + ":" + POSTGRES.getMappedPort(5432) + "/" + database;
  }

  private static Connection migrator() throws SQLException {
    return DriverManager.getConnection(jdbcUrl("iam_db"), "iam_migrator", "iam_migrator_e2e");
  }

  /** Accepts the latest invitation mailed to {@code email}; returns the access token of the new session. */
  private String accept(String email) {
    return acceptToken(smtp.awaitToken(email), email);
  }

  private String acceptToken(String token, String email) {
    Response accepted = Http.post(a + "/auth/invitations/accept", null,
        Map.of("token", token, "password", PASSWORD, "displayName", email.substring(0, email.indexOf('@'))));
    assertThat(accepted.status()).as(accepted.toString()).isEqualTo(200);
    return accepted.text("/accessToken");
  }

  private Response login(String email) {
    Response login = Http.post(a + "/auth/login", null, Map.of("email", email, "password", PASSWORD));
    assertThat(login.status()).as(login.toString()).isEqualTo(200);
    return login;
  }

  private UUID invite(UUID tenant, String email) {
    Response invited = Http.post(a + "/api/tenants/" + tenant + "/users", adminToken, Map.of("email", email));
    assertThat(invited.status()).as(invited.toString()).isEqualTo(201);
    return UUID.fromString(invited.text("/user/id"));
  }

  private UUID assign(UUID user, UUID role, String scopeType, UUID scopeId) {
    Response assigned = Http.post(a + "/api/users/" + user + "/assignments", adminToken,
        Map.of("roleId", role, "scopeType", scopeType, "scopeId", scopeId));
    assertThat(assigned.status()).as(assigned.toString()).isEqualTo(201);
    return UUID.fromString(assigned.text("/id"));
  }

  private Map<String, UUID> systemRoles(String product) {
    Response roles = Http.get(a + "/api/roles?type=SYSTEM&limit=200&productCode=" + product, adminToken);
    assertThat(roles.status()).as(roles.toString()).isEqualTo(200);
    Map<String, UUID> byName = new LinkedHashMap<>();
    roles.json().get("items").forEach(r -> byName.put(r.get("name").asText(), UUID.fromString(r.get("id").asText())));
    return byName;
  }

  private Set<String> explain(UUID user, UUID tenant) {
    Response explained = Http.get(a + "/api/users/" + user + "/effective-permissions?tenantId=" + tenant, adminToken);
    assertThat(explained.status()).as(explained.toString()).isEqualTo(200);
    Set<String> codes = new HashSet<>();
    explained.json().get("permissions").forEach(p -> codes.add(p.get("code").asText()));
    return codes;
  }

  private static String window() {
    Instant now = Instant.now().truncatedTo(ChronoUnit.SECONDS);
    return "from=" + now.minus(1, ChronoUnit.HOURS) + "&to=" + now.plus(1, ChronoUnit.MINUTES);
  }

  private static Duration awaitStatus(Supplier<Response> call, int status) {
    return awaitStatus(call, status, Duration.ofSeconds(15));
  }

  /** Polls every 100 ms until {@code call} answers {@code status}; returns how long it took. */
  private static Duration awaitStatus(Supplier<Response> call, int status, Duration max) {
    Instant start = Instant.now();
    Awaitility.await().atMost(max).pollDelay(Duration.ZERO).pollInterval(Duration.ofMillis(100))
        .ignoreExceptions().until(() -> call.get().status() == status);
    return Duration.between(start, Instant.now());
  }

  private long auditCount(String where, Object... params) throws SQLException {
    try (Connection c = migrator();
         PreparedStatement q = c.prepareStatement("SELECT count(*) FROM audit_event WHERE " + where)) {
      for (int i = 0; i < params.length; i++) {
        q.setObject(i + 1, params[i]);
      }
      try (ResultSet rs = q.executeQuery()) {
        rs.next();
        return rs.getLong(1);
      }
    }
  }

  private long sampleOutbox() throws SQLException {
    try (Connection c = DriverManager.getConnection(jdbcUrl("sample_db"), "sample", "sample_e2e");
         ResultSet rs = c.createStatement().executeQuery("SELECT count(*) FROM iam_audit_outbox")) {
      rs.next();
      return rs.getLong(1);
    }
  }

  private Map<String, Object> event(UUID id, String action) {
    Map<String, Object> event = new LinkedHashMap<>();
    event.put("eventId", id.toString());
    event.put("occurredAt", Instant.now().toString());
    event.put("accountId", account.toString());
    event.put("tenantId", null);
    event.put("actorUserId", null);
    event.put("actorType", "SYSTEM");
    event.put("action", action);
    event.put("outcome", "SUCCESS");
    event.put("metadata", Map.of("e2e", true));
    return event;
  }

  private static int accounted(JsonNode result) {
    return result.get("accepted").asInt() + result.get("duplicates").asInt() + result.get("rejected").size();
  }
}
