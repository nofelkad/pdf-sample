package com.acme.iam.e2e;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.Duration;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

/**
 * A Spring Boot jar run as a child process ({@code java -jar}) with its own environment, on a fixed port so it can be
 * stopped and started again at the same address. Output goes to {@code <e2e.logDir>/<name>.log} (appended across
 * restarts).
 */
final class JarProcess {

  private static final HttpClient HTTP = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(2)).build();

  private final String name;
  private final Path jar;
  private final Map<String, String> env;
  private final List<String> args;
  private final int port;
  private final String healthPath;
  private Process process;

  JarProcess(String name, Path jar, int port, Map<String, String> env, List<String> args) {
    this(name, jar, port, "/actuator/health", env, args);
  }

  /** {@code healthPath}: the readiness URL on the application port (iam-service: the readiness probe, R36). */
  JarProcess(String name, Path jar, int port, String healthPath, Map<String, String> env, List<String> args) {
    this.healthPath = healthPath;
    this.name = name;
    this.jar = jar;
    this.port = port;
    this.env = env;
    this.args = args;
  }

  static int freePort() {
    try (ServerSocket socket = new ServerSocket(0)) {
      return socket.getLocalPort();
    } catch (IOException e) {
      throw new IllegalStateException(e);
    }
  }

  static Path logDir() {
    Path dir = Path.of(System.getProperty("e2e.logDir", "build/e2e-logs"));
    try {
      Files.createDirectories(dir);
    } catch (IOException e) {
      throw new IllegalStateException(e);
    }
    return dir;
  }

  int port() {
    return port;
  }

  String baseUrl() {
    return "http://localhost:" + port;
  }

  Path log() {
    return logDir().resolve(name + ".log");
  }

  /** Starts the process and waits until its health path answers 200 (at most 120 s). */
  JarProcess start() {
    process = launch(args);
    Instant deadline = Instant.now().plusSeconds(120);
    while (Instant.now().isBefore(deadline)) {
      if (!process.isAlive()) {
        throw new IllegalStateException(name + " exited with " + process.exitValue() + "; see " + log());
      }
      try {
        HttpResponse<String> health = HTTP.send(HttpRequest.newBuilder(URI.create(baseUrl() + healthPath))
            .timeout(Duration.ofSeconds(2)).build(), HttpResponse.BodyHandlers.ofString());
        if (health.statusCode() == 200) {
          return this;
        }
      } catch (IOException e) {
        // not listening yet
      } catch (InterruptedException e) {
        Thread.currentThread().interrupt();
        throw new IllegalStateException(e);
      }
      sleep(250);
    }
    throw new IllegalStateException(name + " did not become healthy in 120 s; see " + log());
  }

  /** Runs the jar with extra arguments to completion (a CLI command) and returns its exit code. */
  int run(List<String> extraArgs) {
    List<String> all = new ArrayList<>(args);
    all.addAll(extraArgs);
    Process cli = launch(all);
    try {
      if (!cli.waitFor(120, TimeUnit.SECONDS)) {
        cli.destroyForcibly();
        throw new IllegalStateException(name + " CLI did not finish in 120 s; see " + log());
      }
      return cli.exitValue();
    } catch (InterruptedException e) {
      Thread.currentThread().interrupt();
      throw new IllegalStateException(e);
    }
  }

  /** Graceful stop (SIGTERM), forced after 30 s. */
  void stop() {
    if (process == null || !process.isAlive()) {
      return;
    }
    process.destroy();
    try {
      if (!process.waitFor(30, TimeUnit.SECONDS)) {
        process.destroyForcibly().waitFor(10, TimeUnit.SECONDS);
      }
    } catch (InterruptedException e) {
      Thread.currentThread().interrupt();
    }
  }

  boolean isAlive() {
    return process != null && process.isAlive();
  }

  private Process launch(List<String> arguments) {
    String java = ProcessHandle.current().info().command().orElse("java");
    List<String> command = new ArrayList<>(List.of(java, "-Xmx512m", "-XX:TieredStopAtLevel=1", "-jar",
        jar.toString()));
    command.addAll(arguments);
    ProcessBuilder builder = new ProcessBuilder(command)
        .redirectErrorStream(true)
        .redirectOutput(ProcessBuilder.Redirect.appendTo(log().toFile()));
    builder.environment().putAll(env);
    try {
      return builder.start();
    } catch (IOException e) {
      throw new IllegalStateException("Could not start " + name, e);
    }
  }

  private static void sleep(long millis) {
    try {
      Thread.sleep(millis);
    } catch (InterruptedException e) {
      Thread.currentThread().interrupt();
      throw new IllegalStateException(e);
    }
  }
}
