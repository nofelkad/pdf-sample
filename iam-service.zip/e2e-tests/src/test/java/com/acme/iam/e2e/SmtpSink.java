package com.acme.iam.e2e;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.awaitility.Awaitility;

/**
 * A minimal SMTP server (EHLO, MAIL, RCPT, DATA, RSET, NOOP, QUIT; no TLS, no auth) that keeps every message, so the
 * suite can read the invitation and reset links iam-service mails in {@code iam.notification.mode=smtp}.
 */
final class SmtpSink implements AutoCloseable {

  record Mail(List<String> recipients, String data) {}

  private static final Pattern TOKEN = Pattern.compile("token=(?:3D)?([A-Za-z0-9_-]{20,})");

  private final ServerSocket server;
  private final List<Mail> mails = new CopyOnWriteArrayList<>();
  private final Thread acceptor;

  SmtpSink() throws IOException {
    server = new ServerSocket(0);
    acceptor = new Thread(this::acceptLoop, "e2e-smtp");
    acceptor.setDaemon(true);
    acceptor.start();
  }

  int port() {
    return server.getLocalPort();
  }

  List<Mail> mails() {
    return List.copyOf(mails);
  }

  /** The raw token of the latest mail to {@code recipient} whose link carries {@code token=}, waiting up to 15 s. */
  String awaitToken(String recipient) {
    String[] found = new String[1];
    Awaitility.await("mail to " + recipient).atMost(Duration.ofSeconds(15)).pollInterval(Duration.ofMillis(100))
        .until(() -> {
          for (int i = mails.size() - 1; i >= 0; i--) {
            Mail mail = mails.get(i);
            if (mail.recipients().stream().anyMatch(r -> r.equalsIgnoreCase(recipient))) {
              Matcher m = TOKEN.matcher(mail.data().replace("=\r\n", "").replace("=\n", ""));
              if (m.find()) {
                found[0] = m.group(1);
                return true;
              }
            }
          }
          return false;
        });
    return found[0];
  }

  private void acceptLoop() {
    while (!server.isClosed()) {
      try {
        Socket socket = server.accept();
        Thread session = new Thread(() -> session(socket), "e2e-smtp-session");
        session.setDaemon(true);
        session.start();
      } catch (IOException e) {
        return;
      }
    }
  }

  private void session(Socket socket) {
    try (socket; BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream(),
        StandardCharsets.UTF_8)); OutputStream out = socket.getOutputStream()) {
      reply(out, "220 e2e ESMTP sink");
      List<String> recipients = new ArrayList<>();
      String line;
      while ((line = in.readLine()) != null) {
        String command = line.toUpperCase(Locale.ROOT);
        if (command.startsWith("EHLO")) {
          reply(out, "250-e2e\r\n250 OK");
        } else if (command.startsWith("HELO") || command.startsWith("MAIL FROM") || command.startsWith("NOOP")) {
          reply(out, "250 OK");
        } else if (command.startsWith("RSET")) {
          recipients.clear();
          reply(out, "250 OK");
        } else if (command.startsWith("RCPT TO")) {
          recipients.add(line.substring(line.indexOf('<') + 1, line.lastIndexOf('>')));
          reply(out, "250 OK");
        } else if (command.equals("DATA")) {
          reply(out, "354 End data with <CR><LF>.<CR><LF>");
          StringBuilder data = new StringBuilder();
          String dataLine;
          while ((dataLine = in.readLine()) != null && !dataLine.equals(".")) {
            data.append(dataLine.startsWith("..") ? dataLine.substring(1) : dataLine).append('\n');
          }
          mails.add(new Mail(List.copyOf(recipients), data.toString()));
          recipients.clear();
          reply(out, "250 OK queued");
        } else if (command.startsWith("QUIT")) {
          reply(out, "221 bye");
          return;
        } else {
          reply(out, "250 OK");
        }
      }
    } catch (IOException e) {
      // client went away
    }
  }

  private static void reply(OutputStream out, String text) throws IOException {
    out.write((text + "\r\n").getBytes(StandardCharsets.UTF_8));
    out.flush();
  }

  @Override
  public void close() throws IOException {
    server.close();
  }
}
