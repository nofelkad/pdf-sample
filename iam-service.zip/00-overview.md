# IAM Platform: Implementation Plan Overview

This is a new, standalone Identity & Access Management service for an enterprise multi-product platform. It manages accounts, tenants, products, users, roles and permissions, handles login and issues JWTs. Other applications use it only through its APIs and the JWTs it issues.

| | |
|---|---|
| Runtime | Java 21, Spring Boot 3.x |
| Persistence | PostgreSQL 16 only. **Spring Data JDBC** (no JPA/Hibernate), `JdbcClient` for custom queries, Flyway |
| Security | Spring Security 6: password login, JWT issuing (Nimbus), resource server, method security |
| Infrastructure | **Postgres only.** No Redis, Kafka, Keycloak or object storage. Scheduled jobs use ShedLock (JDBC), rate limiting uses Bucket4j (Postgres backend) |
| Deliverables | `iam-service` (one Spring Boot app) and `iam-client` (a small Spring Boot starter that other applications include to validate tokens) |
| Phase 1 | Core IAM, password login, JWT. ~8 weeks |
| Phase 2 | Enterprise features: SSO, MFA, SCIM, API keys, approvals, tamper-evident audit. ~7 weeks |
| Files | `01-phase-1.md`, `02-phase-2.md` |

---

## Requirements covered

| Requirement | How |
|---|---|
| Multiple accounts | `account` table; each account is a customer and the identity boundary |
| An account has multiple tenants | `tenant.account_id` |
| An account has access to multiple products | `account_product` (subscription); `tenant_product` decides which of those products each tenant has enabled |
| A user belongs to one primary tenant | `app_user.primary_tenant_id` |
| A user can be shared across tenants | `user_tenant_membership` rows (same account only) |
| Products define permissions for feature and data access | `permission(product_id, code, kind = FEATURE or DATA)`, registered from a manifest file |
| Roles group permissions | `role` + `role_permission` |
| System roles and custom roles | `role.type = SYSTEM` (global, read-only) or `CUSTOM` (owned by an account) |
| A user can have multiple roles | `role_assignment` with scope ACCOUNT or TENANT |
| Login | Email and password, JWT access token plus rotating refresh token |
| Audit everything | Every write (DB triggers), every auth event, every denial and every sensitive read go to `audit_event`, append-only and partitioned |

---

## Guiding rules

1. **Code checks permissions, never roles**, e.g. `hasAuthority('billing.invoice.approve')`. Roles are customer data and can be renamed; permission codes are stable.
2. **Feature access and data access use the same mechanism.** Data scope is a suffix on the permission code: `.own`, `.tenant` or `.account`.
3. **The active tenant comes from the token**, never from the request body or query.
4. **The JWT carries the effective permissions.** Applications authorize locally, with no call to IAM per request.
5. **Every write is audited in the same transaction**, so a business change cannot exist without its audit row.
6. **Spring Data JDBC aggregates stay small.** References between aggregates are by id (`AggregateReference`). Complex reads go through `JdbcClient` with plain SQL.
7. **Postgres is the only stateful dependency.** Keep it that way unless a measured bottleneck forces a change.

---

## Domain model

```
Account ──< Tenant ──< UserTenantMembership >── User (primary_tenant_id)
   │           │                                  │
   │           └──< TenantProduct                 └──< RoleAssignment ──> Role ──< RolePermission ──> Permission
   └──< AccountProduct >── Product ─────────────────────────────────────────┴──────────────────────────────┘
                                                      scope = ACCOUNT | TENANT
```

**Spring Data JDBC aggregates**

| Aggregate root | Owns (saved with root) | References by id |
|---|---|---|
| `Account` | `Set<AccountProduct>` | – |
| `Tenant` | `Set<TenantProduct>` | `account` |
| `Product` | – | – |
| `Permission` | – | `product` |
| `Role` | `Set<RolePermission>` | `product`, `account` (nullable) |
| `AppUser` | `Set<Membership>` | `account`, `primaryTenant` |
| `RoleAssignment` | – | `user`, `role` |
| `UserSession` | – | `user`, `activeTenant` |

`RoleAssignment` is its own aggregate because it is queried by scope and by role, not only by user.

---

## Phase split

| Capability | P1 | P2 |
|---|:-:|:-:|
| Accounts, tenants, products, subscriptions | ✅ | |
| Permission registry (manifest per product) | ✅ | |
| Users, primary tenant, sharing, invitations, bulk invite | ✅ | |
| System and custom roles, multiple roles per user, account or tenant scope, expiry | ✅ | |
| Password login, JWT, refresh rotation, tenant switch, logout, password reset | ✅ | |
| Lockout, password policy, login rate limiting | ✅ | |
| Near-instant revocation (revocation feed) | ✅ | |
| Platform operator (super-admin) account | ✅ | |
| Audit of everything, audit search and export | ✅ | |
| `iam-client` starter for applications | ✅ | |
| Basic separation of duties (no granting what you don't hold, protect the last admin) | ✅ | |
| SSO (OIDC + SAML), domain discovery, JIT provisioning, enforce SSO | | ✅ |
| MFA (TOTP) | | ✅ |
| SCIM 2.0, IdP group to role mapping | | ✅ |
| Service accounts and API keys | | ✅ |
| Per-account session policy, two-person approval, operator access grants | | ✅ |
| Hash-chained audit, SIEM webhook export, verification | | ✅ |
| Data export and erasure | | ✅ |

**Not planned:** role inheritance, deny rules, ABAC/policy engine, per-tenant custom permissions, cross-account users, schema-per-tenant, nested tenants.

---

## Performance targets

| Metric | Target |
|---|---|
| Authorization overhead in an application | < 0.5 ms (JWT verify + in-memory revocation check) |
| Login p95 | < 250 ms (dominated by Argon2, about 100 ms) |
| Refresh / tenant switch p95 | < 50 ms |
| Effective-permission query p95 | < 15 ms for a user with 20 assignments |
| Revocation latency | ≤ 5 s across all applications |
| Audit overhead per write | < 2 ms |
| Audit search (1 tenant, 30 days) | < 500 ms p95 |
| Design scale | 5k accounts, 20k tenants, 1M users, 100M audit rows/year, 2+ stateless IAM instances |

Team assumption: 3 backend engineers and 0.5 QA. Estimates are in engineer-days (d). The admin UI is a separate project that consumes these APIs; it is not estimated here.
