# Phase 1: Core IAM with JWT login

**Goal:** a standalone IAM service where an operator creates accounts, account admins manage tenants, users and roles, users log in with email and password, and get a JWT carrying their permissions for the active tenant. Every change is audited.
**Duration:** ~8 weeks · **Infrastructure:** PostgreSQL only.

---

## 1. Architecture

```
          Admin UI / any client                       Business applications (any product)
                 │  HTTPS                                   │ include iam-client starter
                 ▼                                          │  - validates JWT via JWKS (cached)
        ┌─────────────────────────┐   GET /.well-known/jwks.json
        │       iam-service       │◄──────────────────────────┤
        │  (N stateless pods)     │   GET /internal/revocations?since=  (every 5 s)
        │                         │◄──────────────────────────┤
        │  /auth/*   login, JWT   │   POST /internal/audit/events (batched)
        │  /api/*    admin APIs   │◄──────────────────────────┘
        │  /internal/*            │
        │  schedulers (ShedLock)  │
        └───────────┬─────────────┘
                    │ HikariCP
              PostgreSQL (iam_db)
```

- **iam-service** is a stateless Spring Boot app, so you can run as many instances as you need. All state lives in Postgres.
- **JWT signing keys** are stored in Postgres, with the private key encrypted by a master key from the environment or secrets manager. They are published at `/.well-known/jwks.json`.
- **Revocation without Redis:** IAM writes a revocation row whenever a user's access may shrink. Every application (and IAM itself) polls a small feed every 5 s and keeps an in-memory map `userId → minSessionVersion`. Each token carries `sv`; if `sv` is lower than the stored minimum, the request gets 401.
- **Scheduled jobs** (partition creation, assignment expiry, purges) use `@Scheduled` + **ShedLock** (JDBC provider), so only one instance runs each job.
- **Rate limiting** on `/auth/*` uses Bucket4j with its PostgreSQL proxy-manager backend, so limits hold across instances.

### Project structure (modular monolith, package by feature)

```
iam-service/
 ├─ src/main/java/com/acme/iam/
 │   ├─ IamApplication.java
 │   ├─ common/        security config, JwtIssuer, TenantGuard, error handling (RFC 7807), JdbcConfig, TxContextTransactionManager
 │   ├─ account/       Account aggregate, AccountService, AccountController (platform)
 │   ├─ tenant/        Tenant aggregate, TenantService, TenantController
 │   ├─ product/       Product, Permission, RegistryService (manifest upsert)
 │   ├─ user/          AppUser aggregate (+Membership), UserService, InvitationService
 │   ├─ role/          Role aggregate (+RolePermission), RoleService
 │   ├─ assignment/    RoleAssignment aggregate, AssignmentService, PermissionResolver
 │   ├─ auth/          AuthController, LoginService, SessionService, PasswordService, RevocationService
 │   └─ audit/         AuditWriter, AuditQueryService, AuditController, PartitionJob
 ├─ src/main/resources/db/migration/   V1__core.sql, V2__audit.sql, V3__seed.sql …
 └─ src/test/...       Testcontainers Postgres for all integration tests

iam-client/            Spring Boot starter (autoconfig): resource server, revocation poller, TenantContext, @Audited, audit relay
```

Use ArchUnit to enforce that packages talk to each other only through their `*Service` classes.

---

## 2. Schema

### `V1__core.sql`

```sql
CREATE EXTENSION IF NOT EXISTS citext;

-- ===== Commercial & isolation =====
CREATE TABLE account (
  id          UUID PRIMARY KEY,
  name        TEXT   NOT NULL,
  slug        CITEXT NOT NULL UNIQUE,                 -- used in login when an email exists in >1 account
  kind        TEXT   NOT NULL DEFAULT 'CUSTOMER' CHECK (kind IN ('CUSTOMER','PLATFORM')),
  status      TEXT   NOT NULL CHECK (status IN ('ACTIVE','SUSPENDED','CLOSED')),
  settings    JSONB  NOT NULL DEFAULT '{}',           -- password policy, token lifetimes
  version     BIGINT NOT NULL,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE product (
  id          UUID PRIMARY KEY,
  code        TEXT UNIQUE NOT NULL,                   -- IAM, BILLING, CRM …
  name        TEXT NOT NULL,
  version     BIGINT NOT NULL
);

CREATE TABLE account_product (
  account     UUID NOT NULL REFERENCES account(id) ON DELETE CASCADE,
  product_id  UUID NOT NULL REFERENCES product(id),
  status      TEXT NOT NULL CHECK (status IN ('ACTIVE','TRIAL','SUSPENDED','EXPIRED')),
  starts_at   DATE NOT NULL,
  ends_at     DATE,
  PRIMARY KEY (account, product_id)
);

CREATE TABLE tenant (
  id          UUID PRIMARY KEY,
  account_id  UUID   NOT NULL REFERENCES account(id),
  name        TEXT   NOT NULL,
  slug        CITEXT NOT NULL,
  status      TEXT   NOT NULL CHECK (status IN ('ACTIVE','SUSPENDED','ARCHIVED')),
  settings    JSONB  NOT NULL DEFAULT '{}',
  version     BIGINT NOT NULL,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (account_id, slug)
);
CREATE INDEX tenant_account_idx ON tenant(account_id);

CREATE TABLE tenant_product (
  tenant      UUID NOT NULL REFERENCES tenant(id) ON DELETE CASCADE,
  product_id  UUID NOT NULL REFERENCES product(id),
  enabled     BOOLEAN NOT NULL DEFAULT true,
  PRIMARY KEY (tenant, product_id)
);

-- ===== Identity =====
CREATE TABLE app_user (
  id                  UUID PRIMARY KEY,
  account_id          UUID   NOT NULL REFERENCES account(id),
  email               CITEXT NOT NULL,
  display_name        TEXT,
  status              TEXT   NOT NULL CHECK (status IN ('INVITED','ACTIVE','DISABLED','DEPROVISIONED')),
  primary_tenant_id   UUID   NOT NULL REFERENCES tenant(id),
  password_hash       TEXT,                           -- Argon2id, NULL until invitation accepted
  password_changed_at TIMESTAMPTZ,
  failed_logins       INT    NOT NULL DEFAULT 0,
  locked_until        TIMESTAMPTZ,
  session_version     INT    NOT NULL DEFAULT 1,
  last_login_at       TIMESTAMPTZ,
  version             BIGINT NOT NULL,
  created_at          TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at          TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (account_id, email)
);
CREATE INDEX app_user_email_idx ON app_user(email);

CREATE TABLE user_tenant_membership (                 -- owned by AppUser aggregate
  app_user    UUID NOT NULL REFERENCES app_user(id) ON DELETE CASCADE,
  tenant_id   UUID NOT NULL REFERENCES tenant(id),
  status      TEXT NOT NULL DEFAULT 'ACTIVE' CHECK (status IN ('ACTIVE','SUSPENDED')),
  added_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
  PRIMARY KEY (app_user, tenant_id)
);
CREATE INDEX utm_tenant_idx ON user_tenant_membership(tenant_id);

CREATE TABLE password_history (
  user_id       UUID NOT NULL REFERENCES app_user(id),
  password_hash TEXT NOT NULL,
  changed_at    TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX password_history_user_idx ON password_history(user_id, changed_at DESC);

CREATE TABLE user_token (                             -- invitation & password reset
  id          UUID PRIMARY KEY,
  user_id     UUID  NOT NULL REFERENCES app_user(id),
  purpose     TEXT  NOT NULL CHECK (purpose IN ('INVITE','PASSWORD_RESET')),
  token_hash  BYTEA NOT NULL UNIQUE,                  -- SHA-256 of a 256-bit random token
  expires_at  TIMESTAMPTZ NOT NULL,
  used_at     TIMESTAMPTZ,
  created_by  UUID REFERENCES app_user(id),
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE user_session (
  id                UUID PRIMARY KEY,
  user_id           UUID  NOT NULL REFERENCES app_user(id),
  active_tenant_id  UUID  NOT NULL REFERENCES tenant(id),
  refresh_hash      BYTEA NOT NULL UNIQUE,
  prev_refresh_hash BYTEA,                            -- refresh-token reuse detection
  ip                INET,
  user_agent        TEXT,
  created_at        TIMESTAMPTZ NOT NULL DEFAULT now(),
  last_seen_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
  expires_at        TIMESTAMPTZ NOT NULL,             -- absolute lifetime
  revoked_at        TIMESTAMPTZ,
  version           BIGINT NOT NULL
);
CREATE INDEX user_session_user_idx ON user_session(user_id) WHERE revoked_at IS NULL;
CREATE INDEX user_session_prev_idx ON user_session(prev_refresh_hash) WHERE prev_refresh_hash IS NOT NULL;

-- ===== Authorization =====
CREATE TABLE permission (
  id           UUID PRIMARY KEY,
  product_id   UUID NOT NULL REFERENCES product(id),
  code         TEXT UNIQUE NOT NULL,                  -- billing.invoice.approve, billing.invoice.read.tenant
  kind         TEXT NOT NULL CHECK (kind IN ('FEATURE','DATA')),
  description  TEXT NOT NULL,
  sensitive    BOOLEAN NOT NULL DEFAULT false,        -- Phase 2 approval workflow
  audit_read   BOOLEAN NOT NULL DEFAULT false,        -- reads must be audited
  deprecated   BOOLEAN NOT NULL DEFAULT false,
  version      BIGINT NOT NULL
);
CREATE INDEX permission_product_idx ON permission(product_id);

CREATE TABLE role (
  id           UUID PRIMARY KEY,
  product_id   UUID NOT NULL REFERENCES product(id),
  name         TEXT NOT NULL,
  description  TEXT,
  type         TEXT NOT NULL CHECK (type IN ('SYSTEM','CUSTOM')),
  account_id   UUID REFERENCES account(id),
  version      BIGINT NOT NULL,
  created_at   TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at   TIMESTAMPTZ NOT NULL DEFAULT now(),
  CHECK ((type = 'SYSTEM' AND account_id IS NULL) OR (type = 'CUSTOM' AND account_id IS NOT NULL))
);
CREATE UNIQUE INDEX role_name_uq ON role
  (product_id, COALESCE(account_id, '00000000-0000-0000-0000-000000000000'::uuid), lower(name));
CREATE INDEX role_account_idx ON role(account_id) WHERE account_id IS NOT NULL;

CREATE TABLE role_permission (                        -- owned by Role aggregate
  role          UUID NOT NULL REFERENCES role(id) ON DELETE CASCADE,
  permission_id UUID NOT NULL REFERENCES permission(id),
  PRIMARY KEY (role, permission_id)
);

CREATE TABLE role_assignment (
  id          UUID PRIMARY KEY,
  user_id     UUID NOT NULL REFERENCES app_user(id),
  role_id     UUID NOT NULL REFERENCES role(id),
  scope_type  TEXT NOT NULL CHECK (scope_type IN ('ACCOUNT','TENANT')),
  scope_id    UUID NOT NULL,
  granted_by  UUID REFERENCES app_user(id),
  granted_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
  expires_at  TIMESTAMPTZ,
  version     BIGINT NOT NULL,
  UNIQUE (user_id, role_id, scope_type, scope_id)
);
CREATE INDEX ra_user_idx  ON role_assignment(user_id);
CREATE INDEX ra_scope_idx ON role_assignment(scope_type, scope_id);
CREATE INDEX ra_role_idx  ON role_assignment(role_id);
CREATE INDEX ra_expiry_idx ON role_assignment(expires_at) WHERE expires_at IS NOT NULL;

-- ===== Revocation feed =====
CREATE TABLE revocation (
  id          BIGSERIAL PRIMARY KEY,                  -- cursor for pollers
  user_id     UUID NOT NULL,
  min_sv      INT  NOT NULL,                          -- tokens with sv < min_sv are rejected
  reason      TEXT NOT NULL,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX revocation_created_idx ON revocation(created_at);   -- purge rows older than max token lifetime

-- ===== JWT signing keys =====
CREATE TABLE signing_key (
  kid           TEXT PRIMARY KEY,
  public_jwk    JSONB NOT NULL,
  private_enc   BYTEA NOT NULL,                       -- AES-GCM with master key from env/secrets manager
  status        TEXT  NOT NULL CHECK (status IN ('ACTIVE','PUBLISHED','RETIRED')),
  created_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
  retired_at    TIMESTAMPTZ
);

-- ===== Infra tables =====
CREATE TABLE shedlock (
  name VARCHAR(64) PRIMARY KEY, lock_until TIMESTAMP NOT NULL,
  locked_at TIMESTAMP NOT NULL, locked_by VARCHAR(255) NOT NULL
);
CREATE TABLE bucket (                                  -- Bucket4j PostgreSQL proxy manager
  id VARCHAR(255) PRIMARY KEY, state BYTEA, expires_at BIGINT
);
```

> `version` columns serve two purposes. Spring Data JDBC uses them for optimistic locking, and a `null` version tells it the entity is new, which matters because IDs are assigned by the app (UUIDv7).
> Owned child tables (`account_product`, `tenant_product`, `user_tenant_membership`, `role_permission`) name their back-reference column after the parent table, which is the Spring Data JDBC default.

### `V2__audit.sql`

```sql
CREATE TABLE audit_event (
  event_id       UUID NOT NULL,
  occurred_at    TIMESTAMPTZ NOT NULL,
  received_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
  account_id     UUID,
  tenant_id      UUID,
  source         TEXT NOT NULL,                       -- 'IAM' or calling application code
  actor_user_id  UUID,
  actor_type     TEXT NOT NULL CHECK (actor_type IN ('USER','SYSTEM','ANONYMOUS')),
  actor_ip       INET,
  user_agent     TEXT,
  session_id     UUID,
  request_id     TEXT,
  action         TEXT NOT NULL,                       -- noun.verb, e.g. iam.role_assignment.insert, auth.login.failed
  target_type    TEXT,
  target_id      TEXT,
  outcome        TEXT NOT NULL CHECK (outcome IN ('SUCCESS','DENIED','FAILURE')),
  before_state   JSONB,
  after_state    JSONB,
  metadata       JSONB,
  PRIMARY KEY (occurred_at, event_id)
) PARTITION BY RANGE (occurred_at);

CREATE INDEX ae_tenant_time_idx  ON audit_event (tenant_id, occurred_at DESC);
CREATE INDEX ae_account_time_idx ON audit_event (account_id, occurred_at DESC);
CREATE INDEX ae_actor_idx        ON audit_event (actor_user_id, occurred_at DESC);
CREATE INDEX ae_target_idx       ON audit_event (target_type, target_id, occurred_at DESC);
CREATE INDEX ae_action_idx       ON audit_event (action, occurred_at DESC);

-- append-only
CREATE FUNCTION audit_immutable() RETURNS trigger LANGUAGE plpgsql AS
$$ BEGIN RAISE EXCEPTION 'audit_event is append-only'; END $$;
CREATE TRIGGER audit_event_immutable BEFORE UPDATE OR DELETE ON audit_event
  FOR EACH ROW EXECUTE FUNCTION audit_immutable();
-- app DB role gets INSERT, SELECT only on audit_event

-- Row-change capture for every IAM table. Actor/request come from transaction-local settings.
CREATE FUNCTION iam_audit() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE b JSONB; a JSONB; r JSONB;
BEGIN
  IF TG_OP <> 'INSERT' THEN b := to_jsonb(OLD) - 'password_hash' - 'refresh_hash' - 'prev_refresh_hash' - 'token_hash' - 'private_enc'; END IF;
  IF TG_OP <> 'DELETE' THEN a := to_jsonb(NEW) - 'password_hash' - 'refresh_hash' - 'prev_refresh_hash' - 'token_hash' - 'private_enc'; END IF;
  r := COALESCE(a, b);
  INSERT INTO audit_event (event_id, occurred_at, account_id, tenant_id, source, actor_user_id, actor_type,
                           request_id, session_id, action, target_type, target_id, outcome, before_state, after_state)
  VALUES (gen_random_uuid(), clock_timestamp(),
          NULLIF(current_setting('app.account_id', true), '')::uuid,
          NULLIF(current_setting('app.tenant_id',  true), '')::uuid,
          'IAM',
          NULLIF(current_setting('app.user_id', true), '')::uuid,
          CASE WHEN COALESCE(current_setting('app.user_id', true), '') = '' THEN 'SYSTEM' ELSE 'USER' END,
          NULLIF(current_setting('app.request_id', true), ''),
          NULLIF(current_setting('app.session_id', true), '')::uuid,
          'iam.' || TG_TABLE_NAME || '.' || lower(TG_OP),
          TG_TABLE_NAME,
          COALESCE(r->>'id', r->>'kid', concat_ws(':', r->>'app_user', r->>'role', r->>'tenant', r->>'account', r->>'tenant_id', r->>'permission_id', r->>'product_id')),
          'SUCCESS', b, a);
  RETURN NULL;
END $$;

DO $$ DECLARE t TEXT; BEGIN
  FOREACH t IN ARRAY ARRAY['account','account_product','tenant','tenant_product','product','permission',
                           'user_tenant_membership','role','role_permission','role_assignment','signing_key'] LOOP
    EXECUTE format('CREATE TRIGGER %1$s_audit AFTER INSERT OR UPDATE OR DELETE ON %1$s
                    FOR EACH ROW EXECUTE FUNCTION iam_audit()', t);
  END LOOP;
END $$;

-- app_user: skip updates that only touch login bookkeeping (last_login_at, failed_logins); those are auth.* events
CREATE TRIGGER app_user_audit_ins_del AFTER INSERT OR DELETE ON app_user
  FOR EACH ROW EXECUTE FUNCTION iam_audit();
CREATE TRIGGER app_user_audit_upd AFTER UPDATE ON app_user
  FOR EACH ROW
  WHEN ((to_jsonb(OLD) - 'last_login_at' - 'failed_logins' - 'locked_until' - 'updated_at' - 'version')
        IS DISTINCT FROM
        (to_jsonb(NEW) - 'last_login_at' - 'failed_logins' - 'locked_until' - 'updated_at' - 'version'))
  EXECUTE FUNCTION iam_audit();

-- No triggers on user_session, user_token, password_history, revocation:
-- AuthAuditService writes explicit auth.* events for those (cleaner, no secrets, no noise).
```

### `V3__seed.sql`

```sql
INSERT INTO product (id, code, name, version) VALUES ('00000000-0000-7000-8000-000000000001', 'IAM', 'Identity & Access', 0);

-- The platform operator account (your company); its admins can create customer accounts
INSERT INTO account (id, name, slug, kind, status, version) VALUES
  ('00000000-0000-7000-8000-0000000000a1', 'Platform', 'platform', 'PLATFORM', 'ACTIVE', 0);
-- tenant + first operator user created by a bootstrap CLI command (task P1-6.4), not by SQL
```

IAM's own permissions and system roles are loaded from `iam-manifest.yaml` through the same registry code that every product uses:

```yaml
product: IAM
permissions:
  - { code: platform.account.manage,  kind: FEATURE, description: Create and manage customer accounts, sensitive: true }
  - { code: iam.tenant.manage,        kind: FEATURE, description: Create, update, suspend tenants }
  - { code: iam.user.manage,          kind: FEATURE, description: Invite, update, disable users }
  - { code: iam.user.share,           kind: FEATURE, description: Add users to other tenants }
  - { code: iam.user.read.tenant,     kind: DATA,    description: List users of the active tenant }
  - { code: iam.user.read.account,    kind: DATA,    description: List users across the account }
  - { code: iam.role.manage,          kind: FEATURE, description: Create and edit custom roles, sensitive: true }
  - { code: iam.role.assign,          kind: FEATURE, description: Assign and revoke roles, sensitive: true }
  - { code: iam.session.revoke,       kind: FEATURE, description: Force logout users }
  - { code: iam.audit.read,           kind: FEATURE, description: Read audit log }
  - { code: iam.audit.export,         kind: FEATURE, description: Export audit log, audit_read: true }
system_roles:
  - { name: Platform Admin, permissions: [ "platform.*", "iam.*" ] }      # only assignable inside PLATFORM account
  - { name: Account Admin,  permissions: [ "iam.*" ], exclude: [ "platform.*" ] }
  - { name: Tenant Admin,   permissions: [ iam.user.manage, iam.user.read.tenant, iam.role.assign, iam.session.revoke, iam.audit.read ] }
  - { name: Auditor,        permissions: [ iam.audit.read, iam.user.read.account ] }
```

---

## 3. Spring Data JDBC: patterns to follow

### Aggregate (record + owned collection)

```java
@Table("role")
public record Role(
    @Id UUID id,
    AggregateReference<Product, UUID> productId,
    String name,
    String description,
    RoleType type,
    @Nullable AggregateReference<Account, UUID> accountId,
    @MappedCollection(idColumn = "role") Set<RolePermission> permissions,
    @Version Long version,
    @CreatedDate Instant createdAt,
    @LastModifiedDate Instant updatedAt) {

  public Role withPermissions(Set<UUID> permissionIds) {
    return new Role(id, productId, name, description, type, accountId,
        permissionIds.stream().map(RolePermission::new).collect(toUnmodifiableSet()),
        version, createdAt, updatedAt);
  }
}

@Table("role_permission")
public record RolePermission(UUID permissionId) {}

public interface RoleRepository extends ListCrudRepository<Role, UUID> {
  @Query("SELECT * FROM role WHERE product_id = :productId AND (account_id IS NULL OR account_id = :accountId) ORDER BY type, name")
  List<Role> findVisible(UUID productId, UUID accountId);
}
```

Rules:
- **IDs** are UUIDv7 generated in Java (`com.github.f4b6a3:uuid-creator`). `version == null` means insert.
- **Owned collections** are rewritten (delete + insert) on save. That is fine for small sets (memberships, role permissions). Never put large or independently queried data inside an aggregate.
- **Cross-aggregate references** use `AggregateReference`; there is no lazy loading. Load what you need explicitly.
- **Read models and complex queries** (effective permissions, user lists with role counts, audit search) use `JdbcClient` with hand-written SQL that maps into DTO records.
- **Auditing columns:** `@EnableJdbcAuditing` + `AuditorAware<UUID>` from the `SecurityContext`.
- **Converters:** register `JSONB ↔ Map/record` and `CITEXT ↔ String` converters in `AbstractJdbcConfiguration#userConverters()`.
- **Pagination:** keyset (`WHERE (created_at, id) < (:c, :id) ORDER BY created_at DESC, id DESC LIMIT :n`). Avoid OFFSET on large tables.

### Transaction-local audit context (feeds the DB trigger)

```java
/** Sets actor/request info as transaction-local Postgres settings; reset automatically at commit/rollback. */
public class AuditContextTransactionManager extends JdbcTransactionManager {
  public AuditContextTransactionManager(DataSource ds) { super(ds); }

  @Override
  protected void prepareTransactionalConnection(Connection con, TransactionDefinition def) throws SQLException {
    super.prepareTransactionalConnection(con, def);
    RequestActor a = RequestActor.current();               // from SecurityContext + MDC; SYSTEM for jobs
    try (PreparedStatement ps = con.prepareStatement(
        "SELECT set_config('app.user_id',?,true), set_config('app.account_id',?,true), " +
        "set_config('app.tenant_id',?,true), set_config('app.request_id',?,true), set_config('app.session_id',?,true)")) {
      ps.setString(1, a.userId()); ps.setString(2, a.accountId()); ps.setString(3, a.tenantId());
      ps.setString(4, a.requestId()); ps.setString(5, a.sessionId());
      ps.execute();
    }
  }
}
```

Using `is_local = true` scopes the settings to the transaction, so nothing leaks between pooled connections. That is why no `DataSource` proxy is needed.

---

## 4. Authentication and tokens

### Login flow

```
POST /auth/login { email, password, account? }
 1. Rate limit: 10/min per IP, 5/min per email (Bucket4j/Postgres)
 2. Find ACTIVE users with that email (optionally filtered by account slug)
 3. For each candidate: reject if locked_until > now; verify Argon2id
      always run one Argon2 verify even when no user is found (timing equality)
 4. 0 matches  → 401 "Invalid email or password"; increment failed_logins; lock 15 min after 5
    >1 matches → 409 { accounts: [{slug, name}] }  (client re-submits with account)
    1 match    → continue
 5. Account ACTIVE? tenant(primary) ACTIVE? membership ACTIVE?
 6. Create user_session (refresh token = 32 random bytes, store SHA-256)
 7. perms = PermissionResolver.resolve(user, primaryTenant)
 8. Issue access JWT (15 min) + refresh token (opaque)
 9. Audit auth.login.success / auth.login.failed / auth.locked
```

### Endpoints

| Endpoint | Purpose |
|---|---|
| `POST /auth/login` | Password login (above) |
| `POST /auth/refresh` | Rotate refresh token, re-resolve permissions, new access token. Reusing an old refresh token revokes the whole session |
| `POST /auth/switch-tenant` `{tenantId}` | Requires an active membership. Updates the session's active tenant and returns new tokens |
| `POST /auth/logout` | Revoke the current session |
| `POST /auth/logout-all` | Revoke all of the user's sessions and bump `session_version` |
| `POST /auth/password/forgot` | Always 202. Emails a reset link if the user exists |
| `POST /auth/password/reset` | Token (30 min) → new password; revokes all sessions |
| `POST /auth/password/change` | Needs the current password |
| `POST /auth/invitations/accept` | Token (7 days) → set password → ACTIVE → logged in |
| `GET /.well-known/jwks.json` | Public keys (ACTIVE + PUBLISHED) |
| `GET /api/me` | Profile, memberships, active tenant, permissions |

### Access token (JWT, RS256, 15 min)

```json
{
  "iss": "https://iam.acme.com",
  "sub": "0192f3a1-...",            "acc": "0192f3a0-...",
  "tid": "0192f3a2-...",            "sid": "0192f3b0-...",
  "sv": 7,
  "perms": ["iam.user.manage","billing.invoice.read.tenant","billing.invoice.approve"],
  "iat": 1760000000, "exp": 1760000900, "jti": "..."
}
```

Refresh token: opaque, 12 h absolute lifetime, 30 min idle timeout (configurable per account through `account.settings`), rotated on every use.

### Spring Security setup (in iam-service)

```java
@Configuration @EnableMethodSecurity
class SecurityConfig {

  @Bean @Order(1)
  SecurityFilterChain authEndpoints(HttpSecurity http) throws Exception {
    return http.securityMatcher("/auth/**", "/.well-known/**")
        .csrf(c -> c.disable())
        .sessionManagement(s -> s.sessionCreationPolicy(STATELESS))
        .authorizeHttpRequests(a -> a
            .requestMatchers("/auth/logout", "/auth/logout-all", "/auth/switch-tenant", "/auth/password/change").authenticated()
            .anyRequest().permitAll())
        .oauth2ResourceServer(o -> o.jwt(j -> j.decoder(jwtDecoder).jwtAuthenticationConverter(permsConverter())))
        .build();
  }

  @Bean @Order(2)
  SecurityFilterChain api(HttpSecurity http, RevocationFilter revocation) throws Exception {
    return http.securityMatcher("/api/**", "/internal/**")
        .csrf(c -> c.disable())
        .sessionManagement(s -> s.sessionCreationPolicy(STATELESS))
        .oauth2ResourceServer(o -> o.jwt(j -> j.decoder(jwtDecoder).jwtAuthenticationConverter(permsConverter())))
        .addFilterAfter(revocation, BearerTokenAuthenticationFilter.class)
        .exceptionHandling(e -> e.accessDeniedHandler(auditingAccessDeniedHandler))
        .authorizeHttpRequests(a -> a.anyRequest().authenticated())
        .build();
  }

  @Bean PasswordEncoder passwordEncoder() { return Argon2PasswordEncoder.defaultsForSpringSecurity_v5_8(); }

  @Bean JwtEncoder jwtEncoder(SigningKeyService keys) { return new NimbusJwtEncoder(keys.jwkSource()); }
  @Bean JwtDecoder jwtDecoder(SigningKeyService keys) { return NimbusJwtDecoder.withJwkSource(keys.jwkSource()).build(); }

  static Converter<Jwt, AbstractAuthenticationToken> permsConverter() {
    return jwt -> new JwtAuthenticationToken(jwt,
        jwt.getClaimAsStringList("perms").stream().map(SimpleGrantedAuthority::new).toList(), jwt.getSubject());
  }
}
```

Usage:

```java
@PostMapping("/api/tenants/{tenantId}/users")
@PreAuthorize("hasAuthority('iam.user.manage')")
public UserDto invite(@PathVariable UUID tenantId, @Valid @RequestBody InviteRequest req) {
  tenantGuard.requireActive(tenantId);   // path tenant must equal token tid, unless caller holds an ACCOUNT-scope grant
  return userService.invite(tenantId, req);
}
```

---

## 5. Authorization engine

### Effective permissions (user U in tenant T)

```sql
SELECT DISTINCT p.code
FROM role_assignment ra
JOIN role_permission rp ON rp.role = ra.role_id
JOIN permission p       ON p.id = rp.permission_id AND NOT p.deprecated
JOIN tenant t           ON t.id = :tenantId AND t.status = 'ACTIVE'
JOIN account a          ON a.id = t.account_id AND a.status = 'ACTIVE'
JOIN product pr         ON pr.id = p.product_id
LEFT JOIN account_product ap ON ap.account = a.id AND ap.product_id = p.product_id
LEFT JOIN tenant_product tp  ON tp.tenant = t.id AND tp.product_id = p.product_id
JOIN user_tenant_membership m ON m.app_user = ra.user_id AND m.tenant_id = t.id AND m.status = 'ACTIVE'
WHERE ra.user_id = :userId
  AND (ra.expires_at IS NULL OR ra.expires_at > now())
  AND ((ra.scope_type = 'TENANT' AND ra.scope_id = t.id) OR (ra.scope_type = 'ACCOUNT' AND ra.scope_id = a.id))
  AND ( pr.code = 'IAM'                                     -- IAM is always entitled
     OR (ap.status IN ('ACTIVE','TRIAL') AND (ap.ends_at IS NULL OR ap.ends_at >= current_date) AND tp.enabled) );
```

This runs only at login, refresh and tenant switch. With the indexes above it is a handful of index lookups, so no cache is needed.

### Data scope

| Permission held | Meaning | Applied as |
|---|---|---|
| `x.read.own` | Records the user owns or created | `AND owner_id = :sub` |
| `x.read.tenant` | All records in the active tenant | `AND tenant_id = :tid` |
| `x.read.account` | All records across the account | `AND account_id = :acc` |

`DataScope.of(auth, "billing.invoice.read")` returns the broadest scope the user holds, or throws `AccessDeniedException`. Ship this in `iam-client` so every application applies it the same way.

### Write-time invariants (in services, each one unit tested)

| # | Rule |
|---|---|
| I1 | TENANT-scope assignment requires an active membership in that tenant |
| I2 | Removing a membership deletes the user's TENANT-scope assignments for that tenant (same transaction) |
| I3 | A CUSTOM role is assignable only inside its own account and may only contain permissions of its own product |
| I4 | A user must keep a membership in their primary tenant; changing primary requires a membership |
| I5 | `tenant_product` must be a subset of active `account_product` |
| I6 | A grantor can assign only roles whose permissions they themselves hold at that scope |
| I7 | The last active Account Admin of an account cannot be revoked or disabled |
| I8 | SYSTEM roles are read-only through the API; `Platform Admin` is assignable only inside the PLATFORM account |
| I9 | Users are never hard-deleted. Status becomes DEPROVISIONED, sessions are revoked and the email is kept for audit linkage |
| I10 | All queries in admin services are filtered by the caller's `acc`. A test asserts that no repository method lacks an account filter |

### Revocation

Revoke a user's access whenever it may shrink: an assignment is revoked or expires, a role's permissions are edited, a membership is removed, the user is disabled, a tenant, account or product is suspended, the password changes, or an admin forces logout.

```
UPDATE app_user SET session_version = session_version + 1 WHERE id IN (...) RETURNING id, session_version;
INSERT INTO revocation(user_id, min_sv, reason) SELECT ...;           -- same transaction
```

- **Pollers** (`iam-client` and IAM itself) call `GET /internal/revocations?since={lastId}` every 5 s and update a `ConcurrentHashMap<UUID,Integer>`. On startup they load the last 20 minutes of rows.
- **The filter** rejects a token when `jwt.sv < map.getOrDefault(sub, 0)` (`401 error="token_revoked"`). The client then refreshes, and refresh re-checks the DB and re-resolves permissions.
- **Bulk changes** (a role used by 50k users, a tenant suspension) run as one set-based `UPDATE … RETURNING` plus `INSERT … SELECT`, in batches of 5,000.
- **Purge:** a job deletes revocation rows older than 1 hour, since the longest token lifetime is 15 minutes.

---

## 6. Audit everything

| What | How | Examples |
|---|---|---|
| Every IAM data change | DB trigger, same transaction, with before/after state | `iam.role_assignment.insert`, `iam.role.update`, `iam.app_user.update` |
| Authentication | `AuthAuditService` writes directly | `auth.login.success`, `auth.login.failed`, `auth.locked`, `auth.refresh`, `auth.refresh.reuse_detected`, `auth.tenant.switched`, `auth.logout`, `auth.password.reset` |
| Authorization denials | One `AccessDeniedHandler` | `authz.denied` with required authority, path and method |
| Sensitive reads | Explicit `auditWriter.read(...)` for `audit_read` permissions | `iam.audit.exported`, `iam.user.exported` |
| Applications' own events | `iam-client` `@Audited` → local outbox table → relay POSTs batches to `/internal/audit/events` | `invoice.approved`, `document.downloaded` |

Rules:
- **Never audit** passwords, hashes, tokens or private keys. The trigger strips those columns and the ingest endpoint applies a deny-list.
- **Partitions** are monthly and created 3 months ahead by a ShedLock job. Detach partitions older than the retention period (default 7 years) and archive them with `pg_dump`.
- **Search** uses keyset pagination with a maximum 92-day window per query, and must always filter by account.
- **Ingest** from applications is idempotent on `event_id`. Each application's outbox relay uses `SELECT … FOR UPDATE SKIP LOCKED LIMIT 500`.

---

## 7. iam-client starter (for consuming applications)

| Component | What it does |
|---|---|
| `IamResourceServerAutoConfiguration` | JWT validation against IAM JWKS (cached, refreshed on unknown `kid`), `perms` → authorities, stateless |
| `RevocationPoller` + `RevocationFilter` | 5 s polling, in-memory map, 401 on revoked tokens |
| `TenantContext` | Holder for `tid`, `acc`, `sub`, `sid`, request id; propagated to `@Async` via `TaskDecorator` |
| `DataScope` | Turns `.own`, `.tenant` and `.account` permissions into a scope |
| `@Audited` + `AuditOutbox` + `AuditRelay` | Writes an outbox row in the caller's transaction; a ShedLock-guarded relay ships batches to IAM |
| `iam.manifest` upload | On startup, `PUT /internal/products/{code}/manifest` with the application's `permissions.yaml` |

Service-to-service calls to `/internal/*` use a client-credentials style token signed by IAM for a registered "application client". Phase 1 keeps this simple: a static per-application secret, hashed in an `app_client` table (task P1-12.1).

---

## 8. Task breakdown

Legend: **d** = engineer-days

### P1-1 · Project setup (week 1)

| ID | Task | Est | Depends | Done when |
|---|---|---|---|---|
| P1-1.1 | Create `iam-service` Gradle/Maven project: Spring Boot 3, Java 21, `spring-boot-starter-data-jdbc`, `-security`, `-oauth2-resource-server`, `-validation`, Flyway, ShedLock, Bucket4j, uuid-creator, ArchUnit | 1d | – | App boots against Postgres |
| P1-1.2 | Testcontainers Postgres base class; `@DataJdbcTest` and full `@SpringBootTest` profiles | 0.5d | 1.1 | Sample test green in CI |
| P1-1.3 | CI pipeline (build, test, coverage, container image), Docker Compose for local Postgres | 1d | 1.1 | Image pushed on merge |
| P1-1.4 | Common web layer: RFC 7807 errors, validation messages, request-id filter + MDC, JSON logging | 1d | 1.1 | Every response has `X-Request-Id` |
| P1-1.5 | `JdbcConfig`: converters (JSONB, CITEXT, enums), `@EnableJdbcAuditing`, `AuditorAware`, UUIDv7 id generator, `AuditContextTransactionManager` | 1.5d | 1.1 | Integration test shows `app.user_id` visible inside tx and cleared after |
| P1-1.6 | ArchUnit rules: no cross-package repository access; controllers only call services | 0.5d | 1.1 | Build fails on violation |

### P1-2 · Schema (week 1)

| ID | Task | Est | Depends | Done when |
|---|---|---|---|---|
| P1-2.1 | `V1__core.sql` | 1d | 1.1 | Migrates on empty DB |
| P1-2.2 | `V2__audit.sql` incl. trigger function, noise filter on `app_user`, initial 4 partitions | 1d | 2.1 | Insert/update/delete on each table yields exactly one audit row; no-op updates yield none |
| P1-2.3 | DB roles: `iam_app` (DML; INSERT/SELECT only on `audit_event`), `iam_migrator` (DDL) | 0.5d | 2.2 | UPDATE on audit_event fails as `iam_app` |
| P1-2.4 | `V3__seed.sql` (IAM product, PLATFORM account) | 0.5d | 2.1 | – |

### P1-3 · Aggregates & repositories (week 1–2)

| ID | Task | Est | Depends | Done when |
|---|---|---|---|---|
| P1-3.1 | `Account` (+`AccountProduct`), `Tenant` (+`TenantProduct`), `Product`, `Permission` records + repositories | 1.5d | 2.1, 1.5 | Round-trip tests |
| P1-3.2 | `AppUser` (+`Membership`), `UserToken`, `PasswordHistory`, `UserSession` | 1.5d | 2.1 | Round-trip tests; optimistic lock conflict test |
| P1-3.3 | `Role` (+`RolePermission`), `RoleAssignment` | 1d | 2.1 | – |
| P1-3.4 | Read-model queries with `JdbcClient`: user list (filter by tenant/status/role, keyset), role list with assignment counts | 1.5d | 3.1–3.3 | p95 < 50 ms on 1M users |

### P1-4 · Security foundation (week 2)

| ID | Task | Est | Depends | Done when |
|---|---|---|---|---|
| P1-4.1 | `SigningKeyService`: generate RSA-2048 key, encrypt with master key (AES-GCM), JWKSource over ACTIVE+PUBLISHED keys, in-memory cache refreshed every 60 s | 1.5d | 3.1 | JWKS endpoint serves keys |
| P1-4.2 | Key rotation command/job: new key → PUBLISHED (24 h) → ACTIVE; old → PUBLISHED until max token age → RETIRED | 1d | 4.1 | Tokens from old key still valid during overlap |
| P1-4.3 | `JwtIssuer` (claims in section 4), `SecurityConfig` filter chains, `permsConverter`, method security | 1d | 4.1 | `@PreAuthorize` test passes |
| P1-4.4 | `TenantGuard`: path tenant vs token tenant; account-scope override | 0.5d | 4.3 | Unit tests |
| P1-4.5 | Auditing `AccessDeniedHandler` + `AuthenticationEntryPoint` | 0.5d | 4.3, 9.1 | Denials produce `authz.denied` |

### P1-5 · Authentication (week 2–4)

| ID | Task | Est | Depends | Done when |
|---|---|---|---|---|
| P1-5.1 | `PasswordService`: Argon2id, policy from `account.settings` (min 12, max 128, history 5, optional breached-password k-anonymity check off by default) | 1d | 3.2 | Unit tests |
| P1-5.2 | `LoginService` (flow in section 4) incl. multi-account choice, constant-time behaviour, lockout | 2d | 5.1, 4.3, 6.x | Timing test: unknown vs known email within 10% |
| P1-5.3 | `SessionService`: create, refresh rotation, reuse detection, idle/absolute timeout, revoke | 2d | 3.2 | Reused refresh token revokes session + audit event |
| P1-5.4 | Tenant switch | 0.5d | 5.3, 8.3 | – |
| P1-5.5 | Logout, logout-all | 0.5d | 5.3, 10.1 | Next request 401 |
| P1-5.6 | Forgot/reset/change password (tokens hashed, single use, revoke sessions) | 1.5d | 5.1 | E2E test |
| P1-5.7 | Login rate limiting with Bucket4j PostgreSQL backend (per IP, per email) | 1d | 5.2 | 429 with `Retry-After` |
| P1-5.8 | `AuthAuditService` for all `auth.*` events | 0.5d | 9.1 | Every endpoint in section 4 emits an event |
| P1-5.9 | `GET /api/me` | 0.5d | 7.3 | – |

### P1-6 · Accounts, tenants, products (week 2–3)

| ID | Task | Est | Depends | Done when |
|---|---|---|---|---|
| P1-6.1 | Platform API (`platform.account.manage`): create/update/suspend/close account; set `account_product` | 1.5d | 3.1 | Suspend revokes all users of the account |
| P1-6.2 | Account bootstrap: creating an account creates its default tenant and invites the first Account Admin | 1d | 6.1, 8.2 | One call yields a working account |
| P1-6.3 | Tenant API (`iam.tenant.manage`): list/create/update/suspend/archive, enable/disable products (I5) | 1.5d | 3.1 | Suspend tenant revokes members' tokens |
| P1-6.4 | Bootstrap CLI (`--bootstrap-platform-admin email=...`): PLATFORM tenant + first Platform Admin invitation; refuses to run twice | 0.5d | 6.1, 8.2 | Fresh install usable |

### P1-7 · Product & permission registry (week 3)

| ID | Task | Est | Depends | Done when |
|---|---|---|---|---|
| P1-7.1 | Manifest format (YAML/JSON): product, permissions, system roles with wildcard + exclude | 0.5d | – | Documented |
| P1-7.2 | `RegistryService.apply(manifest)`: idempotent upsert; removed permission → `deprecated`; system roles rebuilt; changed system roles trigger revocation of holders | 2d | 3.1, 3.3, 10.1 | Applying the same manifest twice = 0 changes |
| P1-7.3 | Load `iam-manifest.yaml` at startup; `PUT /internal/products/{code}/manifest` for applications; `GET /api/products/{code}/permissions` | 1d | 7.2 | – |
| P1-7.4 | `PermissionResolver` (query in section 5) with index review (`EXPLAIN ANALYZE`) | 1d | 3.3 | p95 < 15 ms at 1M users / 5M assignments |

### P1-8 · Users & memberships (week 3–4)

| ID | Task | Est | Depends | Done when |
|---|---|---|---|---|
| P1-8.1 | User API: list (tenant or account scope via data permission), get, update profile, disable, enable, deprovision (I9) | 2d | 3.4 | Disable revokes tokens |
| P1-8.2 | Invitations: create INVITED user + membership + optional roles in one transaction; token email via `NotificationPort` (SMTP adapter); resend; expire | 1.5d | 3.2 | E2E invite → accept → login |
| P1-8.3 | Membership API: share into tenant, remove (I2, I4), change primary tenant | 1.5d | 8.1 | Invariant tests |
| P1-8.4 | Bulk invite (CSV ≤ 5,000 rows): validate all first, insert in batches with `JdbcClient` batch update, async job with status endpoint | 2d | 8.2 | 5,000 rows < 30 s |

### P1-9 · Audit (week 3–5)

| ID | Task | Est | Depends | Done when |
|---|---|---|---|---|
| P1-9.1 | `AuditWriter` (direct insert for auth/denial/read events), event record, redaction deny-list | 1d | 2.2 | – |
| P1-9.2 | Partition job (ShedLock, daily): ensure 3 future months exist; alert if missing | 0.5d | 2.2 | – |
| P1-9.3 | Retention job: detach and drop partitions past retention after archive hook succeeds | 0.5d | 9.2 | Runbook tested |
| P1-9.4 | `POST /internal/audit/events` batch ingest (≤ 500/batch), idempotent on `event_id`, source = calling app | 1d | 12.1 | 5k events/s single instance |
| P1-9.5 | `GET /api/audit/events`: filters (tenant, actor, action prefix, target, outcome, from/to), keyset pagination | 1.5d | 9.1 | p95 < 500 ms on 100M rows |
| P1-9.6 | `GET /api/audit/targets/{type}/{id}` (history of one record) | 0.5d | 9.5 | – |
| P1-9.7 | Async CSV export (streamed with `JdbcClient` + `fetchSize`), audited | 1d | 9.5 | 1M rows without OOM |

### P1-10 · Roles, assignments & revocation (week 4–5)

| ID | Task | Est | Depends | Done when |
|---|---|---|---|---|
| P1-10.1 | `RevocationService`: set-based bump + revocation insert; `GET /internal/revocations?since=`; purge job | 1.5d | 3.2 | Revoked token rejected ≤ 5 s on all instances |
| P1-10.2 | `RevocationPoller` + `RevocationFilter` inside iam-service (same code as iam-client) | 0.5d | 10.1 | – |
| P1-10.3 | Role API (`iam.role.manage`): list visible, create/update/delete custom, set permissions (I3, I8); delete blocked while assigned (409 with count) | 2d | 3.3, 7.2 | Editing a role revokes all holders |
| P1-10.4 | Assignment API (`iam.role.assign`): assign/revoke at ACCOUNT or TENANT scope, optional expiry, list by user / by role / by tenant (I1, I6, I7) | 2d | 10.3, 8.3 | Invariant tests |
| P1-10.5 | Assignment expiry job (every 5 min): delete expired rows, revoke holders | 0.5d | 10.4 | – |
| P1-10.6 | Explain endpoint: `GET /api/users/{id}/effective-permissions?tenantId=` → permission → role → scope | 1d | 7.4 | – |

### P1-11 · Hardening (week 6–7)

| ID | Task | Est | Depends | Done when |
|---|---|---|---|---|
| P1-11.1 | Authorization matrix test generated from the controller mappings: every endpoint × (no perm / perm / other account / other tenant) | 2d | all APIs | 100% endpoints covered; unannotated endpoint fails build |
| P1-11.2 | Load test (Gatling): 1M users, 5M assignments, 20M audit rows; login 50 rps, refresh 300 rps, admin APIs 100 rps on 2 instances | 2d | all | Targets in overview met |
| P1-11.3 | Security review: JWT alg pinning, `kid` handling, token in logs, password reset enumeration, CORS, headers, SQL injection in dynamic filters | 1.5d | all | Findings fixed |
| P1-11.4 | Failure tests: IAM restart (pollers recover), Postgres failover (Hikari recovers), clock skew ±60 s | 1d | 10.1 | Behaviour documented |
| P1-11.5 | Observability: Micrometer metrics (logins, failures, lockouts, resolver latency, revocation lag, audit lag), health groups | 1d | all | Dashboard exists |
| P1-11.6 | OpenAPI spec (springdoc) and runbooks: key rotation, force logout of user/account, unlock user, audit partition missing | 1d | all | Published |

### P1-12 · iam-client starter (week 5–7)

| ID | Task | Est | Depends | Done when |
|---|---|---|---|---|
| P1-12.1 | `app_client` table + registration API (platform), client secret → short-lived internal JWT for `/internal/*` | 1d | 4.3 | – |
| P1-12.2 | Starter auto-config: resource server with IAM JWKS, perms converter, `RevocationPoller`/`Filter` | 1.5d | 10.1 | Sample app authorizes from JWT |
| P1-12.3 | `TenantContext` + `TaskDecorator`; `DataScope` helper | 1d | 12.2 | – |
| P1-12.4 | `@Audited` aspect, `audit_outbox` Flyway script shipped in the starter, relay with ShedLock + SKIP LOCKED | 2d | 9.4 | Kill IAM 10 min → no event loss |
| P1-12.5 | Manifest upload at startup (`iam.client.manifest-location`) | 0.5d | 7.3 | – |
| P1-12.6 | Sample application + integration guide (README) | 1d | 12.2–12.5 | New app integrated in < 1 day by following the guide |

---

## 9. Timeline (3 backend engineers)

| Week | Work |
|---|---|
| 1 | P1-1, P1-2, start P1-3 |
| 2 | P1-3, P1-4, P1-6.1 |
| 3 | P1-5 (login, sessions), P1-6, P1-7 |
| 4 | P1-5 finish, P1-8, start P1-10 |
| 5 | P1-9, P1-10, start P1-12 |
| 6 | P1-12, P1-11.1 |
| 7 | P1-11 (load, security, failure tests) |
| 8 | Buffer, fixes, docs, release 1.0 |

Critical path: 2.1 → 3.x → 4.1 → 4.3 → 5.2/5.3 → 7.4 → 10.1 → 10.4 → 11.1 → 11.2.

## 10. Phase 1 exit criteria

- [ ] A fresh install can bootstrap a platform admin, who can create an account. The account admin can then create tenants, invite users, share them across tenants, create custom roles and assign multiple roles at account or tenant scope.
- [ ] Users log in with email and password and receive a JWT whose `perms` match the explain endpoint exactly.
- [ ] Disabling a user or revoking a role is enforced on every instance within 5 s.
- [ ] Every IAM row change, auth event, denial and sensitive read is in `audit_event`. `audit_event` cannot be updated or deleted by the app role.
- [ ] Authorization matrix test is green; no endpoint works without an explicit permission.
- [ ] Load test meets the targets in `00-overview.md` with Postgres as the only dependency.
- [ ] A sample application integrated through `iam-client` authorizes, audits and reacts to revocations.
