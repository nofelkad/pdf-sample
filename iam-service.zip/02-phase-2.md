# Phase 2: Enterprise features

**Goal:** pass an enterprise security review: customer SSO, automated provisioning and deprovisioning, MFA, machine access, approval of sensitive access, controlled operator access, tamper-evident audit with SIEM export, and data-subject requests.
**Duration:** ~7 weeks · **Prerequisite:** Phase 1 exit criteria met · **Infrastructure:** still PostgreSQL only.

---

## 1. Scope

| Track | Delivers |
|---|---|
| A. SSO | OIDC + SAML 2.0 per account, email-domain discovery with DNS verification, JIT provisioning, enforce SSO |
| B. MFA | TOTP + recovery codes for password users, per-account "require MFA" |
| C. Provisioning | SCIM 2.0 (Users, Groups), IdP group → role mapping |
| D. Machine access | Service accounts, API keys exchanged for JWT |
| E. Governance | Per-account session policy, two-person approval for sensitive roles, time-boxed operator access to a tenant, access review report |
| F. Audit v2 | Per-account hash chain, chain verification, SIEM webhook export, PII pseudonymisation |
| G. Data rights | Account/tenant/user export, user erasure |

---

## 2. Design choices

- **SSO lives inside iam-service** using Spring Security's `oauth2-client` (OIDC) and `saml2-service-provider`. Both read their registrations from repositories, which we back with the `identity_provider` table. There is no external identity server.
- **Same token after SSO.** SSO changes only *how* the user proves who they are. Once the IdP callback succeeds, the Phase 1 `SessionService` and `JwtIssuer` issue exactly the same JWT, so consuming applications change nothing.
- **Still Postgres only.** The hash chain is computed at insert time with a per-account row lock. Anchors are stored in a separate `audit_anchor` table that is publishable to customers. SIEM export is a ShedLock job with a cursor.
- **Scale check:** the chain lock is per account, so contention is per customer and not global. If a single account ever sustains more than ~1k events/s, move chaining to a batch step (task F.7).

---

## 3. Schema (`V10__enterprise.sql`)

```sql
-- ===== SSO =====
CREATE TABLE identity_provider (
  id                UUID PRIMARY KEY,
  account_id        UUID NOT NULL REFERENCES account(id),
  type              TEXT NOT NULL CHECK (type IN ('OIDC','SAML')),
  name              TEXT NOT NULL,
  registration_id   TEXT NOT NULL UNIQUE,              -- in URLs: /sso/{registration_id}/...
  config            JSONB NOT NULL,                    -- issuer, metadata_url, client_id, attribute mapping
  secret_enc        BYTEA,                             -- OIDC client secret, AES-GCM with master key
  enforce           BOOLEAN NOT NULL DEFAULT false,    -- disables password login for the account (except break-glass admins)
  jit_provision     BOOLEAN NOT NULL DEFAULT true,
  default_tenant_id UUID REFERENCES tenant(id),
  default_role_id   UUID REFERENCES role(id),
  status            TEXT NOT NULL DEFAULT 'ACTIVE' CHECK (status IN ('ACTIVE','DISABLED')),
  version           BIGINT NOT NULL,
  created_at        TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at        TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE identity_provider_domain (
  domain               CITEXT PRIMARY KEY,
  identity_provider_id UUID NOT NULL REFERENCES identity_provider(id) ON DELETE CASCADE,
  verify_token         TEXT NOT NULL,                  -- expected DNS TXT value
  verified_at          TIMESTAMPTZ
);

CREATE TABLE user_identity (
  user_id              UUID NOT NULL REFERENCES app_user(id),
  identity_provider_id UUID NOT NULL REFERENCES identity_provider(id),
  subject              TEXT NOT NULL,                  -- OIDC sub / SAML NameID
  last_login_at        TIMESTAMPTZ,
  PRIMARY KEY (identity_provider_id, subject),
  UNIQUE (user_id, identity_provider_id)
);

CREATE TABLE idp_group_role_mapping (
  identity_provider_id UUID NOT NULL REFERENCES identity_provider(id) ON DELETE CASCADE,
  group_name           TEXT NOT NULL,
  role_id              UUID NOT NULL REFERENCES role(id),
  scope_type           TEXT NOT NULL CHECK (scope_type IN ('ACCOUNT','TENANT')),
  scope_id             UUID NOT NULL,
  PRIMARY KEY (identity_provider_id, group_name, role_id, scope_type, scope_id)
);

ALTER TABLE role_assignment ADD COLUMN source TEXT NOT NULL DEFAULT 'MANUAL'
  CHECK (source IN ('MANUAL','IDP_GROUP','SCIM','APPROVAL','OPERATOR'));
ALTER TABLE app_user ADD COLUMN break_glass BOOLEAN NOT NULL DEFAULT false;   -- may use password even when SSO enforced

-- ===== MFA =====
ALTER TABLE app_user ADD COLUMN mfa_secret_enc  BYTEA;
ALTER TABLE app_user ADD COLUMN mfa_enrolled_at TIMESTAMPTZ;
CREATE TABLE user_recovery_code (
  user_id    UUID  NOT NULL REFERENCES app_user(id),
  code_hash  BYTEA NOT NULL,
  used_at    TIMESTAMPTZ,
  PRIMARY KEY (user_id, code_hash)
);
CREATE TABLE login_challenge (                        -- password OK, waiting for TOTP
  id          UUID PRIMARY KEY,
  user_id     UUID NOT NULL REFERENCES app_user(id),
  attempts    INT  NOT NULL DEFAULT 0,
  expires_at  TIMESTAMPTZ NOT NULL
);

-- ===== SCIM =====
CREATE TABLE scim_token (
  id                   UUID PRIMARY KEY,
  identity_provider_id UUID  NOT NULL REFERENCES identity_provider(id),
  token_hash           BYTEA NOT NULL UNIQUE,
  created_at           TIMESTAMPTZ NOT NULL DEFAULT now(),
  revoked_at           TIMESTAMPTZ
);
ALTER TABLE app_user ADD COLUMN external_id TEXT;
CREATE UNIQUE INDEX app_user_external_uq ON app_user(account_id, external_id) WHERE external_id IS NOT NULL;
CREATE TABLE scim_group (
  id                   UUID PRIMARY KEY,
  identity_provider_id UUID NOT NULL REFERENCES identity_provider(id),
  external_id          TEXT,
  display_name         TEXT NOT NULL,
  version              BIGINT NOT NULL,
  UNIQUE (identity_provider_id, display_name)
);
CREATE TABLE scim_group_member (                      -- owned by scim_group aggregate
  scim_group  UUID NOT NULL REFERENCES scim_group(id) ON DELETE CASCADE,
  user_id     UUID NOT NULL REFERENCES app_user(id),
  PRIMARY KEY (scim_group, user_id)
);

-- ===== Machine access =====
ALTER TABLE app_user ADD COLUMN type TEXT NOT NULL DEFAULT 'HUMAN' CHECK (type IN ('HUMAN','SERVICE'));
CREATE TABLE api_key (
  id           UUID PRIMARY KEY,
  user_id      UUID  NOT NULL REFERENCES app_user(id),
  name         TEXT  NOT NULL,
  key_prefix   TEXT  NOT NULL,                       -- first 8 chars, shown in UI
  key_hash     BYTEA NOT NULL,                       -- SHA-256 of the full key
  expires_at   TIMESTAMPTZ NOT NULL,
  last_used_at TIMESTAMPTZ,
  revoked_at   TIMESTAMPTZ,
  created_by   UUID REFERENCES app_user(id),
  created_at   TIMESTAMPTZ NOT NULL DEFAULT now(),
  version      BIGINT NOT NULL
);
CREATE INDEX api_key_prefix_idx ON api_key(key_prefix) WHERE revoked_at IS NULL;

-- ===== Governance =====
CREATE TABLE role_assignment_request (
  id            UUID PRIMARY KEY,
  user_id       UUID NOT NULL REFERENCES app_user(id),
  role_id       UUID NOT NULL REFERENCES role(id),
  scope_type    TEXT NOT NULL,
  scope_id      UUID NOT NULL,
  grant_expires_at TIMESTAMPTZ,
  justification TEXT NOT NULL,
  requested_by  UUID NOT NULL REFERENCES app_user(id),
  status        TEXT NOT NULL CHECK (status IN ('PENDING','APPROVED','REJECTED','EXPIRED','CANCELLED')),
  decided_by    UUID REFERENCES app_user(id),
  decided_at    TIMESTAMPTZ,
  created_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
  version       BIGINT NOT NULL,
  CHECK (decided_by IS NULL OR decided_by <> requested_by)
);
CREATE INDEX rar_pending_idx ON role_assignment_request(scope_id) WHERE status = 'PENDING';

CREATE TABLE operator_access_grant (                 -- platform operator into a customer tenant
  id              UUID PRIMARY KEY,
  tenant_id       UUID NOT NULL REFERENCES tenant(id),
  operator_id     UUID NOT NULL REFERENCES app_user(id),   -- user of the PLATFORM account
  role_id         UUID NOT NULL REFERENCES role(id),       -- usually read-only system role
  reason          TEXT NOT NULL,
  requested_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
  approved_by     UUID REFERENCES app_user(id),            -- customer Account Admin
  approved_at     TIMESTAMPTZ,
  ends_at         TIMESTAMPTZ NOT NULL,                    -- max 72 h
  revoked_at      TIMESTAMPTZ,
  version         BIGINT NOT NULL
);

-- ===== Audit v2 =====
ALTER TABLE audit_event ADD COLUMN impersonated_by UUID;
ALTER TABLE audit_event ADD COLUMN seq       BIGINT;
ALTER TABLE audit_event ADD COLUMN prev_hash BYTEA;
ALTER TABLE audit_event ADD COLUMN hash      BYTEA;
CREATE INDEX ae_account_seq_idx ON audit_event(account_id, seq);

CREATE TABLE audit_staging (                         -- trigger writes here in Phase 2; chainer job drains it
  id        BIGSERIAL PRIMARY KEY,
  payload   JSONB NOT NULL,                           -- full audit_event row as JSON
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
-- iam_audit() changes its INSERT target from audit_event to audit_staging (same transaction, no lock wait)

CREATE TABLE audit_chain_head (
  account_id  UUID PRIMARY KEY,                       -- '0000…' bucket for events without account
  seq         BIGINT NOT NULL,
  hash        BYTEA  NOT NULL
);
CREATE TABLE audit_anchor (                           -- hourly snapshot of each head; INSERT-only
  account_id  UUID   NOT NULL,
  seq         BIGINT NOT NULL,
  hash        BYTEA  NOT NULL,
  signature   BYTEA  NOT NULL,                        -- signed with the IAM signing key (verifiable via JWKS)
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
  PRIMARY KEY (account_id, seq)
);
CREATE TABLE audit_export_target (
  id          UUID PRIMARY KEY,
  account_id  UUID NOT NULL REFERENCES account(id),
  url         TEXT NOT NULL,
  secret_enc  BYTEA NOT NULL,                         -- HMAC key for X-Signature
  cursor_seq  BIGINT NOT NULL DEFAULT 0,
  status      TEXT NOT NULL DEFAULT 'ACTIVE' CHECK (status IN ('ACTIVE','PAUSED','FAILING')),
  failures    INT  NOT NULL DEFAULT 0,
  version     BIGINT NOT NULL
);
CREATE TABLE pii_key (                                -- per-account key for pseudonymising PII in audit
  account_id  UUID PRIMARY KEY,
  key_enc     BYTEA NOT NULL,
  destroyed_at TIMESTAMPTZ
);

-- ===== Data rights =====
CREATE TABLE data_request (
  id              UUID PRIMARY KEY,
  account_id      UUID NOT NULL REFERENCES account(id),
  tenant_id       UUID REFERENCES tenant(id),
  subject_user_id UUID REFERENCES app_user(id),
  type            TEXT NOT NULL CHECK (type IN ('EXPORT','ERASE')),
  status          TEXT NOT NULL CHECK (status IN ('PENDING','RUNNING','DONE','BLOCKED','FAILED')),
  requested_by    UUID NOT NULL REFERENCES app_user(id),
  result          BYTEA,                              -- zipped JSON for small exports; else streamed on demand
  created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
  finished_at     TIMESTAMPTZ,
  version         BIGINT NOT NULL
);
-- legal hold: account.settings.legal_hold = true blocks ERASE
```

Add the Phase 1 `iam_audit()` trigger to every new table except `login_challenge`, `user_recovery_code` and `scim_token`; those are audited explicitly without secrets.

---

## 4. Flows

### 4.1 Email-first login with SSO discovery

```
POST /auth/discover { email }
  domain = after '@'
  identity_provider_domain (verified, IdP ACTIVE) found
     → { method: "SSO", url: "/sso/{registrationId}/start" }
  else → { method: "PASSWORD" }
  (POST /auth/login rejects password login for an enforced account unless user.break_glass)
```

### 4.2 SSO callback (OIDC and SAML share the same ending)

```
/sso/{registrationId}/callback
  1. Spring Security validates: OIDC (code + PKCE, id_token signature, nonce, aud, iss)
                                SAML (signed assertion required, audience, recipient, NotOnOrAfter, InResponseTo)
  2. SsoUserResolver:
       user_identity(idp, subject) found              → user
       else app_user(account, email) found            → link identity
       else jit_provision                             → create ACTIVE user, primary = default_tenant, role = default_role
       else                                           → reject "Ask your administrator for access"
  3. GroupRoleReconciler.sync(user, groupsClaim)      (4.3)
  4. Phase 1: SessionService.create → PermissionResolver → JwtIssuer
  5. Redirect to app with a one-time code; app exchanges it at POST /auth/sso/token (tokens never in URL)
  6. Audit: auth.sso.success | auth.sso.failed (reason) | iam.user.jit_provisioned
```

`DbClientRegistrationRepository` and `DbRelyingPartyRegistrationRepository` load from `identity_provider`, cache in Caffeine for 5 min, and are evicted when the IdP is updated. A nightly job refreshes SAML metadata so customer certificate rotations do not break login.

### 4.3 Group → role reconciliation

```
desired = idp_group_role_mapping for user's groups
current = role_assignment WHERE user_id = ? AND source = 'IDP_GROUP'
INSERT desired − current ; DELETE current − desired ; if anything deleted → RevocationService.revoke(user)
```

`MANUAL` assignments are never touched, so admins can still grant extra roles inside the app.

### 4.4 MFA

Password OK → `login_challenge` (5 min, 5 attempts) → `POST /auth/mfa/verify {challengeId, code}` → session + tokens, with the `amr: ["pwd","otp"]` claim. TOTP uses RFC 6238 with ±1 step tolerance and replay protection (last used step stored). Admin reset clears the secret and recovery codes, revokes sessions and is audited.

### 4.5 SCIM

- `POST/GET/PUT/PATCH/DELETE /scim/v2/Users`, filter `userName eq` and `externalId eq`.
- `PATCH active=false`: user DISABLED, sessions and API keys revoked, `RevocationService.revoke`, effective within 5 s.
- `DELETE`: DEPROVISIONED (never a hard delete).
- `/scim/v2/Groups` with members updates `scim_group_member` and runs reconciliation 4.3 for affected users. Group pushes with thousands of members are applied with batch SQL.

### 4.6 API keys → JWT

`POST /auth/token { grant_type: "api_key", api_key }`: look up by prefix, constant-time hash compare, check SERVICE user ACTIVE and key valid, then issue a 15-min JWT for the service user's primary tenant (`typ: "SERVICE"`). Downstream checks are identical to those for human users. `last_used_at` is written at most once per minute.

### 4.7 Two-person approval

If `account.settings.require_approval = true` and the role contains a `sensitive` permission, `POST /assignments` returns 202 with a `role_assignment_request`. Another admin approves, which creates the assignment with `source = 'APPROVAL'`. Pending requests expire after 7 days. A DB check prevents self-approval.

### 4.8 Operator access

A platform operator requests access to tenant T with a reason and duration (max 72 h). An Account Admin of T's account approves. `POST /auth/operator-session {grantId}` issues a JWT with `tid = T`, `imp = operatorId` and the grant role's permissions. Every audit event in that session carries `impersonated_by`. The customer can see active grants and revoke them immediately.

### 4.9 Audit hash chain

```
insert path (AuditWriter + trigger + ingest), per event:
  SELECT seq, hash FROM audit_chain_head WHERE account_id = ? FOR UPDATE
  seq  = head.seq + 1
  hash = sha256(head.hash || canonical_json(event))     -- canonical = sorted keys, no whitespace, excluding seq/hash
  INSERT audit_event (..., seq, prev_hash, hash); UPDATE audit_chain_head
```

- **Trigger events:** the DB trigger writes to a small `audit_staging` table. A chainer job (every 1 s, ShedLock, SKIP LOCKED) moves rows into `audit_event` with the chain applied. Business transactions therefore never wait on the per-account lock, and events still exist the moment the transaction commits.
- **Anchors:** an hourly job writes a signed `audit_anchor` for each changed head.
- **Verification:** `GET /api/audit/verify?from=&to=` recomputes the range and compares it with the anchors.

---

## 5. Task breakdown

### Track A · SSO (weeks 1–3)

| ID | Task | Est | Depends | Done when |
|---|---|---|---|---|
| P2-A.1 | `V10__enterprise.sql` (SSO part) + audit triggers | 0.5d | – | Migrates on Phase 1 DB |
| P2-A.2 | IdP aggregate + admin API (`iam.sso.manage`, new permission in manifest): create/update/disable OIDC & SAML; return SP metadata, ACS and redirect URLs | 2d | A.1 | Okta + Entra configured in QA |
| P2-A.3 | Domain verification: TXT token, `POST …/domains/{d}/verify` does DNS lookup (dnsjava); unverified never routed; one domain → one IdP globally | 1d | A.2 | Claiming another account's domain impossible |
| P2-A.4 | `/auth/discover` + password-login block for enforced accounts (break-glass exempt) | 0.5d | A.3 | – |
| P2-A.5 | OIDC via `oauth2-client` with `DbClientRegistrationRepository`, PKCE, claim mapping (email, name, groups) | 2d | A.2 | Login via Okta, Entra, Google in QA |
| P2-A.6 | SAML via `saml2-service-provider` with `DbRelyingPartyRegistrationRepository`, signed assertions, metadata refresh job | 3d | A.2 | Login via Entra SAML + ADFS in QA |
| P2-A.7 | `SsoUserResolver` (link, JIT, reject) + one-time code exchange `POST /auth/sso/token` | 2d | A.5/A.6 | Same JWT shape as password login |
| P2-A.8 | Group mapping API + `GroupRoleReconciler` | 1.5d | A.7 | Leaving IdP group removes role at next login |
| P2-A.9 | Customer setup guides: Okta, Entra ID, Google Workspace, ADFS | 1.5d | A.8 | Published |

### Track B · MFA (week 2)

| ID | Task | Est | Depends | Done when |
|---|---|---|---|---|
| P2-B.1 | TOTP enrol (otpauth URI), verify, replay protection, 10 recovery codes (hashed) | 1.5d | – | Unit tests |
| P2-B.2 | `login_challenge` step in `LoginService`; `amr` claim | 1d | B.1 | Audited |
| P2-B.3 | `require_mfa` account setting (forces enrolment at next login); admin reset | 0.5d | B.2 | – |

### Track C · SCIM (weeks 3–4)

| ID | Task | Est | Depends | Done when |
|---|---|---|---|---|
| P2-C.1 | SCIM token per IdP (create shown once, rotate, revoke); `ScimAuthFilter` | 0.5d | A.2 | – |
| P2-C.2 | `/scim/v2/Users` full CRUD, filters, PATCH ops, `ListResponse` paging | 3d | C.1 | Passes Okta SCIM test suite |
| P2-C.3 | `/scim/v2/Groups` + members → reconciliation, batch SQL | 2d | C.2, A.8 | 5k-member push < 10 s |
| P2-C.4 | `ServiceProviderConfig`, `Schemas`, `ResourceTypes` | 0.5d | C.2 | – |
| P2-C.5 | Cross-account isolation tests (token of IdP X cannot touch account Y) | 0.5d | C.2 | – |
| P2-C.6 | End-to-end with Okta and Entra provisioning | 1.5d | C.2–C.4 | Both green |

### Track D · Machine access (week 4)

| ID | Task | Est | Depends | Done when |
|---|---|---|---|---|
| P2-D.1 | SERVICE user type: no password/SSO login, explicit roles only, `iam.service_account.manage` permission | 1d | – | – |
| P2-D.2 | API keys: create (shown once), list (prefix), revoke; default 365 d; max 2 active for rotation | 1d | D.1 | – |
| P2-D.3 | `grant_type=api_key` token exchange + per-key rate limit (Bucket4j/Postgres) | 1d | D.2 | – |
| P2-D.4 | Expiry notifications (30/7 days) + nightly auto-revoke | 0.5d | D.2 | – |

### Track E · Governance (weeks 4–5)

| ID | Task | Est | Depends | Done when |
|---|---|---|---|---|
| P2-E.1 | Per-account session policy: idle timeout, absolute lifetime, max concurrent sessions (oldest revoked) | 1d | – | Enforced in refresh |
| P2-E.2 | Approval workflow (4.7): request, approve/reject, cancel, auto-expire job, notifications | 2.5d | – | Self-approval impossible (DB + test) |
| P2-E.3 | Operator access (4.8): request, approve, operator session, revoke, `impersonated_by` in every audit event | 2.5d | – | Audit filter by impersonation works |
| P2-E.4 | Access review report: per tenant, users × roles × source × last login; CSV stream | 1d | – | – |

### Track F · Audit v2 (weeks 5–6)

| ID | Task | Est | Depends | Done when |
|---|---|---|---|---|
| P2-F.1 | Canonical JSON serializer + chain computation in `AuditWriter` and ingest | 1.5d | – | Deterministic hash across JVMs |
| P2-F.2 | Trigger → `audit_staging`; chainer job moves rows with chain applied | 1.5d | F.1 | No business tx waits on chain lock |
| P2-F.3 | Backfill job: chain all Phase 1 events per account in `occurred_at, event_id` order | 1d | F.1 | 100% accounts chained |
| P2-F.4 | Hourly signed anchors + `GET /api/audit/verify` + downloadable verification report | 1.5d | F.3 | Manually altered row (as superuser) detected |
| P2-F.5 | SIEM webhook export: batches of 500, HMAC header, exponential backoff, FAILING after 24 h with alert, cursor by `seq` | 2d | F.1 | Splunk HEC + Datadog tested |
| P2-F.6 | PII pseudonymisation: fields marked `pii` in manifest stored as HMAC(pii_key); erasure = destroy key | 1.5d | – | Verification still passes after key destroyed |
| P2-F.7 | Decision checkpoint: measure per-account event rate; document when to switch to batch chaining | 0.5d | F.2 | Recorded |

### Track G · Data rights (weeks 6–7)

| ID | Task | Est | Depends | Done when |
|---|---|---|---|---|
| P2-G.1 | `data_request` aggregate + runner job; legal hold blocks ERASE (status BLOCKED) | 1d | – | – |
| P2-G.2 | EXPORT: account/tenant/user data as JSON (users, memberships, roles, assignments, audit), streamed download | 2d | G.1 | 100k users export < 2 min |
| P2-G.3 | User ERASE: anonymise profile, delete identities, sessions, keys, MFA; audit rows kept (PII already pseudonymised) | 1.5d | G.1, F.6 | Audit chain verifies after erase |
| P2-G.4 | Account close + ERASE after grace period: destroy `pii_key`, anonymise all users, keep tombstone account row | 1d | G.3 | – |

### Track Z · Hardening (week 7)

| ID | Task | Est | Depends | Done when |
|---|---|---|---|---|
| P2-Z.1 | SSO attack tests: assertion replay, unsigned/partially signed assertion, XML signature wrapping, wrong audience/issuer, IdP-initiated disabled by default, open redirect | 2d | A.* | All rejected |
| P2-Z.2 | Load test additions: SSO login 50 rps, SCIM 10k-user sync, audit ingest with chaining 2k events/s | 1.5d | all | Targets met |
| P2-Z.3 | Runbooks: IdP certificate rotation, customer locked out of SSO (break-glass), SCIM token leak, chain verification failure, SIEM endpoint down | 1d | – | Published |
| P2-Z.4 | External penetration test; close findings | – | all | Report clean |

---

## 6. Timeline (3 backend engineers)

| Week | Engineer 1 | Engineer 2 | Engineer 3 |
|---|---|---|---|
| 1 | A.1–A.4 | A.5 | B.1–B.2 |
| 2 | A.6 | A.7 | B.3, D.1–D.2 |
| 3 | A.8–A.9 | C.1–C.2 | D.3–D.4 |
| 4 | C.3–C.6 | E.1–E.2 | F.1 |
| 5 | E.3–E.4 | F.2–F.3 | F.4 |
| 6 | G.1–G.2 | F.5–F.6 | G.3–G.4 |
| 7 | Z.1 | Z.2 | Z.3, fixes |

## 7. Phase 2 exit criteria

- [ ] At least one OIDC and one SAML customer IdP live, and enforce-SSO enabled for one account with a working break-glass admin.
- [ ] Deactivating a user in Okta or Entra blocks access on all applications within 5 s.
- [ ] MFA can be required per account for password users.
- [ ] Integrations use API keys tied to service accounts; no shared human credentials.
- [ ] Sensitive roles need a second admin's approval; operator access is customer-approved, time-boxed and visible in audit.
- [ ] The audit chain verifies for every account, signed anchors exist hourly, and at least one customer receives the SIEM export.
- [ ] A user erasure completes and the audit chain still verifies.
- [ ] Still no infrastructure beyond PostgreSQL.

---

## 8. Backlog (only when a customer needs it)

WebAuthn/passkeys · quarterly access recertification workflow · anomaly alerts on the audit stream (impossible travel, mass export) · external anchoring of the audit chain (S3 Object Lock / public timestamping) · read replicas for audit search · multi-region deployment pinned per account.
