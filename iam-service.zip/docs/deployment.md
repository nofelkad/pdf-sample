# Deploying iam-service

Ruling R44 (final review M5): every setting a shared environment (staging, production) must or should provide. Spring
Boot reads each property from the environment too (`iam.security.trusted-proxies` = `IAM_SECURITY_TRUSTEDPROXIES`,
`spring.mail.host` = `SPRING_MAIL_HOST`, ...); the variables named below have explicit placeholders in
`application.yml`. For a laptop see [local-development.md](local-development.md).

Run the jar without a profile (or with your own, never `dev`, `local` or `test`: those carry well-known passwords and
keys). Startup **fails** when a required value is missing; it **warns** when a value is probably wrong.

## Required

| Variable / property | What | If missing |
|---|---|---|
| `IAM_DB_URL` (`spring.datasource.url`) | JDBC URL of PostgreSQL 16, e.g. `jdbc:postgresql://db:5432/iam_db`. For failover use a URL that follows the primary (DNS/VIP, or multi-host with `targetServerType=primary`) | defaults to `localhost:5442` (docker compose) |
| `IAM_DB_APP_USER`, `IAM_DB_APP_PASSWORD` | the DML-only application role (`iam_app`, P1-2.3) | startup fails (`DatabaseCredentialsGuard` also refuses the well-known compose passwords) |
| `IAM_DB_MIGRATOR_USER`, `IAM_DB_MIGRATOR_PASSWORD` | the Flyway owner role (`iam_migrator`, DDL) | startup fails |
| `IAM_ISSUER` (`iam.security.issuer`) | `iss` of every token and the accepted issuer: the public base URL of IAM, identical on every instance and in every application's `iam.client.issuer` | startup fails |
| `IAM_MASTER_KEY` (`iam.security.master-key`) | base64 of 32 random bytes (`openssl rand -base64 32`); AES-256-GCM key of the signing keys' private parts. Same on every instance; keep it in a secrets manager. Rotation is a known Phase 1 gap | startup fails |

## Network

| Variable / property | Default | What |
|---|---|---|
| `server.port` | `8080` | API, `/auth/**`, `/.well-known/jwks.json`, the two probes |
| `IAM_MANAGEMENT_PORT` (`management.server.port`) | `8081` | actuator: health, info, **unauthenticated** `/actuator/prometheus` (ruling R36). Expose to the monitoring network only |
| `IAM_CORS_ALLOWED_ORIGINS` (`iam.security.cors.allowed-origins`) | empty = CORS denied | exact origins of browser front ends (admin UI), comma separated; no wildcards |
| `iam.security.trusted-proxies` | empty | see [Client IP and rate limits](#client-ip-and-rate-limits) |

### Client IP and rate limits

Final review I3. The client IP feeds the per-IP rate limits (`iam.auth.rate-limit.per-ip`, 10 per minute on login,
forgot and reset; `refresh-per-ip`, 60 per minute) and every audit row's `actor_ip`. It is the TCP peer address, unless
the peer is a **trusted proxy**; then it is the right-most `X-Forwarded-For` entry that is not itself a trusted proxy
(ruling R35).

* Behind a load balancer, ingress or service mesh, set `iam.security.trusted-proxies` to the addresses or **CIDR
  ranges** of those proxies, for example `IAM_SECURITY_TRUSTEDPROXIES=10.0.0.0/8,fd00::/8`. Without it every user shares
  the load balancer's bucket (10 logins per minute for everybody) and audit rows show the proxy's address. iam-service
  logs a WARN at startup when the list is empty outside the `dev`, `local` and `test` profiles.
* List **only** proxy ranges. A range that also covers clients lets those clients pick their own `X-Forwarded-For`
  value and escape per-IP limits.
* The proxy closest to IAM must **append** to `X-Forwarded-For` (AWS ALB, nginx `$proxy_add_x_forwarded_for`, Envoy
  default) or add its own header line; IAM reads every line.
* Applications using iam-client record `getRemoteAddr()` as the audit `actorIp`; configure their own forwarded-header
  handling (iam-client README, section 9).

## Notifications (invitations, password resets)

| Property | Default | What |
|---|---|---|
| `iam.notification.mode` | `log` | `log`: emails are **not sent**, only logged without the link (a startup WARN outside `dev`/`local`/`test`, ruling R44); `smtp`: sent through `spring.mail.*` |
| `iam.notification.from` | `no-reply@iam.local` | sender address |
| `iam.notification.invitation-url` | `http://localhost:3000/invitations/accept?token={token}` | public link to the page that calls `POST /auth/invitations/accept`; `{token}` is replaced by the token |
| `iam.notification.password-reset-url` | `http://localhost:3000/password/reset?token={token}` | public link to the page that calls `POST /auth/password/reset` |
| `spring.mail.host`, `spring.mail.port`, `spring.mail.username`, `spring.mail.password`, `spring.mail.properties.mail.smtp.starttls.enable` | none | SMTP server; required with `mode=smtp` |
| `spring.mail.properties.mail.smtp.connectiontimeout` / `.timeout` / `.writetimeout` | 5000 / 10000 / 10000 ms | bounded socket waits (set in `application.yml`) |
| `iam.notification.executor.threads` / `queue-capacity` / `send-timeout` | 2 / 10000 / `PT30S` | invitation sender (final review I2, see [failure-modes.md](failure-modes.md#5-mail-server-smtp-slow-or-down)) |
| `iam.auth.mail-executor.threads` / `queue-capacity` / `send-timeout` | 1 / 1000 / `PT30S` | password-reset sender (ruling R31) |

With `mode=smtp` startup **fails** when either link URL is missing, relative, lacks `{token}` or points at a loopback
host (`localhost`, `*.localhost`, `127.x`, `::1`; the defaults do): every mailed link would be dead.

## Revocation and polling

| Property | Default | What |
|---|---|---|
| `iam.revocation.poll-interval` | `PT2S` | how often each instance reads the revocation feed (ruling R41: revocation reaches every instance within 5 s) |
| `iam.revocation.startup-lookback` | `PT20M` | feed rows replayed at startup (longer than the 15 min token lifetime) |
| `iam.revocation.retention` / `purge-interval` | `PT1H` / `PT5M` | feed rows older than this are purged |
| `iam.observability.revocation-stale-after` | `PT30S` | readiness turns `NOT_READY` (503) when no complete poll succeeded for this long |
| `iam.client.revocation.poll-interval` (in applications) | `PT2S` | the iam-client poller |

## Tokens and keys

| Property | Default | What |
|---|---|---|
| `iam.security.access-token-ttl` | `PT15M` | user access tokens |
| `iam.security.app-token-ttl` | `PT10M` | application client tokens |
| `iam.security.clock-skew` | `PT60S` | tolerance on `exp`/`nbf`; keep hosts NTP-synchronised |
| `iam.security.key-rotation-interval` / `key-publish-lead` / `key-retire-margin` | `P90D` / `PT24H` / `PT5M` | signing-key rotation (runbook [key-rotation](runbooks/key-rotation.md)) |
| `iam.security.jwk-refresh-interval` | `PT60S` | how often each instance reloads keys from the database |
| `iam.auth.session.absolute-ttl` / `idle-ttl` | `PT12H` / `PT30M` | refresh-token session limits |
| `iam.auth.lockout.max-attempts` / `duration` | 5 / `PT15M` | failed-login lockout |
| `iam.auth.rate-limit.*` | see `AuthProperties` | per-IP / per-email limits on the public `/auth` endpoints |

## Audit, jobs and data retention

| Property | Default | What |
|---|---|---|
| `iam.audit.retention` | `P7Y` | partitions older than this are detached and handed to the archive hook |
| `iam.audit.archive.mode` | empty (refuse) | how detached partitions are archived (runbook [audit-partition-missing](runbooks/audit-partition-missing.md)) |
| `iam.audit.partition-cron` / `retention-cron` | `0 10 1 * * *` / `0 40 2 * * *` | ShedLock jobs |
| `iam.audit.export.max-concurrent` / `timeout` | 2 / `PT30M` | concurrent CSV exports per instance and their async timeout |
| `iam.assignment.expiry.interval` / `batch-size` | `PT5M` / 5000 | expired role assignments are deleted and their users revoked |
| `iam.bulk-invite.threads` / `queue-capacity` / `stale-after` | 2 / 20 / `PT30M` | bulk invite jobs; RUNNING jobs older than `stale-after` are marked FAILED (ruling R29) |
| `iam.tokens.purge.retention` / `interval` | `P30D` / `PT1H` | used or expired invitation/reset tokens and ended sessions older than the retention are deleted (final review M2) |

## Database pool

| Property | Default | What |
|---|---|---|
| `spring.datasource.hikari.maximum-pool-size` | 10 (Hikari) | connections per instance; instances × pool size must stay below PostgreSQL's `max_connections` |
| `spring.datasource.hikari.connection-timeout` | 5000 ms | a request waits at most this long for a connection, then 503 `database_unavailable` |

## Checklist

1. Database roles `iam_app` (DML) and `iam_migrator` (owner) exist (`docker/postgres/init/01-roles.sh` shows the SQL).
2. `IAM_DB_*`, `IAM_ISSUER`, `IAM_MASTER_KEY` set from the secrets manager; the same issuer and master key on every
   instance.
3. Management port reachable from monitoring only; application port behind the load balancer.
4. `iam.security.trusted-proxies` lists the load balancer / ingress ranges; no startup WARN about it.
5. `iam.notification.mode=smtp`, `spring.mail.*`, public `invitation-url` and `password-reset-url`; no startup WARN
   about `mode=log`.
6. `IAM_CORS_ALLOWED_ORIGINS` lists the admin UI's origin if it runs in a browser on another origin.
7. Readiness probe `/actuator/health/readiness`, liveness probe `/actuator/health/liveness`.
8. First operator: runbook [bootstrap-platform-admin](runbooks/bootstrap-platform-admin.md).
