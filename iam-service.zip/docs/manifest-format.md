# Product manifest format (P1-7.1)

A product tells IAM which permissions it defines and which system roles ship with it by publishing a **manifest**.
IAM's own manifest is `iam-service/src/main/resources/iam-manifest.yaml`, loaded at startup. Any other product uploads
its manifest over HTTP. Both go through the same code, `RegistryService.apply`.

The manifest is the product's **complete** catalogue: whatever the product no longer lists is deprecated.

## Fields

YAML and JSON use the same field names. Unknown fields are rejected (`invalid_manifest`), so a typo cannot silently
drop a section.

| Field | Type | Required | Meaning |
|---|---|---|---|
| `product` | string | yes | Product code, `[A-Z][A-Z0-9_]{1,31}`, for example `BILLING`. `PLATFORM` is reserved. |
| `name` | string | no | Display name. A new product defaults to its code; an existing product keeps its name when absent. |
| `permissions` | list | no | The product's permissions (below). |
| `system_roles` | list | no | The product's SYSTEM roles (below). |

### `permissions[]`

| Field | Type | Default | Meaning |
|---|---|---|---|
| `code` | string | required | Lower-case dotted segments, for example `billing.invoice.approve`. Globally unique. |
| `kind` | `FEATURE` or `DATA` | required | `FEATURE` gates an action. `DATA` scopes a read (see below). |
| `description` | string | required | Human readable. |
| `sensitive` | boolean | `false` | Marks the permission for the Phase 2 approval workflow. |
| `audit_read` | boolean | `false` | Reads protected by this permission must be audited. |

Rules, all checked before anything is written:

- **Namespace.** `code` must start with the product code in lower case plus a dot (`BILLING` owns `billing.`).
  IAM additionally owns `platform.` (`platform.account.manage`).
- **No duplicates** inside one manifest. A code already registered by a *different* product is rejected too.
- **Kind.** Anything but `FEATURE` or `DATA` is rejected.
- **Data scope (spec section 5).** A `DATA` permission ends in `.own`, `.tenant` or `.account`
  (`billing.invoice.read.tenant`). Applications apply it as `owner_id = sub`, `tenant_id = tid` or `account_id = acc`.
- **`.account` is granted at ACCOUNT scope only (ruling R42).** A `DATA` permission whose code ends in `.account`
  reaches a token (and `GET /api/users/{id}/effective-permissions`) only when it comes from an **ACCOUNT-scope**
  assignment. A role containing it may still be assigned at TENANT scope; that assignment grants the role's other
  permissions, but not the `.account` one. So `x.read.account` in a token always means "every record of the account",
  which is what iam-client's `DataScope` assumes, and a tenant-scoped grant can never widen a user's data scope beyond
  the tenant. Give tenant-level users the `.tenant` variant (`billing.invoice.read.tenant`) instead; IAM's own
  `Auditor` role (`iam.user.read.account`) is meant for ACCOUNT scope.

### `system_roles[]`

| Field | Type | Meaning |
|---|---|---|
| `name` | string | Unique within the manifest, case-insensitive. The role is identified by `(product, name)`. |
| `permissions` | list of strings | Exact permission codes **or** prefix wildcards ending in `.*` (`billing.*` is every code starting with `billing.`). |
| `exclude` | list of strings | Same syntax. Removed from what `permissions` expanded to. |

- An exact code in `permissions` must be declared in the same manifest.
- Every entry, in `permissions` and in `exclude`, must stay inside the product's namespace, so `billing.*` is allowed and
  `iam.*` is not. A product therefore cannot put another product's permissions into its own roles.
- A role's permission set is the **expansion** of `permissions` minus the expansion of `exclude`. Wildcards expand across
  all products' current, non-deprecated permissions (in practice only the product's own, because of the namespace rule),
  evaluated after this manifest's permissions were upserted. Deprecated permissions are never part of a role.

## Example

```yaml
product: BILLING
name: Billing
permissions:
  - { code: billing.invoice.approve,     kind: FEATURE, description: Approve invoices, sensitive: true }
  - { code: billing.invoice.export,      kind: FEATURE, description: Export invoices, audit_read: true }
  - { code: billing.invoice.read.tenant, kind: DATA,    description: Read invoices of the active tenant }
  - { code: billing.invoice.read.account, kind: DATA,   description: Read invoices of the whole account }
system_roles:
  - { name: Billing Admin,  permissions: [ "billing.*" ] }
  - { name: Billing Viewer, permissions: [ "billing.*" ], exclude: [ "billing.invoice.approve", "billing.invoice.export" ] }
```

In a YAML flow mapping (`{ ... }`) an unquoted comma ends the value; quote descriptions that contain one.

The same document as JSON is what `PUT /internal/products/{code}/manifest` takes:

```json
{ "product": "BILLING", "name": "Billing",
  "permissions": [ { "code": "billing.invoice.approve", "kind": "FEATURE", "description": "Approve invoices",
                     "sensitive": true, "audit_read": false } ],
  "system_roles": [ { "name": "Billing Admin", "permissions": ["billing.*"], "exclude": [] } ] }
```

## What applying a manifest does

`RegistryService.apply(manifest)` runs in **one transaction** and is **idempotent**: applying the same manifest again
writes nothing (no rows, no audit events) and reports `changed: false`.

1. Validates the manifest. Any violation is `400 invalid_manifest` with a `violations` list; nothing is written.
2. Takes an advisory lock per product, so two instances starting together, or an upload racing a startup, run one after
   the other. The later one finds nothing to change.
3. Creates the product when it is new.
4. Upserts the permissions, writing only rows that differ. A permission **missing** from the manifest becomes
   `deprecated`; one that **reappears** is un-deprecated.
5. Rebuilds the product's SYSTEM roles: missing roles are created, an existing role's permissions are changed to exactly
   the expanded set (only the difference is written).
   A SYSTEM role that is **no longer in the manifest is left in place** (a warning is logged), not deleted.
6. **Revocation.** The holders of every system role whose permission set changed, and of every role (system or custom)
   containing a permission that was just deprecated, have their tokens revoked. All of them are collected and revoked in
   **one** `RevocationService.revokeUsers` call as the last write of the transaction (the revocation service allows one
   `revoke*` per transaction). Roles created by the apply have no holders. Both growing and shrinking a role revoke its
   holders, so users pick up new permissions at once.

## Delivery

### IAM's own manifest

`classpath:iam-manifest.yaml`, applied while the Spring context refreshes: after Flyway, before the web server and any
`ApplicationRunner`. A failure aborts startup. `iam.registry.load-on-startup=false` turns it off and
`iam.registry.manifest=<resource location>` points it elsewhere (both meant for tests). It is **never** accepted over HTTP.

### Applications: `PUT /internal/products/{code}/manifest`

- `Content-Type: application/json`, body as above.
- Authorization: an application token (`POST /internal/token`) with `internal.manifest.write`. The token's `prd` claim
  must equal `{code}`; an application manages only its own product.
- Response `200`:

```json
{ "product": "BILLING", "changed": true, "permissionsAdded": 4, "permissionsUpdated": 0,
  "permissionsDeprecated": 0, "rolesChanged": 2 }
```

| Status | `code` | When |
|---|---|---|
| 400 | `invalid_manifest` | A rule above is broken or the JSON is malformed (`violations` lists every problem). |
| 400 | `product_mismatch` | The body's `product` differs from `{code}`. |
| 401 | | No or invalid token. |
| 403 | `product_mismatch` | The token's `prd` differs from `{code}` (audited as `authz.denied`). |
| 403 | `iam_manifest_not_uploadable` | `{code}` is `IAM`. |
| 403 | `forbidden` | The token lacks `internal.manifest.write` (for example a user token). |

### Reading a catalogue: `GET /api/products/{code}/permissions`

Authenticated-only, deliberately: **any signed-in caller may list any product's permission catalogue** (codes, kinds,
descriptions, flags, `deprecated`). It contains no tenant data and the role editor and client applications need it.
`404 product_not_found` for an unknown product.
