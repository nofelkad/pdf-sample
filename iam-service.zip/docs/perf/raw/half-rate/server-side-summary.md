| snapshot | meter | op | p50 ms | p95 ms | p99 ms | count |
|---|---|---|---:|---:|---:|---:|
| LoginSimulation | iam_auth_login_duration |  | 19.40 | 21.50 | 22.54 | 3127 |
| LoginSimulation | iam_auth_refresh_duration |  | 0.00 | 0.00 | 0.00 | 0 |
| LoginSimulation | iam_auth_tenant_switch_duration |  | 0.00 | 0.00 | 0.00 | 0 |
| LoginSimulation | iam_permission_resolve_duration | explain | 0.00 | 0.00 | 0.00 | 0 |
| LoginSimulation | iam_permission_resolve_duration | resolve | 0.48 | 0.71 | 0.81 | 3127 |
| RefreshSimulation | iam_auth_login_duration |  | 0.00 | 0.00 | 0.00 | 3277 |
| RefreshSimulation | iam_auth_refresh_duration |  | 6.95 | 11.40 | 17.69 | 18000 |
| RefreshSimulation | iam_auth_tenant_switch_duration |  | 4.85 | 8.78 | 11.40 | 1810 |
| RefreshSimulation | iam_permission_resolve_duration | explain | 0.00 | 0.00 | 0.00 | 0 |
| RefreshSimulation | iam_permission_resolve_duration | resolve | 0.61 | 2.35 | 3.14 | 23087 |
| EffectivePermissionSimulation | iam_auth_login_duration |  | 0.00 | 0.00 | 0.00 | 3340 |
| EffectivePermissionSimulation | iam_auth_refresh_duration |  | 0.00 | 0.00 | 0.00 | 18000 |
| EffectivePermissionSimulation | iam_auth_tenant_switch_duration |  | 0.00 | 0.00 | 0.00 | 1810 |
| EffectivePermissionSimulation | iam_permission_resolve_duration | explain | 1.23 | 2.02 | 2.87 | 3000 |
| EffectivePermissionSimulation | iam_permission_resolve_duration | resolve | 0.00 | 0.00 | 0.00 | 23150 |
