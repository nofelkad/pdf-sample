| report | request | requests | KO | req/s (whole run) | p50 ms | p75 ms | p95 ms | p99 ms | max ms | mean ms |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| loginsimulation-20261010121812655 | login | 3000 | 0 | 25.0 | 26 | 27 | 29 | 31 | 40 | 26 |
| refreshsimulation-20261010122014989 | setup login | 150 | 0 | 1.1 | 29 | 32 | 35 | 38 | 38 | 29 |
| refreshsimulation-20261010122014989 | setup me | 150 | 0 | 1.1 | 4 | 5 | 8 | 28 | 46 | 5 |
| refreshsimulation-20261010122014989 | refresh | 18000 | 0 | 127.7 | 11 | 15 | 24 | 29 | 32 | 12 |
| refreshsimulation-20261010122014989 | switch tenant | 1810 | 0 | 12.8 | 5 | 6 | 10 | 14 | 16 | 6 |
| adminapisimulation-20261010122236950 | setup login | 38 | 0 | 0.3 | 45 | 47 | 50 | 53 | 53 | 45 |
| adminapisimulation-20261010122236950 | setup roles | 38 | 0 | 0.3 | 4 | 5 | 6 | 19 | 19 | 4 |
| adminapisimulation-20261010122236950 | setup tenants | 38 | 0 | 0.3 | 2 | 2 | 4 | 6 | 6 | 2 |
| adminapisimulation-20261010122236950 | roles list | 652 | 0 | 4.7 | 2 | 4 | 6 | 11 | 13 | 3 |
| adminapisimulation-20261010122236950 | users list | 1387 | 0 | 9.9 | 2 | 3 | 5 | 9 | 11 | 2 |
| adminapisimulation-20261010122236950 | audit search | 1121 | 0 | 8.0 | 5 | 7 | 10 | 13 | 17 | 5 |
| adminapisimulation-20261010122236950 | assignment create | 1400 | 0 | 10.0 | 10 | 14 | 18 | 22 | 32 | 11 |
| adminapisimulation-20261010122236950 | assignment delete | 1400 | 0 | 10.0 | 8 | 10 | 14 | 19 | 22 | 8 |
| effectivepermissionsimulation-20261010122458060 | setup login | 25 | 0 | 0.2 | 46 | 48 | 51 | 51 | 51 | 41 |
| effectivepermissionsimulation-20261010122458060 | explain | 3000 | 0 | 21.4 | 7 | 8 | 11 | 13 | 16 | 7 |
