| report | request | requests | KO | req/s (whole run) | p50 ms | p75 ms | p95 ms | p99 ms | max ms | mean ms |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| loginsimulation-20261010122823793 | login | 6000 | 0 | 50.0 | 23 | 25 | 29 | 32 | 182 | 24 |
| refreshsimulation-20261010123026135 | setup login | 300 | 0 | 2.1 | 24 | 25 | 28 | 30 | 33 | 24 |
| refreshsimulation-20261010123026135 | setup me | 300 | 0 | 2.1 | 3 | 4 | 6 | 7 | 11 | 4 |
| refreshsimulation-20261010123026135 | refresh | 36000 | 0 | 255.3 | 10 | 14 | 17 | 18 | 29 | 11 |
| refreshsimulation-20261010123026135 | switch tenant | 3583 | 0 | 25.4 | 5 | 6 | 9 | 12 | 13 | 5 |
| adminapisimulation-20261010123248200 | setup login | 77 | 0 | 0.6 | 43 | 46 | 48 | 50 | 50 | 42 |
| adminapisimulation-20261010123248200 | setup roles | 77 | 0 | 0.6 | 2 | 2 | 3 | 4 | 4 | 2 |
| adminapisimulation-20261010123248200 | setup tenants | 77 | 0 | 0.6 | 1 | 2 | 2 | 3 | 3 | 1 |
| adminapisimulation-20261010123248200 | roles list | 1403 | 0 | 10.0 | 2 | 4 | 5 | 7 | 13 | 3 |
| adminapisimulation-20261010123248200 | users list | 2843 | 0 | 20.3 | 2 | 3 | 5 | 7 | 13 | 2 |
| adminapisimulation-20261010123248200 | assignment create | 2738 | 0 | 19.6 | 10 | 13 | 17 | 22 | 26 | 10 |
| adminapisimulation-20261010123248200 | assignment delete | 2738 | 0 | 19.6 | 8 | 10 | 13 | 16 | 18 | 8 |
| adminapisimulation-20261010123248200 | audit search | 2256 | 0 | 16.1 | 5 | 7 | 9 | 22 | 33 | 5 |
| effectivepermissionsimulation-20261010123510092 | setup login | 50 | 0 | 0.4 | 42 | 43 | 45 | 46 | 46 | 41 |
| effectivepermissionsimulation-20261010123510092 | explain | 6000 | 0 | 42.9 | 7 | 10 | 15 | 18 | 20 | 8 |
