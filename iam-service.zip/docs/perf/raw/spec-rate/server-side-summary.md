| snapshot | meter | op | p50 ms | p95 ms | p99 ms | count |
|---|---|---|---:|---:|---:|---:|
| LoginSimulation | iam_auth_login_duration |  | 17.30 | 20.45 | 22.54 | 9340 |
| LoginSimulation | iam_auth_refresh_duration |  | 0.00 | 0.00 | 0.00 | 18000 |
| LoginSimulation | iam_auth_tenant_switch_duration |  | 0.00 | 0.00 | 0.00 | 1810 |
| LoginSimulation | iam_permission_resolve_duration | explain | 0.00 | 0.00 | 0.00 | 3000 |
| LoginSimulation | iam_permission_resolve_duration | resolve | 0.32 | 0.61 | 0.71 | 29150 |
| RefreshSimulation | iam_auth_login_duration |  | 0.00 | 0.00 | 0.00 | 9640 |
| RefreshSimulation | iam_auth_refresh_duration |  | 5.37 | 11.40 | 12.98 | 54000 |
| RefreshSimulation | iam_auth_tenant_switch_duration |  | 4.85 | 8.78 | 10.35 | 5393 |
| RefreshSimulation | iam_permission_resolve_duration | explain | 0.00 | 0.00 | 0.00 | 3000 |
| RefreshSimulation | iam_permission_resolve_duration | resolve | 0.48 | 0.91 | 2.02 | 69033 |
| EffectivePermissionSimulation | iam_auth_login_duration |  | 0.00 | 0.00 | 0.00 | 9767 |
| EffectivePermissionSimulation | iam_auth_refresh_duration |  | 0.00 | 0.00 | 0.00 | 54000 |
| EffectivePermissionSimulation | iam_auth_tenant_switch_duration |  | 0.00 | 0.00 | 0.00 | 5393 |
| EffectivePermissionSimulation | iam_permission_resolve_duration | explain | 1.29 | 2.02 | 2.61 | 9000 |
| EffectivePermissionSimulation | iam_permission_resolve_duration | resolve | 0.00 | 0.00 | 0.00 | 69160 |
