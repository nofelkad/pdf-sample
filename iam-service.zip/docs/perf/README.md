# Performance: load test of iam-service

Spec task P1-11.2, Ruling R6. What exists: a bulk data generator and four Gatling simulations (module `load-test`),
and the results of a **scaled-down smoke run on one laptop**. What does **not** exist yet: the full-scale run (1M users,
5M assignments, 20M audit rows, two IAM instances) on a performance environment. The targets of
`00-overview.md` are therefore **not verified at design scale**; the numbers below say how far a small data set and one
instance get, and what to watch when the real run is done.

## What was run (read before trusting any number)

| | Smoke run (this document) | Design scale (spec, **not run**) |
|---|---|---|
| Users | 20,100 (20,000 + 100 administrators) | 1,000,000 |
| Accounts / tenants | 100 / 400 | 5,000 / 20,000 |
| Role assignments | 103,100 (200 "heavy" users with exactly 20) | 5,000,000 |
| Audit rows | 500,000 over 90 days (about 1,250 per tenant) | 20,000,000 (about 1,000 per tenant) |
| IAM instances | **1** | 2 |
| Database | postgres:16-alpine from `docker-compose.yml`, **default configuration** (shared_buffers 128 MB), 451 MB database | a sized production-like instance |
| Hardware | Apple M5 Pro, 15 cores, 24 GB; Docker Desktop VM with 15 CPUs and 7.75 GB; macOS (Darwin 25.6) | |
| Software | Temurin 21.0.9, iam-service jar with `-Xmx1g`, Hikari pool and Tomcat threads at their defaults, Gatling 3.14.9 | |
| Network | everything on one machine, localhost; the load generator competes with the application and the database for the same CPUs | separate hosts |
| Date | 2026-10-10, commit of the `task-10-ops` branch | |

Per simulation: users ramped in over 20 s, then 120 s of steady load. Two passes: **half rate** (login 25, refresh 150,
admin 50, effective-permission 25 rps; the agreed "reduced rates" smoke) and **spec rates on the single instance**
(login 50, refresh 300, admin 100, effective-permission 50 rps), which the laptop turned out to sustain. The
req/s columns below are averaged over the whole run including the ramp, so they sit below the plateau rate.

Configuration deviations from production defaults (`load-test/scripts/start-iam.sh`): rate limits raised to 100,000
(one load-generating host; each virtual user sends its own `X-Forwarded-For` and the limiter still runs and still does its
database round trip per request, so its cost is in the numbers, it just never answers 429), root log level WARN with
plain logs, dev issuer and master key. Nothing about the application's behaviour was tuned.

Honesty notes on the measurement itself:

* Gatling runs on the same machine; an unloaded dedicated generator would show lower or equal latencies, a saturated
  one higher. No CPU profile was taken.
* Refresh, admin and effective-permission use paced virtual users (one request per second each), so the rate is
  reached by the number of users; a slow response delays that user's next request (it does not add extra load), which
  flatters tail latencies under saturation. Nothing saturated here, but a saturation run should use an open model.
* Percentiles are Gatling's (HdrHistogram, 1 ms resolution). The server-side figures are the new Micrometer meters
  (client-side percentiles over a sliding window of about 2 minutes), scraped right after each run.

## Results against the targets

Client-side = Gatling response time (HTTP round trip on localhost; source: `raw/<pass>/gatling-summary.md`). Server-side = the iam-service meter of the same
operation (`docs/observability.md`). Verdict is for **this scale and this hardware only**.

| Target (00-overview.md) | Scenario | Client p50 / p95 / p99 (ms) | Server-side p50 / p95 / p99 (ms) | Verdict |
|---|---|---|---|---|
| Login p95 < 250 ms | `POST /auth/login`, 50 rps (6,000 requests, 0 KO) | **23 / 29 / 32** (max 182) | 17.3 / 20.5 / 22.5 | Met, large margin (see Argon2 note) |
| Login, half rate | 25 rps (3,000, 0 KO) | 26 / 29 / 31 | 19.4 / 21.5 / 22.5 | Met |
| Refresh p95 < 50 ms | `POST /auth/refresh`, 300 rps plateau (36,000, 0 KO) | **10 / 17 / 18** (max 29) | 5.4 / 11.4 / 13.0 | Met |
| Refresh, half rate | 150 rps (18,000, 0 KO) | 11 / 24 / 29 | 7.0 / 11.4 / 17.7 | Met |
| Tenant switch p95 < 50 ms | `POST /auth/switch-tenant`, about 10 % of refresh iterations (3,583, 0 KO) | **5 / 9 / 12** | 4.9 / 8.8 / 10.4 | Met |
| Effective permissions p95 < 15 ms (user with 20 assignments) | `PermissionResolver` query, server-side meters | n/a | explain 1.3 / 2.0 / 2.6 (heavy users, 20 assignments); resolve 0.3-0.5 / 0.6-0.9 / 0.7-2.0 at spec rates (login and refresh users, about 5 assignments) | **Met for the query**, about 7x margin |
| same, end to end | `GET /api/users/{id}/effective-permissions`, 20-assignment users, 50 rps (6,000, 0 KO) | **7 / 15 / 18** (max 20) | | **At the bound** (p95 = 15 ms, not below): includes HTTP, JWT verification, the explain read model. See notes |
| Audit search (1 tenant, 30 days) p95 < 500 ms | `GET /api/audit/events?tenantId&from&to&limit=50`, about 16 rps inside the 100 rps admin mix (2,256, 0 KO) | **5 / 9 / 22** (max 33) | | Met at 0.5M rows (about 420 rows in the window); **not representative of 20M rows** |
| Admin APIs 100 rps | mix at spec rate: users list 20/s, roles list 10/s, assignment create+delete 19.6/s each, audit search 16/s (whole-run averages, plateau about 15 % higher); 0 KO of 12,000 | users list 2 / 5 / 7; roles list 2 / 5 / 7; assignment create 10 / 17 / 22; assignment delete 8 / 13 / 16 | | No target besides audit search; all single-digit to low double-digit ms |
| Revocation latency <= 5 s | one scrape at the end of the admin run (every assignment change revokes the target user): `iam_revocation_lag_seconds` | | 0.24 s, a single sample (`spec-rate/AdminApiSimulation.after.prom`) | Not a max, not a cross-instance measurement |

Half-rate admin pass (50 rps): audit search 5 / 10 / 13 ms, users list 2 / 5 / 9, roles list 2 / 6 / 11, assignment
create 10 / 18 / 22, delete 8 / 14 / 19; no KO.

Not measured at all: authorization overhead inside an application (< 0.5 ms; that is iam-client JWT verification plus the
in-memory revocation check, see `iam-client`), audit overhead per write (< 2 ms; `AuditIngestThroughputIT` and
`AuditSearchPlanIT` in iam-service are the existing baselines), and revocation across several applications.

Raw material, one directory per pass (`docs/perf/raw/half-rate`, `docs/perf/raw/spec-rate`):

| File | What it is | Feeds |
|---|---|---|
| `gatling-summary.md` | `load-test/scripts/summarize.py` output for the four Gatling reports of the pass (requests, KO, req/s, p50/p75/p95/p99/max/mean per request name, parsed from each report's `index.html`) | every **client-side** figure in the table above and in the half-rate paragraph |
| `server-side-summary.md` | `load-test/scripts/server-side.py` output over the `*.after.prom` snapshots (the iam-service meters' percentiles) | every **server-side** figure |
| `<Simulation>.before.prom` / `.after.prom` | the `iam_*` lines of `/actuator/prometheus`, scraped immediately before and after each run | the server-side summaries, and the revocation gauges |

The Gatling HTML reports themselves were generated under `load-test/build/gatling-results` and are not committed (about
10 MB per pass); the summaries are what they showed. In the spec-rate pass the reports are
`loginsimulation-20261010122823793`, `refreshsimulation-20261010123026135`, `adminapisimulation-20261010123248200` and
`effectivepermissionsimulation-20261010123510092` (half-rate: `...121812655`, `...122014989`, `...122236950`,
`...122458060`). The 0.24 s revocation lag is **one sample**: the value of `iam_revocation_lag_seconds` in
`spec-rate/AdminApiSimulation.after.prom`, i.e. the last revocation applied before the scrape. The gauge keeps no
maximum over the run, so no worst case was recorded; a proper measurement needs the gauge scraped every few seconds
during the run (or the timer on the revoking side) on two instances.

## Observations and what to watch at design scale

Nothing missed a target at this scale, so there is nothing to fix in behaviour (that belongs to Task 9 anyway). Three
things deserve attention in the full run:

1. **Argon2 is much cheaper here than the overview assumes.** Server-side login p50 is 17-19 ms on this machine against
   the "about 100 ms" of the overview; the 250 ms target has far more headroom here than it will on production
   hardware. At 50 logins/s and 100 ms each, hashing alone needs 5 CPU cores. Size the two instances (and their CPU
   limits) accordingly and repeat the login scenario there before trusting the margin. Recommendation, not a change.
2. **Effective permissions end to end sit at the 15 ms bound** even though the query itself takes 2 ms. If the target is
   meant for the endpoint rather than the query, `explain` (an admin read path) is the one that will cross it first at
   larger scale; if it is meant for the query (the spec says "Effective-permission query"), it has about 7x margin.
   The spec should say which. At design scale watch `iam_permission_resolve_duration_seconds{op="explain"}`.
3. **Data volume was 2-2.5 % of the design scale.** Index and table sizes (audit 20M rows is roughly 6-7 GB (an estimate, not measured) with five
   indexes), buffer-cache hit rates, partition counts and the audit-search plan at 30 days of a 20M-row table are
   untested; the default 128 MB `shared_buffers` made this run mostly cache-resident anyway (the database is 451 MB).
   Compare against `AuditSearchPlanIT` first if the audit search misses.

## Reproduce

Needs Docker (database), a built jar, JDK 21. Commands run from the repository root.

```
IAM_DB_PORT=5452 docker compose up -d                       # 5442 is the default; pick a free port
./gradlew :iam-service:bootJar
IAM_DB_PORT=5452 load-test/scripts/start-iam.sh &           # one instance (profile local: compose passwords), trusts 127.0.0.1

# 1. data (as the postgres superuser: triggers are bypassed with session_replication_role = replica)
./gradlew :load-test:generateData -Plt.profile=smoke -Plt.jdbcUrl=jdbc:postgresql://localhost:5452/iam_db
#    full design scale (not run for this document):
./gradlew :load-test:generateData -Plt.profile=full  -Plt.jdbcUrl=jdbc:postgresql://localhost:5452/iam_db

# 2. simulations (each prints Gatling's report location; assertions fail the run when a target is missed)
load-test/scripts/smoke.sh                                  # half rates, 120 s each, stores iam_* meters per run
SCALE=1 load-test/scripts/smoke.sh                          # spec rates on this one instance
./gradlew :load-test:gatlingRun -Plt.simulation=LoginSimulation -Plt.rps=50 -Plt.durationSeconds=120
python3 load-test/scripts/summarize.py <report dir>         # markdown table of a report
python3 load-test/scripts/server-side.py load-test/build/smoke/*.after.prom
```

Generator options (`-Plt.<name>=`): `profile` (smoke, full; default smoke), `users`, `accounts`, `tenantsPerAccount`
(1-4, default 4), `rolesPerAccount` (default 8), `assignments`, `heavyUsers`, `auditRows`, `auditDays` (90), `chunk`
(rows per statement, 100,000), `reset=true` (removes earlier generated rows), `jdbcUrl`, `user`, `password`. It is
set-based `INSERT ... SELECT generate_series`; it hard-codes what it needs from IAM and checks the first three up front
(foreign keys are switched off while it runs, so a wrong id would otherwise load silently): the seeded IAM product id
`00000000-0000-7000-8000-000000000001` (migration V3), the system role named `Account Admin` and the `iam.*`
permissions (from `iam-manifest.yaml`, so iam-service must have started once on the database), the database roles
`iam_app` and `iam_migrator` (`docker/postgres/init`), and a **superuser** connection (`session_replication_role` and
`ALTER TABLE ... OWNER TO`; default `postgres`/`postgres` of the compose file). `reset=true` first removes everything a
previous run created (children first: audit rows of the generated accounts and source `LOADTEST`, assignments, sessions,
tokens, password history, revocations, memberships, users, roles, tenants, accounts) so the generator can be re-run;
it does not touch other data. The smoke set took about 9 seconds; the full set has not been generated
(linear extrapolation says minutes to tens of minutes; run it with `chunk` unchanged and watch the disk).
Gatling parameters: `simulation`, `rps`, `durationSeconds`, `rampSeconds`, `baseUrl`, `assert`, and the data-set shape
(`users`, `accounts`, `tenantsPerAccount`, `rolesPerAccount`, `heavyUsers`) which must match what was generated.

What the simulations do:

| Simulation | Users | Requests |
|---|---|---|
| `LoginSimulation` | open model, `rps` new logins per second | `POST /auth/login` for a random generated user (all share one Argon2 hash of one password, computed once by the generator) |
| `RefreshSimulation` | `rps` virtual users, one request per second each | login once, `GET /api/me`, then `POST /auth/refresh` (rotating the refresh token) every second; one iteration in ten also `POST /auth/switch-tenant` to the user's second tenant and back |
| `AdminApiSimulation` | `rps / 1.3` account administrators (system role Account Admin) | users list 30 %, roles list 15 %, audit search 25 % (one tenant, 30 days), assignment create + delete 30 % (Auditor role at TENANT scope to a random user of the account) |
| `EffectivePermissionSimulation` | `rps` administrators | `GET /api/users/{id}/effective-permissions?tenantId=` for the heavy (20-assignment) users |

The assertions are the overview targets (login p95 < 250 ms, refresh and tenant switch p95 < 50 ms, audit search
p95 < 500 ms, explain p95 < 15 ms, failed requests < 1 %); pass `-Plt.assert=false` to record without failing.
The data set's id scheme (deterministic UUIDs, user-to-account and user-to-tenant mapping) is documented in
`load-test/src/main/java/com/acme/iam/loadtest/LoadIds.java`; generated rows are recognisable by the e-mail domain
`lt.example.test`, the account slug prefix `lt-` and the audit `source` `LOADTEST`.

`./gradlew build` compiles the generator and the simulations (so they cannot rot) but runs neither: the module has no
tests and nothing is wired to `test` or `check`.
