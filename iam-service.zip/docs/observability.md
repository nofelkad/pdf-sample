# Observability

How to see what iam-service (and the iam-client starter inside applications) is doing: meters, health groups, the
Grafana dashboard and the alerts worth setting. Spec task P1-11.5. Logs are JSON on stdout (`plain-logs` profile for a
human-readable console); every log line and every audit row carries the request id (`X-Request-Id`).

## Endpoints

Ruling R36 (Task 9): actuator runs on the **management port** (`management.server.port`, env `IAM_MANAGEMENT_PORT`,
default **8081**), without authentication. **Restrict that port to the monitoring/cluster network** (no public ingress;
Kubernetes NetworkPolicy or a security group). The application port (8080) answers only the two probes
(`HealthProbesController`, status-only body); every other `/actuator/**` path is 404 there.

| Endpoint | Port | What | Access |
|---|---|---|---|
| `/actuator/prometheus` | management | Prometheus text exposition of every meter below plus the JVM, Hikari, Tomcat and HTTP server defaults | Open (no credentials) by default; `iam.observability.metrics-public=false` turns it into "authenticated", which no scraper can satisfy. The meters hold no personal data (tags are outcome, reason code, operation). |
| `/actuator/health`, `/actuator/info` | management | Aggregate: database, disk, ping, application states | Open |
| `/actuator/health/liveness` | both | The process only (`livenessState`). Restart the instance when this fails; a database or IAM problem must not restart it | Open |
| `/actuator/health/readiness` | both | May the instance take traffic: `readinessState`, `db`, `revocationFreshness`, `signingKey` | Open, HTTP 503 when not ready |

Every meter carries the tag `application="iam-service"` (`management.metrics.tags.application`); Prometheus adds
`instance`.

### Readiness details

| Contributor | UP when | Otherwise |
|---|---|---|
| `db` | the datasource answers (Boot's indicator) | `DOWN` |
| `revocationFreshness` | the revocation poller completed a poll (startup window or cursor and every page) within `iam.observability.revocation-stale-after` (default `PT30S`, fifteen poll intervals); also false before the first poll | `NOT_READY` |
| `signingKey` | an ACTIVE signing key is loaded (no token can be issued without one) | `NOT_READY` |

`NOT_READY` is a custom status that Spring Boot's default status order does not rank, so it never changes the aggregate
`/actuator/health` or `liveness`; only the `readiness` group ranks it (`management.endpoint.health.group.readiness.status`
in `application.yml`) and answers 503. A load balancer or Kubernetes `readinessProbe` should use
`/actuator/health/readiness`; a `livenessProbe` `/actuator/health/liveness`.

## Meters of iam-service

Micrometer names (dots) become Prometheus names (underscores, unit and `_total` suffixes). Timers and the summary
publish client-side percentiles (`quantile="0.5|0.95|0.99"`, sliding window of about two minutes, per instance:
they cannot be averaged across instances, so the dashboard shows one line per `instance`), plus `_count`, `_sum`
and `_max`. All meters exist, at zero, from the first scrape.

| Meter | Prometheus series | Type | Tags | Meaning |
|---|---|---|---|---|
| `iam.auth.logins` | `iam_auth_logins_total` | counter | `outcome` = `success`\|`failure`; `reason` = `ok` for success; for failures `unknown_user`, `invalid_password`, `locked`, `account_selection_required`, `user_inactive`, `account_inactive`, `tenant_inactive`, `membership_inactive`, `other` | One per login attempt that reached the login service, counted when its audit event commits (so it always matches `auth.login.*` in the audit log). Requests rejected by the rate limiter (429) never reach it, see `auth.rate_limited` in the audit log |
| `iam.auth.lockouts` | `iam_auth_lockouts_total` | counter | | A failed login that applied the account lock (5th failure, `iam.auth.lockout.max-attempts`) |
| `iam.auth.refresh.reuse_detected` | `iam_auth_refresh_reuse_detected_total` | counter | | A rotated-out refresh token was presented again; its session was revoked. A burst means token theft or a client bug |
| `iam.auth.login.duration` | `iam_auth_login_duration_seconds{...}` | timer | `outcome` = `success`\|`error` (`error` = the call threw: 401, 409 ...) | `LoginService.login` latency, Argon2 dominates. Target p95 < 250 ms |
| `iam.auth.refresh.duration` | `iam_auth_refresh_duration_seconds` | timer | `outcome` | `SessionService.refresh`. Target p95 < 50 ms |
| `iam.auth.tenant_switch.duration` | `iam_auth_tenant_switch_duration_seconds` | timer | `outcome` | `SessionService.switchTenant`. Target p95 < 50 ms |
| `iam.permission.resolve.duration` | `iam_permission_resolve_duration_seconds` | timer | `op` = `resolve`\|`explain`; `outcome` | `PermissionResolver.resolve` (runs on login, refresh, tenant switch) and `explain` (`/api/users/{id}/effective-permissions`). Target p95 < 15 ms for a user with 20 assignments |
| `iam.revocation.lag` | `iam_revocation_lag_seconds` | gauge | | When the poller applied new revocation entries: now minus `created_at` of the newest one, fixed at that moment (the time a revocation needed to reach this instance, it does not grow while nothing is revoked; 0 until the first entry created after startup). Entries created before this instance started (the startup replay of the last 20 minutes) are ignored, otherwise every restart would show the age of old history. `created_at` is the start of the revoking transaction. Target: revocation reaches every instance within 5 s |
| `iam.revocation.poll.age` | `iam_revocation_poll_age_seconds` | gauge | | Seconds since the poller last read the feed successfully (since startup when never); any single successful read resets it. The readiness check `revocationFreshness` does **not** use this gauge: it uses `RevocationPoller.lastSuccessfulPoll()`, set only when a whole poll (startup window or cursor, and every page) completed, so the gauge can be young while readiness is still `NOT_READY` (for example a startup poll that failed after its first page) |
| `iam.revocation.poll.failures` | `iam_revocation_poll_failures_total` | counter | | Feed reads of the poller that failed (it logs and retries every 2 s) |
| `iam.audit.ingest.lag` | `iam_audit_ingest_lag_seconds{quantile}`, `_count`, `_sum`, `_max` | distribution summary (seconds) | | For each event of `POST /internal/audit/events` that was not rejected (duplicates of a retried batch included): `received - occurredAt`. Growing percentiles mean application relays are backing up |
| `iam.auth.password_reset.send_timeouts` | `iam_auth_password_reset_send_timeouts_total` | counter | | A reset mail whose send hit `iam.auth.mail-executor.send-timeout` (30 s) and was cancelled. Also a WARN log line, which carries no address or token |
| `iam.auth.password_reset.dropped` | `iam_auth_password_reset_dropped_total` | counter | | Reset requests dropped because the mail queue was full (existing meter) |
| `iam.notification.invitations.sent` | `iam_notification_invitations_sent_total` | counter | | Invitation emails handed to the notification adapter without error (`InvitationMailer`, final review I2) |
| `iam.notification.invitations.failed` | `iam_notification_invitations_failed_total` | counter | | Invitation sends that threw (mail server refused, adapter error); not retried |
| `iam.notification.invitations.send_timeouts` | `iam_notification_invitations_send_timeouts_total` | counter | | Invitation sends cancelled after `iam.notification.executor.send-timeout` (30 s) |
| `iam.notification.invitations.dropped` | `iam_notification_invitations_dropped_total` | counter | | Invitations dropped because the send queue (`iam.notification.executor.queue-capacity`) was full; re-send them |
| `iam.notification.invitations.queued` | `iam_notification_invitations_queued` | gauge | | Invitations waiting to be sent on this instance |
| `iam.audit.partitions.months_ahead` | `iam_audit_partitions_months_ahead` | gauge | | Existing `audit_event` partitions after the current month; expected 3 (existing meter). See [audit partition missing](runbooks/audit-partition-missing.md) |

How they are fed (no business code was changed): the login, lockout and reuse counters listen to the `auth.*` audit
events written through `AuditWriter`; the timers wrap `LoginService.login`, `SessionService.refresh/switchTenant`,
`PermissionResolver.resolve/explain`; the audit lag wraps `AuditIngestService.ingest`; the revocation meters observe the
two feed reads of `RevocationPoller` (`RevocationService.since/startCursor` called from `RevocationPoller.poll`).
The only edit inside an existing method is one counter increment in `PasswordResetMailer` (the timeout catch block).
The code is in `com.acme.iam.observability`; `AuthMetricsIT`, `ServiceMetricsIT` and `PrometheusEndpointIT` fail when a
rename or move breaks a pointcut.

## Meters of the iam-client starter (in every application)

Registered automatically when the application has a Micrometer registry (Spring Boot Actuator); they read the
application's own database and poller.

| Meter | Prometheus series | Type | Meaning |
|---|---|---|---|
| `iam.client.audit.outbox.depth` | `iam_client_audit_outbox_depth` | gauge | Audit events in `iam_audit_outbox` that IAM has not acknowledged. Near 0 when healthy; climbs while IAM is unreachable or rejecting batches |
| `iam.client.audit.outbox.oldest.age` | `iam_client_audit_outbox_oldest_age_seconds` | gauge | Age of the oldest of them; 0 when the outbox is empty. The lag of the application's audit trail |
| `iam.client.audit.relay.failures` | `iam_client_audit_relay_failures` | gauge | Consecutive failed relay runs (the relay backs off to `iam.client.audit.relay.max-backoff`) |
| `iam.client.revocation.poll.age` | `iam_client_revocation_poll_age_seconds` | gauge | Seconds since the application's poller read IAM's feed successfully; NaN before the first success. Above `iam.client.revocation.stale-after` (60 s) the application is not seeing revocations |

The outbox gauges share one `SELECT count(*), min(created_at)` cached for `iam.client.metrics.outbox-cache-ttl`
(default `PT5S`).

## Dashboard

`docs/dashboards/iam-service.json` is a Grafana dashboard (schema 39, Prometheus datasource variable `DS_PROMETHEUS`,
`instance` filter) with a panel for every meter above: logins by outcome and reason, lockouts and
refresh-token reuse, login/refresh/tenant-switch latency, resolver latency, revocation lag, poll age and failures, audit
ingest lag, password reset timeouts and drops, the partition horizon, and the iam-client outbox depth and age. Import it
through Grafana (Dashboards, New, Import) or provision it:

```yaml
# grafana/provisioning/dashboards/iam.yml
apiVersion: 1
providers:
  - name: iam
    type: file
    options: { path: /var/lib/grafana/dashboards/iam }   # put iam-service.json here
```

Prometheus scrape job:

```yaml
scrape_configs:
  - job_name: iam-service
    metrics_path: /actuator/prometheus
    static_configs: [{ targets: ["iam-1:8081", "iam-2:8081"] }]   # management port (R36)
```

## Suggested alerts

| Alert | Expression | Why |
|---|---|---|
| Audit partitions running out | `iam_audit_partitions_months_ahead < 2` for 10 m | Inserts fail when the month's partition is missing: [runbook](runbooks/audit-partition-missing.md) |
| Revocations not applied | `iam_revocation_poll_age_seconds > 30` for 1 m, or `increase(iam_revocation_poll_failures_total[5m]) > 5` | Revoked tokens stay valid on that instance |
| Revocation slow | `iam_revocation_lag_seconds > 10` for 1 m (poll interval 2 s plus margin), together with the poll-age alert above | Revocation target is 5 s across instances; 10 s leaves room for the 2 s poll interval and a long revoking transaction |
| Instance not ready | `probe_success{job="iam-readiness"} == 0` or Kubernetes readiness | |
| Login latency | `iam_auth_login_duration_seconds{quantile="0.95",outcome="success"} > 0.25` for 10 m | Overview target |
| Refresh latency | `iam_auth_refresh_duration_seconds{quantile="0.95",outcome="success"} > 0.05` for 10 m | Overview target |
| Resolver latency | `iam_permission_resolve_duration_seconds{quantile="0.95",op="resolve",outcome="success"} > 0.015` for 10 m | Overview target |
| Lockout or reuse spike | `increase(iam_auth_lockouts_total[10m]) > 20` or `increase(iam_auth_refresh_reuse_detected_total[10m]) > 5` | Credential stuffing, token theft |
| Audit ingest lag | `iam_audit_ingest_lag_seconds{quantile="0.95"} > 300` | Applications' relays are behind |
| Mail trouble | `increase(iam_auth_password_reset_send_timeouts_total[15m]) > 0` or `..._dropped_total` | Password reset mails are not going out |
| Application audit backlog (iam-client) | `iam_client_audit_outbox_oldest_age_seconds > 300` | The application's events are not reaching IAM |
| Application blind to revocations (iam-client) | `iam_client_revocation_poll_age_seconds > 60` | |
