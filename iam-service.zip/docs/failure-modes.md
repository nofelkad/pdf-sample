# Failure modes — Phase 1 (P1-11.4)

Task 9, October 2026. What happens when IAM restarts, when PostgreSQL goes away and when clocks drift, as observed in
tests, and what is **not** handled. Observed timings come from the `E2E-OBSERVED` lines the E2E suite prints
(`e2e-tests/build/test-results/test/*.xml`, system-out) on a laptop (Docker Desktop, macOS), one run.

| Scenario | Test |
|---|---|
| IAM restart, in-service poller | `RevocationPollerStartupIT`; E2E `aRestartedIamInstanceRejectsEarlierRevocationsFromItsFirstRequest` |
| IAM restart, iam-client poller (sample-app) | E2E `theClientPollerKeepsItsStateAndCursorAcrossAnIamRestart` |
| PostgreSQL outage (container paused, then resumed) | E2E `aPostgresOutageFailsRequestsFastWith503AndHikariRecovers`; `DatabaseUnavailableHandlingTest`; `ConfigDefaultsTest` |
| Clock skew ±60 s on token validation | `JwtValidationHardeningIT` (service); iam-client `IamJwtDecoderTest`, `ResourceServerIT` |
| Revocation on a second instance | E2E `disablingAUser…`, `revokingARole…`, `theSampleAppRejectsARevokedToken…` |

The E2E suite runs two iam-service instances and the sample app as real processes (boot jars, no dev/test profile)
against one PostgreSQL container; see `e2e-tests/src/test/java/com/acme/iam/e2e/ExitCriteriaE2ETest.java`.

## 1. IAM restart

### In-service revocation poller

* State: `RevocationRegistry` (user → minimum session version) and its cursor live in memory only. Nothing is persisted
  per instance; the revocation feed (`revocation` table) is the source of truth.
* On start the poller loads every feed row of the last `iam.revocation.startup-lookback` (20 min, longer than the
  15 min access-token lifetime), then polls `since=<cursor>` every `iam.revocation.poll-interval` (2 s by default,
  ruling R41; the E2E suite runs with the defaults).
* **Fixed in Task 9:** the startup load ran on the poller thread after the web server was already accepting
  requests, so a restarted instance accepted tokens revoked before it started until that first asynchronous poll
  finished. It now runs synchronously in `start()`, in a lifecycle phase before the web server (like the iam-client
  poller).
* Observed: instance B stopped, user disabled through instance A, B started again: **B's first request with the old
  token is 401 `token_revoked`**.
* If that first poll fails (database unreachable at that moment), it is logged and retried on the schedule, and the
  instance is **not ready**: `revocationFreshness` in the readiness group stays `NOT_READY` (readiness 503) until a
  complete poll has succeeded (`RevocationPoller.lastSuccessfulPoll()`, Task 9 fix round 1), so a load balancer sends
  it no traffic. Clients that bypass readiness (direct calls to the instance) are not protected: the instance still
  answers. `RevocationPollerReadinessTest`.

### iam-client poller (sample-app)

* State: the client's registry and cursor live in the application's memory; IAM's restart does not touch them.
* While IAM is down the poller logs one WARN (then every 12th failure), keeps the last known state and the cursor, and
  retries on every tick (`RevocationHealthIndicator` reports the staleness). Tokens revoked before the outage stay
  rejected throughout.
* Observed: iam-a stopped for about 4 s, then started on the same port; a user disabled after the restart was
  rejected by the sample app within the 5 s target. The poller resumed with `since=<cursor>` (no reload, no gap).
* The app's audit relay backs off (exponential, `audit.relay.max-backoff`) and keeps every event in its outbox; after
  the restart the outbox drains (Task 8's "kill IAM 10 min → no event loss" test covers long outages).

### Revocation latency

Ruling R41: both pollers default to **2 s** (`iam.revocation.poll-interval`, `iam.client.revocation.poll-interval`),
so the worst case (interval + one indexed query `revocation.id > cursor`, or + one HTTP round trip) stays well inside the
5 s target. The E2E suite runs with these defaults (observed values below are one run; they depend on where in the
poll cycle the change lands, so anything between 0 and the interval plus the query is expected).

| Path | Default interval | Observed (E2E) | Worst case |
|---|---|---|---|
| user disabled on iam-a → rejected by iam-b | 2 s | 0.1 s | poll interval + one feed query |
| role assignment revoked on iam-a → rejected by iam-b | 2 s | 0.4 s | same |
| user disabled → rejected by the sample app | 2 s | 0.4 s | client poll interval + HTTP round trip |
| after an iam-a restart: user disabled → rejected by the sample app | 2 s | 1.6 s | same |

## 2. PostgreSQL outage

Settings (Task 9, `application.yml`):

| Setting | Value | Effect |
|---|---|---|
| `spring.datasource.hikari.connection-timeout` | 5000 ms | a request waits at most 5 s for a connection (was Hikari's 30 s default) |
| `spring.datasource.hikari.validation-timeout` | 2000 ms | a pooled connection that does not answer the validation is evicted |
| pgjdbc `connectTimeout` | 5 s | a new connection to an unreachable host fails within 5 s |
| pgjdbc `socketTimeout` | 30 s | a query waiting on a silent server fails after 30 s (was: wait forever) |
| pgjdbc `tcpKeepAlive` | true | dead peers are detected on idle connections |

Errors (`GlobalExceptionHandler`): `CannotCreateTransactionException`, `DataAccessResourceFailureException` (includes
`CannotGetJdbcConnectionException` and SQLSTATE class 08 I/O errors) and `QueryTimeoutException` are answered **503**
`application/problem+json` with `code=database_unavailable`, `Retry-After: 5` and no driver detail. Before Task 9 they
were 500 `internal_error` after up to 30 s.

Observed in the E2E suite (container paused with `docker pause`, i.e. the server stops answering without closing TCP
connections, which is how a network partition or a frozen primary looks):

* A request arriving after the pool's connections were idle for more than 0.5 s: Hikari validates the connection,
  the validation times out, a new connection cannot be opened, and the request is answered **503
  `database_unavailable`** after **6.0 s** (validation 2 s + a failed new connection within the 5 s pool timeout;
  < 15 s asserted).
* `GET /.well-known/jwks.json` keeps answering 200 (keys are in memory), so **token validation keeps working**
  everywhere (iam-service and every iam-client application): endpoints that do not touch the database (for example the
  sample app's authorization and revocation checks) are unaffected.
* After `docker unpause` Hikari replaces the broken connections (logged as "Failed to validate connection") and the
  next request is 200 (observed: the first poll after unpause, within 15 ms); the second instance recovers the same way. No restart is needed.
* Background work during the outage: the revocation poller, key refresh and jobs log a WARN/ERROR per attempt and
  retry on their next tick; ShedLock-guarded jobs simply do not run.

**Not handled / known limits:**

* A request that is **already executing** a query when the server freezes, or that borrows a connection used in the
  last 0.5 s (Hikari skips validation then), waits for the 30 s `socketTimeout` before it fails (also 503). There is no
  per-statement timeout (`statement_timeout`), because exports, bulk revocations and partition maintenance can
  legitimately run longer than a request should.
* Writes in flight when the connection breaks are rolled back by PostgreSQL; the client sees 503 and must retry. The
  admin API has no idempotency keys, so a retried `POST` (for example an invitation) may meet `409 user_exists` if the
  first attempt did commit just before the failure.
* A PostgreSQL **failover to a new primary** is the same as an outage followed by recovery only if the JDBC URL follows
  the primary (DNS/VIP, or a multi-host URL with `targetServerType=primary`); that is deployment configuration and is not
  tested here (single container).
* Login and refresh need the database: during an outage nobody can log in or refresh, and access tokens expire after
  15 min. Existing access tokens keep working in applications for their remaining lifetime.

## 3. Clock skew

* Token validation (iam-service `JwtConfig` and iam-client) checks `exp` and `nbf` with
  `iam.security.clock-skew` / `iam.client.clock-skew` = **60 s**; `iat` is not checked. Observed
  (`JwtValidationHardeningIT`): a token from an issuer 50 s ahead (`nbf`/`iat` in the future) is accepted, 90 s ahead is
  401; a token that expired 50 s ago by the validator's clock is accepted, 70 s ago is 401.
* Consequence: with ±60 s of drift between instances, an access token can be used up to 60 s past its `exp`; revocation
  (session version) is unaffected by clocks.
* Revocation registry entries are evicted by the validating instance's own clock (1 h / 20 min), far beyond any
  token lifetime, so skew does not shorten revocation.
* ShedLock uses database time (`usingDbTime()`) in the sample app; iam-service jobs use ShedLock's JDBC provider with
  `lockAtMostFor`, so ±60 s skew can shift when a job runs, not whether two instances run it at once.
* **Not handled:** audit ingest rejects events whose `occurredAt` is more than 5 min in the future
  (`occurred_at_out_of_range`, not retried by the relay): an application whose clock is more than 5 min fast loses
  those events. Keep hosts NTP-synchronised; ±60 s is fine.

## 4. Other observations

* Audit ingest de-duplicates on `(occurred_at, event_id)` (the table is partitioned by `occurred_at`). The relay
  re-sends the stored payload byte for byte, so retries de-duplicate; a client that re-creates an event with the same id
  but a new timestamp would store it twice. The relay's "every event accounted for" rule holds against the real
  service: `accepted + duplicates + rejected == batch` for a batch with a duplicate and an invalid event, and again when
  the whole batch is retried (E2E `theRelayCannotWedgeIamAccountsForEveryEventOfABatch`).
* Deadlocks (SQLSTATE 40P01) and serialization failures (40001) between legitimate concurrent admin writes are retried
  up to three times by `@RetryOnDeadlock` (`DeadlockRetryIT`); after that the caller gets 500 and may retry.

## 5. Mail server (SMTP) slow or down

Final review I2. Invitation and password-reset emails never run on a request thread or hold a database connection:

| Mail | Queued by | Executor (`threads` / `queue-capacity` / `send-timeout`) | Metrics |
|---|---|---|---|
| Invitation (invite, resend, account bootstrap, bulk invite: one task per row) | `InvitationMailer`, after commit | `iam.notification.executor.*`: 2 / 10000 / 30 s | `iam.notification.invitations.{sent,failed,send_timeouts,dropped}`, gauge `iam.notification.invitations.queued` |
| Password reset | `PasswordResetMailer`, after commit (R31) | `iam.auth.mail-executor.*`: 1 / 1000 / 30 s | `iam.auth.password_reset.{dropped,send_timeouts}` |

Before the fix an invitation was sent synchronously in `afterCommit`, while Spring still held the request's pooled
connection: an SMTP brownout (each send waiting on `spring.mail` timeouts) pinned one connection per invite, a 5,000-row
bulk invite pinned one for the whole run, and the Hikari pool (and with it every request: 503) was exhausted.

Behaviour now (`InvitationMailIsolationIT`, `InvitationMailerTest`):

* **Mail server hangs:** the invite answers 201 at once and holds no connection; the send is cancelled after
  `send-timeout` (counted in `..._send_timeouts`, WARN without address or token) and the worker moves to the next one.
* **Mail server refuses:** the send fails (counted in `iam.notification.invitations.failed`); no retry.
* **Queue full** (a long outage plus bulk invites): new invitations are **dropped** (counted in `..._dropped`). The users
  exist and stay `INVITED`; an admin re-sends with `POST /api/users/{id}/invitation/resend` (bulk: one call per user).
* **Instance stops:** queued, unsent invitations are lost (count logged at shutdown). Delivery is at most once and
  in memory; there is no outbox for mail in Phase 1.
* Alert on `rate(iam_notification_invitations_failed_total[5m]) + rate(..._send_timeouts_total[5m]) > 0` and on any
  `..._dropped_total` increase.

## 6. Client IP behind a load balancer

Final review I3. The per-IP rate limits (`iam.auth.rate-limit.per-ip`, 10/min on login, forgot and reset;
`refresh-per-ip`, 60/min) and the audit `actor_ip` use the client IP from `ClientInfoResolver`: the TCP peer, unless
the peer is a **trusted proxy** (`iam.security.trusted-proxies`, exact addresses or CIDR ranges such as `10.0.0.0/8`),
in which case the right-most `X-Forwarded-For` entry that is not itself a trusted proxy (ruling R35).

* **Misconfigured (no trusted proxies behind a load balancer):** every request seems to come from the load balancer's
  address, so the whole user population shares one 10/min login bucket (logins fail with 429 after the tenth per
  minute), and every audit row shows the load balancer's IP. iam-service logs a startup WARN
  (`iam.security.trusted-proxies is empty`) in every profile other than dev/local/test.
* **Over-broad (a CIDR that covers client networks):** clients inside it can choose their own `X-Forwarded-For` and
  dodge per-IP limits. List only the load balancer / ingress ranges.
* See [deployment.md](deployment.md#client-ip-and-rate-limits).
