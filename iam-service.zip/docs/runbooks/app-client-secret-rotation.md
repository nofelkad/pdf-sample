# Runbook: rotate an application client secret

Applications call IAM's `/internal/*` API (revocation feed, audit ingest, manifest upload) with a short-lived app token
that they obtain from `POST /internal/token` using HTTP Basic `clientId:clientSecret` (iam-client:
`iam.client.client-id` / `iam.client.client-secret`). The secret is 32 random bytes shown **once** at registration; only
its SHA-256 is stored.

**Rotate in place (Task 9, ruling R39):**

```
curl -X POST -H "Authorization: Bearer $PLATFORM_TOKEN" http://iam:8080/api/platform/app-clients/$ID/rotate-secret
# 200 {id, clientId, productCode, status, createdAt, clientSecret}   (Cache-Control: no-store; shown once)
```

Platform operators only. The old secret stops working **immediately** (the stored hash is replaced); app tokens already
issued stay valid until they expire (10 min). The application cannot obtain new tokens until it runs with the new
secret, so deploy the new secret within that window, or accept a short gap in revocation polling and audit relay (the
outbox keeps events; the revocation registry keeps its last state). Audited `iam.app_client.secret_rotated`.

**Zero-downtime alternative:** *register a second client, move the application, delete the first*; the application
and the new client coexist. The cost: the new client has a new id, and audit rows written on behalf of the application
carry `source = 'app:<clientId>'` and `metadata.client_id` of whichever client the application used at the time (the
`source` column of ingested application events stays the product code).

## Symptoms (when to run it)

* Scheduled rotation, a departing engineer who knew the secret, the secret appeared in a log, chat or repository.
* After a leak also check the audit log for use of the old client: `auth.app_client.token` (SUCCESS, with `jti`) and
  `auth.app_client.failed` (reason `bad_secret`, `unknown_client`, `disabled`) with `metadata.client_id = '<old>'`.

## Diagnosis

```
curl -s -H "Authorization: Bearer $PLATFORM_TOKEN" 'http://iam:8080/api/platform/app-clients?limit=200' | jq '.items[]'
```
(`platform.account.manage`.) Note the client's `clientId` and `productCode`; the new client must use the **same
product code** (it becomes `prd` in the app token and the `source` of ingested events).

## Steps

1. **Register the new client** (response carries `clientSecret` once, with `Cache-Control: no-store`; put it straight
   into the secret store, not into chat or a shell history):

   ```
   curl -s -X POST http://iam:8080/api/platform/app-clients \
        -H "Authorization: Bearer $PLATFORM_TOKEN" -H 'Content-Type: application/json' \
        -d '{"clientId":"billing-app-2","productCode":"BILLING"}' | jq -r '.clientSecret'
   ```
   `clientId` must match `[a-z0-9][a-z0-9._-]{2,63}`, `productCode` `[A-Z][A-Z0-9_]{1,31}`. 409 `app_client_exists`: pick
   another id (a counter suffix works well: `billing-app`, `billing-app-2`, ...).
2. **Deploy the application** with the new `IAM_CLIENT_ID` / `IAM_CLIENT_SECRET` (rolling restart; instances on the old
   and the new client work side by side).
3. Wait until **no instance uses the old client**: the old client's `auth.app_client.token` events stop (an application
   renews its token every 10 minutes, so wait at least 15 minutes after the last instance restarted):

   ```sql
   SELECT max(occurred_at) FROM audit_event
    WHERE action = 'auth.app_client.token' AND metadata->>'client_id' = 'billing-app';
   ```
4. **Delete the old client** (204, or 404 `app_client_not_found`):

   ```
   curl -s -X DELETE -H "Authorization: Bearer $PLATFORM_TOKEN" http://iam:8080/api/platform/app-clients/$OLD_ID
   ```
   App tokens it already issued stay valid until they expire (`iam.security.app-token-ttl`, 10 minutes). For an
   **immediate cut-off after a leak** disable the old client first, before step 1 or 2 if need be:

   ```sql
   UPDATE app_client SET status = 'DISABLED' WHERE client_id = 'billing-app';   -- token requests now fail: 401 invalid_client
   ```
   The already issued token still works for up to 10 minutes; there is no per-token revocation for application tokens.

## Verification

1. `POST /internal/token` with the new credentials returns 200 and `token_type: Bearer`:

   ```
   curl -s -u 'billing-app-2:<secret>' -d grant_type=client_credentials http://iam:8080/internal/token | jq '{token_type, expires_in}'
   ```
   (`-u` sends HTTP Basic; the body is `application/x-www-form-urlencoded`.)
2. The application is healthy: `/actuator/health` UP, `iam_client_revocation_poll_age_seconds` small,
   `iam_client_audit_outbox_depth` near 0 and `iam_client_audit_relay_failures` 0 (see
   [observability](../observability.md)); IAM shows fresh `auth.app_client.token` events for the new `client_id`.
3. The old credentials fail: the same `curl` with the old id returns `401 invalid_client`
   (`WWW-Authenticate: Basic realm="iam"`), and `auth.app_client.failed` is audited.

## Rollback

* Before step 4: put the old `IAM_CLIENT_ID` / `IAM_CLIENT_SECRET` back and redeploy; the old client still works.
* After step 4 the old secret is gone for good (it was never stored in clear text and cannot be recovered). Register
  another client (step 1) and deploy it. An application that cannot authenticate keeps serving users from its last known
  state, buffers audit events in its outbox (nothing is lost) and reports `iam_client_revocation_poll_age_seconds`
  growing: fix forward quickly.
* A client disabled by mistake: `UPDATE app_client SET status = 'ACTIVE' WHERE client_id = '...'`.
