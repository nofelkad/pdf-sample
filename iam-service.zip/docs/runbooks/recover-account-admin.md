# Runbook: recover an account's admin

Ruling R43 (final review I5). A customer account must always keep at least one **effective admin**: an ACTIVE user
holding the IAM SYSTEM role `Account Admin` at ACCOUNT scope **without expiry**, whose primary tenant is ACTIVE. IAM
enforces that on every path it controls:

* removing the last such grant or disabling/deprovisioning its holder is `409 last_admin` (I7; grants with an
  `expiresAt` do not count, because they would leave the account without an admin once they expire);
* suspending or archiving a tenant that is the primary tenant of every remaining effective admin is `409 last_admin`
  (login, refresh and tenant switch are refused while the primary tenant is not ACTIVE).

An account can still end up without a usable admin: the only admin left the company and was disabled before I7 counted
only permanent grants, an admin's grant expired, the admins forgot their passwords and their mailbox is gone, or the
data was changed by SQL. Then a **platform operator** recovers it with one call.

## Symptoms

* The customer reports that nobody can administer the account: every login of a former admin fails, or succeeds
  without `iam.*` permissions.
* `GET /api/platform/accounts/{id}` shows the account ACTIVE, but no one can reach `/api/users` for it.

## Diagnosis

```sql
-- as iam_app: the account's admins and why each one is (not) usable
SELECT u.id, u.email, u.status, ra.expires_at, t.id AS primary_tenant, t.status AS primary_tenant_status,
       m.status AS primary_membership
FROM role_assignment ra
JOIN role r ON r.id = ra.role_id AND r.type = 'SYSTEM' AND r.name = 'Account Admin'
JOIN app_user u ON u.id = ra.user_id
JOIN tenant t ON t.id = u.primary_tenant_id
LEFT JOIN user_tenant_membership m ON m.app_user = u.id AND m.tenant_id = u.primary_tenant_id
WHERE ra.scope_type = 'ACCOUNT' AND ra.scope_id = :'account_id';

-- the account's tenants (pick an ACTIVE or SUSPENDED one; ARCHIVED cannot be used)
SELECT id, slug, status FROM tenant WHERE account_id = :'account_id' ORDER BY created_at;
```

Usable admin = `status = 'ACTIVE'`, `expires_at IS NULL`, `primary_tenant_status = 'ACTIVE'`,
`primary_membership = 'ACTIVE'`. If one exists the account is not locked out: help that person (password reset
`POST /auth/password/forgot`, [unlock](unlock-user.md)) instead.

Agree with the customer, **through a verified channel** (the contract owner, a support ticket from a known address),
which email becomes the new admin. Recovery hands full control of the account to that email.

## Steps

As a platform operator (a user of the PLATFORM account holding `platform.account.manage` at ACCOUNT scope):

```
curl -X POST http://iam:8080/api/platform/accounts/$ACCOUNT_ID/admins \
  -H "Authorization: Bearer $OPERATOR_TOKEN" -H 'Content-Type: application/json' \
  -d '{"email":"new-admin@customer.example","tenantId":"'$TENANT_ID'"}'
```

When the recovery invites (`invited: true`), the response's `activation.link` is the same link the email carries
(ruling R46): hand it to the new admin over a trusted channel if the email cannot be relied on. It is valid for 7 days
and only the newest one works.

What it does, in one transaction:

| Situation | Effect |
|---|---|
| tenant SUSPENDED | reactivated (`tenantReactivated: true`) |
| tenant ARCHIVED | `409 tenant_not_active`: pick another tenant |
| email unknown in the account | a new INVITED user with its primary membership in the tenant; invitation mailed after commit (`invited: true`, `invitationExpiresAt`) |
| existing user, ACTIVE | ACTIVE membership in the tenant; becomes the primary tenant if the current one is unusable (`primaryTenantChanged`) |
| existing user, DISABLED | as above, plus re-enabled: ACTIVE, or INVITED with a fresh invitation when it never set a password (`userReactivated: true`) |
| existing user, INVITED | as above, plus a fresh invitation (old links stop working) |
| existing user, DEPROVISIONED | `409 user_deprovisioned`: deprovisioning is final, use another email |
| account CLOSED | `409 account_closed` |
| the PLATFORM account | `409 platform_account_protected`: use [bootstrap-platform-admin](bootstrap-platform-admin.md) |

Then `Account Admin` at ACCOUNT scope, granted by the operator, without expiry (`grant`: `created`, `made_permanent`
when an expiring grant existed, or `existing`). Nothing is revoked. The account's own status is not changed: reactivate
a SUSPENDED account separately (`POST /api/platform/accounts/{id}/reactivate`) if that is also the problem.

With `iam.notification.mode=log` the invitation is not delivered and its link is not printed (only the bootstrap CLI
prints links, ruling R23): configure SMTP first ([deployment.md](../deployment.md#notifications-invitations-password-resets)),
or recover with an existing user that already has a password (it is re-enabled without needing a mail).

## Verification

* Response `200` with `userId`; the user accepts the invitation (or logs in) and `GET /api/me` shows `iam.*`
  permissions in the recovered tenant.
* Audit, in the recovered account (visible to its own auditors and to `GET /api/audit/events?accountId=...` for
  operators): one `iam.account.admin_recovered` event (actor = the operator, metadata `invited`, `tenant_reactivated`,
  `user_reactivated`, `primary_tenant_changed`, `grant`), plus the row events (`iam.tenant.update`,
  `iam.app_user.insert|update`, `iam.user_tenant_membership.*`, `iam.role_assignment.insert|update`).
* The diagnosis query shows a usable admin.

## Rollback

Recovery only adds access. To undo it, have the (now working) customer admin, or an operator through SQL, remove the
grant: `DELETE /api/assignments/{id}` as an Account Admin (I7 still applies: the account must keep another effective
admin), then disable the user if needed. Re-suspend the tenant only if another admin can still log in elsewhere.
