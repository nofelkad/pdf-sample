# Runbook: unlock a user

A user is locked after `iam.auth.lockout.max-attempts` (5) consecutive failed logins, for `iam.auth.lockout.duration`
(15 minutes): `app_user.locked_until` is set and `failed_logins` goes back to 0. While `locked_until` is in the future
every login of that user answers the same `401 invalid_credentials` as a wrong password, even with the right one (so the
lock cannot be probed), and the audit event says `reason: locked`.

## Unlock endpoint (Task 9, ruling R38)

```
curl -X POST -H "Authorization: Bearer $TOKEN" http://iam:8080/api/users/$USER_ID/unlock
# 200 UserView
```

Needs `iam.user.manage` (at account scope, or a tenant-local target: R28). Clears `failed_logins` and `locked_until`
through `UserCredentialService` and writes `auth.unlocked` (metadata `was_locked`). It does not change the password: if
the lock came from a guessing attack, reset the password instead or as well.

The other ways out remain:

1. **Wait.** The lock expires on its own after 15 minutes (nothing to run).
2. **The user resets their password**: `POST /auth/password/forgot`, then `POST /auth/password/reset` with the mailed
   token. A successful reset (and a password change, and accepting an invitation) clears the lock
   (`failed_logins = 0`, `locked_until = NULL`). Forgot/reset do not need a login, so a locked user can use them.
3. **Operator SQL**, below, when the user cannot wait and cannot use mail.


## Symptoms

* The user reports "invalid email or password" with the right password, and has recently typed a wrong one.
* Metric `iam_auth_logins_total{reason="locked"}` rises for them; `iam_auth_lockouts_total` counted the lock itself.
* Audit (as the account's auditor, `GET /api/audit/events?action=auth.locked&from=...&to=...`, or SQL):
  `auth.locked` (DENIED) once when the lock was applied, then `auth.login.failed` with `metadata.reason = 'locked'`.

## Diagnosis

```sql
-- as iam_app
SELECT id, email, status, failed_logins, locked_until, locked_until > now() AS locked_now, last_login_at
FROM app_user WHERE account_id = :'account_id' AND email = :'email';

SELECT occurred_at, action, outcome, actor_ip, metadata->>'reason' AS reason
FROM audit_event
WHERE target_type = 'app_user' AND target_id = :'user_id'::text
  AND action IN ('auth.locked', 'auth.login.failed', 'auth.login.success')
  AND occurred_at > now() - interval '1 day'
ORDER BY occurred_at DESC LIMIT 20;
```
Check the IPs before unlocking: many failures from foreign addresses mean a guessing attack, in which case force a
password reset (`forgot`) instead of just unlocking, and consider [force logout](force-logout.md).

## Steps (SQL)

Only `app_user.failed_logins` and `locked_until` change; the row trigger ignores those columns, so write the audit
event yourself. One transaction, as `iam_app`, with psql variables (`-v user_id=<uuid> -v ticket=INC-123`; the
`:'name'` form quotes the value):

```sql
BEGIN;
UPDATE app_user SET failed_logins = 0, locked_until = NULL
 WHERE id = :'user_id' AND status = 'ACTIVE';              -- expect UPDATE 1
INSERT INTO audit_event (event_id, occurred_at, source, actor_type, action, target_type, target_id, outcome, metadata)
SELECT gen_random_uuid(), now(), 'OPS', 'SYSTEM', 'ops.user.unlock', 'app_user', id::text, 'SUCCESS',
       jsonb_build_object('ticket', :'ticket', 'by', current_user)
  FROM app_user WHERE id = :'user_id';
COMMIT;
```
Do not touch `version` (the application does not use it for login bookkeeping, and bumping it would make a concurrent
profile update fail with 409 `concurrent_modification`). An `INVITED` or `DISABLED` user is not locked, it cannot log in
for another reason (`user_inactive` in the audit event): do not "unlock" it, fix its status.

## Verification

1. `SELECT failed_logins, locked_until FROM app_user WHERE id = :'user_id';` shows `0` and NULL.
2. The user logs in: `iam_auth_logins_total{outcome="success"}` rises and `auth.login.success` is in the audit log.
3. If the user is immediately locked again, the cause is a client that keeps sending an old password (a mobile app, a
   mail client, a script): find it from `actor_ip` / `user_agent` in the `auth.login.failed` events.

## Rollback

Re-lock manually: `UPDATE app_user SET locked_until = now() + interval '15 minutes' WHERE id = :'user_id';` (and record
`ops.user.lock` the same way). There is nothing else to undo.
