# Runbook: force logout of a user or an account

Use it when a user's credentials or device are compromised, an employee leaves, or an account must be cut off at once.

## What "logged in" means here (read this first)

A session has two parts, and ending it means ending both:

| Part | Lifetime | How it ends |
|---|---|---|
| **Access token** (JWT) | 15 minutes | Revocation: `app_user.session_version` is bumped and a row `(user_id, min_sv)` is appended to the `revocation` feed. Every IAM instance polls the feed every 2 s, every application every 2 s (iam-client; ruling R41), and rejects tokens with a lower `sv` (`401 token_revoked`). **Effective within about 5 s everywhere.** |
| **Session** (`user_session`, the refresh token) | up to 12 h absolute, 30 min idle | `user_session.revoked_at` is set. Revocation of access tokens alone does **not** end it: the next `POST /auth/refresh` would mint a new access token with the new session version. |

API calls that bump the session version (all of them end by `RevocationService`, one summary event
`auth.sessions.revoked` in the audit log): `POST /auth/logout-all` (own sessions), user `disable` and `deprovision`,
account `suspend`/`close`, tenant `suspend`/`archive`, editing a role's permissions. A session whose user or account is
no longer ACTIVE is ended (`revoked_at` set, `401 session_invalid`) **when its refresh token is next presented**; one that
is never presented stays open in the table until it expires.

## Symptoms

* A stolen device or leaked refresh token, "this user must be out now", a closed account, a security incident.
* Audit: `auth.refresh` events for a user that should not have access (`SELECT ... FROM audit_event WHERE actor_user_id = :id AND action = 'auth.refresh' ORDER BY occurred_at DESC`).

## Diagnosis

```sql
-- as iam_app: what is open for this user?
SELECT id, active_tenant_id, ip, user_agent, created_at, last_seen_at, expires_at, revoked_at
FROM user_session WHERE user_id = :'user_id' ORDER BY created_at DESC;
SELECT id, session_version, status, locked_until FROM app_user WHERE id = :'user_id';
SELECT * FROM revocation WHERE user_id = :'user_id' ORDER BY id DESC LIMIT 5;   -- retained for 1 h only
```

## A. One user

1. **Force logout endpoint (Task 9, ruling R37)** — the normal way. Needs `iam.session.revoke` (Account Admin; Tenant
   Admin for users that only belong to their tenant, R28):

   ```
   curl -X POST -H "Authorization: Bearer $TOKEN" http://iam:8080/api/users/$USER_ID/sessions/revoke
   # 200 {"userId": "...", "sessionsRevoked": 2}
   ```
   Sets `revoked_at` on every open session (refresh fails at once with `session_invalid`) and revokes the access
   tokens (reason `admin_force_logout`, effective within the poll interval everywhere). Audited
   `auth.sessions.force_logout` plus `auth.sessions.revoked`. The user can log in again with their password: if the
   credentials are compromised, also disable the user or have the password reset.

The other options:

2. **The user themself**: `POST /auth/logout-all` with their access token ends every session and revokes their tokens.
3. **Disable, then enable** (needs `iam.user.manage`; 409 `last_admin` if it is the last account administrator):

   ```
   curl -X POST -H "Authorization: Bearer $TOKEN" http://iam:8080/api/users/$USER_ID/disable
   # wait until the sessions have tried to refresh, at least the access token lifetime (15 min); see the caveat
   curl -X POST -H "Authorization: Bearer $TOKEN" http://iam:8080/api/users/$USER_ID/enable
   ```
   Disabling revokes the access tokens at once (within 5 s) and makes every refresh fail with `session_invalid`, which
   ends that session. **Caveat:** a session whose refresh token is not presented while the user is disabled survives
   and works again after `enable`. Keep the user disabled for at least 30 minutes (idle timeout) before enabling, or
   use option 4. If the user must stay out (compromise, leaver), use `disable` (or `POST /api/users/{id}/deprovision`
   for good, which also removes assignments) and leave it at that.
4. **SQL fallback** (guaranteed): one transaction that ends the sessions and revokes the access tokens. Take the feed
   lock **after** the row update and write the feed row last, exactly as `RevocationService` does (the lock serialises
   feed writers so pollers cannot skip an id):

   ```sql
   BEGIN;
   UPDATE user_session SET revoked_at = now(), version = version + 1
    WHERE user_id = :'user_id' AND revoked_at IS NULL;
   WITH bumped AS (UPDATE app_user SET session_version = session_version + 1 WHERE id = :'user_id'
                   RETURNING id, session_version)
   SELECT 1 FROM bumped;                                     -- row locked and bumped first
   SELECT pg_advisory_xact_lock(441253889);                  -- RevocationService.FEED_LOCK_KEY (0x1A4D0001)
   INSERT INTO revocation (user_id, min_sv, reason)
   SELECT id, session_version, 'ops.force_logout' FROM app_user WHERE id = :'user_id';
   INSERT INTO audit_event (event_id, occurred_at, source, actor_type, action, target_type, target_id, outcome, metadata)
   VALUES (gen_random_uuid(), now(), 'OPS', 'SYSTEM', 'ops.force_logout', 'app_user', :'user_id'::text, 'SUCCESS',
           jsonb_build_object('ticket', :'ticket', 'by', current_user));
   COMMIT;
   ```
   Run it as `iam_app` (the application role: DML, plus INSERT on `audit_event`) with psql variables, e.g.
   `psql -v ON_ERROR_STOP=1 -v user_id=<uuid> -v ticket=INC-123 -f force-logout-user.sql`. One transaction per user.

## B. Every user of an account

1. **Force logout endpoint (Task 9, ruling R37)**, platform operators only (PLATFORM account, `platform.account.manage`
   at account scope):

   ```
   curl -X POST -H "Authorization: Bearer $PLATFORM_TOKEN" \
     http://iam:8080/api/platform/accounts/$ACCOUNT_ID/sessions/revoke
   # 200 {"accountId": "...", "sessionsRevoked": 17, "usersRevoked": 12}
   ```
   Ends every session of the account and revokes every user's access tokens (`revokeAccountUsers`), without blocking
   new logins. Use suspend (below) to also keep them out.
2. **API** (platform operator, `platform.account.manage`): suspend, then reactivate when appropriate:

   ```
   curl -X POST -H "Authorization: Bearer $PLATFORM_TOKEN" http://iam:8080/api/platform/accounts/$ACCOUNT_ID/suspend
   ```
   Revokes every user of the account in one transaction (batches of 5,000 rows, one `auth.sessions.revoked` event) and
   blocks logins and refreshes (`account_inactive`). Same session caveat as above. `POST .../reactivate` lifts it;
   `POST .../close` is terminal. For one tenant of an account: `POST /api/tenants/{id}/suspend` (`iam.tenant.manage`).
3. **SQL fallback** (also guarantees the sessions are gone):

   ```sql
   BEGIN;
   UPDATE user_session SET revoked_at = now(), version = version + 1
    WHERE revoked_at IS NULL AND user_id IN (SELECT id FROM app_user WHERE account_id = :'account_id');
   CREATE TEMP TABLE bumped ON COMMIT DROP AS
     WITH b AS (UPDATE app_user SET session_version = session_version + 1 WHERE account_id = :'account_id'
                RETURNING id, session_version)
     SELECT id, session_version FROM b;
   SELECT pg_advisory_xact_lock(441253889);
   INSERT INTO revocation (user_id, min_sv, reason)
   SELECT id, session_version, 'ops.force_logout_account' FROM bumped ORDER BY id;
   INSERT INTO audit_event (event_id, occurred_at, source, actor_type, action, target_type, target_id, outcome, metadata)
   VALUES (gen_random_uuid(), now(), 'OPS', 'SYSTEM', 'ops.force_logout_account', 'account', :'account_id'::text, 'SUCCESS',
           jsonb_build_object('ticket', :'ticket', 'users', (SELECT count(*) FROM bumped)));
   COMMIT;
   ```
   For accounts with tens of thousands of users the single transaction holds row locks for seconds; schedule it, or
   split by `id` ranges.

## Verification

1. The old access token is refused: `curl -i -H "Authorization: Bearer $OLD" http://iam:8080/api/me` returns
   `401` with `code: token_revoked` within about 5 s (check on every instance; applications using iam-client behave the
   same, `iam_client_revocation_poll_age_seconds` shows their poller is alive).
2. The refresh token is refused: `POST /auth/refresh` with it returns `401 invalid_refresh_token` or `session_invalid`.
3. `SELECT count(*) FROM user_session WHERE user_id = :id AND revoked_at IS NULL` is 0.
4. Audit: `auth.sessions.revoked` (API paths) or `ops.force_logout*` (SQL) for the target; metric
   `iam_revocation_lag_seconds` shows the time the instances needed to apply it.

## Rollback

Revocation is not undone: the user logs in again. Undo only the administrative state: `POST /api/users/{id}/enable`,
`POST /api/platform/accounts/{id}/reactivate`. There is nothing to restore for `user_session` rows (the user starts a
new session at login).
