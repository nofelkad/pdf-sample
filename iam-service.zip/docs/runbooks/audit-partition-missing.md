# Runbook: audit partition missing

`audit_event` is partitioned by month on `occurred_at` (`audit_event_yYYYYmMM`, one partition per UTC month, **no
default partition**). A row whose `occurred_at` falls in a month without a partition cannot be inserted. The service
keeps the current month plus three ahead in place (`audit_ensure_partitions(3)`: at startup of each instance and daily
at 01:10 UTC by `AuditPartitionJob`, ShedLock `audit-partitions`). If that stops working, the horizon shrinks by one
month per month, and on the first day of an uncovered month everything that writes audit rows fails.

## Symptoms

| What you see | Meaning |
|---|---|
| Alert on `iam_audit_partitions_months_ahead < 2` (expected 3) | Early warning, weeks before any failure |
| ERROR logs `Only N future audit_event partition(s) exist (expected 3); ingest of events beyond the last partition will be rejected...` | Same, from `AuditPartitionService` after every refresh |
| ERROR logs `audit_ensure_partitions failed; audit partitions may run out` | The daily job (or startup) could not create partitions; the exception follows |
| ERROR logs `Could not determine the audit_event partition horizon` | The partition listing itself failed (database trouble) |
| **Inserts fail**: `ERROR: no partition of relation "audit_event" found for row` (SQLSTATE 23514) in the logs and 500 `internal_error` on login, refresh, every admin write (each writes an audit row in its transaction, so the whole transaction rolls back) | The current month has no partition. Authentication is down |
| `POST /internal/audit/events` answers `rejected: occurred_at_out_of_range` for events of a month without a partition | Ingest validates the month first, so applications get rejections rather than 500s; **rejected events are dropped by iam-client, not retried** |

## Diagnosis

```sql
-- as iam_app: the partitions that exist
SELECT inhrelid::regclass AS partition,
       pg_get_expr(c.relpartbound, c.oid) AS bound
FROM pg_inherits i JOIN pg_class c ON c.oid = i.inhrelid
WHERE i.inhparent = 'public.audit_event'::regclass ORDER BY 1;
```
Compare with `date_trunc('month', now() AT TIME ZONE 'UTC')`. Why did the job not create them? Look for the ERROR log
above and for a held lock: `SELECT * FROM shedlock WHERE name = 'audit-partitions';` (`lock_until` in the future with
no instance running it means a crashed holder; it expires by itself within 10 minutes). Typical causes: the function
`audit_ensure_partitions` lost its EXECUTE grant for `iam_app`, the migrator role lost CREATE rights, a table with the
partition's name exists but is not attached (`audit_event_y2026m11` created by hand and detached), or the instances
were down over a month boundary with no restart.

## Steps

1. **Create the partitions now**, as the application role (the function is `SECURITY DEFINER`, owned by the migrator,
   so this needs no DDL rights; an advisory lock inside makes concurrent runs safe):

   ```
   psql "postgresql://iam_app:***@db:5432/iam_db" -c "SELECT audit_ensure_partitions(3);"
   ```
   It returns the number of partitions created (0 when all four exist). It covers the current month plus three ahead
   only; it cannot create past months. If you need a **past** month (late events, a restore), the migrator creates it:

   ```sql
   -- as iam_migrator
   CREATE TABLE public.audit_event_y2026m02 PARTITION OF public.audit_event
     FOR VALUES FROM ('2026-02-01 00:00:00+00') TO ('2026-03-01 00:00:00+00');
   REVOKE UPDATE, DELETE, TRUNCATE ON public.audit_event_y2026m02 FROM iam_app;   -- append-only for the app
   ```
2. If the call fails, fix the cause it names (`permission denied for function` => `GRANT EXECUTE ON FUNCTION
   audit_ensure_partitions(int) TO iam_app;` as the owner; "relation ... already exists" => the name is taken by a
   detached table: rename or attach it). Do not grant `iam_app` DDL rights.
3. Refresh the gauge without waiting for the daily job: restart one instance, or wait for the next job; the gauge is set
   after every `ensure`, and the logs say `Created N audit_event partition(s)`.
4. Check the scheduler: if the job did not run, see ShedLock above and the instance logs around 01:10 UTC.

## Verification

* `iam_audit_partitions_months_ahead` is 3 on every instance and the alert clears.
* The ERROR lines stop; login works (`POST /auth/login` returns 200), `POST /internal/audit/events` accepts events.
* The partitions are listed by the query above, each `FOR VALUES FROM (...) TO (...)` adjoining the previous one.
* Events that applications failed to deliver while the partition was missing: rejected events are logged as
  `IAM rejected audit event <id> (occurred_at_out_of_range); dropping it from the outbox` by the relay and are lost to
  IAM; the application's own database still has its business change. Events that were not yet relayed are retried
  and succeed now.

## Retention and the archive hook

Retention (`iam.audit.retention`, default `P7Y`, at least 90 days) drops a partition only once **all** of it is older
than the period **and** an `AuditArchiveHook` bean returned `true` for it. The default hook (`RefusingArchiveHook`)
logs `Audit partition ... is past retention but no archive hook is configured; keeping it` and returns `false`, so
nothing is ever dropped until an operator decides:

* **Archive, then drop:** provide an `AuditArchiveHook` bean (public SPI in `com.acme.iam.audit`) whose
  `archive(String partitionName)` copies the still-attached partition to cold storage, verifies it and returns `true`.
  The usual implementation is `pg_dump -t public.audit_event_y2019m03 --format=custom` to object storage with a
  checksum check. It must be idempotent: the same partition is offered again after a failed drop.
* **Drop without archive** (dev, or after an external archive): `iam.audit.archive.mode=none-acknowledged`.
* **By hand**, as `iam_app`: `SELECT audit_detach_partition('audit_event_y2019m03');` (detach plus drop in one
  transaction; refuses partitions that ended less than 90 days ago and names that are not partitions of `audit_event`;
  returns `false` when the partition does not exist). Archive first.
* The job runs daily at 02:40 UTC (`iam.audit.retention-cron`, ShedLock `audit-retention`) and writes
  `iam.audit.partition.dropped`.

## Rollback

Creating a partition is additive and safe to leave. To remove an empty partition created by mistake:
`SELECT audit_detach_partition('<name>')` works only for partitions ended more than 90 days ago; for a future one use
`ALTER TABLE audit_event DETACH PARTITION <name>; DROP TABLE <name>;` as the migrator, only while it is empty. A dropped
(archived) partition is restored by `pg_restore` of the dump into a table and
`ALTER TABLE audit_event ATTACH PARTITION ... FOR VALUES FROM (...) TO (...)` as the migrator.
