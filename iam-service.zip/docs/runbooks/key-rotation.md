# Runbook: rotate the JWT signing key

Access tokens and application tokens are RS256 JWTs signed with the ACTIVE key of the `signing_key` table. Keys rotate
automatically every `iam.security.key-rotation-interval` (90 days); this runbook is for a rotation you want now
(scheduled hygiene, a departing administrator, a suspected leak).

## How rotation works (so you know what to expect)

| Step | Status | When |
|---|---|---|
| New key created | `PUBLISHED`: in `/.well-known/jwks.json`, not yet signing | the command below |
| Promoted | `ACTIVE` (the previous ACTIVE becomes `PUBLISHED`, still verifies) | after `iam.security.key-publish-lead` (24 h, so every application's JWKS cache has the new key), by the hourly `KeyRotationJob` (`iam.security.key-rotation-check-interval`, ShedLock `signing-key-rotation`) |
| Previous key retired | `RETIRED`, removed from the JWKS | after the longest token lifetime + clock skew + margin (about 21 minutes) since it was demoted |

No token is invalidated by a normal rotation: tokens signed with the old key keep verifying until they expire (15 min).

## Symptoms (when to run it)

* Calendar or policy driven: nothing is wrong.
* Key suspected compromised: read "Emergency" at the end first, a normal rotation takes 24 h to start signing.
* `signingKey` readiness is `NOT_READY` or logs say "No ACTIVE signing key": that is not a rotation, see Diagnosis.

## Diagnosis

```sql
-- as iam_app or iam_migrator
SELECT kid, status, created_at, activated_at, demoted_at, retired_at FROM signing_key ORDER BY created_at DESC;
```
Exactly one `ACTIVE` row is expected (unique index `signing_key_one_active_uq`). JWKS as an application sees it:

```
curl -s http://iam:8080/.well-known/jwks.json | jq '.keys[] | {kid, alg, use}'
```
The JWKS lists every `ACTIVE` and `PUBLISHED` key. Readiness: `curl -s http://iam:8080/actuator/health/readiness`
(`signingKey` contributor).

## Steps

1. Make sure the environment has the same settings as the running service: `IAM_DB_URL`, `IAM_DB_APP_USER`,
   `IAM_DB_APP_PASSWORD`, `IAM_DB_MIGRATOR_USER`, `IAM_DB_MIGRATOR_PASSWORD`, `IAM_ISSUER`, and **`IAM_MASTER_KEY`**
   (the same value as the running instances: the private part of the key is encrypted with it).
2. Run the command once, from any host that can reach the database:

   ```
   java -jar iam-service.jar --spring.main.web-application-type=none --iam.rotate-signing-key
   ```
   `--spring.main.web-application-type=none` keeps the process from binding port 8080 (it would clash with a local
   instance and is not needed). The process publishes one new key, logs
   `Signing key rotation requested: published <kid>; exiting` and exits: code `0` on success, `1` on failure (logged
   as `Signing key rotation failed`). From a checkout:
   `./gradlew :iam-service:bootRun --args='--spring.profiles.active=local --spring.main.web-application-type=none --iam.rotate-signing-key'`
   (profile `local`: the docker-compose database passwords; `IAM_ISSUER` and `IAM_MASTER_KEY` still from the environment,
   see [local development](../local-development.md)).
   The command may start the schedulers for a moment; they are guarded by ShedLock and idempotent. Do not run it twice
   "to be sure": each run adds a key (harmless, the older never-activated one is retired later, but pointless).
3. Note the `<kid>` from the log (or take the newest `PUBLISHED` row).

## Verification

1. Within about 60 s (`iam.security.jwk-refresh-interval`) every instance lists the new key:
   `curl -s http://iam:8080/.well-known/jwks.json | jq -r '.keys[].kid'` shows the old ACTIVE kid and the new one.
   Check each instance, not only the load balancer.
2. After 24 h plus up to one hour: the new key is `ACTIVE`, the old one `PUBLISHED`; new tokens carry the new `kid`:
   `jq -R 'split(".")[0] | @base64d | fromjson' <<< "$ACCESS_TOKEN"` (log in, then decode the header).
3. About 21 minutes after that the old key is `RETIRED` and disappears from the JWKS.
4. Applications keep working throughout: iam-client caches the JWKS for `iam.client.jwks.cache-ttl` (5 m) and re-reads
   it on an unknown `kid` (at most every `min-refresh-interval`, 10 s).

## Rollback

* **Before promotion** (the new key is still `PUBLISHED`): retire it. Tokens are unaffected, nothing was signed with it.

  ```sql
  BEGIN;
  SELECT pg_advisory_xact_lock(hashtext('iam.signing_key'));   -- the lock the service uses for key changes
  UPDATE signing_key SET status = 'RETIRED', retired_at = now() WHERE kid = '<new kid>' AND status = 'PUBLISHED';
  COMMIT;
  ```
  Instances drop it from the JWKS within 60 s.
* **After promotion** (the new key is `ACTIVE` and has signed tokens): make the previous key ACTIVE again and keep the
  new one `PUBLISHED`, so tokens already signed with it still verify until they expire:

  ```sql
  BEGIN;
  SELECT pg_advisory_xact_lock(hashtext('iam.signing_key'));
  UPDATE signing_key SET status = 'PUBLISHED', demoted_at = now() WHERE kid = '<new kid>' AND status = 'ACTIVE';
  UPDATE signing_key SET status = 'ACTIVE', activated_at = now(), demoted_at = NULL, retired_at = NULL
   WHERE kid = '<old kid>';
  COMMIT;
  ```
  This also works for a key that is already `RETIRED` (its encrypted private key stays in the table); it appears in
  the JWKS again once ACTIVE.
  The `KeyRotationJob` will rotate again when the active key is older than 90 days, or promote a published
  successor; retire the unwanted `PUBLISHED` key (previous bullet) so it does not become ACTIVE a day later.

## Emergency: the key leaked

A leaked private key lets an attacker mint tokens until its `kid` is no longer accepted. The normal flow (24 h publish
lead) is too slow, so shorten it knowingly:

1. Run step 2 above, wait at least 10 minutes (so applications have re-read the JWKS), then promote by hand with the
   SQL of "After promotion" with the roles swapped (new key `ACTIVE`, old key `PUBLISHED`).
2. Retire the compromised key at once: `UPDATE signing_key SET status = 'RETIRED', retired_at = now() WHERE kid = '<old>'`.
   Every token signed with it stops verifying after the next JWKS refresh (60 s at IAM, up to 5 minutes in
   applications): **all users are effectively logged out of access tokens** and must refresh (refresh tokens do not
   depend on the key) or log in again.
3. Rotate the master key if it was exposed too. There is no command for that: the private parts are encrypted with
   `IAM_MASTER_KEY` and re-encrypting them is a manual, offline procedure not covered here (known gap).
4. Check the audit log for `auth.app_client.token` and unusual `auth.token.invalid` events during the exposure window.
