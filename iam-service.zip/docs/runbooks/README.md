# Runbooks

Operational procedures for iam-service (spec P1-11.6). Every runbook has the same sections: symptoms, diagnosis, steps,
verification, rollback. Commands were checked against the code of this repository; where a capability does not exist yet
the runbook says so ("known gap") and gives the SQL.

| Runbook | When |
|---|---|
| [Rotate the JWT signing key](key-rotation.md) | Scheduled or emergency rotation (`--iam.rotate-signing-key`) |
| [Force logout of a user or an account](force-logout.md) | Compromise, leaver, account cut-off |
| [Unlock a user](unlock-user.md) | `failed_logins` / `locked_until` after five wrong passwords (no API yet) |
| [Audit partition missing](audit-partition-missing.md) | `iam_audit_partitions_months_ahead < 2`, or audit inserts failing |
| [Bootstrap the first platform admin](bootstrap-platform-admin.md) | New installation |
| [Recover an account's admin](recover-account-admin.md) | A customer account has no usable Account Admin (ruling R43) |
| [Rotate an application client secret](app-client-secret-rotation.md) | Application credentials for `/internal/*` (no rotate endpoint yet) |

Related: [observability](../observability.md) (meters, health groups, dashboard, alerts), [OpenAPI](../openapi.json),
[performance](../perf/README.md).

Conventions: `iam_app` is the application database role (DML only), `iam_migrator` owns the schema; SQL snippets say
which one to use. The operator-facing command line options (`--iam.rotate-signing-key`,
`--bootstrap-platform-admin email=...`) always take `--spring.main.web-application-type=none` when run next to a live
instance, so the process does not bind port 8080.
