# Runbook: bootstrap the first platform admin

A fresh database has the IAM product, the PLATFORM account and the system roles (loaded from the IAM manifest when the
service first starts) but **no user**. The bootstrap command creates the `platform` tenant, an invited user with the
Platform Admin role (account scope) and a 7-day invitation. Run it once per installation; that user then creates
customer accounts (`POST /api/platform/accounts`).

The account-create request names the default tenant and default user (`defaultTenant`, `defaultUser`), and the response
returns that user's `activation.link` (ruling R46). Further tenants are created by the platform too:
`POST /api/platform/accounts/{id}/tenants`.

## Symptoms

* New environment: nobody can log in, there is no user in `app_user`.
* The platform admin's invitation expired or the mail never arrived (re-run, see below).

## Diagnosis

```sql
SELECT count(*) FROM app_user;                                              -- 0 on a fresh install
SELECT id FROM role WHERE name = 'Platform Admin' AND type = 'SYSTEM';       -- must exist: the manifest was loaded
SELECT u.email, u.status FROM role_assignment ra JOIN app_user u ON u.id = ra.user_id
  JOIN role r ON r.id = ra.role_id WHERE r.name = 'Platform Admin';          -- already bootstrapped?
```
If the role is missing the service has never started successfully against this database: start it once first
(Flyway migrates and `ManifestLoader` loads `iam-manifest.yaml`), then run the command. The command refuses (exit 2)
when the `platform` tenant or any Platform Admin assignment exists.

## Steps

1. Same environment as the running service (`IAM_DB_URL`, the app and migrator database credentials, `IAM_ISSUER`,
   `IAM_MASTER_KEY`) plus the notification settings of the environment: `iam.notification.mode` is `log` by default and
   `smtp` when mail is configured (`spring.mail.*`, `iam.notification.from`); `iam.notification.invitation-url`
   (default `http://localhost:3000/invitations/accept?token={token}`) is the link template: set it to the real UI.
2. Run:

   ```
   java -jar iam-service.jar --spring.main.web-application-type=none --bootstrap-platform-admin email=ops@example.com
   ```
   `--spring.main.web-application-type=none` keeps the process from binding port 8080. The argument is
   `email=<address>` (also accepted as `--bootstrap-platform-admin=email=<address>`).
3. Read the result:

   | Exit | Meaning |
   |---|---|
   | `0` | Done. With `iam.notification.mode=log` the accept link is printed **once, to stdout** (`Accept the invitation: ...`): copy it, it contains the token and is not logged anywhere else. With `smtp` it is mailed and never printed |
   | `2` | Already bootstrapped; nothing changed (the message says so) |
   | `1` | Missing or invalid email, a failed invitation mail (the data is committed: run the same command again to reissue and re-send), or another failure (for example the system roles are not loaded) |
4. Open the link, choose a password (`POST /auth/invitations/accept`, the UI does it): the user is activated and
   logged in. Password policy: at least 12 characters.

**Re-running** with the same email while that single Platform Admin is still `INVITED` reissues the invitation (earlier
links stop working, the new one is valid 7 days) and exits 0: this is the recovery for a lost link or a failed mail.
A different email, or an admin who already accepted, exits 2.

## Verification

```
curl -s -X POST http://iam:8080/auth/login -H 'Content-Type: application/json' \
     -d '{"email":"ops@example.com","password":"..."}' | jq '{tokenType, expiresIn, activeTenantId}'
curl -s -H "Authorization: Bearer $ACCESS" http://iam:8080/api/me | jq '.permissions'
```
`permissions` contains `platform.account.manage` and the `iam.*` permissions. Audit: `iam.app_user.insert`,
`iam.role_assignment.insert` (from the bootstrap) and `auth.invitation.accepted`, `auth.login.success`.

## Rollback

Before the invitation is accepted the bootstrap can be undone with SQL, as `iam_migrator` (or `iam_app`):

```sql
BEGIN;
DELETE FROM role_assignment WHERE user_id IN (SELECT id FROM app_user WHERE email = 'ops@example.com');
DELETE FROM user_token WHERE user_id IN (SELECT id FROM app_user WHERE email = 'ops@example.com');
DELETE FROM user_tenant_membership WHERE app_user IN (SELECT id FROM app_user WHERE email = 'ops@example.com');
DELETE FROM app_user WHERE email = 'ops@example.com' AND status = 'INVITED';
DELETE FROM tenant WHERE slug = 'platform' AND account_id = '00000000-0000-7000-8000-0000000000a1';
COMMIT;
```
The audit rows of the bootstrap stay (append-only). After the admin has accepted, do not delete: disable the user
through the API and invite another administrator (`POST /api/tenants/{tenantId}/users` with the Platform Admin role
granted through `POST /api/users/{userId}/assignments`).
