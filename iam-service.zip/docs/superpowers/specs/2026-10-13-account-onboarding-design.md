# Account onboarding: request-driven bootstrap, platform-only tenant create, activation links

Date: 2026-10-13 · Branch: `feat/account-onboarding` (from `phase-1`) · Ruling: R46

## Intent

A platform operator onboards a customer in one call. That call creates the account, a default tenant and a default user, and every name in it comes from the request. Only the platform operator ("iamadmin") can create tenants. When a user is created, the API response carries an activation link that the user opens to set their password. The invitation email still goes out as well.

**Success criteria**
- One `POST /api/platform/accounts` call returns a link that the default user can open to set a password and log in.
- Customer Account Admins can no longer create tenants. The platform operator can create them for any ACTIVE account.
- Every single-user create returns the link: invite, resend and admin recovery.
- Every link returned is audited, and no token or link is ever written to the audit log or to application logs.

## Decisions

| # | Decision | Rejected alternatives |
|---|---|---|
| D1 | "iamadmin" means the platform operator (`platform.account.manage` in the PLATFORM account, enforced by `PlatformGuard`). | A new `iam.tenant.create` permission; leaving creation with the Account Admin |
| D2 | Only tenant **create** moves to the platform. Account Admins keep list, get, update, suspend, reactivate, archive and product switches. | Moving archive too; moving all tenant writes |
| D3 | Platform tenant create does not create a user. | Optional user; required tenant admin |
| D4 | The link is returned by every single-user create: account bootstrap, tenant invite, resend and admin recovery (only when it invited someone). Bulk CSV invite stays email-only. | Bootstrap only; bulk included |
| D5 | The response carries the full link, built from the same template as the email (option A), behind the switch `iam.notification.expose-activation-link` (default `true`). | Raw token only; a separate issue-link endpoint |

## API

### `POST /api/platform/accounts` (changed)

Request. `defaultTenant` and `defaultUser` are required. The flat fields `adminEmail` and `adminDisplayName` are removed (a breaking change on an unreleased branch).

```json
{
  "name": "Acme Corp",
  "slug": "acme",
  "products": [{ "code": "billing", "status": "ACTIVE", "startsAt": "2026-10-13" }],
  "defaultTenant": { "name": "Acme HQ", "slug": "hq" },
  "defaultUser": { "email": "admin@acme.com", "displayName": "Acme Admin" }
}
```

Validation:
- `defaultTenant.name`: `@NotBlank @Size(max=200)`.
- `defaultTenant.slug`: the same regex as `TenantController`, `[a-zA-Z0-9][a-zA-Z0-9-]{0,62}`.
- `defaultUser.email`: `@NotBlank @Email @Size(max=254)`.
- `defaultUser.displayName`: optional, `@Size(max=200)`.

Response `201`:

```json
{
  "account": { "...": "AccountView, unchanged" },
  "defaultTenant": { "id": "…", "name": "Acme HQ", "slug": "hq" },
  "defaultUser": { "id": "…", "email": "admin@acme.com", "status": "INVITED" },
  "activation": { "link": "https://…/invitations/accept?token=…", "expiresAt": "2026-10-20T…Z" }
}
```

Behaviour is otherwise unchanged:
- One transaction creates the account, subscriptions, tenant (every entitled product enabled), INVITED user with primary membership, Account Admin grant at ACCOUNT scope (`grantAsSystem`) and INVITE token.
- The email goes out after commit.
- The tenant slug is lower-cased like today. It only needs to be unique within the new account, so it cannot clash.
- `TenantAdminService.DEFAULT_TENANT_SLUG` and the hard-coded `"Default"` are deleted.

### `POST /api/platform/accounts/{id}/tenants` (new)

- **Guard:** `@PreAuthorize("hasAuthority('platform.account.manage')")` and `PlatformGuard.requireOperator()`, like every other platform endpoint (I10 exception).
- **Request:** `{ name, slug, products?: [{code, enabled}] }`, the same body as the old tenant create.
- **Response:** `201` with `TenantView` and `Location: /api/platform/accounts/{id}/tenants/{tenantId}`. No user is created.

| Case | Result |
|---|---|
| Unknown account | 404 `account_not_found` |
| Account SUSPENDED or CLOSED | 409 `account_not_active` |
| Slug already used in that account | 409 `slug_taken` (existing) |
| Product not entitled or unknown | existing `TenantAdminService.create` errors |

### `POST /api/tenants` (removed)

- `TenantController.create` and `CreateTenantRequest` are deleted.
- `iam.tenant.manage` keeps its manifest description minus "create"; nothing else in the manifest changes.

### Activation link added to existing responses

| Endpoint | Response type | `activation` |
|---|---|---|
| `POST /api/tenants/{tenantId}/users` | `InvitationResult` | always (when exposed) |
| `POST /api/users/{id}/invitation/resend` | `InvitationResult` | only when the caller holds, at the same scope, every permission of every role the invitee holds (final review); otherwise email only |
| `POST /api/platform/accounts/{id}/admins` | `RecoveredAdmin` | only when `invited=true` |
| bulk CSV invite | job status | never |

`activation` is `{ link, expiresAt }`. It is absent (not `null`) when `iam.notification.expose-activation-link=false`, via `@JsonInclude(NON_NULL)`.

## Components

**`user/ActivationLinks`** (new, `@Component`)
- `@Nullable Activation forInvite(IssuedToken token)`: returns `new Activation(notificationProperties.invitationLink(raw), token.expiresAt())`, or `null` when the switch is off.
- This is the only production class that turns a raw token into response data. It runs no SQL, so the I10 SQL scan is unaffected.

**`user/NotificationProperties`**: gains `@DefaultValue("true") boolean exposeActivationLink`.

**`account/AccountAdminService.create`**
- New signature: `(name, slug, DefaultTenant tenant, DefaultUser user, List<SubscriptionRequest>)`.
- Returns `CreatedAccount(AccountView account, TenantRef defaultTenant, UserRef defaultUser, @Nullable Activation activation)`.

**`account/PlatformAccountController`**
- Request records are reshaped.
- New `createTenant` endpoint: it loads the account (404 or 409 per the table above), then calls `TenantAdminService.create(accountId, …)`.

**`tenant/TenantController`**: `create` is removed. Javadoc notes that tenants are created by the platform (R46).

**`user/InvitationService`**: `invite` and `resend` fill `InvitationResult.activation`.

**`account/AdminRecoveryService`**: `RecoveredAdmin` gains `activation` (set only when it invited someone).

## Audit

- Each response that carries a link also writes `iam.invitation.link_issued` (naming follows `iam.account.admin_recovered`) through `AuditWriter.write`, in the same transaction as the token.
- **Fields:** actor, `accountId`, `tenantId` and `target` = user id. Metadata is `{ "expires_at": …, "via": "account_create" | "invite" | "resend" | "admin_recovery" }` (snake_case, like the other metadata).
- **Never stored:** the token and the link.
- No event is written when the switch is off. Recovery that re-sends to an existing INVITED user records `via=admin_recovery`, not `resend`.

Tenant creation through the platform endpoint is already audited by the DB write triggers. The actor is the operator.

## Security

- **Bearer secret.** A link is a 7-day bearer secret. Whoever calls the API can activate the user. This is accepted (D5), audited, and can be switched off per environment.
- **No caching.** Responses carrying `activation` set `Cache-Control: no-store`.
- **No logging.** Checked: no filter in `iam-service` logs request or response bodies (no `ContentCachingResponseWrapper` or `CommonsRequestLoggingFilter`), so nothing to change.
- **One live token.** A resend makes the earlier INVITE token invalid (existing behaviour), so only the newest link works.
- **Docs.** Update `docs/security-review.md` with a row for the bearer-link risk and the switch.

## Testing

All tests use the existing Testcontainers-based ITs. TDD per change.

**`PlatformAccountApiIT`**
- Create with `defaultTenant` and `defaultUser` returns 201. The tenant's name and slug come from the request.
- The response contains `activation.link`, built from the configured template.
- Posting the link's token to `/auth/invitations/accept` with a password, then logging in, works.
- Missing or invalid `defaultTenant` or `defaultUser` returns 400.

**Platform tenant create (new tests in `PlatformAccountApiIT`)**
- 201 for an operator, and the tenant belongs to the target account.
- 404 for an unknown account.
- 409 for a SUSPENDED and for a CLOSED account.
- 409 for a duplicate slug.
- 403 for a customer Account Admin.

**`TenantApiIT`**
- `POST /api/tenants` now returns 405 for an Account Admin (`GET` still maps that path). Existing create-based setup moves to the platform endpoint or to a fixture.

**`UserApiIT` and `InvitationAcceptIT`**
- Invite and resend return `activation`. After a resend, the old link fails and the new one works.

**`AdminLockoutIT`**
- Recovery that invites returns `activation`. Recovery that reuses an existing user does not.

**`exposeActivationLink=false`**: one IT checks that `activation` is absent and no `iam.invitation.link_issued` row is written.

**Audit**: one `iam.invitation.link_issued` row per link-bearing response. Its details contain neither the token nor `token=`.

**`AuthorizationMatrixIT`**: update the matrix. `POST /api/tenants` is removed, and the new platform endpoint is operator-only.

**`AccountFilterScanTest` (I10)**: no new SQL is added (the platform endpoint reuses `TenantAdminService.create`), so the scan must stay green without new allowlist entries.

**`ExitCriteriaE2ETest`**: the operator creates the second tenant through the platform endpoint. The Account Admin flow (invite, share, roles) is unchanged. The bootstrap admin activates through the returned link instead of reading the mail log.

**Header check**: `Cache-Control: no-store` is asserted on all four endpoints.

## Docs

- Regenerate `docs/openapi.json`.
- `docs/plans/phase-1-decisions.md`: add R46 (D1 to D5), and note that the Phase 1 exit criterion "account admin can create tenants" is superseded.
- `docs/security-review.md`: add the bearer-link row.
- `docs/runbooks/recover-account-admin.md`: mention the returned link.

## Out of scope

- Bulk-invite links, a platform tenant list endpoint, and per-tenant default users.
- Changing the invite TTL (7 days) or the accept flow.
