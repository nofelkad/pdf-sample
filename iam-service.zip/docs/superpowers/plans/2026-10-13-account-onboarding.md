# Account Onboarding Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Account bootstrap takes the default tenant and default user from the request. Only the platform operator can create tenants. Every single-user create returns an audited activation link.

**Architecture:**
- A new `ActivationLinks` component is the only place that turns an INVITE token into `{link, expiresAt}`. It writes the `iam.invitation.link_issued` audit event in the caller's transaction and returns `null` when `iam.notification.expose-activation-link=false`.
- `AccountAdminService` gains request-driven bootstrap and a platform `createTenant`. `TenantController.create` is deleted.
- `InvitationService` and `AdminRecoveryService` attach the activation to their results.

**Tech Stack:** Java 21, Spring Boot 3, Spring Data JDBC / `JdbcClient`, Postgres 16 (Testcontainers), JUnit 5, AssertJ, MockMvc, Mockito.

**Spec:** `docs/superpowers/specs/2026-10-13-account-onboarding-design.md`

## Global Constraints

- **Branch:** `feat/account-onboarding` (from `phase-1`). Commit after every task.
- **Docker:** must be running for ITs (`open -a Docker`). Run tests with `./gradlew :iam-service:test --tests '<FQN>'` from the repo root.
- **Request shape:** `defaultTenant` `{name, slug}` and `defaultUser` `{email, displayName?}` are required. The flat `adminEmail` and `adminDisplayName` fields are removed.
- **Tenant slug regex:** `[a-zA-Z0-9][a-zA-Z0-9-]{0,62}`, the same as `TenantController`.
- **Activation JSON:** `activation: { link, expiresAt }`, absent (not `null`) when the switch is off (`@JsonInclude(NON_NULL)`).
- **Audit:**
  - Action is `iam.invitation.link_issued`.
  - Target is `app_user`/userId; `affecting(accountId, tenantId)`.
  - Metadata is `{expires_at, via}` with `via ∈ account_create | invite | resend | admin_recovery`.
  - The token and the link are never in audit or logs.
- **Caching:** every response carrying `activation` sets `Cache-Control: no-store` via `.cacheControl(CacheControl.noStore())`, the same pattern as `AppClientController`.
- **Platform tenant create:**
  - `POST /api/platform/accounts/{id}/tenants`, operator only (`@PreAuthorize("hasAuthority('platform.account.manage')")` + `platformGuard.requireOperator()`).
  - Unknown account: 404 `account_not_found`. Account not ACTIVE: 409 `account_not_active`.
- **Removed endpoint:** `POST /api/tenants` now returns 405.
- **Bulk invite:** stays email-only.
- **Style:** match the surrounding code (2-space indent, Javadoc on public API, records for DTOs, `@Nullable` from `org.springframework.lang`).

## Review Focus

1. **Recovery that re-sends** to an existing INVITED user must return a working link, and only the newest link may be consumable. Pinned in Task 5 (`aReInvitedAdminGetsALinkAndOnlyTheNewestWorks`).
2. **Rollback:** a bootstrap that fails after the token is issued (unknown product, `slug_taken`) must leave no `link_issued` audit row behind. Audit is REQUIRED-propagation, so it rolls back. Pinned in Task 2 (`aFailedBootstrapLeavesNothingBehindAndSendsNoMail` extended).
3. **Uppercase tenant slug** in `defaultTenant.slug` must be stored lower-cased, like the account slug. Pinned in Task 2 (`bootstrapUsesTheRequestedTenantAndReturnsAWorkingLink`, which uses `"HQ"`).
4. **The PLATFORM account itself** must still be able to get new tenants through the platform endpoint, now that `POST /api/tenants` is gone. Pinned in Task 3 (`theOperatorCanAddATenantToThePlatformAccount`).
5. **Switch off:** with `expose-activation-link=false`, the email must still be sent and the response must contain no `activation` key at all. Pinned in Task 4 (`ActivationLinkDisabledIT`).

---

### Task 1: `Activation` value, `ActivationLinks` component, config switch

**Files:**
- Create: `iam-service/src/main/java/com/acme/iam/user/Activation.java`
- Create: `iam-service/src/main/java/com/acme/iam/user/ActivationLinks.java`
- Modify: `iam-service/src/main/java/com/acme/iam/user/NotificationProperties.java` (add `exposeActivationLink`)
- Modify: `iam-service/src/test/java/com/acme/iam/user/NotificationAdaptersTest.java:127-128`, `iam-service/src/test/java/com/acme/iam/account/PlatformBootstrapCommandTest.java:114-115` (constructor gains a 5th arg)
- Test: `iam-service/src/test/java/com/acme/iam/user/ActivationLinksTest.java`

**Interfaces:**
- Produces:
  - `record Activation(String link, Instant expiresAt)` (`toString()` hides the link).
  - `ActivationLinks.issue(IssuedToken token, UUID accountId, UUID tenantId, UUID userId, ActivationLinks.Via via)` returning `@Nullable Activation`.
  - `enum ActivationLinks.Via { ACCOUNT_CREATE, INVITE, RESEND, ADMIN_RECOVERY }` (with `.code()`, e.g. `"account_create"`).
  - `ActivationLinks.AUDIT_ACTION = "iam.invitation.link_issued"`.

- [ ] **Step 1: Write the failing unit test**

```java
package com.acme.iam.user;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoInteractions;

import com.acme.iam.audit.AuditEvent;
import com.acme.iam.audit.AuditWriter;
import java.time.Instant;
import java.util.UUID;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;

class ActivationLinksTest {

  private static final UUID ACCOUNT = UUID.randomUUID();
  private static final UUID TENANT = UUID.randomUUID();
  private static final UUID USER = UUID.randomUUID();
  private static final IssuedToken TOKEN =
      new IssuedToken(UUID.randomUUID(), "raw-abc", Instant.parse("2026-10-20T00:00:00Z"));

  private final AuditWriter audit = mock(AuditWriter.class);

  @Test
  void buildsTheLinkFromTheInvitationTemplateAndAuditsWithoutTheToken() {
    Activation activation = links(true).issue(TOKEN, ACCOUNT, TENANT, USER, ActivationLinks.Via.INVITE);

    assertThat(activation.link()).isEqualTo("https://app.test/accept?token=raw-abc");
    assertThat(activation.expiresAt()).isEqualTo(TOKEN.expiresAt());
    assertThat(activation.toString()).doesNotContain("raw-abc");

    ArgumentCaptor<AuditEvent> captor = ArgumentCaptor.forClass(AuditEvent.class);
    verify(audit).write(captor.capture());
    AuditEvent event = captor.getValue();
    assertThat(event.action()).isEqualTo("iam.invitation.link_issued");
    assertThat(event.accountId()).isEqualTo(ACCOUNT);
    assertThat(event.tenantId()).isEqualTo(TENANT);
    assertThat(event.targetType()).isEqualTo("app_user");
    assertThat(event.targetId()).isEqualTo(USER.toString());
    assertThat(event.metadata()).containsEntry("via", "invite")
        .containsEntry("expires_at", "2026-10-20T00:00:00Z");
    assertThat(event.metadata().toString()).doesNotContain("raw-abc").doesNotContain("token=");
  }

  @Test
  void returnsNothingAndAuditsNothingWhenSwitchedOff() {
    assertThat(links(false).issue(TOKEN, ACCOUNT, TENANT, USER, ActivationLinks.Via.RESEND)).isNull();
    verifyNoInteractions(audit);
  }

  @Test
  void viaCodesAreSnakeCase() {
    assertThat(ActivationLinks.Via.ACCOUNT_CREATE.code()).isEqualTo("account_create");
    assertThat(ActivationLinks.Via.ADMIN_RECOVERY.code()).isEqualTo("admin_recovery");
  }

  private ActivationLinks links(boolean expose) {
    return new ActivationLinks(new NotificationProperties(NotificationProperties.Mode.LOG, "no-reply@iam.local",
        "https://app.test/accept?token={token}", "https://app.test/reset?token={token}", expose), audit);
  }
}
```

- [ ] **Step 2: Run it and confirm it fails to compile**

Run: `./gradlew :iam-service:test --tests 'com.acme.iam.user.ActivationLinksTest'`
Expected: compilation FAILURE (`Activation`, `ActivationLinks` and the 5-arg `NotificationProperties` constructor do not exist).

- [ ] **Step 3: Add the switch to `NotificationProperties`**

Add the record component and its Javadoc `@param`:

```java
 * @param exposeActivationLink when {@code true} (default) API responses that create or re-invite a single user carry
 *     the activation link ({@link ActivationLinks}); {@code false} keeps links email-only
 */
@ConfigurationProperties("iam.notification")
public record NotificationProperties(
    @DefaultValue("log") Mode mode,
    @DefaultValue("no-reply@iam.local") String from,
    @DefaultValue("http://localhost:3000/invitations/accept?token={token}") String invitationUrl,
    @DefaultValue("http://localhost:3000/password/reset?token={token}") String passwordResetUrl,
    @DefaultValue("true") boolean exposeActivationLink) {
```

Then update the two existing test constructors to pass `true` as the last argument:
- `NotificationAdaptersTest.java:127`: `new NotificationProperties(NotificationProperties.Mode.SMTP, "iam@acme.test", "https://app.acme.test/invite?t={token}", "https://app.acme.test/reset?t={token}", true)`
- `PlatformBootstrapCommandTest.java:114`: `new NotificationProperties(mode, "no-reply@iam.local", "https://iam.example.test/accept?token={token}", "https://iam.example.test/reset?token={token}", true)`

- [ ] **Step 4: Create `Activation`**

```java
package com.acme.iam.user;

import java.time.Instant;

/**
 * An activation (accept-invitation) link returned by the API (ruling R46). The link embeds a raw INVITE token: it is a
 * 7-day bearer secret, so {@link #toString()} hides it and responses carrying it are {@code Cache-Control: no-store}.
 */
public record Activation(String link, Instant expiresAt) {

  @Override
  public String toString() {
    return "Activation[expiresAt=" + expiresAt + "]";
  }
}
```

- [ ] **Step 5: Create `ActivationLinks`**

```java
package com.acme.iam.user;

import com.acme.iam.audit.AuditEvent;
import com.acme.iam.audit.AuditWriter;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import org.springframework.lang.Nullable;
import org.springframework.stereotype.Component;

/**
 * Ruling R46: the only place that turns an issued INVITE token into an {@link Activation} for an API response. The link
 * is built from {@code iam.notification.invitation-url}, so it is the same link the invitation email carries. Every
 * link handed out is audited as {@value #AUDIT_ACTION} in the caller's transaction (without the token or the link).
 * With {@code iam.notification.expose-activation-link=false} nothing is returned and nothing is audited.
 */
@Component
public class ActivationLinks {

  public static final String AUDIT_ACTION = "iam.invitation.link_issued";

  /** Which flow handed the link out ({@code via} in the audit metadata). */
  public enum Via {
    ACCOUNT_CREATE, INVITE, RESEND, ADMIN_RECOVERY;

    public String code() {
      return name().toLowerCase(Locale.ROOT);
    }
  }

  private final NotificationProperties properties;
  private final AuditWriter audit;

  public ActivationLinks(NotificationProperties properties, AuditWriter audit) {
    this.properties = properties;
    this.audit = audit;
  }

  /** The activation for {@code token}, or {@code null} when links are not exposed. */
  @Nullable
  public Activation issue(IssuedToken token, UUID accountId, UUID tenantId, UUID userId, Via via) {
    if (!properties.exposeActivationLink()) {
      return null;
    }
    Map<String, Object> metadata = new LinkedHashMap<>();
    metadata.put("expires_at", token.expiresAt().toString());
    metadata.put("via", via.code());
    audit.write(AuditEvent.forCurrentActor(AUDIT_ACTION).affecting(accountId, tenantId)
        .target("app_user", userId.toString()).metadata(metadata).build());
    return new Activation(properties.invitationLink(token.rawToken()), token.expiresAt());
  }
}
```

- [ ] **Step 6: Run the new test and the two touched tests**

Run: `./gradlew :iam-service:test --tests 'com.acme.iam.user.ActivationLinksTest' --tests 'com.acme.iam.user.NotificationAdaptersTest' --tests 'com.acme.iam.account.PlatformBootstrapCommandTest'`
Expected: PASS.

- [ ] **Step 7: Commit**

```bash
git add iam-service/src/main/java/com/acme/iam/user/Activation.java iam-service/src/main/java/com/acme/iam/user/ActivationLinks.java iam-service/src/main/java/com/acme/iam/user/NotificationProperties.java iam-service/src/test/java/com/acme/iam/user/ActivationLinksTest.java iam-service/src/test/java/com/acme/iam/user/NotificationAdaptersTest.java iam-service/src/test/java/com/acme/iam/account/PlatformBootstrapCommandTest.java
git commit -m "feat(user): ActivationLinks builds and audits activation links behind iam.notification.expose-activation-link (R46)"
```

---

### Task 2: Request-driven account bootstrap returning the activation

**Files:**
- Modify: `iam-service/src/main/java/com/acme/iam/account/AccountAdminService.java` (`create`, `CreatedAccount`, new `DefaultTenant`, `DefaultUser`, `TenantRef`, `UserRef` records, constructor gains `ActivationLinks`)
- Modify: `iam-service/src/main/java/com/acme/iam/account/PlatformAccountController.java` (`CreateAccountRequest`, `create`)
- Modify: `iam-service/src/main/java/com/acme/iam/tenant/TenantAdminService.java:62` (delete `DEFAULT_TENANT_SLUG`)
- Test: `iam-service/src/test/java/com/acme/iam/account/PlatformAccountApiIT.java`
- Modify tests that post the old body:
  - `iam-service/src/test/java/com/acme/iam/security/AuthorizationMatrixIT.java:135-137`
  - `iam-service/src/test/java/com/acme/iam/audit/AuditAttributionIT.java:142-147`

**Interfaces:**
- Consumes: `ActivationLinks.issue(...)`, `Activation` (Task 1).
- Produces:
  - `AccountAdminService.create(String name, String slug, DefaultTenant tenant, DefaultUser user, List<SubscriptionRequest> subscriptions)` returning `CreatedAccount`.
  - `record DefaultTenant(String name, String slug)`.
  - `record DefaultUser(String email, @Nullable String displayName)`.
  - `record TenantRef(UUID id, String name, String slug)`.
  - `record UserRef(UUID id, String email, UserStatus status)`.
  - `@JsonInclude(NON_NULL) record CreatedAccount(AccountView account, TenantRef defaultTenant, UserRef defaultUser, @Nullable Activation activation)`.
  - JSON paths: `/account/id`, `/defaultTenant/id`, `/defaultUser/id`, `/activation/link`.

- [ ] **Step 1: Rewrite the bootstrap tests in `PlatformAccountApiIT` (failing)**

Add the imports `com.acme.iam.user.ActivationLinks`, `org.springframework.http.HttpHeaders` and `static org.springframework.test.web.servlet.result.MockMvcResultMatchers.header`. Add a helper and a constant:

```java
  private static final String PASSWORD = "Activated-Passphrase-123";

  private static String body(String slug, String tenantSlug, String email) {
    return """
        {"name":"Acme","slug":"%s","defaultTenant":{"name":"Acme HQ","slug":"%s"},
         "defaultUser":{"email":"%s","displayName":"Ada"}}""".formatted(slug, tenantSlug, email);
  }
```

Replace `bootstrapCreatesAccountDefaultTenantAndInvitedAccountAdmin` with the version below. It is the same assertions as before, but the tenant comes from the request, ids come from the new paths, and the token comes from the response link:

```java
  @Test
  void bootstrapCreatesAccountDefaultTenantAndInvitedAccountAdmin() throws Exception {
    String slug = slug();
    String email = "admin-" + slug + "@example.test";
    String suspendedCode = code(fx.product());

    JsonNode created = create("""
        {"name":"Acme","slug":"%s","defaultTenant":{"name":"Acme HQ","slug":"hq"},
         "defaultUser":{"email":"%s","displayName":"Ada"},
         "products":[{"code":"%s","status":"ACTIVE","startsAt":"2026-01-01"},
                     {"code":"%s","status":"SUSPENDED","startsAt":"2026-01-01"}]}"""
        .formatted(slug, email, productCode, suspendedCode));

    UUID accountId = UUID.fromString(created.at("/account/id").asText());
    UUID tenantId = UUID.fromString(created.at("/defaultTenant/id").asText());
    UUID adminId = UUID.fromString(created.at("/defaultUser/id").asText());
    assertThat(created.at("/account/kind").asText()).isEqualTo("CUSTOMER");
    assertThat(created.at("/account/products").size()).isEqualTo(2);
    assertThat(created.at("/defaultTenant/name").asText()).isEqualTo("Acme HQ");
    assertThat(created.at("/defaultTenant/slug").asText()).isEqualTo("hq");
    assertThat(created.at("/defaultUser/email").asText()).isEqualTo(email);
    assertThat(created.at("/defaultUser/status").asText()).isEqualTo("INVITED");

    // default tenant: name and slug from the request, only the entitled product switched on (I5)
    Map<String, Object> tenant = jdbc.sql("""
            SELECT account_id, name, slug::text AS slug, status FROM tenant WHERE id = :id""")
        .param("id", tenantId).query().singleRow();
    assertThat(tenant).containsEntry("account_id", accountId).containsEntry("name", "Acme HQ")
        .containsEntry("slug", "hq").containsEntry("status", "ACTIVE");
    assertThat(jdbc.sql("SELECT product_id FROM tenant_product WHERE tenant = :t AND enabled")
        .param("t", tenantId).query(UUID.class).list()).containsExactly(product);

    // admin: INVITED, primary membership, Account Admin at ACCOUNT scope granted by the operator
    assertThat(org.userStatus(adminId)).isEqualTo("INVITED");
    assertThat(org.membershipTenants(adminId)).containsExactly(tenantId);
    Map<String, Object> grant = jdbc.sql("""
            SELECT ra.scope_type, ra.scope_id, ra.granted_by, r.name FROM role_assignment ra
            JOIN role r ON r.id = ra.role_id WHERE ra.user_id = :u""").param("u", adminId).query().singleRow();
    assertThat(grant).containsEntry("scope_type", "ACCOUNT").containsEntry("scope_id", accountId)
        .containsEntry("granted_by", operator).containsEntry("name", "Account Admin");
    assertThat(resolver.resolve(adminId, tenantId)).contains("iam.user.manage", "iam.tenant.manage");

    // invitation: one INVITE token valid for 7 days; the response link and the email carry the same token
    assertThat(org.outstandingInviteExpiry(adminId).toInstant())
        .isCloseTo(OffsetDateTime.now().plusDays(7).toInstant(), within(1, ChronoUnit.MINUTES));
    String linkToken = tokenOf(created.at("/activation/link").asText());
    CapturingNotificationAdapter.Sent sent = mailbox.last(CapturingNotificationAdapter.Kind.INVITATION, email)
        .orElseThrow();
    assertThat(sent.accountName()).isEqualTo("Acme");
    assertThat(sent.rawToken()).isEqualTo(linkToken);
    UUID consumedBy = tx.execute(s -> userTokens.consume(linkToken, TokenPurpose.INVITE).user());
    assertThat(consumedBy).isEqualTo(adminId);

    // audited once, without the token
    Map<String, Object> audited = jdbc.sql("""
            SELECT account_id, tenant_id, metadata::text AS metadata FROM audit_event
            WHERE action = :a AND target_id = :u""")
        .param("a", ActivationLinks.AUDIT_ACTION).param("u", adminId.toString()).query().singleRow();
    assertThat(audited).containsEntry("account_id", accountId).containsEntry("tenant_id", tenantId);
    assertThat((String) audited.get("metadata")).contains("account_create").doesNotContain(linkToken);
  }

  @Test
  void bootstrapUsesTheRequestedTenantAndReturnsAWorkingLink() throws Exception {
    String slug = slug();
    String email = "admin-" + slug + "@example.test";
    String response = mvc.perform(post(ACCOUNTS).header(AUTHORIZATION, bearer).contentType(MediaType.APPLICATION_JSON)
            .content(body(slug, "HQ", email)))
        .andExpect(status().isCreated())
        .andExpect(header().string(HttpHeaders.CACHE_CONTROL, "no-store"))
        .andExpect(jsonPath("$.defaultTenant.slug").value("hq"))
        .andExpect(jsonPath("$.activation.expiresAt").isNotEmpty())
        .andReturn().getResponse().getContentAsString();
    String token = tokenOf(json.readTree(response).at("/activation/link").asText());

    mvc.perform(post("/auth/invitations/accept").contentType(MediaType.APPLICATION_JSON)
            .content("{\"token\":\"%s\",\"password\":\"%s\"}".formatted(token, PASSWORD)))
        .andExpect(status().isOk())
        .andExpect(jsonPath("$.accessToken").isNotEmpty());
    mvc.perform(post("/auth/login").contentType(MediaType.APPLICATION_JSON)
            .content("{\"email\":\"%s\",\"password\":\"%s\"}".formatted(email, PASSWORD)))
        .andExpect(status().isOk());
  }
```

Add a helper next to `slug()`:

```java
  /** The raw token in an activation link ({@code …?token=<raw>}). */
  private static String tokenOf(String link) {
    assertThat(link).startsWith("http").contains("token=");
    return link.substring(link.indexOf("token=") + "token=".length());
  }
```

In `aFailedBootstrapLeavesNothingBehindAndSendsNoMail`, change the body to the new shape and assert that no link was audited:

```java
            .content("""
                {"name":"Acme","slug":"%s","defaultTenant":{"name":"HQ","slug":"hq"},
                 "defaultUser":{"email":"%s"},
                 "products":[{"code":"NO_SUCH_PRODUCT","status":"ACTIVE","startsAt":"2026-01-01"}]}"""
                .formatted(slug, email)))
```

and after the existing `mailbox.sent()` assertion:

```java
    assertThat(jdbc.sql("""
            SELECT count(*) FROM audit_event WHERE action = :a AND occurred_at > now() - interval '1 minute'
              AND metadata->>'via' = 'account_create' AND account_id NOT IN (SELECT id FROM account)""")
        .param("a", ActivationLinks.AUDIT_ACTION).query(Long.class).single()).isZero();
```

In `slugMustBeUnique`, use `body(slug, "hq", "a-" + slug + "@example.test")` for the first create, and the same shape with `slug.toUpperCase()` and `"b-" + slug + "@example.test"` for the second.

Replace `validatesTheRequest` with:

```java
  @Test
  void validatesTheRequest() throws Exception {
    for (String invalid : new String[] {
        "{\"name\":\"\",\"slug\":\"Bad Slug\",\"defaultTenant\":{\"name\":\"HQ\",\"slug\":\"hq\"},"
            + "\"defaultUser\":{\"email\":\"a@example.test\"}}",
        "{\"name\":\"Acme\",\"slug\":\"acme-x\",\"defaultUser\":{\"email\":\"a@example.test\"}}",
        "{\"name\":\"Acme\",\"slug\":\"acme-x\",\"defaultTenant\":{\"name\":\"HQ\",\"slug\":\"hq\"}}",
        "{\"name\":\"Acme\",\"slug\":\"acme-x\",\"defaultTenant\":{\"name\":\"\",\"slug\":\"-bad\"},"
            + "\"defaultUser\":{\"email\":\"a@example.test\"}}",
        "{\"name\":\"Acme\",\"slug\":\"acme-x\",\"defaultTenant\":{\"name\":\"HQ\",\"slug\":\"hq\"},"
            + "\"defaultUser\":{\"email\":\"not-an-email\"}}"}) {
      mvc.perform(post(ACCOUNTS).header(AUTHORIZATION, bearer).contentType(MediaType.APPLICATION_JSON)
              .content(invalid))
          .andExpect(status().isBadRequest())
          .andExpect(jsonPath("$.code").value("validation_failed"));
    }
  }
```

- [ ] **Step 2: Run and confirm failure**

Run: `./gradlew :iam-service:test --tests 'com.acme.iam.account.PlatformAccountApiIT'`
Expected: FAIL. The new bodies get 400 `validation_failed` (`adminEmail` is missing), and `/defaultTenant/id` is missing.

- [ ] **Step 3: Change `AccountAdminService`**

Add the imports `com.acme.iam.user.Activation`, `com.acme.iam.user.ActivationLinks`, `com.acme.iam.user.UserStatus` and `com.fasterxml.jackson.annotation.JsonInclude`. Replace the `CreatedAccount` record and add the new records:

```java
  /** The default tenant of a new account, as requested (R46). */
  public record DefaultTenant(String name, String slug) {}

  /** The default user (first Account Admin) of a new account, as requested (R46). */
  public record DefaultUser(String email, @Nullable String displayName) {}

  public record TenantRef(UUID id, String name, String slug) {}

  public record UserRef(UUID id, String email, UserStatus status) {}

  /**
   * Result of {@link #create}: the account, its default tenant, the invited default user and (unless
   * {@code iam.notification.expose-activation-link=false}) the activation link.
   */
  @JsonInclude(JsonInclude.Include.NON_NULL)
  public record CreatedAccount(AccountView account, TenantRef defaultTenant, UserRef defaultUser,
                               @Nullable Activation activation) {}
```

Add the field `private final ActivationLinks activationLinks;`, add it as the last constructor parameter, and assign it.

Replace `create`. Update its Javadoc first line to *"P1-6.2 / R46: creates a CUSTOMER account with the requested default tenant and invites the requested default user as its first Account Admin."*:

```java
  @Transactional
  public CreatedAccount create(String name, String slug, DefaultTenant defaultTenant, DefaultUser defaultUser,
      List<SubscriptionRequest> subscriptions) {
    UUID operator = RequestActor.current().userUuid();
    slug = slug.toLowerCase(Locale.ROOT);
    if (accounts.findBySlug(slug).isPresent()) {
      throw slugTaken();
    }
    Set<AccountProduct> requested = resolve(subscriptions);
    Role adminRole = roles.findSystemRole(Product.IAM_ID, Role.ACCOUNT_ADMIN)
        .orElseThrow(() -> new ApiException(HttpStatus.INTERNAL_SERVER_ERROR, "system_role_missing",
            "The " + Role.ACCOUNT_ADMIN + " system role is not loaded"));

    Account account = accounts.save(Account.create(name, slug, AccountKind.CUSTOMER).withProducts(requested));
    Tenant tenant = tenantAdmin.createWithProducts(account.id(), defaultTenant.name(), defaultTenant.slug(),
        account.entitledProductIds(today()));
    InvitedUser admin = invitations.createInvitedUser(account.id(), tenant.id(), defaultUser.email(),
        defaultUser.displayName(), operator);
    assignments.grantAsSystem(admin.user().id(), adminRole.id(), ScopeType.ACCOUNT, account.id(), operator, null);
    Activation activation = activationLinks.issue(admin.token(), account.id(), tenant.id(), admin.user().id(),
        ActivationLinks.Via.ACCOUNT_CREATE);
    invitations.notifyAfterCommit(List.of(new PendingInvitation(admin.user().email(), account.name(),
        admin.token().rawToken())));
    return new CreatedAccount(view(account), new TenantRef(tenant.id(), tenant.name(), tenant.slug()),
        new UserRef(admin.user().id(), admin.user().email(), admin.user().status()), activation);
  }
```

`createInternal` already lower-cases the slug. Confirm that `Tenant` exposes `name()` and `slug()` and that `AppUser` exposes `status()` (`grep -n "public .* name()\|slug()\|status()" iam-service/src/main/java/com/acme/iam/tenant/Tenant.java iam-service/src/main/java/com/acme/iam/user/AppUser.java`). Spring Data JDBC aggregates here are records or have accessors, so use whatever accessor names exist.

Update the class Javadoc bootstrap bullet: replace *"the {@value TenantAdminService#DEFAULT_TENANT_SLUG} tenant"* with *"the requested default tenant"*, and add *"; the activation link is returned ({@link ActivationLinks}) and the email goes out after commit"*.

- [ ] **Step 4: Delete `DEFAULT_TENANT_SLUG`**

Delete line 62 (`public static final String DEFAULT_TENANT_SLUG = "default";`) of `TenantAdminService.java`. Then run `grep -rn DEFAULT_TENANT_SLUG iam-service/src` and confirm there are no matches.

- [ ] **Step 5: Change `PlatformAccountController`**

Add the imports `com.acme.iam.account.AccountAdminService.DefaultTenant`, `com.acme.iam.account.AccountAdminService.DefaultUser` and `org.springframework.http.CacheControl`. Replace `CreateAccountRequest`:

```java
  public record DefaultTenantBody(@NotBlank @Size(max = 200) String name,
                                  @NotBlank @Pattern(regexp = "[a-zA-Z0-9][a-zA-Z0-9-]{0,62}") String slug) {}

  public record DefaultUserBody(@NotBlank @Email @Size(max = 254) String email,
                                @Nullable @Size(max = 200) String displayName) {}

  /** R46: every name of the new account, its default tenant and its default user comes from the request. */
  public record CreateAccountRequest(
      @NotBlank @Size(max = 200) String name,
      @NotBlank @Pattern(regexp = "[a-zA-Z0-9][a-zA-Z0-9-]{1,62}") String slug,
      @NotNull @Valid DefaultTenantBody defaultTenant,
      @NotNull @Valid DefaultUserBody defaultUser,
      @Nullable List<@Valid SubscriptionBody> products) {}
```

Replace the `create` handler. Update its Javadoc to *"P1-6.2 / R46: account + requested default tenant + invited default user (Account Admin), in one call. The response carries the activation link, so it is never cached."*:

```java
  @PostMapping
  @PreAuthorize("hasAuthority('platform.account.manage')")
  public ResponseEntity<CreatedAccount> create(@Valid @RequestBody CreateAccountRequest request) {
    requirePlatformCaller();
    CreatedAccount created = service.create(request.name(), request.slug(),
        new DefaultTenant(request.defaultTenant().name(), request.defaultTenant().slug()),
        new DefaultUser(request.defaultUser().email(), request.defaultUser().displayName()),
        toRequests(request.products()));
    return ResponseEntity.created(URI.create(PATH + "/" + created.account().id()))
        .cacheControl(CacheControl.noStore())
        .body(created);
  }
```

- [ ] **Step 6: Update the two other tests that post the old body**

`AuthorizationMatrixIT.java:136`. Change the JSON to:

```java
          w -> json(post("/api/platform/accounts"), ("{\"name\":\"M\",\"slug\":\"m-%s\","
              + "\"defaultTenant\":{\"name\":\"HQ\",\"slug\":\"hq\"},\"defaultUser\":{\"email\":\"a-%s@example.test\"}}")
              .formatted(w.nonce, w.nonce))),
```

`AuditAttributionIT.java:142-147`. Change the body and the id paths:

```java
    JsonNode created = body(mvc.perform(json(post("/api/platform/accounts"),
            ("{\"name\":\"C1\",\"slug\":\"%s\",\"defaultTenant\":{\"name\":\"HQ\",\"slug\":\"hq\"},"
                + "\"defaultUser\":{\"email\":\"admin-%s@example.test\"}}").formatted(slug, slug))
        .header(AUTHORIZATION, platform)), 201);
    UUID x = UUID.fromString(created.at("/account/id").asText());
    UUID defaultTenant = UUID.fromString(created.at("/defaultTenant/id").asText());
    UUID bootstrapAdmin = UUID.fromString(created.at("/defaultUser/id").asText());
```

- [ ] **Step 7: Run the affected tests**

Run: `./gradlew :iam-service:test --tests 'com.acme.iam.account.PlatformAccountApiIT' --tests 'com.acme.iam.audit.AuditAttributionIT' --tests 'com.acme.iam.security.AuthorizationMatrixIT' --tests 'com.acme.iam.account.PlatformBootstrapIT'`
Expected: PASS.

If `AuditAttributionIT` asserts an exact list of audit actions for the bootstrap, add `iam.invitation.link_issued` to it. It is filed under the new account and default tenant, the same stamp as the other bootstrap rows.

- [ ] **Step 8: Commit**

```bash
git add -A iam-service/src
git commit -m "feat(account): bootstrap takes default tenant and user from the request and returns the activation link (R46)"
```

---

### Task 3: Platform-only tenant creation

**Files:**
- Modify: `iam-service/src/main/java/com/acme/iam/account/AccountAdminService.java` (add `createTenant`)
- Modify: `iam-service/src/main/java/com/acme/iam/account/PlatformAccountController.java` (add `CreateTenantRequest`, `createTenant`)
- Modify: `iam-service/src/main/java/com/acme/iam/tenant/TenantController.java` (delete `create`, `CreateTenantRequest`; Javadoc)
- Modify: `iam-service/src/main/resources/iam-manifest.yaml:7` (description)
- Test: `iam-service/src/test/java/com/acme/iam/account/PlatformAccountApiIT.java` (new tests)
- Modify: `iam-service/src/test/java/com/acme/iam/tenant/TenantApiIT.java` (replace create-based tests)
- Modify: `iam-service/src/test/java/com/acme/iam/security/AuthorizationMatrixIT.java:173-174` (swap row)

**Interfaces:**
- Consumes: `TenantAdminService.create(UUID accountId, String name, String slug, List<ProductSwitch>)` returning `TenantView` (existing).
- Produces: `AccountAdminService.createTenant(UUID accountId, String name, String slug, List<TenantAdminService.ProductSwitch> switches)` returning `TenantAdminService.TenantView`, plus the endpoint `POST /api/platform/accounts/{id}/tenants`.

- [ ] **Step 1: Write failing tests in `PlatformAccountApiIT`**

```java
  @Test
  void theOperatorCreatesATenantInACustomerAccount() throws Exception {
    Fixtures.Scenario s = fx.scenario();
    fx.subscribe(s.accountId(), product, SubscriptionStatus.ACTIVE, null);
    String slug = "t-" + Ids.newId().toString().substring(24);

    mvc.perform(post(ACCOUNTS + "/{id}/tenants", s.accountId()).header(AUTHORIZATION, bearer)
            .contentType(MediaType.APPLICATION_JSON)
            .content("""
                {"name":"Europe","slug":"%s","products":[{"code":"%s","enabled":true}]}""".formatted(slug, productCode)))
        .andExpect(status().isCreated())
        .andExpect(header().string(HttpHeaders.LOCATION,
            org.hamcrest.Matchers.startsWith("/api/platform/accounts/" + s.accountId() + "/tenants/")))
        .andExpect(jsonPath("$.accountId").value(s.accountId().toString()))
        .andExpect(jsonPath("$.name").value("Europe"))
        .andExpect(jsonPath("$.status").value("ACTIVE"))
        .andExpect(jsonPath("$.products[0].productCode").value(productCode));
    assertThat(jdbc.sql("SELECT count(*) FROM app_user WHERE primary_tenant_id IN "
            + "(SELECT id FROM tenant WHERE account_id = :a AND slug = :s)")
        .param("a", s.accountId()).param("s", slug).query(Long.class).single()).as("no user is created").isZero();
  }

  @Test
  void theOperatorCanAddATenantToThePlatformAccount() throws Exception {
    mvc.perform(post(ACCOUNTS + "/{id}/tenants", Account.PLATFORM_ID).header(AUTHORIZATION, bearer)
            .contentType(MediaType.APPLICATION_JSON)
            .content("{\"name\":\"Ops\",\"slug\":\"ops-%s\"}".formatted(Ids.newId().toString().substring(24))))
        .andExpect(status().isCreated());
  }

  @Test
  void tenantCreationNeedsAnActiveAccountAndAFreeSlug() throws Exception {
    String request = "{\"name\":\"N\",\"slug\":\"n-%s\"}".formatted(Ids.newId().toString().substring(24));
    mvc.perform(post(ACCOUNTS + "/{id}/tenants", Ids.newId()).header(AUTHORIZATION, bearer)
            .contentType(MediaType.APPLICATION_JSON).content(request))
        .andExpect(status().isNotFound())
        .andExpect(jsonPath("$.code").value("account_not_found"));
    for (AccountStatus inactive : new AccountStatus[] {AccountStatus.SUSPENDED, AccountStatus.CLOSED}) {
      UUID account = fx.account(AccountKind.CUSTOMER, inactive);
      mvc.perform(post(ACCOUNTS + "/{id}/tenants", account).header(AUTHORIZATION, bearer)
              .contentType(MediaType.APPLICATION_JSON).content(request))
          .andExpect(status().isConflict())
          .andExpect(jsonPath("$.code").value("account_not_active"));
    }
    UUID active = fx.account();
    mvc.perform(post(ACCOUNTS + "/{id}/tenants", active).header(AUTHORIZATION, bearer)
        .contentType(MediaType.APPLICATION_JSON).content(request)).andExpect(status().isCreated());
    mvc.perform(post(ACCOUNTS + "/{id}/tenants", active).header(AUTHORIZATION, bearer)
            .contentType(MediaType.APPLICATION_JSON).content(request))
        .andExpect(status().isConflict())
        .andExpect(jsonPath("$.code").value("slug_taken"));
  }

  @Test
  void aCustomerAccountAdminCannotCreateTenantsAnyMore() throws Exception {
    Fixtures.Scenario s = fx.scenario();
    UUID admin = org.accountAdmin(s.accountId(), s.tenantId());
    String adminBearer = org.bearer(tokens, admin, s.accountId(), s.tenantId(), "iam.tenant.manage");
    String request = "{\"name\":\"N\",\"slug\":\"n-%s\"}".formatted(Ids.newId().toString().substring(24));

    mvc.perform(post("/api/tenants").header(AUTHORIZATION, adminBearer)
            .contentType(MediaType.APPLICATION_JSON).content(request))
        .andExpect(status().isMethodNotAllowed());
    mvc.perform(post(ACCOUNTS + "/{id}/tenants", s.accountId()).header(AUTHORIZATION, adminBearer)
            .contentType(MediaType.APPLICATION_JSON).content(request))
        .andExpect(status().isForbidden());
  }
```

- [ ] **Step 2: Run and confirm failure**

Run: `./gradlew :iam-service:test --tests 'com.acme.iam.account.PlatformAccountApiIT'`
Expected: the four new tests FAIL. The platform path returns 404 or 405, and `/api/tenants` POST returns 201.

- [ ] **Step 3: Add `AccountAdminService.createTenant`**

Add the import `com.acme.iam.tenant.TenantAdminService.ProductSwitch` and `TenantAdminService.TenantView`. Then, in the writes section:

```java
  /**
   * R46: tenants are created by platform operators only, in any ACTIVE account (the PLATFORM account included). No user
   * is created; the account's admins invite users into the new tenant.
   *
   * @throws NotFoundException {@code account_not_found}
   * @throws ConflictException {@code account_not_active} (SUSPENDED or CLOSED), {@code slug_taken}
   * @throws BadRequestException {@code unknown_product}, {@code product_not_subscribed}
   */
  @Transactional
  public TenantView createTenant(UUID accountId, String name, String slug, List<ProductSwitch> switches) {
    Account account = load(accountId);
    if (!account.isActive()) {
      throw new ConflictException("account_not_active", "The account is " + account.status());
    }
    return tenantAdmin.create(accountId, name, slug, switches);
  }
```

- [ ] **Step 4: Add the endpoint to `PlatformAccountController`**

Add the imports `com.acme.iam.tenant.TenantAdminService.ProductSwitch` and `com.acme.iam.tenant.TenantAdminService.TenantView`:

```java
  public record TenantProductBody(@NotBlank String code, boolean enabled) {
    ProductSwitch toSwitch() {
      return new ProductSwitch(code, enabled);
    }
  }

  public record CreateTenantRequest(
      @NotBlank @Size(max = 200) String name,
      @NotBlank @Pattern(regexp = "[a-zA-Z0-9][a-zA-Z0-9-]{0,62}") String slug,
      @Nullable List<@Valid TenantProductBody> products) {}
```

```java
  /** R46: tenant creation is a platform operation; customer Account Admins manage, but no longer create, tenants. */
  @PostMapping("/{id}/tenants")
  @PreAuthorize("hasAuthority('platform.account.manage')")
  public ResponseEntity<TenantView> createTenant(@PathVariable UUID id,
                                                 @Valid @RequestBody CreateTenantRequest request) {
    requirePlatformCaller();
    List<ProductSwitch> switches = request.products() == null ? List.of()
        : request.products().stream().map(TenantProductBody::toSwitch).toList();
    TenantView created = service.createTenant(id, request.name(), request.slug(), switches);
    return ResponseEntity.created(URI.create(PATH + "/" + id + "/tenants/" + created.id())).body(created);
  }
```

- [ ] **Step 5: Remove customer tenant creation**

In `TenantController`:
- Delete the `create` method and the `CreateTenantRequest` record.
- Remove the now-unused imports (`URI`, `ResponseEntity`, `PostMapping` is still used by suspend and others, `Pattern`; check each one).
- Change the class Javadoc first sentence to: *"Tenant API (P1-6.3). Tenants are created by platform operators ({@code POST /api/platform/accounts/{id}/tenants}, ruling R46); here an account manages its existing tenants. Every endpoint needs ..."* and keep the rest.

In `iam-manifest.yaml:7`, change the description to `"Update, suspend, archive tenants and switch their products"`.

- [ ] **Step 6: Update `TenantApiIT`**

`TenantApiIT` no longer creates tenants through the API:

- **`createsListsGetsAndUpdatesTenantsOfTheOwnAccount`:** rename it to `listsGetsAndUpdatesTenantsOfTheOwnAccount`. Replace the POST with `UUID id = fx.tenant(account);` and look the slug up with `String slug = jdbc.sql("SELECT slug::text FROM tenant WHERE id = :id").param("id", id).query(String.class).single();`. Replace the `$.name` "Sales" assertion on GET with `.andExpect(jsonPath("$.id").value(id.toString()))`. Keep the PATCH assertions.
- **`i5_enablingAProductTheAccountDoesNotActivelySubscribeIsRejected`:** delete the first `post("/api/tenants")` block (lines 112-117); the I5 check on create is covered by the platform endpoint (`TenantAdminService.create` is unchanged). Keep the `PUT .../products` part.
- **`duplicateSlugInTheAccountIsAConflict`:** delete it. It is covered by `tenantCreationNeedsAnActiveAccountAndAFreeSlug`.
- **`tenantManagementNeedsTheGrantAtAccountScope`:** delete the `post("/api/tenants")` block (lines 241-243).
- **`aClosedAccountCannotChangeTenants`:** delete the `post("/api/tenants")` block (lines 255-259) and keep the PATCH check.
- Add:

```java
  @Test
  void accountAdminsCanNoLongerCreateTenants() throws Exception {
    mvc.perform(post("/api/tenants").header(AUTHORIZATION, bearer).contentType(MediaType.APPLICATION_JSON)
            .content("{\"name\":\"N\",\"slug\":\"n-%s\"}".formatted(Ids.newId().toString().substring(24))))
        .andExpect(status().isMethodNotAllowed());
  }
```

Update the class Javadoc: *"P1-6.3: tenant API ({@code iam.tenant.manage}, own account only; creation is platform-only, R46), I5 and revocation on suspend/archive/disable."*

- [ ] **Step 7: Swap the matrix row**

In `AuthorizationMatrixIT`, delete the `POST /api/tenants` row (lines 173-174). After the R43 `/admins` row, add:

```java
      // R46: tenant creation is a platform operation
      row("POST", "/api/platform/accounts/{id}/tenants", PLATFORM, Home.PLATFORM, "403,403,201,403,403,403",
          w -> json(post("/api/platform/accounts/{id}/tenants", w.customerAccount),
              "{\"name\":\"T\",\"slug\":\"pt-%s\"}".formatted(w.nonce))),
```

If the matrix has a completeness check over all mapped endpoints, it now passes because both changes are made together.

- [ ] **Step 8: Run the affected tests and the I10 scan**

Run: `./gradlew :iam-service:test --tests 'com.acme.iam.account.PlatformAccountApiIT' --tests 'com.acme.iam.tenant.TenantApiIT' --tests 'com.acme.iam.security.AuthorizationMatrixIT' --tests 'com.acme.iam.security.AccountFilterScanTest' --tests 'com.acme.iam.security.SqlInjectionIT' --tests 'com.acme.iam.account.AdminLockoutIT'`
Expected: PASS. `AccountFilterScanTest` passes with no allowlist change, because no new SQL was added.

- [ ] **Step 9: Commit**

```bash
git add -A iam-service/src
git commit -m "feat(tenant): tenant creation is platform-only: POST /api/platform/accounts/{id}/tenants, POST /api/tenants removed (R46)"
```

---

### Task 4: Invite and resend return the activation

**Files:**
- Modify: `iam-service/src/main/java/com/acme/iam/user/InvitationService.java` (`InvitationResult`, `invite`, `resend`, constructor)
- Modify: `iam-service/src/main/java/com/acme/iam/user/TenantUserController.java` (no-store)
- Modify: `iam-service/src/main/java/com/acme/iam/user/UserController.java:118-124` (no-store)
- Test: `iam-service/src/test/java/com/acme/iam/user/InvitationApiIT.java`
- Test: `iam-service/src/test/java/com/acme/iam/user/ActivationLinkDisabledIT.java` (new)

**Interfaces:**
- Consumes: `ActivationLinks.issue(...)`, `Activation` (Task 1).
- Produces:
  - `@JsonInclude(NON_NULL) record InvitationResult(UserView user, Instant invitationExpiresAt, List<UUID> assignmentIds, @Nullable Activation activation)`.
  - `InvitationService.resend(UUID accountId, UUID userId, ActivationLinks.Via via)` returning `InvitationResult`. The existing 2-arg `resend(accountId, userId)` delegates with `Via.RESEND`.

- [ ] **Step 1: Write failing tests in `InvitationApiIT`**

Add the imports `org.springframework.http.HttpHeaders` and `static org.springframework.test.web.servlet.result.MockMvcResultMatchers.header`. In `invitesWithRolesInOneTransactionAndEmailsAfterCommit`, after the existing `jsonPath` expectations, add `.andExpect(header().string(HttpHeaders.CACHE_CONTROL, "no-store"))` and `.andExpect(jsonPath("$.activation.expiresAt").isNotEmpty())`. At the end of the test, add:

```java
    assertThat(body.at("/activation/link").asText()).endsWith("token=" + raw);
    assertThat(jdbc.sql("SELECT count(*) FROM audit_event WHERE action = 'iam.invitation.link_issued' "
            + "AND target_id = :u AND metadata->>'via' = 'invite'")
        .param("u", user.toString()).query(Long.class).single()).isEqualTo(1);
```

In the resend test (around line 164), capture the response and check that the new link is the one that works:

```java
    JsonNode resent = json.readTree(mvc.perform(post("/api/users/{id}/invitation/resend", user)
            .header(AUTHORIZATION, adminBearer))
        .andExpect(status().isOk())
        .andExpect(header().string(HttpHeaders.CACHE_CONTROL, "no-store"))
        .andExpect(jsonPath("$.invitationExpiresAt").isNotEmpty())
        .andReturn().getResponse().getContentAsString());
```

and, after `String second = mailbox.lastInvitationToken(email);`:

```java
    assertThat(resent.at("/activation/link").asText()).endsWith("token=" + second);
```

The existing assertions already prove that `first` fails and `second` works.

- [ ] **Step 2: Write the switch-off IT (failing)**

```java
package com.acme.iam.user;

import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.http.HttpHeaders.AUTHORIZATION;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import com.acme.iam.common.Ids;
import com.acme.iam.common.test.CapturingNotificationAdapter;
import com.acme.iam.common.test.Fixtures;
import com.acme.iam.common.test.IntegrationTest;
import com.acme.iam.common.test.OrgTestData;
import com.acme.iam.common.test.PostgresTestBase;
import com.acme.iam.common.test.TestTokens;
import java.util.UUID;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.context.annotation.Import;
import org.springframework.http.MediaType;
import org.springframework.jdbc.core.simple.JdbcClient;
import org.springframework.test.web.servlet.MockMvc;

/** R46: with {@code iam.notification.expose-activation-link=false} links stay email-only and nothing is audited. */
@IntegrationTest(properties = "iam.notification.expose-activation-link=false")
@AutoConfigureMockMvc
@Import(CapturingNotificationAdapter.Config.class)
class ActivationLinkDisabledIT extends PostgresTestBase {

  @Autowired MockMvc mvc;
  @Autowired TestTokens tokens;
  @Autowired JdbcClient jdbc;
  @Autowired CapturingNotificationAdapter mailbox;

  @Test
  void inviteReturnsNoActivationButStillSendsTheEmail() throws Exception {
    mailbox.clear();
    OrgTestData org = new OrgTestData(jdbc);
    Fixtures.Scenario s = org.fixtures().scenario();
    UUID admin = org.accountAdmin(s.accountId(), s.tenantId());
    String bearer = org.adminBearer(tokens, admin, s.accountId(), s.tenantId());
    String email = "off-" + Ids.newId() + "@example.test";

    String body = mvc.perform(post("/api/tenants/{t}/users", s.tenantId()).header(AUTHORIZATION, bearer)
            .contentType(MediaType.APPLICATION_JSON).content("{\"email\":\"%s\"}".formatted(email)))
        .andExpect(status().isCreated())
        .andExpect(jsonPath("$.activation").doesNotExist())
        .andReturn().getResponse().getContentAsString();

    assertThat(body).doesNotContain("token=");
    assertThat(mailbox.lastInvitationToken(email)).isNotBlank();
    UUID user = org.userByEmail(s.accountId(), email).orElseThrow();
    assertThat(jdbc.sql("SELECT count(*) FROM audit_event WHERE action = 'iam.invitation.link_issued' "
            + "AND target_id = :u").param("u", user.toString()).query(Long.class).single()).isZero();
  }
}
```

- [ ] **Step 3: Run and confirm failure**

Run: `./gradlew :iam-service:test --tests 'com.acme.iam.user.InvitationApiIT' --tests 'com.acme.iam.user.ActivationLinkDisabledIT'`
Expected: `InvitationApiIT` FAILS (no `activation`, no `Cache-Control: no-store`). `ActivationLinkDisabledIT` may already pass, since nothing returns a link yet. It must stay green after Step 4.

- [ ] **Step 4: Change `InvitationService`**

Add the imports `com.fasterxml.jackson.annotation.JsonInclude` and `com.acme.iam.user.ActivationLinks.Via` (same package; use `ActivationLinks.Via`). Change the record:

```java
  /** {@code activation} is absent when {@code iam.notification.expose-activation-link=false} (R46). */
  @JsonInclude(JsonInclude.Include.NON_NULL)
  public record InvitationResult(UserView user, Instant invitationExpiresAt, List<UUID> assignmentIds,
                                 @Nullable Activation activation) {}
```

Add the field `private final ActivationLinks activationLinks;`, add it as the last constructor parameter, and assign it.

In `invite`, replace the return:

```java
    Activation activation = activationLinks.issue(invited.token(), accountId, tenantId, invited.user().id(),
        ActivationLinks.Via.INVITE);
    return new InvitationResult(UserView.of(invited.user()), invited.token().expiresAt(), assignmentIds, activation);
```

Replace `resend` with the delegating pair:

```java
  @Transactional
  public InvitationResult resend(UUID accountId, UUID userId) {
    return resend(accountId, userId, ActivationLinks.Via.RESEND);
  }

  /**
   * As {@link #resend(UUID, UUID)}, recording {@code via} on the activation-link audit event (admin recovery re-sends
   * through here, R46).
   */
  @Transactional
  public InvitationResult resend(UUID accountId, UUID userId, ActivationLinks.Via via) {
    // serialise concurrent re-sends of the same user, so exactly one token stays usable
    jdbc.sql("SELECT 1 FROM app_user WHERE id = :id AND account_id = :a FOR NO KEY UPDATE")
        .param("id", userId).param("a", accountId).query(Integer.class).optional();
    AppUser user = users.findByIdInAccount(userId, accountId)
        .orElseThrow(() -> new NotFoundException("user_not_found", "User not found"));
    if (user.status() != UserStatus.INVITED) {
      throw new ConflictException("not_invited", "Only invited users can be sent a new invitation");
    }
    tokens.invalidateOutstanding(userId, TokenPurpose.INVITE);
    IssuedToken token = tokens.issue(userId, TokenPurpose.INVITE, INVITE_TTL, RequestActor.current().userUuid());
    notifyAfterCommit(List.of(new PendingInvitation(user.email(), accounts.getById(accountId).name(),
        token.rawToken())));
    Activation activation = activationLinks.issue(token, accountId, user.primaryTenantId(), userId, via);
    return new InvitationResult(UserView.of(user), token.expiresAt(), List.of(), activation);
  }
```

Check the accessor name for the primary tenant on `AppUser` (`grep -n "primaryTenant" iam-service/src/main/java/com/acme/iam/user/AppUser.java`). It may be an `AggregateReference`. If so, use `.getId()`.

Keep the existing Javadoc on the 2-arg `resend` and move it to the first method.

- [ ] **Step 5: Add `Cache-Control: no-store` to both controllers**

In `TenantUserController.invite`, add the import `org.springframework.http.CacheControl`:

```java
    return ResponseEntity.created(URI.create(UserController.PATH + "/" + result.user().id()))
        .cacheControl(CacheControl.noStore())
        .body(result);
```

In `UserController.resendInvitation`, add the imports `org.springframework.http.CacheControl` and `org.springframework.http.ResponseEntity` if missing:

```java
  /** New INVITE token (old ones invalidated), emailed after commit; the response carries the new activation link. */
  @PostMapping("/{id}/invitation/resend")
  @PreAuthorize("hasAuthority('iam.user.manage')")
  public ResponseEntity<InvitationResult> resendInvitation(@PathVariable UUID id) {
    users.requireManageable(id, MANAGE, false);
    return ResponseEntity.ok().cacheControl(CacheControl.noStore())
        .body(invitations.resend(currentUser.accountId(), id));
  }
```

- [ ] **Step 6: Run the invitation suites, plus anything constructing `InvitationResult`**

Run: `grep -rn "new InvitationResult(" iam-service/src` and fix any other constructor call by passing `null` as the 4th argument. Bulk invite must pass `null`, because it stays email-only.

Run: `./gradlew :iam-service:test --tests 'com.acme.iam.user.*' --tests 'com.acme.iam.auth.InvitationAcceptIT' --tests 'com.acme.iam.security.AuthorizationMatrixIT'`
Expected: PASS.

- [ ] **Step 7: Commit**

```bash
git add -A iam-service/src
git commit -m "feat(user): invite and resend return the activation link with Cache-Control no-store (R46)"
```

---

### Task 5: Admin recovery returns the activation

**Files:**
- Modify: `iam-service/src/main/java/com/acme/iam/account/AdminRecoveryService.java` (`RecoveredAdmin`, `recover`, constructor)
- Modify: `iam-service/src/main/java/com/acme/iam/account/PlatformAccountController.java` (`recoverAdmin` returns `ResponseEntity` with no-store)
- Test: `iam-service/src/test/java/com/acme/iam/account/AdminLockoutIT.java`

**Interfaces:**
- Consumes: `ActivationLinks.issue(...)`, `InvitationService.resend(UUID, UUID, ActivationLinks.Via)` returning `InvitationResult` with `activation()` (Task 4).
- Produces: `@JsonInclude(NON_NULL) record RecoveredAdmin(..., String grant, @Nullable Activation activation)`. `activation` is the last component.

- [ ] **Step 1: Write failing tests in `AdminLockoutIT`**

Add the import `com.acme.iam.user.TokenPurpose` if missing. Add:

```java
  @Test
  void recoveringWithANewEmailReturnsAWorkingLink() throws Exception {
    String email = "rescue-" + Ids.newId() + "@example.test";

    MockHttpServletResponse r = recoverRaw(account, email, home, 200);
    assertThat(r.getHeader("Cache-Control")).isEqualTo("no-store");
    JsonNode body = json.readTree(r.getContentAsString());

    assertThat(body.get("invited").asBoolean()).isTrue();
    String link = body.at("/activation/link").asText();
    String raw = mailbox.lastInvitationToken(email);
    assertThat(link).endsWith("token=" + raw);
    UUID user = UUID.fromString(body.get("userId").asText());
    assertThat(tx.execute(s -> userTokens.consume(raw, TokenPurpose.INVITE).user())).isEqualTo(user);
    assertThat(jdbc.sql("SELECT count(*) FROM audit_event WHERE action = 'iam.invitation.link_issued' "
            + "AND target_id = :u AND metadata->>'via' = 'admin_recovery'")
        .param("u", user.toString()).query(Long.class).single()).isEqualTo(1);
  }

  @Test
  void aReInvitedAdminGetsALinkAndOnlyTheNewestWorks() throws Exception {
    UUID invited = fx.user(account, home, UserStatus.INVITED);
    String email = fx.email(invited);

    JsonNode first = recover(account, email, home, 200);
    mailbox.awaitCount(CapturingNotificationAdapter.Kind.INVITATION, email, 1);
    JsonNode second = recover(account, email, home, 200);
    mailbox.awaitCount(CapturingNotificationAdapter.Kind.INVITATION, email, 2);

    String firstRaw = tokenOf(first.at("/activation/link").asText());
    String secondRaw = tokenOf(second.at("/activation/link").asText());
    assertThat(secondRaw).isNotEqualTo(firstRaw).isEqualTo(mailbox.lastInvitationToken(email));
    assertThatThrownBy(() -> tx.execute(s -> userTokens.consume(firstRaw, TokenPurpose.INVITE)))
        .isInstanceOf(com.acme.iam.common.error.BadRequestException.class);
    assertThat(tx.execute(s -> userTokens.consume(secondRaw, TokenPurpose.INVITE).user())).isEqualTo(invited);
    assertThat(jdbc.sql("SELECT count(*) FROM audit_event WHERE action = 'iam.invitation.link_issued' "
            + "AND target_id = :u AND metadata->>'via' = 'admin_recovery'")
        .param("u", invited.toString()).query(Long.class).single()).isEqualTo(2);
  }

  @Test
  void recoveringAnActiveUserReturnsNoLink() throws Exception {
    UUID active = fx.user(account, home);
    JsonNode body = recover(account, fx.email(active), home, 200);
    assertThat(body.get("invited").asBoolean()).isFalse();
    assertThat(body.has("activation")).isFalse();
  }

  private static String tokenOf(String link) {
    return link.substring(link.indexOf("token=") + "token=".length());
  }
```

Add the imports `static org.assertj.core.api.Assertions.assertThatThrownBy` and `com.acme.iam.common.test.CapturingNotificationAdapter` if missing (it is already `@Import`ed). If `mailbox.awaitCount` takes different argument types, mirror its use in `InvitationApiIT:167`.

- [ ] **Step 2: Run and confirm failure**

Run: `./gradlew :iam-service:test --tests 'com.acme.iam.account.AdminLockoutIT'`
Expected: the three new tests FAIL (no `activation`, no `Cache-Control: no-store`).

- [ ] **Step 3: Change `AdminRecoveryService`**

Add the imports `com.acme.iam.user.Activation`, `com.acme.iam.user.ActivationLinks` and `com.fasterxml.jackson.annotation.JsonInclude`. Change the record:

```java
  /**
   * What the recovery did. {@code invitationExpiresAt} is set when an invitation was (re)sent; {@code activation} then
   * carries the link (R46), unless {@code iam.notification.expose-activation-link=false}.
   */
  @JsonInclude(JsonInclude.Include.NON_NULL)
  public record RecoveredAdmin(UUID accountId, UUID tenantId, UUID userId, String email, boolean invited,
      @Nullable Instant invitationExpiresAt, boolean tenantReactivated, boolean userReactivated,
      boolean primaryTenantChanged, String grant, @Nullable Activation activation) {}
```

`@JsonInclude(NON_NULL)` also drops `invitationExpiresAt` when it is `null`. `AdminLockoutIT` only asserts `invitationExpiresAt` when `invited` is true, but check with `grep -n invitationExpiresAt iam-service/src/test` that no test expects an explicit `null`. If one does, put `@JsonInclude(NON_NULL)` on the `activation` component only, instead of the record.

Add the field `private final ActivationLinks activationLinks;`, add it as the last constructor parameter, and assign it.

In `recover`, declare `Activation activation = null;` next to `invitationExpiresAt`. In the new-user branch, after `invitationExpiresAt = created.token().expiresAt();`:

```java
      activation = activationLinks.issue(created.token(), accountId, tenantId, userId,
          ActivationLinks.Via.ADMIN_RECOVERY);
```

In the existing-INVITED branch, replace the resend line with:

```java
        InvitationResult resent = invitations.resend(accountId, userId, ActivationLinks.Via.ADMIN_RECOVERY);
        invitationExpiresAt = resent.invitationExpiresAt();
        activation = resent.activation();
        invited = true;
```

Add the import `com.acme.iam.user.InvitationService.InvitationResult`. Pass `activation` as the last constructor argument of `RecoveredAdmin` in the return.

The audit for the existing-user path is filed under `user.primaryTenantId()`, which `ensureUsableMembership` has just set to the recovery tenant when it changed. That is acceptable.

- [ ] **Step 4: Add no-store to `PlatformAccountController.recoverAdmin`**

```java
  public ResponseEntity<AdminRecoveryService.RecoveredAdmin> recoverAdmin(@PathVariable UUID id,
      @Valid @RequestBody RecoverAdminRequest request) {
    requirePlatformCaller();
    return ResponseEntity.ok().cacheControl(CacheControl.noStore())
        .body(recovery.recover(id, request.email(), request.tenantId()));
  }
```

Append to its Javadoc: *"When it invites, the response carries the activation link (R46) and is not cached."*

- [ ] **Step 5: Run the recovery suite**

Run: `./gradlew :iam-service:test --tests 'com.acme.iam.account.AdminLockoutIT' --tests 'com.acme.iam.security.AuthorizationMatrixIT'`
Expected: PASS.

- [ ] **Step 6: Commit**

```bash
git add -A iam-service/src
git commit -m "feat(account): admin recovery returns the activation link when it invites (R46)"
```

---

### Task 6: End-to-end test, OpenAPI, docs, full build

**Files:**
- Modify: `e2e-tests/src/test/java/com/acme/iam/e2e/ExitCriteriaE2ETest.java` (orders 3 and 4)
- Modify: `docs/openapi.json` (regenerated)
- Modify: `docs/plans/phase-1-decisions.md` (R46)
- Modify: `docs/security-review.md` (bearer-link row)
- Modify: `docs/runbooks/recover-account-admin.md`, `docs/runbooks/bootstrap-platform-admin.md` (mention the link and the request shape)

**Interfaces:**
- Consumes: every endpoint from Tasks 2–5.

- [ ] **Step 1: Update `ExitCriteriaE2ETest`**

Order 3: replace the create call and the id extraction. The admin activates through the returned link:

```java
    Response created = Http.post(a + "/api/platform/accounts", platformToken, Map.of(
        "name", "Acme", "slug", "acme",
        "defaultTenant", Map.of("name", "Acme HQ", "slug", "hq"),
        "defaultUser", Map.of("email", ADMIN, "displayName", "Ada"),
        "products", List.of(Map.of("code", "BILLING", "status", "ACTIVE",
            "startsAt", LocalDate.now(ZoneOffset.UTC).minusDays(1).toString()))));
    assertThat(created.status()).as(created.toString()).isEqualTo(201);
    account = UUID.fromString(created.text("/account/id"));
    t1 = UUID.fromString(created.text("/defaultTenant/id"));
    admin = UUID.fromString(created.text("/defaultUser/id"));

    String link = created.text("/activation/link");
    adminToken = acceptToken(link.substring(link.indexOf("token=") + "token=".length()), ADMIN);
```

Split the existing `accept(String email)` helper so that the token-based path is reusable:

```java
  private String accept(String email) {
    return acceptToken(smtp.awaitToken(email), email);
  }

  private String acceptToken(String token, String email) {
    Response accepted = Http.post(a + "/auth/invitations/accept", null,
        Map.of("token", token, "password", PASSWORD, "displayName", email.substring(0, email.indexOf('@'))));
    assertThat(accepted.status()).as(accepted.toString()).isEqualTo(200);
    return accepted.text("/accessToken");
  }
```

Order 4: rename the test to `thePlatformCreatesASecondTenantAndTheAccountAdminInvitesSharesCreatesARoleAndAssignsAtBothScopes`. Replace the tenant POST:

```java
    Response tenant = Http.post(a + "/api/platform/accounts/" + account + "/tenants", platformToken,
        Map.of("name", "Europe", "slug", "europe", "products", List.of(Map.of("code", "BILLING", "enabled", true))));
    assertThat(tenant.status()).as(tenant.toString()).isEqualTo(201);
    t2 = UUID.fromString(tenant.text("/id"));
    assertThat(Http.post(a + "/api/tenants", adminToken, Map.of("name", "X", "slug", "x")).status())
        .as("customers no longer create tenants (R46)").isEqualTo(405);
```

If the `smtp` mailbox later asserts an exact count of messages to `ADMIN`, it is unaffected: the email is still sent.

- [ ] **Step 2: Run the E2E suite**

Run: `./gradlew :e2e-tests:test`
Expected: PASS. It builds the boot jars; this takes a few minutes.

- [ ] **Step 3: Regenerate OpenAPI**

Run: `IAM_OPENAPI_UPDATE=true ./gradlew :iam-service:test --tests '*OpenApiSpecIT'`, then `./gradlew :iam-service:test --tests '*OpenApiSpecIT'`.
Expected: the second run PASSES. `git diff --stat docs/openapi.json` shows the changed schemas: `CreateAccountRequest`, `CreatedAccount`, `InvitationResult`, `RecoveredAdmin`, the new `/api/platform/accounts/{id}/tenants` path, and `POST /api/tenants` removed.

- [ ] **Step 4: Record R46 in `docs/plans/phase-1-decisions.md`**

Append after R45, in the same one-line style:

```markdown
- R46 (post-Phase-1, spec docs/superpowers/specs/2026-10-13-account-onboarding-design.md) account bootstrap takes `defaultTenant {name, slug}` and `defaultUser {email, displayName?}` from the request (no hard-coded "Default"/`default`); tenant creation is platform-only (`POST /api/platform/accounts/{id}/tenants`, 409 `account_not_active` unless ACTIVE), `POST /api/tenants` removed; account bootstrap, tenant invite, invitation resend and admin recovery (when it invites) return `activation {link, expiresAt}` (`Cache-Control: no-store`, audited as `iam.invitation.link_issued` without token, switch `iam.notification.expose-activation-link`, default true); bulk invite stays email-only. Supersedes the Phase 1 exit criterion "the account admin can create tenants" — cost if wrong: one config flag flip / one endpoint to restore.
```

- [ ] **Step 5: Update `docs/security-review.md` and the runbooks**

Add a row to the findings or risks table in `docs/security-review.md`, matching the table's columns:

> **R46 activation links in API responses.** The link embeds a 7-day single-use INVITE token, so whoever calls the create/invite/resend/recovery API can activate the user. Mitigations: operator/admin-only endpoints, `Cache-Control: no-store`, one live token per user (resend invalidates), `iam.invitation.link_issued` audit (no token stored), no body logging in the service, and `iam.notification.expose-activation-link=false` to keep links email-only. **Status:** accepted.

In `docs/runbooks/recover-account-admin.md`, after the curl example, add: *"When the recovery invites (`invited: true`), the response's `activation.link` is the same link the email carries. Hand it to the new admin over a trusted channel if the email cannot be relied on. It is valid for 7 days and only the newest one works."*

In `docs/runbooks/bootstrap-platform-admin.md`, where it mentions `POST /api/platform/accounts`, add: *"The request names the default tenant and default user (`defaultTenant`, `defaultUser`); the response returns the user's `activation.link`. Additional tenants are created with `POST /api/platform/accounts/{id}/tenants`."*

- [ ] **Step 6: Full build**

Run: `./gradlew build`
Expected: BUILD SUCCESSFUL, with all module tests green (the timing tests are excluded by R45).

- [ ] **Step 7: Commit**

```bash
git add -A e2e-tests docs
git commit -m "test(e2e)+docs: exit-criteria flow uses platform tenant create and returned activation link; OpenAPI, R46, security review, runbooks"
```
