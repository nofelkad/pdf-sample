# Phase 1 — Multi-agent execution plan

**Spec (binding authority):** `01-phase-1.md` (and `00-overview.md`). This file only groups the spec's tasks into
agent-sized work packages, fixes the cross-package contracts so packages can be built in parallel, and records rulings
where the spec is silent. When this file and the spec disagree, the spec wins unless a `Ruling:` below says otherwise.

Spec section line ranges in `01-phase-1.md` (read only what your task needs):
§1 Architecture 8–54 · §2 Schema 58–383 · §3 Spring Data JDBC patterns 387–452 · §4 Auth & tokens 456–558 ·
§5 Authorization engine 562–623 · §6 Audit 627–641 · §7 iam-client 645–656 · §8 Task table 660–787 · §10 Exit criteria 806–814.
Performance targets: `00-overview.md` lines 102–115.

Scope: **backend only** (no admin UI).

## Execution waves

| Wave | Tasks (parallel within a wave, each in its own git worktree) |
|---|---|
| 0 | Task 1 |
| 1 | Task 2, Task 3 |
| 2 | Task 4, Task 5, Task 6, Task 7, Task 8 |
| 3 | Task 9, Task 10 |

Each wave starts from `main` after the previous wave's branches are merged.

---

## Global Constraints

**Build & runtime**
- Gradle (Kotlin DSL) multi-project with wrapper, Gradle 8.14.x. A cached distribution exists at
  `~/.gradle/wrapper/dists/gradle-8.14.4-bin/*/gradle-8.14.4/bin/gradle` (no system gradle/maven installed).
  `~/.gradle/gradle.properties` sets a corporate truststore — do not override it.
- Java 21 toolchain, Spring Boot latest 3.5.x, Spring Data JDBC (no JPA/Hibernate anywhere), Flyway, PostgreSQL 16.
- Modules: `iam-core` (plain Java library, no Spring Boot auto-config, minimal deps), `iam-service` (the Boot app),
  `iam-client` (Boot starter). Task 8 adds `sample-app`.
- Base package `com.acme.iam` (service), `com.acme.iam.core` (core), `com.acme.iam.client` (starter).
- Package-by-feature exactly as spec §1: `common, account, tenant, product, user, role, assignment, auth, audit`,
  plus `appclient` (Ruling R5).
- IDs: UUIDv7 generated in Java via `com.github.f4b6a3:uuid-creator` (`UuidCreator.getTimeOrderedEpoch()`), exposed as
  `com.acme.iam.common.Ids.newId()`. `version == null` ⇒ insert.
- Tests: JUnit 5 + AssertJ + Testcontainers `postgres:16-alpine`, one shared (singleton) container per JVM via the
  base classes from Task 1. Docker Desktop is the runtime. Every task's tests must pass with `./gradlew build`.
- Logging is JSON (logstash encoder or Boot structured logging). Never log passwords, tokens, refresh tokens, hashes,
  private keys or `Authorization` headers.

**Database**
- Migrations under `iam-service/src/main/resources/db/migration`. Version numbers reserved per task so parallel work
  never collides: Task 1 `V1–V3` (+ `V4` roles/grants if needed), Task 3 `V5–V9`, Task 2 `V10–V19`, Task 4 `V20–V29`,
  Task 5 `V30–V39`, Task 6 `V40–V49`, Task 7 `V50–V59`, Tasks 9/10 `V60+`. Never edit a migration owned by another task;
  add a new one in your range.
- DB roles (P1-2.3): Flyway runs as `iam_migrator` (owner/DDL); the app datasource runs as `iam_app`
  (DML only; `INSERT, SELECT` only on `audit_event`). DDL the app needs at runtime (partition create/detach) goes
  through `SECURITY DEFINER` functions owned by the migrator with `EXECUTE` granted to `iam_app` (Ruling R3).
- Every write runs inside a transaction managed by `AuditContextTransactionManager` (spec §3), so the `iam_audit()`
  trigger sees `app.user_id/account_id/tenant_id/request_id/session_id`.
- Keyset pagination only (no OFFSET) for list endpoints.

**Shared contracts (names are binding — later tasks compile against them)**

| Contract | Owner | Shape |
|---|---|---|
| `common.Ids.newId()` | T1 | UUIDv7 |
| `common.RequestActor` | T1 | `record RequestActor(String userId, String accountId, String tenantId, String requestId, String sessionId)` + `static RequestActor current()` (SecurityContext JWT claims + MDC `requestId`; all-null ⇒ SYSTEM) |
| `common.error.ApiException` | T1 | `RuntimeException` carrying `HttpStatus status`, `String code` (machine code, e.g. `last_admin`), `String detail`, `Map<String,Object> properties`; subclasses `NotFoundException`, `ConflictException`, `BadRequestException`, `ForbiddenException`. Global handler renders RFC 7807 `ProblemDetail` with `code`, `requestId` and properties. |
| `audit.AuditWriter` | T1 | `void write(AuditEvent e)` — direct insert into `audit_event` in the caller's transaction (REQUIRED propagation); `AuditEvent` record + builder; redaction deny-list applied to `metadata`/`before`/`after` (keys containing password, secret, token, hash, private, authorization — case-insensitive) |
| Test base classes | T1 | `common.test.PostgresTestBase` (singleton Testcontainer, `@DynamicPropertySource`), `@IntegrationTest` meta-annotation (`@SpringBootTest` + test profile) and `@JdbcSliceTest` (`@DataJdbcTest` + container) |
| Aggregates + repositories | T2 | Spec §0 overview table + §3 patterns; repository per aggregate root in its feature package |
| `assignment.PermissionResolver` | T2 | `Set<String> resolve(UUID userId, UUID tenantId)` — exactly the spec §5 SQL; also `List<PermissionGrant> explain(UUID userId, UUID tenantId)` returning permission → role → scope rows from the **same** predicate (exit criterion: JWT perms == explain) |
| `assignment.AssignmentService` | T2 | `RoleAssignment assign(AssignCommand cmd)` enforcing I1, I3, I6, I8 (grantor = current actor); `RoleAssignment grantAsSystem(UUID userId, UUID roleId, ScopeType, UUID scopeId, @Nullable UUID grantedBy, @Nullable Instant expiresAt)` skipping I6 (bootstrap only, still I1/I3/I8) |
| `user.UserTokenService` | T2 | `IssuedToken issue(UUID userId, TokenPurpose purpose, Duration ttl, @Nullable UUID createdBy)` returns raw token once (256-bit random, base64url) and stores SHA-256; `UserToken consume(String rawToken, TokenPurpose purpose)` single-use, throws `BadRequestException(code=invalid_token)` if unknown/expired/used; `invalidateOutstanding(UUID userId, TokenPurpose)` |
| `user.NotificationPort` | T2 | `sendInvitation(String email, String accountName, String rawToken)`, `sendPasswordReset(String email, String rawToken)`; adapters: SMTP (`spring-boot-starter-mail`, active when `iam.notification.mode=smtp`) and `LoggingNotificationAdapter` (default; logs the event **without** the token) plus a test-only `CapturingNotificationAdapter` in test sources that records tokens for E2E tests |
| `common.security.SigningKeyService`, `JwtIssuer` | T3 | `JwtIssuer.issueAccessToken(AccessTokenClaims)` → spec §4 claims; `issueAppToken(AppClient)` |
| `auth.RevocationService` | T3 | `revokeUsers(Collection<UUID> userIds, String reason)`, `revokeAccountUsers(UUID accountId, String reason)`, `revokeTenantMembers(UUID tenantId, String reason)`, `revokeRoleHolders(UUID roleId, String reason)` — set-based `UPDATE … RETURNING` + `INSERT … SELECT`, batches of 5,000, same transaction; `List<RevocationEntry> since(long cursor, int limit)` |
| `com.acme.iam.core.revocation.RevocationRegistry` | T3 | in-memory `userId → minSv`; `apply(List<RevocationEntry>)`, `isRevoked(UUID userId, int sv)`, `lastCursor()` — used by both iam-service and iam-client |
| `common.security.TenantGuard` | T3 | `requireActive(UUID tenantId)` and `requireActive(UUID tenantId, String permission)` (Ruling R2) |
| `common.security.CurrentUser` | T3 | accessor over the JWT: `userId(), accountId(), tenantId(), sessionId(), sessionVersion(), permissions(), isApp()` |
| Internal app token | T3 | `POST /internal/token` (HTTP Basic `clientId:secret`, form `grant_type=client_credentials`) → `{access_token, token_type:"Bearer", expires_in:600}`; JWT `sub="app:<clientId>"`, `typ="app"`, `prd=<productCode>`, `perms=["internal.revocations.read","internal.audit.write","internal.manifest.write"]` |
| `GET /internal/revocations?since={id}` | T3 | `{entries:[{id,userId,minSv}], cursor}`; requires `internal.revocations.read` |

**Security rules**
- Code checks permissions, never roles (`@PreAuthorize("hasAuthority('…')")`). Every `/api/**` and `/internal/**`
  endpoint carries an explicit `@PreAuthorize` (or is listed as intentionally authenticated-only, e.g. `/api/me`).
- Active tenant comes from the token, never from the request body/query.
- I10: every admin-service query filters by the caller's `acc` (platform endpoints excepted).
- Request bodies are validated with Jakarta Validation; errors are RFC 7807.

---

## Rulings (pre-execution)

- **R1** iam-core module — Ruling: add a plain-Java `iam-core` module holding `RevocationRegistry`, `DataScope` and claim-name constants, used by both iam-service and iam-client — spec P1-10.2 asks for "same code as iam-client" but the service cannot include the auto-configuring starter — cost if wrong: one extra small module to fold back.
- **R2** TenantGuard semantics — Ruling: a path tenant ≠ token `tid` is allowed only when the tenant belongs to the token's `acc` and the caller holds an unexpired ACCOUNT-scope assignment (for the overload: one whose role contains the given permission) — spec says "account-scope override" without defining it — cost if wrong: guard logic change in one class.
- **R3** Runtime DDL — Ruling: partition create/detach via `SECURITY DEFINER` functions owned by `iam_migrator` — spec gives `iam_app` DML only yet needs runtime partition jobs — cost if wrong: swap to a maintenance datasource.
- **R4** Shared kernel in Task 2 — Ruling: `AssignmentService.assign/grantAsSystem`, `PermissionResolver`, `UserTokenService`, `NotificationPort` are built before Wave 2 so Tasks 4–6 compile against them in parallel — cost if wrong: none functionally; ordering only.
- **R5** `appclient` package + internal token (P1-12.1) moved into Task 3 — `/internal/*` callers (Tasks 6, 7, 8) all need it — cost if wrong: none.
- **R6** Load test (P1-11.2) — Ruling: deliver the Gatling simulations, the bulk data generator (1M users / 5M assignments / 20M audit rows) and a **scaled-down** smoke run on the laptop; the full-scale run on 2 instances is left to a perf environment and reported as not-yet-run — cost if wrong: perf targets unverified until run.
- **R7** CI (P1-1.3) — Ruling: a GitHub Actions workflow (build, test, coverage via JaCoCo, image via `bootBuildImage`) plus `docker-compose.yml`; the image push step is written but not executed — no remote/registry exists — cost if wrong: workflow tweaks.
- **R8** iam-client outbox migration — Ruling: the starter ships `db/iam-client/V1_000__iam_audit_outbox.sql` and auto-config appends `classpath:db/iam-client` to Flyway locations — cost if wrong: host apps with conflicting version numbers rename.

---

## Task 1: Foundation — project, schema, common layer
Wave 0. Spec tasks **P1-1.1–1.6, P1-2.1–2.4, P1-9.1**. Read spec §1, §2, §3, §6 and the P1-1/P1-2/P1-9.1 rows of §8.

Deliver:
1. Gradle multi-project (`iam-core`, `iam-service`, `iam-client` skeleton with empty auto-config), wrapper committed, version catalog `gradle/libs.versions.toml` declaring **every** dependency Phase 1 needs (Boot starters web, data-jdbc, security, oauth2-resource-server, oauth2-jose, validation, actuator, mail, aop; flyway-core + flyway-database-postgresql; postgresql; shedlock-spring + shedlock-provider-jdbc-template; bucket4j postgresql module; uuid-creator; bouncycastle (Argon2); springdoc-openapi; micrometer-registry-prometheus; logstash-logback-encoder; jackson; Testcontainers postgresql + junit-jupiter; ArchUnit; Gatling plugin left for Task 10) so later tasks rarely touch build files.
2. `docker-compose.yml` (Postgres 16 with init script creating `iam_migrator` and `iam_app`), `.github/workflows/ci.yml` (R7), JaCoCo.
3. `V1__core.sql`, `V2__audit.sql` (trigger function, `app_user` noise filter, **initial partitions for the current month + 3 ahead**, and `SECURITY DEFINER` `audit_ensure_partitions(months_ahead int)` per R3), `V3__seed.sql`, plus grants (`iam_app` INSERT/SELECT only on `audit_event`; default privileges for future tables). Schema text verbatim from spec §2.
4. `common`: RFC 7807 global handler + `ApiException` family, request-id filter (`X-Request-Id` in/out, MDC), JSON logging, `JdbcConfig` (JSONB↔`Map<String,Object>` and JSONB↔`JsonNode`, CITEXT, enums, `@EnableJdbcAuditing`, `AuditorAware<UUID>`), `Ids`, `RequestActor`, `AuditContextTransactionManager` as the primary transaction manager.
5. `audit.AuditWriter` + `AuditEvent` (P1-9.1).
6. Test infra base classes; ArchUnit rules (no cross-package repository access; controllers depend only on services; `..repository..`/`*Repository` used only inside own feature package).
7. `IamApplication` boots against compose Postgres with Flyway as migrator and app as `iam_app`.

Done when: `./gradlew build` green; tests prove (a) `app.user_id` visible inside a tx and empty after commit, (b) insert/update/delete on each audited table yields exactly one audit row, no-op update on `app_user` (only `last_login_at`/`failed_logins`) yields none, (c) `UPDATE audit_event` fails as `iam_app`, (d) every response has `X-Request-Id`, (e) ArchUnit rules run in the build.

## Task 2: Domain core — aggregates, read models, kernel services
Wave 1 (parallel with Task 3). Spec tasks **P1-3.1–3.4, P1-7.4**, plus kernel services per R4. Read spec §2, §3, §5 and `00-overview.md` domain model.

Deliver:
1. All aggregates as records with owned collections and repositories (Account+AccountProduct, Tenant+TenantProduct, Product, Permission, AppUser+Membership, UserToken, PasswordHistory, UserSession, Role+RolePermission, RoleAssignment) in their feature packages. Round-trip tests; optimistic-lock conflict test.
2. Read models with `JdbcClient` (P1-3.4): user list (filter by tenant/status/role, keyset), role list with assignment counts.
3. `PermissionResolver.resolve` + `explain` (shared predicate, single source of SQL truth). `EXPLAIN` the query and add any missing index in `V10+`.
4. `AssignmentService.assign` (I1, I3, I6, I8) and `grantAsSystem`; unit/integration tests per invariant.
5. `UserTokenService`, `NotificationPort` + adapters (contracts table).

Done when: build green; each invariant I1, I3, I6, I8 has a failing-path test; resolver test covers tenant vs account scope, expired assignment, disabled `tenant_product`, expired subscription, suspended tenant/account, deprecated permission, inactive membership, and IAM-always-entitled.

## Task 3: Security foundation, revocation, app clients
Wave 1 (parallel with Task 2). Spec tasks **P1-4.1–4.5, P1-10.1, P1-10.2, P1-12.1**. Read spec §1, §4 (Spring Security setup), §5 Revocation, §7 last paragraph.

Deliver:
1. `SigningKeyService` (RSA-2048, AES-GCM private key with master key from `iam.security.master-key` / env `IAM_MASTER_KEY`, base64 32 bytes; dev/test default in profile config only), JWKSource over ACTIVE+PUBLISHED with 60 s refresh, `/.well-known/jwks.json`. Generates the first key on startup if none (ShedLock-guarded).
2. Rotation job/command (P1-4.2) with the PUBLISHED(24 h)→ACTIVE→PUBLISHED→RETIRED lifecycle; test that old-key tokens validate during overlap.
3. `JwtIssuer`, `SecurityConfig` (two chains as in spec §4; JWT alg pinned to RS256), `permsConverter`, method security, `CurrentUser`.
4. `TenantGuard` (R2), auditing `AccessDeniedHandler` + `AuthenticationEntryPoint` writing `authz.denied` via `AuditWriter`.
5. `RevocationService` + `GET /internal/revocations` + purge job (rows > 1 h), `RevocationRegistry` in iam-core, in-service poller (5 s, startup loads last 20 min, reads DB directly) and `RevocationFilter` (`401`, `WWW-Authenticate: Bearer error="token_revoked"`); app tokens (`typ=app`) skip the revocation check.
6. `app_client` table (`V5`), `AppClientService` (secret hashed with Argon2 or SHA-256+salt; shown once), platform registration API `POST/GET/DELETE /api/platform/app-clients` (`platform.account.manage`), `POST /internal/token`.

Done when: build green; tests: `@PreAuthorize` allow/deny, denial produces `authz.denied` row, revoked token rejected after poll, JWKS serves both keys during rotation overlap, internal token obtains revocations.

## Task 4: Authentication
Wave 2. Spec tasks **P1-5.1–5.9**. Read spec §4 fully, §5 Revocation, §6 Audit (auth rows).
Builds on: `PermissionResolver`, `UserTokenService`, `NotificationPort` (T2); `JwtIssuer`, `RevocationService`, `CurrentUser`, `SecurityConfig` (T3). Owns `/auth/**` endpoints including `/auth/invitations/accept` and `/api/me`. Migrations `V20–V29`.
Done when: every spec P1-5 "done when" holds; E2E: login → refresh → reuse old refresh revokes session → switch tenant → logout → next request 401; forgot/reset flow via `CapturingNotificationAdapter`; 429 with `Retry-After`; timing test known vs unknown email within 10%; every §4 endpoint emits its `auth.*` audit event.

## Task 5: Accounts, tenants, users, memberships, invitations
Wave 2. Spec tasks **P1-6.1–6.4, P1-8.1–8.4**. Read spec §4 (TenantGuard usage), §5 invariants I2, I4, I5, I7, I9, I10 and Revocation, §8 rows P1-6/P1-8.
Builds on: aggregates/read models, `AssignmentService` (invite-with-roles and bootstrap use `assign`/`grantAsSystem`), `UserTokenService`, `NotificationPort` (T2); `RevocationService`, `TenantGuard`, `CurrentUser` (T3). Does **not** own `/auth/invitations/accept` (Task 4) — the INVITE token contract is `UserTokenService` with purpose `INVITE`, TTL 7 days. Migrations `V30–V39`.
Done when: P1-6/P1-8 "done when" criteria hold; I2, I4, I5, I7 (disable path), I9 tests; bulk invite 5,000 rows < 30 s in test.

## Task 6: Registry, roles, assignments API, explain
Wave 2. Spec tasks **P1-7.1–7.3, P1-10.3–10.6**. Read spec §2 (`iam-manifest.yaml`), §5, §8 rows P1-7/P1-10.
Builds on: `PermissionResolver`, `AssignmentService` (T2); `RevocationService`, internal token (T3). Adds revoke (I7), list by user/role/tenant, expiry job, explain endpoint, manifest apply/upload, role API. Migrations `V40–V49`.
Done when: applying the same manifest twice yields 0 changes (and 0 audit rows); editing a role revokes all holders; I3, I7, I8 tests; explain output equals `PermissionResolver.resolve` for the same user/tenant.

## Task 7: Audit jobs, ingest, search, export
Wave 2. Spec tasks **P1-9.2–9.7**. Read spec §2 `V2__audit.sql`, §6.
Builds on: `AuditWriter` (T1), internal token (T3). Migrations `V50–V59` (detach function per R3, export job table).
Done when: partition job keeps 3 future months; retention job detaches+drops only after the archive hook succeeds; ingest idempotent on `event_id` with deny-list; search filters + keyset + 92-day window + account filter; target history; streamed CSV export of 1M rows without OOM (test with a smaller row count + bounded heap assertion or fetch-size check), export itself audited.

## Task 8: iam-client starter + sample app
Wave 2. Spec tasks **P1-12.2–12.6**. Read spec §5 Data scope + Revocation, §6 last bullet, §7.
Builds on: `RevocationRegistry`, claim constants (iam-core, T3); internal token + `/internal/revocations` contract (T3); `/internal/audit/events` (T7) and `PUT /internal/products/{code}/manifest` (T6) **by contract only** (test against WireMock or a stub server; real end-to-end in Task 9).
Done when: sample app authorizes from an IAM JWT, applies `DataScope`, writes `@Audited` events through the outbox, relay retries so a 10-min IAM outage loses no events (simulated), uploads its manifest at startup; README integration guide.

## Task 9: Hardening I — authorization matrix, exit-criteria E2E, security review
Wave 3. Spec tasks **P1-11.1, P1-11.3, P1-11.4**, I10 test, and the §10 exit criteria as an executable E2E suite (including sample-app ↔ iam-service in one test).
Done when: matrix covers 100% of endpoints and an unannotated endpoint fails the build; exit-criteria suite green; security review findings fixed and listed in `docs/security-review.md`; failure behaviour documented in `docs/failure-modes.md`.

## Task 10: Hardening II — observability, OpenAPI, runbooks, load test
Wave 3. Spec tasks **P1-11.2 (per R6), P1-11.5, P1-11.6**.
Done when: Micrometer metrics listed in P1-11.5 exposed via `/actuator/prometheus` with health groups; springdoc OpenAPI at `/v3/api-docs`; runbooks in `docs/runbooks/` (key rotation, force logout user/account, unlock user, audit partition missing); Gatling module + data generator committed with a scaled-down smoke run's results recorded in `docs/perf/README.md`.
