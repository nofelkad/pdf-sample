# Phase 1 — decisions made during execution

Every ruling the orchestrator made on the user's behalf while executing `docs/plans/phase-1-execution.md`, in the order made, each with its reason and what it costs if wrong. R1–R8 are in the execution plan; R9 onward were made during the build. "Parked" items are final-review residuals accepted rather than fixed.

## Rulings

- R0 parallel waves in git worktrees despite skill's "no parallel implementers" — user explicitly requested multi-agent execution; conflicts contained by package-by-feature + reserved migration ranges — cost if wrong: merge-conflict resolution effort.
- pull minors #3 (spec §6 auditWriter.read API missing) and #4 (malformed actorIp aborts caller tx) into fix round 1 — both are load-bearing for Tasks 4/9 which call AuditWriter in login/sensitive-read paths — cost if wrong: slightly larger fix round.
- R9 app-client attribution — T3 adds V6 migration making iam_audit() take source from tx setting app.source (default 'IAM') and AuditContextTransactionManager sets app.source='app:<clientId>' for typ=app tokens — reviewer flagged app-client writes recorded as anonymous SYSTEM — cost if wrong: one trigger function revision.
- R10 T3 also ships test helper common.test.TestTokens (mint access/app JWTs in tests) and ShedLock LockProvider config — every Wave-2 task needs both — cost if wrong: none.
- R11 I6 at TENANT scope — grantor's held permissions = resolve(grantor, tenant) ∪ resolveAccountScope(grantor, tenant.account) — an Account Admin must be able to grant in tenants they're not a member of; spec's "at that scope" intends account-scope grants to cover tenants — cost if wrong: one-line revert.
- R12 common.error maps wrapped unique violations (DbActionExecutionException → DuplicateKeyException) to 409 globally — Spring Data JDBC wraps them, so every Wave-2 write would otherwise 500 — goes into T2 fix round — cost if wrong: none.
- R13 revocation ordering — revoke* performs all app_user UPDATEs (ordered by id) first, takes the feed advisory lock only immediately before the single INSERT into revocation, and stays the caller's last write — removes the lock-then-wait-on-row cycle while keeping commit-ordered ids — cost if wrong: switch to xid8-horizon poller.
- R2 amended — remove TenantGuard.requireActive(tenantId) one-arg overload; callers always pass the @PreAuthorize permission — reviewer showed cross-tenant permission leak — cost if wrong: none (stricter).
- R14 audit invalid-token 401s (bad signature/issuer/kid/expired) as authz.denied-like `auth.token.invalid`; missing-token 401s not audited; tenant_mismatch thrown as AccessDeniedException subclass so it is audited `authz.denied` and rendered with code — spec §6 "every denial" — cost if wrong: audit noise from expired tokens (accepted).
- R15 exclude session_version from app_user update trigger WHEN clause (V8) and have RevocationService write one `auth.sessions.revoked` audit event per call (reason, count, user ids capped at 1000; target = user when single) — avoids 50k rows per role edit while keeping traceability — cost if wrong: per-user trail only via summary event.
- R16 accept unsalted SHA-256 for 256-bit random app-client secrets (salt adds nothing at that entropy), accept issueAppToken(String clientId, String productCode), accept advisory lock for first-key bootstrap — cost if wrong: none material.
- R11 refined — TENANT-scope I6 "held" = resolve(grantor,T) ∪ grantor's unexpired ACCOUNT-scope assignments in T's account filtered by T's entitlement (tenant ACTIVE, tenant_product enabled, subscription valid; no membership join). Plain union with resolveAccountScope rejected (ignores tenant_product) — cost if wrong: one query.
- pull minors 1 (I10 fail-open on null acc), 2 (foreign custom role id enumeration), 3 (grantAsSystem ignores tenant status), 5 (concurrent consume test), 6 (unknown user → 500), 8 (notification mode enum) into T2 fix round 1 with R12 — security/fail-fast items cheap while implementer context is warm — cost if wrong: slightly longer round.
- R17 sessions on disable/deprovision/suspend — callers only call revoke*; T4 refresh/switch re-checks user/account/tenant/membership ACTIVE and marks the session revoked — avoids T5 touching auth's user_session in parallel — cost if wrong: sessions linger in DB until next refresh attempt (tokens already dead via sv).
- R18 pre-Wave-2 mini task (Task 3b): assignment.LastAdminService (I7 query + guard) on phase-1 before Wave 2, since T5 (disable path) and T6 (revoke path) both need it in parallel — cost if wrong: ~15 min serial.
- R19 T4 owns new user.UserCredentialService for credential/login writes on app_user so T4 and T5 don't both edit UserService — cost if wrong: one extra service class.
- fold Task 3 re-review minors (a) scope-loop early stop on concurrent delete, (b) fail-fast guard: at most one revoke* per tx + javadoc says deadlock, (d) FOR NO KEY UPDATE instead of FOR UPDATE into Task 3b — Wave 2 adds the first real callers — cost if wrong: none.
- R20 T6 loads iam-manifest.yaml during context refresh (before ApplicationRunners) so T5's bootstrap CLI finds system roles — cost if wrong: bootstrap ordering bug caught in T9 E2E.
- R21 audit CSV export (P1-9.7) is a streamed download (StreamingResponseBody + fetchSize, cursor in one tx), not a stored async job — no object storage allowed and local files break statelessness — cost if wrong: long downloads hold a connection.
- R22 T4: reused refresh token → revoke that session AND revokeUsers([user]); logout → revoke session + revokeUsers([user]) so "next request 401" holds (sv is per-user; other devices refresh once) — cost if wrong: extra refresh on other devices.
- R23 T5 bootstrap CLI prints the invitation link to stdout only when notification mode is LOG (fresh install without SMTP) — cost if wrong: token visible in container stdout once.
- R24 manifest-upload and audit-ingest JSON contracts fixed in wave2-context.md so T6/T7 and T8 build in parallel — cost if wrong: T9 integration fix.
- R25 audit search/export data scope — caller sees account-wide audit only if they hold iam.audit.read (resp. iam.audit.export) via an unexpired ACCOUNT-scope assignment; otherwise tenant_id is forced to token tid and other tenant filters → 403 scope_exceeded — Tenant Admin/Auditor hold iam.audit.read at tenant scope and JWT perms carry no scope — cost if wrong: tenant-scoped auditors see less than intended.
- R26 ingest source = prd claim (spec "source = calling app"); extra `index` in rejected entries accepted as additive — cost if wrong: none.
- R27 (amends R8) iam-client migrations run through their own Flyway instance with table `iam_client_schema_history` and location classpath:db/iam-client, so versions never collide with the host app's — V1_000 in the shared history forces hosts to start at V2 / out-of-order — cost if wrong: one extra Flyway bean.
- R28 account-wide user actions (disable/enable/deprovision/profile update/change primary tenant) need iam.user.manage via ACCOUNT-scope assignment, unless every membership of the target user is in the caller's active tenant (tenant-local user), where tenant-scope holding suffices — Tenant Admins must not disable shared users account-wide — cost if wrong: tenant admins can't manage some users (use membership removal instead).
- R29 stale bulk jobs — RUNNING jobs older than a timeout are marked FAILED by a ShedLock sweep + at startup — cost if wrong: none.
- R30 concurrent refresh with the same token stays strict reuse → revoke (spec P1-5.3 / §4 "Reusing an old refresh token revokes the whole session"); clients must serialise refresh — documented in API docs — cost if wrong: multi-tab clients occasionally logged out.
- R31 forgot-password must not reveal account existence by timing: token issue + email dispatch happen off the request thread (after-commit async) and the request path does equal work for known/unknown emails — spec P1-11.3 lists reset enumeration — cost if wrong: none.
- R32 accept iam-client failing startup fast on missing/malformed local manifest file (documented deviation from "never fails startup", which targets IAM reachability) — cost if wrong: none.
- R33 tenant management (iam.tenant.manage) is account-level: all write/list endpoints require ACCOUNT-scope holding — custom TENANT-scope grants must not create/list account tenants — cost if wrong: a custom tenant-scoped tenant manager can't edit its own tenant.
- R34 accept switch-tenant inaccessible target → 403 tenant_not_accessible keeping session; reset rate-limited per IP only; /api/me & JWKS unaudited; per-candidate Argon2 capped at 20 (documented) — cost if wrong: minor.
- R35 (amends T4 dispatch) behind trusted proxies use the right-most XFF entry that is not a trusted proxy — first entry is client-controlled — cost if wrong: none.
- R36 actuator on separate management port (default 8081, network-restricted); main port exposes only liveness/readiness — prometheus was open on the main port — assigned to T9 after T10 merge.
- R37 add force-logout endpoints (user: iam.session.revoke + R28 scope; account: platform) — spec defines iam.session.revoke and runbook needs it — T9.
- R38 add unlock endpoint (iam.user.manage + R28) — runbook "unlock user" — T9.
- R39 add app-client secret rotation endpoint — T9. Master-key rotation recorded as known Phase-1 gap.
- R40 I6 exemption for product SYSTEM roles — a grantor holding iam.role.assign at the target scope (ACCOUNT scope → account-scope holding; TENANT scope → TenantGuard) may assign SYSTEM roles of non-IAM products that are entitled for the account (and enabled for the tenant at TENANT scope) without holding their permissions; IAM SYSTEM roles and all CUSTOM roles keep full I6 — literal I6 makes product roles ungrantable by anyone (nobody holds billing.*), blocking the exit criterion — cost if wrong: weaker separation of duties for product roles (any role-assigner can hand out product admin roles); reversible by reverting the exemption. Goes into T9 fix round.
- R41 default revocation poll interval lowered to 2 s in iam-service and iam-client so the shipped defaults meet "within 5 s" — cost if wrong: 2.5x poll queries (one indexed query per tick per instance).
- R42 the resolver includes DATA permissions ending in `.account` only when they come from an ACCOUNT-scope assignment (explain uses the same predicate), so JWT perms are truthful for DataScope — cost if wrong: a tenant-scoped grant of a .account permission silently grants nothing (documented in manifest-format.md + iam-client README).
- R43 I7 counts only non-expiring admin grants; suspending/archiving a tenant that is the primary tenant of every remaining effective admin → 409 last_admin; add platform recovery endpoint POST /api/platform/accounts/{id}/admins {email, tenantId} (reactivates a SUSPENDED tenant, invites or reuses+reactivates the user, grants Account Admin via grantAsSystem, audited) + runbook — cost if wrong: one more platform endpoint.
- R44 notification mode=log outside dev/local/test logs a startup WARN (not fail); SMTP mode with a localhost public base URL fails fast; add docs/deployment.md config reference — cost if wrong: none.
- R45 timing-tagged tests excluded from `build`, run via separate `timingTest` task — cost if wrong: timing regressions caught only when that task runs.
- R46 (post-Phase-1, spec docs/superpowers/specs/2026-10-13-account-onboarding-design.md) account bootstrap takes `defaultTenant {name, slug}` and `defaultUser {email, displayName?}` from the request (no hard-coded "Default"/`default`); tenant creation is platform-only (`POST /api/platform/accounts/{id}/tenants`, 409 `account_not_active` unless ACTIVE), `POST /api/tenants` removed; account bootstrap, tenant invite, invitation resend and admin recovery (when it invites) return `activation {link, expiresAt}` (a re-send only when the caller holds every role of the invitee at the same scope, else email only; `Cache-Control: no-store`, audited as `iam.invitation.link_issued` without token, switch `iam.notification.expose-activation-link`, default true); bulk invite stays email-only. Supersedes the Phase 1 exit criterion "the account admin can create tenants" — cost if wrong: one config flag flip / one endpoint to restore.
- Parked: PLATFORM-account recovery runbook points to bootstrap CLI which refuses once bootstrapped — Ruling: documented as known gap (DBA procedure needed) — cost if wrong: platform lockout needs manual SQL.
- Parked: pre-V60 audit rows keep actor attribution — Ruling: accepted (audit is immutable) — cost: historical rows misfiled for tenant-scoped auditors.
- Parked: lock-order inversion suspend/archive (account FOR SHARE then I7) vs recovery (I7 then account) — Ruling: accepted; needs a third exclusive writer, Postgres detects, @RetryOnDeadlock on recovery — cost: rare 40P01.
- Parked: R42 makes TENANT-scope holders of custom roles with x.read.account unable to re-grant them — Ruling: accepted (stricter, not a hole).
- Parked: single-user tenant-wide revocation summary filed under user's primary tenant — Ruling: accepted cosmetic.
- Parked: purge query OR-branch unindexed — Ruling: accepted at hourly LIMIT 5000.
- Parked: admin lockout still reachable via suspend-then-disable sequence or changePrimary race (I7 doesn't consider "can log in") — Ruling: recovery endpoint is the backstop per R43; a stricter I7 needs a product decision — cost: operator must use recovery endpoint.

## Accepted residuals (parked after the final review)

- PLATFORM-account recovery runbook points to bootstrap CLI which refuses once bootstrapped — Ruling: documented as known gap (DBA procedure needed) — cost if wrong: platform lockout needs manual SQL.
- pre-V60 audit rows keep actor attribution — Ruling: accepted (audit is immutable) — cost: historical rows misfiled for tenant-scoped auditors.
- lock-order inversion suspend/archive (account FOR SHARE then I7) vs recovery (I7 then account) — Ruling: accepted; needs a third exclusive writer, Postgres detects, @RetryOnDeadlock on recovery — cost: rare 40P01.
- R42 makes TENANT-scope holders of custom roles with x.read.account unable to re-grant them — Ruling: accepted (stricter, not a hole).
- single-user tenant-wide revocation summary filed under user's primary tenant — Ruling: accepted cosmetic.
- purge query OR-branch unindexed — Ruling: accepted at hourly LIMIT 5000.
- admin lockout still reachable via suspend-then-disable sequence or changePrimary race (I7 doesn't consider "can log in") — Ruling: recovery endpoint is the backstop per R43; a stricter I7 needs a product decision — cost: operator must use recovery endpoint.

## Deferred minor findings

Minor review findings not fixed in Phase 1; the final review triaged each as fine to defer or already resolved.

- Task 1: minor (deferred): ArchUnit "controllers only call services" enforced only cross-feature (ArchitectureRules.java:115-135)
- Task 1: minor (deferred): @JdbcSliceTest doesn't carry container; relies on extending PostgresTestBase (fail-fast mitigates)
- Task 1: minor (deferred): DataIntegrityViolationException (non-duplicate) → 500 instead of 409/400 (GlobalExceptionHandler.java:87-93)
- Task 1: minor (deferred): default DB credentials in application.yml outside a local profile
- Task 1: minor (deferred): logback masking uses exact field names (clientSecret/newPassword not masked)
- Task 1: minor (deferred): audit_ensure_partitions check-then-create race (advisory lock) — T7 ShedLock guards
- Task 1: minor (deferred): AuditEvent exposes mutable maps
- Task 1: minor (deferred): static AuditWriter.redact DEFAULT_MAPPER renders Instant as number; IPv6 check not byte-identical to PG inet
- Task 1: minor (deferred): AuditWriter.read() inside @Transactional(readOnly=true) caller fails INSERT — first caller (T7 export / T9) must not be readOnly or use REQUIRES_NEW
- Task 3: minor (deferred): AppTokenController.invalidClient duplicates GlobalExceptionHandler problem-body logic
- Task 3: minor (deferred): app client hard delete; add DISABLED path for incident response
- Task 2: minor (deferred): *PlanIT plan-shape assertions may flake with planner changes
- Task 2: minor (deferred): concurrentConsumersExactlyOneWins leaves committed fixture rows
- Task 3: minor (deferred): pre-V7 signing_key rows not backfilled (hypothetical; no pre-T3 keys exist)
- Task 3: minor (deferred): auth.token.invalid audit per request can inflate volume (edge rate limiting)
- Task 3: minor (deferred): rotation command starts full app (doc --spring.main.web-application-type=none) — T10 runbook
- Task 3: minor (deferred): \p{Cntrl} misses Unicode format chars; coded.auditMetadata() putAll can overwrite method/path/reason
- Task 3: minor (deferred): row-order 40P01 still possible between caller and bulk revoke — document retry
- Task 3b: minor (deferred): waitUntilSomeoneWaitsOnALock returns silently; filler assertion in assignmentLevelCheck; no assignment-level concurrency test; guard test only covers revokeUsers path; IN(:ids) batch size cap
- Task 3b: minor (deferred): no test for unknown-user-passes branch in requireNotLastAdmin; guard silently off when tx synchronization inactive (comment only)
- Task 7: minor (deferred): export permit leak on executor rejection; per-instance (not per-account) export cap; 30-min async timeout is app-wide; heap test System.gc flakiness; plan IT page-2 assertion weaker than claimed; ingest dedup key (occurred_at,event_id) — same eventId w/ different occurredAt stored twice; any app can write events into any account (source truthful) — document for T8/T9
- Task 6: minor (deferred → T9): no 40P01 deadlock retry at HTTP entry points (cross-cutting retry aspect); role delete vs assign FK race surfaces as 409 conflict via R12
- Task 8: minor (deferred): requestIp uses getRemoteAddr; relay holds DB connection during HTTP (~12 s bounded); TaskDecorator silently skipped when host defines one; relay wedge if T7 response undercounts — verify in T9 E2E
- Task 7: minor (deferred → T9): resolveTenant with null tid and no account scope falls back to account-wide (unreachable today: user tokens always carry tid, app tokens lack iam.audit.read) — fail closed in T9
- Task 5: minor (deferred → T9): AssignmentService doesn't reject DEPROVISIONED/DISABLED target users; user_exists reveals users in other tenants (product decision); PlatformAccountApiIT order-sensitive if tests ever run in parallel
- Task 4: minor (deferred): reuse detection only one rotation back (schema limit, documented); trigger rows during reset/accept show SYSTEM actor; timing test in default build (CI flake risk)
- Task 8: minor (deferred): staleAfter javadoc says DOWN (now DEGRADED); 408/429 logged as ERROR "no progress"; host ObjectMapper customisations shape outbox payload (undocumented); host-defined Flyway bean → ordering not guaranteed (migrate=false escape documented)
- Task 5: minor (deferred): archive of archived tenant returns 200 no-op; requireNotClosed on unlocked load; concurrent deprovisions both run (idempotent); reissue IT doesn't prove old token invalidated
- Task 4: minor (deferred): null client IP → refresh/reset unlimited (low impact); per-instance mail executor ordering; RateLimitIT mixes lock + limit
- Task 5: minor (deferred → T9): grant FOR SHARE on user row vs revoker NKU bump can 40P01 (assignment delete racing same-key grant; role delete racing grant) — covered by T9 40P01 retry aspect; profile update/primary change/resend/share rely on controller-time R28 check only
- Task 4: minor (deferred → T9/T10): spring.mail smtp connection/read/write timeouts unset (hung socket pins sender thread); send timeout not counted in a metric; InvitationAcceptService ignores recordSuccessfulLogin boolean
- Task 10: minor (deferred): OpenApiDevOnlyIT doesn't boot dev profile and fetch /v3/api-docs
- Task 10: minor (deferred): bulk_invite_job not cleaned by --reset; startedAt JVM clock vs DB created_at skew; cumulative counts in server-side summaries
- Task 9: minor (deferred): observability.md poll.age row says readiness uses same clock (no longer true); entitlement date basis differs (DB CURRENT_DATE vs UTC clock) at ends_at boundary; requireProductSystemRoleScope ordering gives tenant_mismatch instead of grantor_lacks_permissions; spec 01-phase-1.md still says poll every 5 s (R41 → 2 s); publicAuthEndpointsNeedNoToken weak
