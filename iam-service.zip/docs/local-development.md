# Running iam-service locally

Everything needs Docker (PostgreSQL) and JDK 21. Commands run from the repository root.

## Development (`dev` profile)

```
docker compose up -d                                   # PostgreSQL 16 on localhost:5442 (IAM_DB_PORT to change)
SPRING_PROFILES_ACTIVE=dev ./gradlew :iam-service:bootRun
```

The `dev` profile (`application-dev.yml`) supplies the docker-compose database passwords, a development issuer
(`http://localhost:8080`) and master key, and turns on the OpenAPI document (`/v3/api-docs`) and Swagger UI. The API is
on port 8080, actuator (health, info, prometheus) on the management port 8081 (ruling R36). First user:
`./gradlew :iam-service:bootRun --args='--spring.profiles.active=dev --spring.main.web-application-type=none
--bootstrap-platform-admin=email=you@example.com'` (with `iam.notification.mode=log`, the default, the accept link is
printed). Reset the database with `docker compose down -v`.

## Other local runs (`local` profile)

`local` (`application-local.yml`) only supplies the docker-compose database passwords; issuer and master key come from
`IAM_ISSUER` / `IAM_MASTER_KEY`. It is what `load-test/scripts/start-iam.sh` and the runbooks' "from a checkout"
commands use.

```
IAM_ISSUER=http://localhost:8080 IAM_MASTER_KEY=<base64 32 bytes> \
  java -jar iam-service/build/libs/iam-service-0.1.0-SNAPSHOT.jar --spring.profiles.active=local
```

## Without a profile

Production behaviour: `IAM_DB_APP_PASSWORD`, `IAM_DB_MIGRATOR_PASSWORD`, `IAM_ISSUER` and `IAM_MASTER_KEY` are
required, and `DatabaseCredentialsGuard` refuses to start with a missing or well-known password (`iam_app`,
`iam_migrator`, ...). The E2E suite (`e2e-tests`) runs the jar this way. Every required setting is listed in
[deployment.md](deployment.md).

## Tests

```
./gradlew build          # every module's tests, including the e2e-tests suite; excludes @Tag("timing")
./gradlew timingTest     # only the @Tag("timing") tests (LoginTimingIT, ForgotPasswordTimingIT)
```

The timing tests compare wall-clock medians (P1-5.2 / P1-11.3 enumeration resistance) and are sensitive to machine
load, so `build` leaves them out (ruling R45). Run `timingTest` on a quiet machine before a release and after any change
to login, forgot-password or the password hashing settings; CI runs it as a separate, non-blocking step.
