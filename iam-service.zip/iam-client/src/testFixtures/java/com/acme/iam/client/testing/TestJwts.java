package com.acme.iam.client.testing;

import com.nimbusds.jose.JOSEException;
import com.nimbusds.jose.JWSAlgorithm;
import com.nimbusds.jose.JWSHeader;
import com.nimbusds.jose.JWSSigner;
import com.nimbusds.jose.crypto.RSASSASigner;
import com.nimbusds.jose.jwk.RSAKey;
import com.nimbusds.jose.jwk.gen.RSAKeyGenerator;
import com.nimbusds.jwt.JWTClaimsSet;
import com.nimbusds.jwt.SignedJWT;
import java.time.Clock;
import java.time.Duration;
import java.time.Instant;
import java.util.Date;
import java.util.List;
import java.util.UUID;

/**
 * Mints RS256 tokens shaped like IAM's (spec section 4) with a locally generated key; serve {@link #key()} from the
 * {@link StubIamServer} JWKS.
 */
public final class TestJwts {

  private final RSAKey key;
  private final String issuer;
  private final Clock clock;

  public TestJwts(RSAKey key, String issuer, Clock clock) {
    this.key = key;
    this.issuer = issuer;
    this.clock = clock;
  }

  public TestJwts(RSAKey key, String issuer) {
    this(key, issuer, Clock.systemUTC());
  }

  public static RSAKey newKey(String kid) {
    try {
      return new RSAKeyGenerator(2048).keyID(kid).generate();
    } catch (JOSEException e) {
      throw new IllegalStateException(e);
    }
  }

  public RSAKey key() {
    return key;
  }

  public UserToken user(UUID userId) {
    return new UserToken(userId);
  }

  /** Application token as issued by {@code POST /internal/token}. */
  public String app(String clientId, String product) {
    Instant now = clock.instant();
    return sign(
        new JWTClaimsSet.Builder()
            .issuer(issuer)
            .subject("app:" + clientId)
            .claim("typ", "app")
            .claim("prd", product)
            .claim("perms", List.of("internal.revocations.read", "internal.audit.write", "internal.manifest.write"))
            .issueTime(Date.from(now))
            .expirationTime(Date.from(now.plus(Duration.ofMinutes(10))))
            .jwtID(UUID.randomUUID().toString())
            .build(),
        key.getKeyID());
  }

  public String sign(JWTClaimsSet claims, String kid) {
    return sign(claims, key, JWSAlgorithm.RS256, kid);
  }

  public static String sign(JWTClaimsSet claims, RSAKey signingKey, JWSAlgorithm alg, String kid) {
    try {
      JWSSigner signer = new RSASSASigner(signingKey);
      SignedJWT jwt = new SignedJWT(new JWSHeader.Builder(alg).keyID(kid).build(), claims);
      jwt.sign(signer);
      return jwt.serialize();
    } catch (JOSEException e) {
      throw new IllegalStateException(e);
    }
  }

  /** Builder of user access tokens; defaults: random account/tenant/session, sv 1, no permissions, 15 min. */
  public final class UserToken {
    private final UUID userId;
    private UUID account = UUID.randomUUID();
    private UUID tenant = UUID.randomUUID();
    private UUID session = UUID.randomUUID();
    private int sv = 1;
    private List<String> perms = List.of();
    private String issuerOverride;
    private Instant issuedAt;
    private Instant expiresAt;
    private String kid;

    private UserToken(UUID userId) {
      this.userId = userId;
    }

    public UserToken account(UUID account) {
      this.account = account;
      return this;
    }

    public UserToken tenant(UUID tenant) {
      this.tenant = tenant;
      return this;
    }

    public UserToken session(UUID session) {
      this.session = session;
      return this;
    }

    public UserToken sv(int sv) {
      this.sv = sv;
      return this;
    }

    public UserToken perms(String... perms) {
      this.perms = List.of(perms);
      return this;
    }

    public UserToken issuer(String issuer) {
      this.issuerOverride = issuer;
      return this;
    }

    public UserToken expiresAt(Instant expiresAt) {
      this.expiresAt = expiresAt;
      return this;
    }

    public UserToken issuedAt(Instant issuedAt) {
      this.issuedAt = issuedAt;
      return this;
    }

    public UserToken kid(String kid) {
      this.kid = kid;
      return this;
    }

    public JWTClaimsSet.Builder claims() {
      Instant now = clock.instant();
      Instant iat = issuedAt != null ? issuedAt : now;
      Instant exp = expiresAt != null ? expiresAt : iat.plus(Duration.ofMinutes(15));
      return new JWTClaimsSet.Builder()
          .issuer(issuerOverride != null ? issuerOverride : issuer)
          .subject(userId.toString())
          .claim("acc", account.toString())
          .claim("tid", tenant.toString())
          .claim("sid", session.toString())
          .claim("sv", sv)
          .claim("perms", perms)
          .issueTime(Date.from(iat))
          .expirationTime(Date.from(exp))
          .jwtID(UUID.randomUUID().toString());
    }

    public String mint() {
      return sign(claims().build(), kid != null ? kid : key.getKeyID());
    }

    public String bearer() {
      return "Bearer " + mint();
    }
  }
}
