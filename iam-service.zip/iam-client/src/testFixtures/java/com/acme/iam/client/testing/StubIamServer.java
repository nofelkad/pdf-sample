package com.acme.iam.client.testing;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.nimbusds.jose.jwk.JWK;
import com.nimbusds.jose.jwk.JWKSet;
import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpServer;
import java.io.IOException;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Collections;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Stand-in for iam-service in tests of the client starter, implementing the HTTP contracts of the wave-2 context:
 * JWKS, {@code POST /internal/token}, {@code GET /internal/revocations}, {@code POST /internal/audit/events} (idempotent
 * on {@code eventId}) and {@code PUT /internal/products/{code}/manifest}. Failure modes: {@link #stop()} (connection
 * refused until {@link #start()}), {@link #failAudit(int)} (HTTP status for every ingest call), {@link
 * #failManifest(int, int)}.
 */
public final class StubIamServer implements AutoCloseable {

  public static final String CLIENT_ID = "billing-app";
  public static final String CLIENT_SECRET = "s3cret-for-tests";
  public static final String PRODUCT = "BILLING";

  private static final ObjectMapper MAPPER = new ObjectMapper();

  /** One revocation feed row. */
  public record Revocation(long id, UUID userId, int minSv) {}

  /** One request received by the stub. */
  public record Received(String method, String path, String query, String body) {}

  private final int port;
  private HttpServer server;

  private volatile JWKSet jwks = new JWKSet();
  private final Set<String> validTokens = Collections.synchronizedSet(new HashSet<>());
  private final AtomicInteger tokenRequests = new AtomicInteger();
  private final AtomicInteger jwksRequests = new AtomicInteger();
  private volatile long tokenExpiresIn = 600;

  private final List<Revocation> revocations = new CopyOnWriteArrayList<>();
  private final List<Received> revocationRequests = new CopyOnWriteArrayList<>();
  private volatile int revocationsStatus = 200;
  private volatile boolean revocationFeedIgnoresLimit;

  private final Map<String, Integer> auditEvents = Collections.synchronizedMap(new LinkedHashMap<>());
  private final List<Integer> auditBatchSizes = new CopyOnWriteArrayList<>();
  private final AtomicInteger auditRequests = new AtomicInteger();
  private final Set<String> rejectEventIds = Collections.synchronizedSet(new HashSet<>());
  private volatile int auditFailStatus;
  private volatile boolean auditUnderReporting;

  private final List<Received> manifests = new CopyOnWriteArrayList<>();
  private final AtomicInteger manifestRequests = new AtomicInteger();
  private volatile int manifestFailStatus;
  private final AtomicInteger manifestFailuresRemaining = new AtomicInteger();

  public StubIamServer() {
    this(0);
  }

  private StubIamServer(int port) {
    try {
      this.server = create(port);
      this.port = server.getAddress().getPort();
    } catch (IOException e) {
      throw new IllegalStateException(e);
    }
  }

  private HttpServer create(int port) throws IOException {
    HttpServer s = HttpServer.create(new InetSocketAddress(InetAddress.getLoopbackAddress(), port), 0);
    s.createContext("/", this::handle);
    s.setExecutor(Executors.newFixedThreadPool(8, r -> {
      Thread t = new Thread(r, "stub-iam");
      t.setDaemon(true);
      return t;
    }));
    s.start();
    return s;
  }

  public String baseUrl() {
    return "http://localhost:" + port;
  }

  public int port() {
    return port;
  }

  /** Stops listening: connections are refused until {@link #start()}. */
  public synchronized void stop() {
    if (server != null) {
      server.stop(0);
      server = null;
    }
  }

  /** Listens again on the same port. */
  public synchronized void start() {
    if (server == null) {
      try {
        server = create(port);
      } catch (IOException e) {
        throw new IllegalStateException(e);
      }
    }
  }

  @Override
  public void close() {
    stop();
  }

  // ---- configuration -------------------------------------------------------------------------------------------

  public void setPublicKeys(JWK... keys) {
    this.jwks = new JWKSet(List.of(keys)).toPublicJWKSet();
  }

  public void setTokenExpiresIn(long seconds) {
    this.tokenExpiresIn = seconds;
  }

  /** Makes every previously issued app token invalid (IAM answers 401 to them). */
  public void invalidateIssuedTokens() {
    validTokens.clear();
  }

  public void setRevocations(List<Revocation> rows) {
    revocations.clear();
    revocations.addAll(rows);
  }

  public void addRevocation(Revocation row) {
    revocations.add(row);
  }

  public void failRevocations(int status) {
    this.revocationsStatus = status;
  }

  /** {@code 0} = healthy; otherwise every ingest call answers with this status. */
  public void failAudit(int status) {
    this.auditFailStatus = status;
  }

  /** IAM answers 200 but accounts for one event less than it received (a misbehaving server). */
  public void setAuditUnderReporting(boolean value) {
    this.auditUnderReporting = value;
  }

  /** Event ids IAM rejects (per-event validation failure). */
  public void rejectEvent(String eventId) {
    rejectEventIds.add(eventId);
  }

  /** The next {@code times} manifest uploads answer with {@code status}. */
  public void failManifest(int status, int times) {
    manifestFailStatus = status;
    manifestFailuresRemaining.set(times);
  }

  public void reset() {
    start();
    validTokens.clear();
    tokenRequests.set(0);
    jwksRequests.set(0);
    tokenExpiresIn = 600;
    revocations.clear();
    revocationRequests.clear();
    revocationsStatus = 200;
    auditEvents.clear();
    auditBatchSizes.clear();
    auditRequests.set(0);
    rejectEventIds.clear();
    auditFailStatus = 0;
    auditUnderReporting = false;
    manifests.clear();
    manifestRequests.set(0);
    manifestFailuresRemaining.set(0);
  }

  // ---- observations --------------------------------------------------------------------------------------------

  public int tokenRequests() {
    return tokenRequests.get();
  }

  public int jwksRequests() {
    return jwksRequests.get();
  }

  public List<Received> revocationRequests() {
    return List.copyOf(revocationRequests);
  }

  /** eventId to number of times it was delivered (accepted or duplicate). */
  public Map<String, Integer> auditEvents() {
    synchronized (auditEvents) {
      return new LinkedHashMap<>(auditEvents);
    }
  }

  public List<Integer> auditBatchSizes() {
    return List.copyOf(auditBatchSizes);
  }

  public int auditRequests() {
    return auditRequests.get();
  }

  public List<Received> manifests() {
    return List.copyOf(manifests);
  }

  public int manifestRequests() {
    return manifestRequests.get();
  }

  // ---- HTTP ----------------------------------------------------------------------------------------------------

  private void handle(HttpExchange ex) throws IOException {
    try {
      String path = ex.getRequestURI().getPath();
      String method = ex.getRequestMethod();
      String body = new String(ex.getRequestBody().readAllBytes(), StandardCharsets.UTF_8);
      if (path.equals("/.well-known/jwks.json") && method.equals("GET")) {
        jwksRequests.incrementAndGet();
        send(ex, 200, jwks.toString());
      } else if (path.equals("/internal/token") && method.equals("POST")) {
        token(ex, body);
      } else if (path.startsWith("/internal/")) {
        if (!authorized(ex)) {
          send(ex, 401, "{\"code\":\"invalid_token\"}");
          return;
        }
        if (path.equals("/internal/revocations") && method.equals("GET")) {
          revocations(ex);
        } else if (path.equals("/internal/audit/events") && method.equals("POST")) {
          audit(ex, body);
        } else if (path.matches("/internal/products/[^/]+/manifest") && method.equals("PUT")) {
          manifest(ex, path, body);
        } else {
          send(ex, 404, "{\"code\":\"not_found\"}");
        }
      } else {
        send(ex, 404, "{\"code\":\"not_found\"}");
      }
    } catch (RuntimeException e) {
      send(ex, 500, "{\"code\":\"internal_error\",\"detail\":\"" + e.getClass().getSimpleName() + "\"}");
    } finally {
      ex.close();
    }
  }

  private void token(HttpExchange ex, String body) throws IOException {
    tokenRequests.incrementAndGet();
    String expected = "Basic " + Base64.getEncoder()
        .encodeToString((CLIENT_ID + ":" + CLIENT_SECRET).getBytes(StandardCharsets.UTF_8));
    String contentType = ex.getRequestHeaders().getFirst("Content-Type");
    if (!expected.equals(ex.getRequestHeaders().getFirst("Authorization"))) {
      ex.getResponseHeaders().add("WWW-Authenticate", "Basic realm=\"iam\"");
      send(ex, 401, "{\"code\":\"invalid_client\"}");
    } else if (contentType == null || !contentType.startsWith("application/x-www-form-urlencoded")
        || !body.equals("grant_type=client_credentials")) {
      send(ex, 400, "{\"code\":\"invalid_request\"}");
    } else {
      String token = "app-token-" + UUID.randomUUID();
      validTokens.add(token);
      send(ex, 200, "{\"access_token\":\"" + token + "\",\"token_type\":\"Bearer\",\"expires_in\":" + tokenExpiresIn + "}");
    }
  }

  private boolean authorized(HttpExchange ex) {
    String header = ex.getRequestHeaders().getFirst("Authorization");
    return header != null && header.startsWith("Bearer ") && validTokens.contains(header.substring(7));
  }

  private void revocations(HttpExchange ex) throws IOException {
    String query = ex.getRequestURI().getRawQuery();
    revocationRequests.add(new Received("GET", ex.getRequestURI().getPath(), query, ""));
    if (revocationsStatus != 200) {
      send(ex, revocationsStatus, "{\"code\":\"unavailable\"}");
      return;
    }
    Map<String, String> params = queryParams(query);
    long since = params.containsKey("since") ? Long.parseLong(params.get("since")) : 0;
    int limit = params.containsKey("limit") ? Integer.parseInt(params.get("limit")) : 1000;
    ObjectNode out = MAPPER.createObjectNode();
    ArrayNode entries = out.putArray("entries");
    long cursor = since;
    int count = 0;
    for (Revocation r : revocations) {
      if (r.id() > since && count < limit) {
        entries.addObject().put("id", r.id()).put("userId", r.userId().toString()).put("minSv", r.minSv());
        cursor = r.id();
        count++;
      }
    }
    out.put("cursor", cursor);
    send(ex, 200, out.toString());
  }

  private void audit(HttpExchange ex, String body) throws IOException {
    auditRequests.incrementAndGet();
    if (auditFailStatus != 0) {
      send(ex, auditFailStatus, "{\"code\":\"unavailable\"}");
      return;
    }
    JsonNode events = MAPPER.readTree(body).path("events");
    if (events.size() > 500) {
      send(ex, 400, "{\"code\":\"batch_too_large\"}");
      return;
    }
    int accepted = 0;
    int duplicates = 0;
    ArrayNode rejected = MAPPER.createArrayNode();
    synchronized (auditEvents) {
      for (JsonNode event : events) {
        String id = event.path("eventId").asText();
        if (rejectEventIds.contains(id)) {
          rejected.addObject().put("eventId", id).put("reason", "invalid_action");
        } else if (auditEvents.containsKey(id)) {
          auditEvents.merge(id, 1, Integer::sum);
          duplicates++;
        } else {
          auditEvents.put(id, 1);
          accepted++;
        }
      }
    }
    auditBatchSizes.add(events.size());
    if (auditUnderReporting) {
      accepted = Math.max(0, accepted - 1);
    }
    ObjectNode out = MAPPER.createObjectNode().put("accepted", accepted).put("duplicates", duplicates);
    out.set("rejected", rejected);
    send(ex, 200, out.toString());
  }

  private void manifest(HttpExchange ex, String path, String body) throws IOException {
    manifestRequests.incrementAndGet();
    if (manifestFailuresRemaining.getAndUpdate(n -> Math.max(0, n - 1)) > 0) {
      send(ex, manifestFailStatus, "{\"code\":\"unavailable\"}");
      return;
    }
    manifests.add(new Received("PUT", path, null, body));
    String code = path.split("/")[3];
    send(ex, 200, "{\"product\":\"" + code
        + "\",\"changed\":true,\"permissionsAdded\":2,\"permissionsUpdated\":0,\"permissionsDeprecated\":0,\"rolesChanged\":1}");
  }

  private static Map<String, String> queryParams(String query) {
    Map<String, String> params = new LinkedHashMap<>();
    if (query != null) {
      for (String pair : query.split("&")) {
        String[] kv = pair.split("=", 2);
        params.put(kv[0], kv.length > 1 ? kv[1] : "");
      }
    }
    return params;
  }

  private static void send(HttpExchange ex, int status, String body) throws IOException {
    byte[] bytes = body.getBytes(StandardCharsets.UTF_8);
    ex.getResponseHeaders().add("Content-Type", "application/json");
    ex.sendResponseHeaders(status, bytes.length);
    ex.getResponseBody().write(bytes);
  }

  /** Helper for tests that need a list of events delivered so far, in arrival order. */
  public List<String> deliveredEventIds() {
    return new ArrayList<>(auditEvents().keySet());
  }
}
