package com.acme.iam.client.testing;

import javax.sql.DataSource;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.test.context.DynamicPropertyRegistry;
import org.springframework.test.context.DynamicPropertySource;
import org.testcontainers.containers.PostgreSQLContainer;
import org.testcontainers.utility.DockerImageName;

/**
 * Base class for tests that need PostgreSQL: one {@code postgres:16-alpine} container per JVM (singleton, removed by
 * Testcontainers' Ryuk), exposed as the application's {@code spring.datasource.*} (Flyway uses the same role).
 */
public abstract class PostgresTestBase {

  protected static final PostgreSQLContainer<?> POSTGRES =
      new PostgreSQLContainer<>(DockerImageName.parse("postgres:16-alpine"))
          .withDatabaseName("app_db")
          .withUsername("app")
          .withPassword("app_test");

  static {
    POSTGRES.start();
  }

  @DynamicPropertySource
  static void postgresProperties(DynamicPropertyRegistry registry) {
    registry.add("spring.datasource.url", POSTGRES::getJdbcUrl);
    registry.add("spring.datasource.username", POSTGRES::getUsername);
    registry.add("spring.datasource.password", POSTGRES::getPassword);
  }

  /**
   * Unpooled connections whose default schema is {@code schema} (created on demand), so a test can own tables without
   * disturbing Flyway in the {@code public} schema of Spring contexts that share this container.
   */
  public static DataSource dataSource(String schema) {
    new org.springframework.jdbc.core.JdbcTemplate(dataSource()).execute("CREATE SCHEMA IF NOT EXISTS " + schema);
    String url = POSTGRES.getJdbcUrl();
    url += (url.contains("?") ? "&" : "?") + "currentSchema=" + schema;
    return new DriverManagerDataSource(url, POSTGRES.getUsername(), POSTGRES.getPassword());
  }

  /** Unpooled connections to the test database. */
  public static DataSource dataSource() {
    return new DriverManagerDataSource(POSTGRES.getJdbcUrl(), POSTGRES.getUsername(), POSTGRES.getPassword());
  }
}
