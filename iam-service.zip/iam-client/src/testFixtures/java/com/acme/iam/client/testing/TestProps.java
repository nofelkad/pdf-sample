package com.acme.iam.client.testing;

import com.acme.iam.client.IamClientProperties;
import java.time.Duration;
import java.util.List;

/** {@link IamClientProperties} for unit tests, pointing at a {@link StubIamServer}. */
public final class TestProps {

  private TestProps() {}

  public static IamClientProperties of(StubIamServer stub) {
    return of(stub, new IamClientProperties.Relay(Duration.ofMillis(20), 500, Duration.ofMillis(200), Duration.ofMinutes(1)));
  }

  public static IamClientProperties of(StubIamServer stub, IamClientProperties.Relay relay) {
    return new IamClientProperties(
        stub.baseUrl(),
        null,
        null,
        StubIamServer.CLIENT_ID,
        StubIamServer.CLIENT_SECRET,
        StubIamServer.PRODUCT,
        null,
        false,
        Duration.ofSeconds(60),
        List.of("/actuator/health/**"),
        new IamClientProperties.Http(Duration.ofSeconds(1), Duration.ofSeconds(3)),
        new IamClientProperties.Jwks(Duration.ofMinutes(5), Duration.ofMillis(200), Duration.ofHours(1)),
        new IamClientProperties.Revocation(Duration.ofMillis(50), Duration.ofMinutes(20), Duration.ofSeconds(60), 1000),
        new IamClientProperties.Audit(true, true, relay),
        new IamClientProperties.Manifest(Duration.ofMillis(50), Duration.ofMillis(200)));
  }
}
