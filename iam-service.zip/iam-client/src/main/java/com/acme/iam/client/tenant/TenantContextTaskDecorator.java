package com.acme.iam.client.tenant;

import java.util.Map;
import org.slf4j.MDC;
import org.springframework.core.task.TaskDecorator;

/**
 * Copies the {@link TenantContext} and the MDC of the submitting thread to the task's thread and clears them
 * afterwards, so {@code @Async} work (and anything run on a decorated executor) acts for the same user and tenant
 * without leaking identity to the next task on a pooled thread. Spring Boot applies a single {@link TaskDecorator}
 * bean to its auto-configured {@code applicationTaskExecutor}; add it to custom executors with
 * {@code executor.setTaskDecorator(decorator)}.
 */
public class TenantContextTaskDecorator implements TaskDecorator {

  @Override
  public Runnable decorate(Runnable runnable) {
    TenantContext captured = TenantContext.current().orElse(null);
    Map<String, String> mdc = MDC.getCopyOfContextMap();
    return () -> {
      TenantContext previous = TenantContext.set(captured);
      Map<String, String> previousMdc = MDC.getCopyOfContextMap();
      if (mdc != null) {
        MDC.setContextMap(mdc);
      } else {
        MDC.clear();
      }
      try {
        runnable.run();
      } finally {
        TenantContext.set(previous); // pooled threads normally had none: this clears it
        if (previousMdc != null) {
          MDC.setContextMap(previousMdc);
        } else {
          MDC.clear();
        }
      }
    };
  }
}
