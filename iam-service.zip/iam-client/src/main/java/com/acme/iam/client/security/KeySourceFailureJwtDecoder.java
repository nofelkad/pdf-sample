package com.acme.iam.client.security;

import com.nimbusds.jose.KeySourceException;
import org.springframework.security.oauth2.jwt.BadJwtException;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.security.oauth2.jwt.JwtDecoder;
import org.springframework.security.oauth2.jwt.JwtException;

/**
 * Turns "no verification key available" into a plain bad token. Nimbus signals an unknown {@code kid} that arrives
 * inside the JWKS rate-limit window ({@code RateLimitReachedException}), or a JWKS that has been unreachable longer than
 * the outage tolerance, as a {@code KeySourceException}; Spring Security then raises a non-"bad" {@link JwtException},
 * the bearer filter rethrows it as {@code AuthenticationServiceException} and the client sees a 500. Such a token
 * cannot be verified, so the right answer is the same as for any other invalid token: 401.
 */
public final class KeySourceFailureJwtDecoder implements JwtDecoder {

  private final JwtDecoder delegate;

  public KeySourceFailureJwtDecoder(JwtDecoder delegate) {
    this.delegate = delegate;
  }

  @Override
  public Jwt decode(String token) throws JwtException {
    try {
      return delegate.decode(token);
    } catch (BadJwtException e) {
      throw e;
    } catch (JwtException e) {
      if (hasKeySourceCause(e)) {
        throw new BadJwtException("The token's signing key could not be resolved", e);
      }
      throw e;
    }
  }

  private static boolean hasKeySourceCause(Throwable error) {
    for (Throwable t = error; t != null; t = t.getCause() == t ? null : t.getCause()) {
      if (t instanceof KeySourceException) { // includes RateLimitReachedException and RemoteKeySourceException
        return true;
      }
    }
    return false;
  }
}
