package com.acme.iam.client.autoconfigure;

import com.acme.iam.client.IamClientProperties;
import com.acme.iam.client.http.AppTokenProvider;
import com.acme.iam.client.http.IamApiClient;
import com.acme.iam.client.http.IamHttp;
import com.acme.iam.client.http.IamJson;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.time.Clock;
import org.springframework.boot.autoconfigure.AutoConfiguration;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;

/**
 * Core of the IAM client starter: {@code iam.client.*} properties, the application token and the typed HTTP client
 * for IAM's {@code /internal/*} API. Everything is a {@code @ConditionalOnMissingBean}, so applications can replace
 * any piece. Disable the whole starter with {@code iam.client.enabled=false}.
 */
@AutoConfiguration
@ConditionalOnProperty(prefix = "iam.client", name = "enabled", havingValue = "true", matchIfMissing = true)
@EnableConfigurationProperties(IamClientProperties.class)
public class IamClientAutoConfiguration {

  /** Private mapper for the starter's own JSON (deliberately not a bean: it must not replace the application's). */
  static final ObjectMapper MAPPER = IamJson.mapper();

  static ObjectMapper defaultMapper() {
    return MAPPER;
  }

  @Bean
  @ConditionalOnMissingBean
  Clock iamClientClock() {
    return Clock.systemUTC();
  }

  @Bean
  @ConditionalOnMissingBean
  IamHttp iamHttp(IamClientProperties properties) {
    return new IamHttp(properties);
  }

  @Bean
  @ConditionalOnMissingBean
  AppTokenProvider iamAppTokenProvider(IamHttp http, IamClientProperties properties, Clock clock) {
    return new AppTokenProvider(http, properties, clock, MAPPER);
  }

  @Bean
  @ConditionalOnMissingBean
  IamApiClient iamApiClient(IamHttp http, AppTokenProvider tokens) {
    return new IamApiClient(http, tokens, MAPPER);
  }
}
