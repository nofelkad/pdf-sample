package com.acme.iam.client.http;

import com.acme.iam.core.revocation.RevocationEntry;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;

/**
 * Typed calls to IAM's {@code /internal/*} endpoints with the application token. A 401 invalidates the cached token
 * and retries once. Failures surface as {@link IamUnavailableException} (retry later) or {@link IamApiException}
 * (client error).
 */
public class IamApiClient {

  /** One page of the revocation feed. */
  public record RevocationPage(List<RevocationEntry> entries, long cursor) {}

  /** Result of an audit ingest request. */
  public record AuditIngestResult(int accepted, int duplicates, List<Rejected> rejected) {

    /** One event IAM refused for good. */
    public record Rejected(String eventId, String reason) {}

    /** Number of events IAM took a decision on. */
    public int total() {
      return accepted + duplicates + rejected.size();
    }
  }

  /** Result of a manifest upload. */
  public record ManifestResult(
      boolean changed, int permissionsAdded, int permissionsUpdated, int permissionsDeprecated, int rolesChanged) {}

  private final IamHttp http;
  private final AppTokenProvider tokens;
  private final ObjectMapper mapper;

  public IamApiClient(IamHttp http, AppTokenProvider tokens, ObjectMapper mapper) {
    this.http = http;
    this.tokens = tokens;
    this.mapper = mapper;
  }

  /**
   * {@code GET /internal/revocations}.
   *
   * @param since feed cursor, or {@code null} to load the server's startup window
   */
  public RevocationPage fetchRevocations(Long since, int limit) {
    String path = "/internal/revocations?limit=" + limit + (since == null ? "" : "&since=" + since);
    JsonNode json = parse(call(HttpMethod.GET, path, null).body());
    List<RevocationEntry> entries = new ArrayList<>();
    for (JsonNode node : json.path("entries")) {
      entries.add(new RevocationEntry(
          node.path("id").asLong(), UUID.fromString(node.path("userId").asText()), node.path("minSv").asInt()));
    }
    return new RevocationPage(entries, json.path("cursor").asLong(since == null ? 0 : since));
  }

  /**
   * {@code POST /internal/audit/events}.
   *
   * @param body the JSON request body {@code {"events":[...]}}
   */
  public AuditIngestResult postAuditEvents(String body) {
    JsonNode json = parse(call(HttpMethod.POST, "/internal/audit/events", body).body());
    List<AuditIngestResult.Rejected> rejected = new ArrayList<>();
    for (JsonNode node : json.path("rejected")) {
      rejected.add(new AuditIngestResult.Rejected(node.path("eventId").asText(), node.path("reason").asText()));
    }
    return new AuditIngestResult(json.path("accepted").asInt(), json.path("duplicates").asInt(), rejected);
  }

  /** {@code PUT /internal/products/{code}/manifest}. */
  public ManifestResult putManifest(String productCode, String body) {
    JsonNode json = parse(call(HttpMethod.PUT, "/internal/products/" + productCode + "/manifest", body).body());
    return new ManifestResult(
        json.path("changed").asBoolean(),
        json.path("permissionsAdded").asInt(),
        json.path("permissionsUpdated").asInt(),
        json.path("permissionsDeprecated").asInt(),
        json.path("rolesChanged").asInt());
  }

  private IamHttp.Response call(HttpMethod method, String path, String body) {
    IamHttp.Response response = send(method, path, body);
    if (response.status() == 401) {
      tokens.invalidate();
      response = send(method, path, body);
    }
    return response.requireSuccess();
  }

  private IamHttp.Response send(HttpMethod method, String path, String body) {
    String token = tokens.token();
    return http.exchange(
        method,
        path,
        headers -> {
          headers.setBearerAuth(token);
          headers.setAccept(List.of(MediaType.APPLICATION_JSON));
        },
        body == null ? null : MediaType.APPLICATION_JSON_VALUE,
        body);
  }

  private JsonNode parse(String body) {
    try {
      return mapper.readTree(body);
    } catch (IOException e) {
      throw new IamUnavailableException("IAM answered with a body that is not valid JSON", e);
    }
  }
}
