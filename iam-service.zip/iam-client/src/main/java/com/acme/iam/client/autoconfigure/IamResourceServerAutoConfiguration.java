package com.acme.iam.client.autoconfigure;

import com.acme.iam.client.IamClientProperties;
import com.acme.iam.client.http.IamApiClient;
import com.acme.iam.client.revocation.RevocationHealthIndicator;
import com.acme.iam.client.revocation.RevocationPoller;
import com.acme.iam.client.security.IamJwtAuthenticationConverter;
import com.acme.iam.client.security.IamJwtDecoderFactory;
import com.acme.iam.client.security.IamSecurity;
import com.acme.iam.client.security.NoDataScopeExceptionHandler;
import com.acme.iam.client.security.ProblemResponseWriter;
import com.acme.iam.client.tenant.TenantContextTaskDecorator;
import com.acme.iam.core.revocation.RevocationRegistry;
import java.time.Clock;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.actuate.health.HealthIndicator;
import org.springframework.boot.autoconfigure.AutoConfiguration;
import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnWebApplication;
import org.springframework.boot.autoconfigure.security.oauth2.resource.servlet.OAuth2ResourceServerAutoConfiguration;
import org.springframework.boot.autoconfigure.security.servlet.SecurityAutoConfiguration;
import org.springframework.boot.autoconfigure.security.servlet.UserDetailsServiceAutoConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.task.TaskDecorator;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.oauth2.core.OAuth2TokenValidator;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.security.oauth2.jwt.JwtDecoder;
import org.springframework.security.web.SecurityFilterChain;

/**
 * Resource-server side of the IAM client (spec section 7, P1-12.2/12.3):
 *
 * <ul>
 *   <li>{@link JwtDecoder} over IAM's JWKS (cached, refreshed on an unknown {@code kid}, RS256 only);
 *   <li>token validators: issuer, timestamps (60 s skew), IAM claim structure, application tokens rejected;
 *   <li>{@code perms} claim to authorities ({@link IamJwtAuthenticationConverter});
 *   <li>{@link RevocationRegistry} fed by the {@link RevocationPoller}, enforced by the {@code RevocationFilter}
 *       (401 {@code token_revoked}), plus a health indicator;
 *   <li>{@code TenantContext} binding and a {@link TaskDecorator} that propagates it to {@code @Async} tasks;
 *   <li>a default stateless {@link SecurityFilterChain} (only when the application defines none) and method security
 *       ({@code @PreAuthorize}).
 * </ul>
 *
 * All beans are {@code @ConditionalOnMissingBean}.
 */
@AutoConfiguration(
    after = IamClientAutoConfiguration.class,
    before = {
      SecurityAutoConfiguration.class,
      UserDetailsServiceAutoConfiguration.class,
      OAuth2ResourceServerAutoConfiguration.class
    })
@ConditionalOnWebApplication(type = ConditionalOnWebApplication.Type.SERVLET)
@ConditionalOnClass({JwtDecoder.class, HttpSecurity.class})
@ConditionalOnBean(IamClientProperties.class)
public class IamResourceServerAutoConfiguration {

  /** {@code @PreAuthorize} and friends, and the servlet security infrastructure. */
  @Configuration(proxyBeanMethods = false)
  @EnableWebSecurity
  @EnableMethodSecurity
  static class SecurityInfrastructure {}

  @Bean
  @ConditionalOnMissingBean(name = "iamJwtValidator")
  OAuth2TokenValidator<Jwt> iamJwtValidator(IamClientProperties properties, Clock clock) {
    return IamJwtDecoderFactory.validator(properties, clock);
  }

  @Bean
  @ConditionalOnMissingBean(JwtDecoder.class)
  JwtDecoder iamJwtDecoder(
      IamClientProperties properties,
      @Qualifier("iamJwtValidator") OAuth2TokenValidator<Jwt> validator) {
    return IamJwtDecoderFactory.create(IamJwtDecoderFactory.jwkSource(properties), validator);
  }

  @Bean
  @ConditionalOnMissingBean(IamJwtAuthenticationConverter.class)
  IamJwtAuthenticationConverter iamJwtAuthenticationConverter() {
    return new IamJwtAuthenticationConverter();
  }

  @Bean
  @ConditionalOnMissingBean
  ProblemResponseWriter iamProblemResponseWriter() {
    return new ProblemResponseWriter(IamClientAutoConfiguration.MAPPER);
  }

  @Bean
  @ConditionalOnMissingBean
  NoDataScopeExceptionHandler iamNoDataScopeExceptionHandler(ProblemResponseWriter problems) {
    return new NoDataScopeExceptionHandler(problems);
  }

  @Bean
  @ConditionalOnMissingBean
  RevocationRegistry iamRevocationRegistry(Clock clock) {
    return new RevocationRegistry(clock);
  }

  @Bean
  @ConditionalOnMissingBean
  RevocationPoller iamRevocationPoller(
      IamApiClient api, RevocationRegistry registry, IamClientProperties properties, Clock clock) {
    return new RevocationPoller(api, registry, properties.revocation(), clock);
  }

  @Bean
  @ConditionalOnMissingBean(name = "iamRevocationHealthIndicator")
  @ConditionalOnClass(HealthIndicator.class)
  HealthIndicator iamRevocationHealthIndicator(RevocationPoller poller, IamClientProperties properties) {
    return new RevocationHealthIndicator(poller, properties.revocation());
  }

  @Bean
  @ConditionalOnMissingBean
  IamSecurity iamSecurity(
      JwtDecoder decoder,
      IamJwtAuthenticationConverter converter,
      RevocationRegistry registry,
      ProblemResponseWriter problems) {
    return new IamSecurity(decoder, converter, registry, problems);
  }

  /** Spring Boot applies a single {@code TaskDecorator} bean to its {@code applicationTaskExecutor} ({@code @Async}). */
  @Bean
  @ConditionalOnMissingBean(TaskDecorator.class)
  TaskDecorator iamTenantContextTaskDecorator() {
    return new TenantContextTaskDecorator();
  }

  /**
   * Default chain: stateless, bearer JWT, {@code iam.client.public-paths} open, everything else authenticated. Backs
   * off as soon as the application declares any {@link SecurityFilterChain}; such an application keeps the IAM
   * behaviour through {@link IamSecurity#apply(HttpSecurity)}.
   */
  @Bean
  @ConditionalOnMissingBean(SecurityFilterChain.class)
  SecurityFilterChain iamSecurityFilterChain(HttpSecurity http, IamSecurity iam, IamClientProperties properties)
      throws Exception {
    return iam.apply(http)
        .authorizeHttpRequests(authorize -> authorize
            .requestMatchers(properties.publicPaths().toArray(String[]::new))
            .permitAll()
            .anyRequest()
            .authenticated())
        .build();
  }
}
