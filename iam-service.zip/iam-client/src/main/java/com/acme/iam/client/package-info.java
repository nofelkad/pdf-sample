/**
 * IAM client Spring Boot starter: resource server, revocation poller, tenant context, {@code @Audited} outbox and relay.
 * Auto-configurations are registered in {@code META-INF/spring/org.springframework.boot.autoconfigure.AutoConfiguration.imports}.
 */
package com.acme.iam.client;
