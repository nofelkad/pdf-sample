package com.acme.iam.client.security;

import com.acme.iam.core.Claims;
import com.acme.iam.core.revocation.RevocationRegistry;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.UUID;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.security.oauth2.server.resource.authentication.JwtAuthenticationToken;
import org.springframework.web.filter.OncePerRequestFilter;

/**
 * Rejects user tokens revoked through IAM's revocation feed (spec section 5): when {@code jwt.sv} is lower than the
 * user's minimum session version in the {@link RevocationRegistry}, the request ends with {@code 401},
 * {@code WWW-Authenticate: Bearer error="token_revoked"} and an RFC 7807 body with {@code code = "token_revoked"}.
 * The client is expected to refresh its token (refresh re-checks IAM's database) and retry.
 *
 * <p>Placed right after {@code BearerTokenAuthenticationFilter}. Application tokens are not subject to user
 * revocation. Deliberately not a Spring bean (that would register it as a servlet filter for every request);
 * {@link IamSecurity} adds it to the security chain.
 */
public class RevocationFilter extends OncePerRequestFilter {

  public static final String ERROR_CODE = "token_revoked";
  static final String WWW_AUTHENTICATE_VALUE =
      "Bearer error=\"token_revoked\", error_description=\"The access token has been revoked\"";

  private final RevocationRegistry registry;
  private final ProblemResponseWriter problems;

  public RevocationFilter(RevocationRegistry registry, ProblemResponseWriter problems) {
    this.registry = registry;
    this.problems = problems;
  }

  @Override
  protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain chain)
      throws ServletException, IOException {
    Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
    if (authentication instanceof JwtAuthenticationToken token && isRevoked(token.getToken())) {
      SecurityContextHolder.clearContext();
      response.setHeader(HttpHeaders.WWW_AUTHENTICATE, WWW_AUTHENTICATE_VALUE);
      problems.write(request, response, HttpStatus.UNAUTHORIZED, ERROR_CODE, "The access token has been revoked");
      return;
    }
    chain.doFilter(request, response);
  }

  private boolean isRevoked(Jwt jwt) {
    if (IamJwtValidator.isApp(jwt)) {
      return false;
    }
    // sub (UUID) and sv (integer) are guaranteed by IamJwtValidator; a custom decoder that skips it fails closed
    Object sv = jwt.getClaim(Claims.SESSION_VERSION);
    if (!(sv instanceof Number number)) {
      return true;
    }
    try {
      return registry.isRevoked(UUID.fromString(jwt.getSubject()), number.intValue());
    } catch (IllegalArgumentException | NullPointerException e) {
      return true;
    }
  }
}
