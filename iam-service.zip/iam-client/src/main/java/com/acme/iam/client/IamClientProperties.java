package com.acme.iam.client;

import jakarta.validation.Valid;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import java.time.Duration;
import java.util.List;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.bind.DefaultValue;
import org.springframework.validation.annotation.Validated;

/**
 * {@code iam.client.*} configuration of the IAM client starter.
 *
 * @param issuerUri expected {@code iss} of IAM tokens, e.g. {@code https://iam.acme.com}
 * @param jwksUri IAM's JWKS endpoint; defaults to {@code {issuer-uri}/.well-known/jwks.json}
 * @param baseUrl where this application reaches IAM's {@code /internal/*} API; defaults to {@code issuer-uri}
 * @param clientId application client id registered in IAM ({@code POST /api/platform/app-clients})
 * @param clientSecret the secret returned once at registration
 * @param productCode product code of this application, e.g. {@code BILLING}
 * @param manifestLocation Spring resource of the permissions manifest (e.g. {@code classpath:permissions.yaml}); the
 *     manifest upload is skipped when unset
 * @param acceptAppTokens accept application ({@code typ=app}) tokens on this application's endpoints; off by default
 * @param clockSkew tolerated clock difference for {@code exp}/{@code nbf}
 * @param publicPaths ant patterns the default filter chain leaves unauthenticated
 */
@Validated
@ConfigurationProperties("iam.client")
public record IamClientProperties(
    @NotBlank String issuerUri,
    String jwksUri,
    String baseUrl,
    @NotBlank String clientId,
    @NotBlank String clientSecret,
    @NotBlank String productCode,
    String manifestLocation,
    @DefaultValue("false") boolean acceptAppTokens,
    @DefaultValue("60s") @NotNull Duration clockSkew,
    @DefaultValue({"/actuator/health/**", "/error"}) List<String> publicPaths,
    @DefaultValue @Valid Http http,
    @DefaultValue @Valid Jwks jwks,
    @DefaultValue @Valid Revocation revocation,
    @DefaultValue @Valid Audit audit,
    @DefaultValue @Valid Manifest manifest) {

  /** Never prints the client secret. */
  @Override
  public String toString() {
    return "IamClientProperties[issuerUri=" + issuerUri + ", jwksUri=" + jwksUri + ", baseUrl=" + baseUrl
        + ", clientId=" + clientId + ", clientSecret=******, productCode=" + productCode
        + ", manifestLocation=" + manifestLocation + ", acceptAppTokens=" + acceptAppTokens
        + ", clockSkew=" + clockSkew + ", publicPaths=" + publicPaths + ", http=" + http + ", jwks=" + jwks
        + ", revocation=" + revocation + ", audit=" + audit + ", manifest=" + manifest + "]";
  }

  /** The effective JWKS URI. */
  public String effectiveJwksUri() {
    if (jwksUri != null && !jwksUri.isBlank()) {
      return jwksUri;
    }
    return stripTrailingSlash(issuerUri) + "/.well-known/jwks.json";
  }

  /** The effective base URL for {@code /internal/*} calls (no trailing slash). */
  public String effectiveBaseUrl() {
    return stripTrailingSlash(baseUrl != null && !baseUrl.isBlank() ? baseUrl : issuerUri);
  }

  private static String stripTrailingSlash(String url) {
    return url.endsWith("/") ? url.substring(0, url.length() - 1) : url;
  }

  /** Timeouts of calls to IAM. */
  public record Http(
      @DefaultValue("2s") @NotNull Duration connectTimeout, @DefaultValue("5s") @NotNull Duration readTimeout) {}

  /**
   * JWKS handling: keys are cached for {@code cacheTtl}; an unknown {@code kid} forces a refetch, at most once every
   * {@code minRefreshInterval}; cached keys keep working for {@code outageTolerance} when IAM is unreachable.
   */
  public record Jwks(
      @DefaultValue("5m") @NotNull Duration cacheTtl,
      @DefaultValue("10s") @NotNull Duration minRefreshInterval,
      @DefaultValue("1h") @NotNull Duration outageTolerance) {}

  /**
   * Revocation feed polling.
   *
   * @param pollInterval delay between polls
   * @param startupWindow how far back the feed is read at startup (the server decides the window; keep it equal to
   *     IAM's {@code iam.revocation.startup-lookback}) and how long applied entries are kept in memory (must exceed the
   *     access token lifetime plus clock skew)
   * @param staleAfter the {@code iamRevocation} health indicator reports {@code DEGRADED} (not {@code DOWN}: the
   *     aggregate health stays UP, see the README) when no poll succeeded for this long
   * @param pageSize {@code limit} used for feed requests
   */
  public record Revocation(
      @DefaultValue("2s") @NotNull Duration pollInterval,
      @DefaultValue("20m") @NotNull Duration startupWindow,
      @DefaultValue("60s") @NotNull Duration staleAfter,
      @DefaultValue("1000") @Min(1) @Max(5000) int pageSize) {}

  /**
   * {@code @Audited} outbox and relay.
   *
   * @param migrate apply the starter's own migration (own Flyway instance, history table
   *     {@code iam_client_schema_history}); set {@code false} to run {@code V1__iam_audit_outbox.sql} yourself
   */
  public record Audit(
      @DefaultValue("true") boolean enabled,
      @DefaultValue("true") boolean migrate,
      @DefaultValue @Valid Relay relay) {}

  /**
   * Outbox relay.
   *
   * @param interval delay between relay runs while there is nothing to do
   * @param batchSize events per request (IAM accepts at most 500)
   * @param maxBackoff cap of the exponential backoff after failures
   * @param lockAtMostFor ShedLock safety net if an instance dies while holding the relay lock
   */
  public record Relay(
      @DefaultValue("2s") @NotNull Duration interval,
      @DefaultValue("500") @Min(1) @Max(500) int batchSize,
      @DefaultValue("1m") @NotNull Duration maxBackoff,
      @DefaultValue("2m") @NotNull Duration lockAtMostFor) {}

  /** Manifest upload retry policy. */
  public record Manifest(
      @DefaultValue("1s") @NotNull Duration retryInitialDelay, @DefaultValue("1m") @NotNull Duration retryMaxDelay) {}
}
