package com.acme.iam.client.revocation;

import com.acme.iam.client.IamClientProperties;
import com.acme.iam.client.http.IamApiClient;
import com.acme.iam.core.revocation.RevocationRegistry;
import java.time.Clock;
import java.time.Duration;
import java.time.Instant;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.SmartLifecycle;

/**
 * Keeps the {@link RevocationRegistry} in step with IAM's revocation feed ({@code GET /internal/revocations}).
 *
 * <ul>
 *   <li>Runs on its own single daemon thread ({@value #THREAD_NAME}), never on the application's shared scheduler.
 *   <li>On start it loads the startup window first (request without {@code since}), before the web server accepts
 *       requests; then it polls every {@code iam.client.revocation.poll-interval} with {@code since=<last cursor>}
 *       until a page is shorter than the page size.
 *   <li>When IAM is unreachable it keeps the last known state, logs a WARN (first failure, then every
 *       {@value #LOG_EVERY} failures) and retries on the next tick; {@link RevocationHealthIndicator} reports it.
 *   <li>Applied entries older than {@code startup-window} are evicted from memory (every token they could reject has
 *       expired by then).
 * </ul>
 */
public class RevocationPoller implements SmartLifecycle {

  public static final String THREAD_NAME = "iam-revocation-poller";
  static final int LOG_EVERY = 12;
  private static final int MAX_PAGES_PER_POLL = 100;
  private static final Logger log = LoggerFactory.getLogger(RevocationPoller.class);

  private final IamApiClient api;
  private final RevocationRegistry registry;
  private final IamClientProperties.Revocation config;
  private final Clock clock;

  private ScheduledExecutorService scheduler;
  private volatile boolean running;
  private boolean initialLoadDone;

  private volatile Instant lastSuccess;
  private volatile int consecutiveFailures;
  private volatile String lastError;

  public RevocationPoller(
      IamApiClient api, RevocationRegistry registry, IamClientProperties.Revocation config, Clock clock) {
    this.api = api;
    this.registry = registry;
    this.config = config;
    this.clock = clock;
  }

  /**
   * One poll cycle (all pages). Never throws; failures are recorded and logged. Tests call this directly.
   *
   * @return {@code true} when the registry is up to date with IAM
   */
  public synchronized boolean poll() {
    try {
      int pages = 0;
      int size;
      do {
        Long since = initialLoadDone ? registry.lastCursor() : null;
        IamApiClient.RevocationPage page = api.fetchRevocations(since, config.pageSize());
        registry.apply(page.entries(), page.cursor());
        initialLoadDone = true;
        size = page.entries().size();
      } while (size >= config.pageSize() && ++pages < MAX_PAGES_PER_POLL);
      registry.evictOlderThan(clock.instant().minus(config.startupWindow()));
      if (consecutiveFailures > 0) {
        log.info("Revocation feed reachable again after {} failed polls", consecutiveFailures);
      }
      consecutiveFailures = 0;
      lastError = null;
      lastSuccess = clock.instant();
      return true;
    } catch (RuntimeException e) { // IamUnavailableException, IamApiException or a malformed response
      failed(e);
    }
    return false;
  }

  private void failed(Exception e) {
    int failures = ++consecutiveFailures;
    lastError = e.getMessage();
    if (failures == 1 || failures % LOG_EVERY == 0) {
      log.warn(
          "Revocation feed poll failed ({} in a row, keeping last known state, cursor {}): {}",
          failures, registry.lastCursor(), e.getMessage());
    }
  }

  /** The last successful poll, or {@code null} if none succeeded yet. */
  public Instant lastSuccess() {
    return lastSuccess;
  }

  public int consecutiveFailures() {
    return consecutiveFailures;
  }

  public String lastError() {
    return lastError;
  }

  public RevocationRegistry registry() {
    return registry;
  }

  @Override
  public void start() {
    if (running) {
      return;
    }
    running = true;
    poll(); // startup window before requests are served; bounded by the HTTP timeouts when IAM is down
    scheduler = Executors.newSingleThreadScheduledExecutor(r -> {
      Thread t = new Thread(r, THREAD_NAME);
      t.setDaemon(true);
      return t;
    });
    long interval = Math.max(config.pollInterval().toMillis(), 1);
    scheduler.scheduleWithFixedDelay(this::poll, interval, interval, TimeUnit.MILLISECONDS);
  }

  @Override
  public void stop() {
    running = false;
    if (scheduler != null) {
      scheduler.shutdownNow();
      try {
        scheduler.awaitTermination(2, TimeUnit.SECONDS);
      } catch (InterruptedException e) {
        Thread.currentThread().interrupt();
      }
      scheduler = null;
    }
  }

  @Override
  public boolean isRunning() {
    return running;
  }

  /** Starts before the web server accepts requests (the web server lifecycle runs at {@code MAX_VALUE - 1}). */
  @Override
  public int getPhase() {
    return Integer.MAX_VALUE - 1000;
  }

  /** How long the registry has been without a successful poll, or {@code null} if it never succeeded. */
  public Duration staleness() {
    Instant last = lastSuccess;
    return last == null ? null : Duration.between(last, clock.instant());
  }
}
