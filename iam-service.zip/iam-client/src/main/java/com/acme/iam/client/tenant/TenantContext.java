package com.acme.iam.client.tenant;

import com.acme.iam.core.Claims;
import java.util.Optional;
import java.util.UUID;
import org.springframework.security.oauth2.jwt.Jwt;

/**
 * Who is calling and in which tenant: the {@code sub}, {@code acc}, {@code tid} and {@code sid} of the access token
 * plus the request id. Bound to the request thread by {@link TenantContextFilter} after authentication, copied to
 * {@code @Async} tasks by {@link TenantContextTaskDecorator} and cleared when the request/task ends.
 *
 * <pre>{@code
 * TenantContext ctx = TenantContext.require();   // throws outside an authenticated request
 * UUID tenant = ctx.tenantId();
 * }</pre>
 *
 * <p>The active tenant always comes from here (the token), never from request bodies or parameters.
 *
 * @param userId {@code sub}
 * @param accountId {@code acc}
 * @param tenantId {@code tid}
 * @param sessionId {@code sid}
 * @param requestId request id ({@code X-Request-Id}); may be {@code null} outside HTTP requests
 */
public record TenantContext(UUID userId, UUID accountId, UUID tenantId, UUID sessionId, String requestId) {

  private static final ThreadLocal<TenantContext> HOLDER = new ThreadLocal<>();

  /** Builds the context of a user access token. */
  public static TenantContext from(Jwt jwt, String requestId) {
    return new TenantContext(
        UUID.fromString(jwt.getSubject()),
        UUID.fromString(jwt.getClaimAsString(Claims.ACCOUNT)),
        UUID.fromString(jwt.getClaimAsString(Claims.TENANT)),
        UUID.fromString(jwt.getClaimAsString(Claims.SESSION)),
        requestId);
  }

  /** The context bound to the current thread, if any. */
  public static Optional<TenantContext> current() {
    return Optional.ofNullable(HOLDER.get());
  }

  /**
   * The context bound to the current thread.
   *
   * @throws IllegalStateException when none is bound (no authenticated user request, or an async task without the
   *     {@link TenantContextTaskDecorator})
   */
  public static TenantContext require() {
    TenantContext ctx = HOLDER.get();
    if (ctx == null) {
      throw new IllegalStateException("No TenantContext bound to this thread (not an authenticated user request)");
    }
    return ctx;
  }

  /** Binds {@code context} to the current thread (or clears it for {@code null}); returns the previous one. */
  static TenantContext set(TenantContext context) {
    TenantContext previous = HOLDER.get();
    if (context == null) {
      HOLDER.remove();
    } else {
      HOLDER.set(context);
    }
    return previous;
  }

  /**
   * Binds {@code context} until the returned scope is closed (restoring the previous binding). For code that runs
   * outside a request, e.g. tests or message consumers acting on behalf of a user.
   */
  public static Scope bind(TenantContext context) {
    TenantContext previous = set(context);
    return () -> set(previous);
  }

  /** Clears the binding of the current thread. */
  public static void clear() {
    HOLDER.remove();
  }

  /** Handle returned by {@link #bind}; closing it restores the previous binding. */
  @FunctionalInterface
  public interface Scope extends AutoCloseable {
    @Override
    void close();
  }
}
