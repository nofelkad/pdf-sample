package com.acme.iam.client.security;

import com.acme.iam.core.Claims;
import java.util.List;
import org.springframework.core.convert.converter.Converter;
import org.springframework.security.authentication.AbstractAuthenticationToken;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.security.oauth2.server.resource.authentication.JwtAuthenticationToken;

/**
 * Maps the {@code perms} claim 1:1 to authorities (no {@code ROLE_} or {@code SCOPE_} prefix), so code checks
 * {@code hasAuthority('billing.invoice.approve')}. Permissions starting with {@code internal.} are reserved for
 * application tokens and stripped from user tokens. The principal name is the {@code sub} claim.
 */
public class IamJwtAuthenticationConverter implements Converter<Jwt, AbstractAuthenticationToken> {

  @Override
  public AbstractAuthenticationToken convert(Jwt jwt) {
    List<String> perms = jwt.getClaimAsStringList(Claims.PERMISSIONS);
    boolean app = IamJwtValidator.isApp(jwt);
    List<GrantedAuthority> authorities = (perms == null ? List.<String>of() : perms).stream()
        .filter(p -> app || !p.startsWith(Claims.INTERNAL_PERMISSION_PREFIX))
        .<GrantedAuthority>map(SimpleGrantedAuthority::new)
        .toList();
    return new JwtAuthenticationToken(jwt, authorities, jwt.getSubject());
  }
}
