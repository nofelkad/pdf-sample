package com.acme.iam.client.autoconfigure;

import com.acme.iam.client.IamClientProperties;
import com.acme.iam.client.audit.AuditOutbox;
import com.acme.iam.client.audit.AuditRelay;
import com.acme.iam.client.audit.AuditedAspect;
import com.acme.iam.client.audit.IamClientMigrator;
import com.acme.iam.client.http.IamApiClient;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.time.Clock;
import javax.sql.DataSource;
import net.javacrumbs.shedlock.core.LockProvider;
import org.aspectj.lang.annotation.Aspect;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.boot.autoconfigure.AutoConfiguration;
import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.autoconfigure.flyway.FlywayAutoConfiguration;
import org.springframework.boot.autoconfigure.flyway.FlywayMigrationInitializer;
import org.springframework.boot.autoconfigure.jackson.JacksonAutoConfiguration;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.boot.autoconfigure.jdbc.JdbcClientAutoConfiguration;
import org.springframework.boot.autoconfigure.jdbc.JdbcTemplateAutoConfiguration;
import org.springframework.boot.autoconfigure.transaction.TransactionAutoConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.core.simple.JdbcClient;
import org.springframework.transaction.PlatformTransactionManager;

/**
 * Audit side of the IAM client (P1-12.4): the {@code iam_audit_outbox} table, {@link AuditOutbox}, the
 * {@code @Audited} aspect and the {@link AuditRelay}.
 *
 * <p>The table comes from the starter's own migration ({@code db/iam-client/V1__iam_audit_outbox.sql}), applied by a
 * separate Flyway instance with its own history table {@code iam_client_schema_history}, after the host's Flyway
 * migration and before the outbox/relay are used (Ruling R27). The host's Flyway beans and version numbers are
 * untouched. Switch off with {@code iam.client.audit.migrate=false} and run the script yourself.
 *
 * <p>The outbox serialises with the host's Spring Boot {@link ObjectMapper} when there is one, otherwise with the
 * starter's own (all modules, ISO dates).
 *
 * <p>The relay is guarded by ShedLock when the application declares a {@link LockProvider} bean (and needs the
 * {@code shedlock} table then); without one it relies on {@code FOR UPDATE SKIP LOCKED} alone and logs a WARN.
 * Disable with {@code iam.client.audit.enabled=false}.
 */
@AutoConfiguration(
    after = {
      IamClientAutoConfiguration.class,
      DataSourceAutoConfiguration.class,
      JdbcTemplateAutoConfiguration.class,
      JdbcClientAutoConfiguration.class,
      TransactionAutoConfiguration.class,
      FlywayAutoConfiguration.class,
      JacksonAutoConfiguration.class
    })
@ConditionalOnProperty(prefix = "iam.client", name = "enabled", havingValue = "true", matchIfMissing = true)
@ConditionalOnProperty(prefix = "iam.client.audit", name = "enabled", havingValue = "true", matchIfMissing = true)
@ConditionalOnClass(JdbcClient.class)
@ConditionalOnBean({DataSource.class, IamClientProperties.class})
public class IamAuditAutoConfiguration {

  private static final Logger log = LoggerFactory.getLogger(IamAuditAutoConfiguration.class);

  /**
   * Creates the outbox table. Requesting the host's Flyway initializer first makes sure the host's migrations run
   * before ours (a schema that already holds our table but no host history would make the host's Flyway refuse to
   * start on a fresh database).
   */
  @Bean
  @ConditionalOnMissingBean
  @ConditionalOnProperty(prefix = "iam.client.audit", name = "migrate", havingValue = "true", matchIfMissing = true)
  IamClientMigrator iamClientMigrator(DataSource dataSource, ObjectProvider<FlywayMigrationInitializer> hostFlyway) {
    hostFlyway.orderedStream().forEach(initializer -> { });
    return new IamClientMigrator(dataSource);
  }

  @Bean
  @ConditionalOnMissingBean
  AuditOutbox iamAuditOutbox(
      DataSource dataSource,
      ObjectProvider<ObjectMapper> hostMapper,
      ObjectProvider<IamClientMigrator> migrator,
      Clock clock) {
    migrator.getIfAvailable(); // the table must exist before the outbox is used
    return new AuditOutbox(dataSource, hostMapper.getIfUnique(IamClientAutoConfiguration::defaultMapper), clock);
  }

  @Bean
  @ConditionalOnBean(PlatformTransactionManager.class)
  @ConditionalOnMissingBean
  AuditRelay iamAuditRelay(
      DataSource dataSource,
      PlatformTransactionManager transactionManager,
      IamApiClient api,
      IamClientProperties properties,
      ObjectProvider<LockProvider> lockProvider,
      ObjectProvider<IamClientMigrator> migrator,
      Clock clock) {
    migrator.getIfAvailable(); // the relay must not start before the table exists
    LockProvider lock = lockProvider.getIfAvailable();
    if (lock == null) {
      log.warn("No ShedLock LockProvider bean: the IAM audit relay relies on FOR UPDATE SKIP LOCKED only."
          + " Declare a LockProvider (and the shedlock table) so one instance relays at a time");
    }
    return new AuditRelay(
        JdbcClient.create(dataSource),
        transactionManager,
        api,
        IamClientAutoConfiguration.MAPPER,
        properties.audit().relay(),
        lock,
        "iam-audit-relay-" + properties.productCode(),
        clock);
  }

  /** {@code @Audited} support; needs AspectJ (spring-boot-starter-aop) on the classpath. */
  @Configuration(proxyBeanMethods = false)
  @ConditionalOnClass(Aspect.class)
  static class AuditedAspectConfiguration {

    @Bean
    @ConditionalOnMissingBean
    AuditedAspect iamAuditedAspect(AuditOutbox outbox) {
      return new AuditedAspect(outbox);
    }
  }
}
