package com.acme.iam.client.audit;

import com.acme.iam.client.IamClientProperties;
import com.acme.iam.client.http.IamApiClient;
import com.acme.iam.client.http.IamApiClient.AuditIngestResult;
import com.acme.iam.client.http.IamApiException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import java.time.Clock;
import java.time.Duration;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import net.javacrumbs.shedlock.core.LockConfiguration;
import net.javacrumbs.shedlock.core.LockProvider;
import net.javacrumbs.shedlock.core.SimpleLock;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.SmartLifecycle;
import org.springframework.jdbc.core.simple.JdbcClient;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.support.TransactionTemplate;

/**
 * Ships the {@code iam_audit_outbox} to IAM ({@code POST /internal/audit/events}).
 *
 * <p>Each run takes the ShedLock {@code lockName} (when the application supplies a {@link LockProvider}; without one
 * the row locks below are the only guard), then in one transaction:
 *
 * <ol>
 *   <li>{@code SELECT ... ORDER BY seq LIMIT n FOR UPDATE SKIP LOCKED}: instances that race anyway take disjoint
 *       batches;
 *   <li>POSTs the batch; IAM answers {@code accepted}, {@code duplicates} and {@code rejected[]};
 *   <li>when IAM accounted for every event of the batch (accepted + duplicates + rejected = batch size) it deletes
 *       the batch. Rejected events are logged and dropped (IAM said retrying cannot help).
 * </ol>
 *
 * Any failure (connection refused, timeout, 5xx, 4xx, malformed answer) rolls back and keeps every row. The loop then
 * backs off exponentially, {@code interval * 2^(failures-1)} capped at {@code max-backoff} (1 min), and retries
 * forever: events stay in the database through an IAM outage of any length (and through restarts) and are delivered
 * at least once; IAM de-duplicates on {@code eventId}, so every event is stored exactly once.
 *
 * <p>The HTTP call happens inside the database transaction on purpose (the row locks must outlive the call); it is
 * bounded by the read timeout.
 */
public class AuditRelay implements SmartLifecycle {

  /** Outcome of one {@link #relayOnce()}. */
  public enum RelayResult {
    /** A batch was delivered and deleted from the outbox. */
    SENT,
    /** Nothing to send. */
    IDLE,
    /** Another instance holds the relay lock. */
    LOCKED,
    /** Delivery failed; all rows were kept. */
    FAILED
  }

  public static final String THREAD_NAME = "iam-audit-relay";
  private static final Logger log = LoggerFactory.getLogger(AuditRelay.class);

  private record Row(long seq, String payload) {}

  private final JdbcClient jdbc;
  private final TransactionTemplate tx;
  private final IamApiClient api;
  private final ObjectMapper mapper;
  private final IamClientProperties.Relay config;
  private final LockProvider lockProvider;
  private final String lockName;
  private final Clock clock;

  private ScheduledExecutorService scheduler;
  private volatile boolean running;
  private volatile int consecutiveFailures;

  public AuditRelay(
      JdbcClient jdbc,
      TransactionTemplate tx,
      IamApiClient api,
      ObjectMapper mapper,
      IamClientProperties.Relay config,
      LockProvider lockProvider,
      String lockName,
      Clock clock) {
    this.jdbc = jdbc;
    this.tx = tx;
    this.api = api;
    this.mapper = mapper;
    this.config = config;
    this.lockProvider = lockProvider;
    this.lockName = lockName;
    this.clock = clock;
  }

  public AuditRelay(
      JdbcClient jdbc,
      PlatformTransactionManager transactionManager,
      IamApiClient api,
      ObjectMapper mapper,
      IamClientProperties.Relay config,
      LockProvider lockProvider,
      String lockName,
      Clock clock) {
    this(jdbc, new TransactionTemplate(transactionManager), api, mapper, config, lockProvider, lockName, clock);
  }

  /** {@code interval * 2^(failures-1)}, never more than {@code max}. */
  public static Duration backoff(int failures, Duration interval, Duration max) {
    if (failures <= 1) {
      return interval.compareTo(max) > 0 ? max : interval;
    }
    int shift = Math.min(failures - 1, 30);
    long millis = interval.toMillis() * (1L << shift);
    return millis >= max.toMillis() || millis < 0 ? max : Duration.ofMillis(millis);
  }

  public int consecutiveFailures() {
    return consecutiveFailures;
  }

  /** Delivers at most one batch. Never throws. Tests call this directly. */
  public RelayResult relayOnce() {
    SimpleLock lock = null;
    try {
      if (lockProvider != null) {
        Optional<SimpleLock> acquired = lockProvider.lock(new LockConfiguration(
            clock.instant(), lockName, config.lockAtMostFor(), Duration.ZERO));
        if (acquired.isEmpty()) {
          return RelayResult.LOCKED;
        }
        lock = acquired.get();
      }
      RelayResult result = tx.execute(status -> shipBatch());
      consecutiveFailures = 0;
      return result;
    } catch (RuntimeException e) {
      int failures = ++consecutiveFailures;
      if (e instanceof IamApiException api && api.status() != 401 && api.status() != 403) {
        // IAM answered with a client error for the whole batch (400 batch_too_large, 404, 409, 422 ...): retrying the same
        // batch cannot succeed until the cause (client or IAM version mismatch) is fixed, and the outbox grows
        if (failures == 1 || failures % 10 == 0) {
          log.error("IAM refused the audit batch with HTTP {} ({} failures in a row). The events are kept in the outbox"
              + " but no progress is possible until this is fixed. Response: {}",
              api.status(), failures, excerpt(api.body()));
        }
      } else if (failures == 1 || failures % 10 == 0) {
        log.warn("Audit relay could not deliver events to IAM ({} failures in a row; events stay in the outbox,"
            + " retrying with backoff): {}", failures, e.getMessage());
      }
      return RelayResult.FAILED;
    } finally {
      if (lock != null) {
        try {
          lock.unlock();
        } catch (RuntimeException e) {
          log.warn("Audit relay lock '{}' could not be released: {}", lockName, e.getMessage());
        }
      }
    }
  }

  private static String excerpt(String body) {
    if (body == null || body.isBlank()) {
      return "(empty)";
    }
    return body.length() <= 300 ? body : body.substring(0, 300) + "...";
  }

  private RelayResult shipBatch() {
    List<Row> rows = jdbc.sql("SELECT seq, payload::text AS payload FROM iam_audit_outbox"
            + " ORDER BY seq LIMIT :limit FOR UPDATE SKIP LOCKED")
        .param("limit", config.batchSize())
        .query((rs, i) -> new Row(rs.getLong("seq"), rs.getString("payload")))
        .list();
    if (rows.isEmpty()) {
      return RelayResult.IDLE;
    }
    AuditIngestResult result = api.postAuditEvents(body(rows));
    if (result.total() != rows.size()) {
      throw new IllegalStateException("IAM accounted for " + result.total() + " of " + rows.size()
          + " events (accepted " + result.accepted() + ", duplicates " + result.duplicates() + ", rejected "
          + result.rejected().size() + "); keeping the batch");
    }
    for (AuditIngestResult.Rejected rejected : result.rejected()) {
      log.warn("IAM rejected audit event {} ({}); dropping it from the outbox", rejected.eventId(), rejected.reason());
    }
    jdbc.sql("DELETE FROM iam_audit_outbox WHERE seq IN (:seqs)")
        .param("seqs", rows.stream().map(Row::seq).toList())
        .update();
    return RelayResult.SENT;
  }

  private String body(List<Row> rows) {
    try {
      ObjectNode body = mapper.createObjectNode();
      ArrayNode events = body.putArray("events");
      for (Row row : rows) {
        JsonNode event = mapper.readTree(row.payload());
        events.add(event);
      }
      return mapper.writeValueAsString(body);
    } catch (JsonProcessingException e) {
      throw new IllegalStateException("Outbox payload is not valid JSON", e);
    }
  }

  // ---- lifecycle ------------------------------------------------------------------------------------------------

  @Override
  public void start() {
    if (running) {
      return;
    }
    running = true;
    scheduler = Executors.newSingleThreadScheduledExecutor(r -> {
      Thread t = new Thread(r, THREAD_NAME);
      t.setDaemon(true);
      return t;
    });
    scheduler.schedule(this::loop, config.interval().toMillis(), TimeUnit.MILLISECONDS);
  }

  private void loop() {
    if (!running) {
      return;
    }
    RelayResult result = relayOnce();
    Duration delay = switch (result) {
      case SENT -> Duration.ZERO; // more may be waiting
      case FAILED -> backoff(consecutiveFailures, config.interval(), config.maxBackoff());
      case IDLE, LOCKED -> config.interval();
    };
    if (running) {
      try {
        scheduler.schedule(this::loop, delay.toMillis(), TimeUnit.MILLISECONDS);
      } catch (java.util.concurrent.RejectedExecutionException e) {
        // shutting down
      }
    }
  }

  @Override
  public void stop() {
    running = false;
    if (scheduler != null) {
      scheduler.shutdownNow();
      try {
        scheduler.awaitTermination(5, TimeUnit.SECONDS);
      } catch (InterruptedException e) {
        Thread.currentThread().interrupt();
      }
      scheduler = null;
    }
  }

  @Override
  public boolean isRunning() {
    return running;
  }
}
