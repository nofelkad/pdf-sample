package com.acme.iam.client.security;

import com.acme.iam.core.DataScope;
import com.acme.iam.core.DataScope.Scope;
import com.acme.iam.core.NoDataScopeException;
import java.util.List;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;

/**
 * Spring-side convenience over {@link DataScope}: reads the authorities of an {@link Authentication} and turns a
 * missing scope into {@link AccessDeniedException} (HTTP 403).
 *
 * <pre>{@code
 * Scope scope = IamDataScope.of(authentication, "billing.invoice.read");
 * // OWN -> AND owner_id = :sub   TENANT -> AND tenant_id = :tid   ACCOUNT -> AND account_id = :acc
 * }</pre>
 */
public final class IamDataScope {

  private IamDataScope() {}

  /**
   * The broadest scope of {@code basePermission} held by {@code authentication}.
   *
   * @throws AccessDeniedException when none of {@code base.own}, {@code base.tenant}, {@code base.account} is held
   */
  public static Scope of(Authentication authentication, String basePermission) {
    if (authentication == null) {
      throw new AccessDeniedException("No authentication");
    }
    List<String> authorities =
        authentication.getAuthorities().stream().map(GrantedAuthority::getAuthority).toList();
    try {
      return DataScope.of(authorities, basePermission);
    } catch (NoDataScopeException e) {
      throw new AccessDeniedException(e.getMessage(), e);
    }
  }

  /** Same as {@link #of(Authentication, String)} for the authentication of the current security context. */
  public static Scope of(String basePermission) {
    return of(SecurityContextHolder.getContext().getAuthentication(), basePermission);
  }
}
