package com.acme.iam.client.http;

/**
 * IAM could not be reached or answered with a server-side failure (connection refused, timeout, 5xx, 429). Callers
 * keep their state and retry later.
 */
public class IamUnavailableException extends RuntimeException {

  private static final long serialVersionUID = 1L;

  public IamUnavailableException(String message, Throwable cause) {
    super(message, cause);
  }

  public IamUnavailableException(String message) {
    super(message);
  }
}
