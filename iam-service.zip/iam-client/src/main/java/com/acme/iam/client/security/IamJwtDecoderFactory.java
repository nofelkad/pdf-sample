package com.acme.iam.client.security;

import com.acme.iam.client.IamClientProperties;
import com.nimbusds.jose.JWSAlgorithm;
import com.nimbusds.jose.jwk.source.JWKSource;
import com.nimbusds.jose.jwk.source.JWKSourceBuilder;
import com.nimbusds.jose.proc.JWSVerificationKeySelector;
import com.nimbusds.jose.proc.SecurityContext;
import com.nimbusds.jose.util.DefaultResourceRetriever;
import com.nimbusds.jwt.proc.DefaultJWTProcessor;
import java.net.MalformedURLException;
import java.net.URI;
import java.net.URL;
import java.time.Clock;
import org.springframework.security.oauth2.core.DelegatingOAuth2TokenValidator;
import org.springframework.security.oauth2.core.OAuth2TokenValidator;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.security.oauth2.jwt.JwtDecoder;
import org.springframework.security.oauth2.jwt.JwtIssuerValidator;
import org.springframework.security.oauth2.jwt.JwtTimestampValidator;
import org.springframework.security.oauth2.jwt.NimbusJwtDecoder;

/**
 * Builds the {@link JwtDecoder} over IAM's JWKS.
 *
 * <ul>
 *   <li>Keys come from {@code jwks-uri} through Nimbus' caching source: cached for {@code jwks.cache-ttl}, refetched
 *       when a token carries an unknown {@code kid} (rate limited to once per {@code jwks.min-refresh-interval}, so a
 *       forged {@code kid} cannot turn the application into a JWKS request amplifier) and tolerant of IAM outages for
 *       {@code jwks.outage-tolerance}.
 *   <li>The algorithm is pinned to RS256; {@code none}, HMAC and every other algorithm are rejected.
 *   <li>Claims are validated by {@link #validator}: timestamps with the configured skew, issuer, IAM claim structure.
 * </ul>
 */
public final class IamJwtDecoderFactory {

  private static final long REFRESH_AHEAD_MIN_TTL_MILLIS = 120_000;

  private IamJwtDecoderFactory() {}

  /** The JWKS source used by the decoder (exposed for tests and custom decoders). */
  public static JWKSource<SecurityContext> jwkSource(IamClientProperties properties) {
    URL url;
    try {
      url = URI.create(properties.effectiveJwksUri()).toURL();
    } catch (MalformedURLException | IllegalArgumentException e) {
      throw new IllegalStateException("iam.client.jwks-uri is not a valid URL: " + properties.effectiveJwksUri(), e);
    }
    int connect = (int) properties.http().connectTimeout().toMillis();
    int read = (int) properties.http().readTimeout().toMillis();
    long ttl = properties.jwks().cacheTtl().toMillis();
    JWKSourceBuilder<SecurityContext> builder =
        JWKSourceBuilder.<SecurityContext>create(url, new DefaultResourceRetriever(connect, read, 64 * 1024))
            .cache(ttl, read)
            .rateLimited(properties.jwks().minRefreshInterval().toMillis())
            .retrying(true)
            .outageTolerant(properties.jwks().outageTolerance().toMillis());
    if (ttl <= REFRESH_AHEAD_MIN_TTL_MILLIS) {
      builder.refreshAheadCache(false); // refresh-ahead (30 s) only makes sense for a longer cache lifetime
    }
    return builder.build();
  }

  /** RS256-pinned decoder with the given claim validator. */
  public static JwtDecoder create(JWKSource<SecurityContext> jwkSource, OAuth2TokenValidator<Jwt> validator) {
    DefaultJWTProcessor<SecurityContext> processor = new DefaultJWTProcessor<>();
    processor.setJWSKeySelector(new JWSVerificationKeySelector<>(JWSAlgorithm.RS256, jwkSource));
    processor.setJWTClaimsSetVerifier((claims, context) -> { }); // claims are validated by the Spring validators
    NimbusJwtDecoder decoder = new NimbusJwtDecoder(processor);
    decoder.setJwtValidator(validator);
    return new KeySourceFailureJwtDecoder(decoder);
  }

  /** The default validator: timestamps (skew), issuer, then {@link IamJwtValidator}. */
  public static OAuth2TokenValidator<Jwt> validator(IamClientProperties properties, Clock clock) {
    JwtTimestampValidator timestamps = new JwtTimestampValidator(properties.clockSkew());
    timestamps.setClock(clock);
    return new DelegatingOAuth2TokenValidator<>(
        timestamps, new JwtIssuerValidator(properties.issuerUri()), new IamJwtValidator(properties.acceptAppTokens()));
  }
}
