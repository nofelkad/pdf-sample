package com.acme.iam.client.http;

import com.acme.iam.client.IamClientProperties;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.time.Clock;
import java.time.Duration;
import java.time.Instant;
import java.nio.charset.StandardCharsets;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;

/**
 * Application token for IAM's {@code /internal/*} endpoints: {@code POST /internal/token} with HTTP Basic
 * {@code clientId:secret} and {@code grant_type=client_credentials}. The token is cached and renewed
 * {@value #RENEW_MARGIN_SECONDS} s before it expires. Never logs the secret or the token.
 */
public class AppTokenProvider {

  static final long RENEW_MARGIN_SECONDS = 60;
  static final String TOKEN_PATH = "/internal/token";

  private final IamHttp http;
  private final String clientId;
  private final String clientSecret;
  private final Clock clock;
  private final ObjectMapper mapper;

  private String token;
  private Instant renewAt = Instant.MIN;

  public AppTokenProvider(IamHttp http, IamClientProperties properties, Clock clock, ObjectMapper mapper) {
    this.http = http;
    this.clientId = properties.clientId();
    this.clientSecret = properties.clientSecret();
    this.clock = clock;
    this.mapper = mapper;
  }

  /** A bearer token valid for at least another minute; fetched from IAM when none is cached. */
  public synchronized String token() {
    if (token == null || !clock.instant().isBefore(renewAt)) {
      fetch();
    }
    return token;
  }

  /** Drops the cached token (e.g. after IAM answered 401), so the next call fetches a new one. */
  public synchronized void invalidate() {
    token = null;
    renewAt = Instant.MIN;
  }

  private void fetch() {
    IamHttp.Response response = http.exchange(
        HttpMethod.POST,
        TOKEN_PATH,
        headers -> {
          headers.setBasicAuth(clientId, clientSecret, StandardCharsets.UTF_8);
          headers.setAccept(java.util.List.of(MediaType.APPLICATION_JSON));
        },
        MediaType.APPLICATION_FORM_URLENCODED_VALUE,
        "grant_type=client_credentials");
    response.requireSuccess();
    try {
      JsonNode json = mapper.readTree(response.body());
      String accessToken = json.path("access_token").asText(null);
      long expiresIn = json.path("expires_in").asLong(0);
      if (accessToken == null || accessToken.isBlank()) {
        throw new IamUnavailableException("IAM token response has no access_token");
      }
      // renew a minute early; for very short-lived tokens use half of the lifetime instead
      long renewAfter = Math.max(expiresIn - RENEW_MARGIN_SECONDS, expiresIn / 2);
      this.token = accessToken;
      this.renewAt = clock.instant().plus(Duration.ofSeconds(Math.max(renewAfter, 0)));
    } catch (java.io.IOException e) {
      throw new IamUnavailableException("IAM token response is not valid JSON", e);
    }
  }
}
