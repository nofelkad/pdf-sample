package com.acme.iam.client.http;

import com.acme.iam.client.IamClientProperties;
import java.net.http.HttpClient;
import java.nio.charset.StandardCharsets;
import java.util.function.Consumer;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.client.JdkClientHttpRequestFactory;
import org.springframework.web.client.RestClient;
import org.springframework.web.client.RestClientException;

/**
 * Thin blocking HTTP layer to IAM's {@code /internal/*} API on {@link RestClient} (JDK HTTP client, HTTP/1.1, explicit
 * timeouts). Returns status and body instead of throwing on 4xx/5xx; transport failures become
 * {@link IamUnavailableException}.
 */
public class IamHttp {

  /** Raw response. */
  public record Response(int status, String body) {

    public boolean isSuccess() {
      return status >= 200 && status < 300;
    }

    /**
     * Returns this response when it is 2xx.
     *
     * @throws IamUnavailableException for 5xx, 429 and 408 (worth retrying)
     * @throws IamApiException for any other non-2xx status
     */
    public Response requireSuccess() {
      if (isSuccess()) {
        return this;
      }
      if (status >= 500 || status == 429 || status == 408) {
        throw new IamUnavailableException("IAM answered HTTP " + status);
      }
      throw new IamApiException(status, body);
    }
  }

  private final RestClient restClient;
  private final String baseUrl;

  public IamHttp(IamClientProperties properties) {
    HttpClient httpClient = HttpClient.newBuilder()
        .version(HttpClient.Version.HTTP_1_1)
        .connectTimeout(properties.http().connectTimeout())
        .build();
    JdkClientHttpRequestFactory factory = new JdkClientHttpRequestFactory(httpClient);
    factory.setReadTimeout(properties.http().readTimeout());
    this.restClient = RestClient.builder().requestFactory(factory).build();
    this.baseUrl = properties.effectiveBaseUrl();
  }

  /**
   * Sends one request to {@code baseUrl + path}.
   *
   * @param contentType request content type, or {@code null} for a request without body
   * @param body request body, or {@code null}
   */
  public Response exchange(
      HttpMethod method, String path, Consumer<HttpHeaders> headers, String contentType, String body) {
    try {
      RestClient.RequestBodySpec spec = restClient.method(method).uri(baseUrl + path).headers(headers);
      if (contentType != null) {
        spec = spec.header(HttpHeaders.CONTENT_TYPE, contentType);
      }
      if (body != null) {
        spec = spec.body(body.getBytes(StandardCharsets.UTF_8));
      }
      return spec.exchange((request, response) -> new Response(
          response.getStatusCode().value(), new String(response.getBody().readAllBytes(), StandardCharsets.UTF_8)));
    } catch (RestClientException e) {
      throw new IamUnavailableException("IAM is unreachable: " + rootMessage(e), e);
    } catch (IllegalStateException e) {
      // JDK client wraps some transport errors (e.g. interrupted/closed connections)
      throw new IamUnavailableException("IAM call failed: " + rootMessage(e), e);
    }
  }

  static String rootMessage(Throwable t) {
    Throwable root = t;
    while (root.getCause() != null && root.getCause() != root) {
      root = root.getCause();
    }
    return root.getClass().getSimpleName() + (root.getMessage() == null ? "" : " " + root.getMessage());
  }
}
