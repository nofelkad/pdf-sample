package com.acme.iam.client.autoconfigure;

import com.acme.iam.client.IamClientProperties;
import com.acme.iam.client.http.IamApiClient;
import com.acme.iam.client.manifest.ManifestUploader;
import org.springframework.boot.autoconfigure.AutoConfiguration;
import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.core.io.ResourceLoader;

/**
 * Manifest upload at startup (P1-12.5): active when {@code iam.client.manifest-location} is set, e.g.
 * {@code classpath:permissions.yaml}.
 */
@AutoConfiguration(after = IamClientAutoConfiguration.class)
@ConditionalOnProperty(prefix = "iam.client", name = "enabled", havingValue = "true", matchIfMissing = true)
@ConditionalOnProperty(prefix = "iam.client", name = "manifest-location")
@ConditionalOnBean(IamClientProperties.class)
public class IamManifestAutoConfiguration {

  @Bean
  @ConditionalOnMissingBean
  ManifestUploader iamManifestUploader(IamApiClient api, IamClientProperties properties, ResourceLoader resources) {
    return new ManifestUploader(
        api, properties, resources.getResource(properties.manifestLocation()), IamClientAutoConfiguration.MAPPER);
  }
}
