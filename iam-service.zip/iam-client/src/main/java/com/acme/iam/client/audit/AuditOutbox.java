package com.acme.iam.client.audit;

import com.acme.iam.client.tenant.TenantContext;
import com.acme.iam.core.Claims;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import jakarta.servlet.http.HttpServletRequest;
import java.sql.Timestamp;
import java.time.Clock;
import java.time.Instant;
import java.util.Optional;
import java.util.UUID;
import javax.sql.DataSource;
import org.springframework.http.HttpHeaders;
import org.springframework.jdbc.core.simple.JdbcClient;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.security.oauth2.server.resource.authentication.JwtAuthenticationToken;
import org.springframework.transaction.IllegalTransactionStateException;
import org.springframework.transaction.support.TransactionSynchronizationManager;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

/**
 * Writes audit events to the {@value #TABLE} table. {@link #append} must be called inside the transaction of the
 * business change (propagation MANDATORY): the event then commits or rolls back with it, and the
 * {@link AuditRelay} ships it to IAM afterwards (at-least-once, idempotent on {@code eventId}).
 *
 * <p>The stored payload is one element of the {@code events} array of IAM's ingest API
 * ({@code POST /internal/audit/events}); IAM sets the {@code source} from the application token and redacts
 * sensitive keys.
 */
public class AuditOutbox {

  public static final String TABLE = "iam_audit_outbox";

  private final JdbcClient jdbc;
  private final ObjectMapper mapper;
  private final Clock clock;

  public AuditOutbox(DataSource dataSource, ObjectMapper mapper, Clock clock) {
    this(JdbcClient.create(dataSource), mapper, clock);
  }

  public AuditOutbox(JdbcClient jdbc, ObjectMapper mapper, Clock clock) {
    this.jdbc = jdbc;
    this.mapper = mapper;
    this.clock = clock;
  }

  /**
   * Appends {@code entry} with the identity of the current {@link TenantContext} (or, without one, of the JWT in the
   * security context) and the current request's IP, user agent and request id.
   *
   * @return the generated event id
   * @throws IllegalTransactionStateException when no transaction is active
   */
  public UUID append(AuditEntry entry) {
    if (!TransactionSynchronizationManager.isActualTransactionActive()) {
      throw new IllegalTransactionStateException(
          "Audit events must be written inside the business transaction (@Transactional); no transaction is active");
    }
    UUID eventId = UUID.randomUUID();
    Instant occurredAt = clock.instant();
    Actor actor = Actor.current();
    ObjectNode event = mapper.createObjectNode();
    event.put("eventId", eventId.toString());
    event.put("occurredAt", occurredAt.toString());
    putUuid(event, "accountId", actor.accountId);
    putUuid(event, "tenantId", actor.tenantId);
    putUuid(event, "actorUserId", actor.userId);
    event.put("actorType", actor.userId == null ? "SYSTEM" : "USER");
    putText(event, "actorIp", requestIp());
    putText(event, "userAgent", requestHeader(HttpHeaders.USER_AGENT));
    putUuid(event, "sessionId", actor.sessionId);
    putText(event, "requestId", actor.requestId);
    event.put("action", entry.action());
    putText(event, "targetType", entry.targetType());
    putText(event, "targetId", entry.targetId());
    event.put("outcome", entry.outcome().name());
    event.set("before", mapper.valueToTree(entry.before()));
    event.set("after", mapper.valueToTree(entry.after()));
    event.set("metadata", mapper.valueToTree(entry.metadata()));
    String json;
    try {
      json = mapper.writeValueAsString(event);
    } catch (JsonProcessingException e) {
      throw new IllegalStateException("Audit event cannot be serialised", e);
    }
    jdbc.sql("INSERT INTO " + TABLE + " (event_id, occurred_at, payload) VALUES (:id, :at, CAST(:payload AS jsonb))")
        .param("id", eventId)
        .param("at", Timestamp.from(occurredAt))
        .param("payload", json)
        .update();
    return eventId;
  }

  private static void putUuid(ObjectNode node, String name, UUID value) {
    if (value == null) {
      node.putNull(name);
    } else {
      node.put(name, value.toString());
    }
  }

  private static void putText(ObjectNode node, String name, String value) {
    if (value == null || value.isBlank()) {
      node.putNull(name);
    } else {
      node.put(name, value);
    }
  }

  private static HttpServletRequest currentRequest() {
    return RequestContextHolder.getRequestAttributes() instanceof ServletRequestAttributes attrs
        ? attrs.getRequest()
        : null;
  }

  private static String requestIp() {
    HttpServletRequest request = currentRequest();
    return request == null ? null : request.getRemoteAddr();
  }

  private static String requestHeader(String name) {
    HttpServletRequest request = currentRequest();
    return request == null ? null : request.getHeader(name);
  }

  /** Identity of the caller: the TenantContext, else the user JWT of the security context. */
  private record Actor(UUID userId, UUID accountId, UUID tenantId, UUID sessionId, String requestId) {

    static Actor current() {
      Optional<TenantContext> context = TenantContext.current();
      if (context.isPresent()) {
        TenantContext c = context.get();
        return new Actor(c.userId(), c.accountId(), c.tenantId(), c.sessionId(), c.requestId());
      }
      String requestId = org.slf4j.MDC.get(com.acme.iam.client.tenant.RequestIdFilter.MDC_KEY);
      Authentication auth = SecurityContextHolder.getContext().getAuthentication();
      if (auth instanceof JwtAuthenticationToken token
          && !Claims.TYPE_APP.equals(token.getToken().getClaimAsString(Claims.TYPE))) {
        Jwt jwt = token.getToken();
        return new Actor(
            uuid(jwt.getSubject()),
            uuid(jwt.getClaimAsString(Claims.ACCOUNT)),
            uuid(jwt.getClaimAsString(Claims.TENANT)),
            uuid(jwt.getClaimAsString(Claims.SESSION)),
            requestId);
      }
      return new Actor(null, null, null, null, requestId);
    }

    private static UUID uuid(String value) {
      try {
        return value == null ? null : UUID.fromString(value);
      } catch (IllegalArgumentException e) {
        return null;
      }
    }
  }
}
