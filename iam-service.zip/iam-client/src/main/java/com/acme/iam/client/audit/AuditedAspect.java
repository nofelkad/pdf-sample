package com.acme.iam.client.audit;

import java.lang.reflect.Method;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.reflect.MethodSignature;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.aop.support.AopUtils;
import org.springframework.core.DefaultParameterNameDiscoverer;
import org.springframework.core.Ordered;
import org.springframework.core.ParameterNameDiscoverer;
import org.springframework.expression.EvaluationContext;
import org.springframework.expression.Expression;
import org.springframework.expression.ExpressionParser;
import org.springframework.expression.spel.standard.SpelExpressionParser;
import org.springframework.expression.spel.support.StandardEvaluationContext;
import org.springframework.context.expression.MethodBasedEvaluationContext;

/**
 * Implements {@link Audited}: after the annotated method returned, appends an event to the {@link AuditOutbox} in the
 * transaction that is active at that point. The aspect runs with the lowest precedence so that it is nested inside a
 * {@code @Transactional} on the same method.
 */
@Aspect
public class AuditedAspect implements Ordered {

  private static final Logger log = LoggerFactory.getLogger(AuditedAspect.class);

  private final AuditOutbox outbox;
  private final ExpressionParser parser = new SpelExpressionParser();
  private final ParameterNameDiscoverer parameterNames = new DefaultParameterNameDiscoverer();

  public AuditedAspect(AuditOutbox outbox) {
    this.outbox = outbox;
  }

  @AfterReturning(pointcut = "@annotation(audited)", returning = "result")
  public void record(JoinPoint joinPoint, Audited audited, Object result) {
    AuditEntry.Builder entry = AuditEntry.builder(audited.action());
    String targetId = null;
    if (!audited.targetId().isBlank()) {
      try {
        targetId = evaluate(joinPoint, audited.targetId(), result);
      } catch (RuntimeException e) {
        log.warn("@Audited targetId '{}' of '{}' could not be evaluated: {}", audited.targetId(), audited.action(),
            e.getMessage());
        entry.metadata("target_id_error", e.getMessage());
      }
    }
    entry.target(audited.targetType().isBlank() ? null : audited.targetType(), targetId);
    outbox.append(entry.build());
  }

  private String evaluate(JoinPoint joinPoint, String expression, Object result) {
    MethodSignature signature = (MethodSignature) joinPoint.getSignature();
    Method method = AopUtils.getMostSpecificMethod(signature.getMethod(), joinPoint.getTarget().getClass());
    EvaluationContext context = joinPoint.getArgs().length == 0
        ? new StandardEvaluationContext()
        : new MethodBasedEvaluationContext(joinPoint.getTarget(), method, joinPoint.getArgs(), parameterNames);
    context.setVariable("result", result);
    Expression parsed = parser.parseExpression(expression);
    Object value = parsed.getValue(context);
    return value == null ? null : value.toString();
  }

  /** Lowest precedence: inside the transaction advice of the same method. */
  @Override
  public int getOrder() {
    return Ordered.LOWEST_PRECEDENCE;
  }
}
