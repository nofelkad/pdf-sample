package com.acme.iam.client.manifest;

import com.acme.iam.client.IamClientProperties;
import com.acme.iam.client.audit.AuditRelay;
import com.acme.iam.client.http.IamApiClient;
import com.acme.iam.client.http.IamApiClient.ManifestResult;
import com.acme.iam.client.http.IamApiException;
import com.acme.iam.client.http.IamUnavailableException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.fasterxml.jackson.dataformat.yaml.YAMLMapper;
import java.io.IOException;
import java.io.InputStream;
import java.time.Duration;
import java.util.concurrent.Executors;
import java.util.concurrent.RejectedExecutionException;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.DisposableBean;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.ApplicationListener;
import org.springframework.core.io.Resource;

/**
 * Uploads the application's permissions manifest ({@code permissions.yaml}) to IAM once the application is ready:
 * {@code PUT /internal/products/{product-code}/manifest}. The YAML uses the field names of the JSON contract
 * ({@code product}, {@code name}, {@code permissions[]}, {@code system_roles[]}) and is sent as JSON; IAM treats an
 * identical manifest as a no-op, so uploading on every start is cheap.
 *
 * <p>The file is read and validated when this bean is created (a missing or malformed manifest is a build error and
 * fails startup). The upload itself runs on a background thread with exponential backoff and never blocks or fails
 * startup: if IAM is down, a WARN is logged and the upload is retried until it succeeds. A definitive refusal (4xx
 * other than 401/408/429, e.g. {@code product_mismatch}) is logged as ERROR and not retried.
 */
public class ManifestUploader implements ApplicationListener<ApplicationReadyEvent>, DisposableBean {

  public static final String THREAD_NAME = "iam-manifest-upload";
  private static final Logger log = LoggerFactory.getLogger(ManifestUploader.class);
  private static final ObjectMapper YAML = new YAMLMapper();

  private final IamApiClient api;
  private final IamClientProperties.Manifest retry;
  private final String productCode;
  private final String json;

  private volatile ScheduledExecutorService scheduler;
  private volatile boolean uploaded;

  public ManifestUploader(
      IamApiClient api, IamClientProperties properties, Resource manifest, ObjectMapper jsonMapper) {
    this.api = api;
    this.retry = properties.manifest();
    this.productCode = properties.productCode();
    this.json = toJson(manifest, productCode, jsonMapper);
  }

  /** Converts the YAML manifest to the JSON request body; fills {@code product} when the file omits it. */
  public static String toJson(Resource manifest, String productCode, ObjectMapper jsonMapper) {
    JsonNode tree;
    try (InputStream in = manifest.getInputStream()) {
      tree = YAML.readTree(in);
    } catch (IOException e) {
      throw new IllegalStateException(
          "iam.client.manifest-location '" + manifest + "' cannot be read as YAML: " + e.getMessage(), e);
    }
    if (tree == null || !tree.isObject()) {
      throw new IllegalStateException("iam.client.manifest-location '" + manifest + "' must contain a YAML mapping");
    }
    ObjectNode body = (ObjectNode) tree;
    JsonNode declared = body.get("product");
    if (declared == null || declared.asText().isBlank()) {
      body.put("product", productCode);
    } else if (!declared.asText().equals(productCode)) {
      throw new IllegalStateException("Manifest product '" + declared.asText() + "' differs from iam.client.product-code '"
          + productCode + "'; an application may only manage its own product");
    }
    try {
      return jsonMapper.writeValueAsString(body);
    } catch (IOException e) {
      throw new IllegalStateException("Manifest cannot be converted to JSON", e);
    }
  }

  /** The JSON body that is uploaded. */
  public String json() {
    return json;
  }

  public boolean isUploaded() {
    return uploaded;
  }

  @Override
  public void onApplicationEvent(ApplicationReadyEvent event) {
    start();
  }

  /** Starts the background upload (also called by tests). */
  public synchronized void start() {
    if (scheduler != null) {
      return;
    }
    scheduler = Executors.newSingleThreadScheduledExecutor(r -> {
      Thread t = new Thread(r, THREAD_NAME);
      t.setDaemon(true);
      return t;
    });
    scheduler.execute(() -> attempt(1));
  }

  public synchronized void stop() {
    if (scheduler != null) {
      scheduler.shutdownNow();
      scheduler = null;
    }
  }

  @Override
  public void destroy() {
    stop();
  }

  private void attempt(int attempt) {
    try {
      ManifestResult result = api.putManifest(productCode, json);
      uploaded = true;
      log.info("Manifest of product {} uploaded to IAM (changed={}, permissions +{} ~{} -{}, roles changed {})",
          productCode, result.changed(), result.permissionsAdded(), result.permissionsUpdated(),
          result.permissionsDeprecated(), result.rolesChanged());
      return;
    } catch (IamApiException e) {
      if (e.status() != 401 && e.status() != 408) {
        log.error("IAM refused the manifest of product {} (HTTP {}); not retrying, fix the manifest or the client"
            + " registration: {}", productCode, e.status(), e.body());
        return;
      }
      warn(attempt, e.getMessage());
    } catch (IamUnavailableException e) {
      warn(attempt, e.getMessage());
    } catch (RuntimeException e) {
      warn(attempt, e.toString());
    }
    ScheduledExecutorService s = scheduler;
    if (s != null) {
      Duration delay = AuditRelay.backoff(attempt, retry.retryInitialDelay(), retry.retryMaxDelay());
      try {
        s.schedule(() -> attempt(attempt + 1), delay.toMillis(), TimeUnit.MILLISECONDS);
      } catch (RejectedExecutionException ignored) {
        // shutting down
      }
    }
  }

  private void warn(int attempt, String message) {
    if (attempt == 1 || attempt % 10 == 0) {
      log.warn("Manifest upload to IAM failed (attempt {}), retrying in the background: {}", attempt, message);
    }
  }
}
