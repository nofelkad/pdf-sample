package com.acme.iam.client.tenant;

import com.acme.iam.client.security.IamJwtValidator;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.oauth2.server.resource.authentication.JwtAuthenticationToken;
import org.springframework.web.filter.OncePerRequestFilter;

/**
 * Binds {@link TenantContext} for the duration of an authenticated user request. Placed after the bearer and
 * revocation filters in the security chain, so it only ever sees accepted tokens. Application tokens get no context.
 * Not a Spring bean (see {@code RevocationFilter}).
 */
public class TenantContextFilter extends OncePerRequestFilter {

  @Override
  protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain chain)
      throws ServletException, IOException {
    Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
    if (authentication instanceof JwtAuthenticationToken token && !IamJwtValidator.isApp(token.getToken())) {
      TenantContext context = TenantContext.from(token.getToken(), RequestIdFilter.currentRequestId(request));
      try (TenantContext.Scope ignored = TenantContext.bind(context)) {
        chain.doFilter(request, response);
      }
      return;
    }
    chain.doFilter(request, response);
  }
}
