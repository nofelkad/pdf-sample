package com.acme.iam.client.http;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.databind.json.JsonMapper;

/** The starter's own JSON mapper: all Jackson modules on the classpath (JavaTime...), ISO-8601 dates. */
public final class IamJson {

  private static final ObjectMapper MAPPER = JsonMapper.builder()
      .findAndAddModules()
      .disable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS)
      .build();

  private IamJson() {}

  /** Shared, thread-safe mapper; do not reconfigure it. */
  public static ObjectMapper mapper() {
    return MAPPER;
  }
}
