package com.acme.iam.client.autoconfigure;

import com.acme.iam.client.audit.AuditOutbox;
import com.acme.iam.client.audit.AuditRelay;
import com.acme.iam.client.metrics.IamClientMetrics;
import com.acme.iam.client.revocation.RevocationPoller;
import io.micrometer.core.instrument.MeterRegistry;
import io.micrometer.core.instrument.binder.MeterBinder;
import java.time.Clock;
import java.time.Duration;
import javax.sql.DataSource;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.AutoConfiguration;
import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.jdbc.core.simple.JdbcClient;

/**
 * Operational meters of the starter (P1-11.5, see {@link IamClientMetrics}): active when the application has a
 * Micrometer registry and the audit outbox. Spring Boot binds every {@link MeterBinder} bean to the registry.
 * {@code iam.client.metrics.outbox-cache-ttl} (default 5 s) bounds how often the outbox is queried.
 */
@AutoConfiguration(after = {IamAuditAutoConfiguration.class, IamResourceServerAutoConfiguration.class})
@ConditionalOnProperty(prefix = "iam.client", name = "enabled", havingValue = "true", matchIfMissing = true)
@ConditionalOnClass(MeterRegistry.class)
@ConditionalOnBean({DataSource.class, AuditOutbox.class})
public class IamClientMetricsAutoConfiguration {

  @Bean
  @ConditionalOnMissingBean
  IamClientMetrics iamClientMetrics(
      DataSource dataSource,
      Clock clock,
      ObjectProvider<AuditRelay> relay,
      ObjectProvider<RevocationPoller> poller,
      @Value("${iam.client.metrics.outbox-cache-ttl:PT5S}") Duration cacheTtl) {
    return new IamClientMetrics(
        JdbcClient.create(dataSource),
        clock,
        cacheTtl,
        () -> {
          AuditRelay r = relay.getIfAvailable();
          return r == null ? 0 : r.consecutiveFailures();
        },
        () -> {
          RevocationPoller p = poller.getIfAvailable();
          return p == null ? null : p.staleness();
        });
  }
}
