package com.acme.iam.client.http;

/**
 * IAM answered with a client-side error (4xx other than 429). Retrying the same request will not help unless the
 * configuration or credentials change.
 */
public class IamApiException extends RuntimeException {

  private static final long serialVersionUID = 1L;

  private final int status;
  private final String body;

  public IamApiException(int status, String body) {
    super("IAM answered HTTP " + status + (body == null || body.isBlank() ? "" : ": " + abbreviate(body)));
    this.status = status;
    this.body = body;
  }

  public int status() {
    return status;
  }

  public String body() {
    return body;
  }

  private static String abbreviate(String text) {
    return text.length() <= 300 ? text : text.substring(0, 300) + "...";
  }
}
