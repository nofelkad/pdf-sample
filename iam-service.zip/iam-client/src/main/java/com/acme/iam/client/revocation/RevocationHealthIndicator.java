package com.acme.iam.client.revocation;

import com.acme.iam.client.IamClientProperties;
import java.time.Duration;
import org.springframework.boot.actuate.health.AbstractHealthIndicator;
import org.springframework.boot.actuate.health.Health;
import org.springframework.boot.actuate.health.Status;

/**
 * Health of the revocation feed ({@code /actuator/health/iamRevocation}). {@code UP} while the last successful poll is
 * younger than {@code iam.client.revocation.stale-after}; {@code DEGRADED} when IAM has been unreachable longer
 * (revocations are then not being seen, a security-relevant condition worth alerting on), or before the first
 * successful poll.
 *
 * <p>{@code DEGRADED} is deliberately not one of Spring Boot's ranked statuses, so it does <em>not</em> change the
 * aggregate {@code /actuator/health} (which stays {@code UP}, HTTP 200): a load balancer must not pull every instance
 * of an application out of rotation because IAM is down, when each instance keeps serving with the last known state.
 * To make it count in a health group, opt in explicitly, see the README.
 */
public class RevocationHealthIndicator extends AbstractHealthIndicator {

  /** Custom status: not ranked by Spring Boot, so it never turns the aggregate health DOWN. */
  public static final Status DEGRADED = new Status("DEGRADED");

  private final RevocationPoller poller;
  private final Duration staleAfter;

  public RevocationHealthIndicator(RevocationPoller poller, IamClientProperties.Revocation config) {
    super("IAM revocation feed health check failed");
    this.poller = poller;
    this.staleAfter = config.staleAfter();
  }

  @Override
  protected void doHealthCheck(Health.Builder builder) {
    Duration staleness = poller.staleness();
    boolean healthy = staleness != null && staleness.compareTo(staleAfter) <= 0;
    builder.status(healthy ? Status.UP : DEGRADED)
        .withDetail("cursor", poller.registry().lastCursor())
        .withDetail("trackedUsers", poller.registry().size())
        .withDetail("consecutiveFailures", poller.consecutiveFailures());
    if (poller.lastSuccess() != null) {
      builder.withDetail("lastSuccess", poller.lastSuccess().toString());
    }
    if (poller.lastError() != null) {
      builder.withDetail("lastError", poller.lastError());
    }
  }
}
