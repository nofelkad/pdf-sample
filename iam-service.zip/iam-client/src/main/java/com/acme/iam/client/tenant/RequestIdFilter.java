package com.acme.iam.client.tenant;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.UUID;
import java.util.regex.Pattern;
import org.slf4j.MDC;
import org.springframework.web.filter.OncePerRequestFilter;

/**
 * Establishes the request id: the inbound {@code X-Request-Id} when it matches {@code [A-Za-z0-9._-]{1,64}}, else an
 * id already in the MDC (set by the application's own filter), else a new UUID. It is published as request attribute,
 * MDC key {@code requestId}, response header {@code X-Request-Id}, and ends up in {@link TenantContext} and in
 * {@code @Audited} events. Runs first in the starter's filter chain.
 */
public class RequestIdFilter extends OncePerRequestFilter {

  public static final String HEADER = "X-Request-Id";
  public static final String MDC_KEY = "requestId";
  public static final String ATTRIBUTE = RequestIdFilter.class.getName() + ".REQUEST_ID";

  private static final Pattern VALID = Pattern.compile("[A-Za-z0-9._-]{1,64}");

  /** The request id of {@code request}, or {@code null} before this filter ran. */
  public static String currentRequestId(HttpServletRequest request) {
    Object attribute = request.getAttribute(ATTRIBUTE);
    return attribute instanceof String s ? s : MDC.get(MDC_KEY);
  }

  @Override
  protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain chain)
      throws ServletException, IOException {
    String inbound = request.getHeader(HEADER);
    String existing = MDC.get(MDC_KEY);
    String requestId = inbound != null && VALID.matcher(inbound).matches()
        ? inbound
        : existing != null ? existing : UUID.randomUUID().toString();
    request.setAttribute(ATTRIBUTE, requestId);
    response.setHeader(HEADER, requestId);
    boolean setMdc = !requestId.equals(existing);
    if (setMdc) {
      MDC.put(MDC_KEY, requestId);
    }
    try {
      chain.doFilter(request, response);
    } finally {
      if (setMdc) {
        if (existing == null) {
          MDC.remove(MDC_KEY);
        } else {
          MDC.put(MDC_KEY, existing);
        }
      }
    }
  }
}
