package com.acme.iam.client.security;

import com.acme.iam.core.Claims;
import java.util.List;
import java.util.UUID;
import org.springframework.security.oauth2.core.OAuth2Error;
import org.springframework.security.oauth2.core.OAuth2ErrorCodes;
import org.springframework.security.oauth2.core.OAuth2TokenValidator;
import org.springframework.security.oauth2.core.OAuth2TokenValidatorResult;
import org.springframework.security.oauth2.jwt.Jwt;

/**
 * Structural check of IAM tokens after signature, issuer and timestamp validation:
 *
 * <ul>
 *   <li>{@code exp} is present;
 *   <li>application tokens ({@code typ=app}) are rejected unless {@code iam.client.accept-app-tokens=true}: an
 *       application's own credentials must never open the application's user endpoints;
 *   <li>user tokens carry UUID {@code sub}, {@code acc}, {@code tid}, {@code sid}, an integer {@code sv} and a
 *       {@code perms} array of strings, so downstream code can rely on them.
 * </ul>
 */
public final class IamJwtValidator implements OAuth2TokenValidator<Jwt> {

  private static final OAuth2Error MALFORMED =
      new OAuth2Error(OAuth2ErrorCodes.INVALID_TOKEN, "The token is missing required IAM claims", null);
  private static final OAuth2Error APP_TOKEN =
      new OAuth2Error(OAuth2ErrorCodes.INVALID_TOKEN, "Application tokens are not accepted on this endpoint", null);

  private final boolean acceptAppTokens;

  public IamJwtValidator(boolean acceptAppTokens) {
    this.acceptAppTokens = acceptAppTokens;
  }

  /** {@code true} for application (client-credentials) tokens. */
  public static boolean isApp(Jwt jwt) {
    return Claims.TYPE_APP.equals(jwt.getClaimAsString(Claims.TYPE));
  }

  @Override
  public OAuth2TokenValidatorResult validate(Jwt jwt) {
    if (jwt.getExpiresAt() == null) {
      return OAuth2TokenValidatorResult.failure(MALFORMED);
    }
    if (isApp(jwt)) {
      if (!acceptAppTokens) {
        return OAuth2TokenValidatorResult.failure(APP_TOKEN);
      }
      String subject = jwt.getSubject();
      return subject != null && subject.startsWith(Claims.APP_SUBJECT_PREFIX)
          ? OAuth2TokenValidatorResult.success()
          : OAuth2TokenValidatorResult.failure(MALFORMED);
    }
    boolean valid = isUuid(jwt.getSubject())
        && List.of(Claims.ACCOUNT, Claims.TENANT, Claims.SESSION).stream()
            .allMatch(c -> isUuid(jwt.getClaimAsString(c)))
        && jwt.getClaim(Claims.SESSION_VERSION) instanceof Number
        && isStringList(jwt.getClaim(Claims.PERMISSIONS));
    return valid ? OAuth2TokenValidatorResult.success() : OAuth2TokenValidatorResult.failure(MALFORMED);
  }

  private static boolean isStringList(Object value) {
    return value instanceof List<?> list && list.stream().allMatch(String.class::isInstance);
  }

  private static boolean isUuid(String value) {
    if (value == null) {
      return false;
    }
    try {
      UUID.fromString(value);
      return true;
    } catch (IllegalArgumentException e) {
      return false;
    }
  }
}
