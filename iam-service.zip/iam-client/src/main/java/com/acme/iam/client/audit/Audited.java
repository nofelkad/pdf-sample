package com.acme.iam.client.audit;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * Records an audit event when the annotated method returns normally. The event is written to the
 * {@code iam_audit_outbox} table <b>in the caller's transaction</b> (so it commits and rolls back together with the
 * business change) and shipped to IAM by the relay.
 *
 * <p><b>A transaction is required</b> (propagation MANDATORY): the method must run inside an active Spring
 * transaction, normally by also being {@code @Transactional}. Without one, the call fails with
 * {@link org.springframework.transaction.IllegalTransactionStateException} instead of silently writing an event that
 * could survive a rolled-back change. When the method throws, nothing is recorded (the business change did not
 * happen). To record a {@code DENIED} or {@code FAILURE} event for an operation that fails, call
 * {@link AuditOutbox#append} yourself inside a transaction you open explicitly with {@code REQUIRES_NEW}
 * ({@code TransactionTemplate} with {@code PROPAGATION_REQUIRES_NEW}); in the failing transaction the row would be rolled
 * back together with the rest.
 *
 * <p>Actor, account, tenant, session and request id come from the {@link com.acme.iam.client.tenant.TenantContext},
 * IP and user agent from the current HTTP request.
 *
 * <pre>{@code
 * @Transactional
 * @Audited(action = "invoice.approved", targetType = "invoice", targetId = "#id")
 * public void approve(UUID id) { ... }
 * }</pre>
 *
 * <p>The attributes {@link #targetType()} and {@link #targetId()} are plain text / SpEL as documented below.
 */
@Documented
@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.METHOD)
public @interface Audited {

  /** Event name, e.g. {@code invoice.approved}. */
  String action();

  /** Type of the affected object, e.g. {@code invoice}. Literal text. */
  String targetType() default "";

  /**
   * SpEL expression for the id of the affected object, evaluated after the method returned. Method arguments are
   * available by name ({@code #id}, {@code #request.invoiceId}; needs {@code -parameters}, which Spring Boot builds
   * enable) or position ({@code #p0}, {@code #a0}); the return value is {@code #result}. Empty means no target id.
   * If the expression fails, the event is still recorded without target id and {@code metadata.target_id_error} says
   * why.
   */
  String targetId() default "";
}
