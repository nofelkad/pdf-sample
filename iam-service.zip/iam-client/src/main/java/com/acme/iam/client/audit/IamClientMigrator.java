package com.acme.iam.client.audit;

import javax.sql.DataSource;
import org.flywaydb.core.Flyway;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.InitializingBean;

/**
 * Applies the starter's own migrations ({@code classpath:db/iam-client}, currently {@code V1__iam_audit_outbox.sql}) with
 * a dedicated Flyway instance and its own history table {@value #HISTORY_TABLE} (Ruling R27). The host application's
 * Flyway configuration, history table and version numbers are never touched, so they cannot collide with the starter's.
 *
 * <p>Not exposed as a {@link Flyway} bean (that would switch off Spring Boot's own Flyway auto-configuration). It runs
 * on bean creation, after the host's Flyway migration (see the auto-configuration) and before the outbox or the relay
 * is used. {@code baselineOnMigrate} lets it work in a schema that already holds tables without a history table; the
 * script is idempotent ({@code CREATE TABLE IF NOT EXISTS}).
 */
public class IamClientMigrator implements InitializingBean {

  public static final String LOCATION = "classpath:db/iam-client";
  public static final String HISTORY_TABLE = "iam_client_schema_history";
  private static final Logger log = LoggerFactory.getLogger(IamClientMigrator.class);

  private final DataSource dataSource;

  public IamClientMigrator(DataSource dataSource) {
    this.dataSource = dataSource;
  }

  /** Runs the migrations; returns the number applied. */
  public int migrate() {
    return Flyway.configure()
        .dataSource(dataSource)
        .locations(LOCATION)
        .table(HISTORY_TABLE)
        .baselineOnMigrate(true)
        .baselineVersion("0")
        .load()
        .migrate()
        .migrationsExecuted;
  }

  @Override
  public void afterPropertiesSet() {
    int applied = migrate();
    if (applied > 0) {
      log.info("Applied {} iam-client migration(s) (history table {})", applied, HISTORY_TABLE);
    }
  }
}
