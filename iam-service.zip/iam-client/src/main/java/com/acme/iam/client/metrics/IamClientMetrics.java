package com.acme.iam.client.metrics;

import io.micrometer.core.instrument.Gauge;
import io.micrometer.core.instrument.MeterRegistry;
import io.micrometer.core.instrument.binder.MeterBinder;
import java.time.Clock;
import java.time.Duration;
import java.time.Instant;
import java.time.OffsetDateTime;
import java.util.function.IntSupplier;
import java.util.function.Supplier;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.core.simple.JdbcClient;

/**
 * Operational meters of the iam-client starter (P1-11.5), registered when the application has a Micrometer registry
 * (Spring Boot Actuator):
 *
 * <ul>
 *   <li>{@value #OUTBOX_DEPTH}: rows in {@code iam_audit_outbox}, i.e. audit events written by the application that
 *       IAM has not yet acknowledged. Climbs while IAM is unreachable or rejecting batches; should hover near 0.
 *   <li>{@value #OUTBOX_OLDEST_AGE} (seconds): age of the oldest of those rows; 0 when the outbox is empty. This is
 *       the lag of the application's audit trail: alert when it passes a few minutes.
 *   <li>{@value #RELAY_FAILURES}: consecutive failed relay runs (0 when healthy; the relay backs off up to
 *       {@code iam.client.audit.relay.max-backoff}).
 *   <li>{@value #REVOCATION_POLL_AGE} (seconds): time since the revocation poller last read IAM's feed
 *       successfully; NaN before the first success. Alert above {@code iam.client.revocation.stale-after}: the
 *       application is not seeing revocations.
 * </ul>
 *
 * The two outbox gauges share one {@code SELECT count(*), min(created_at)}, cached for {@code cacheTtl} (5 s by
 * default) so a scrape never costs more than one query however many series are read. The outbox is near-empty
 * unless IAM has been unreachable for a long time.
 */
public class IamClientMetrics implements MeterBinder {

  public static final String OUTBOX_DEPTH = "iam.client.audit.outbox.depth";
  public static final String OUTBOX_OLDEST_AGE = "iam.client.audit.outbox.oldest.age";
  public static final String RELAY_FAILURES = "iam.client.audit.relay.failures";
  public static final String REVOCATION_POLL_AGE = "iam.client.revocation.poll.age";

  private static final Logger log = LoggerFactory.getLogger(IamClientMetrics.class);

  private record Snapshot(double depth, double oldestAgeSeconds, Instant takenAt) {}

  private final JdbcClient jdbc;
  private final Clock clock;
  private final Duration cacheTtl;
  private final IntSupplier relayFailures;
  private final Supplier<Duration> pollAge;
  private volatile Snapshot snapshot;

  /**
   * @param relayFailures consecutive failed relay runs
   * @param pollAge       time since the last successful revocation poll, {@code null} when there has been none
   */
  public IamClientMetrics(JdbcClient jdbc, Clock clock, Duration cacheTtl, IntSupplier relayFailures,
                          Supplier<Duration> pollAge) {
    this.jdbc = jdbc;
    this.clock = clock;
    this.cacheTtl = cacheTtl;
    this.relayFailures = relayFailures;
    this.pollAge = pollAge;
  }

  @Override
  public void bindTo(MeterRegistry registry) {
    Gauge.builder(OUTBOX_DEPTH, this, m -> m.outbox().depth())
        .description("Audit events waiting in the iam_audit_outbox for delivery to IAM")
        .strongReference(true).register(registry);
    Gauge.builder(OUTBOX_OLDEST_AGE, this, m -> m.outbox().oldestAgeSeconds())
        .description("Age of the oldest event in the iam_audit_outbox (0 when empty)")
        .baseUnit("seconds").strongReference(true).register(registry);
    Gauge.builder(RELAY_FAILURES, relayFailures, IntSupplier::getAsInt)
        .description("Consecutive failed runs of the audit relay")
        .strongReference(true).register(registry);
    Gauge.builder(REVOCATION_POLL_AGE, pollAge, supplier -> {
          Duration age = supplier.get();
          return age == null ? Double.NaN : age.toMillis() / 1000.0;
        })
        .description("Time since the revocation poller last read IAM's feed successfully")
        .baseUnit("seconds").strongReference(true).register(registry);
  }

  private Snapshot outbox() {
    Snapshot current = snapshot;
    Instant now = clock.instant();
    if (current != null && Duration.between(current.takenAt(), now).compareTo(cacheTtl) < 0) {
      return current;
    }
    Snapshot fresh;
    try {
      fresh = jdbc.sql("SELECT count(*) AS depth, min(created_at) AS oldest FROM iam_audit_outbox")
          .query((rs, i) -> {
            OffsetDateTime oldest = rs.getObject("oldest", OffsetDateTime.class);
            double age = oldest == null ? 0 : Math.max(0, (now.toEpochMilli() - oldest.toInstant().toEpochMilli()) / 1000.0);
            return new Snapshot(rs.getLong("depth"), age, now);
          })
          .single();
    } catch (RuntimeException e) {
      log.debug("Could not read the iam_audit_outbox for metrics", e);
      fresh = new Snapshot(Double.NaN, Double.NaN, now);
    }
    snapshot = fresh;
    return fresh;
  }
}
