package com.acme.iam.client.security;

import com.acme.iam.core.NoDataScopeException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

/**
 * Maps the core {@link NoDataScopeException} (thrown when application code calls the Spring-free
 * {@code DataScope.of(...)} directly) to the same 403 problem response an {@code AccessDeniedException} produces.
 * {@link IamDataScope} already converts it to {@code AccessDeniedException} itself.
 */
@RestControllerAdvice
public class NoDataScopeExceptionHandler {

  private final ProblemResponseWriter problems;

  public NoDataScopeExceptionHandler(ProblemResponseWriter problems) {
    this.problems = problems;
  }

  @ExceptionHandler(NoDataScopeException.class)
  public void handle(NoDataScopeException e, HttpServletRequest request, HttpServletResponse response)
      throws IOException {
    problems.write(request, response, HttpStatus.FORBIDDEN, "forbidden", "Access is denied");
  }
}
