package com.acme.iam.client.security;

import com.acme.iam.client.tenant.RequestIdFilter;
import com.acme.iam.client.tenant.TenantContextFilter;
import com.acme.iam.core.revocation.RevocationRegistry;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import org.springframework.core.convert.converter.Converter;
import org.springframework.http.HttpStatus;
import org.springframework.security.authentication.AbstractAuthenticationToken;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.security.oauth2.jwt.JwtDecoder;
import org.springframework.security.oauth2.server.resource.web.authentication.BearerTokenAuthenticationFilter;
import org.springframework.security.web.AuthenticationEntryPoint;
import org.springframework.security.web.access.AccessDeniedHandler;
import org.springframework.security.web.savedrequest.NullRequestCache;
import org.springframework.security.web.session.DisableEncodeUrlFilter;

/**
 * Wires IAM resource-server behaviour into an {@link HttpSecurity}: stateless, CSRF off (bearer tokens only), JWT
 * validation against IAM's JWKS, {@code perms} to authorities, request id, {@link RevocationFilter} right after the
 * bearer filter, {@link com.acme.iam.client.tenant.TenantContextFilter} after that, and RFC 7807 401/403 bodies.
 *
 * <p>The starter's default filter chain uses it; an application that defines its own {@code SecurityFilterChain}
 * keeps all of this with one call:
 *
 * <pre>{@code
 * @Bean
 * SecurityFilterChain api(HttpSecurity http, IamSecurity iam) throws Exception {
 *   return iam.apply(http.securityMatcher("/api/**"))
 *       .authorizeHttpRequests(a -> a.anyRequest().authenticated())
 *       .build();
 * }
 * }</pre>
 */
public class IamSecurity {

  private final JwtDecoder decoder;
  private final Converter<Jwt, ? extends AbstractAuthenticationToken> converter;
  private final RevocationRegistry registry;
  private final ProblemResponseWriter problems;

  public IamSecurity(
      JwtDecoder decoder,
      Converter<Jwt, ? extends AbstractAuthenticationToken> converter,
      RevocationRegistry registry,
      ProblemResponseWriter problems) {
    this.decoder = decoder;
    this.converter = converter;
    this.registry = registry;
    this.problems = problems;
  }

  /** Applies the IAM resource-server configuration to {@code http} and returns it. */
  @SuppressWarnings("unchecked")
  public HttpSecurity apply(HttpSecurity http) throws Exception {
    AuthenticationEntryPoint entryPoint = this::unauthorized;
    AccessDeniedHandler accessDenied = this::forbidden;
    Converter<Jwt, AbstractAuthenticationToken> jwtConverter = (Converter<Jwt, AbstractAuthenticationToken>) converter;
    http.csrf(csrf -> csrf.disable())
        .sessionManagement(s -> s.sessionCreationPolicy(SessionCreationPolicy.STATELESS))
        .requestCache(cache -> cache.requestCache(new NullRequestCache()))
        .oauth2ResourceServer(o -> o.jwt(j -> j.decoder(decoder).jwtAuthenticationConverter(jwtConverter))
            .authenticationEntryPoint(entryPoint)
            .accessDeniedHandler(accessDenied))
        .exceptionHandling(e -> e.authenticationEntryPoint(entryPoint).accessDeniedHandler(accessDenied))
        .addFilterBefore(new RequestIdFilter(), DisableEncodeUrlFilter.class)
        .addFilterAfter(new RevocationFilter(registry, problems), BearerTokenAuthenticationFilter.class)
        .addFilterAfter(new TenantContextFilter(), RevocationFilter.class);
    return http;
  }

  /** 401: {@code WWW-Authenticate: Bearer} challenge and a problem body ({@code unauthorized} / {@code invalid_token}). */
  private void unauthorized(
      HttpServletRequest request, HttpServletResponse response, org.springframework.security.core.AuthenticationException e)
      throws IOException {
    boolean presented = request.getHeader("Authorization") != null;
    String code = presented ? "invalid_token" : "unauthorized";
    response.setHeader("WWW-Authenticate", presented ? "Bearer error=\"invalid_token\"" : "Bearer");
    problems.write(request, response, HttpStatus.UNAUTHORIZED, code,
        presented ? "The access token is invalid or expired" : "Authentication is required");
  }

  /** 403 with a problem body ({@code forbidden}). */
  private void forbidden(
      HttpServletRequest request, HttpServletResponse response, org.springframework.security.access.AccessDeniedException e)
      throws IOException {
    problems.write(request, response, HttpStatus.FORBIDDEN, "forbidden", "Access is denied");
  }
}
