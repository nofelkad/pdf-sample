package com.acme.iam.client.audit;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Objects;

/**
 * An application audit event as seen by application code; {@link AuditOutbox} adds identity, time, request context
 * and the event id.
 *
 * @param action event name, e.g. {@code invoice.approved}
 * @param targetType type of the affected object, or {@code null}
 * @param targetId id of the affected object, or {@code null}
 * @param outcome {@code SUCCESS}, {@code DENIED} or {@code FAILURE}
 * @param before state before the change (IAM redacts keys containing password, secret, token, hash, private,
 *     authorization), possibly empty
 * @param after state after the change, possibly empty
 * @param metadata free-form details, possibly empty
 */
public record AuditEntry(
    String action,
    String targetType,
    String targetId,
    Outcome outcome,
    Map<String, Object> before,
    Map<String, Object> after,
    Map<String, Object> metadata) {

  /** Result of the audited operation. */
  public enum Outcome {
    SUCCESS,
    DENIED,
    FAILURE
  }

  public AuditEntry {
    Objects.requireNonNull(action, "action");
    if (action.isBlank()) {
      throw new IllegalArgumentException("action must not be blank");
    }
    outcome = outcome == null ? Outcome.SUCCESS : outcome;
    before = before == null ? Map.of() : before;
    after = after == null ? Map.of() : after;
    metadata = metadata == null ? Map.of() : metadata;
  }

  public static Builder builder(String action) {
    return new Builder(action);
  }

  /** Fluent builder. */
  public static final class Builder {
    private final String action;
    private String targetType;
    private String targetId;
    private Outcome outcome = Outcome.SUCCESS;
    private Map<String, Object> before = new LinkedHashMap<>();
    private Map<String, Object> after = new LinkedHashMap<>();
    private final Map<String, Object> metadata = new LinkedHashMap<>();

    private Builder(String action) {
      this.action = action;
    }

    public Builder target(String type, Object id) {
      this.targetType = type;
      this.targetId = id == null ? null : id.toString();
      return this;
    }

    public Builder outcome(Outcome outcome) {
      this.outcome = outcome;
      return this;
    }

    public Builder before(Map<String, Object> before) {
      this.before = before;
      return this;
    }

    public Builder after(Map<String, Object> after) {
      this.after = after;
      return this;
    }

    public Builder metadata(String key, Object value) {
      this.metadata.put(key, value);
      return this;
    }

    public AuditEntry build() {
      return new AuditEntry(action, targetType, targetId, outcome, before, after, new LinkedHashMap<>(metadata));
    }
  }
}
