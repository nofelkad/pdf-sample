-- iam-client: transactional outbox for application audit events (spec P1-12.4, Rulings R8 and R27).
--
-- @Audited / AuditOutbox.append() insert a row here in the caller's transaction; the AuditRelay ships the rows to
-- IAM (POST /internal/audit/events) and deletes them once IAM accepted, de-duplicated or rejected them.
-- Applied by the starter's own Flyway instance (location classpath:db/iam-client, history table
-- iam_client_schema_history), independent of the host application's Flyway and version numbers.
CREATE TABLE IF NOT EXISTS iam_audit_outbox (
    seq         BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,   -- relay order
    event_id    UUID        NOT NULL UNIQUE,                       -- idempotency key at IAM
    occurred_at TIMESTAMPTZ NOT NULL,
    payload     JSONB       NOT NULL,                              -- one element of the "events" array of the ingest API
    created_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);
