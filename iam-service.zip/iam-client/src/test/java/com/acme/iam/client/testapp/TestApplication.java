package com.acme.iam.client.testapp;

import com.acme.iam.client.audit.Audited;
import com.acme.iam.client.security.IamDataScope;
import com.acme.iam.client.tenant.TenantContext;
import com.acme.iam.core.DataScope.Scope;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.atomic.AtomicReference;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.jdbc.core.simple.JdbcClient;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

/** Minimal application that uses every part of the starter; scanned by the starter's integration tests. */
@SpringBootApplication
@EnableAsync
public class TestApplication {

  public static void main(String[] args) {
    SpringApplication.run(TestApplication.class, args);
  }

  /** The record an audited method returns. */
  public record Approval(UUID id) {}

  @Service
  public static class AuditedService {

    private final JdbcClient jdbc;

    public AuditedService(JdbcClient jdbc) {
      this.jdbc = jdbc;
    }

    @Transactional
    @Audited(action = "invoice.approved", targetType = "invoice", targetId = "#id")
    public void approve(UUID id) {
      jdbc.sql("SELECT 1").query(Integer.class).single();
    }

    @Transactional
    @Audited(action = "invoice.created", targetType = "invoice", targetId = "#result.id()")
    public Approval create() {
      return new Approval(UUID.fromString("00000000-0000-0000-0000-00000000c0de"));
    }

    @Transactional
    @Audited(action = "invoice.rejected", targetType = "invoice", targetId = "#id")
    public void failAfterwards(UUID id) {
      throw new IllegalStateException("business rule violated");
    }

    @Transactional
    @Audited(action = "invoice.broken", targetType = "invoice", targetId = "#nope.id")
    public void brokenExpression() {}

    @Transactional
    @Audited(action = "invoice.no-target")
    public void noTarget() {}

    /** Missing @Transactional: the aspect must refuse to write. */
    @Audited(action = "invoice.no-tx", targetType = "invoice", targetId = "#p0")
    public void noTransaction(UUID id) {}
  }

  @Service
  public static class AsyncProbe {

    private final AtomicReference<TenantContext> seen = new AtomicReference<>();

    public TenantContext seen() {
      return seen.get();
    }

    @Async
    public CompletableFuture<String> capture() {
      seen.set(TenantContext.current().orElse(null));
      return CompletableFuture.completedFuture(Thread.currentThread().getName());
    }

    /** Submitted without a context: must not see a leftover one from an earlier task on the same pooled thread. */
    @Async
    public CompletableFuture<Boolean> leftover() {
      return CompletableFuture.completedFuture(TenantContext.current().isPresent());
    }
  }

  @RestController
  public static class ProbeController {

    private final AuditedService service;
    private final AsyncProbe async;

    public ProbeController(AuditedService service, AsyncProbe async) {
      this.service = service;
      this.async = async;
    }

    @GetMapping("/api/whoami")
    public Map<String, Object> whoami(Authentication authentication) {
      TenantContext ctx = TenantContext.require();
      return Map.of(
          "user", ctx.userId(),
          "account", ctx.accountId(),
          "tenant", ctx.tenantId(),
          "session", ctx.sessionId(),
          "requestId", String.valueOf(ctx.requestId()),
          "authorities", authentication.getAuthorities().stream().map(Object::toString).sorted().toList());
    }

    @GetMapping("/api/secured")
    @PreAuthorize("hasAuthority('billing.invoice.approve')")
    public Map<String, String> secured() {
      return Map.of("ok", "yes");
    }

    @GetMapping("/api/scope")
    public Map<String, Scope> scope(Authentication authentication) {
      return Map.of("scope", IamDataScope.of(authentication, "billing.invoice.read"));
    }

    /** Uses the Spring-free core DataScope directly: the starter maps its exception to 403. */
    @GetMapping("/api/scope-core")
    public Map<String, Scope> scopeCore(Authentication authentication) {
      return Map.of("scope", com.acme.iam.core.DataScope.of(
          authentication.getAuthorities().stream().map(Object::toString).toList(), "billing.invoice.read"));
    }

    @PostMapping("/api/invoices/{id}/approve")
    @PreAuthorize("hasAuthority('billing.invoice.approve')")
    public void approve(@PathVariable UUID id) {
      service.approve(id);
    }

    @GetMapping("/api/async")
    public Map<String, Object> async() throws Exception {
      String thread = async.capture().get();
      TenantContext seen = async.seen();
      return Map.of(
          "thread", thread,
          "tenant", seen == null ? "none" : seen.tenantId().toString());
    }

    @GetMapping("/public/ping")
    public List<String> publicPing() {
      return List.of("pong");
    }
  }
}
