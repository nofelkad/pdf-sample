package com.acme.iam.client.metrics;

import static org.assertj.core.api.Assertions.assertThat;

import com.acme.iam.client.testapp.ClientIT;
import io.micrometer.core.instrument.MeterRegistry;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;

/** The starter registers its operational meters in an application that has a MeterRegistry (actuator). */
class IamClientMetricsWiringIT extends ClientIT {

  @Autowired MeterRegistry meters;

  @Test
  void theOutboxAndFeedMetersAreRegisteredByAutoConfiguration() {
    assertThat(meters.find(IamClientMetrics.OUTBOX_DEPTH).gauge()).isNotNull();
    assertThat(meters.find(IamClientMetrics.OUTBOX_OLDEST_AGE).gauge()).isNotNull();
    assertThat(meters.find(IamClientMetrics.RELAY_FAILURES).gauge()).isNotNull();
    assertThat(meters.find(IamClientMetrics.REVOCATION_POLL_AGE).gauge()).isNotNull();
  }
}
