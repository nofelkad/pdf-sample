package com.acme.iam.client.http;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

import com.acme.iam.client.IamClientProperties;
import com.acme.iam.client.testing.StubIamServer;
import com.acme.iam.client.testing.TestProps;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.time.Clock;
import java.time.Duration;
import java.time.Instant;
import java.time.ZoneOffset;
import java.util.concurrent.atomic.AtomicReference;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class AppTokenProviderTest {

  /** Mutable test clock. */
  private static final class MovableClock extends Clock {
    private final AtomicReference<Instant> now = new AtomicReference<>(Instant.parse("2026-10-10T10:00:00Z"));

    void advance(Duration d) {
      now.updateAndGet(i -> i.plus(d));
    }

    @Override
    public java.time.ZoneId getZone() {
      return ZoneOffset.UTC;
    }

    @Override
    public Clock withZone(java.time.ZoneId zone) {
      return this;
    }

    @Override
    public Instant instant() {
      return now.get();
    }
  }

  private final ObjectMapper mapper = new ObjectMapper();
  private StubIamServer stub;
  private MovableClock clock;
  private AppTokenProvider provider;
  private IamApiClient api;

  @BeforeEach
  void setUp() {
    stub = new StubIamServer();
    clock = new MovableClock();
    IamClientProperties props = TestProps.of(stub);
    IamHttp http = new IamHttp(props);
    provider = new AppTokenProvider(http, props, clock, mapper);
    api = new IamApiClient(http, provider, mapper);
  }

  @AfterEach
  void tearDown() {
    stub.close();
  }

  @Test
  void fetchesWithBasicAuthAndCachesUntilAMinuteBeforeExpiry() {
    String first = provider.token();
    assertThat(first).startsWith("app-token-");
    assertThat(provider.token()).isEqualTo(first);
    assertThat(stub.tokenRequests()).isEqualTo(1); // Basic auth + form body were accepted by the stub

    clock.advance(Duration.ofSeconds(539)); // expires_in 600: renew at 540
    assertThat(provider.token()).isEqualTo(first);
    clock.advance(Duration.ofSeconds(1));
    String second = provider.token();
    assertThat(second).isNotEqualTo(first);
    assertThat(stub.tokenRequests()).isEqualTo(2);
  }

  @Test
  void aVeryShortLivedTokenIsRenewedAtHalfItsLifetime() {
    stub.setTokenExpiresIn(40);
    String first = provider.token();
    clock.advance(Duration.ofSeconds(19));
    assertThat(provider.token()).isEqualTo(first);
    clock.advance(Duration.ofSeconds(1));
    assertThat(provider.token()).isNotEqualTo(first);
  }

  @Test
  void aRejectedTokenIsReplacedAndTheCallRetriedOnce() {
    api.fetchRevocations(null, 10);
    assertThat(stub.tokenRequests()).isEqualTo(1);

    stub.invalidateIssuedTokens(); // IAM no longer knows the cached token (e.g. key rotation)
    api.fetchRevocations(null, 10);

    assertThat(stub.tokenRequests()).isEqualTo(2);
    assertThat(stub.revocationRequests()).hasSize(2); // the 401 is answered before the feed handler records anything
  }

  @Test
  void badClientCredentialsAreAClientError() {
    IamClientProperties good = TestProps.of(stub);
    IamClientProperties bad = new IamClientProperties(good.issuerUri(), null, null, "billing-app", "wrong", "BILLING",
        null, false, good.clockSkew(), good.publicPaths(), good.http(), good.jwks(), good.revocation(), good.audit(),
        good.manifest());
    AppTokenProvider badProvider = new AppTokenProvider(new IamHttp(bad), bad, clock, mapper);
    assertThatThrownBy(badProvider::token).isInstanceOfSatisfying(IamApiException.class,
        e -> assertThat(e.status()).isEqualTo(401));
  }

  @Test
  void unreachableIamIsReportedAsUnavailable() {
    stub.stop();
    assertThatThrownBy(provider::token).isInstanceOf(IamUnavailableException.class);
    assertThatThrownBy(() -> api.postAuditEvents("{\"events\":[]}")).isInstanceOf(IamUnavailableException.class);
  }

  @Test
  void serverErrorsAreUnavailableAndClientErrorsAreNot() {
    stub.failAudit(503);
    assertThatThrownBy(() -> api.postAuditEvents("{\"events\":[]}")).isInstanceOf(IamUnavailableException.class);
    stub.failAudit(429);
    assertThatThrownBy(() -> api.postAuditEvents("{\"events\":[]}")).isInstanceOf(IamUnavailableException.class);
    stub.failAudit(400);
    assertThatThrownBy(() -> api.postAuditEvents("{\"events\":[]}")).isInstanceOfSatisfying(IamApiException.class,
        e -> assertThat(e.status()).isEqualTo(400));
  }
}
