package com.acme.iam.client.manifest;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

import com.acme.iam.client.IamClientProperties;
import com.acme.iam.client.http.AppTokenProvider;
import com.acme.iam.client.http.IamApiClient;
import com.acme.iam.client.http.IamHttp;
import com.acme.iam.client.testing.StubIamServer;
import com.acme.iam.client.testing.TestProps;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.nio.charset.StandardCharsets;
import java.time.Clock;
import java.time.Duration;
import org.awaitility.Awaitility;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

class ManifestUploaderTest {

  private final ObjectMapper mapper = new ObjectMapper();
  private StubIamServer stub;
  private IamClientProperties props;
  private IamApiClient api;
  private ManifestUploader uploader;

  @BeforeEach
  void setUp() {
    stub = new StubIamServer();
    props = TestProps.of(stub);
    IamHttp http = new IamHttp(props);
    api = new IamApiClient(http, new AppTokenProvider(http, props, Clock.systemUTC(), mapper), mapper);
  }

  @AfterEach
  void tearDown() {
    if (uploader != null) {
      uploader.stop();
    }
    stub.close();
  }

  private static Resource yaml(String text) {
    return new ByteArrayResource(text.getBytes(StandardCharsets.UTF_8));
  }

  @Test
  void yamlIsConvertedToTheJsonContractFieldForField() throws Exception {
    String json = ManifestUploader.toJson(new ClassPathResource("permissions-test.yaml"), "BILLING", mapper);
    JsonNode body = mapper.readTree(json);

    assertThat(body.path("product").asText()).isEqualTo("BILLING");
    assertThat(body.path("name").asText()).isEqualTo("Billing");
    assertThat(body.path("permissions")).hasSize(3);
    JsonNode approve = body.path("permissions").get(2);
    assertThat(approve.path("code").asText()).isEqualTo("billing.invoice.approve");
    assertThat(approve.path("kind").asText()).isEqualTo("FEATURE");
    assertThat(approve.path("sensitive").asBoolean()).isTrue();
    assertThat(body.path("system_roles").get(0).path("name").asText()).isEqualTo("Billing Admin");
    assertThat(body.path("system_roles").get(0).path("permissions").get(0).asText()).isEqualTo("billing.*");
  }

  @Test
  void productDefaultsToTheConfiguredCodeAndMismatchesAreRejected() throws Exception {
    JsonNode body = mapper.readTree(ManifestUploader.toJson(yaml("permissions: []"), "BILLING", mapper));
    assertThat(body.path("product").asText()).isEqualTo("BILLING");

    assertThatThrownBy(() -> ManifestUploader.toJson(yaml("product: CRM\npermissions: []"), "BILLING", mapper))
        .isInstanceOf(IllegalStateException.class)
        .hasMessageContaining("CRM")
        .hasMessageContaining("BILLING");
    assertThatThrownBy(() -> ManifestUploader.toJson(yaml("- a\n- b"), "BILLING", mapper))
        .isInstanceOf(IllegalStateException.class);
    assertThatThrownBy(() -> ManifestUploader.toJson(yaml("product: [unclosed"), "BILLING", mapper))
        .isInstanceOf(IllegalStateException.class);
  }

  @Test
  void uploadsToTheProductEndpoint() {
    uploader = new ManifestUploader(api, props, new ClassPathResource("permissions-test.yaml"), mapper);
    uploader.start();

    Awaitility.await().atMost(Duration.ofSeconds(5)).until(uploader::isUploaded);
    assertThat(stub.manifests()).hasSize(1);
    assertThat(stub.manifests().get(0).path()).isEqualTo("/internal/products/BILLING/manifest");
    assertThat(stub.manifests().get(0).body()).isEqualTo(uploader.json());
  }

  @Test
  void retriesInTheBackgroundWhileIamIsDownAndStartDoesNotBlockOrThrow() {
    stub.stop();
    uploader = new ManifestUploader(api, props, new ClassPathResource("permissions-test.yaml"), mapper);
    long begin = System.nanoTime();
    uploader.start(); // returns immediately
    assertThat(Duration.ofNanos(System.nanoTime() - begin)).isLessThan(Duration.ofSeconds(1));

    sleepMillis(500);
    assertThat(uploader.isUploaded()).isFalse();

    stub.start();
    Awaitility.await().atMost(Duration.ofSeconds(5)).until(uploader::isUploaded);
    assertThat(stub.manifests()).hasSize(1);
  }

  @Test
  void retriesServerErrorsWithBackoffThenSucceeds() {
    stub.failManifest(503, 3);
    uploader = new ManifestUploader(api, props, new ClassPathResource("permissions-test.yaml"), mapper);
    uploader.start();

    Awaitility.await().atMost(Duration.ofSeconds(5)).until(uploader::isUploaded);
    assertThat(stub.manifestRequests()).isEqualTo(4);
  }

  @Test
  void aDefinitiveRefusalIsNotRetried() {
    stub.failManifest(400, 100);
    uploader = new ManifestUploader(api, props, new ClassPathResource("permissions-test.yaml"), mapper);
    uploader.start();

    sleepMillis(800);
    assertThat(uploader.isUploaded()).isFalse();
    assertThat(stub.manifestRequests()).isEqualTo(1);
  }

  private static void sleepMillis(long millis) {
    try {
      Thread.sleep(millis);
    } catch (InterruptedException e) {
      Thread.currentThread().interrupt();
    }
  }
}
