package com.acme.iam.client.testapp;

import com.acme.iam.client.testing.PostgresTestBase;
import com.acme.iam.client.testing.StubIamServer;
import com.acme.iam.client.testing.TestJwts;
import com.nimbusds.jose.jwk.RSAKey;
import java.util.UUID;
import org.junit.jupiter.api.BeforeEach;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.test.context.DynamicPropertyRegistry;
import org.springframework.test.context.DynamicPropertySource;

/**
 * Full-context test base: the {@link TestApplication} with the starter auto-configured against a {@link StubIamServer}
 * (JWKS, token, revocations, audit ingest, manifest) and a Testcontainers PostgreSQL. One shared context per JVM.
 */
@SpringBootTest(classes = TestApplication.class)
@AutoConfigureMockMvc
public abstract class ClientIT extends PostgresTestBase {

  protected static final StubIamServer STUB = new StubIamServer();
  protected static final RSAKey KEY = TestJwts.newKey("key-1");
  protected static final TestJwts JWTS = new TestJwts(KEY, STUB.baseUrl());

  static {
    STUB.setPublicKeys(KEY);
  }

  @DynamicPropertySource
  static void iamProperties(DynamicPropertyRegistry registry) {
    registry.add("iam.client.issuer-uri", STUB::baseUrl);
    registry.add("iam.client.client-id", () -> StubIamServer.CLIENT_ID);
    registry.add("iam.client.client-secret", () -> StubIamServer.CLIENT_SECRET);
    registry.add("iam.client.product-code", () -> StubIamServer.PRODUCT);
    registry.add("iam.client.manifest-location", () -> "classpath:permissions-test.yaml");
    registry.add("iam.client.public-paths", () -> "/actuator/health/**,/public/**");
    registry.add("iam.client.revocation.poll-interval", () -> "100ms");
    registry.add("iam.client.revocation.stale-after", () -> "2s");
    registry.add("iam.client.audit.relay.interval", () -> "50ms");
    registry.add("iam.client.audit.relay.max-backoff", () -> "300ms");
    registry.add("iam.client.manifest.retry-initial-delay", () -> "50ms");
    registry.add("iam.client.manifest.retry-max-delay", () -> "200ms");
    registry.add("management.endpoints.web.exposure.include", () -> "health");
    registry.add("management.endpoint.health.show-details", () -> "always");
    registry.add("spring.main.banner-mode", () -> "off");
  }

  @BeforeEach
  void resetStubAudit() {
    STUB.failAudit(0);
    STUB.start();
  }

  protected static TestJwts.UserToken user() {
    return JWTS.user(UUID.randomUUID());
  }
}
