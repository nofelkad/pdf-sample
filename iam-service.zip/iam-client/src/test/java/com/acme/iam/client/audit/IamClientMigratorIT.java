package com.acme.iam.client.audit;

import static org.assertj.core.api.Assertions.assertThat;

import com.acme.iam.client.testing.PostgresTestBase;
import javax.sql.DataSource;
import org.junit.jupiter.api.Test;
import org.springframework.jdbc.core.simple.JdbcClient;

/** The starter's own Flyway instance: own history table, works in a non-empty schema, idempotent. */
class IamClientMigratorIT extends PostgresTestBase {

  @Test
  void createsTheOutboxInItsOwnHistoryEvenInASchemaThatAlreadyHoldsOtherTables() {
    DataSource ds = dataSource("migrator_it");
    JdbcClient jdbc = JdbcClient.create(ds);
    jdbc.sql("CREATE TABLE host_table (id INT)").update(); // non-empty schema, no Flyway history at all

    IamClientMigrator migrator = new IamClientMigrator(ds);
    assertThat(migrator.migrate()).isEqualTo(1);
    assertThat(migrator.migrate()).isZero(); // idempotent

    assertThat(jdbc.sql("SELECT to_regclass('iam_audit_outbox') IS NOT NULL").query(Boolean.class).single()).isTrue();
    assertThat(jdbc.sql("SELECT script FROM iam_client_schema_history WHERE version = '1'").query(String.class).single())
        .isEqualTo("V1__iam_audit_outbox.sql");
    assertThat(jdbc.sql("SELECT to_regclass('flyway_schema_history') IS NULL").query(Boolean.class).single())
        .isTrue(); // the default history table of a host is not used
  }
}
