package com.acme.iam.client.security;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

import com.acme.iam.core.DataScope.Scope;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Test;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.authentication.TestingAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;

class IamDataScopeTest {

  @AfterEach
  void clear() {
    SecurityContextHolder.clearContext();
  }

  @Test
  void resolvesTheBroadestScopeOfAnAuthentication() {
    var auth = new TestingAuthenticationToken("u", "n", "billing.invoice.read.own", "billing.invoice.read.account");
    assertThat(IamDataScope.of(auth, "billing.invoice.read")).isEqualTo(Scope.ACCOUNT);
  }

  @Test
  void noScopeBecomesAccessDenied() {
    var auth = new TestingAuthenticationToken("u", "n", "billing.invoice.approve");
    assertThatThrownBy(() -> IamDataScope.of(auth, "billing.invoice.read"))
        .isInstanceOf(AccessDeniedException.class)
        .hasMessageContaining("billing.invoice.read");
  }

  @Test
  void noAuthenticationIsAccessDenied() {
    assertThatThrownBy(() -> IamDataScope.of(null, "billing.invoice.read")).isInstanceOf(AccessDeniedException.class);
    assertThatThrownBy(() -> IamDataScope.of("billing.invoice.read")).isInstanceOf(AccessDeniedException.class);
  }

  @Test
  void readsTheCurrentSecurityContext() {
    SecurityContextHolder.getContext()
        .setAuthentication(new TestingAuthenticationToken("u", "n", "billing.invoice.read.tenant"));
    assertThat(IamDataScope.of("billing.invoice.read")).isEqualTo(Scope.TENANT);
  }
}
