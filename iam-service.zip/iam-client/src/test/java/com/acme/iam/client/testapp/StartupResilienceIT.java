package com.acme.iam.client.testapp;

import static org.assertj.core.api.Assertions.assertThat;

import com.acme.iam.client.manifest.ManifestUploader;
import com.acme.iam.client.testing.PostgresTestBase;
import com.acme.iam.client.testing.StubIamServer;
import com.acme.iam.client.testing.TestJwts;
import com.nimbusds.jose.jwk.RSAKey;
import java.time.Duration;
import org.awaitility.Awaitility;
import org.junit.jupiter.api.Test;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.context.ConfigurableApplicationContext;

/** An application must start, serve and eventually register its manifest even when IAM is down at startup. */
class StartupResilienceIT extends PostgresTestBase {

  @Test
  void startsWhileIamIsDownThenUploadsTheManifestAndLoadsRevocationsWhenItReturns() {
    try (StubIamServer iam = new StubIamServer()) {
      RSAKey key = TestJwts.newKey("k");
      iam.setPublicKeys(key);
      iam.stop(); // IAM is down while the application boots

      try (ConfigurableApplicationContext context = new SpringApplicationBuilder(TestApplication.class)
          .properties(
              "server.port=0",
              "spring.main.banner-mode=off",
              "spring.datasource.url=" + POSTGRES.getJdbcUrl(),
              "spring.datasource.username=" + POSTGRES.getUsername(),
              "spring.datasource.password=" + POSTGRES.getPassword(),
              "iam.client.issuer-uri=" + iam.baseUrl(),
              "iam.client.client-id=" + StubIamServer.CLIENT_ID,
              "iam.client.client-secret=" + StubIamServer.CLIENT_SECRET,
              "iam.client.product-code=" + StubIamServer.PRODUCT,
              "iam.client.manifest-location=classpath:permissions-test.yaml",
              "iam.client.revocation.poll-interval=100ms",
              "iam.client.manifest.retry-initial-delay=50ms",
              "iam.client.manifest.retry-max-delay=200ms")
          .run()) {
        assertThat(context.isRunning()).isTrue(); // startup survived the outage
        ManifestUploader uploader = context.getBean(ManifestUploader.class);
        assertThat(uploader.isUploaded()).isFalse();

        iam.start();
        Awaitility.await().atMost(Duration.ofSeconds(10)).until(uploader::isUploaded);
        assertThat(iam.manifests()).hasSize(1);
        assertThat(iam.manifests().get(0).path()).isEqualTo("/internal/products/BILLING/manifest");
        // the revocation poller recovered too
        Awaitility.await().atMost(Duration.ofSeconds(10)).until(() -> !iam.revocationRequests().isEmpty());
      }
    }
  }
}
