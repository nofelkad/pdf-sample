package com.acme.iam.client;

import static org.assertj.core.api.Assertions.assertThat;

import com.acme.iam.client.testing.StubIamServer;
import com.acme.iam.client.testing.TestProps;
import org.junit.jupiter.api.Test;

class IamClientPropertiesTest {

  @Test
  void toStringNeverPrintsTheClientSecret() {
    try (StubIamServer stub = new StubIamServer()) {
      IamClientProperties props = TestProps.of(stub);
      String text = props.toString();
      assertThat(text).doesNotContain(StubIamServer.CLIENT_SECRET).contains("clientSecret=******");
      assertThat(text).contains(StubIamServer.CLIENT_ID).contains(StubIamServer.PRODUCT);
      assertThat(String.valueOf(props)).doesNotContain(StubIamServer.CLIENT_SECRET);
    }
  }
}
