package com.acme.iam.client.security;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

import com.acme.iam.client.IamClientProperties;
import com.acme.iam.client.testing.StubIamServer;
import com.acme.iam.client.testing.TestJwts;
import com.acme.iam.client.testing.TestProps;
import com.nimbusds.jose.jwk.RSAKey;
import com.nimbusds.jwt.JWTClaimsSet;
import java.time.Clock;
import java.time.Duration;
import java.time.Instant;
import java.time.ZoneOffset;
import java.util.Date;
import java.util.UUID;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.security.oauth2.jwt.BadJwtException;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.security.oauth2.jwt.JwtDecoder;
import org.springframework.security.oauth2.jwt.JwtException;

class IamJwtDecoderTest {

  private static final Duration REFRESH_WINDOW = Duration.ofMillis(300);
  private static final Duration LONG_REFRESH_WINDOW = Duration.ofSeconds(3);

  private StubIamServer stub;
  private RSAKey key1;
  private TestJwts jwts1;
  private Clock clock;

  @BeforeEach
  void setUp() {
    stub = new StubIamServer();
    key1 = TestJwts.newKey("key-1");
    stub.setPublicKeys(key1);
    clock = Clock.fixed(Instant.parse("2026-10-10T10:00:00Z"), ZoneOffset.UTC);
    jwts1 = new TestJwts(key1, stub.baseUrl(), clock);
  }

  @AfterEach
  void tearDown() {
    stub.close();
  }

  private IamClientProperties props(Duration cacheTtl) {
    return props(cacheTtl, cacheTtl.compareTo(REFRESH_WINDOW) > 0 ? REFRESH_WINDOW : cacheTtl.dividedBy(2));
  }

  private IamClientProperties props(Duration cacheTtl, Duration refreshWindow) {
    IamClientProperties base = TestProps.of(stub);
    return new IamClientProperties(base.issuerUri(), null, null, base.clientId(), base.clientSecret(),
        base.productCode(), null, false, Duration.ofSeconds(60), base.publicPaths(), base.http(),
        new IamClientProperties.Jwks(cacheTtl, refreshWindow, Duration.ofHours(1)), base.revocation(), base.audit(),
        base.manifest());
  }

  private JwtDecoder decoder(IamClientProperties props) {
    return IamJwtDecoderFactory.create(IamJwtDecoderFactory.jwkSource(props), IamJwtDecoderFactory.validator(props, clock));
  }

  private static void sleep(Duration d) {
    try {
      Thread.sleep(d.toMillis());
    } catch (InterruptedException e) {
      Thread.currentThread().interrupt();
    }
  }

  @Test
  void jwksDefaultsToIssuerWellKnownAndKeysAreCached() {
    JwtDecoder decoder = decoder(props(Duration.ofMinutes(5)));
    for (int i = 0; i < 10; i++) {
      Jwt jwt = decoder.decode(jwts1.user(UUID.randomUUID()).mint());
      assertThat(jwt.getClaimAsStringList("perms")).isEmpty();
    }
    assertThat(stub.jwksRequests()).isEqualTo(1);
  }

  @Test
  void anUnknownKidTriggersARefreshAfterKeyRotation() {
    JwtDecoder decoder = decoder(props(Duration.ofMinutes(5)));
    decoder.decode(jwts1.user(UUID.randomUUID()).mint());
    assertThat(stub.jwksRequests()).isEqualTo(1);

    RSAKey key2 = TestJwts.newKey("key-2");
    String token2 = new TestJwts(key2, stub.baseUrl(), clock).user(UUID.randomUUID()).mint();
    stub.setPublicKeys(key1, key2); // IAM published its new key
    sleep(REFRESH_WINDOW.plusMillis(100));

    assertThat(decoder.decode(token2).getSubject()).isNotBlank();
    assertThat(stub.jwksRequests()).isEqualTo(2);
    decoder.decode(token2); // now cached
    assertThat(stub.jwksRequests()).isEqualTo(2);
  }

  @Test
  void forgedKidsCannotTriggerAJwksRequestPerToken() {
    JwtDecoder decoder = decoder(props(Duration.ofMinutes(5), LONG_REFRESH_WINDOW));
    decoder.decode(jwts1.user(UUID.randomUUID()).mint());
    sleep(Duration.ofMillis(100));
    int before = stub.jwksRequests();

    for (int i = 0; i < 25; i++) {
      String forged = jwts1.user(UUID.randomUUID()).kid("evil-" + i).mint();
      assertThatThrownBy(() -> decoder.decode(forged)).isInstanceOf(JwtException.class);
    }
    assertThat(stub.jwksRequests() - before).isLessThanOrEqualTo(1); // rate limited
  }

  @Test
  void unresolvableKeysAreABadJwtSoTheBearerFilterAnswers401Not500() {
    JwtDecoder decoder = decoder(props(Duration.ofMinutes(5), LONG_REFRESH_WINDOW));
    decoder.decode(jwts1.user(UUID.randomUUID()).mint());
    for (int i = 0; i < 3; i++) { // 2nd and 3rd hit the JWKS rate limit
      String forged = jwts1.user(UUID.randomUUID()).kid("evil-" + i).mint();
      assertThatThrownBy(() -> decoder.decode(forged)).isInstanceOf(BadJwtException.class);
    }
  }

  @Test
  void aJwksOutageLongerThanTheToleranceIsABadJwtToo() {
    IamClientProperties base = props(Duration.ofMillis(100));
    IamClientProperties noTolerance = new IamClientProperties(base.issuerUri(), null, null, base.clientId(),
        base.clientSecret(), base.productCode(), null, false, base.clockSkew(), base.publicPaths(), base.http(),
        new IamClientProperties.Jwks(Duration.ofMillis(100), Duration.ofMillis(50), Duration.ofMillis(100)),
        base.revocation(), base.audit(), base.manifest());
    JwtDecoder decoder = decoder(noTolerance);
    decoder.decode(jwts1.user(UUID.randomUUID()).mint());
    stub.stop();
    sleep(Duration.ofMillis(500)); // cache and outage tolerance have both elapsed
    assertThatThrownBy(() -> decoder.decode(jwts1.user(UUID.randomUUID()).mint())).isInstanceOf(BadJwtException.class);
  }

  @Test
  void cachedKeysKeepWorkingWhileIamIsDown() {
    JwtDecoder decoder = decoder(props(Duration.ofMillis(100)));
    decoder.decode(jwts1.user(UUID.randomUUID()).mint());
    stub.stop();
    sleep(Duration.ofMillis(250)); // cache TTL elapsed, refresh impossible

    assertThat(decoder.decode(jwts1.user(UUID.randomUUID()).mint()).getSubject()).isNotBlank();
  }

  @Test
  void timestampsAreCheckedWithSixtySecondsOfSkew() {
    JwtDecoder decoder = decoder(props(Duration.ofMinutes(5)));
    Instant now = clock.instant();
    assertThat(decoder.decode(jwts1.user(UUID.randomUUID()).issuedAt(now.minusSeconds(900))
        .expiresAt(now.minusSeconds(59)).mint())).isNotNull();
    assertThatThrownBy(() -> decoder.decode(jwts1.user(UUID.randomUUID()).issuedAt(now.minusSeconds(900))
        .expiresAt(now.minusSeconds(61)).mint())).isInstanceOf(JwtException.class);

    JWTClaimsSet soon = jwts1.user(UUID.randomUUID()).claims().notBeforeTime(Date.from(now.plusSeconds(50))).build();
    assertThat(decoder.decode(jwts1.sign(soon, "key-1"))).isNotNull();
    JWTClaimsSet later = jwts1.user(UUID.randomUUID()).claims().notBeforeTime(Date.from(now.plusSeconds(70))).build();
    assertThatThrownBy(() -> decoder.decode(jwts1.sign(later, "key-1"))).isInstanceOf(JwtException.class);
  }

  @Test
  void issuerMustMatchExactly() {
    JwtDecoder decoder = decoder(props(Duration.ofMinutes(5)));
    assertThatThrownBy(() -> decoder.decode(jwts1.user(UUID.randomUUID()).issuer(stub.baseUrl() + "/").mint()))
        .isInstanceOf(JwtException.class);
  }

  @Test
  void applicationTokensAreRejectedUnlessExplicitlyAccepted() {
    String app = jwts1.app("billing-app", "BILLING");
    assertThatThrownBy(() -> decoder(props(Duration.ofMinutes(5))).decode(app))
        .isInstanceOf(JwtException.class)
        .hasMessageContaining("Application tokens are not accepted");

    IamClientProperties base = props(Duration.ofMinutes(5));
    IamClientProperties accepting = new IamClientProperties(base.issuerUri(), null, null, base.clientId(),
        base.clientSecret(), base.productCode(), null, true, base.clockSkew(), base.publicPaths(), base.http(),
        base.jwks(), base.revocation(), base.audit(), base.manifest());
    assertThat(decoder(accepting).decode(app).getSubject()).isEqualTo("app:billing-app");
  }

  @Test
  void permsAreMappedToAuthoritiesWithoutPrefix() {
    Jwt jwt = decoder(props(Duration.ofMinutes(5)))
        .decode(jwts1.user(UUID.randomUUID()).perms("a.b", "internal.audit.write", "c.d.own").mint());
    var token = new IamJwtAuthenticationConverter().convert(jwt);
    assertThat(token.getAuthorities()).extracting(Object::toString).containsExactlyInAnyOrder("a.b", "c.d.own");
    assertThat(token.getName()).isEqualTo(jwt.getSubject());
  }
}
