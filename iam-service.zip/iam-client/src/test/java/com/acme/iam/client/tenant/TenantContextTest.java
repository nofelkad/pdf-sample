package com.acme.iam.client.tenant;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

import java.util.UUID;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Test;
import org.slf4j.MDC;

class TenantContextTest {

  private static final TenantContext CTX =
      new TenantContext(UUID.randomUUID(), UUID.randomUUID(), UUID.randomUUID(), UUID.randomUUID(), "req-1");

  private final ExecutorService pool = Executors.newSingleThreadExecutor(); // one reused thread, like a pool

  @AfterEach
  void cleanUp() {
    TenantContext.clear();
    MDC.clear();
    pool.shutdownNow();
  }

  @Test
  void requireFailsWithoutBinding() {
    assertThat(TenantContext.current()).isEmpty();
    assertThatThrownBy(TenantContext::require).isInstanceOf(IllegalStateException.class);
  }

  @Test
  void bindRestoresThePreviousContext() {
    TenantContext outer = new TenantContext(UUID.randomUUID(), UUID.randomUUID(), UUID.randomUUID(), UUID.randomUUID(), null);
    try (var a = TenantContext.bind(outer)) {
      try (var b = TenantContext.bind(CTX)) {
        assertThat(TenantContext.require()).isEqualTo(CTX);
      }
      assertThat(TenantContext.require()).isEqualTo(outer);
    }
    assertThat(TenantContext.current()).isEmpty();
  }

  @Test
  void decoratorCarriesContextAndMdcToTheTaskThread() throws Exception {
    TenantContextTaskDecorator decorator = new TenantContextTaskDecorator();
    MDC.put("requestId", "req-1");
    Runnable decorated;
    try (var ignored = TenantContext.bind(CTX)) {
      decorated = decorator.decorate(() -> { });
    }
    TenantContext[] seen = new TenantContext[1];
    String[] mdc = new String[1];
    Runnable task;
    try (var ignored = TenantContext.bind(CTX)) {
      task = decorator.decorate(() -> {
        seen[0] = TenantContext.current().orElse(null);
        mdc[0] = MDC.get("requestId");
      });
    }
    pool.submit(task).get();
    assertThat(seen[0]).isEqualTo(CTX);
    assertThat(mdc[0]).isEqualTo("req-1");
    assertThat(decorated).isNotNull();
  }

  @Test
  void decoratorClearsTheContextAfterTheTaskSoNextTasksOnTheSameThreadSeeNothing() throws Exception {
    TenantContextTaskDecorator decorator = new TenantContextTaskDecorator();
    Runnable withContext;
    try (var ignored = TenantContext.bind(CTX)) {
      withContext = decorator.decorate(() -> assertThat(TenantContext.current()).contains(CTX));
    }
    pool.submit(withContext).get();

    boolean[] leaked = new boolean[1];
    pool.submit(() -> leaked[0] = TenantContext.current().isPresent() || MDC.get("requestId") != null).get();
    assertThat(leaked[0]).isFalse();
  }

  @Test
  void aTaskSubmittedWithoutContextRunsWithoutOne() throws Exception {
    TenantContextTaskDecorator decorator = new TenantContextTaskDecorator();
    boolean[] present = new boolean[1];
    pool.submit(decorator.decorate(() -> present[0] = TenantContext.current().isPresent())).get();
    assertThat(present[0]).isFalse();
  }

  @Test
  void contextIsClearedEvenWhenTheTaskFails() throws Exception {
    TenantContextTaskDecorator decorator = new TenantContextTaskDecorator();
    Runnable failing;
    try (var ignored = TenantContext.bind(CTX)) {
      failing = decorator.decorate(() -> {
        throw new IllegalStateException("boom");
      });
    }
    try {
      pool.submit(failing).get();
    } catch (Exception expected) {
      // task failure is reported through the future
    }
    boolean[] leaked = new boolean[1];
    pool.submit(() -> leaked[0] = TenantContext.current().isPresent()).get();
    assertThat(leaked[0]).isFalse();
  }
}
