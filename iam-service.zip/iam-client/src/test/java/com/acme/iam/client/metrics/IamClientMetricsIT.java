package com.acme.iam.client.metrics;

import static org.assertj.core.api.Assertions.assertThat;

import com.acme.iam.client.testing.PostgresTestBase;
import io.micrometer.core.instrument.MeterRegistry;
import io.micrometer.core.instrument.simple.SimpleMeterRegistry;
import java.nio.charset.StandardCharsets;
import java.time.Clock;
import java.time.Duration;
import java.util.UUID;
import javax.sql.DataSource;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.core.io.ClassPathResource;
import org.springframework.jdbc.core.simple.JdbcClient;

/** P1-11.5: outbox depth and oldest-event age of the iam-client relay, read from the real outbox table. */
class IamClientMetricsIT extends PostgresTestBase {

  private static JdbcClient jdbc;

  private final MeterRegistry meters = new SimpleMeterRegistry();

  @BeforeAll
  static void createOutbox() throws Exception {
    DataSource dataSource = dataSource("metrics_it");
    jdbc = JdbcClient.create(dataSource);
    jdbc.sql(new ClassPathResource("db/iam-client/V1__iam_audit_outbox.sql").getContentAsString(StandardCharsets.UTF_8))
        .update();
  }

  @BeforeEach
  void clean() {
    jdbc.sql("TRUNCATE iam_audit_outbox").update();
  }

  @Test
  void anEmptyOutboxHasDepthZeroAndNoAge() {
    new IamClientMetrics(jdbc, Clock.systemUTC(), Duration.ZERO, () -> 0, () -> null).bindTo(meters);

    assertThat(meters.get(IamClientMetrics.OUTBOX_DEPTH).gauge().value()).isZero();
    assertThat(meters.get(IamClientMetrics.OUTBOX_OLDEST_AGE).gauge().value()).isZero();
  }

  @Test
  void depthCountsRowsAndOldestAgeIsMeasuredFromTheOldestRow() {
    insert(90);
    insert(30);
    insert(5);
    new IamClientMetrics(jdbc, Clock.systemUTC(), Duration.ZERO, () -> 3, () -> Duration.ofSeconds(7)).bindTo(meters);

    assertThat(meters.get(IamClientMetrics.OUTBOX_DEPTH).gauge().value()).isEqualTo(3.0);
    assertThat(meters.get(IamClientMetrics.OUTBOX_OLDEST_AGE).gauge().value()).isBetween(89.0, 100.0);
    assertThat(meters.get(IamClientMetrics.RELAY_FAILURES).gauge().value()).isEqualTo(3.0);
    assertThat(meters.get(IamClientMetrics.REVOCATION_POLL_AGE).gauge().value()).isEqualTo(7.0);
  }

  @Test
  void theOutboxIsQueriedAtMostOncePerCacheTtl() {
    new IamClientMetrics(jdbc, Clock.systemUTC(), Duration.ofMinutes(5), () -> 0, () -> null).bindTo(meters);
    assertThat(meters.get(IamClientMetrics.OUTBOX_DEPTH).gauge().value()).isZero();

    insert(10);

    assertThat(meters.get(IamClientMetrics.OUTBOX_DEPTH).gauge().value()).as("cached").isZero();
  }

  @Test
  void aPollerThatNeverSucceededHasNoAge() {
    new IamClientMetrics(jdbc, Clock.systemUTC(), Duration.ZERO, () -> 0, () -> null).bindTo(meters);

    assertThat(meters.get(IamClientMetrics.REVOCATION_POLL_AGE).gauge().value()).isNaN();
  }

  private static void insert(int secondsOld) {
    jdbc.sql("""
            INSERT INTO iam_audit_outbox (event_id, occurred_at, payload, created_at)
            VALUES (:id, now(), '{}'::jsonb, now() - make_interval(secs => :age))""")
        .param("id", UUID.randomUUID()).param("age", secondsOld).update();
  }
}
