package com.acme.iam.client.revocation;

import static org.assertj.core.api.Assertions.assertThat;

import com.acme.iam.client.IamClientProperties;
import com.acme.iam.client.http.AppTokenProvider;
import com.acme.iam.client.http.IamApiClient;
import com.acme.iam.client.http.IamHttp;
import com.acme.iam.client.testing.StubIamServer;
import com.acme.iam.client.testing.StubIamServer.Revocation;
import com.acme.iam.client.testing.TestProps;
import com.acme.iam.core.revocation.RevocationRegistry;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.time.Clock;
import java.time.Duration;
import java.util.List;
import java.util.UUID;
import org.awaitility.Awaitility;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.boot.actuate.health.Health;
import org.springframework.boot.actuate.health.Status;

class RevocationPollerTest {

  private final ObjectMapper mapper = new ObjectMapper();
  private StubIamServer stub;
  private RevocationRegistry registry;
  private RevocationPoller poller;
  private IamClientProperties props;

  @BeforeEach
  void setUp() {
    stub = new StubIamServer();
    props = TestProps.of(stub);
    IamHttp http = new IamHttp(props);
    IamApiClient api = new IamApiClient(http, new AppTokenProvider(http, props, Clock.systemUTC(), mapper), mapper);
    registry = new RevocationRegistry();
    poller = new RevocationPoller(api, registry, props.revocation(), Clock.systemUTC());
  }

  @AfterEach
  void tearDown() {
    poller.stop();
    stub.close();
  }

  @Test
  void firstPollLoadsTheStartupWindowWithoutSinceThenResumesFromTheCursor() {
    UUID alice = UUID.randomUUID();
    UUID bob = UUID.randomUUID();
    stub.setRevocations(List.of(new Revocation(5, alice, 3)));

    assertThat(poller.poll()).isTrue();
    assertThat(registry.isRevoked(alice, 2)).isTrue();
    assertThat(registry.isRevoked(alice, 3)).isFalse();
    assertThat(registry.lastCursor()).isEqualTo(5);

    stub.addRevocation(new Revocation(9, bob, 7));
    assertThat(poller.poll()).isTrue();
    assertThat(registry.isRevoked(bob, 6)).isTrue();
    assertThat(registry.lastCursor()).isEqualTo(9);

    assertThat(stub.revocationRequests().get(0).query()).doesNotContain("since");
    assertThat(stub.revocationRequests().get(1).query()).contains("since=5").contains("limit=1000");
  }

  @Test
  void followsPagesUntilTheFeedIsDrained() {
    IamClientProperties small = TestProps.of(stub);
    IamClientProperties.Revocation tiny = new IamClientProperties.Revocation(
        Duration.ofMillis(50), Duration.ofMinutes(20), Duration.ofSeconds(60), 2);
    IamHttp http = new IamHttp(small);
    IamApiClient api = new IamApiClient(http, new AppTokenProvider(http, small, Clock.systemUTC(), mapper), mapper);
    RevocationPoller paged = new RevocationPoller(api, registry, tiny, Clock.systemUTC());
    List<UUID> users = java.util.stream.IntStream.range(0, 5).mapToObj(i -> UUID.randomUUID()).toList();
    for (int i = 0; i < users.size(); i++) {
      stub.addRevocation(new Revocation(i + 1, users.get(i), 2));
    }

    assertThat(paged.poll()).isTrue();

    users.forEach(u -> assertThat(registry.isRevoked(u, 1)).isTrue());
    assertThat(registry.lastCursor()).isEqualTo(5);
    assertThat(stub.revocationRequests()).hasSize(3); // 2 + 2 + 1
  }

  @Test
  void keepsLastKnownStateWhenIamIsUnreachableAndRecovers() {
    UUID alice = UUID.randomUUID();
    stub.setRevocations(List.of(new Revocation(1, alice, 3)));
    assertThat(poller.poll()).isTrue();

    stub.stop();
    assertThat(poller.poll()).isFalse();
    assertThat(poller.poll()).isFalse();
    assertThat(poller.consecutiveFailures()).isEqualTo(2);
    assertThat(poller.lastError()).isNotBlank();
    assertThat(registry.isRevoked(alice, 2)).isTrue(); // fail-closed for what is already known
    assertThat(registry.lastCursor()).isEqualTo(1);

    stub.start();
    UUID bob = UUID.randomUUID();
    stub.addRevocation(new Revocation(2, bob, 4));
    assertThat(poller.poll()).isTrue();
    assertThat(poller.consecutiveFailures()).isZero();
    assertThat(poller.lastError()).isNull();
    assertThat(registry.isRevoked(bob, 3)).isTrue();
  }

  @Test
  void serverErrorsAreFailuresToo() {
    stub.failRevocations(503);
    assertThat(poller.poll()).isFalse();
    stub.failRevocations(200);
    assertThat(poller.poll()).isTrue();
  }

  @Test
  void startLoadsTheWindowBeforeReturningThenPollsOnItsOwnThread() {
    UUID alice = UUID.randomUUID();
    stub.setRevocations(List.of(new Revocation(1, alice, 3)));

    poller.start();
    assertThat(registry.isRevoked(alice, 2)).isTrue(); // already loaded when start() returned

    UUID bob = UUID.randomUUID();
    stub.addRevocation(new Revocation(2, bob, 4));
    Awaitility.await().atMost(Duration.ofSeconds(5)).until(() -> registry.isRevoked(bob, 3));
    assertThat(Thread.getAllStackTraces().keySet()).anyMatch(t -> t.getName().equals(RevocationPoller.THREAD_NAME));
    poller.stop();
    assertThat(poller.isRunning()).isFalse();
  }

  @Test
  void startDoesNotFailWhenIamIsDownAndCatchesUpLater() {
    UUID alice = UUID.randomUUID();
    stub.setRevocations(List.of(new Revocation(1, alice, 3)));
    stub.stop();

    poller.start(); // must not throw
    assertThat(registry.isRevoked(alice, 2)).isFalse();

    stub.start();
    Awaitility.await().atMost(Duration.ofSeconds(5)).until(() -> registry.isRevoked(alice, 2));
    assertThat(stub.revocationRequests().get(0).query()).doesNotContain("since"); // window load, not a cursor resume
  }

  @Test
  void healthIsDegradedBeforeTheFirstSuccessUpAfterwardsAndDegradedWhenStale() {
    RevocationHealthIndicator health = new RevocationHealthIndicator(poller, props.revocation());
    assertThat(health.health().getStatus()).isEqualTo(RevocationHealthIndicator.DEGRADED);

    assertThat(poller.poll()).isTrue();
    Health up = health.health();
    assertThat(up.getStatus()).isEqualTo(Status.UP);
    assertThat(up.getDetails()).containsKeys("cursor", "lastSuccess", "consecutiveFailures");

    IamClientProperties.Revocation staleQuickly = new IamClientProperties.Revocation(
        Duration.ofMillis(50), Duration.ofMinutes(20), Duration.ofMillis(100), 1000);
    RevocationHealthIndicator strict = new RevocationHealthIndicator(poller, staleQuickly);
    stub.stop();
    Awaitility.await().atMost(Duration.ofSeconds(5)).until(() -> {
      poller.poll();
      return strict.health().getStatus().equals(RevocationHealthIndicator.DEGRADED);
    });
    assertThat(strict.health().getDetails()).containsKey("lastError");
  }

  @Test
  void oldEntriesAreEvictedAfterTheStartupWindow() {
    IamClientProperties.Revocation shortWindow = new IamClientProperties.Revocation(
        Duration.ofMillis(50), Duration.ofMillis(150), Duration.ofSeconds(60), 1000);
    IamHttp http = new IamHttp(props);
    IamApiClient api = new IamApiClient(http, new AppTokenProvider(http, props, Clock.systemUTC(), mapper), mapper);
    RevocationPoller shortLived = new RevocationPoller(api, registry, shortWindow, Clock.systemUTC());
    UUID alice = UUID.randomUUID();
    stub.setRevocations(List.of(new Revocation(1, alice, 3)));
    shortLived.poll();
    assertThat(registry.size()).isEqualTo(1);

    Awaitility.await().atMost(Duration.ofSeconds(5)).until(() -> {
      shortLived.poll();
      return registry.size() == 0;
    });
    assertThat(registry.lastCursor()).isEqualTo(1); // the cursor is kept, only the map shrinks
  }
}
