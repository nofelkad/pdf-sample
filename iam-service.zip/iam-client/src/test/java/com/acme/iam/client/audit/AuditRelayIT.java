package com.acme.iam.client.audit;

import static org.assertj.core.api.Assertions.assertThat;

import com.acme.iam.client.IamClientProperties;
import com.acme.iam.client.audit.AuditRelay.RelayResult;
import com.acme.iam.client.http.AppTokenProvider;
import com.acme.iam.client.http.IamApiClient;
import com.acme.iam.client.http.IamHttp;
import com.acme.iam.client.testing.PostgresTestBase;
import com.acme.iam.client.testing.StubIamServer;
import com.acme.iam.client.testing.TestProps;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.nio.charset.StandardCharsets;
import java.time.Clock;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import javax.sql.DataSource;
import net.javacrumbs.shedlock.core.LockConfiguration;
import net.javacrumbs.shedlock.core.LockProvider;
import net.javacrumbs.shedlock.core.SimpleLock;
import org.awaitility.Awaitility;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.core.io.ClassPathResource;
import org.springframework.jdbc.core.simple.JdbcClient;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.transaction.support.TransactionTemplate;

/** Outbox relay against a real PostgreSQL and a stub IAM: no event is lost, none is delivered twice. */
class AuditRelayIT extends PostgresTestBase {

  private static final ObjectMapper MAPPER = new ObjectMapper();
  private static StubIamServer stub;
  private static DataSource dataSource;
  private static JdbcClient jdbc;
  private static TransactionTemplate tx;
  private static AuditOutbox outbox;

  private final List<AuditRelay> started = new ArrayList<>();

  @BeforeAll
  static void setUp() throws Exception {
    stub = new StubIamServer();
    dataSource = dataSource("relay_it");
    jdbc = JdbcClient.create(dataSource);
    tx = new TransactionTemplate(new DataSourceTransactionManager(dataSource));
    String ddl = new ClassPathResource("db/iam-client/V1__iam_audit_outbox.sql")
        .getContentAsString(StandardCharsets.UTF_8);
    jdbc.sql(ddl).update();
    outbox = new AuditOutbox(dataSource, MAPPER, Clock.systemUTC());
  }

  @AfterAll
  static void tearDown() {
    stub.close();
  }

  @BeforeEach
  void clean() {
    stub.reset();
    jdbc.sql("TRUNCATE iam_audit_outbox").update();
  }

  @AfterEach
  void stopRelays() {
    started.forEach(AuditRelay::stop);
  }

  private AuditRelay relay(int batchSize, LockProvider lock) {
    IamClientProperties.Relay config = new IamClientProperties.Relay(
        Duration.ofMillis(20), batchSize, Duration.ofMillis(200), Duration.ofMinutes(1));
    IamClientProperties props = TestProps.of(stub, config);
    IamHttp http = new IamHttp(props);
    IamApiClient api = new IamApiClient(http, new AppTokenProvider(http, props, Clock.systemUTC(), MAPPER), MAPPER);
    AuditRelay relay = new AuditRelay(jdbc, tx, api, MAPPER, config, lock, "iam-audit-relay-test", Clock.systemUTC());
    started.add(relay);
    return relay;
  }

  private List<UUID> append(int count) {
    List<UUID> ids = new ArrayList<>();
    tx.executeWithoutResult(status -> {
      for (int i = 0; i < count; i++) {
        ids.add(outbox.append(AuditEntry.builder("invoice.approved").target("invoice", "inv-" + i).build()));
      }
    });
    return ids;
  }

  private int outboxSize() {
    return jdbc.sql("SELECT count(*) FROM iam_audit_outbox").query(Integer.class).single();
  }

  private void assertDeliveredExactlyOnce(List<UUID> ids) {
    assertThat(stub.auditEvents()).hasSize(ids.size());
    assertThat(stub.auditEvents().keySet()).containsExactlyInAnyOrderElementsOf(ids.stream().map(UUID::toString).toList());
    assertThat(stub.auditEvents().values()).allMatch(times -> times == 1);
  }

  @Test
  void backoffDoublesAndIsCappedAtOneMinute() {
    Duration base = Duration.ofSeconds(2);
    Duration cap = Duration.ofMinutes(1);
    assertThat(AuditRelay.backoff(1, base, cap)).isEqualTo(Duration.ofSeconds(2));
    assertThat(AuditRelay.backoff(2, base, cap)).isEqualTo(Duration.ofSeconds(4));
    assertThat(AuditRelay.backoff(3, base, cap)).isEqualTo(Duration.ofSeconds(8));
    assertThat(AuditRelay.backoff(5, base, cap)).isEqualTo(Duration.ofSeconds(32));
    assertThat(AuditRelay.backoff(6, base, cap)).isEqualTo(cap);
    assertThat(AuditRelay.backoff(50, base, cap)).isEqualTo(cap);
    assertThat(AuditRelay.backoff(Integer.MAX_VALUE, base, cap)).isEqualTo(cap);
  }

  @Test
  void shipsInBatchesAndEmptiesTheOutbox() {
    List<UUID> ids = append(1200);
    AuditRelay relay = relay(500, null);

    assertThat(relay.relayOnce()).isEqualTo(RelayResult.SENT);
    assertThat(relay.relayOnce()).isEqualTo(RelayResult.SENT);
    assertThat(relay.relayOnce()).isEqualTo(RelayResult.SENT);
    assertThat(relay.relayOnce()).isEqualTo(RelayResult.IDLE);

    assertThat(stub.auditBatchSizes()).containsExactly(500, 500, 200);
    assertThat(outboxSize()).isZero();
    assertDeliveredExactlyOnce(ids);
  }

  @Test
  void keepsEveryRowWhileIamIsDownAndDeliversAfterRecovery() {
    List<UUID> ids = append(40);
    AuditRelay relay = relay(500, null);

    stub.failAudit(503);
    assertThat(relay.relayOnce()).isEqualTo(RelayResult.FAILED);
    stub.failAudit(0);
    stub.stop(); // connection refused
    assertThat(relay.relayOnce()).isEqualTo(RelayResult.FAILED);
    assertThat(relay.relayOnce()).isEqualTo(RelayResult.FAILED);
    assertThat(outboxSize()).isEqualTo(40);
    assertThat(stub.auditEvents()).isEmpty();

    stub.start();
    assertThat(relay.relayOnce()).isEqualTo(RelayResult.SENT);
    assertThat(outboxSize()).isZero();
    assertDeliveredExactlyOnce(ids);
  }

  @Test
  void aWholeBatchRefusalIsLoggedAtErrorWithStatusAndBodyAndKeepsTheRows() {
    ch.qos.logback.classic.Logger logger =
        (ch.qos.logback.classic.Logger) org.slf4j.LoggerFactory.getLogger(AuditRelay.class);
    ch.qos.logback.core.read.ListAppender<ch.qos.logback.classic.spi.ILoggingEvent> appender =
        new ch.qos.logback.core.read.ListAppender<>();
    appender.start();
    logger.addAppender(appender);
    try {
      List<UUID> ids = append(3);
      AuditRelay relay = relay(500, null);
      stub.failAudit(400);
      assertThat(relay.relayOnce()).isEqualTo(RelayResult.FAILED);
      assertThat(outboxSize()).isEqualTo(3);
      assertThat(appender.list).anySatisfy(event -> {
        assertThat(event.getLevel()).isEqualTo(ch.qos.logback.classic.Level.ERROR);
        assertThat(event.getFormattedMessage()).contains("HTTP 400").contains("unavailable"); // stub body
      });
      stub.failAudit(0);
      assertThat(relay.relayOnce()).isEqualTo(RelayResult.SENT);
      assertDeliveredExactlyOnce(ids);
    } finally {
      logger.detachAppender(appender);
    }
  }

  @Test
  void javaTimeInAnEventDoesNotBreakTheStartersOwnMapper() {
    tx.executeWithoutResult(status -> new AuditOutbox(dataSource, com.acme.iam.client.http.IamJson.mapper(), Clock.systemUTC())
        .append(AuditEntry.builder("x.y").metadata("at", java.time.Instant.parse("2026-10-10T10:00:00Z")).build()));
    assertThat(outboxSize()).isEqualTo(1);
  }

  @Test
  void clientErrorsAlsoKeepTheRows() {
    List<UUID> ids = append(3);
    AuditRelay relay = relay(500, null);
    stub.failAudit(403);
    assertThat(relay.relayOnce()).isEqualTo(RelayResult.FAILED);
    assertThat(outboxSize()).isEqualTo(3);
    stub.failAudit(0);
    assertThat(relay.relayOnce()).isEqualTo(RelayResult.SENT);
    assertDeliveredExactlyOnce(ids);
  }

  @Test
  void backgroundRelaySurvivesALongOutageWithBackoffAndARestart() {
    stub.stop();
    AuditRelay first = relay(500, null);
    first.start();
    List<UUID> ids = new ArrayList<>(append(100));
    Awaitility.await().atMost(Duration.ofSeconds(5)).until(() -> first.consecutiveFailures() >= 3);
    first.stop();

    // the application restarts during the outage: the outbox is durable
    ids.addAll(append(100));
    AuditRelay second = relay(500, null);
    second.start();
    Awaitility.await().atMost(Duration.ofSeconds(5)).until(() -> second.consecutiveFailures() >= 3);
    assertThat(stub.auditEvents()).isEmpty();
    assertThat(outboxSize()).isEqualTo(200);

    stub.start();
    Awaitility.await().atMost(Duration.ofSeconds(10)).until(() -> outboxSize() == 0);
    assertDeliveredExactlyOnce(ids);
    assertThat(second.consecutiveFailures()).isZero();
  }

  @Test
  void duplicatesReportedByIamAreDeleted() {
    List<UUID> ids = append(5);
    AuditRelay relay = relay(500, null);
    assertThat(relay.relayOnce()).isEqualTo(RelayResult.SENT);
    // re-queue the same event ids (e.g. IAM committed but the response was lost before the rows were deleted)
    for (UUID id : ids) {
      jdbc.sql("INSERT INTO iam_audit_outbox (event_id, occurred_at, payload) "
              + "VALUES (:id, now(), CAST(:p AS jsonb))")
          .param("id", id)
          .param("p", "{\"eventId\":\"" + id + "\",\"action\":\"invoice.approved\"}")
          .update();
    }
    assertThat(relay.relayOnce()).isEqualTo(RelayResult.SENT);
    assertThat(outboxSize()).isZero();
    assertThat(stub.auditEvents()).hasSize(5);
    assertThat(stub.auditEvents().values()).allMatch(times -> times == 2); // delivered twice, stored once at IAM
  }

  @Test
  void rejectedEventsAreDeletedAndNotRetried() {
    List<UUID> ids = append(4);
    stub.rejectEvent(ids.get(1).toString());
    AuditRelay relay = relay(500, null);

    assertThat(relay.relayOnce()).isEqualTo(RelayResult.SENT);
    assertThat(outboxSize()).isZero();
    assertThat(relay.relayOnce()).isEqualTo(RelayResult.IDLE);
    assertThat(stub.auditEvents().keySet()).doesNotContain(ids.get(1).toString()).hasSize(3);
    assertThat(stub.auditRequests()).isEqualTo(1);
  }

  @Test
  void relaysRacingOnTheSameOutboxNeverDeliverAnEventTwice() throws Exception {
    List<UUID> ids = append(1500);
    int workers = 4;
    ExecutorService pool = Executors.newFixedThreadPool(workers);
    CountDownLatch go = new CountDownLatch(1);
    List<Future<?>> futures = new ArrayList<>();
    for (int w = 0; w < workers; w++) {
      AuditRelay relay = relay(100, null); // no ShedLock: FOR UPDATE SKIP LOCKED alone keeps batches disjoint
      futures.add(pool.submit(() -> {
        go.await();
        RelayResult result;
        do {
          result = relay.relayOnce();
        } while (result != RelayResult.IDLE || outboxSize() > 0);
        return null;
      }));
    }
    go.countDown();
    for (Future<?> f : futures) {
      f.get(60, TimeUnit.SECONDS);
    }
    pool.shutdownNow();

    assertThat(outboxSize()).isZero();
    assertDeliveredExactlyOnce(ids);
  }

  @Test
  void doesNothingWhenAnotherInstanceHoldsTheLock() {
    List<UUID> ids = append(3);
    AtomicBoolean locked = new AtomicBoolean(true);
    LockProvider provider = new LockProvider() {
      @Override
      public Optional<SimpleLock> lock(LockConfiguration configuration) {
        return locked.get() ? Optional.empty() : Optional.of(() -> { });
      }
    };
    AuditRelay relay = relay(500, provider);

    assertThat(relay.relayOnce()).isEqualTo(RelayResult.LOCKED);
    assertThat(stub.auditRequests()).isZero();
    assertThat(outboxSize()).isEqualTo(3);

    locked.set(false);
    assertThat(relay.relayOnce()).isEqualTo(RelayResult.SENT);
    assertDeliveredExactlyOnce(ids);
  }

  @Test
  void aBatchIsOnlyDeletedWhenIamAccountedForEveryEvent() {
    List<UUID> ids = append(3);
    AuditRelay relay = relay(500, null);
    stub.failAudit(0);
    stub.setAuditUnderReporting(true); // answers 200 but only accounts for part of the batch
    assertThat(relay.relayOnce()).isEqualTo(RelayResult.FAILED);
    assertThat(outboxSize()).isEqualTo(ids.size());
  }
}
