package com.acme.iam.client.security;

import static org.assertj.core.api.Assertions.assertThat;
import static org.hamcrest.Matchers.containsInAnyOrder;
import static org.hamcrest.Matchers.startsWith;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.header;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import com.acme.iam.client.testapp.ClientIT;
import com.acme.iam.client.testapp.TestApplication.AsyncProbe;
import com.acme.iam.client.testing.StubIamServer;
import com.acme.iam.client.testing.StubIamServer.Revocation;
import com.acme.iam.client.testing.TestJwts;
import com.acme.iam.core.revocation.RevocationRegistry;
import com.nimbusds.jose.JWSAlgorithm;
import com.nimbusds.jose.JWSHeader;
import com.nimbusds.jose.PlainHeader;
import com.nimbusds.jose.crypto.MACSigner;
import com.nimbusds.jose.jwk.RSAKey;
import com.nimbusds.jwt.JWTClaimsSet;
import com.nimbusds.jwt.PlainJWT;
import com.nimbusds.jwt.SignedJWT;
import java.time.Duration;
import java.time.Instant;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicLong;
import org.awaitility.Awaitility;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.test.web.servlet.MockMvc;

/** The starter wired into a real application context: JWT validation, authorities, revocation, TenantContext. */
class ResourceServerIT extends ClientIT {

  private static final AtomicLong FEED_IDS = new AtomicLong(1000);

  @Autowired MockMvc mvc;
  @Autowired RevocationRegistry registry;
  @Autowired AsyncProbe asyncProbe;

  @Test
  void validTokenAuthenticatesAndPermsBecomeAuthorities() throws Exception {
    UUID userId = UUID.randomUUID();
    UUID account = UUID.randomUUID();
    UUID tenant = UUID.randomUUID();
    UUID session = UUID.randomUUID();
    String token = JWTS.user(userId).account(account).tenant(tenant).session(session)
        .perms("billing.invoice.read.tenant", "billing.invoice.approve", "internal.audit.write").bearer();

    mvc.perform(get("/api/whoami").header(HttpHeaders.AUTHORIZATION, token).header("X-Request-Id", "req-42"))
        .andExpect(status().isOk())
        .andExpect(header().string("X-Request-Id", "req-42"))
        .andExpect(jsonPath("$.user").value(userId.toString()))
        .andExpect(jsonPath("$.account").value(account.toString()))
        .andExpect(jsonPath("$.tenant").value(tenant.toString()))
        .andExpect(jsonPath("$.session").value(session.toString()))
        .andExpect(jsonPath("$.requestId").value("req-42"))
        // 1:1, no ROLE_/SCOPE_ prefix; the reserved internal.* permission is stripped from user tokens
        .andExpect(jsonPath("$.authorities", containsInAnyOrder("billing.invoice.read.tenant", "billing.invoice.approve")));
  }

  @Test
  void requestIdIsGeneratedWhenMissingOrInvalid() throws Exception {
    String token = user().bearer();
    mvc.perform(get("/api/whoami").header(HttpHeaders.AUTHORIZATION, token))
        .andExpect(status().isOk())
        .andExpect(header().exists("X-Request-Id"));
    mvc.perform(get("/api/whoami").header(HttpHeaders.AUTHORIZATION, token).header("X-Request-Id", "bad id with spaces"))
        .andExpect(status().isOk())
        .andExpect(jsonPath("$.requestId").value(org.hamcrest.Matchers.not("bad id with spaces")));
  }

  @Test
  void missingTokenIsA401WithBearerChallengeAndProblemBody() throws Exception {
    mvc.perform(get("/api/whoami"))
        .andExpect(status().isUnauthorized())
        .andExpect(header().string(HttpHeaders.WWW_AUTHENTICATE, "Bearer"))
        .andExpect(jsonPath("$.code").value("unauthorized"))
        .andExpect(jsonPath("$.status").value(401));
  }

  @Test
  void garbageTokenIsInvalidToken() throws Exception {
    mvc.perform(get("/api/whoami").header(HttpHeaders.AUTHORIZATION, "Bearer not.a.jwt"))
        .andExpect(status().isUnauthorized())
        .andExpect(header().string(HttpHeaders.WWW_AUTHENTICATE, startsWith("Bearer error=\"invalid_token\"")))
        .andExpect(jsonPath("$.code").value("invalid_token"));
  }

  @Test
  void expiredWrongIssuerAndForeignKeyAreRejected() throws Exception {
    mvc.perform(get("/api/whoami").header(HttpHeaders.AUTHORIZATION,
            user().issuedAt(Instant.now().minusSeconds(3600)).expiresAt(Instant.now().minusSeconds(600)).bearer()))
        .andExpect(status().isUnauthorized());
    mvc.perform(get("/api/whoami").header(HttpHeaders.AUTHORIZATION, user().issuer("https://evil.example").bearer()))
        .andExpect(status().isUnauthorized());
    RSAKey other = TestJwts.newKey("key-1"); // same kid, different key
    String forged = new TestJwts(other, STUB.baseUrl()).user(UUID.randomUUID()).bearer();
    mvc.perform(get("/api/whoami").header(HttpHeaders.AUTHORIZATION, forged)).andExpect(status().isUnauthorized());
  }

  @Test
  void clockSkewOfSixtySecondsIsTolerated() throws Exception {
    mvc.perform(get("/api/whoami").header(HttpHeaders.AUTHORIZATION,
            user().issuedAt(Instant.now().minusSeconds(900)).expiresAt(Instant.now().minusSeconds(30)).bearer()))
        .andExpect(status().isOk());
  }

  @Test
  void onlyRs256IsAccepted() throws Exception {
    JWTClaimsSet claims = user().claims().build();
    // HS256 signed with a shared secret
    SignedJWT hs = new SignedJWT(new JWSHeader.Builder(JWSAlgorithm.HS256).keyID("key-1").build(), claims);
    hs.sign(new MACSigner("0123456789abcdef0123456789abcdef"));
    mvc.perform(get("/api/whoami").header(HttpHeaders.AUTHORIZATION, "Bearer " + hs.serialize()))
        .andExpect(status().isUnauthorized());
    // alg none
    String none = new PlainJWT(new PlainHeader(), claims).serialize();
    mvc.perform(get("/api/whoami").header(HttpHeaders.AUTHORIZATION, "Bearer " + none))
        .andExpect(status().isUnauthorized());
    // RS512 with the right key
    String rs512 = TestJwts.sign(claims, KEY, JWSAlgorithm.RS512, "key-1");
    mvc.perform(get("/api/whoami").header(HttpHeaders.AUTHORIZATION, "Bearer " + rs512))
        .andExpect(status().isUnauthorized());
  }

  @Test
  void tokensMissingIamClaimsAreRejected() throws Exception {
    JWTClaimsSet noSession = new JWTClaimsSet.Builder(user().claims().build()).claim("sid", null).build();
    mvc.perform(get("/api/whoami").header(HttpHeaders.AUTHORIZATION, "Bearer " + JWTS.sign(noSession, "key-1")))
        .andExpect(status().isUnauthorized());
    JWTClaimsSet noSv = new JWTClaimsSet.Builder(user().claims().build()).claim("sv", null).build();
    mvc.perform(get("/api/whoami").header(HttpHeaders.AUTHORIZATION, "Bearer " + JWTS.sign(noSv, "key-1")))
        .andExpect(status().isUnauthorized());
  }

  @Test
  void applicationTokensAreRejectedOnUserEndpoints() throws Exception {
    String appToken = JWTS.app(StubIamServer.CLIENT_ID, StubIamServer.PRODUCT);
    mvc.perform(get("/api/whoami").header(HttpHeaders.AUTHORIZATION, "Bearer " + appToken))
        .andExpect(status().isUnauthorized())
        .andExpect(jsonPath("$.code").value("invalid_token"));
  }

  @Test
  void missingAuthorityIsA403ProblemAndPresentAuthorityPasses() throws Exception {
    mvc.perform(get("/api/secured").header(HttpHeaders.AUTHORIZATION, user().perms("billing.invoice.read.own").bearer()))
        .andExpect(status().isForbidden())
        .andExpect(jsonPath("$.code").value("forbidden"));
    mvc.perform(get("/api/secured").header(HttpHeaders.AUTHORIZATION, user().perms("billing.invoice.approve").bearer()))
        .andExpect(status().isOk());
  }

  @Test
  void publicPathsAndHealthAreOpen() throws Exception {
    mvc.perform(get("/public/ping")).andExpect(status().isOk());
    mvc.perform(get("/actuator/health")).andExpect(status().isOk());
  }

  @Test
  void revokedTokenGets401TokenRevokedUntilTheUserHasANewerSession() throws Exception {
    UUID userId = UUID.randomUUID();
    String oldToken = JWTS.user(userId).sv(3).bearer();
    String newToken = JWTS.user(userId).sv(4).bearer();
    mvc.perform(get("/api/whoami").header(HttpHeaders.AUTHORIZATION, oldToken)).andExpect(status().isOk());

    STUB.addRevocation(new Revocation(FEED_IDS.incrementAndGet(), userId, 4));
    Awaitility.await().atMost(Duration.ofSeconds(10)).until(() -> registry.isRevoked(userId, 3));

    mvc.perform(get("/api/whoami").header(HttpHeaders.AUTHORIZATION, oldToken))
        .andExpect(status().isUnauthorized())
        .andExpect(header().string(HttpHeaders.WWW_AUTHENTICATE, startsWith("Bearer error=\"token_revoked\"")))
        .andExpect(jsonPath("$.code").value("token_revoked"));
    mvc.perform(get("/api/whoami").header(HttpHeaders.AUTHORIZATION, newToken)).andExpect(status().isOk());
  }

  @Test
  void unknownKidsInsideTheJwksRateLimitWindowAre401NotServerErrors() throws Exception {
    // the first one may trigger the (rate-limited) JWKS refetch, the following ones hit the rate limit
    for (int i = 0; i < 4; i++) {
      String forged = JWTS.user(UUID.randomUUID()).kid("forged-" + i).bearer();
      mvc.perform(get("/api/whoami").header(HttpHeaders.AUTHORIZATION, forged))
          .andExpect(status().isUnauthorized())
          .andExpect(jsonPath("$.code").value("invalid_token"));
    }
    // a legitimate token still works afterwards
    mvc.perform(get("/api/whoami").header(HttpHeaders.AUTHORIZATION, user().bearer())).andExpect(status().isOk());
  }

  @Test
  void anIamOutageDegradesOnlyTheRevocationIndicatorNeverTheAggregateHealth() throws Exception {
    try {
      STUB.failRevocations(503);
      Awaitility.await().atMost(Duration.ofSeconds(15)).untilAsserted(() ->
          mvc.perform(get("/actuator/health/iamRevocation"))
              .andExpect(jsonPath("$.status").value("DEGRADED"))
              .andExpect(jsonPath("$.details.lastError").exists()));
      // load balancers keep the instance: aggregate stays UP / HTTP 200
      mvc.perform(get("/actuator/health"))
          .andExpect(status().isOk())
          .andExpect(jsonPath("$.status").value("UP"))
          .andExpect(jsonPath("$.components.iamRevocation.status").value("DEGRADED"));
    } finally {
      STUB.failRevocations(200);
    }
    Awaitility.await().atMost(Duration.ofSeconds(15)).untilAsserted(() ->
        mvc.perform(get("/actuator/health/iamRevocation")).andExpect(jsonPath("$.status").value("UP")));
  }

  @Test
  void revocationHealthIsUpWhileThePollerSucceeds() throws Exception {
    mvc.perform(get("/actuator/health/iamRevocation"))
        .andExpect(status().isOk())
        .andExpect(jsonPath("$.status").value("UP"))
        .andExpect(jsonPath("$.details.consecutiveFailures").value(0));
  }

  @Test
  void tenantContextFollowsAsyncTasksAndIsClearedAfterwards() throws Exception {
    UUID tenant = UUID.randomUUID();
    mvc.perform(get("/api/async").header(HttpHeaders.AUTHORIZATION, user().tenant(tenant).bearer()))
        .andExpect(status().isOk())
        .andExpect(jsonPath("$.tenant").value(tenant.toString()));
    // the pooled thread that ran it must not keep the identity: tasks submitted without a context see none
    for (int i = 0; i < 5; i++) {
      assertThat(asyncProbe.leftover().get()).isFalse();
    }
  }

  @Test
  void dataScopeEndpointUsesTheBroadestHeldScopeOr403() throws Exception {
    mvc.perform(get("/api/scope").header(HttpHeaders.AUTHORIZATION,
            user().perms("billing.invoice.read.own", "billing.invoice.read.tenant").bearer()))
        .andExpect(status().isOk())
        .andExpect(jsonPath("$.scope").value("TENANT"));
    mvc.perform(get("/api/scope").header(HttpHeaders.AUTHORIZATION, user().perms("billing.invoice.approve").bearer()))
        .andExpect(status().isForbidden());
  }

  @Test
  void theCoreDataScopeExceptionIsMappedTo403() throws Exception {
    mvc.perform(get("/api/scope-core").header(HttpHeaders.AUTHORIZATION, user().perms("billing.invoice.read.account").bearer()))
        .andExpect(status().isOk())
        .andExpect(jsonPath("$.scope").value("ACCOUNT"));
    mvc.perform(get("/api/scope-core").header(HttpHeaders.AUTHORIZATION, user().perms("x.y").bearer()))
        .andExpect(status().isForbidden())
        .andExpect(jsonPath("$.code").value("forbidden"));
  }

  @Test
  void authorizationIsStatelessNoSessionIsCreated() throws Exception {
    var result = mvc.perform(get("/api/whoami").header(HttpHeaders.AUTHORIZATION, user().bearer()))
        .andExpect(status().isOk())
        .andReturn();
    assertThat(result.getRequest().getSession(false)).isNull();
    assertThat(result.getResponse().getHeader(HttpHeaders.SET_COOKIE)).isNull();
    // CSRF is off for bearer-only APIs: a POST with a valid token is not rejected with 403 csrf
    mvc.perform(post("/api/invoices/" + UUID.randomUUID() + "/approve")
            .header(HttpHeaders.AUTHORIZATION, user().perms("billing.invoice.approve").bearer()))
        .andExpect(status().isOk());
  }
}
