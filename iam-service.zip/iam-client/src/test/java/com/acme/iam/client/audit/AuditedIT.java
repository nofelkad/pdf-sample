package com.acme.iam.client.audit;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

import com.acme.iam.client.testapp.ClientIT;
import com.acme.iam.client.testapp.TestApplication.AuditedService;
import com.acme.iam.client.tenant.TenantContext;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.time.Duration;
import java.time.Instant;
import java.time.LocalDate;
import java.util.List;
import java.util.UUID;
import org.awaitility.Awaitility;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.simple.JdbcClient;
import org.springframework.transaction.IllegalTransactionStateException;
import org.springframework.transaction.support.TransactionTemplate;

/** {@code @Audited}: the event is written in the caller's transaction and reaches IAM through the relay. */
class AuditedIT extends ClientIT {

  private static final ObjectMapper MAPPER = new ObjectMapper();

  @Autowired AuditedService service;
  @Autowired AuditOutbox outbox;
  @Autowired JdbcClient jdbc;
  @Autowired TransactionTemplate tx;

  /** Stop the relay from draining the outbox while a test inspects it. */
  @Autowired AuditRelay relay;

  @BeforeEach
  void pauseRelayAndClean() {
    relay.stop();
    jdbc.sql("TRUNCATE iam_audit_outbox").update();
    STUB.reset();
  }

  private List<JsonNode> outboxPayloads() {
    return jdbc.sql("SELECT payload::text FROM iam_audit_outbox ORDER BY seq").query(String.class).list().stream()
        .map(json -> {
          try {
            return MAPPER.readTree(json);
          } catch (Exception e) {
            throw new IllegalStateException(e);
          }
        })
        .toList();
  }

  @Test
  void theStartersMigrationRunsInItsOwnHistoryAndLeavesTheHostFlywayAlone() {
    assertThat(jdbc.sql("SELECT to_regclass('iam_audit_outbox') IS NOT NULL").query(Boolean.class).single()).isTrue();
    assertThat(jdbc.sql("SELECT script FROM iam_client_schema_history WHERE version = '1'").query(String.class).list())
        .containsExactly("V1__iam_audit_outbox.sql");
    // the host application has its own V1__ migration: same version number, separate history, no collision
    assertThat(jdbc.sql("SELECT script FROM flyway_schema_history WHERE version = '1'").query(String.class).list())
        .containsExactly("V1__host_probe.sql");
    assertThat(jdbc.sql("SELECT count(*) FROM flyway_schema_history WHERE script LIKE '%outbox%'")
        .query(Integer.class).single()).isZero();
    assertThat(jdbc.sql("SELECT to_regclass('host_probe') IS NOT NULL").query(Boolean.class).single()).isTrue();
  }

  @Test
  void javaTimeValuesInBeforeAfterAndMetadataSerialiseAndDoNotBreakTheBusinessTransaction() {
    Instant at = Instant.parse("2026-10-10T10:00:00Z");
    tx.executeWithoutResult(status -> outbox.append(AuditEntry.builder("invoice.updated")
        .after(java.util.Map.of("approvedAt", at, "dueDate", LocalDate.of(2026, 11, 1)))
        .metadata("window", java.time.Duration.ofMinutes(5))
        .build()));
    assertThat(outboxPayloads()).singleElement().satisfies(e -> {
      assertThat(e.path("after").path("approvedAt").asText()).isEqualTo("2026-10-10T10:00:00Z");
      assertThat(e.path("after").path("dueDate").asText()).isEqualTo("2026-11-01");
      assertThat(e.path("metadata").path("window").asText()).isEqualTo("PT5M");
    });
  }

  @Test
  void eventIsWrittenInTheCallersTransactionWithContextAndSpelTarget() {
    UUID user = UUID.randomUUID();
    UUID account = UUID.randomUUID();
    UUID tenant = UUID.randomUUID();
    UUID session = UUID.randomUUID();
    UUID invoice = UUID.randomUUID();
    try (var ignored = TenantContext.bind(new TenantContext(user, account, tenant, session, "req-7"))) {
      service.approve(invoice);
    }

    List<JsonNode> events = outboxPayloads();
    assertThat(events).hasSize(1);
    JsonNode e = events.get(0);
    assertThat(e.path("action").asText()).isEqualTo("invoice.approved");
    assertThat(e.path("targetType").asText()).isEqualTo("invoice");
    assertThat(e.path("targetId").asText()).isEqualTo(invoice.toString());
    assertThat(e.path("actorUserId").asText()).isEqualTo(user.toString());
    assertThat(e.path("accountId").asText()).isEqualTo(account.toString());
    assertThat(e.path("tenantId").asText()).isEqualTo(tenant.toString());
    assertThat(e.path("sessionId").asText()).isEqualTo(session.toString());
    assertThat(e.path("requestId").asText()).isEqualTo("req-7");
    assertThat(e.path("actorType").asText()).isEqualTo("USER");
    assertThat(e.path("outcome").asText()).isEqualTo("SUCCESS");
    assertThat(UUID.fromString(e.path("eventId").asText())).isNotNull();
    assertThat(e.path("occurredAt").asText()).endsWith("Z");
    assertThat(e.path("before").isObject()).isTrue();
    assertThat(e.path("metadata").isObject()).isTrue();
  }

  @Test
  void targetIdCanReadTheReturnValue() {
    service.create();
    assertThat(outboxPayloads()).singleElement()
        .satisfies(e -> assertThat(e.path("targetId").asText()).isEqualTo("00000000-0000-0000-0000-00000000c0de"));
  }

  @Test
  void withoutContextTheActorIsSystem() {
    service.noTarget();
    assertThat(outboxPayloads()).singleElement().satisfies(e -> {
      assertThat(e.path("actorType").asText()).isEqualTo("SYSTEM");
      assertThat(e.path("actorUserId").isNull()).isTrue();
      assertThat(e.path("targetId").isNull()).isTrue();
    });
  }

  @Test
  void rollbackOfTheBusinessTransactionRemovesTheEvent() {
    assertThatThrownBy(() -> tx.executeWithoutResult(status -> {
          service.approve(UUID.randomUUID());
          throw new IllegalStateException("later step failed");
        }))
        .isInstanceOf(IllegalStateException.class);
    assertThat(outboxPayloads()).isEmpty();
  }

  @Test
  void aFailingMethodRecordsNothing() {
    assertThatThrownBy(() -> service.failAfterwards(UUID.randomUUID())).isInstanceOf(IllegalStateException.class);
    assertThat(outboxPayloads()).isEmpty();
  }

  @Test
  void aTransactionIsRequired() {
    assertThatThrownBy(() -> service.noTransaction(UUID.randomUUID()))
        .isInstanceOf(IllegalTransactionStateException.class);
    assertThatThrownBy(() -> outbox.append(AuditEntry.builder("x.y").build()))
        .isInstanceOf(IllegalTransactionStateException.class);
    assertThat(outboxPayloads()).isEmpty();
  }

  @Test
  void aBrokenSpelExpressionStillRecordsTheEvent() {
    service.brokenExpression();
    assertThat(outboxPayloads()).singleElement().satisfies(e -> {
      assertThat(e.path("action").asText()).isEqualTo("invoice.broken");
      assertThat(e.path("targetId").isNull()).isTrue();
      assertThat(e.path("metadata").path("target_id_error").asText()).isNotBlank();
    });
  }

  @Test
  void explicitOutcomeAndDetailsCanBeAppended() {
    tx.executeWithoutResult(status -> outbox.append(AuditEntry.builder("invoice.approve.denied")
        .target("invoice", "inv-1")
        .outcome(AuditEntry.Outcome.DENIED)
        .metadata("reason", "limit_exceeded")
        .build()));
    assertThat(outboxPayloads()).singleElement().satisfies(e -> {
      assertThat(e.path("outcome").asText()).isEqualTo("DENIED");
      assertThat(e.path("metadata").path("reason").asText()).isEqualTo("limit_exceeded");
    });
  }

  @Test
  void theBackgroundRelayShipsTheEventToIamExactlyOnce() {
    UUID invoice = UUID.randomUUID();
    service.approve(invoice);
    relay.start();

    Awaitility.await().atMost(Duration.ofSeconds(10)).until(() -> !STUB.auditEvents().isEmpty());
    Awaitility.await().atMost(Duration.ofSeconds(10))
        .until(() -> jdbc.sql("SELECT count(*) FROM iam_audit_outbox").query(Integer.class).single() == 0);
    assertThat(STUB.auditEvents()).hasSize(1);
    assertThat(STUB.auditEvents().values()).containsExactly(1);
  }
}
