-- A host application's own first migration: the starter's outbox migration (also "V1") must not collide with it.
CREATE TABLE host_probe (id INT PRIMARY KEY);
