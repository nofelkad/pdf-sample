// Spring Boot starter for applications that consume IAM (spec section 7, tasks P1-12.2 - P1-12.6).
plugins {
    `java-test-fixtures`
}

description = "IAM client Spring Boot starter"

dependencies {
    api(platform(libs.spring.boot.dependencies))
    api(project(":iam-core"))
    api(libs.spring.boot.autoconfigure)

    // Resource server, method security, JDBC (outbox), AOP (@Audited), actuator (health indicator), Flyway (outbox DDL)
    api(libs.spring.boot.starter.web)
    api(libs.spring.boot.starter.security)
    api(libs.spring.boot.starter.oauth2.resource.server)
    api(libs.spring.boot.starter.jdbc)
    api(libs.spring.boot.starter.aop)
    api(libs.spring.boot.starter.validation)
    api(libs.spring.boot.starter.actuator)
    api(libs.flyway.core)
    runtimeOnly(libs.flyway.database.postgresql)
    api(libs.shedlock.spring)
    api(libs.jackson.databind)
    api(libs.jackson.datatype.jsr310)
    api(libs.jackson.dataformat.yaml)

    annotationProcessor(libs.spring.boot.configuration.processor)

    // Stub IAM server, token minting and a Postgres base class, shared with the sample app's tests
    testFixturesApi(platform(libs.spring.boot.dependencies))
    testFixturesApi(libs.spring.boot.starter.test)
    testFixturesApi(libs.spring.security.oauth2.jose)
    testFixturesApi(libs.bundles.testcontainers)
    testFixturesApi(libs.postgresql)
    testFixturesApi(libs.awaitility)

    testImplementation(libs.spring.security.test)
    testImplementation(libs.shedlock.provider.jdbc.template)
}
