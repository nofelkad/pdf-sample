# iam-client: integration guide

Spring Boot starter that connects an application to the IAM service. It gives you, with configuration only:

| You get | How |
|---|---|
| Authentication from IAM access tokens (JWT, RS256) | JWKS cached, refreshed on an unknown `kid` (rate limited), issuer and time checks with 60 s skew |
| Authorization with `@PreAuthorize("hasAuthority('billing.invoice.approve')")` | the token's `perms` claim becomes authorities, 1:1, no prefix |
| Immediate logout / role removal | 2 s revocation poll (within 5 s everywhere), `401 token_revoked` |
| Who is calling | `TenantContext` (`sub`, `acc`, `tid`, `sid`, request id), also inside `@Async` |
| Row-level scope | `DataScope`: `.own` / `.tenant` / `.account` permissions become an SQL filter |
| Audit trail | `@Audited` writes to a local outbox table in your transaction; a relay ships it to IAM and never loses an event |
| Permission registry | your `permissions.yaml` is uploaded to IAM at startup |

The working reference is the `sample-app` module (invoices): copy its structure.

A new application can be integrated in well under a day by following steps 1 to 8.

---

## 0. One-time setup in IAM (platform operator)

Register the application as an *application client* and keep the secret (shown once):

```
POST {iam}/api/platform/app-clients        (needs platform.account.manage)
{ "clientId": "billing-app", "productCode": "BILLING" }
-> 201 { "clientId": "billing-app", "productCode": "BILLING", "clientSecret": "..." }
```

`productCode` (`[A-Z][A-Z0-9_]{1,31}`) is the prefix of your permission codes (`billing.*`). An application client can
only manage its own product.

## 1. Dependency

```kotlin
dependencies {
    implementation("com.acme.iam:iam-client:<version>")   // in this repo: implementation(project(":iam-client"))
    implementation("net.javacrumbs.shedlock:shedlock-provider-jdbc-template:6.10.0") // or any other LockProvider
    runtimeOnly("org.postgresql:postgresql")
}
```

The starter brings Spring Web, Security, OAuth2 resource server, JDBC, AOP, Actuator, Flyway and ShedLock core. Build with
`-parameters` (Spring Boot's Gradle/Maven plugins do) so `@Audited` SpEL can use argument names.

## 2. Properties

```yaml
iam:
  client:
    issuer-uri: https://iam.acme.com        # expected `iss`; JWKS defaults to {issuer-uri}/.well-known/jwks.json
    client-id: billing-app
    client-secret: ${IAM_CLIENT_SECRET}     # from your secret store, never in git
    product-code: BILLING
    manifest-location: classpath:permissions.yaml   # omit to skip the manifest upload
    # base-url: http://iam.internal:8080    # if /internal/* is reached on another address than the issuer
```

Everything else has a default:

| Property | Default | Meaning |
|---|---|---|
| `iam.client.enabled` | `true` | switch the whole starter off |
| `issuer-uri` / `client-id` / `client-secret` / `product-code` | required | startup fails with a clear message when blank |
| `jwks-uri` | `{issuer-uri}/.well-known/jwks.json` | |
| `base-url` | `issuer-uri` | for `/internal/token`, `/internal/revocations`, `/internal/audit/events`, `/internal/products/*/manifest` |
| `accept-app-tokens` | `false` | `typ=app` tokens are rejected on your endpoints |
| `clock-skew` | `60s` | tolerance for `exp`/`nbf` |
| `public-paths` | `/actuator/health/**`, `/error` | left unauthenticated by the default filter chain |
| `http.connect-timeout` / `http.read-timeout` | `2s` / `5s` | calls to IAM |
| `jwks.cache-ttl` / `jwks.min-refresh-interval` / `jwks.outage-tolerance` | `5m` / `10s` / `1h` | key cache; unknown-`kid` refetch at most every 10 s; cached keys survive an IAM outage |
| `revocation.poll-interval` | `2s` | one indexed query per tick; keeps the 5 s revocation target (ruling R41) |
| `revocation.startup-window` | `20m` | startup load covers IAM's `iam.revocation.startup-lookback`; entries older than this are dropped from memory (must exceed the access-token lifetime) |
| `revocation.stale-after` | `60s` | the `iamRevocation` health indicator reports `DEGRADED` if no successful poll for this long |
| `audit.enabled` | `true` | outbox, `@Audited` and relay |
| `audit.migrate` | `true` | apply the starter's own outbox migration (own Flyway instance, table `iam_client_schema_history`) |
| `audit.relay.interval` / `batch-size` / `max-backoff` | `2s` / `500` / `1m` | relay cadence, events per request (max 500), cap of the exponential backoff |
| `manifest.retry-initial-delay` / `retry-max-delay` | `1s` / `1m` | manifest upload retries |

## 3. Database

The audit outbox is one table, `iam_audit_outbox`. The starter creates it itself and **does not touch your Flyway**:

* It ships `db/iam-client/V1__iam_audit_outbox.sql` and applies it with **its own Flyway instance**, location
  `classpath:db/iam-client`, history table **`iam_client_schema_history`**. Your Flyway beans, history table
  (`flyway_schema_history`) and version numbers are independent: use `V1__`, `V2__`... as you like, there is no collision and
  no `out-of-order` setting to worry about.
* It runs at startup after your own Flyway migration and before the outbox or relay is used, with the application's
  `DataSource` (that role needs `CREATE TABLE` once). It also works in a schema that already holds tables without any
  Flyway history. If your runtime role has no DDL rights, set `iam.client.audit.migrate=false` and run
  `iam-client/src/main/resources/db/iam-client/V1__iam_audit_outbox.sql` with your migration role.
* The relay needs the usual ShedLock table (see step 4):

```sql
CREATE TABLE shedlock (
    name       VARCHAR(64)  NOT NULL PRIMARY KEY,
    lock_until TIMESTAMPTZ  NOT NULL,
    locked_at  TIMESTAMPTZ  NOT NULL,
    locked_by  VARCHAR(255) NOT NULL
);
```

## 4. LockProvider

With several instances, only one should ship the outbox at a time. Provide a ShedLock `LockProvider` bean:

```java
@Bean
LockProvider lockProvider(DataSource dataSource) {
  return new JdbcTemplateLockProvider(JdbcTemplateLockProvider.Configuration.builder()
      .withJdbcTemplate(new JdbcTemplate(dataSource)).usingDbTime().build());
}
```

Without one the relay still never double-sends (it uses `SELECT ... FOR UPDATE SKIP LOCKED`) and logs a WARN; the lock
just keeps instances from contending for the same rows. The lock name is `iam-audit-relay-<product-code>`.

## 5. permissions.yaml

The permissions and system roles of your product, with the field names of IAM's manifest API. See
`sample-app/src/main/resources/permissions.yaml`:

```yaml
product: BILLING          # optional; must equal iam.client.product-code when present
name: Billing
permissions:
  - { code: billing.invoice.read.own,     kind: DATA,    description: Read invoices the user created }
  - { code: billing.invoice.read.tenant,  kind: DATA,    description: Read all invoices of the active tenant }
  - { code: billing.invoice.read.account, kind: DATA,    description: Read invoices across the account }
  - { code: billing.invoice.approve,      kind: FEATURE, description: Approve invoices, sensitive: true, audit_read: false }
system_roles:
  - { name: Billing Admin, permissions: [ "billing.*" ], exclude: [] }
```

* `kind`: `FEATURE` (can the user do X) or `DATA` (scope of the data they see). Code names permissions, never roles.
* The upload runs on a background thread once the application is ready: `PUT /internal/products/BILLING/manifest`.
  Re-uploading an unchanged manifest is a no-op at IAM, so it happens on every start. If IAM is down the application
  starts normally, logs a WARN and retries with backoff until it succeeds. A 4xx refusal (for example
  `product_mismatch`) is logged as ERROR and not retried. A missing or malformed file fails startup.

## 6. Authentication and authorization

With the starter on the classpath you already have a stateless filter chain: bearer JWT, CSRF off, `public-paths` open,
everything else authenticated, `@EnableMethodSecurity` on. Write controllers like this:

```java
@PostMapping("/invoices/{id}/approve")
@PreAuthorize("hasAuthority('billing.invoice.approve')")
public void approve(@PathVariable UUID id) { ... }
```

Rules of thumb: every endpoint carries an explicit `@PreAuthorize` (or is deliberately authenticated-only), the active
tenant comes from the token (`TenantContext`), never from a request parameter, and every query filters by `acc`.

**Your own filter chain.** If you declare any `SecurityFilterChain` bean the default backs off. Keep the IAM behaviour
(JWT, revocation, `TenantContext`, 401/403 problem bodies) with one call:

```java
@Bean
SecurityFilterChain api(HttpSecurity http, IamSecurity iam) throws Exception {
  return iam.apply(http.securityMatcher("/api/**"))
      .authorizeHttpRequests(a -> a.anyRequest().authenticated())
      .build();
}
```

Errors are RFC 7807 `application/problem+json` with `code`: `unauthorized` (no token), `invalid_token` (bad signature,
expired, wrong issuer, application token...), `token_revoked`, `forbidden`.

**Overriding.** Every bean is `@ConditionalOnMissingBean`: define your own `JwtDecoder`, `IamJwtAuthenticationConverter`
(extend it to map more claims), a bean named `iamJwtValidator` (an `OAuth2TokenValidator<Jwt>`), `RevocationRegistry`,
`TaskDecorator`, `ProblemResponseWriter`, `AuditOutbox`, `AuditRelay`, ...

## 7. TenantContext

```java
TenantContext ctx = TenantContext.require();   // inside an authenticated request or an @Async task started from one
UUID tenant = ctx.tenantId();  UUID account = ctx.accountId();  UUID user = ctx.userId();
UUID session = ctx.sessionId(); String requestId = ctx.requestId();
```

It is bound for the duration of an authenticated user request and cleared afterwards. The starter registers a
`TaskDecorator` that copies it (and the MDC) to `@Async` tasks and clears it when they finish; Spring Boot applies a
single `TaskDecorator` bean to `applicationTaskExecutor` automatically. For your own executors:
`executor.setTaskDecorator(decorator)`. Outside a request (scheduled jobs) bind one explicitly:
`try (var s = TenantContext.bind(ctx)) { ... }`. The request id is `X-Request-Id` when valid, else generated, and is
echoed in the response and written to the MDC key `requestId`.

## 8. DataScope: row-level visibility

Data permissions come in three flavours, `x.read.own`, `x.read.tenant`, `x.read.account`. Turn them into a filter:

```java
Scope scope = IamDataScope.of(authentication, "billing.invoice.read");   // throws AccessDeniedException (403) if none is held
String filter = switch (scope) {
  case OWN     -> "account_id = :acc AND tenant_id = :tid AND owner_id = :sub";
  case TENANT  -> "account_id = :acc AND tenant_id = :tid";
  case ACCOUNT -> "account_id = :acc";
};
```

`IamDataScope` (in the starter) reads the authorities of an `Authentication`; the plain-Java
`com.acme.iam.core.DataScope.of(Collection<String> authorities, String base)` does the same without Spring and throws
`NoDataScopeException`. The broadest held scope wins. Bind `:acc`, `:tid`, `:sub` from `TenantContext`. See
`InvoiceRepository` in the sample.

**Why `ACCOUNT` is safe to trust.** Token permissions carry no scope. IAM therefore puts a `x.read.account` DATA
permission into a token only when the user holds it through an **ACCOUNT-scope** role assignment (ruling R42); a
role containing it that was assigned at TENANT scope grants the role's other permissions but not that one. So
`DataScope.of(...) == ACCOUNT` always means the user may see the whole account, and a tenant administrator cannot widen
anyone's data scope past the tenant by granting a role at tenant scope. Give tenant-level users the `.tenant` variant.

## 9. @Audited: audit events without losing any

```java
@Transactional
@Audited(action = "invoice.approved", targetType = "invoice", targetId = "#id")
public void approve(UUID id) { ... }
```

* `action` is the event name, `targetType` literal text, `targetId` a SpEL expression over the method arguments
  (`#id`, `#request.invoiceId`, `#p0`) and the return value (`#result`, `#result.id()`).
* **A transaction is required** (propagation MANDATORY). The event row is inserted into `iam_audit_outbox` in the same
  transaction as your change: both commit or both roll back. Calling an `@Audited` method outside a transaction throws
  `IllegalTransactionStateException` rather than risk an event for a change that never committed. If the method
  throws, nothing is recorded.
* Actor, account, tenant, session and request id come from `TenantContext`, IP and user agent from the request.
  Outside a request the actor is `SYSTEM`.
* **Client IP behind a proxy.** `actorIp` is `HttpServletRequest.getRemoteAddr()`; the starter does not read
  `X-Forwarded-For` itself. Behind a load balancer or ingress every event therefore records the proxy's address unless
  your application resolves the real client first: set `server.forward-headers-strategy=native` (Tomcat's
  `RemoteIpValve`; restrict `server.tomcat.remoteip.internal-proxies` to your proxies' addresses) or `framework`
  (Spring's `ForwardedHeaderFilter`, only when **every** request passes a proxy that overwrites the headers). Never trust
  forwarded headers from arbitrary clients: they are client-controlled. IAM itself uses `iam.security.trusted-proxies`
  (exact addresses or CIDR ranges) for the same purpose, see IAM's `docs/deployment.md`.
* For a `DENIED`/`FAILURE` outcome, extra detail or before/after state, call the outbox yourself, inside a transaction.
  An operation that fails rolls its transaction back (and the event row with it), so record a denial in a **new
  transaction you open explicitly**: `new TransactionTemplate(tm, def(PROPAGATION_REQUIRES_NEW)).executeWithoutResult(s ->
  outbox.append(AuditEntry.builder("invoice.approve.denied").target("invoice", id).outcome(DENIED).metadata("reason", "limit").build()))`.
  The outbox serialises `before`/`after`/`metadata` with your Spring Boot `ObjectMapper` (or its own, with JavaTime, when
  you have none), so `Instant`, `LocalDate` etc. are fine.
  Never put passwords, tokens or secrets in an event (IAM redacts keys containing password, secret, token, hash,
  private, authorization, but do not rely on it).
* **Trust model of ingested events.** IAM accepts an application's events for **any** account and tenant: every
  registered application client holding `internal.audit.write` may write events that carry any `accountId`/`tenantId`
  (an application serves many accounts and IAM cannot tell which accounts' data it legitimately touched). What IAM does
  guarantee is the **source**: `audit_event.source` is always the calling client's product (the token's `prd`), never a
  value from the payload, so a forged event is always attributable to the application that sent it, and IAM's own rows
  (`source = IAM`) cannot be imitated. Auditors reading another product's events should treat their account/tenant as
  that application's claim. Protect the client secret accordingly (runbook `app-client-secret-rotation.md`).
* **Delivery.** The relay (single thread `iam-audit-relay`, ShedLock-guarded) reads up to 500 rows with
  `SELECT ... FOR UPDATE SKIP LOCKED`, `POST`s them to `/internal/audit/events` and deletes the rows IAM accounted for
  (accepted, duplicate or rejected). On a network error, timeout, 5xx or any other failure every row stays and the
  relay retries with exponential backoff (2 s, 4 s ... capped at 1 min), indefinitely. An IAM outage of any length, or
  an application restart in the middle of it, loses nothing; delivery is at least once and IAM de-duplicates on
  `eventId`, so every event is stored exactly once. Events IAM rejects (`rejected[]`, a validation problem) are logged at
  WARN with their reason and dropped, because retrying cannot help.
* Watch the outbox: `SELECT count(*), min(created_at) FROM iam_audit_outbox` should hover near zero. A growing
  backlog means IAM is unreachable or rejecting the batches (see the WARN logs of `AuditRelay`).

## 10. Handling `401 token_revoked`

Access tokens live 15 minutes; when permissions may shrink (role removed, user disabled, "log out everywhere", password
change) IAM revokes older tokens of that user and every application learns it within about 5 seconds. The next request
with an old token answers:

```
HTTP/1.1 401
WWW-Authenticate: Bearer error="token_revoked", error_description="The access token has been revoked"
Content-Type: application/problem+json
{ "status": 401, "code": "token_revoked", ... }
```

Clients must not treat this as "logged out": call IAM's `POST /auth/refresh` with the refresh token (it re-checks the
database and re-resolves permissions), then retry the request once with the new access token. Only if the refresh itself
fails send the user to the login. Any other 401 with `invalid_token` normally means "expired": refresh the same way.

## 11. Operations

* **Health:** `/actuator/health/iamRevocation` is `UP` while the last successful revocation poll is younger than
  `revocation.stale-after`, `DEGRADED` otherwise (revocations are then not being seen: alert on it). `DEGRADED` is not
  a ranked Spring Boot status, so it **never turns the aggregate `/actuator/health` DOWN** (it stays 200/`UP`, the
  indicator is still listed under `components`): a load balancer must not pull every instance because IAM is down, each
  instance keeps serving with its last known state. To make it count somewhere, opt in explicitly, e.g. a dedicated
  group that your monitoring (not the load balancer) calls:
  `management.endpoint.health.group.iam.include=iamRevocation`,
  `management.endpoint.health.group.iam.status.order=DEGRADED,UP`,
  `management.endpoint.health.group.iam.status.http-mapping.DEGRADED=503`. Add it to `readiness` only if you really want
  instances taken out of rotation when IAM is down.
* **IAM unreachable:** revocation poller keeps the last state and logs a WARN on the first failure and every 12th after
  that; JWT validation keeps working on cached keys for `jwks.outage-tolerance`; the outbox keeps filling; the manifest
  upload retries in the background. Nothing blocks the request path.
* **Threads:** `iam-revocation-poller`, `iam-audit-relay`, `iam-manifest-upload` (all daemon, own threads, separate from
  the application's `@Scheduled` pool). The revocation poller loads the startup window before the web server accepts
  requests (bounded by the 2 s connect timeout when IAM is down).
* **Security of the credentials:** the client secret and tokens are never logged.

## 12. Testing your integration

Run against a stub of IAM, as `sample-app` does: the module `iam-client` publishes test fixtures
(`testFixtures(project(":iam-client"))`): `StubIamServer` (JWKS, `/internal/token`, `/internal/revocations`,
`/internal/audit/events` with eventId de-duplication, manifest PUT; failure modes: `stop()`, `failAudit(503)`,
`failManifest(...)`), `TestJwts` (mints RS256 user and app tokens), and a Testcontainers `PostgresTestBase`.

```java
JWTS.user(userId).account(acc).tenant(tid).perms("billing.invoice.approve").bearer()   // "Bearer eyJ..."
```

## 13. Run the sample

```
docker run -d --name sample-db -p 5443:5432 -e POSTGRES_USER=sample -e POSTGRES_PASSWORD=sample -e POSTGRES_DB=sample_db postgres:16-alpine
IAM_ISSUER_URI=http://localhost:8080 IAM_CLIENT_ID=sample-billing IAM_CLIENT_SECRET=... ./gradlew :sample-app:bootRun
```

`GET /invoices` (scope from the token), `POST /invoices/{id}/approve` (`billing.invoice.approve`, audited).

## Troubleshooting

| Symptom | Cause |
|---|---|
| Startup fails: `Binding to target ... IamClientProperties failed` | a required `iam.client.*` property is blank |
| Every request `401 invalid_token` | wrong `issuer-uri` (must equal the token's `iss` exactly, no trailing slash difference), JWKS unreachable, or clock skew above 60 s |
| `401 invalid_token` for the application's own service calls | application tokens are rejected on user endpoints by design |
| `IllegalTransactionStateException` from `@Audited` | the annotated method is not running inside a transaction |
| Outbox grows, `ERROR IAM refused the audit batch with HTTP 4xx` | IAM rejects the **whole batch** with a client error other than 401/403 (e.g. `400 batch_too_large` because `audit.relay.batch-size` > 500, 404/409/422 from a version mismatch). The rows are kept and retried with backoff, but nothing is delivered until the cause is fixed; the log line carries the status and a response excerpt (repeated every 10th failure) |
| Outbox grows, WARN logs only | IAM unreachable, or 401/403: check the app client's secret and its `internal.audit.write` permission |
| `permission denied for schema` at startup | the runtime role cannot create the outbox table: set `iam.client.audit.migrate=false` and run the script with a migration role |
| `/actuator/health/iamRevocation` is `DEGRADED` | no successful revocation poll for `revocation.stale-after`: IAM unreachable or the app token is refused |
| `WARN No ShedLock LockProvider bean` | step 4 |
