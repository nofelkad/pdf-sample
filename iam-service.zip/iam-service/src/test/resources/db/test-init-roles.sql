-- Test counterpart of docker/postgres/init/01-roles.sh: same roles and database privileges, fixed test passwords.
-- Executed by Testcontainers as the container superuser before any Spring context starts.
CREATE ROLE iam_migrator LOGIN PASSWORD 'iam_migrator_test';
CREATE ROLE iam_app LOGIN PASSWORD 'iam_app_test' NOSUPERUSER NOCREATEDB NOCREATEROLE NOINHERIT;
ALTER DATABASE iam_db OWNER TO iam_migrator;
REVOKE ALL ON DATABASE iam_db FROM PUBLIC;
GRANT CONNECT, TEMPORARY ON DATABASE iam_db TO iam_app;
