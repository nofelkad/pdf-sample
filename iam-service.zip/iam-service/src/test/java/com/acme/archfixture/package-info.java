/** ArchUnit fixtures: deliberately violating and conforming classes used by {@code ArchitectureRulesSelfTest}. */
package com.acme.archfixture;
