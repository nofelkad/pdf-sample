package com.acme.archfixture.alpha;

public record AlphaDto(String value) {}
