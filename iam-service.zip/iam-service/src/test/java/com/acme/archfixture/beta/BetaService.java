package com.acme.archfixture.beta;

import com.acme.archfixture.alpha.AlphaRepository;

/** Violates: uses another feature's repository. */
public class BetaService {
  private final AlphaRepository alphaRepository;

  public BetaService(AlphaRepository alphaRepository) {
    this.alphaRepository = alphaRepository;
  }

  public String get() {
    return alphaRepository.load();
  }
}
