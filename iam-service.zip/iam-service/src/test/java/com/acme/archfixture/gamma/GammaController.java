package com.acme.archfixture.gamma;

import com.acme.archfixture.alpha.AlphaDto;
import com.acme.archfixture.alpha.AlphaService;
import com.acme.archfixture.common.SharedThing;
import org.springframework.web.bind.annotation.RestController;

/** Conforming: another feature only through its *Service and DTO records; shared kernel allowed. */
@RestController
public class GammaController {
  private final AlphaService alphaService;

  public GammaController(AlphaService alphaService) {
    this.alphaService = alphaService;
  }

  public String get() {
    AlphaDto dto = alphaService.find();
    return dto.value() + new SharedThing().name();
  }
}
