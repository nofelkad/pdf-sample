package com.acme.archfixture.alpha;

public interface AlphaRepository {
  String load();
}
