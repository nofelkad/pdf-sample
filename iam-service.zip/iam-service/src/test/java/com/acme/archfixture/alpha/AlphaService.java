package com.acme.archfixture.alpha;

public class AlphaService {
  private final AlphaRepository repository;

  public AlphaService(AlphaRepository repository) {
    this.repository = repository;
  }

  public AlphaDto find() {
    return new AlphaDto(repository.load());
  }
}
