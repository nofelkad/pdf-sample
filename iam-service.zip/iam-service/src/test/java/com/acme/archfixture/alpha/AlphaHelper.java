package com.acme.archfixture.alpha;

public class AlphaHelper {
  public String help() {
    return "internal";
  }
}
