package com.acme.archfixture.beta;

import com.acme.archfixture.alpha.AlphaHelper;
import com.acme.archfixture.alpha.AlphaRepository;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.web.bind.annotation.RestController;

/** Violates: repository + JdbcTemplate in a controller, and a non-service call into another feature. */
@RestController
public class BetaController {
  private final AlphaRepository alphaRepository;
  private final JdbcTemplate jdbcTemplate;

  public BetaController(AlphaRepository alphaRepository, JdbcTemplate jdbcTemplate) {
    this.alphaRepository = alphaRepository;
    this.jdbcTemplate = jdbcTemplate;
  }

  public String get() {
    return alphaRepository.load() + new AlphaHelper().help() + jdbcTemplate.getFetchSize();
  }
}
