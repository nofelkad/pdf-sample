package com.acme.archfixture.common;

public class SharedThing {
  public String name() {
    return "shared";
  }
}
