package com.acme.archfixture.alpha;

import org.springframework.web.bind.annotation.RestController;

/** Conforming: uses its own service and helper. */
@RestController
public class AlphaController {
  private final AlphaService service;
  private final AlphaHelper helper = new AlphaHelper();

  public AlphaController(AlphaService service) {
    this.service = service;
  }

  public String get() {
    return service.find().value() + helper.help();
  }
}
