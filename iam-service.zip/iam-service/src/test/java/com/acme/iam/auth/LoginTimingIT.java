package com.acme.iam.auth;

import static org.assertj.core.api.Assertions.assertThat;

import com.acme.iam.common.error.ApiException;
import com.acme.iam.common.test.PostgresTestBase;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.function.Supplier;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.simple.JdbcClient;

/**
 * P1-5.2 "done when": a login for an unknown email and one for a known email with a wrong password take the same time
 * (medians within 10%). Exercises {@link LoginService} directly: the HTTP rate limits (5/min per email) would otherwise
 * answer most attempts with a fast 429.
 *
 * <p>The known user is unlocked (failure counter and lock reset, untimed) before every "known" sample, so the samples
 * measure the real wrong-password path (Argon2 + failure counter + audit). The locked path (Argon2 + audit, no counter)
 * is compared separately.
 */
@AuthIT
@Tag("timing")
class LoginTimingIT extends PostgresTestBase {

  static final int WARM_UP = 8;
  static final int ROUNDS = 30;
  static final double TOLERANCE = 0.10;

  @Autowired JdbcClient jdbc;
  @Autowired PasswordService passwords;
  @Autowired LoginService loginService;

  @Test
  void unknownEmailAndUnlockedWrongPasswordTakeTheSameTime() {
    AuthTestData.TestUser known = new AuthTestData(jdbc, passwords).user();
    String unknown = "nobody-" + UUID.randomUUID() + "@example.test";

    double difference = compare("unlocked wrong password", () -> {
      unlock(known);
      return attempt(known.email());
    }, () -> attempt(unknown));

    assertThat(failedLogins(known)).as("the known samples took the unlocked path").isEqualTo(1);
    assertThat(difference).isLessThanOrEqualTo(TOLERANCE);
  }

  @Test
  void unknownEmailAndLockedUserTakeTheSameTime() {
    AuthTestData.TestUser known = new AuthTestData(jdbc, passwords).user();
    String unknown = "nobody-" + UUID.randomUUID() + "@example.test";
    jdbc.sql("UPDATE app_user SET locked_until = now() + interval '1 hour' WHERE id = :id")
        .param("id", known.userId()).update();

    double difference = compare("locked user", () -> attempt(known.email()), () -> attempt(unknown));

    assertThat(difference).isLessThanOrEqualTo(TOLERANCE);
  }

  /** Warm-up, then interleaved samples; returns the relative difference of the medians. */
  private double compare(String label, Supplier<Long> knownSample, Supplier<Long> unknownSample) {
    for (int i = 0; i < WARM_UP; i++) {
      knownSample.get();
      unknownSample.get();
    }
    List<Long> knownTimes = new ArrayList<>();
    List<Long> unknownTimes = new ArrayList<>();
    for (int i = 0; i < ROUNDS; i++) { // interleaved, alternating order, so drift affects both equally
      if (i % 2 == 0) {
        knownTimes.add(knownSample.get());
        unknownTimes.add(unknownSample.get());
      } else {
        unknownTimes.add(unknownSample.get());
        knownTimes.add(knownSample.get());
      }
    }
    double knownMedian = median(knownTimes);
    double unknownMedian = median(unknownTimes);
    double difference = Math.abs(knownMedian - unknownMedian) / Math.max(knownMedian, unknownMedian);
    System.out.printf("login timing (%s): median known=%.2f ms, unknown=%.2f ms, difference=%.1f%%%n",
        label, knownMedian / 1e6, unknownMedian / 1e6, difference * 100);
    return difference;
  }

  private void unlock(AuthTestData.TestUser user) {
    jdbc.sql("UPDATE app_user SET failed_logins = 0, locked_until = NULL WHERE id = :id")
        .param("id", user.userId()).update();
  }

  private int failedLogins(AuthTestData.TestUser user) {
    return jdbc.sql("SELECT failed_logins FROM app_user WHERE id = :id").param("id", user.userId())
        .query(Integer.class).single();
  }

  private long attempt(String email) {
    long start = System.nanoTime();
    try {
      loginService.login(new LoginCommand(email, "Wrong-Password-123", null), ClientInfo.UNKNOWN);
      throw new AssertionError("login must fail");
    } catch (ApiException expected) {
      assertThat(expected.code()).isEqualTo("invalid_credentials");
    }
    return System.nanoTime() - start;
  }

  private static double median(List<Long> values) {
    List<Long> sorted = values.stream().sorted().toList();
    int n = sorted.size();
    return n % 2 == 1 ? sorted.get(n / 2) : (sorted.get(n / 2 - 1) + sorted.get(n / 2)) / 2.0;
  }
}
