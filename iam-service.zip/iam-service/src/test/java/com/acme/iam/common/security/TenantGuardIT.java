package com.acme.iam.common.security;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.springframework.http.HttpHeaders.AUTHORIZATION;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import com.acme.iam.common.Ids;
import com.acme.iam.common.web.RequestIdFilter;
import com.acme.iam.common.test.IntegrationTest;
import com.acme.iam.common.test.PostgresTestBase;
import com.acme.iam.common.test.TestTokens;
import java.time.Instant;
import java.util.Map;
import java.util.UUID;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.context.annotation.Import;
import org.springframework.http.MediaType;
import org.springframework.jdbc.core.simple.JdbcClient;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.security.oauth2.jwt.JwtDecoder;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.ResultActions;

/** P1-4.4 / Ruling R2: path tenant vs token tenant, account-scope override, no leak across accounts. */
@IntegrationTest
@AutoConfigureMockMvc
@Import(SecurityTestEndpoints.class)
class TenantGuardIT extends PostgresTestBase {

  @Autowired MockMvc mvc;
  @Autowired TestTokens tokens;
  @Autowired JdbcClient jdbc;
  @Autowired JwtDecoder decoder;
  @Autowired TenantGuard tenantGuard;

  private SecurityTestData data;
  private UUID account;
  private UUID activeTenant;
  private UUID otherTenant;
  private UUID user;

  @BeforeEach
  void setUp() {
    data = new SecurityTestData(jdbc);
    account = data.account();
    activeTenant = data.tenant(account);
    otherTenant = data.tenant(account);
    user = data.user(account, activeTenant);
  }

  @Test
  void activeTenantFromTheTokenIsAllowed() throws Exception {
    call(SecurityTestEndpoints.TENANT, activeTenant, "test.read").andExpect(status().isOk());
  }

  @Test
  void otherTenantWithoutAccountScopeGrantIsTenantMismatchAndAudited() throws Exception {
    data.assign(user, data.role(account, "test.read"), "TENANT", activeTenant, null);
    String requestId = "tg-" + Ids.newId();

    mvc.perform(get(SecurityTestEndpoints.TENANT, otherTenant).header(RequestIdFilter.HEADER, requestId)
            .header(AUTHORIZATION, tokens.user(user).account(account).tenant(activeTenant).perms("test.read").bearer()))
        .andExpect(status().isForbidden())
        .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_PROBLEM_JSON))
        .andExpect(jsonPath("$.code").value("scope_exceeded"))
        .andExpect(jsonPath("$.requestId").value(requestId));

    Map<String, Object> row = jdbc.sql("""
            SELECT outcome, actor_user_id, metadata->>'reason' AS reason, metadata->>'tenantId' AS tenant,
                   metadata->>'requiredAuthority' AS required, metadata->>'path' AS path
            FROM audit_event WHERE action = 'authz.denied' AND request_id = ?""")
        .params(requestId).query().singleRow();
    assertThat(row).containsEntry("outcome", "DENIED").containsEntry("actor_user_id", user)
        .containsEntry("reason", "scope_exceeded").containsEntry("tenant", otherTenant.toString())
        .containsEntry("required", "test.read");
  }

  @Test
  void unrelatedAccountScopeGrantDoesNotUnlockOtherTenants() throws Exception {
    // test.read comes from a TENANT-scope grant in the active tenant; the ACCOUNT-scope role lacks it (R2 amended)
    data.assign(user, data.role(account, "test.read"), "TENANT", activeTenant, null);
    data.assign(user, data.role(account, "iam.audit.read"), "ACCOUNT", account, null);

    call(SecurityTestEndpoints.TENANT, otherTenant, "test.read")
        .andExpect(status().isForbidden())
        .andExpect(jsonPath("$.code").value("scope_exceeded"));
  }

  @Test
  void foreignTenantNotFoundIsNotAudited() throws Exception {
    String requestId = "tg-404-" + Ids.newId();

    mvc.perform(get(SecurityTestEndpoints.TENANT, data.tenant(data.account())).header(RequestIdFilter.HEADER, requestId)
            .header(AUTHORIZATION, tokens.user(user).account(account).tenant(activeTenant).perms("test.read").bearer()))
        .andExpect(status().isNotFound());

    assertThat(jdbc.sql("SELECT count(*) FROM audit_event WHERE request_id = ?").params(requestId)
        .query(Long.class).single()).isZero();
  }

  @Test
  void otherTenantOfTheAccountIsAllowedWithAnAccountScopeGrant() throws Exception {
    data.assign(user, data.role(account, "test.read"), "ACCOUNT", account, null);

    call(SecurityTestEndpoints.TENANT, otherTenant, "test.read").andExpect(status().isOk());
  }

  @Test
  void expiredAccountScopeGrantDoesNotCount() throws Exception {
    data.assign(user, data.role(account, "test.read"), "ACCOUNT", account, Instant.now().minusSeconds(60));

    call(SecurityTestEndpoints.TENANT, otherTenant, "test.read")
        .andExpect(status().isForbidden())
        .andExpect(jsonPath("$.code").value("scope_exceeded"));
  }

  @Test
  void accountScopeGrantInAnotherAccountDoesNotCount() throws Exception {
    UUID elsewhere = data.account();
    data.assign(user, data.role(elsewhere, "test.read"), "ACCOUNT", elsewhere, null);

    call(SecurityTestEndpoints.TENANT, otherTenant, "test.read")
        .andExpect(status().isForbidden())
        .andExpect(jsonPath("$.code").value("scope_exceeded"));
  }

  @Test
  void tenantOfAnotherAccountIsNotFoundEvenWithAccountScope() throws Exception {
    data.assign(user, data.role(account, "test.read"), "ACCOUNT", account, null);
    UUID foreignTenant = data.tenant(data.account());

    call(SecurityTestEndpoints.TENANT, foreignTenant, "test.read")
        .andExpect(status().isNotFound())
        .andExpect(jsonPath("$.code").value("tenant_not_found"));
    call(SecurityTestEndpoints.TENANT, Ids.newId(), "test.read")
        .andExpect(status().isNotFound())
        .andExpect(jsonPath("$.code").value("tenant_not_found"));
  }

  @Test
  void permissionOverloadRequiresTheAccountScopeRoleToContainThePermission() throws Exception {
    data.assign(user, data.role(account, "iam.user.read.account"), "ACCOUNT", account, null);

    call(SecurityTestEndpoints.TENANT_WITH_PERMISSION, otherTenant, "iam.user.manage")
        .andExpect(status().isForbidden())
        .andExpect(jsonPath("$.code").value("scope_exceeded"));

    data.assign(user, data.role(account, "iam.user.manage"), "ACCOUNT", account, null);

    call(SecurityTestEndpoints.TENANT_WITH_PERMISSION, otherTenant, "iam.user.manage").andExpect(status().isOk());
  }

  @Test
  void permissionOverloadStillAllowsTheActiveTenant() throws Exception {
    call(SecurityTestEndpoints.TENANT_WITH_PERMISSION, activeTenant, "iam.user.manage").andExpect(status().isOk());
  }

  @Test
  void applicationTokensHaveNoTenant() {
    Jwt app = decoder.decode(tokens.appToken("app-x", "X"));
    SecurityContextHolder.getContext().setAuthentication(SecurityConfig.permsConverter().convert(app));
    try {
      assertThatThrownBy(() -> tenantGuard.requireActive(activeTenant, "test.read"))
          .isInstanceOfSatisfying(CodedAccessDeniedException.class,
              e -> assertThat(e.code()).isEqualTo("scope_exceeded"));
    } finally {
      SecurityContextHolder.clearContext();
    }
  }

  private ResultActions call(String path, UUID tenantId, String permission) throws Exception {
    return mvc.perform(get(path, tenantId).header(AUTHORIZATION,
        tokens.user(user).account(account).tenant(activeTenant).perms(permission).bearer()));
  }
}
