package com.acme.iam.audit;

import static org.assertj.core.api.Assertions.assertThat;

import com.acme.iam.common.Ids;
import com.acme.iam.common.security.SecurityTestData;
import com.acme.iam.common.test.IntegrationTest;
import com.acme.iam.common.test.PostgresTestBase;
import com.acme.iam.common.test.TestTokens;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.net.URI;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.time.Clock;
import java.time.Duration;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;
import java.util.UUID;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.boot.test.web.server.LocalServerPort;
import org.springframework.jdbc.core.simple.JdbcClient;

/**
 * Ruling R25: tenant scope of audit search, target history and export, plus the validation of timestamps that
 * PostgreSQL cannot store. A holder of the permission through an ACCOUNT-scope assignment sees every tenant and the
 * account-level rows; everyone else is pinned to the token's tenant.
 */
@IntegrationTest(webEnvironment = WebEnvironment.RANDOM_PORT)
class AuditTenantScopeIT extends PostgresTestBase {

  @LocalServerPort int port;
  @Autowired TestTokens tokens;
  @Autowired JdbcClient jdbc;
  @Autowired ObjectMapper json;
  @Autowired Clock clock;

  private final HttpClient http = HttpClient.newHttpClient();
  private AuditTestData data;
  private SecurityTestData sd;
  private Instant now;
  private UUID account;
  private UUID tenant1;
  private UUID tenant2;
  private UUID eventT1;
  private UUID eventT2;
  private UUID eventAccountLevel;

  @BeforeEach
  void setUp() {
    AuditTestData.ensureRecentPartitions();
    data = new AuditTestData(jdbc);
    sd = new SecurityTestData(jdbc);
    now = clock.instant().truncatedTo(ChronoUnit.MICROS);
    account = sd.account();
    tenant1 = sd.tenant(account);
    tenant2 = sd.tenant(account);
    eventT1 = data.event(account, "doc.updated", now.minusSeconds(30)).tenant(tenant1).target("doc", "D-1").insert();
    eventT2 = data.event(account, "doc.updated", now.minusSeconds(20)).tenant(tenant2).target("doc", "D-1").insert();
    eventAccountLevel = data.event(account, "doc.updated", now.minusSeconds(10)).target("doc", "D-1").insert();
  }

  // ------------------------------------------------------------------------------------------ search

  @Test
  void aTenantScopedReaderSeesOnlyTheirTenantAndNoAccountLevelRows() throws Exception {
    String tenantAdmin = holder("iam.audit.read", "TENANT", tenant1);

    assertThat(search(tenantAdmin, "")).containsExactly(eventT1);
    assertThat(search(tenantAdmin, "&tenantId=" + tenant1)).containsExactly(eventT1);
  }

  @Test
  void aTenantScopedReaderNamingAnotherTenantIsRefused() throws Exception {
    String tenantAdmin = holder("iam.audit.read", "TENANT", tenant1);
    String requestId = "scope-" + Ids.newId();

    HttpResponse<String> response = get(tenantAdmin, "/api/audit/events", window("&tenantId=" + tenant2), requestId);

    assertThat(response.statusCode()).isEqualTo(403);
    assertThat(json.readTree(response.body()).get("code").asText()).isEqualTo("scope_exceeded");
    assertThat(jdbc.sql("SELECT metadata->>'reason' FROM audit_event WHERE request_id = :r AND action = 'authz.denied'")
        .param("r", requestId).query(String.class).single()).isEqualTo("scope_exceeded");
  }

  @Test
  void anAccountScopedAuditorSeesEveryTenantAndAccountLevelRows() throws Exception {
    String auditor = holder("iam.audit.read", "ACCOUNT", account);

    assertThat(search(auditor, "")).containsExactlyInAnyOrder(eventT1, eventT2, eventAccountLevel);
    assertThat(search(auditor, "&tenantId=" + tenant2)).containsExactly(eventT2);
  }

  @Test
  void anAccountScopedAuditorStillCannotNameATenantOfAnotherAccount() throws Exception {
    String auditor = holder("iam.audit.read", "ACCOUNT", account);
    UUID foreignTenant = sd.tenant(sd.account());

    HttpResponse<String> response = get(auditor, "/api/audit/events", window("&tenantId=" + foreignTenant), null);

    assertThat(response.statusCode()).isEqualTo(404);
    assertThat(json.readTree(response.body()).get("code").asText()).isEqualTo("tenant_not_found");
  }

  @Test
  void anExpiredAccountScopeGrantIsATenantScopedCaller() throws Exception {
    UUID user = sd.user(account, tenant1);
    sd.assign(user, sd.role(account, "iam.audit.read"), "ACCOUNT", account, now.minus(Duration.ofDays(1)));
    String bearer = tokens.user(user).account(account).tenant(tenant1).perms("iam.audit.read").bearer();

    assertThat(search(bearer, "")).containsExactly(eventT1);
  }

  @Test
  void theScopeIsThatOfTheEndpointsOwnPermission() throws Exception {
    // account-scope grant of read only; the export permission comes from a tenant-scope grant
    UUID user = sd.user(account, tenant1);
    sd.assign(user, sd.role(account, "iam.audit.read"), "ACCOUNT", account, null);
    sd.assign(user, sd.role(account, "iam.audit.export"), "TENANT", tenant1, null);
    String bearer = tokens.user(user).account(account).tenant(tenant1).perms("iam.audit.read", "iam.audit.export")
        .bearer();

    assertThat(search(bearer, "")).containsExactlyInAnyOrder(eventT1, eventT2, eventAccountLevel);
    assertThat(exportedIds(get(bearer, "/api/audit/exports.csv", window(""), null))).containsExactly(eventT1);
  }

  // ------------------------------------------------------------------------------------------ target history

  @Test
  void targetHistoryFollowsTheSameTenantRules() throws Exception {
    String tenantAdmin = holder("iam.audit.read", "TENANT", tenant1);
    String auditor = holder("iam.audit.read", "ACCOUNT", account);

    assertThat(ids(get(tenantAdmin, "/api/audit/targets/doc/D-1", "", null))).containsExactly(eventT1);
    assertThat(ids(get(auditor, "/api/audit/targets/doc/D-1", "", null)))
        .containsExactlyInAnyOrder(eventT1, eventT2, eventAccountLevel);
  }

  // ------------------------------------------------------------------------------------------ export

  @Test
  void exportFollowsTheSameTenantRules() throws Exception {
    String tenantAdmin = holder("iam.audit.export", "TENANT", tenant1);
    String auditor = holder("iam.audit.export", "ACCOUNT", account);

    assertThat(exportedIds(get(tenantAdmin, "/api/audit/exports.csv", window(""), null))).containsExactly(eventT1);
    assertThat(exportedIds(get(auditor, "/api/audit/exports.csv", window(""), null)))
        .containsExactlyInAnyOrder(eventT1, eventT2, eventAccountLevel);
    assertThat(exportedIds(get(auditor, "/api/audit/exports.csv", window("&tenantId=" + tenant2), null)))
        .containsExactly(eventT2);
  }

  @Test
  void aTenantScopedExporterNamingAnotherTenantIsRefusedBeforeAnythingStreams() throws Exception {
    String tenantAdmin = holder("iam.audit.export", "TENANT", tenant1);

    HttpResponse<String> response = get(tenantAdmin, "/api/audit/exports.csv", window("&tenantId=" + tenant2), null);

    assertThat(response.statusCode()).isEqualTo(403);
    assertThat(json.readTree(response.body()).get("code").asText()).isEqualTo("scope_exceeded");
    assertThat(jdbc.sql("SELECT count(*) FROM audit_event WHERE action = 'iam.audit.export.started' AND account_id = :a")
        .param("a", account).query(Long.class).single()).isZero();
  }

  // ------------------------------------------------------------------------------------------ range validation

  @Test
  void timestampsOutsideThePostgresRangeAreBadRequestsNotServerErrors() throws Exception {
    String auditor = holder("iam.audit.read", "ACCOUNT", account);
    String exporter = holder("iam.audit.export", "ACCOUNT", account);
    String huge = "+999999999-12-31T23:59:59Z";
    String tiny = "-999999999-01-01T00:00:00Z";

    for (String path : List.of("/api/audit/events", "/api/audit/exports.csv")) {
      String bearer = path.contains("export") ? exporter : auditor;
      for (String query : List.of("?from=" + enc(tiny) + "&to=" + enc(now.toString()),
          "?from=" + enc(now.minusSeconds(60).toString()) + "&to=" + enc(huge))) {
        HttpResponse<String> r = get(bearer, path, query, null);
        assertThat(r.statusCode()).as(path + query).isEqualTo(400);
        assertThat(json.readTree(r.body()).get("code").asText()).isEqualTo("invalid_parameter");
      }
    }
    HttpResponse<String> history = get(auditor, "/api/audit/targets/doc/D-1", "?from=" + enc(tiny), null);
    assertThat(history.statusCode()).isEqualTo(400);
    assertThat(json.readTree(history.body()).get("code").asText()).isEqualTo("invalid_parameter");
  }

  @Test
  void aCraftedCursorOutsideThePostgresRangeIsAnInvalidCursor() throws Exception {
    String auditor = holder("iam.audit.read", "ACCOUNT", account);
    for (String time : List.of("+999999999-12-31T23:59:59Z", "-999999999-01-01T00:00:00Z")) {
      String cursor = Base64.getUrlEncoder().withoutPadding()
          .encodeToString((time + "|" + Ids.newId()).getBytes(StandardCharsets.UTF_8));

      HttpResponse<String> r = get(auditor, "/api/audit/events", window("&cursor=" + cursor), null);

      assertThat(r.statusCode()).as(time).isEqualTo(400);
      assertThat(json.readTree(r.body()).get("code").asText()).isEqualTo("invalid_cursor");
    }
  }

  // ------------------------------------------------------------------------------------------ helpers

  /** A user holding {@code permission} through one assignment of the given scope, as a bearer token with tid = tenant1. */
  private String holder(String permission, String scopeType, UUID scopeId) {
    UUID user = sd.user(account, tenant1);
    sd.assign(user, sd.role(account, permission), scopeType, scopeId, null);
    return tokens.user(user).account(account).tenant(tenant1).perms(permission).bearer();
  }

  /**
   * The search window, limited to the {@code doc.*} events this test inserts: since final review C1 the trigger rows of
   * the fixtures (users, roles, assignments created for the callers) carry the account and tenant they belong to, so
   * they are visible to these searches too.
   */
  private String window(String extra) {
    return "?from=" + enc(now.minus(Duration.ofDays(1)).toString()) + "&to=" + enc(now.toString()) + "&action=doc."
        + extra;
  }

  private List<UUID> search(String bearer, String extra) throws Exception {
    return ids(get(bearer, "/api/audit/events", window(extra), null));
  }

  private List<UUID> ids(HttpResponse<String> response) throws Exception {
    assertThat(response.statusCode()).as(response.body()).isEqualTo(200);
    List<UUID> ids = new ArrayList<>();
    JsonNode items = json.readTree(response.body()).get("items");
    items.forEach(n -> ids.add(UUID.fromString(n.get("eventId").asText())));
    return ids;
  }

  private List<UUID> exportedIds(HttpResponse<String> response) {
    assertThat(response.statusCode()).as(response.body()).isEqualTo(200);
    return AuditExportIT.parseCsv(response.body()).stream().skip(1).map(r -> UUID.fromString(r.get(0))).toList();
  }

  private HttpResponse<String> get(String bearer, String path, String query, String requestId) throws Exception {
    HttpRequest.Builder request = HttpRequest.newBuilder(URI.create("http://localhost:" + port + path + query))
        .header("Authorization", bearer).timeout(Duration.ofMinutes(1));
    if (requestId != null) {
      request.header("X-Request-Id", requestId);
    }
    return http.send(request.build(), HttpResponse.BodyHandlers.ofString(StandardCharsets.UTF_8));
  }

  private static String enc(String s) {
    return URLEncoder.encode(s, StandardCharsets.UTF_8);
  }
}
