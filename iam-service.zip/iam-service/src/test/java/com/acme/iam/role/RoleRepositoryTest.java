package com.acme.iam.role;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

import com.acme.iam.common.test.Fixtures;
import com.acme.iam.common.test.JdbcSliceTest;
import com.acme.iam.common.test.PostgresTestBase;
import java.util.List;
import java.util.Set;
import java.util.UUID;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.jdbc.core.simple.JdbcClient;

/** P1-3.3: Role (+RolePermission) round trip. */
@JdbcSliceTest
class RoleRepositoryTest extends PostgresTestBase {

  @Autowired RoleRepository roles;
  @Autowired JdbcClient jdbc;

  @Test
  void roundTripsCustomRoleWithPermissions() {
    Fixtures fx = new Fixtures(jdbc);
    UUID account = fx.account();
    UUID product = fx.product();
    UUID read = fx.permission(product);
    UUID write = fx.permission(product);

    Role saved = roles.save(Role.custom(product, account, "Clerk", "Front office", List.of(read, write)));
    assertThat(saved.version()).isZero();

    Role loaded = roles.findById(saved.id()).orElseThrow();
    assertThat(loaded.product()).isEqualTo(product);
    assertThat(loaded.account()).isEqualTo(account);
    assertThat(loaded.type()).isEqualTo(RoleType.CUSTOM);
    assertThat(loaded.name()).isEqualTo("Clerk");
    assertThat(loaded.description()).isEqualTo("Front office");
    assertThat(loaded.permissionIds()).containsExactlyInAnyOrder(read, write);

    roles.save(loaded.withPermissions(Set.of(read)));
    Role reloaded = roles.findById(saved.id()).orElseThrow();
    assertThat(reloaded.permissionIds()).containsExactly(read);
    assertThat(reloaded.version()).isEqualTo(1);
  }

  @Test
  void findVisibleReturnsSystemRolesAndOwnCustomRoles() {
    Fixtures fx = new Fixtures(jdbc);
    UUID account = fx.account();
    UUID other = fx.account();
    UUID product = fx.product();
    Role system = roles.save(Role.system(product, "Viewer", null, List.of()));
    Role own = roles.save(Role.custom(product, account, "Own", null, List.of()));
    roles.save(Role.custom(product, other, "Foreign", null, List.of()));

    assertThat(roles.findVisible(product, account)).extracting(Role::id).containsExactlyInAnyOrder(system.id(),
        own.id());
    assertThat(roles.findSystemRole(product, "VIEWER")).map(Role::id).contains(system.id());
    assertThat(system.account()).isNull();
  }

  @Test
  void roleNamesAreUniquePerProductAndAccountIgnoringCase() {
    Fixtures fx = new Fixtures(jdbc);
    UUID account = fx.account();
    UUID product = fx.product();
    roles.save(Role.custom(product, account, "Clerk", null, List.of()));
    assertThatThrownBy(() -> roles.save(Role.custom(product, account, "CLERK", null, List.of())))
        .hasCauseInstanceOf(DuplicateKeyException.class);
  }
}
