package com.acme.iam.audit;

import static org.assertj.core.api.Assertions.assertThat;

import com.acme.iam.audit.AuditEvent.ActorType;
import com.acme.iam.audit.AuditEvent.Outcome;
import com.acme.iam.common.RequestActor;
import com.acme.iam.common.test.IntegrationTest;
import com.acme.iam.common.test.PostgresTestBase;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.simple.JdbcClient;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.security.oauth2.server.resource.authentication.JwtAuthenticationToken;
import org.springframework.transaction.support.TransactionTemplate;

/** P1-9.1: direct audit inserts in the caller's transaction, with the redaction deny-list. */
@IntegrationTest
class AuditWriterIT extends PostgresTestBase {

  @Autowired AuditWriter auditWriter;
  @Autowired JdbcClient jdbc;
  @Autowired TransactionTemplate tx;

  @AfterEach
  void clear() {
    SecurityContextHolder.clearContext();
    MDC.clear();
  }

  @Test
  void writesEventWithCurrentActorAndRequestId() {
    UUID user = UUID.randomUUID();
    UUID account = UUID.randomUUID();
    UUID tenant = UUID.randomUUID();
    UUID session = UUID.randomUUID();
    authenticate(user, account, tenant, session);
    MDC.put(RequestActor.MDC_REQUEST_ID, "req-writer-1");

    AuditEvent event = AuditEvent.forCurrentActor("auth.login.success")
        .actorIp("10.1.2.3")
        .userAgent("JUnit")
        .target("app_user", user.toString())
        .metadata("method", "password")
        .build();
    auditWriter.write(event);

    Map<String, Object> row = jdbc.sql("""
            SELECT actor_user_id, actor_type, account_id, tenant_id, session_id, request_id, source, outcome,
                   host(actor_ip) AS ip, user_agent, action, target_type, target_id, metadata::text AS metadata
            FROM audit_event WHERE event_id = :id""")
        .param("id", event.eventId())
        .query().singleRow();
    assertThat(row)
        .containsEntry("actor_user_id", user)
        .containsEntry("actor_type", "USER")
        .containsEntry("account_id", account)
        .containsEntry("tenant_id", tenant)
        .containsEntry("session_id", session)
        .containsEntry("request_id", "req-writer-1")
        .containsEntry("source", "IAM")
        .containsEntry("outcome", "SUCCESS")
        .containsEntry("ip", "10.1.2.3")
        .containsEntry("user_agent", "JUnit")
        .containsEntry("action", "auth.login.success")
        .containsEntry("target_type", "app_user")
        .containsEntry("target_id", user.toString())
        .containsEntry("metadata", "{\"method\": \"password\"}");
  }

  @Test
  void withoutJwtTheActorIsSystem() {
    AuditEvent event = AuditEvent.forCurrentActor("iam.partition.created").build();

    auditWriter.write(event);

    assertThat(jdbc.sql("SELECT actor_type FROM audit_event WHERE event_id = :id")
        .param("id", event.eventId()).query(String.class).single()).isEqualTo("SYSTEM");
  }

  @Test
  void anonymousFailureCanBeRecorded() {
    AuditEvent event = AuditEvent.builder("auth.login.failed").anonymous().outcome(Outcome.FAILURE)
        .metadata("email", "someone@example.com").build();

    auditWriter.write(event);

    assertThat(jdbc.sql("SELECT actor_type || '/' || outcome FROM audit_event WHERE event_id = :id")
        .param("id", event.eventId()).query(String.class).single()).isEqualTo("ANONYMOUS/FAILURE");
    assertThat(event.actorType()).isEqualTo(ActorType.ANONYMOUS);
  }

  @Test
  void redactsSecretsInMetadataBeforeAndAfterRecursively() {
    AuditEvent event = AuditEvent.builder("iam.test.redaction")
        .metadata(Map.of(
            "Password", "p@ss",
            "client_secret", "s",
            "refreshToken", "rt",
            "nested", Map.of("passwordHash", "h", "keep", "ok", "list", List.of(Map.of("Authorization", "Bearer x")))))
        .before(Map.of("private_key", "k", "name", "old"))
        .after(Map.of("token_hash", "abc", "name", "new"))
        .build();

    auditWriter.write(event);

    Map<String, Object> row = jdbc.sql("""
            SELECT metadata->>'Password' AS pw, metadata->>'client_secret' AS secret,
                   metadata->>'refreshToken' AS rt, metadata#>>'{nested,passwordHash}' AS hash,
                   metadata#>>'{nested,keep}' AS keep, metadata#>>'{nested,list,0,Authorization}' AS authz,
                   before_state->>'private_key' AS pk, before_state->>'name' AS old_name,
                   after_state->>'token_hash' AS th, after_state->>'name' AS new_name
            FROM audit_event WHERE event_id = :id""")
        .param("id", event.eventId()).query().singleRow();
    assertThat(row)
        .containsEntry("pw", AuditWriter.REDACTED)
        .containsEntry("secret", AuditWriter.REDACTED)
        .containsEntry("rt", AuditWriter.REDACTED)
        .containsEntry("hash", AuditWriter.REDACTED)
        .containsEntry("keep", "ok")
        .containsEntry("authz", AuditWriter.REDACTED)
        .containsEntry("pk", AuditWriter.REDACTED)
        .containsEntry("old_name", "old")
        .containsEntry("th", AuditWriter.REDACTED)
        .containsEntry("new_name", "new");
  }

  @Test
  void participatesInCallerTransaction() {
    AuditEvent event = AuditEvent.builder("iam.test.rollback").build();

    tx.executeWithoutResult(status -> {
      auditWriter.write(event);
      status.setRollbackOnly();
    });

    assertThat(jdbc.sql("SELECT count(*) FROM audit_event WHERE event_id = :id")
        .param("id", event.eventId()).query(Long.class).single()).isZero();
  }

  @Test
  void writingTheSameEventTwiceIsIdempotent() {
    AuditEvent event = AuditEvent.builder("iam.test.idempotent").build();

    auditWriter.write(event);
    auditWriter.write(event);

    assertThat(jdbc.sql("SELECT count(*) FROM audit_event WHERE event_id = :id")
        .param("id", event.eventId()).query(Long.class).single()).isEqualTo(1L);
  }

  record LoginRequest(String email, String password, Nested nested) {}

  record Nested(String apiToken, String label) {}

  @Test
  void redactsSecretsInsideRecordValues() {
    AuditEvent event = AuditEvent.builder("iam.test.redaction.record")
        .metadata("request", new LoginRequest("a@example.com", "hunter2", new Nested("tok-1", "x")))
        .build();

    auditWriter.write(event);

    String stored = metadataText(event);
    assertThat(stored).doesNotContain("hunter2").doesNotContain("tok-1").contains("a@example.com");
    assertThat(jdbc.sql("SELECT metadata#>>'{request,password}' FROM audit_event WHERE event_id = :id")
        .param("id", event.eventId()).query(String.class).single()).isEqualTo(AuditWriter.REDACTED);
  }

  @Test
  void redactsSecretsInsideJsonNodeValues() throws Exception {
    JsonNode node = new ObjectMapper().readTree(
        "{\"clientSecret\":\"s3cr3t\",\"inner\":{\"refresh_token\":\"rt-9\",\"ok\":1},\"arr\":[{\"passwordHash\":\"h\"}]}");
    AuditEvent event = AuditEvent.builder("iam.test.redaction.jsonnode").metadata("payload", node)
        .after(Map.of("doc", node)).build();

    auditWriter.write(event);

    assertThat(metadataText(event)).doesNotContain("s3cr3t").doesNotContain("rt-9").contains("\"ok\": 1");
    assertThat(jdbc.sql("SELECT after_state::text FROM audit_event WHERE event_id = :id")
        .param("id", event.eventId()).query(String.class).single())
        .doesNotContain("s3cr3t").doesNotContain("rt-9").doesNotContain("\"h\"");
  }

  @Test
  void redactsSecretsInsideArrayValues() {
    Object[] items = {Map.of("token", "t-1"), new Nested("tok-2", "y"), "plain"};
    AuditEvent event = AuditEvent.builder("iam.test.redaction.array").metadata("items", items)
        .before(Map.of("list", new Object[] {Map.of("private_key", "pk")})).build();

    auditWriter.write(event);

    assertThat(metadataText(event)).doesNotContain("t-1").doesNotContain("tok-2").contains("plain");
    assertThat(jdbc.sql("SELECT before_state::text FROM audit_event WHERE event_id = :id")
        .param("id", event.eventId()).query(String.class).single()).doesNotContain("\"pk\"");
  }

  @Test
  void staticRedactAlsoNormalizesNonMapValues() {
    Map<String, Object> redacted = AuditWriter.redact(Map.of("req", new LoginRequest("e", "pw", null)));

    assertThat(redacted.toString()).doesNotContain("pw,").contains(AuditWriter.REDACTED);
  }

  @Test
  void readRecordsASensitiveReadForTheCurrentActor() {
    UUID user = UUID.randomUUID();
    authenticate(user, UUID.randomUUID(), UUID.randomUUID(), UUID.randomUUID());
    MDC.put(RequestActor.MDC_REQUEST_ID, "req-read-" + UUID.randomUUID());

    auditWriter.read("iam.audit.exported", "audit_event", "export-42", Map.of("rows", 10, "token", "x"));

    Map<String, Object> row = jdbc.sql("""
            SELECT actor_user_id, actor_type, outcome, target_type, target_id,
                   metadata->>'rows' AS rows_, metadata->>'token' AS token
            FROM audit_event WHERE request_id = :rid AND action = 'iam.audit.exported'""")
        .param("rid", MDC.get(RequestActor.MDC_REQUEST_ID)).query().singleRow();
    assertThat(row)
        .containsEntry("actor_user_id", user)
        .containsEntry("actor_type", "USER")
        .containsEntry("outcome", "SUCCESS")
        .containsEntry("target_type", "audit_event")
        .containsEntry("target_id", "export-42")
        .containsEntry("rows_", "10")
        .containsEntry("token", AuditWriter.REDACTED);
  }

  @ParameterizedTest
  @CsvSource(delimiter = '|', nullValues = "NULL", value = {
      "unknown                      | NULL",
      "203.0.113.7, 10.0.0.1        | 203.0.113.7",
      "unknown, 10.0.0.1            | NULL",
      "999.1.1.1                    | NULL",
      "10.0.0.1:8080                | NULL",
      "::1                          | ::1",
      "2001:db8::1, 203.0.113.9     | 2001:db8::1",
      "'  198.51.100.4 '            | 198.51.100.4",
      "''                           | NULL",
      "example.com                  | NULL",
      "..:                          | NULL",
      "fe80::1%eth0                 | NULL"})
  void malformedActorIpIsStoredAsNullWithoutFailingTheTransaction(String rawIp, String expected) {
    AuditEvent event = AuditEvent.builder("iam.test.ip").actorIp(rawIp).build();

    tx.executeWithoutResult(status -> auditWriter.write(event));

    assertThat(jdbc.sql("SELECT host(actor_ip) FROM audit_event WHERE event_id = :id")
        .param("id", event.eventId()).query(String.class).optional().orElse(null)).isEqualTo(expected);
  }

  private String metadataText(AuditEvent event) {
    return jdbc.sql("SELECT metadata::text FROM audit_event WHERE event_id = :id")
        .param("id", event.eventId()).query(String.class).single();
  }

  private static void authenticate(UUID user, UUID account, UUID tenant, UUID session) {
    Jwt jwt = Jwt.withTokenValue("t").header("alg", "none").subject(user.toString())
        .claim("acc", account.toString()).claim("tid", tenant.toString()).claim("sid", session.toString())
        .build();
    SecurityContextHolder.getContext().setAuthentication(new JwtAuthenticationToken(jwt));
  }
}
