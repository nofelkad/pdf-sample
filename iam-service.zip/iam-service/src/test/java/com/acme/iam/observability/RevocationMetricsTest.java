package com.acme.iam.observability;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import com.acme.iam.core.revocation.RevocationEntry;
import io.micrometer.core.instrument.simple.SimpleMeterRegistry;
import java.time.Clock;
import java.time.Instant;
import java.time.ZoneId;
import java.time.ZoneOffset;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicReference;
import org.aspectj.lang.ProceedingJoinPoint;
import org.junit.jupiter.api.Test;
import org.springframework.jdbc.core.simple.JdbcClient;

/** Feed-read bookkeeping of {@link RevocationMetrics}: only reads made by the poller count. */
class RevocationMetricsTest {

  final SimpleMeterRegistry meters = new SimpleMeterRegistry();
  final Clock clock = Clock.fixed(Instant.parse("2026-01-01T00:00:10Z"), ZoneOffset.UTC);

  @Test
  void aFailedReadFromThePollerIsCountedAndRethrown() throws Throwable {
    RevocationMetrics metrics = new RevocationMetrics(meters, clock, mock(JdbcClient.class), () -> true);
    ProceedingJoinPoint failing = mock(ProceedingJoinPoint.class);
    when(failing.proceed()).thenThrow(new IllegalStateException("db down"));

    assertThatThrownBy(() -> metrics.aroundFeedRead(failing)).hasMessage("db down");

    assertThat(meters.get(MetricNames.REVOCATION_POLL_FAILURES).counter().count()).isEqualTo(1.0);
    assertThat(metrics.lastSuccess()).isNull();
  }

  @Test
  void aSuccessfulEmptyReadFromThePollerMarksTheFeedFresh() throws Throwable {
    RevocationMetrics metrics = new RevocationMetrics(meters, clock, mock(JdbcClient.class), () -> true);
    ProceedingJoinPoint ok = mock(ProceedingJoinPoint.class);
    when(ok.proceed()).thenReturn(List.of());

    metrics.aroundFeedRead(ok);

    assertThat(metrics.lastSuccess()).isEqualTo(clock.instant());
    assertThat(meters.get(MetricNames.REVOCATION_POLL_AGE).gauge().value()).isZero();
    assertThat(meters.get(MetricNames.REVOCATION_POLL_FAILURES).counter().count()).isZero();
  }

  @Test
  void readsByOtherCallersAreNeitherCountedNorMarkedFresh() throws Throwable {
    RevocationMetrics metrics = new RevocationMetrics(meters, clock, mock(JdbcClient.class), () -> false);
    ProceedingJoinPoint failing = mock(ProceedingJoinPoint.class);
    when(failing.proceed()).thenThrow(new IllegalStateException("db down"));

    assertThatThrownBy(() -> metrics.aroundFeedRead(failing)).hasMessage("db down");

    assertThat(meters.get(MetricNames.REVOCATION_POLL_FAILURES).counter().count()).isZero();
    assertThat(metrics.lastSuccess()).isNull();
  }

  /** A clock the test moves. */
  static final class MovableClock extends Clock {
    final AtomicReference<Instant> now = new AtomicReference<>(Instant.parse("2026-01-01T00:00:00Z"));

    @Override
    public ZoneId getZone() {
      return ZoneOffset.UTC;
    }

    @Override
    public Clock withZone(ZoneId zone) {
      return this;
    }

    @Override
    public Instant instant() {
      return now.get();
    }

    void advance(long seconds) {
      now.updateAndGet(i -> i.plusSeconds(seconds));
    }
  }

  private static ProceedingJoinPoint returning(Object result) throws Throwable {
    ProceedingJoinPoint pjp = mock(ProceedingJoinPoint.class);
    when(pjp.proceed()).thenReturn(result);
    return pjp;
  }

  @Test
  void entriesCreatedBeforeThisInstanceStartedAreStartupReplayAndDoNotSetTheLag() throws Throwable {
    MovableClock time = new MovableClock();
    Instant start = time.instant();
    RevocationMetrics metrics = new RevocationMetrics(meters, time, () -> true, id -> Optional.of(start.minusSeconds(600)));
    time.advance(5);

    metrics.aroundFeedRead(returning(List.of(new RevocationEntry(1, UUID.randomUUID(), 2))));

    assertThat(meters.get(MetricNames.REVOCATION_LAG).gauge().value()).isZero();
    assertThat(metrics.lastSuccess()).isEqualTo(time.instant()); // the poll itself still counts as fresh
  }

  @Test
  void anEntryCreatedAfterStartupSetsTheLagToItsAgeAndAnEmptyPollKeepsIt() throws Throwable {
    MovableClock time = new MovableClock();
    RevocationMetrics metrics = new RevocationMetrics(meters, time, () -> true,
        id -> Optional.of(time.instant().minusSeconds(2)));
    time.advance(30);

    metrics.aroundFeedRead(returning(List.of(new RevocationEntry(7, UUID.randomUUID(), 3))));
    assertThat(meters.get(MetricNames.REVOCATION_LAG).gauge().value()).isEqualTo(2.0);

    time.advance(10);
    metrics.aroundFeedRead(returning(List.of())); // nothing new: lag keeps its value, age restarts
    assertThat(meters.get(MetricNames.REVOCATION_LAG).gauge().value()).isEqualTo(2.0);
    assertThat(meters.get(MetricNames.REVOCATION_POLL_AGE).gauge().value()).isZero();
    time.advance(7);
    assertThat(meters.get(MetricNames.REVOCATION_POLL_AGE).gauge().value()).isEqualTo(7.0);
  }
}
