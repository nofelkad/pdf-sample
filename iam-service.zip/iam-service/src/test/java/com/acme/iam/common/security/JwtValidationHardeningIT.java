package com.acme.iam.common.security;

import static org.mockito.Mockito.atLeastOnce;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.reset;
import static org.mockito.Mockito.verify;
import static org.springframework.http.HttpHeaders.AUTHORIZATION;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import com.acme.iam.common.Ids;
import com.acme.iam.common.test.IntegrationTest;
import com.acme.iam.common.test.PostgresTestBase;
import com.acme.iam.common.test.TestTokens;
import com.acme.iam.core.Claims;
import com.nimbusds.jose.JWSAlgorithm;
import com.nimbusds.jose.JWSHeader;
import com.nimbusds.jose.crypto.RSASSASigner;
import com.nimbusds.jose.jwk.RSAKey;
import com.nimbusds.jose.jwk.gen.RSAKeyGenerator;
import com.nimbusds.jwt.JWTClaimsSet;
import com.nimbusds.jwt.PlainJWT;
import com.nimbusds.jwt.SignedJWT;
import java.time.Instant;
import java.util.Date;
import java.util.List;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.context.annotation.Import;
import org.springframework.dao.DataAccessResourceFailureException;
import org.springframework.test.context.bean.override.mockito.MockitoSpyBean;
import org.springframework.test.web.servlet.MockMvc;

/**
 * Task 9 security review (P1-11.3) and failure modes (P1-11.4) for iam-service's own JWT decoder: algorithm pinning,
 * {@code kid} handling and clock skew. Task 8 found that the client answered 500 for an unknown {@code kid} inside the
 * Nimbus refresh rate-limit window; here every unverifiable token must be 401 {@code invalid_token}, also when the
 * key reload itself fails (database outage).
 */
@IntegrationTest
@AutoConfigureMockMvc
@Import(SecurityTestEndpoints.class)
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
class JwtValidationHardeningIT extends PostgresTestBase {

  @Autowired MockMvc mvc;
  @MockitoSpyBean SigningKeyService keys;
  @Autowired SecurityProperties properties;

  @AfterEach
  void unstub() {
    reset(keys);
  }

  /** Runs first: the unknown-kid reload is rate limited (once per 5 s), so no other test may have used it yet. */
  @Test
  @Order(1)
  void unknownKidWhileTheKeyReloadFailsIs401NotA500() throws Exception {
    doThrow(new DataAccessResourceFailureException("database down")).when(keys).refresh();

    expect401(foreignKeyToken("unknown-" + Ids.newId()));
    verify(keys, atLeastOnce()).refresh();
  }

  @Test
  void unknownKidsInsideTheReloadRateLimitWindowAre401() throws Exception {
    for (int i = 0; i < 3; i++) {
      expect401(foreignKeyToken("unknown-" + Ids.newId()));
    }
  }

  @Test
  void unsignedTokensAreRejected() throws Exception {
    String none = new PlainJWT(claims(Instant.now(), Instant.now().plusSeconds(300), null)).serialize();

    expect401(none);
  }

  @Test
  void aMissingKidIsRejectedForAForeignKey() throws Exception {
    RSAKey foreign = new RSAKeyGenerator(2048).generate();
    SignedJWT jwt = new SignedJWT(new JWSHeader.Builder(JWSAlgorithm.RS256).build(),
        claims(Instant.now(), Instant.now().plusSeconds(300), null));
    jwt.sign(new RSASSASigner(foreign));

    expect401(jwt.serialize());
  }

  // ------------------------------------------------------------------------------------------- clock skew ±60 s

  /** An issuer whose clock is 50 s ahead: {@code iat}/{@code nbf} lie in our future but within the 60 s skew. */
  @Test
  void anIssuerAheadWithinTheSkewIsAccepted() throws Exception {
    Instant issuerNow = Instant.now().plusSeconds(50);
    mvc.perform(get(SecurityTestEndpoints.READ).header(AUTHORIZATION,
            TestTokens.bearer(activeKeyToken(claims(issuerNow, issuerNow.plusSeconds(900), issuerNow)))))
        .andExpect(status().isOk());
  }

  @Test
  void anIssuerAheadBeyondTheSkewIsRejected() throws Exception {
    Instant issuerNow = Instant.now().plusSeconds(90);
    expect401(activeKeyToken(claims(issuerNow, issuerNow.plusSeconds(900), issuerNow)));
  }

  /** An issuer 50 s behind: a token that by its own clock expired 50 s ago... is still inside our skew window. */
  @Test
  void anExpiredTokenIsAcceptedOnlyWithinTheSkew() throws Exception {
    mvc.perform(get(SecurityTestEndpoints.READ).header(AUTHORIZATION,
            TestTokens.bearer(activeKeyToken(claims(Instant.now().minusSeconds(950), Instant.now().minusSeconds(50),
                null)))))
        .andExpect(status().isOk());
    expect401(activeKeyToken(claims(Instant.now().minusSeconds(990), Instant.now().minusSeconds(70), null)));
  }

  // ------------------------------------------------------------------------------------------------ helpers

  private void expect401(String token) throws Exception {
    mvc.perform(get(SecurityTestEndpoints.READ).header(AUTHORIZATION, TestTokens.bearer(token)))
        .andExpect(status().isUnauthorized())
        .andExpect(jsonPath("$.code").value("invalid_token"));
  }

  private String foreignKeyToken(String kid) throws Exception {
    RSAKey foreign = new RSAKeyGenerator(2048).keyID(kid).generate();
    SignedJWT jwt = new SignedJWT(new JWSHeader.Builder(JWSAlgorithm.RS256).keyID(kid).build(),
        claims(Instant.now(), Instant.now().plusSeconds(300), null));
    jwt.sign(new RSASSASigner(foreign));
    return jwt.serialize();
  }

  private String activeKeyToken(JWTClaimsSet claims) throws Exception {
    SignedJWT jwt = new SignedJWT(new JWSHeader.Builder(JWSAlgorithm.RS256).keyID(keys.activeKeyId()).build(), claims);
    jwt.sign(new RSASSASigner(keys.activeSigningKey()));
    return jwt.serialize();
  }

  private JWTClaimsSet claims(Instant issuedAt, Instant expiresAt, Instant notBefore) {
    JWTClaimsSet.Builder b = new JWTClaimsSet.Builder()
        .issuer(properties.issuer())
        .subject(Ids.newId().toString())
        .claim(Claims.ACCOUNT, Ids.newId().toString())
        .claim(Claims.TENANT, Ids.newId().toString())
        .claim(Claims.SESSION, Ids.newId().toString())
        .claim(Claims.SESSION_VERSION, 1)
        .claim(Claims.PERMISSIONS, List.of("test.read"))
        .issueTime(Date.from(issuedAt))
        .expirationTime(Date.from(expiresAt))
        .jwtID(Ids.newId().toString());
    if (notBefore != null) {
      b.notBeforeTime(Date.from(notBefore));
    }
    return b.build();
  }
}
