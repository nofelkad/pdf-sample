package com.acme.iam.auth;

import static org.assertj.core.api.Assertions.assertThat;

import com.acme.iam.common.Ids;
import com.acme.iam.common.test.Fixtures;
import com.acme.iam.common.test.IntegrationTest;
import com.acme.iam.common.test.PostgresTestBase;
import java.security.SecureRandom;
import java.time.Duration;
import java.time.Instant;
import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.util.UUID;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.simple.JdbcClient;

/**
 * Final review M2: used or expired {@code user_token} rows and revoked or expired {@code user_session} rows older than
 * {@code iam.tokens.purge.retention} (30 days) are deleted by a ShedLock job; everything younger, and every live token
 * and session, stays. {@code user_token(user_id)} is indexed.
 */
@IntegrationTest
class CredentialPurgeJobIT extends PostgresTestBase {

  private static final SecureRandom RANDOM = new SecureRandom();

  @Autowired CredentialPurgeJob job;
  @Autowired JdbcClient jdbc;

  @Test
  void deletesOnlyEndedCredentialsOlderThanTheRetention() {
    Fixtures fx = new Fixtures(jdbc);
    Fixtures.Scenario s = fx.scenario();
    Instant now = Instant.now();
    Instant old = now.minus(Duration.ofDays(31));
    Instant recent = now.minus(Duration.ofDays(29));

    UUID usedLongAgo = token(s.userId(), old.minus(Duration.ofDays(1)), old);
    UUID expiredLongAgo = token(s.userId(), old, null);
    UUID usedRecently = token(s.userId(), now.plus(Duration.ofDays(1)), recent);
    UUID expiredRecently = token(s.userId(), recent, null);
    UUID live = token(s.userId(), now.plus(Duration.ofDays(7)), null);

    UUID revokedLongAgo = session(s.userId(), s.tenantId(), now.plus(Duration.ofHours(1)), old);
    UUID expiredSessionLongAgo = session(s.userId(), s.tenantId(), old, null);
    UUID revokedRecently = session(s.userId(), s.tenantId(), now.plus(Duration.ofHours(1)), recent);
    UUID openSession = session(s.userId(), s.tenantId(), now.plus(Duration.ofHours(12)), null);

    CredentialPurgeJob.Purged purged = job.runOnce();

    assertThat(purged.tokens()).isGreaterThanOrEqualTo(2);
    assertThat(purged.sessions()).isGreaterThanOrEqualTo(2);
    assertThat(existing("user_token", usedLongAgo, expiredLongAgo, usedRecently, expiredRecently, live))
        .containsExactlyInAnyOrder(usedRecently, expiredRecently, live);
    assertThat(existing("user_session", revokedLongAgo, expiredSessionLongAgo, revokedRecently, openSession))
        .containsExactlyInAnyOrder(revokedRecently, openSession);
  }

  @Test
  void userTokenIsIndexedByUser() {
    assertThat(jdbc.sql("""
            SELECT indexdef FROM pg_indexes WHERE tablename = 'user_token' AND indexdef LIKE '%(user_id)%'""")
        .query(String.class).list()).isNotEmpty();
  }

  // ------------------------------------------------------------------------------------------ helpers

  private UUID token(UUID user, Instant expiresAt, Instant usedAt) {
    UUID id = Ids.newId();
    byte[] hash = new byte[32];
    RANDOM.nextBytes(hash);
    jdbc.sql("""
            INSERT INTO user_token (id, user_id, purpose, token_hash, expires_at, used_at, created_at)
            VALUES (:id, :u, 'INVITE', :h, :e, :used, :e)""")
        .param("id", id).param("u", user).param("h", hash).param("e", utc(expiresAt)).param("used", utc(usedAt))
        .update();
    return id;
  }

  private UUID session(UUID user, UUID tenant, Instant expiresAt, Instant revokedAt) {
    UUID id = Ids.newId();
    byte[] hash = new byte[32];
    RANDOM.nextBytes(hash);
    jdbc.sql("""
            INSERT INTO user_session (id, user_id, active_tenant_id, refresh_hash, expires_at, revoked_at, version)
            VALUES (:id, :u, :t, :h, :e, :r, 0)""")
        .param("id", id).param("u", user).param("t", tenant).param("h", hash).param("e", utc(expiresAt))
        .param("r", utc(revokedAt))
        .update();
    return id;
  }

  private java.util.List<UUID> existing(String table, UUID... ids) {
    return jdbc.sql("SELECT id FROM " + table + " WHERE id = ANY (CAST(:ids AS uuid[]))")
        .param("ids", "{" + String.join(",", java.util.Arrays.stream(ids).map(UUID::toString).toList()) + "}")
        .query(UUID.class).list();
  }

  private static OffsetDateTime utc(Instant instant) {
    return instant == null ? null : OffsetDateTime.ofInstant(instant, ZoneOffset.UTC);
  }
}
