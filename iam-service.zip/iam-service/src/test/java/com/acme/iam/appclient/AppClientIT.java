package com.acme.iam.appclient;

import static org.assertj.core.api.Assertions.assertThat;
import static org.hamcrest.Matchers.startsWith;
import static org.springframework.http.HttpHeaders.AUTHORIZATION;
import static org.springframework.http.HttpHeaders.CACHE_CONTROL;
import static org.springframework.http.HttpHeaders.WWW_AUTHENTICATE;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.header;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import com.acme.iam.account.Account;
import com.acme.iam.assignment.ScopeType;
import com.acme.iam.common.Ids;
import com.acme.iam.common.test.Fixtures;
import com.acme.iam.common.test.OrgTestData;
import com.acme.iam.product.Product;
import java.util.UUID;
import com.acme.iam.common.security.SecurityTestEndpoints;
import com.acme.iam.common.test.IntegrationTest;
import com.acme.iam.common.test.PostgresTestBase;
import com.acme.iam.common.test.TestTokens;
import com.acme.iam.common.web.RequestIdFilter;
import com.acme.iam.core.Claims;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.nimbusds.jwt.JWTClaimsSet;
import com.nimbusds.jwt.SignedJWT;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Base64;
import java.util.Map;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.context.annotation.Import;
import org.springframework.http.MediaType;
import org.springframework.jdbc.core.simple.JdbcClient;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.ResultActions;

/** P1-12.1: app client registration (platform) and the client-credentials token for {@code /internal/*}. */
@IntegrationTest
@AutoConfigureMockMvc
@Import(SecurityTestEndpoints.class)
class AppClientIT extends PostgresTestBase {

  private static final String CLIENTS = "/api/platform/app-clients";

  @Autowired MockMvc mvc;
  @Autowired TestTokens tokens;
  @Autowired JdbcClient jdbc;
  @Autowired ObjectMapper json;

  private String platformAdmin;
  private String clientId;

  private OrgTestData orgData;

  @BeforeEach
  void setUp() {
    orgData = new OrgTestData(jdbc);
    platformAdmin = orgData.platformBearer(tokens, orgData.platformOperator());
    clientId = "billing-" + Ids.newId().toString().substring(24);
  }

  @Test
  void registrationShowsTheSecretOnceAndStoresOnlyItsHash() throws Exception {
    JsonNode created = register(clientId, "BILLING")
        .andExpect(status().isCreated())
        .andExpect(header().string(CACHE_CONTROL, "no-store"))
        .andExpect(jsonPath("$.clientId").value(clientId))
        .andExpect(jsonPath("$.productCode").value("BILLING"))
        .andExpect(jsonPath("$.status").value("ACTIVE"))
        .andExpect(jsonPath("$.createdAt").isNotEmpty())
        .andExpect(jsonPath("$.id").isNotEmpty())
        .andReturn().getResponse().getContentAsString().transform(this::tree);
    String secret = created.get("clientSecret").asText();

    assertThat(Base64.getUrlDecoder().decode(secret)).hasSize(32);
    byte[] stored = jdbc.sql("SELECT secret_hash FROM app_client WHERE client_id = ?").params(clientId)
        .query(byte[].class).single();
    assertThat(stored).isEqualTo(MessageDigest.getInstance("SHA-256").digest(secret.getBytes(StandardCharsets.UTF_8)));

    String audit = jdbc.sql("SELECT after_state::text FROM audit_event WHERE action = 'iam.app_client.insert' "
        + "AND target_id = ?").params(created.get("id").asText()).query(String.class).single();
    assertThat(audit).contains(clientId).doesNotContain("secret_hash").doesNotContain(secret);

    String list = mvc.perform(get(CLIENTS).param("limit", "200").header(AUTHORIZATION, platformAdmin))
        .andExpect(status().isOk())
        .andReturn().getResponse().getContentAsString();
    assertThat(list).contains(clientId).doesNotContain(secret).doesNotContain("secret");
  }

  @Test
  void listIsKeysetPaginated() throws Exception {
    register(clientId + "-a", "BILLING").andExpect(status().isCreated());
    register(clientId + "-b", "BILLING").andExpect(status().isCreated());

    JsonNode first = tree(mvc.perform(get(CLIENTS).param("limit", "1").header(AUTHORIZATION, platformAdmin))
        .andExpect(status().isOk()).andReturn().getResponse().getContentAsString());
    assertThat(first.get("items")).hasSize(1);
    String next = first.get("next").asText();

    mvc.perform(get(CLIENTS).param("limit", "1").param("after", next).header(AUTHORIZATION, platformAdmin))
        .andExpect(status().isOk())
        .andExpect(jsonPath("$.items.length()").value(1))
        .andExpect(jsonPath("$.items[0].id").value(org.hamcrest.Matchers.not(next)));
  }

  @Test
  void duplicateAndInvalidRegistrationsAreRejected() throws Exception {
    register(clientId, "BILLING").andExpect(status().isCreated());

    register(clientId, "BILLING").andExpect(status().isConflict()).andExpect(jsonPath("$.code").value("app_client_exists"));
    register("Bad Id!", "BILLING").andExpect(status().isBadRequest())
        .andExpect(jsonPath("$.code").value("validation_failed"));
    register(clientId + "x", "billing").andExpect(status().isBadRequest());
  }

  @Test
  void platformApiRequiresPlatformAccountManage() throws Exception {
    String requestId = "ac-deny-" + Ids.newId();

    mvc.perform(post(CLIENTS).header(RequestIdFilter.HEADER, requestId)
            .header(AUTHORIZATION, tokens.user(Ids.newId()).perms("iam.user.manage").bearer())
            .contentType(MediaType.APPLICATION_JSON)
            .content("{\"clientId\":\"" + clientId + "\",\"productCode\":\"BILLING\"}"))
        .andExpect(status().isForbidden());
    mvc.perform(get(CLIENTS).header(AUTHORIZATION, TestTokens.bearer(tokens.appToken("x-app", "X"))))
        .andExpect(status().isForbidden());

    assertThat(jdbc.sql("SELECT metadata->>'requiredAuthority' FROM audit_event "
            + "WHERE action = 'authz.denied' AND request_id = ?").params(requestId).query(String.class).single())
        .isEqualTo("platform.account.manage");
  }

  /** Deferred fix E1: like every platform endpoint, only callers of the PLATFORM account (403 otherwise). */
  @Test
  void platformApiRequiresThePlatformAccount() throws Exception {
    Fixtures fx = orgData.fixtures();
    Fixtures.Scenario customer = fx.scenario();
    fx.assign(customer.userId(), fx.customRole(Product.IAM_ID, customer.accountId(),
        fx.permission(Product.IAM_ID, OrgTestData.PLATFORM_PERMISSION)), ScopeType.ACCOUNT, customer.accountId());
    String customerBearer = orgData.bearer(tokens, customer.userId(), customer.accountId(), customer.tenantId(),
        OrgTestData.PLATFORM_PERMISSION);

    mvc.perform(get(CLIENTS).header(AUTHORIZATION, customerBearer))
        .andExpect(status().isForbidden())
        .andExpect(jsonPath("$.code").value("platform_account_required"));
    mvc.perform(post(CLIENTS).header(AUTHORIZATION, customerBearer).contentType(MediaType.APPLICATION_JSON)
            .content("{\"clientId\":\"" + clientId + "\",\"productCode\":\"BILLING\"}"))
        .andExpect(status().isForbidden())
        .andExpect(jsonPath("$.code").value("platform_account_required"));
    mvc.perform(delete(CLIENTS + "/{id}", Ids.newId()).header(AUTHORIZATION, customerBearer))
        .andExpect(status().isForbidden())
        .andExpect(jsonPath("$.code").value("platform_account_required"));
  }

  /** The platform permission held only at TENANT scope does not reach the cross-account platform API. */
  @Test
  void platformApiRequiresAnAccountScopeGrant() throws Exception {
    Fixtures fx = orgData.fixtures();
    UUID tenant = fx.tenant(Account.PLATFORM_ID);
    UUID user = fx.user(Account.PLATFORM_ID, tenant);
    fx.assign(user, orgData.platformAdminRole(), ScopeType.TENANT, tenant);
    String tenantScoped = orgData.platformBearer(tokens, new OrgTestData.Operator(user, tenant));

    mvc.perform(get(CLIENTS).header(AUTHORIZATION, tenantScoped))
        .andExpect(status().isForbidden())
        .andExpect(jsonPath("$.code").value("account_scope_required"));
  }

  /** Deferred fix E6: a DISABLED client keeps its row but cannot obtain tokens; disabling is idempotent. */
  @Test
  void disabledClientCannotObtainTokens() throws Exception {
    JsonNode created = tree(register(clientId, "BILLING").andReturn().getResponse().getContentAsString());
    String id = created.get("id").asText();
    String secret = created.get("clientSecret").asText();
    token(basic(clientId, secret), "client_credentials", null).andExpect(status().isOk());

    mvc.perform(post(CLIENTS + "/{id}/disable", id).header(AUTHORIZATION, platformAdmin))
        .andExpect(status().isOk())
        .andExpect(jsonPath("$.status").value("DISABLED"))
        .andExpect(jsonPath("$.clientSecret").doesNotExist());
    mvc.perform(post(CLIENTS + "/{id}/disable", id).header(AUTHORIZATION, platformAdmin))
        .andExpect(status().isOk())
        .andExpect(jsonPath("$.status").value("DISABLED"));

    String requestId = "ac-disabled-" + Ids.newId();
    token(basic(clientId, secret), "client_credentials", requestId)
        .andExpect(status().isUnauthorized())
        .andExpect(header().string(WWW_AUTHENTICATE, startsWith("Basic")))
        .andExpect(header().string(CACHE_CONTROL, "no-store"))
        .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_PROBLEM_JSON))
        .andExpect(jsonPath("$.code").value("invalid_client"))
        .andExpect(jsonPath("$.requestId").value(requestId));
    assertThat(jdbc.sql("SELECT metadata->>'reason' FROM audit_event WHERE action = 'auth.app_client.failed' "
        + "AND request_id = ?").params(requestId).query(String.class).single()).isEqualTo("disabled");
    assertThat(jdbc.sql("SELECT count(*) FROM audit_event WHERE action = 'iam.app_client.update' AND target_id = ?")
        .params(id).query(Long.class).single()).as("one audited row change, the second call is a no-op").isEqualTo(1);

    mvc.perform(post(CLIENTS + "/{id}/disable", Ids.newId()).header(AUTHORIZATION, platformAdmin))
        .andExpect(status().isNotFound())
        .andExpect(jsonPath("$.code").value("app_client_not_found"));
  }

  /** Ruling R39: a new secret is shown once, the old one stops working immediately, the rotation is audited. */
  @Test
  void rotatingTheSecretInvalidatesTheOldOneAtOnce() throws Exception {
    JsonNode created = tree(register(clientId, "BILLING").andReturn().getResponse().getContentAsString());
    String id = created.get("id").asText();
    String oldSecret = created.get("clientSecret").asText();

    JsonNode rotated = tree(mvc.perform(post(CLIENTS + "/{id}/rotate-secret", id).header(AUTHORIZATION, platformAdmin))
        .andExpect(status().isOk())
        .andExpect(header().string(CACHE_CONTROL, "no-store"))
        .andExpect(jsonPath("$.clientId").value(clientId))
        .andReturn().getResponse().getContentAsString());
    String newSecret = rotated.get("clientSecret").asText();

    assertThat(newSecret).isNotEqualTo(oldSecret);
    assertThat(Base64.getUrlDecoder().decode(newSecret)).hasSize(32);
    token(basic(clientId, oldSecret), "client_credentials", null).andExpect(status().isUnauthorized());
    token(basic(clientId, newSecret), "client_credentials", null).andExpect(status().isOk());
    String audit = jdbc.sql("SELECT metadata::text FROM audit_event WHERE action = 'iam.app_client.secret_rotated' "
        + "AND target_id = ?").params(clientId).query(String.class).single();
    assertThat(audit).doesNotContain(newSecret).doesNotContain(oldSecret);
    mvc.perform(post(CLIENTS + "/{id}/rotate-secret", Ids.newId()).header(AUTHORIZATION, platformAdmin))
        .andExpect(status().isNotFound()).andExpect(jsonPath("$.code").value("app_client_not_found"));
  }

  @Test
  void clientCredentialsYieldAnInternalTokenThatReadsRevocations() throws Exception {
    String secret = secretOf(register(clientId, "BILLING"));
    String requestId = "ac-token-" + Ids.newId();

    JsonNode token = tree(token(basic(clientId, secret), "client_credentials", requestId)
        .andExpect(status().isOk())
        .andExpect(header().string(CACHE_CONTROL, "no-store"))
        .andExpect(jsonPath("$.token_type").value("Bearer"))
        .andExpect(jsonPath("$.expires_in").value(600))
        .andReturn().getResponse().getContentAsString());

    JWTClaimsSet claims = SignedJWT.parse(token.get("access_token").asText()).getJWTClaimsSet();
    assertThat(claims.getSubject()).isEqualTo("app:" + clientId);
    assertThat(claims.getStringClaim("typ")).isEqualTo("app");
    assertThat(claims.getStringClaim("prd")).isEqualTo("BILLING");
    assertThat(claims.getStringListClaim("perms")).containsExactlyElementsOf(Claims.APP_PERMISSIONS);

    mvc.perform(get("/internal/revocations").param("since", "0")
            .header(AUTHORIZATION, TestTokens.bearer(token.get("access_token").asText())))
        .andExpect(status().isOk())
        .andExpect(jsonPath("$.entries").isArray())
        .andExpect(jsonPath("$.cursor").isNumber());

    Map<String, Object> audit = jdbc.sql("SELECT outcome, source, actor_type, metadata->>'client_id' AS client_id "
        + "FROM audit_event WHERE action = 'auth.app_client.token' AND request_id = ?").params(requestId).query().singleRow();
    assertThat(audit).containsEntry("outcome", "SUCCESS").containsEntry("source", "app:" + clientId)
        .containsEntry("actor_type", "SYSTEM").containsEntry("client_id", clientId);
  }

  @Test
  void badCredentialsAre401InvalidClientAndAudited() throws Exception {
    String secret = secretOf(register(clientId, "BILLING"));
    String requestId = "ac-fail-" + Ids.newId();

    token(basic(clientId, secret + "x"), "client_credentials", requestId)
        .andExpect(status().isUnauthorized())
        .andExpect(header().string(WWW_AUTHENTICATE, startsWith("Basic")))
        .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_PROBLEM_JSON))
        .andExpect(jsonPath("$.code").value("invalid_client"))
        .andExpect(jsonPath("$.requestId").value(requestId));
    token(basic("no-such-client", secret), "client_credentials", null)
        .andExpect(status().isUnauthorized()).andExpect(jsonPath("$.code").value("invalid_client"));
    token(null, "client_credentials", null)
        .andExpect(status().isUnauthorized()).andExpect(jsonPath("$.code").value("invalid_client"));
    token("Basic !!!notbase64", "client_credentials", null)
        .andExpect(status().isUnauthorized()).andExpect(jsonPath("$.code").value("invalid_client"));

    Map<String, Object> audit = jdbc.sql("SELECT outcome, actor_type, metadata->>'client_id' AS client_id, "
            + "metadata->>'reason' AS reason, metadata::text AS metadata "
            + "FROM audit_event WHERE action = 'auth.app_client.failed' AND request_id = ?")
        .params(requestId).query().singleRow();
    assertThat(audit).containsEntry("outcome", "FAILURE").containsEntry("actor_type", "ANONYMOUS")
        .containsEntry("client_id", clientId).containsEntry("reason", "bad_secret");
    assertThat((String) audit.get("metadata")).doesNotContain(secret);
  }

  @Test
  void malformedClientIdIsRecordedOnlyTruncatedAndMarked() throws Exception {
    String requestId = "ac-junk-" + Ids.newId();
    String junk = "Evil\u0001Id<script>" + "x".repeat(500);

    token(basic(junk, "whatever"), "client_credentials", requestId)
        .andExpect(status().isUnauthorized())
        .andExpect(jsonPath("$.code").value("invalid_client"));

    Map<String, Object> audit = jdbc.sql("SELECT target_type, target_id, metadata->>'client_id' AS client_id, "
            + "metadata->>'client_id_invalid' AS invalid, metadata->>'reason' AS reason "
            + "FROM audit_event WHERE action = 'auth.app_client.failed' AND request_id = ?")
        .params(requestId).query().singleRow();
    assertThat(audit.get("target_type")).isNull();
    assertThat(audit.get("target_id")).isNull();
    assertThat(audit.get("client_id")).isNull();
    assertThat((String) audit.get("invalid")).hasSizeLessThanOrEqualTo(64).startsWith("evil").doesNotContain("\u0001");
    assertThat(audit).containsEntry("reason", "unknown_client");
  }

  @Test
  void onlyClientCredentialsGrantIsSupported() throws Exception {
    String secret = secretOf(register(clientId, "BILLING"));

    token(basic(clientId, secret), "password", null)
        .andExpect(status().isBadRequest())
        .andExpect(jsonPath("$.code").value("unsupported_grant_type"));
    token(basic(clientId, secret), null, null)
        .andExpect(status().isBadRequest());
  }

  @Test
  void deletedClientCanNoLongerGetTokens() throws Exception {
    JsonNode created = tree(register(clientId, "BILLING").andReturn().getResponse().getContentAsString());
    String id = created.get("id").asText();

    mvc.perform(delete(CLIENTS + "/{id}", id).header(AUTHORIZATION, platformAdmin))
        .andExpect(status().isNoContent());

    token(basic(clientId, created.get("clientSecret").asText()), "client_credentials", null)
        .andExpect(status().isUnauthorized());
    mvc.perform(delete(CLIENTS + "/{id}", id).header(AUTHORIZATION, platformAdmin))
        .andExpect(status().isNotFound())
        .andExpect(jsonPath("$.code").value("app_client_not_found"));
  }

  // ------------------------------------------------------------------------------------------------ helpers

  private ResultActions register(String id, String product) throws Exception {
    return mvc.perform(post(CLIENTS).header(AUTHORIZATION, platformAdmin)
        .contentType(MediaType.APPLICATION_JSON)
        .content("{\"clientId\":\"" + id + "\",\"productCode\":\"" + product + "\"}"));
  }

  private String secretOf(ResultActions registration) throws Exception {
    return tree(registration.andExpect(status().isCreated()).andReturn().getResponse().getContentAsString())
        .get("clientSecret").asText();
  }

  private ResultActions token(String authorization, String grantType, String requestId) throws Exception {
    var request = post("/internal/token").contentType(MediaType.APPLICATION_FORM_URLENCODED);
    if (authorization != null) {
      request.header(AUTHORIZATION, authorization);
    }
    if (grantType != null) {
      request.param("grant_type", grantType);
    }
    if (requestId != null) {
      request.header(RequestIdFilter.HEADER, requestId);
    }
    return mvc.perform(request);
  }

  private static String basic(String id, String secret) {
    return "Basic " + Base64.getEncoder().encodeToString((id + ":" + secret).getBytes(StandardCharsets.UTF_8));
  }

  private JsonNode tree(String body) {
    try {
      return json.readTree(body);
    } catch (Exception e) {
      throw new IllegalStateException(e);
    }
  }
}
