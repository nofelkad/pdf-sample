package com.acme.iam.auth;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatCode;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

import com.acme.iam.common.error.ApiException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;
import org.junit.jupiter.api.Test;
import org.springframework.http.HttpStatus;
import org.springframework.security.crypto.argon2.Argon2PasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;

/** P1-5.1: Argon2id hashing and the per-account password policy. */
class PasswordServiceTest {

  static final PasswordEncoder ARGON2 = Argon2PasswordEncoder.defaultsForSpringSecurity_v5_8();

  final AtomicInteger breachedCalls = new AtomicInteger();
  final List<String> breachedList = new ArrayList<>(List.of("correct horse battery staple"));
  final BreachedPasswordChecker checker = raw -> {
    breachedCalls.incrementAndGet();
    return breachedList.contains(raw);
  };
  final PasswordService service = new PasswordService(ARGON2, checker, PasswordPolicy.DEFAULTS);

  @Test
  void hashesWithArgon2idAndVerifies() {
    String hash = service.hash("a perfectly fine passphrase");

    assertThat(hash).startsWith("$argon2id$");
    assertThat(service.matches("a perfectly fine passphrase", hash)).isTrue();
    assertThat(service.matches("another passphrase!", hash)).isFalse();
  }

  @Test
  void aMissingHashNeverMatchesButStillRunsOneVerification() {
    long start = System.nanoTime();
    assertThat(service.matches("whatever password", null)).isFalse();
    // a dummy Argon2 verification takes measurable time (no early return)
    assertThat(System.nanoTime() - start).isGreaterThan(1_000_000L);
  }

  @Test
  void defaultPolicyIsMin12Max128History5NoBreachedCheck() {
    assertThat(PasswordPolicy.DEFAULTS).isEqualTo(new PasswordPolicy(12, 128, 5, false));
    assertThat(service.policy(Map.of())).isEqualTo(PasswordPolicy.DEFAULTS);
  }

  @Test
  void accountSettingsOverrideIndividualPolicyKeys() {
    PasswordPolicy policy = service.policy(Map.of("passwordPolicy",
        Map.of("minLength", 16, "historySize", 2, "breachedCheck", true)));

    assertThat(policy).isEqualTo(new PasswordPolicy(16, 128, 2, true));
  }

  @Test
  void malformedSettingsFallBackToDefaults() {
    PasswordPolicy policy = service.policy(Map.of("passwordPolicy",
        Map.of("minLength", "twelve", "maxLength", "lots", "historySize", "five", "breachedCheck", "yes")));

    assertThat(policy).isEqualTo(PasswordPolicy.DEFAULTS);
  }

  @Test
  void outOfRangeSettingsAreClamped() {
    // 8 <= minLength <= maxLength <= 1024, 0 <= historySize <= 24
    assertThat(service.policy(Map.of("passwordPolicy", Map.of("minLength", 4, "maxLength", 5000, "historySize", 99))))
        .isEqualTo(new PasswordPolicy(8, 1024, 24, false));
    assertThat(service.policy(Map.of("passwordPolicy", Map.of("minLength", 40, "maxLength", 20, "historySize", -1))))
        .isEqualTo(new PasswordPolicy(40, 40, 0, false));
    assertThat(service.policy(Map.of("passwordPolicy", Map.of("minLength", 2000))))
        .isEqualTo(new PasswordPolicy(1024, 1024, 5, false));
  }

  @Test
  void theConfiguredDefaultsAreClampedTheSameWay() {
    // iam.auth.password-policy.min-length > max-length (each within its own @Min/@Max bounds)
    assertThat(new AuthProperties.Policy(40, 20, 5, false).toPolicy()).isEqualTo(new PasswordPolicy(40, 40, 5, false));
    assertThat(new AuthProperties.Policy(12, 128, 5, true).toPolicy()).isEqualTo(new PasswordPolicy(12, 128, 5, true));
  }

  @Test
  void rejectsTooShortAndTooLongPasswordsWithViolations() {
    assertViolations(() -> service.validate(PasswordPolicy.DEFAULTS, "short", List.of()), "too_short");
    assertViolations(() -> service.validate(PasswordPolicy.DEFAULTS, "x".repeat(129), List.of()), "too_long");
  }

  @Test
  void lengthCountsCodePointsNotUtf16Units() {
    String twelveEmoji = "😀".repeat(12);
    assertThatCode(() -> service.validate(PasswordPolicy.DEFAULTS, twelveEmoji, List.of())).doesNotThrowAnyException();
  }

  @Test
  void rejectsReuseOfCurrentOrRecentPasswords() {
    List<String> previous = List.of(service.hash("old passphrase one"), service.hash("old passphrase two"));

    assertViolations(() -> service.validate(PasswordPolicy.DEFAULTS, "old passphrase two", previous), "reused");
    assertThatCode(() -> service.validate(PasswordPolicy.DEFAULTS, "brand new passphrase", previous))
        .doesNotThrowAnyException();
  }

  @Test
  void historySizeLimitsHowManyPreviousHashesAreChecked() {
    // newest first: the first entry is the current password, then history
    List<String> previous = List.of(service.hash("current passphrase"), service.hash("older passphrase"));
    PasswordPolicy historyOne = new PasswordPolicy(12, 128, 1, false);

    assertViolations(() -> service.validate(historyOne, "current passphrase", previous), "reused");
    assertThatCode(() -> service.validate(historyOne, "older passphrase", previous)).doesNotThrowAnyException();
  }

  @Test
  void breachedCheckRunsOnlyWhenEnabled() {
    service.validate(PasswordPolicy.DEFAULTS, "correct horse battery staple", List.of());
    assertThat(breachedCalls).hasValue(0);

    PasswordPolicy withCheck = new PasswordPolicy(12, 128, 5, true);
    assertViolations(() -> service.validate(withCheck, "correct horse battery staple", List.of()), "breached");
    assertThat(breachedCalls).hasValue(1);
  }

  private static void assertViolations(org.assertj.core.api.ThrowableAssert.ThrowingCallable call, String... codes) {
    assertThatThrownBy(call)
        .isInstanceOfSatisfying(ApiException.class, ex -> {
          assertThat(ex.status()).isEqualTo(HttpStatus.BAD_REQUEST);
          assertThat(ex.code()).isEqualTo("password_policy");
          assertThat(ex.properties()).containsEntry("violations", List.of(codes));
        });
  }
}
