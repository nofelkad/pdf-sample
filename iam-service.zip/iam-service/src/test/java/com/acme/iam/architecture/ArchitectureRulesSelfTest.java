package com.acme.iam.architecture;

import static org.assertj.core.api.Assertions.assertThat;

import com.tngtech.archunit.core.domain.JavaClasses;
import com.tngtech.archunit.core.importer.ClassFileImporter;
import com.tngtech.archunit.lang.ArchRule;
import com.tngtech.archunit.lang.EvaluationResult;
import org.junit.jupiter.api.Test;

/** Proves the rules bite: run against {@code com.acme.archfixture}, which contains known violations. */
class ArchitectureRulesSelfTest {

  private static final String ROOT = "com.acme.archfixture";
  private static final JavaClasses FIXTURES = new ClassFileImporter().importPackages(ROOT);

  @Test
  void crossFeatureRepositoryUseIsReported() {
    String report = violations(ArchitectureRules.repositoriesAreOnlyUsedInsideTheirFeature(ROOT));

    assertThat(report).contains("BetaService").contains("BetaController").doesNotContain("AlphaService");
  }

  @Test
  void persistenceInControllersIsReported() {
    String report = violations(ArchitectureRules.controllersDoNotAccessPersistence(ROOT));

    assertThat(report).contains("BetaController").contains("AlphaRepository").contains("JdbcTemplate")
        .doesNotContain("AlphaController").doesNotContain("GammaController");
  }

  @Test
  void nonServiceCallsIntoOtherFeaturesAreReported() {
    String report = violations(ArchitectureRules.controllersCallOtherFeaturesOnlyThroughServices(ROOT));

    assertThat(report).contains("BetaController").contains("AlphaHelper")
        .doesNotContain("GammaController").doesNotContain("Method <com.acme.archfixture.alpha.AlphaController");
  }

  private static String violations(ArchRule rule) {
    EvaluationResult result = rule.evaluate(FIXTURES);
    assertThat(result.hasViolation()).as("rule %s should report violations", rule.getDescription()).isTrue();
    return String.join("\n", result.getFailureReport().getDetails());
  }
}
