package com.acme.iam.audit;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;

/**
 * An operator-style {@link AuditArchiveHook} provided by an ordinary component-scanned configuration. Active only with
 * the {@value #PROFILE} profile, so it does not leak into other test contexts.
 */
@Configuration(proxyBeanMethods = false)
@Profile(ScannedArchiveHookConfig.PROFILE)
class ScannedArchiveHookConfig {

  static final String PROFILE = "scanned-archive-hook";
  static final AuditArchiveHook INSTANCE = name -> false;

  @Bean
  AuditArchiveHook scannedArchiveHook() {
    return INSTANCE;
  }
}
