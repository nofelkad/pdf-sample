package com.acme.iam.audit;

import static org.assertj.core.api.Assertions.assertThat;

import com.acme.iam.common.test.IntegrationTest;
import com.acme.iam.common.test.PostgresTestBase;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Import;
import org.springframework.test.context.ActiveProfiles;

/** Which {@link AuditArchiveHook} the application wires: refusing by default, configurable, or the operator's own. */
class AuditArchiveHookSelectionIT {

  @IntegrationTest
  @Nested
  class Default extends PostgresTestBase {
    @Autowired AuditArchiveHook hook;

    @Test
    void refusesSoNothingIsDroppedUntilAnOperatorDecides() {
      assertThat(hook).isInstanceOf(RefusingArchiveHook.class);
      assertThat(hook.archive("audit_event_y2015m03")).isFalse();
    }
  }

  @IntegrationTest(properties = "iam.audit.archive.mode=none-acknowledged")
  @Nested
  class Acknowledged extends PostgresTestBase {
    @Autowired AuditArchiveHook hook;

    @Test
    void noneAcknowledgedAllowsDroppingWithoutArchive() {
      assertThat(hook).isInstanceOf(AcknowledgedNoArchiveHook.class);
      assertThat(hook.archive("audit_event_y2015m03")).isTrue();
    }
  }

  @IntegrationTest(properties = "iam.audit.archive.mode=none-acknowledged")
  @Import(OperatorHook.class)
  @Nested
  class Custom extends PostgresTestBase {
    @Autowired AuditArchiveHook hook;

    @Test
    void anOperatorProvidedHookReplacesTheDefaultEvenWhenTheModeIsSet() {
      assertThat(hook).isSameAs(OperatorHook.INSTANCE);
    }
  }

  /** The operator's hook comes from an ordinary component-scanned configuration, not from an import. */
  @IntegrationTest
  @ActiveProfiles({"test", ScannedArchiveHookConfig.PROFILE})
  @Nested
  class Scanned extends PostgresTestBase {
    @Autowired AuditArchiveHook hook;

    @Test
    void aHookFromAScannedConfigurationWinsRegardlessOfBeanOrdering() {
      assertThat(hook).isSameAs(ScannedArchiveHookConfig.INSTANCE);
    }
  }

  @TestConfiguration
  static class OperatorHook {
    static final AuditArchiveHook INSTANCE = name -> false;

    @Bean
    AuditArchiveHook operatorArchiveHook() {
      return INSTANCE;
    }
  }
}
