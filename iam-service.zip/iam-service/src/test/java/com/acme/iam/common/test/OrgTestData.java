package com.acme.iam.common.test;

import com.acme.iam.account.Account;
import com.acme.iam.assignment.ScopeType;
import com.acme.iam.product.Product;
import com.acme.iam.role.Role;
import java.time.OffsetDateTime;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import org.springframework.jdbc.core.simple.JdbcClient;

/**
 * Task 5 test data on top of {@link Fixtures}: the IAM permissions and system roles of {@code iam-manifest.yaml}
 * (spec section 2), created find-or-create by name the way Task 6's registry would, plus small read helpers.
 *
 * <pre>{@code
 * OrgTestData org = new OrgTestData(jdbc);
 * UUID admin = org.accountAdmin(s.accountId(), s.tenantId());   // ACTIVE user + Account Admin at ACCOUNT scope
 * String bearer = org.bearer(tokens, admin, s.accountId(), s.tenantId(), "iam.user.manage");
 * }</pre>
 */
public final class OrgTestData {

  public static final List<String> IAM_PERMISSIONS = List.of(
      "iam.tenant.manage", "iam.user.manage", "iam.user.share", "iam.user.read.tenant", "iam.user.read.account",
      "iam.role.manage", "iam.role.assign", "iam.session.revoke", "iam.audit.read", "iam.audit.export");
  public static final String PLATFORM_PERMISSION = "platform.account.manage";
  public static final List<String> TENANT_ADMIN_PERMISSIONS = List.of(
      "iam.user.manage", "iam.user.read.tenant", "iam.role.assign", "iam.session.revoke", "iam.audit.read");
  public static final String TENANT_ADMIN = "Tenant Admin";

  private final JdbcClient jdbc;
  private final Fixtures fx;

  public OrgTestData(JdbcClient jdbc) {
    this.jdbc = jdbc;
    this.fx = new Fixtures(jdbc);
  }

  public Fixtures fixtures() {
    return fx;
  }

  /** The "Account Admin" SYSTEM role (IAM, every iam.* permission). */
  public UUID accountAdminRole() {
    return fx.systemRole(Product.IAM_ID, Role.ACCOUNT_ADMIN, iamPermissionIds());
  }

  /** The "Platform Admin" SYSTEM role (IAM, platform.* and iam.*). */
  public UUID platformAdminRole() {
    UUID[] perms = new UUID[IAM_PERMISSIONS.size() + 1];
    System.arraycopy(iamPermissionIds(), 0, perms, 0, IAM_PERMISSIONS.size());
    perms[IAM_PERMISSIONS.size()] = fx.permission(Product.IAM_ID, PLATFORM_PERMISSION);
    return fx.systemRole(Product.IAM_ID, Role.PLATFORM_ADMIN, perms);
  }

  /** The "Tenant Admin" SYSTEM role. */
  public UUID tenantAdminRole() {
    return fx.systemRole(Product.IAM_ID, TENANT_ADMIN,
        TENANT_ADMIN_PERMISSIONS.stream().map(c -> fx.permission(Product.IAM_ID, c)).toArray(UUID[]::new));
  }

  /** A new ACTIVE user of the account (member of {@code tenant}) holding Account Admin at ACCOUNT scope. */
  public UUID accountAdmin(UUID account, UUID tenant) {
    UUID user = fx.user(account, tenant);
    fx.assign(user, accountAdminRole(), ScopeType.ACCOUNT, account);
    return user;
  }

  /** A user of the PLATFORM account and the tenant its token is active in. */
  public record Operator(UUID userId, UUID tenantId) {}

  /**
   * A platform operator as the bootstrap creates one: an ACTIVE user of the PLATFORM account (in a new tenant of it)
   * holding Platform Admin at ACCOUNT scope.
   */
  public Operator platformOperator() {
    UUID tenant = fx.tenant(Account.PLATFORM_ID);
    UUID user = fx.user(Account.PLATFORM_ID, tenant);
    fx.assign(user, platformAdminRole(), ScopeType.ACCOUNT, Account.PLATFORM_ID);
    return new Operator(user, tenant);
  }

  /** A bearer header for {@code operator} carrying {@code perms} (default: {@value #PLATFORM_PERMISSION}). */
  public String platformBearer(TestTokens tokens, Operator operator, String... perms) {
    return bearer(tokens, operator.userId(), Account.PLATFORM_ID, operator.tenantId(),
        perms.length == 0 ? new String[] {PLATFORM_PERMISSION} : perms);
  }

  /** A bearer header for a user token with the given claims and permissions. */
  public String bearer(TestTokens tokens, UUID user, UUID account, UUID tenant, String... perms) {
    return tokens.user(user).account(account).tenant(tenant).perms(perms).bearer();
  }

  /** A bearer header carrying every iam.* permission (what an Account Admin's token holds). */
  public String adminBearer(TestTokens tokens, UUID user, UUID account, UUID tenant) {
    return bearer(tokens, user, account, tenant, IAM_PERMISSIONS.toArray(String[]::new));
  }

  // ------------------------------------------------------------------------------------------------- reads

  public String userStatus(UUID user) {
    return jdbc.sql("SELECT status FROM app_user WHERE id = :id").param("id", user).query(String.class).single();
  }

  public int sessionVersion(UUID user) {
    return jdbc.sql("SELECT session_version FROM app_user WHERE id = :id").param("id", user).query(Integer.class)
        .single();
  }

  /** Revocation feed rows of the user. */
  public long revocations(UUID user) {
    return jdbc.sql("SELECT count(*) FROM revocation WHERE user_id = :id").param("id", user).query(Long.class)
        .single();
  }

  public long assignments(UUID user) {
    return jdbc.sql("SELECT count(*) FROM role_assignment WHERE user_id = :id").param("id", user).query(Long.class)
        .single();
  }

  public List<UUID> membershipTenants(UUID user) {
    return jdbc.sql("SELECT tenant_id FROM user_tenant_membership WHERE app_user = :id ORDER BY tenant_id")
        .param("id", user).query(UUID.class).list();
  }

  public Optional<UUID> userByEmail(UUID account, String email) {
    return jdbc.sql("SELECT id FROM app_user WHERE account_id = :a AND email = :e")
        .param("a", account).param("e", email).query(UUID.class).optional();
  }

  /** Expiry of the user's single unused INVITE token. */
  public OffsetDateTime outstandingInviteExpiry(UUID user) {
    return jdbc.sql("""
            SELECT expires_at FROM user_token WHERE user_id = :id AND purpose = 'INVITE' AND used_at IS NULL""")
        .param("id", user).query(OffsetDateTime.class).single();
  }

  public long outstandingTokens(UUID user) {
    return jdbc.sql("SELECT count(*) FROM user_token WHERE user_id = :id AND used_at IS NULL")
        .param("id", user).query(Long.class).single();
  }

  private UUID[] iamPermissionIds() {
    return IAM_PERMISSIONS.stream().map(c -> fx.permission(Product.IAM_ID, c)).toArray(UUID[]::new);
  }
}
