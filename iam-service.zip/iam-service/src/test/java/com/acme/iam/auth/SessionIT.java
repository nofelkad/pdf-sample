package com.acme.iam.auth;

import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import com.acme.iam.account.AccountStatus;
import com.acme.iam.common.test.PostgresTestBase;
import com.acme.iam.core.Claims;
import com.acme.iam.tenant.TenantStatus;
import com.acme.iam.user.MembershipStatus;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.simple.JdbcClient;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.security.oauth2.jwt.JwtDecoder;
import org.springframework.test.web.servlet.MockMvc;

/** P1-5.3 – P1-5.5: refresh rotation, reuse detection, timeouts, R17 re-checks, tenant switch, logout. */
@AuthIT
class SessionIT extends PostgresTestBase {

  @Autowired MockMvc mvc;
  @Autowired ObjectMapper json;
  @Autowired JdbcClient jdbc;
  @Autowired PasswordService passwords;
  @Autowired JwtDecoder jwtDecoder;
  @Autowired RevocationPoller poller;

  AuthTestData data;
  AuthClient client;
  AuthTestData.TestUser u;

  @BeforeEach
  void setUp() {
    data = new AuthTestData(jdbc, passwords);
    client = new AuthClient(mvc, json);
    u = data.user();
  }

  @Test
  void refreshRotatesTheRefreshTokenAndKeepsThePreviousHash() throws Exception {
    AuthClient.Tokens first = client.loginOk(u.email(), u.password());
    UUID sessionId = sid(first);

    AuthClient.Tokens second = client.tokens(client.refresh(first.refreshToken()).andExpect(status().isOk()).andReturn());

    assertThat(second.refreshToken()).isNotEqualTo(first.refreshToken());
    assertThat(sid(second)).isEqualTo(sessionId);
    Map<String, Object> session = data.session(sessionId);
    assertThat((byte[]) session.get("refresh_hash")).isEqualTo(AuthTestData.sha256(second.refreshToken()));
    assertThat((byte[]) session.get("prev_refresh_hash")).isEqualTo(AuthTestData.sha256(first.refreshToken()));
    assertThat(data.auditOfRequest(client.lastRequestId())).containsExactly("auth.refresh/SUCCESS/USER");
  }

  @Test
  void reusingTheOldRefreshTokenRevokesTheSessionAndTheUsersAccessTokens() throws Exception {
    AuthClient.Tokens first = client.loginOk(u.email(), u.password());
    AuthClient.Tokens second = client.tokens(client.refresh(first.refreshToken()).andReturn());
    int svBefore = data.sessionVersion(u.userId());

    client.refresh(first.refreshToken())
        .andExpect(status().isUnauthorized())
        .andExpect(jsonPath("$.code").value("invalid_refresh_token"));

    assertThat(data.session(sid(first)).get("revoked_at")).isNotNull();
    assertThat(data.sessionVersion(u.userId())).isEqualTo(svBefore + 1);
    assertThat(data.revocationReasons(u.userId())).containsExactly("refresh_reuse");
    assertThat(data.auditOfRequest(client.lastRequestId()))
        .contains("auth.refresh.reuse_detected/DENIED/ANONYMOUS", "auth.sessions.revoked/SUCCESS/SYSTEM");
    client.refresh(second.refreshToken())
        .andExpect(status().isUnauthorized())
        .andExpect(jsonPath("$.code").value("invalid_refresh_token"));
    poller.poll();
    client.me(second.bearer()).andExpect(status().isUnauthorized())
        .andExpect(jsonPath("$.code").value("token_revoked"));
  }

  @Test
  void anUnknownRefreshTokenIs401AndAudited() throws Exception {
    client.refresh("not-a-real-refresh-token")
        .andExpect(status().isUnauthorized())
        .andExpect(jsonPath("$.code").value("invalid_refresh_token"));

    assertThat(data.auditOfRequest(client.lastRequestId())).containsExactly("auth.refresh.failed/FAILURE/ANONYMOUS");
  }

  @Test
  void anIdleSessionCannotBeRefreshed() throws Exception {
    AuthClient.Tokens tokens = client.loginOk(u.email(), u.password());
    jdbc.sql("UPDATE user_session SET last_seen_at = now() - interval '31 minutes' WHERE id = :id")
        .param("id", sid(tokens)).update();

    client.refresh(tokens.refreshToken())
        .andExpect(status().isUnauthorized())
        .andExpect(jsonPath("$.code").value("invalid_refresh_token"));
  }

  @Test
  void anExpiredSessionCannotBeRefreshed() throws Exception {
    AuthClient.Tokens tokens = client.loginOk(u.email(), u.password());
    jdbc.sql("UPDATE user_session SET expires_at = now() - interval '1 second' WHERE id = :id")
        .param("id", sid(tokens)).update();

    client.refresh(tokens.refreshToken())
        .andExpect(status().isUnauthorized())
        .andExpect(jsonPath("$.code").value("invalid_refresh_token"));
  }

  @ParameterizedTest
  @ValueSource(strings = {"user_inactive", "account_inactive", "tenant_inactive", "membership_inactive"})
  void refreshRechecksStatusesAndRevokesTheSession(String reason) throws Exception {
    AuthClient.Tokens tokens = client.loginOk(u.email(), u.password());
    deactivate(reason);

    client.refresh(tokens.refreshToken())
        .andExpect(status().isUnauthorized())
        .andExpect(jsonPath("$.code").value("session_invalid"));

    assertThat(data.session(sid(tokens)).get("revoked_at")).isNotNull();
    assertThat(data.auditRows(client.lastRequestId(), "auth.session.invalidated")).singleElement()
        .satisfies(row -> assertThat((String) row.get("metadata")).contains(reason));
  }

  @Test
  void refreshReResolvesPermissionsAndReadsTheCurrentSessionVersion() throws Exception {
    AuthClient.Tokens tokens = client.loginOk(u.email(), u.password());
    String perm = data.grantTenantPermission(u.userId(), u.tenantId());
    jdbc.sql("UPDATE app_user SET session_version = session_version + 3 WHERE id = :id").param("id", u.userId())
        .update();

    Jwt refreshed = jwt(client.tokens(client.refresh(tokens.refreshToken()).andReturn()));

    assertThat(refreshed.getClaimAsStringList(Claims.PERMISSIONS)).containsExactly(perm);
    assertThat(((Number) refreshed.getClaim(Claims.SESSION_VERSION)).intValue()).isEqualTo(4);
  }

  @Test
  void switchTenantMovesTheSessionAndReturnsNewTokens() throws Exception {
    UUID second = data.fx.tenant(u.accountId());
    data.fx.membership(u.userId(), second, MembershipStatus.ACTIVE);
    String perm = data.grantTenantPermission(u.userId(), second);
    AuthClient.Tokens tokens = client.loginOk(u.email(), u.password());

    AuthClient.Tokens switched = client.tokens(client.switchTenant(tokens.bearer(), second)
        .andExpect(status().isOk()).andExpect(jsonPath("$.activeTenantId").value(second.toString())).andReturn());

    Jwt jwt = jwt(switched);
    assertThat(jwt.getClaimAsString(Claims.TENANT)).isEqualTo(second.toString());
    assertThat(jwt.getClaimAsStringList(Claims.PERMISSIONS)).containsExactly(perm);
    assertThat(sid(switched)).isEqualTo(sid(tokens));
    assertThat(data.session(sid(tokens)).get("active_tenant_id")).isEqualTo(second);
    assertThat(data.auditRows(client.lastRequestId(), "auth.tenant.switched")).singleElement().satisfies(row -> {
      assertThat(row).containsEntry("outcome", "SUCCESS").containsEntry("tenant_id", second)
          .containsEntry("actor_user_id", u.userId());
      assertThat((String) row.get("metadata")).contains(u.tenantId().toString());
    });
    // the refresh token returned by the switch continues the session in the new tenant
    client.refresh(switched.refreshToken()).andExpect(status().isOk())
        .andExpect(jsonPath("$.activeTenantId").value(second.toString()));
  }

  @Test
  void switchTenantRequiresAnActiveMembershipInAnActiveTenantOfTheAccount() throws Exception {
    UUID noMembership = data.fx.tenant(u.accountId());
    UUID suspendedMembership = data.fx.tenant(u.accountId());
    data.fx.membership(u.userId(), suspendedMembership, MembershipStatus.SUSPENDED);
    UUID suspendedTenant = data.fx.tenant(u.accountId(), TenantStatus.SUSPENDED);
    data.fx.membership(u.userId(), suspendedTenant, MembershipStatus.ACTIVE);
    UUID otherAccountTenant = data.fx.tenant(data.fx.account());
    AuthClient.Tokens tokens = client.loginOk(u.email(), u.password());

    for (UUID target : List.of(noMembership, suspendedMembership, suspendedTenant, otherAccountTenant)) {
      client.switchTenant(tokens.bearer(), target)
          .andExpect(status().isForbidden())
          .andExpect(jsonPath("$.code").value("tenant_not_accessible"));
      assertThat(data.auditOfRequest(client.lastRequestId())).containsExactly("auth.tenant.switched/DENIED/USER");
    }
    assertThat(data.session(sid(tokens))).containsEntry("active_tenant_id", u.tenantId());
    assertThat(data.session(sid(tokens)).get("revoked_at")).isNull();
  }

  @Test
  void switchTenantRevokesTheSessionWhenTheAccountIsNoLongerActive() throws Exception {
    UUID second = data.fx.tenant(u.accountId());
    data.fx.membership(u.userId(), second, MembershipStatus.ACTIVE);
    AuthClient.Tokens tokens = client.loginOk(u.email(), u.password());
    data.fx.accountStatus(u.accountId(), AccountStatus.SUSPENDED);

    client.switchTenant(tokens.bearer(), second)
        .andExpect(status().isUnauthorized())
        .andExpect(jsonPath("$.code").value("session_invalid"));

    assertThat(data.session(sid(tokens)).get("revoked_at")).isNotNull();
  }

  @Test
  void switchTenantNeedsAnAccessToken() throws Exception {
    client.switchTenant(null, u.tenantId()).andExpect(status().isUnauthorized());
  }

  @Test
  void logoutRevokesTheSessionAndTheNextRequestIs401() throws Exception {
    AuthClient.Tokens tokens = client.loginOk(u.email(), u.password());
    client.me(tokens.bearer()).andExpect(status().isOk());

    client.logout(tokens.bearer()).andExpect(status().isNoContent());

    assertThat(data.session(sid(tokens)).get("revoked_at")).isNotNull();
    assertThat(data.revocationReasons(u.userId())).containsExactly("logout");
    assertThat(data.auditOfRequest(client.lastRequestId()))
        .containsExactly("auth.logout/SUCCESS/USER", "auth.sessions.revoked/SUCCESS/USER");
    poller.poll();
    client.me(tokens.bearer()).andExpect(status().isUnauthorized());
    client.refresh(tokens.refreshToken()).andExpect(status().isUnauthorized())
        .andExpect(jsonPath("$.code").value("invalid_refresh_token"));
  }

  @Test
  void logoutAllRevokesEverySessionOfTheUser() throws Exception {
    AuthClient.Tokens one = client.loginOk(u.email(), u.password());
    AuthClient.Tokens two = client.loginOk(u.email(), u.password());

    client.logoutAll(one.bearer()).andExpect(status().isNoContent());

    assertThat(data.sessionsOf(u.userId())).hasSize(2).allSatisfy(s -> assertThat(s.get("revoked_at")).isNotNull());
    assertThat(data.revocationReasons(u.userId())).containsExactly("logout_all");
    assertThat(data.auditRows(client.lastRequestId(), "auth.logout_all")).singleElement()
        .satisfies(row -> assertThat((String) row.get("metadata")).contains("\"sessions_revoked\": 2"));
    poller.poll();
    client.me(two.bearer()).andExpect(status().isUnauthorized());
    client.refresh(two.refreshToken()).andExpect(status().isUnauthorized());
  }

  private void deactivate(String reason) {
    switch (reason) {
      case "user_inactive" -> jdbc.sql("UPDATE app_user SET status = 'DISABLED' WHERE id = :id")
          .param("id", u.userId()).update();
      case "account_inactive" -> data.fx.accountStatus(u.accountId(), AccountStatus.SUSPENDED);
      case "tenant_inactive" -> data.fx.tenantStatus(u.tenantId(), TenantStatus.SUSPENDED);
      default -> data.fx.membership(u.userId(), u.tenantId(), MembershipStatus.SUSPENDED);
    }
  }

  private Jwt jwt(AuthClient.Tokens tokens) {
    return jwtDecoder.decode(tokens.accessToken());
  }

  private UUID sid(AuthClient.Tokens tokens) {
    return UUID.fromString(jwt(tokens).getClaimAsString(Claims.SESSION));
  }
}
