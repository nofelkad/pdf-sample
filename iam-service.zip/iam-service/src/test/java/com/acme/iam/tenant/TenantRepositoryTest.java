package com.acme.iam.tenant;

import static org.assertj.core.api.Assertions.assertThat;

import com.acme.iam.common.Ids;
import com.acme.iam.common.test.Fixtures;
import com.acme.iam.common.test.JdbcSliceTest;
import com.acme.iam.common.test.PostgresTestBase;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.simple.JdbcClient;

/** P1-3.1: Tenant (+TenantProduct) round trip. */
@JdbcSliceTest
class TenantRepositoryTest extends PostgresTestBase {

  @Autowired TenantRepository tenants;
  @Autowired JdbcClient jdbc;

  @Test
  void roundTripsTenantWithProducts() {
    Fixtures fx = new Fixtures(jdbc);
    UUID account = fx.account();
    UUID billing = fx.product();
    UUID crm = fx.product();
    String slug = "eu-" + Ids.newId();

    Tenant saved = tenants.save(Tenant.create(account, "EU", slug)
        .withSettings(Map.of("locale", "de-DE"))
        .withProducts(Set.of(new TenantProduct(billing, true), new TenantProduct(crm, false))));
    assertThat(saved.version()).isZero();

    Tenant loaded = tenants.findById(saved.id()).orElseThrow();
    assertThat(loaded.account()).isEqualTo(account);
    assertThat(loaded.name()).isEqualTo("EU");
    assertThat(loaded.slug()).isEqualTo(slug);
    assertThat(loaded.status()).isEqualTo(TenantStatus.ACTIVE);
    assertThat(loaded.settings()).containsEntry("locale", "de-DE");
    assertThat(loaded.products()).containsExactlyInAnyOrder(new TenantProduct(billing, true),
        new TenantProduct(crm, false));

    tenants.save(loaded.withStatus(TenantStatus.SUSPENDED).withProducts(Set.of(new TenantProduct(billing, false))));
    Tenant reloaded = tenants.findById(saved.id()).orElseThrow();
    assertThat(reloaded.status()).isEqualTo(TenantStatus.SUSPENDED);
    assertThat(reloaded.products()).containsExactly(new TenantProduct(billing, false));
    assertThat(reloaded.version()).isEqualTo(1);
  }

  @Test
  void accountScopedLookups() {
    Fixtures fx = new Fixtures(jdbc);
    UUID account = fx.account();
    UUID other = fx.account();
    UUID t1 = fx.tenant(account);
    UUID t2 = fx.tenant(account);
    fx.tenant(other);

    assertThat(tenants.findAllByAccount(account)).extracting(Tenant::id).containsExactly(t1, t2);
    assertThat(tenants.findByIdInAccount(t1, account)).isPresent();
    assertThat(tenants.findByIdInAccount(t1, other)).isEmpty();
  }
}
