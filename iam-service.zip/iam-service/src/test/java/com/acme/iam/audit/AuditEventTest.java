package com.acme.iam.audit;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

import java.time.Instant;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import org.junit.jupiter.api.Test;

/** Task 9 (deferred fix E5): an {@link AuditEvent} is a value; its maps cannot be changed after construction. */
class AuditEventTest {

  @Test
  void mapsAreUnmodifiableViews() {
    AuditEvent event = AuditEvent.builder("x.y")
        .metadata("k", "v")
        .before(Map.of("a", 1))
        .after(Map.of("b", 2))
        .build();

    assertThatThrownBy(() -> event.metadata().put("k2", "v2")).isInstanceOf(UnsupportedOperationException.class);
    assertThatThrownBy(() -> event.before().put("a", 3)).isInstanceOf(UnsupportedOperationException.class);
    assertThatThrownBy(() -> event.after().remove("b")).isInstanceOf(UnsupportedOperationException.class);
  }

  @Test
  void canonicalConstructorCopiesItsMapsAndKeepsNullValues() {
    Map<String, Object> metadata = new HashMap<>();
    metadata.put("reason", null);
    metadata.put("path", "/api/x");
    AuditEvent event = new AuditEvent(UUID.randomUUID(), Instant.now(), null, null, "IAM", null,
        AuditEvent.ActorType.SYSTEM, null, null, null, null, "x.y", null, null, AuditEvent.Outcome.SUCCESS, null, null,
        metadata);

    metadata.put("path", "/changed");
    assertThat(event.metadata()).containsEntry("path", "/api/x").containsEntry("reason", null);
    assertThat(event.before()).isNull();
    assertThatThrownBy(() -> event.metadata().clear()).isInstanceOf(UnsupportedOperationException.class);
  }
}
