package com.acme.iam.user;

import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.http.HttpHeaders.AUTHORIZATION;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import com.acme.iam.common.Ids;
import com.acme.iam.common.test.CapturingNotificationAdapter;
import com.acme.iam.common.test.Fixtures;
import com.acme.iam.common.test.IntegrationTest;
import com.acme.iam.common.test.OrgTestData;
import com.acme.iam.common.test.PostgresTestBase;
import com.acme.iam.common.test.TestTokens;
import java.util.UUID;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.context.annotation.Import;
import org.springframework.http.MediaType;
import org.springframework.jdbc.core.simple.JdbcClient;
import org.springframework.test.web.servlet.MockMvc;

/** R46: with {@code iam.notification.expose-activation-link=false} links stay email-only and nothing is audited. */
@IntegrationTest(properties = "iam.notification.expose-activation-link=false")
@AutoConfigureMockMvc
@Import(CapturingNotificationAdapter.Config.class)
class ActivationLinkDisabledIT extends PostgresTestBase {

  @Autowired MockMvc mvc;
  @Autowired TestTokens tokens;
  @Autowired JdbcClient jdbc;
  @Autowired CapturingNotificationAdapter mailbox;

  @Test
  void inviteReturnsNoActivationButStillSendsTheEmail() throws Exception {
    mailbox.clear();
    OrgTestData org = new OrgTestData(jdbc);
    Fixtures.Scenario s = org.fixtures().scenario();
    UUID admin = org.accountAdmin(s.accountId(), s.tenantId());
    String bearer = org.adminBearer(tokens, admin, s.accountId(), s.tenantId());
    String email = "off-" + Ids.newId() + "@example.test";

    String body = mvc.perform(post("/api/tenants/{t}/users", s.tenantId()).header(AUTHORIZATION, bearer)
            .contentType(MediaType.APPLICATION_JSON).content("{\"email\":\"%s\"}".formatted(email)))
        .andExpect(status().isCreated())
        .andExpect(jsonPath("$.activation").doesNotExist())
        .andReturn().getResponse().getContentAsString();

    assertThat(body).doesNotContain("token=");
    assertThat(mailbox.lastInvitationToken(email)).isNotBlank();
    UUID user = org.userByEmail(s.accountId(), email).orElseThrow();
    assertThat(jdbc.sql("SELECT count(*) FROM audit_event WHERE action = 'iam.invitation.link_issued' "
            + "AND target_id = :u").param("u", user.toString()).query(Long.class).single()).isZero();
  }
}
