package com.acme.iam.auth;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

import com.acme.iam.common.test.Fixtures;
import com.acme.iam.common.test.JdbcSliceTest;
import com.acme.iam.common.test.PostgresTestBase;
import java.security.SecureRandom;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.UUID;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Import;
import org.springframework.dao.OptimisticLockingFailureException;
import org.springframework.jdbc.core.simple.JdbcClient;

/** P1-3.2: UserSession and PasswordHistory round trips. */
@JdbcSliceTest
@Import(PasswordHistoryRepository.class)
class SessionAndPasswordHistoryRepositoryTest extends PostgresTestBase {

  @Autowired UserSessionRepository sessions;
  @Autowired PasswordHistoryRepository history;
  @Autowired JdbcClient jdbc;

  private final Instant now = Instant.now().truncatedTo(ChronoUnit.MICROS);

  @Test
  void roundTripsSessionAndRotation() {
    Fixtures fx = new Fixtures(jdbc);
    Fixtures.Scenario s = fx.scenario();
    UUID otherTenant = fx.tenant(s.accountId());
    byte[] first = random();
    byte[] second = random();

    UserSession saved = sessions.save(UserSession.open(s.userId(), s.tenantId(), first, "203.0.113.7", "JUnit",
        now, now.plus(12, ChronoUnit.HOURS)));
    assertThat(saved.version()).isZero();

    UserSession loaded = sessions.findByRefreshHash(first).orElseThrow();
    assertThat(loaded.id()).isEqualTo(saved.id());
    assertThat(loaded.user()).isEqualTo(s.userId());
    assertThat(loaded.activeTenant()).isEqualTo(s.tenantId());
    assertThat(loaded.ip()).isEqualTo("203.0.113.7");
    assertThat(loaded.userAgent()).isEqualTo("JUnit");
    assertThat(loaded.lastSeenAt()).isEqualTo(now);
    assertThat(loaded.expiresAt()).isEqualTo(now.plus(12, ChronoUnit.HOURS));
    assertThat(loaded.isActive(now)).isTrue();

    sessions.save(loaded.rotate(second, now.plusSeconds(60)).withActiveTenant(otherTenant));
    UserSession rotated = sessions.findByRefreshHash(second).orElseThrow();
    assertThat(rotated.prevRefreshHash()).isEqualTo(first);
    assertThat(rotated.activeTenant()).isEqualTo(otherTenant);
    assertThat(sessions.findByPrevRefreshHash(first)).map(UserSession::id).contains(saved.id());
    assertThat(sessions.findUnrevokedByUser(s.userId())).hasSize(1);

    assertThatThrownBy(() -> sessions.save(loaded.revoke(now))).as("stale copy")
        .isInstanceOf(OptimisticLockingFailureException.class);
    sessions.save(rotated.revoke(now));
    assertThat(sessions.findUnrevokedByUser(s.userId())).isEmpty();
  }

  @Test
  void passwordHistoryKeepsNewestEntries() {
    Fixtures fx = new Fixtures(jdbc);
    UUID user = fx.scenario().userId();
    for (int i = 0; i < 5; i++) {
      history.insert(new PasswordHistory(user, "hash-" + i, now.plusSeconds(i)));
    }

    assertThat(history.findRecent(user, 3)).extracting(PasswordHistory::passwordHash)
        .containsExactly("hash-4", "hash-3", "hash-2");
    assertThat(history.findRecent(user, 1).getFirst().changedAt()).isEqualTo(now.plusSeconds(4));

    assertThat(history.trim(user, 2)).isEqualTo(3);
    assertThat(history.findRecent(user, 10)).extracting(PasswordHistory::passwordHash)
        .containsExactly("hash-4", "hash-3");
  }

  private static byte[] random() {
    byte[] bytes = new byte[32];
    new SecureRandom().nextBytes(bytes);
    return bytes;
  }
}
