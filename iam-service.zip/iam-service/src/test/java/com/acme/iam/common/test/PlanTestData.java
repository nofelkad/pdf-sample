package com.acme.iam.common.test;

import java.util.Map;
import java.util.UUID;
import org.flywaydb.core.Flyway;
import org.springframework.jdbc.core.simple.JdbcClient;

/**
 * Bulk data for query-plan tests ({@code *PlanIT}). Not a Spring test helper: it talks to the singleton container as
 * the superuser, so callers must extend {@link PostgresTestBase} (which starts the container).
 *
 * <p>{@link #seedAccount()} creates, with triggers disabled ({@code session_replication_role = replica}: fast and no
 * audit rows), one ACTIVE account with a subscribed product enabled in 20 tenants, 20 product roles (10 permissions
 * each), 5 IAM roles (5 permissions each), 5,000 users with 2 memberships and 4 assignments each (2 TENANT, 1 ACCOUNT,
 * 1 expired), {@code created_at} spread one second apart. Committed, so {@link #analyze()} sees it; remove it with
 * {@link #delete(UUID)}.
 */
public final class PlanTestData {

  public static final int USERS_PER_ACCOUNT = 5_000;

  private final JdbcClient admin = JdbcClient.create(PostgresTestBase.adminDataSource());

  /** Runs the Flyway migrations (plan tests have no Spring context to do it). Idempotent. */
  public PlanTestData migrate() {
    Flyway.configure()
        .dataSource(PostgresTestBase.jdbcUrl(), PostgresTestBase.MIGRATOR_USER, PostgresTestBase.MIGRATOR_PASSWORD)
        .locations("classpath:db/migration")
        .load()
        .migrate();
    return this;
  }

  /** {@code VACUUM ANALYZE}: statistics plus a set visibility map, as autovacuum would leave a live database. */
  public void analyze() {
    admin.sql("VACUUM ANALYZE").update();
  }

  /** {@code EXPLAIN (ANALYZE, BUFFERS)} of {@code sql} with named parameters, as text. */
  public String explain(String sql, Map<String, ?> params) {
    JdbcClient.StatementSpec spec = admin.sql("EXPLAIN (ANALYZE, BUFFERS) " + sql);
    for (Map.Entry<String, ?> p : params.entrySet()) {
      spec = spec.param(p.getKey(), p.getValue());
    }
    return String.join("\n", spec.query(String.class).list());
  }

  public JdbcClient admin() {
    return admin;
  }

  /** A deterministic sample user of the account: {@code id}, {@code primary_tenant_id}. */
  public Map<String, Object> sampleUser(UUID accountId) {
    return admin.sql("SELECT id, primary_tenant_id FROM app_user WHERE account_id = :acc ORDER BY id OFFSET 1234 LIMIT 1")
        .param("acc", accountId).query().singleRow();
  }

  public UUID seedAccount() {
    UUID acc = UUID.randomUUID();
    admin.sql("""
        DO $$
        DECLARE
          acc uuid := '%s';
          prod uuid;
          tenants uuid[];
          roles uuid[];
          iam_roles uuid[];
          perm uuid;
          r uuid;
          u uuid;
          i int; j int;
        BEGIN
          SET LOCAL session_replication_role = replica;
          INSERT INTO account (id, name, slug, status, version) VALUES (acc, 'Plan ' || acc, 'plan-' || acc, 'ACTIVE', 0);
          prod := gen_random_uuid();
          INSERT INTO product (id, code, name, version) VALUES (prod, 'PLAN_' || replace(acc::text, '-', ''), 'Plan', 0);
          INSERT INTO account_product (account, product_id, status, starts_at) VALUES (acc, prod, 'ACTIVE', current_date);
          FOR i IN 1..20 LOOP
            tenants[i] := gen_random_uuid();
            INSERT INTO tenant (id, account_id, name, slug, status, version)
              VALUES (tenants[i], acc, 'T' || i, 't-' || i, 'ACTIVE', 0);
            INSERT INTO tenant_product (tenant, product_id, enabled) VALUES (tenants[i], prod, true);
          END LOOP;
          FOR i IN 1..20 LOOP
            r := gen_random_uuid(); roles[i] := r;
            INSERT INTO role (id, product_id, name, type, account_id, version) VALUES (r, prod, 'R' || i, 'CUSTOM', acc, 0);
            FOR j IN 1..10 LOOP
              perm := gen_random_uuid();
              INSERT INTO permission (id, product_id, code, kind, description, version)
                VALUES (perm, prod, 'plan.' || acc || '.' || i || '.' || j, 'FEATURE', 'x', 0);
              INSERT INTO role_permission (role, permission_id) VALUES (r, perm);
            END LOOP;
          END LOOP;
          FOR i IN 1..5 LOOP
            r := gen_random_uuid(); iam_roles[i] := r;
            INSERT INTO role (id, product_id, name, type, account_id, version)
              VALUES (r, '00000000-0000-7000-8000-000000000001', 'IAM R' || i, 'CUSTOM', acc, 0);
            FOR j IN 1..5 LOOP
              perm := gen_random_uuid();
              INSERT INTO permission (id, product_id, code, kind, description, version)
                VALUES (perm, '00000000-0000-7000-8000-000000000001', 'planiam.' || acc || '.' || i || '.' || j,
                        'FEATURE', 'x', 0);
              INSERT INTO role_permission (role, permission_id) VALUES (r, perm);
            END LOOP;
          END LOOP;
          FOR i IN 1..%d LOOP
            u := gen_random_uuid();
            INSERT INTO app_user (id, account_id, email, status, primary_tenant_id, version, created_at)
              VALUES (u, acc, 'u' || i || '@' || acc || '.test',
                      CASE WHEN i %% 50 = 0 THEN 'DISABLED' ELSE 'ACTIVE' END,
                      tenants[1 + i %% 20], 0, now() - make_interval(secs => i));
            INSERT INTO user_tenant_membership (app_user, tenant_id) VALUES (u, tenants[1 + i %% 20]);
            INSERT INTO user_tenant_membership (app_user, tenant_id) VALUES (u, tenants[1 + (i + 3) %% 20]);
            INSERT INTO role_assignment (id, user_id, role_id, scope_type, scope_id, version) VALUES
              (gen_random_uuid(), u, roles[1 + i %% 20], 'TENANT', tenants[1 + i %% 20], 0),
              (gen_random_uuid(), u, roles[1 + (i + 7) %% 20], 'TENANT', tenants[1 + (i + 3) %% 20], 0),
              (gen_random_uuid(), u, iam_roles[1 + i %% 5], 'ACCOUNT', acc, 0);
            INSERT INTO role_assignment (id, user_id, role_id, scope_type, scope_id, expires_at, version) VALUES
              (gen_random_uuid(), u, roles[1 + (i + 11) %% 20], 'TENANT', tenants[1 + i %% 20],
               now() - interval '1 day', 0);
          END LOOP;
        END $$""".formatted(acc, USERS_PER_ACCOUNT)).update();
    return acc;
  }

  /** Removes everything {@link #seedAccount()} created for the account (triggers disabled). */
  public void delete(UUID accountId) {
    admin.sql("""
        DO $$
        DECLARE acc uuid := '%s';
        BEGIN
          SET LOCAL session_replication_role = replica;
          DELETE FROM role_assignment WHERE user_id IN (SELECT id FROM app_user WHERE account_id = acc);
          DELETE FROM user_tenant_membership WHERE app_user IN (SELECT id FROM app_user WHERE account_id = acc);
          DELETE FROM app_user WHERE account_id = acc;
          DELETE FROM role_permission WHERE role IN (SELECT id FROM role WHERE account_id = acc);
          DELETE FROM permission WHERE code LIKE 'plan.' || acc || '.%%' OR code LIKE 'planiam.' || acc || '.%%';
          DELETE FROM role WHERE account_id = acc;
          DELETE FROM tenant_product WHERE tenant IN (SELECT id FROM tenant WHERE account_id = acc);
          DELETE FROM tenant WHERE account_id = acc;
          DELETE FROM account_product WHERE account = acc;
          DELETE FROM product WHERE code = 'PLAN_' || replace(acc::text, '-', '');
          DELETE FROM account WHERE id = acc;
        END $$""".formatted(accountId)).update();
  }
}
