package com.acme.iam.audit;

import static org.assertj.core.api.Assertions.assertThat;

import com.acme.iam.common.Ids;
import com.acme.iam.common.test.IntegrationTest;
import com.acme.iam.common.test.PostgresTestBase;
import com.acme.iam.common.test.TestTokens;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.time.Instant;
import org.junit.jupiter.api.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.boot.test.web.server.LocalServerPort;
import org.springframework.jdbc.core.simple.JdbcClient;

/**
 * P1-9.4 throughput: 10 batches of 500 events over real HTTP (loopback, JWT validation, JSON, redaction, insert) into
 * a Postgres container on the same machine, after 3 warm-up batches. The target is 5,000 events/s on one instance; the
 * measured figure is logged ({@code INGEST THROUGHPUT ...}) and the assertion is only a sanity floor, because a CI
 * machine's speed is not under the test's control.
 */
@IntegrationTest(webEnvironment = WebEnvironment.RANDOM_PORT)
class AuditIngestThroughputIT extends PostgresTestBase {

  private static final Logger log = LoggerFactory.getLogger(AuditIngestThroughputIT.class);
  private static final int BATCH = 500;
  private static final int MEASURED_BATCHES = 10;
  private static final int WARMUP_BATCHES = 3;

  @LocalServerPort int port;
  @Autowired TestTokens tokens;
  @Autowired ObjectMapper json;
  @Autowired JdbcClient jdbc;

  @Test
  void tenBatchesOfFiveHundredEvents() throws Exception {
    HttpClient http = HttpClient.newHttpClient();
    String bearer = TestTokens.bearer(tokens.appToken("perf-svc", "PERF"));
    String marker = "perf." + Ids.newId().toString().substring(24);

    for (int i = 0; i < WARMUP_BATCHES; i++) {
      post(http, bearer, batch(marker + ".warm"));
    }
    byte[][] bodies = new byte[MEASURED_BATCHES][];
    for (int i = 0; i < MEASURED_BATCHES; i++) {
      bodies[i] = json.writeValueAsBytes(batch(marker));   // building the payload is not part of the measurement
    }

    long start = System.nanoTime();
    for (byte[] body : bodies) {
      JsonNode result = send(http, bearer, body);
      assertThat(result.get("accepted").asInt()).isEqualTo(BATCH);
    }
    double seconds = (System.nanoTime() - start) / 1e9;
    double perSecond = MEASURED_BATCHES * BATCH / seconds;
    log.info("INGEST THROUGHPUT {} events in {} s = {} events/s (batch {}, {} cores)",
        MEASURED_BATCHES * BATCH, "%.2f".formatted(seconds), Math.round(perSecond), BATCH,
        Runtime.getRuntime().availableProcessors());

    assertThat(jdbc.sql("SELECT count(*) FROM audit_event WHERE action = :a").param("a", marker)
        .query(Long.class).single()).isEqualTo(MEASURED_BATCHES * BATCH);
    assertThat(perSecond).as("events/s (target 5000 on a dedicated instance)").isGreaterThan(1000);
  }

  private ObjectNode batch(String action) {
    ArrayNode events = json.createArrayNode();
    Instant now = Instant.now();
    for (int i = 0; i < BATCH; i++) {
      ObjectNode e = events.addObject();
      e.put("eventId", Ids.newId().toString());
      e.put("occurredAt", now.toString());
      e.put("accountId", Ids.newId().toString());
      e.put("tenantId", Ids.newId().toString());
      e.put("actorUserId", Ids.newId().toString());
      e.put("actorType", "USER");
      e.put("actorIp", "198.51.100." + (i % 250 + 1));
      e.put("userAgent", "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 Chrome/126.0 Safari/537.36");
      e.put("sessionId", Ids.newId().toString());
      e.put("requestId", "req-" + i);
      e.put("action", action);
      e.put("targetType", "invoice");
      e.put("targetId", "INV-" + i);
      e.put("outcome", "SUCCESS");
      e.putObject("before").put("status", "DRAFT").put("amount", 100 + i);
      e.putObject("after").put("status", "APPROVED").put("amount", 100 + i);
      e.putObject("metadata").put("channel", "web").put("apiToken", "t-" + i).put("note", "approved by finance");
    }
    ObjectNode body = json.createObjectNode();
    body.set("events", events);
    return body;
  }

  private void post(HttpClient http, String bearer, ObjectNode body) throws Exception {
    send(http, bearer, json.writeValueAsBytes(body));
  }

  private JsonNode send(HttpClient http, String bearer, byte[] body) throws Exception {
    HttpResponse<String> response = http.send(HttpRequest.newBuilder(URI.create("http://localhost:" + port + "/internal/audit/events"))
        .header("Authorization", bearer).header("Content-Type", "application/json")
        .timeout(Duration.ofSeconds(60)).POST(HttpRequest.BodyPublishers.ofByteArray(body)).build(),
        HttpResponse.BodyHandlers.ofString());
    assertThat(response.statusCode()).as(response.body()).isEqualTo(200);
    return json.readTree(response.body());
  }
}
