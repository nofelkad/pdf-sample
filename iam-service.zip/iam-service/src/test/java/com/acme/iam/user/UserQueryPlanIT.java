package com.acme.iam.user;

import static org.assertj.core.api.Assertions.assertThat;

import com.acme.iam.common.paging.KeysetPage;
import com.acme.iam.common.test.PlanTestData;
import com.acme.iam.common.test.PostgresTestBase;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.core.simple.JdbcClient;

/** P1-3.4 index review of the user list: no sort, no sequential scan of {@code app_user}. Logs the plans. */
class UserQueryPlanIT extends PostgresTestBase {

  private static final Logger log = LoggerFactory.getLogger(UserQueryPlanIT.class);

  static PlanTestData data;
  static UUID account;
  static UUID noiseAccount;

  @BeforeAll
  static void seed() {
    data = new PlanTestData().migrate();
    account = data.seedAccount();
    noiseAccount = data.seedAccount();
    data.analyze();
  }

  @AfterAll
  static void cleanUp() {
    data.delete(account);
    data.delete(noiseAccount);
  }

  @Test
  void firstPageWalksTheAccountIndexInOrder() {
    String plan = explain(UserListFilter.NONE, false);
    log.info("EXPLAIN user list (first page):\n{}", plan);
    assertThat(plan).contains("app_user_account_created_idx").doesNotContain("Seq Scan on app_user")
        .doesNotContain("Sort Key");
  }

  @Test
  void laterPageSeeksPastTheCursor() {
    String plan = explain(UserListFilter.NONE, true);
    log.info("EXPLAIN user list (cursor page):\n{}", plan);
    assertThat(plan).contains("app_user_account_created_idx").doesNotContain("Seq Scan on app_user")
        .doesNotContain("Sort Key");
  }

  @Test
  void statusFilterUsesTheStatusIndex() {
    String plan = explain(new UserListFilter(null, UserStatus.DISABLED, null), false);
    log.info("EXPLAIN user list (status):\n{}", plan);
    assertThat(plan).contains("app_user_account_status_created_idx").doesNotContain("Seq Scan on app_user");
  }

  @Test
  void tenantAndRoleFiltersProbeKeys() {
    Map<String, Object> held = data.admin().sql("""
            SELECT ra.role_id, ra.scope_id FROM role_assignment ra JOIN app_user u ON u.id = ra.user_id
            WHERE u.account_id = :acc AND ra.scope_type = 'TENANT' AND ra.expires_at IS NULL
            ORDER BY ra.id LIMIT 1""")
        .param("acc", account).query().singleRow();
    String plan = explain(new UserListFilter((UUID) held.get("scope_id"), null, (UUID) held.get("role_id")), false);
    log.info("EXPLAIN user list (tenant + role):\n{}", plan);
    assertThat(plan).doesNotContain("Seq Scan on app_user").doesNotContain("Seq Scan on role_assignment")
        .doesNotContain("Seq Scan on user_tenant_membership");
  }

  /**
   * The planner either drives from the tenant's memberships ({@code utm_tenant_idx}, then a top-N sort; small tenants)
   * or walks {@code app_user_account_created_idx} probing the membership key (large tenants). At this data size it may
   * still hash-join against a scan of {@code app_user}; only the membership access is asserted here, the 1M-user case
   * is covered by the Task 10 load test.
   */
  @Test
  void tenantFilterReachesMembershipsThroughAnIndex() {
    UUID tenant = (UUID) data.sampleUser(account).get("primary_tenant_id");
    String plan = explain(new UserListFilter(tenant, null, null), false);
    log.info("EXPLAIN user list (tenant):\n{}", plan);
    assertThat(plan).doesNotContain("Seq Scan on user_tenant_membership")
        .containsAnyOf("utm_tenant_idx", "user_tenant_membership_pkey");
  }

  @Test
  void serviceReturnsPagesOnTheSeededData() {
    UserQueryService service = new UserQueryService(JdbcClient.create(appDataSource()));
    KeysetPage<UserSummary> first = service.list(account, UserListFilter.NONE, null, 200);
    KeysetPage<UserSummary> second = service.list(account, UserListFilter.NONE, first.nextCursor(), 200);
    assertThat(first.items()).hasSize(200);
    assertThat(second.items()).hasSize(200);
    assertThat(second.items().getFirst().createdAt()).isBefore(first.items().getLast().createdAt());
  }

  private String explain(UserListFilter filter, boolean withCursor) {
    Map<String, Object> params = new HashMap<>();
    params.put("accountId", account);
    params.put("limit", 51);
    if (filter.status() != null) {
      params.put("status", filter.status().name());
    }
    if (filter.tenantId() != null) {
      params.put("tenantId", filter.tenantId());
    }
    if (filter.roleId() != null) {
      params.put("roleId", filter.roleId());
    }
    if (withCursor) {
      Map<String, Object> mid = data.admin().sql("""
              SELECT id, created_at FROM app_user WHERE account_id = :acc
              ORDER BY created_at DESC, id DESC OFFSET 2500 LIMIT 1""")
          .param("acc", account).query().singleRow();
      params.put("cursorAt", ((java.sql.Timestamp) mid.get("created_at")).toInstant()
          .atOffset(java.time.ZoneOffset.UTC));
      params.put("cursorId", mid.get("id"));
    }
    return data.explain(UserQueryService.sql(filter, withCursor), params);
  }
}
