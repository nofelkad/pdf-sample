package com.acme.iam.audit;

import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.http.HttpHeaders.AUTHORIZATION;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import com.acme.iam.common.Ids;
import com.acme.iam.common.RequestActor;
import com.acme.iam.common.security.SecurityTestEndpoints;
import com.acme.iam.common.test.IntegrationTest;
import com.acme.iam.common.test.PostgresTestBase;
import com.acme.iam.common.test.TestTokens;
import com.acme.iam.common.web.RequestIdFilter;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.util.Map;
import java.util.UUID;
import org.junit.jupiter.api.Test;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.context.annotation.Import;
import org.springframework.jdbc.core.simple.JdbcClient;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.transaction.support.TransactionTemplate;

/** Ruling R9: row changes made with an application token are attributed to {@code app:<clientId>}. */
@IntegrationTest
@AutoConfigureMockMvc
@Import(SecurityTestEndpoints.class)
class AuditSourceIT extends PostgresTestBase {

  @Autowired MockMvc mvc;
  @Autowired TestTokens tokens;
  @Autowired JdbcClient jdbc;
  @Autowired TransactionTemplate tx;
  @Autowired ObjectMapper json;

  @Test
  void appTokenWriteIsAttributedToTheClient() throws Exception {
    String requestId = "r9-app-" + Ids.newId();

    String body = mvc.perform(post(SecurityTestEndpoints.INTERNAL_WRITE)
            .header(RequestIdFilter.HEADER, requestId)
            .header(AUTHORIZATION, TestTokens.bearer(tokens.appToken("billing-svc", "BILLING"))))
        .andExpect(status().isOk())
        .andReturn().getResponse().getContentAsString();

    Map<String, Object> row = auditRow(requestId);
    assertThat(row)
        .containsEntry("action", "iam.product.insert")
        .containsEntry("target_id", json.readTree(body).get("id").asText())
        .containsEntry("source", "app:billing-svc")
        .containsEntry("client_id", "billing-svc")
        .containsEntry("actor_type", "SYSTEM");
    assertThat(row.get("actor_user_id")).isNull();
  }

  @Test
  void writeWithoutAppCallerKeepsSourceIamAndNoMetadata() {
    UUID id = Ids.newId();
    String requestId = "r9-system-" + Ids.newId();
    MDC.put(RequestActor.MDC_REQUEST_ID, requestId);
    try {
      tx.executeWithoutResult(s -> jdbc.sql("INSERT INTO product (id, code, name, version) VALUES (?, ?, 'P', 0)")
          .params(id, "U" + id.toString().replace("-", "").substring(20).toUpperCase()).update());
    } finally {
      MDC.remove(RequestActor.MDC_REQUEST_ID);
    }

    Map<String, Object> row = auditRow(requestId);
    assertThat(row).containsEntry("source", "IAM").containsEntry("actor_type", "SYSTEM");
    assertThat(row.get("metadata")).isNull();
  }

  private Map<String, Object> auditRow(String requestId) {
    return jdbc.sql("""
            SELECT action, target_id, source, actor_type, actor_user_id, metadata::text AS metadata,
                   metadata->>'client_id' AS client_id
            FROM audit_event WHERE request_id = :rid""")
        .param("rid", requestId).query().singleRow();
  }
}
