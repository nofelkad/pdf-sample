package com.acme.iam.audit;

import static org.assertj.core.api.Assertions.assertThat;

import com.acme.iam.common.paging.KeysetCursor;
import com.acme.iam.common.test.PlanTestData;
import com.acme.iam.common.test.PostgresTestBase;
import java.time.Instant;
import java.time.YearMonth;
import java.util.List;
import java.util.UUID;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * P1-9.5 index review: EXPLAIN (ANALYZE, BUFFERS) of the real search SQL ({@link AuditSearchSql}) on 400,000 generated
 * rows in four monthly partitions (Jan-Apr 2020, dropped afterwards because audit rows cannot be deleted), 40
 * accounts. Confirms partition pruning by the time window and index use; the plans are logged.
 */
class AuditSearchPlanIT extends PostgresTestBase {

  private static final Logger log = LoggerFactory.getLogger(AuditSearchPlanIT.class);
  private static final List<YearMonth> MONTHS =
      List.of(YearMonth.of(2020, 1), YearMonth.of(2020, 2), YearMonth.of(2020, 3), YearMonth.of(2020, 4));
  private static final int ROWS = 400_000;

  static PlanTestData data;
  static AuditTestPartitions ddl;
  static UUID account;
  static UUID tenant;
  static UUID actor;

  @BeforeAll
  static void seed() {
    data = new PlanTestData().migrate();
    ddl = new AuditTestPartitions();
    MONTHS.forEach(ddl::create);
    data.admin().sql("""
        INSERT INTO audit_event (event_id, occurred_at, account_id, tenant_id, source, actor_user_id, actor_type,
                                 action, target_type, target_id, outcome, metadata)
        SELECT gen_random_uuid(),
               timestamptz '2020-01-01 00:00:00+00' + interval '121 days' * random(),
               acc.id,
               md5(acc.id::text || ((g / 40) % 10))::uuid,
               'IAM',
               md5(acc.id::text || 'u' || ((g / 40) % 200))::uuid,
               'USER',
               (ARRAY['iam.role.update','iam.role_assignment.insert','iam.user.update','auth.login.success',
                      'auth.login.failed','invoice.approved'])[1 + (g / 40) % 6],
               (ARRAY['role','user','invoice','tenant'])[1 + (g / 40) % 4],
               'T-' || ((g / 40) % 5000),
               (ARRAY['SUCCESS','SUCCESS','SUCCESS','DENIED','FAILURE'])[1 + (g / 40) % 5],
               jsonb_build_object('n', g)
        FROM generate_series(1, {ROWS}) g
        CROSS JOIN LATERAL (SELECT md5('account-' || (g % 40))::uuid AS id) acc""".replace("{ROWS}", String.valueOf(ROWS))).update();
    data.analyze();
    account = data.admin().sql("SELECT md5('account-7')::uuid").query(UUID.class).single();
    tenant = data.admin().sql("SELECT md5(:a || '7')::uuid").param("a", account.toString()).query(UUID.class).single();
    actor = data.admin().sql("SELECT md5(:a || 'u' || '7')::uuid").param("a", account.toString()).query(UUID.class).single();
  }

  @AfterAll
  static void cleanUp() {
    MONTHS.forEach(ddl::drop);
  }

  @Test
  void sanityOfTheSeed() {
    assertThat(data.admin().sql("SELECT count(*) FROM audit_event WHERE account_id = :a").param("a", account)
        .query(Long.class).single()).isBetween(9_000L, 11_000L);
  }

  @Test
  void aThirtyDayWindowTouchesOnlyTheMonthsItOverlaps() {
    AuditSearchSql.Query q = AuditSearchSql.page(criteria(null, null, null, null, null, "2020-02-10T00:00:00Z",
        "2020-03-11T00:00:00Z", null));
    String plan = explain(q);
    log.info("EXPLAIN search, 30-day window over Feb-Mar 2020, account only:\n{}", plan);

    assertThat(plan).contains("audit_event_y2020m02", "audit_event_y2020m03");
    assertThat(plan).doesNotContain("audit_event_y2020m01", "audit_event_y2020m04");
    assertThat(plan).doesNotContain("Seq Scan");
    assertThat(plan).contains("account_id_occurred_at_idx");   // partition child of ae_account_time_idx
  }

  @Test
  void aSingleMonthWindowScansASinglePartition() {
    AuditSearchSql.Query q = AuditSearchSql.page(criteria(null, null, null, null, null, "2020-03-02T00:00:00Z",
        "2020-03-09T00:00:00Z", null));
    String plan = explain(q);
    log.info("EXPLAIN search, 7-day window inside March 2020:\n{}", plan);

    assertThat(plan).contains("audit_event_y2020m03");
    assertThat(plan).doesNotContain("y2020m01", "y2020m02", "y2020m04").doesNotContain("Seq Scan");
  }

  @Test
  void filtersByTenantActorAndActionStillUseIndexes() {
    AuditSearchSql.Query byTenant = AuditSearchSql.page(criteria(tenant, null, null, null, null,
        "2020-02-01T00:00:00Z", "2020-04-01T00:00:00Z", null));
    String tenantPlan = explain(byTenant);
    log.info("EXPLAIN search with tenantId:\n{}", tenantPlan);
    assertThat(tenantPlan).doesNotContain("Seq Scan");

    AuditSearchSql.Query byActor = AuditSearchSql.page(criteria(null, actor, null, null, null,
        "2020-02-01T00:00:00Z", "2020-04-01T00:00:00Z", null));
    String actorPlan = explain(byActor);
    log.info("EXPLAIN search with actorUserId:\n{}", actorPlan);
    assertThat(actorPlan).doesNotContain("Seq Scan").contains("actor_user_id_occurred_at_idx");

    AuditSearchSql.Query byAction = AuditSearchSql.page(criteria(null, null, "iam.role.", null, null,
        "2020-02-01T00:00:00Z", "2020-04-01T00:00:00Z", null));
    String actionPlan = explain(byAction);
    log.info("EXPLAIN search with action prefix:\n{}", actionPlan);
    assertThat(actionPlan).doesNotContain("Seq Scan").contains("account_id_occurred_at_idx");
  }

  @Test
  void theSecondPageUsesTheKeysetConditionInsideTheIndexScan() {
    KeysetCursor cursor = new KeysetCursor(Instant.parse("2020-03-05T12:00:00Z"), UUID.randomUUID());
    AuditSearchSql.Query q = AuditSearchSql.page(criteria(null, null, null, null, null, "2020-02-10T00:00:00Z",
        "2020-03-11T00:00:00Z", cursor));
    String plan = explain(q);
    log.info("EXPLAIN search, page 2 (keyset cursor):\n{}", plan);

    assertThat(plan).doesNotContain("Seq Scan");
    assertThat(plan).contains("audit_event_y2020m03", "audit_event_y2020m02");
  }

  @Test
  void targetHistoryUsesTheTargetIndexAcrossAllPartitions() {
    AuditSearchCriteria c = new AuditSearchCriteria(account, null, null, null, "invoice", "T-1202", null, null, null,
        null, 50);
    String plan = explain(AuditSearchSql.page(c));
    log.info("EXPLAIN target history (no window):\n{}", plan);

    // the four generated partitions are probed through the index; only the near-empty current-month ones are scanned
    assertThat(plan).doesNotContain("Seq Scan on audit_event_y2020");
    assertThat(plan).contains("target_type_target_id_occurred_at_idx");   // partition child of ae_target_idx
  }

  private static AuditSearchCriteria criteria(UUID tenantId, UUID actorUserId, String action, String targetType,
                                              String outcome, String from, String to, KeysetCursor cursor) {
    return new AuditSearchCriteria(account, tenantId, actorUserId, action, targetType, null, outcome,
        Instant.parse(from), Instant.parse(to), cursor, 50);
  }

  private static String explain(AuditSearchSql.Query q) {
    return data.explain(q.sql(), q.params());
  }
}
