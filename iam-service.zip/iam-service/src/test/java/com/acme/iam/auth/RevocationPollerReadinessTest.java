package com.acme.iam.auth;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import com.acme.iam.core.revocation.RevocationRegistry;
import com.acme.iam.observability.ReadinessStatus;
import com.acme.iam.observability.RevocationFreshnessHealthIndicator;
import java.time.Clock;
import java.time.Duration;
import java.util.List;
import org.junit.jupiter.api.Test;
import org.springframework.boot.actuate.health.Status;
import org.springframework.dao.DataAccessResourceFailureException;

/**
 * Task 9 fix round 1: the startup poll does not fail open. When it fails (database unreachable), the instance stays
 * NOT_READY (readiness 503, so it takes no traffic) until a full poll succeeds; a partial read (cursor loaded, page
 * failed) does not count.
 */
class RevocationPollerReadinessTest {

  private final Clock clock = Clock.systemUTC();
  private final RevocationService feed = mock(RevocationService.class);

  @Test
  void notReadyUntilTheFirstCompletePollSucceeds() {
    when(feed.startCursor(Duration.ofMinutes(20))).thenReturn(0L);
    when(feed.since(anyLong(), anyInt())).thenThrow(new DataAccessResourceFailureException("database down"));
    RevocationPoller poller = new RevocationPoller(feed, new RevocationRegistry(clock), clock, Duration.ofHours(1),
        Duration.ofMinutes(20), Duration.ofHours(1));
    RevocationFreshnessHealthIndicator readiness = new RevocationFreshnessHealthIndicator(poller, clock,
        Duration.ofSeconds(30));
    try {
      poller.start(); // the synchronous startup poll fails and is only logged

      assertThat(poller.lastSuccessfulPoll()).isNull();
      assertThat(readiness.health().getStatus()).isEqualTo(ReadinessStatus.NOT_READY);

      doReturn(List.of()).when(feed).since(anyLong(), anyInt());
      poller.poll();

      assertThat(poller.lastSuccessfulPoll()).isNotNull();
      assertThat(readiness.health().getStatus()).isEqualTo(Status.UP);
    } finally {
      poller.stop();
    }
  }
}
