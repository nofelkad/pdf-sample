package com.acme.iam.tenant;

import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.http.HttpHeaders.AUTHORIZATION;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.patch;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import com.acme.iam.account.SubscriptionStatus;
import com.acme.iam.common.Ids;
import com.acme.iam.common.test.Fixtures;
import com.acme.iam.common.test.IntegrationTest;
import com.acme.iam.common.test.OrgTestData;
import com.acme.iam.common.test.PostgresTestBase;
import com.acme.iam.common.test.TestTokens;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.util.UUID;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.http.MediaType;
import org.springframework.jdbc.core.simple.JdbcClient;
import org.springframework.test.web.servlet.MockMvc;

/**
 * P1-6.3: tenant API ({@code iam.tenant.manage}, own account only; creation is platform-only, R46), I5 and revocation
 * on suspend/archive/disable.
 */
@IntegrationTest
@AutoConfigureMockMvc
class TenantApiIT extends PostgresTestBase {

  @Autowired MockMvc mvc;
  @Autowired TestTokens tokens;
  @Autowired JdbcClient jdbc;
  @Autowired ObjectMapper json;

  OrgTestData org;
  Fixtures fx;
  UUID account;
  UUID homeTenant;
  UUID admin;
  String bearer;
  UUID product;
  String productCode;

  @BeforeEach
  void setUp() {
    org = new OrgTestData(jdbc);
    fx = org.fixtures();
    Fixtures.Scenario s = fx.scenario();
    account = s.accountId();
    homeTenant = s.tenantId();
    admin = org.accountAdmin(account, homeTenant);
    bearer = org.bearer(tokens, admin, account, homeTenant, "iam.tenant.manage");
    product = fx.product();
    fx.subscribe(account, product, SubscriptionStatus.ACTIVE, null);
    productCode = jdbc.sql("SELECT code FROM product WHERE id = :id").param("id", product).query(String.class).single();
  }

  @Test
  void listsGetsAndUpdatesTenantsOfTheOwnAccount() throws Exception {
    UUID id = fx.tenant(account);
    String slug = jdbc.sql("SELECT slug::text FROM tenant WHERE id = :id").param("id", id).query(String.class).single();

    mvc.perform(get("/api/tenants").header(AUTHORIZATION, bearer))
        .andExpect(status().isOk())
        .andExpect(jsonPath("$.items[?(@.id=='%s')].slug".formatted(id)).value(slug));
    mvc.perform(get("/api/tenants/{id}", id).header(AUTHORIZATION, bearer))
        .andExpect(status().isOk())
        .andExpect(jsonPath("$.id").value(id.toString()));
    mvc.perform(patch("/api/tenants/{id}", id).header(AUTHORIZATION, bearer)
            .contentType(MediaType.APPLICATION_JSON).content("{\"name\":\"Sales EMEA\"}"))
        .andExpect(status().isOk())
        .andExpect(jsonPath("$.name").value("Sales EMEA"));
  }

  @Test
  void listIsKeysetPaginated() throws Exception {
    for (int i = 0; i < 3; i++) {
      fx.tenant(account);
    }
    JsonNode first = body(mvc.perform(get("/api/tenants?limit=2").header(AUTHORIZATION, bearer))
        .andExpect(status().isOk())
        .andExpect(jsonPath("$.items.length()").value(2))
        .andReturn().getResponse().getContentAsString());
    String cursor = first.get("nextCursor").asText();
    mvc.perform(get("/api/tenants?limit=2&cursor=" + cursor).header(AUTHORIZATION, bearer))
        .andExpect(status().isOk())
        .andExpect(jsonPath("$.items.length()").value(2)); // 4 tenants in total (home + 3)
  }

  @Test
  void i5_enablingAProductTheAccountDoesNotActivelySubscribeIsRejected() throws Exception {
    UUID suspended = fx.product();
    fx.subscribe(account, suspended, SubscriptionStatus.SUSPENDED, null);
    String suspendedCode = code(suspended);
    String unsubscribedCode = code(fx.product());

    UUID tenant = fx.tenant(account);
    mvc.perform(put("/api/tenants/{id}/products", tenant).header(AUTHORIZATION, bearer)
            .contentType(MediaType.APPLICATION_JSON)
            .content("{\"products\":[{\"code\":\"%s\",\"enabled\":true}]}".formatted(suspendedCode)))
        .andExpect(status().isBadRequest())
        .andExpect(jsonPath("$.code").value("product_not_subscribed"))
        .andExpect(jsonPath("$.products[0]").value(suspendedCode));

    // a disabled switch for a non-entitled product is allowed (it grants nothing)
    mvc.perform(put("/api/tenants/{id}/products", tenant).header(AUTHORIZATION, bearer)
            .contentType(MediaType.APPLICATION_JSON)
            .content("{\"products\":[{\"code\":\"%s\",\"enabled\":false},{\"code\":\"%s\",\"enabled\":true}]}"
                .formatted(suspendedCode, productCode)))
        .andExpect(status().isOk());
  }

  @Test
  void suspendRevokesMembersTokensAndReactivateRestoresStatus() throws Exception {
    UUID tenant = fx.tenant(account);
    UUID member = fx.user(account, tenant);
    UUID outsider = fx.user(account, homeTenant);
    int before = org.sessionVersion(member);

    mvc.perform(post("/api/tenants/{id}/suspend", tenant).header(AUTHORIZATION, bearer))
        .andExpect(status().isOk())
        .andExpect(jsonPath("$.status").value("SUSPENDED"));

    assertThat(org.sessionVersion(member)).isEqualTo(before + 1);
    assertThat(org.revocations(member)).isEqualTo(1);
    assertThat(org.revocations(outsider)).isZero();

    mvc.perform(post("/api/tenants/{id}/reactivate", tenant).header(AUTHORIZATION, bearer))
        .andExpect(status().isOk())
        .andExpect(jsonPath("$.status").value("ACTIVE"));
  }

  @Test
  void archiveRevokesAndIsTerminal() throws Exception {
    UUID tenant = fx.tenant(account);
    UUID member = fx.user(account, tenant);

    mvc.perform(post("/api/tenants/{id}/archive", tenant).header(AUTHORIZATION, bearer))
        .andExpect(status().isOk())
        .andExpect(jsonPath("$.status").value("ARCHIVED"));
    assertThat(org.revocations(member)).isEqualTo(1);

    mvc.perform(post("/api/tenants/{id}/reactivate", tenant).header(AUTHORIZATION, bearer))
        .andExpect(status().isConflict())
        .andExpect(jsonPath("$.code").value("tenant_not_active"));
    for (var write : java.util.List.of(
        patch("/api/tenants/{id}", tenant).contentType(MediaType.APPLICATION_JSON).content("{\"name\":\"Z\"}"),
        put("/api/tenants/{id}/products", tenant).contentType(MediaType.APPLICATION_JSON).content("{\"products\":[]}"),
        post("/api/tenants/{id}/suspend", tenant))) {
      mvc.perform(write.header(AUTHORIZATION, bearer))
          .andExpect(status().isConflict())
          .andExpect(jsonPath("$.code").value("tenant_not_active"));
    }
  }

  @Test
  void disablingAProductRevokesMembersButEnablingDoesNot() throws Exception {
    UUID tenant = fx.tenant(account);
    UUID member = fx.user(account, tenant);
    String on = "{\"products\":[{\"code\":\"%s\",\"enabled\":true}]}".formatted(productCode);
    String off = "{\"products\":[{\"code\":\"%s\",\"enabled\":false}]}".formatted(productCode);

    mvc.perform(put("/api/tenants/{id}/products", tenant).header(AUTHORIZATION, bearer)
            .contentType(MediaType.APPLICATION_JSON).content(on))
        .andExpect(status().isOk())
        .andExpect(jsonPath("$.products[0].enabled").value(true));
    assertThat(org.revocations(member)).isZero();

    mvc.perform(put("/api/tenants/{id}/products", tenant).header(AUTHORIZATION, bearer)
            .contentType(MediaType.APPLICATION_JSON).content(off))
        .andExpect(status().isOk())
        .andExpect(jsonPath("$.products[0].enabled").value(false));
    assertThat(org.revocations(member)).isEqualTo(1);
  }

  @Test
  void i10_tenantsOfAnotherAccountAreNotFound() throws Exception {
    UUID foreign = fx.scenario().tenantId();
    mvc.perform(get("/api/tenants/{id}", foreign).header(AUTHORIZATION, bearer))
        .andExpect(status().isNotFound())
        .andExpect(jsonPath("$.code").value("tenant_not_found"));
    mvc.perform(post("/api/tenants/{id}/suspend", foreign).header(AUTHORIZATION, bearer))
        .andExpect(status().isNotFound());
    assertThat(jdbc.sql("SELECT status FROM tenant WHERE id = :id").param("id", foreign).query(String.class).single())
        .isEqualTo("ACTIVE");
  }

  @Test
  void requiresTenantManage() throws Exception {
    String reader = org.bearer(tokens, admin, account, homeTenant, "iam.user.read.account");
    mvc.perform(get("/api/tenants").header(AUTHORIZATION, reader)).andExpect(status().isForbidden());
    mvc.perform(post("/api/tenants/{id}/suspend", homeTenant).header(AUTHORIZATION, reader))
        .andExpect(status().isForbidden());
  }

  @Test
  void tenantManagementNeedsTheGrantAtAccountScope() throws Exception {
    UUID manager = fx.user(account, homeTenant);
    UUID role = fx.systemRole(com.acme.iam.product.Product.IAM_ID,
        fx.permission(com.acme.iam.product.Product.IAM_ID, "iam.tenant.manage"));
    fx.assign(manager, role, com.acme.iam.assignment.ScopeType.TENANT, homeTenant);
    String tenantScoped = org.bearer(tokens, manager, account, homeTenant, "iam.tenant.manage");

    mvc.perform(get("/api/tenants").header(AUTHORIZATION, tenantScoped))
        .andExpect(status().isForbidden())
        .andExpect(jsonPath("$.code").value("account_scope_required"));
    mvc.perform(post("/api/tenants/{id}/suspend", homeTenant).header(AUTHORIZATION, tenantScoped))
        .andExpect(status().isForbidden())
        .andExpect(jsonPath("$.code").value("account_scope_required"));
    assertThat(jdbc.sql("SELECT status FROM tenant WHERE id = :id").param("id", homeTenant).query(String.class)
        .single()).isEqualTo("ACTIVE");
  }

  @Test
  void aClosedAccountCannotChangeTenants() throws Exception {
    UUID tenant = fx.tenant(account);
    fx.accountStatus(account, com.acme.iam.account.AccountStatus.CLOSED);
    mvc.perform(patch("/api/tenants/{id}", tenant).header(AUTHORIZATION, bearer)
            .contentType(MediaType.APPLICATION_JSON).content("{\"name\":\"Z\"}"))
        .andExpect(status().isConflict())
        .andExpect(jsonPath("$.code").value("account_closed"));
  }

  @Test
  void accountAdminsCanNoLongerCreateTenants() throws Exception {
    mvc.perform(post("/api/tenants").header(AUTHORIZATION, bearer).contentType(MediaType.APPLICATION_JSON)
            .content("{\"name\":\"N\",\"slug\":\"n-%s\"}".formatted(Ids.newId().toString().substring(24))))
        .andExpect(status().isMethodNotAllowed());
  }

  private String code(UUID productId) {
    return jdbc.sql("SELECT code FROM product WHERE id = :id").param("id", productId).query(String.class).single();
  }

  private JsonNode body(String content) throws Exception {
    return json.readTree(content);
  }
}
