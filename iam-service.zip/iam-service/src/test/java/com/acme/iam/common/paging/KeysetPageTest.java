package com.acme.iam.common.paging;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

import com.acme.iam.common.error.BadRequestException;
import java.nio.charset.StandardCharsets;
import java.time.Instant;
import java.util.Base64;
import java.util.List;
import java.util.UUID;
import org.junit.jupiter.api.Test;

class KeysetPageTest {

  record Row(Instant createdAt, UUID id) {}

  @Test
  void cursorRoundTripsAndIsOpaqueBase64Url() {
    KeysetCursor cursor = new KeysetCursor(Instant.parse("2026-10-10T12:34:56.123456Z"), UUID.randomUUID());
    String encoded = cursor.encode();

    assertThat(encoded).doesNotContain("=", "+", "/");
    assertThat(new String(Base64.getUrlDecoder().decode(encoded), StandardCharsets.UTF_8))
        .isEqualTo("2026-10-10T12:34:56.123456Z|" + cursor.id());
    assertThat(KeysetCursor.decode(encoded)).contains(cursor);
    assertThat(KeysetCursor.decode(null)).isEmpty();
    assertThat(KeysetCursor.decode(" ")).isEmpty();
  }

  @Test
  void malformedCursorsAreBadRequests() {
    for (String bad : List.of("%%%", "bm8tc2VwYXJhdG9y", Base64.getUrlEncoder().encodeToString("x|y".getBytes()))) {
      assertThatThrownBy(() -> KeysetCursor.decode(bad))
          .isInstanceOfSatisfying(BadRequestException.class, e -> assertThat(e.code()).isEqualTo("invalid_cursor"));
    }
  }

  @Test
  void limitDefaultsAndIsCapped() {
    assertThat(KeysetPage.limit(null)).isEqualTo(50);
    assertThat(KeysetPage.limit(10)).isEqualTo(10);
    assertThat(KeysetPage.limit(1000)).isEqualTo(200);
    assertThatThrownBy(() -> KeysetPage.limit(0)).isInstanceOf(BadRequestException.class);
  }

  @Test
  void pageDropsTheLookAheadRowAndPointsAtTheLastItem() {
    Row a = new Row(Instant.parse("2026-01-03T00:00:00Z"), UUID.randomUUID());
    Row b = new Row(Instant.parse("2026-01-02T00:00:00Z"), UUID.randomUUID());
    Row c = new Row(Instant.parse("2026-01-01T00:00:00Z"), UUID.randomUUID());

    KeysetPage<Row> full = KeysetPage.of(List.of(a, b, c), 2, Row::createdAt, Row::id);
    assertThat(full.items()).containsExactly(a, b);
    assertThat(KeysetCursor.decode(full.nextCursor())).contains(new KeysetCursor(b.createdAt(), b.id()));

    KeysetPage<Row> last = KeysetPage.of(List.of(a, b), 2, Row::createdAt, Row::id);
    assertThat(last.items()).containsExactly(a, b);
    assertThat(last.nextCursor()).isNull();
  }
}
