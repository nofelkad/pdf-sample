package com.acme.iam.role;

import static org.assertj.core.api.Assertions.assertThat;

import com.acme.iam.common.test.PlanTestData;
import com.acme.iam.common.test.PostgresTestBase;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.core.simple.JdbcClient;

/**
 * P1-3.4 index review of the role list. A SYSTEM role is held at TENANT scope by every seeded user of both accounts,
 * so a count that is not restricted to the caller's tenants inside the index condition would read the other account's
 * rows. Logs the plan.
 */
class RoleQueryPlanIT extends PostgresTestBase {

  private static final Logger log = LoggerFactory.getLogger(RoleQueryPlanIT.class);

  static PlanTestData data;
  static UUID account;
  static UUID noiseAccount;
  static UUID sharedRole;

  @BeforeAll
  static void seed() {
    data = new PlanTestData().migrate();
    account = data.seedAccount();
    noiseAccount = data.seedAccount();
    sharedRole = UUID.randomUUID();
    data.admin().sql("""
            INSERT INTO role (id, product_id, name, type, version)
            VALUES (:id, '00000000-0000-7000-8000-000000000001', CAST(:name AS text), 'SYSTEM', 0)""")
        .param("id", sharedRole).param("name", "Shared " + sharedRole).update();
    data.admin().sql("""
            INSERT INTO role_assignment (id, user_id, role_id, scope_type, scope_id, version)
            SELECT gen_random_uuid(), u.id, :role, 'TENANT', u.primary_tenant_id, 0
            FROM app_user u WHERE u.account_id IN (:a, :b)""")
        .param("role", sharedRole).param("a", account).param("b", noiseAccount).update();
    data.analyze();
  }

  @AfterAll
  static void cleanUp() {
    data.admin().sql("DELETE FROM role_assignment WHERE role_id = :role").param("role", sharedRole).update();
    data.admin().sql("DELETE FROM role WHERE id = :role").param("role", sharedRole).update();
    data.delete(account);
    data.delete(noiseAccount);
  }

  @Test
  void assignmentCountsProbeOnlyTheCallersScopes() {
    String plan = data.explain(RoleQueryService.sql(RoleListFilter.NONE, false),
        Map.of("accountId", account, "limit", 51));
    log.info("EXPLAIN role list:\n{}", plan);
    assertThat(plan).contains("ra_role_scope_idx").doesNotContain("Seq Scan on role_assignment");
    // every probe of the role/scope index must constrain scope_id in the index condition, not in a filter
    List<String> lines = plan.lines().toList();
    for (int i = 0; i < lines.size(); i++) {
      if (lines.get(i).contains("on role_assignment ra")) {
        assertThat(lines.get(i + 1)).as("index condition after: %s", lines.get(i))
            .contains("Index Cond:").contains("role_id = r.id").contains("scope_id =");
      }
    }
  }

  @Test
  void countsMatchTheSeededData() {
    RoleQueryService service = new RoleQueryService(JdbcClient.create(appDataSource()));
    var roles = service.list(account, RoleListFilter.NONE, null, 200).items();

    RoleSummary r7 = roles.stream().filter(r -> r.name().equals("R7") && account.equals(r.accountId()))
        .findFirst().orElseThrow();
    // R7 is held at TENANT scope by users with i % 20 == 6 and by users with (i + 7) % 20 == 6; expired rows excluded
    assertThat(r7.assignmentCount()).isEqualTo(500);
    assertThat(r7.permissionCount()).isEqualTo(10);

    RoleSummary shared = roles.stream().filter(r -> r.id().equals(sharedRole)).findFirst().orElseThrow();
    assertThat(shared.assignmentCount()).isEqualTo(PlanTestData.USERS_PER_ACCOUNT);
  }
}
