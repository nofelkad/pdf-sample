package com.acme.iam.common.security;

import static org.assertj.core.api.Assertions.assertThat;

import java.time.Duration;
import org.junit.jupiter.api.Test;
import org.springframework.boot.autoconfigure.AutoConfigurations;
import org.springframework.boot.autoconfigure.validation.ValidationAutoConfiguration;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.boot.test.context.runner.ApplicationContextRunner;
import org.springframework.context.annotation.Configuration;

/** Outside the dev/test profiles there is no issuer or master key: startup must fail. */
class SecurityPropertiesTest {

  @Configuration(proxyBeanMethods = false)
  @EnableConfigurationProperties(SecurityProperties.class)
  static class Config {}

  private final ApplicationContextRunner runner = new ApplicationContextRunner()
      .withConfiguration(AutoConfigurations.of(ValidationAutoConfiguration.class))
      .withUserConfiguration(Config.class);

  @Test
  void missingMasterKeyOrIssuerFailsStartup() {
    runner.withPropertyValues("iam.security.issuer=https://iam.example")
        .run(ctx -> assertThat(ctx).hasFailed()
            .getFailure().rootCause().hasMessageContaining("masterKey"));
    runner.withPropertyValues("iam.security.master-key=abc", "iam.security.issuer=")
        .run(ctx -> assertThat(ctx).hasFailed());
  }

  @Test
  void defaultsMatchTheSpec() {
    runner.withPropertyValues("iam.security.issuer=https://iam.example", "iam.security.master-key=abc")
        .run(ctx -> {
          SecurityProperties p = ctx.getBean(SecurityProperties.class);
          assertThat(p.accessTokenTtl()).isEqualTo(Duration.ofMinutes(15));
          assertThat(p.appTokenTtl()).isEqualTo(Duration.ofMinutes(10));
          assertThat(p.clockSkew()).isEqualTo(Duration.ofSeconds(60));
          assertThat(p.keyPublishLead()).isEqualTo(Duration.ofHours(24));
          assertThat(p.jwkRefreshInterval()).isEqualTo(Duration.ofSeconds(60));
          assertThat(p.toString()).doesNotContain("abc");
        });
  }
}
