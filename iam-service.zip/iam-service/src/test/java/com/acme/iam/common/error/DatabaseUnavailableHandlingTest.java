package com.acme.iam.common.error;

import static org.assertj.core.api.Assertions.assertThat;

import java.sql.SQLTransientConnectionException;
import org.junit.jupiter.api.Test;
import org.postgresql.util.PSQLException;
import org.postgresql.util.PSQLState;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.DataAccessResourceFailureException;
import org.springframework.dao.QueryTimeoutException;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ProblemDetail;
import org.springframework.http.ResponseEntity;
import org.springframework.jdbc.CannotGetJdbcConnectionException;
import org.springframework.jdbc.support.SQLStateSQLExceptionTranslator;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.transaction.CannotCreateTransactionException;

/**
 * Task 9 failure modes (P1-11.4): while PostgreSQL is unreachable, requests fail fast with 503
 * {@code database_unavailable} and {@code Retry-After} instead of a generic 500.
 */
class DatabaseUnavailableHandlingTest {

  private final GlobalExceptionHandler handler = new GlobalExceptionHandler();

  @Test
  void connectionFailuresAre503WithRetryAfter() {
    for (Exception ex : new Exception[] {
        new CannotCreateTransactionException("Could not open JDBC Connection for transaction",
            new SQLTransientConnectionException("iam-app - Connection is not available, request timed out after 5000ms")),
        new CannotGetJdbcConnectionException("Failed to obtain JDBC Connection"),
        new DataAccessResourceFailureException("I/O error"),
        new QueryTimeoutException("socket timeout")}) {
      ResponseEntity<Object> response = handler.handleDatabaseUnavailable(ex, new MockHttpServletRequest());

      assertThat(response.getStatusCode().value()).as(ex.getClass().getSimpleName()).isEqualTo(503);
      assertThat(response.getHeaders().getFirst(HttpHeaders.RETRY_AFTER)).isEqualTo("5");
      ProblemDetail body = (ProblemDetail) response.getBody();
      assertThat(body.getProperties()).containsEntry("code", "database_unavailable");
      assertThat(body.getDetail()).doesNotContain("iam-app").doesNotContain("JDBC");
    }
  }

  /** An in-flight query whose socket times out (frozen server) surfaces as SQLSTATE 08006 → 503 as well. */
  @Test
  void aSocketTimeoutOfAnInFlightQueryIsADataAccessResourceFailure() {
    DataAccessException translated = new SQLStateSQLExceptionTranslator().translate("select", "SELECT 1",
        new PSQLException("An I/O error occurred while sending to the backend.", PSQLState.CONNECTION_FAILURE));

    assertThat(translated).isInstanceOf(DataAccessResourceFailureException.class);
    assertThat(handler.handleDatabaseUnavailable(translated, new MockHttpServletRequest()).getStatusCode().value())
        .isEqualTo(503);
  }
}
