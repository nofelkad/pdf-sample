package com.acme.iam.user;

import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.http.HttpHeaders.AUTHORIZATION;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import com.acme.iam.assignment.ScopeType;
import com.acme.iam.common.test.Fixtures;
import com.acme.iam.common.test.IntegrationTest;
import com.acme.iam.common.test.OrgTestData;
import com.acme.iam.common.test.PostgresTestBase;
import com.acme.iam.common.test.TestTokens;
import com.acme.iam.product.Product;
import com.acme.iam.tenant.TenantStatus;
import java.util.List;
import java.util.UUID;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.http.MediaType;
import org.springframework.jdbc.core.simple.JdbcClient;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.ResultActions;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;

/** P1-8.3 membership API: share into a tenant, remove (I2, I4), change primary tenant (I4). */
@IntegrationTest
@AutoConfigureMockMvc
class MembershipApiIT extends PostgresTestBase {

  @Autowired MockMvc mvc;
  @Autowired TestTokens tokens;
  @Autowired JdbcClient jdbc;

  OrgTestData org;
  Fixtures fx;
  UUID account;
  UUID tenantA;
  UUID tenantB;
  UUID admin;
  String adminBearer;
  UUID user;

  @BeforeEach
  void setUp() {
    org = new OrgTestData(jdbc);
    fx = org.fixtures();
    Fixtures.Scenario s = fx.scenario();
    account = s.accountId();
    tenantA = s.tenantId();
    tenantB = fx.tenant(account);
    admin = org.accountAdmin(account, tenantA);
    adminBearer = org.adminBearer(tokens, admin, account, tenantA);
    user = fx.user(account, tenantA);
  }

  @Test
  void sharesAUserIntoAnotherTenantOnce() throws Exception {
    perform(post("/api/users/{id}/memberships", user), tenantB)
        .andExpect(status().isCreated())
        .andExpect(jsonPath("$.memberships.length()").value(2));
    assertThat(org.membershipTenants(user)).containsExactlyInAnyOrder(tenantA, tenantB);
    assertThat(org.revocations(user)).isZero();

    perform(post("/api/users/{id}/memberships", user), tenantB)
        .andExpect(status().isConflict())
        .andExpect(jsonPath("$.code").value("membership_exists"));
  }

  @Test
  void sharingReactivatesASuspendedMembership() throws Exception {
    fx.membership(user, tenantB, MembershipStatus.SUSPENDED);
    perform(post("/api/users/{id}/memberships", user), tenantB).andExpect(status().isCreated());
    assertThat(jdbc.sql("SELECT status FROM user_tenant_membership WHERE app_user = :u AND tenant_id = :t")
        .param("u", user).param("t", tenantB).query(String.class).single()).isEqualTo("ACTIVE");
  }

  @Test
  void sharingIntoAnInactiveOrForeignTenantIsRejected() throws Exception {
    perform(post("/api/users/{id}/memberships", user), fx.tenant(account, TenantStatus.SUSPENDED))
        .andExpect(status().isConflict())
        .andExpect(jsonPath("$.code").value("tenant_not_active"));
    perform(post("/api/users/{id}/memberships", user), fx.scenario().tenantId())
        .andExpect(status().isNotFound())
        .andExpect(jsonPath("$.code").value("tenant_not_found"));
  }

  @Test
  void i2_removingAMembershipDeletesThatTenantsAssignmentsAndRevokes() throws Exception {
    fx.membership(user, tenantB, MembershipStatus.ACTIVE);
    UUID role = fx.systemRole(Product.IAM_ID, fx.permission(Product.IAM_ID));
    UUID inB = fx.assign(user, role, ScopeType.TENANT, tenantB);
    UUID inA = fx.assign(user, role, ScopeType.TENANT, tenantA);
    UUID accountWide = fx.assign(user, role, ScopeType.ACCOUNT, account);

    mvc.perform(delete("/api/users/{id}/memberships/{tenantId}", user, tenantB).header(AUTHORIZATION, adminBearer))
        .andExpect(status().isNoContent());

    assertThat(org.membershipTenants(user)).containsExactly(tenantA);
    List<UUID> remaining = jdbc.sql("SELECT id FROM role_assignment WHERE user_id = :u").param("u", user)
        .query(UUID.class).list();
    assertThat(remaining).containsExactlyInAnyOrder(inA, accountWide).doesNotContain(inB);
    assertThat(org.revocations(user)).isEqualTo(1);
  }

  @Test
  void i4_thePrimaryMembershipCannotBeRemoved() throws Exception {
    mvc.perform(delete("/api/users/{id}/memberships/{tenantId}", user, tenantA).header(AUTHORIZATION, adminBearer))
        .andExpect(status().isConflict())
        .andExpect(jsonPath("$.code").value("primary_membership"));
    assertThat(org.membershipTenants(user)).containsExactly(tenantA);
    mvc.perform(delete("/api/users/{id}/memberships/{tenantId}", user, tenantB).header(AUTHORIZATION, adminBearer))
        .andExpect(status().isNotFound())
        .andExpect(jsonPath("$.code").value("membership_not_found"));
  }

  @Test
  void i4_changingThePrimaryTenantRequiresAnActiveMembership() throws Exception {
    perform(put("/api/users/{id}/primary-tenant", user), tenantB)
        .andExpect(status().isConflict())
        .andExpect(jsonPath("$.code").value("membership_required"));
    fx.membership(user, tenantB, MembershipStatus.SUSPENDED);
    perform(put("/api/users/{id}/primary-tenant", user), tenantB)
        .andExpect(status().isConflict())
        .andExpect(jsonPath("$.code").value("membership_required"));

    fx.membership(user, tenantB, MembershipStatus.ACTIVE);
    perform(put("/api/users/{id}/primary-tenant", user), tenantB)
        .andExpect(status().isOk())
        .andExpect(jsonPath("$.primaryTenantId").value(tenantB.toString()));

    // the old primary is now an ordinary membership and can be removed
    mvc.perform(delete("/api/users/{id}/memberships/{tenantId}", user, tenantA).header(AUTHORIZATION, adminBearer))
        .andExpect(status().isNoContent());
    assertThat(org.membershipTenants(user)).containsExactly(tenantB);
  }

  @Test
  void sharingRequiresUserShare() throws Exception {
    String manager = org.bearer(tokens, admin, account, tenantA, "iam.user.manage");
    mvc.perform(post("/api/users/{id}/memberships", user).header(AUTHORIZATION, manager)
            .contentType(MediaType.APPLICATION_JSON).content("{\"tenantId\":\"%s\"}".formatted(tenantB)))
        .andExpect(status().isForbidden());
    mvc.perform(delete("/api/users/{id}/memberships/{tenantId}", user, tenantB).header(AUTHORIZATION, manager))
        .andExpect(status().isForbidden());
  }

  @Test
  void i10_usersOfAnotherAccountAreNotFound() throws Exception {
    UUID foreign = fx.scenario().userId();
    perform(post("/api/users/{id}/memberships", foreign), tenantB)
        .andExpect(status().isNotFound())
        .andExpect(jsonPath("$.code").value("user_not_found"));
  }

  private ResultActions perform(MockHttpServletRequestBuilder request, UUID tenantId) throws Exception {
    return mvc.perform(request.header(AUTHORIZATION, adminBearer).contentType(MediaType.APPLICATION_JSON)
        .content("{\"tenantId\":\"%s\"}".formatted(tenantId)));
  }
}
