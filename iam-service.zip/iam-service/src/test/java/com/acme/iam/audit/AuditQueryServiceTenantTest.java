package com.acme.iam.audit;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import com.acme.iam.common.security.CodedAccessDeniedException;
import com.acme.iam.common.security.CurrentUser;
import com.acme.iam.common.security.PlatformGuard;
import com.acme.iam.common.security.TenantGuard;
import com.acme.iam.core.Claims;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.time.Instant;
import java.util.List;
import java.util.UUID;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Test;
import org.springframework.jdbc.core.simple.JdbcClient;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.security.oauth2.server.resource.authentication.JwtAuthenticationToken;

/** Task 9 (deferred fix E3): without an active tenant and without account scope the audit API fails closed. */
class AuditQueryServiceTenantTest {

  private final TenantGuard tenantGuard = mock(TenantGuard.class);
  private final AuditQueryService service = new AuditQueryService(mock(JdbcClient.class), new CurrentUser(),
      new ObjectMapper(), tenantGuard, mock(PlatformGuard.class));
  private final UUID account = UUID.randomUUID();
  private final Instant to = Instant.parse("2026-10-10T00:00:00Z");
  private final AuditFilter noTenant =
      new AuditFilter(null, null, null, null, null, null, null, to.minusSeconds(3600), to, null, null);

  @AfterEach
  void clear() {
    SecurityContextHolder.clearContext();
  }

  @Test
  void missingTenantClaimWithoutAccountScopeIsTenantRequired() {
    authenticate(null);
    when(tenantGuard.hasAccountScope(AuditQueryService.PERM_READ)).thenReturn(false);

    assertThatThrownBy(() -> service.criteria(noTenant, true, AuditQueryService.PERM_READ))
        .isInstanceOfSatisfying(CodedAccessDeniedException.class,
            e -> assertThat(e.code()).isEqualTo("tenant_required"));
  }

  @Test
  void missingTenantClaimWithAccountScopeIsAccountWide() {
    authenticate(null);
    when(tenantGuard.hasAccountScope(AuditQueryService.PERM_READ)).thenReturn(true);

    AuditSearchCriteria criteria = service.criteria(noTenant, true, AuditQueryService.PERM_READ);

    assertThat(criteria.accountId()).isEqualTo(account);
    assertThat(criteria.tenantId()).isNull();
  }

  @Test
  void tenantScopedCallerIsPinnedToTheTokenTenant() {
    UUID tenant = UUID.randomUUID();
    authenticate(tenant);
    when(tenantGuard.hasAccountScope(AuditQueryService.PERM_READ)).thenReturn(false);

    assertThat(service.criteria(noTenant, true, AuditQueryService.PERM_READ).tenantId()).isEqualTo(tenant);
  }

  private void authenticate(UUID tenant) {
    Jwt.Builder jwt = Jwt.withTokenValue("t").header("alg", "RS256").subject(UUID.randomUUID().toString())
        .claim(Claims.ACCOUNT, account.toString()).claim(Claims.SESSION, UUID.randomUUID().toString())
        .claim(Claims.SESSION_VERSION, 1L).claim(Claims.PERMISSIONS, List.of(AuditQueryService.PERM_READ));
    if (tenant != null) {
      jwt.claim(Claims.TENANT, tenant.toString());
    }
    SecurityContextHolder.getContext().setAuthentication(new JwtAuthenticationToken(jwt.build(), List.of()));
  }
}
