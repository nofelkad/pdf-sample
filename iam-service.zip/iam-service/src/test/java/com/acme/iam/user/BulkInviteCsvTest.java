package com.acme.iam.user;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

import com.acme.iam.common.error.BadRequestException;
import com.acme.iam.user.BulkInviteCsv.Row;
import java.io.ByteArrayInputStream;
import java.nio.charset.StandardCharsets;
import java.util.List;
import org.junit.jupiter.api.Test;

class BulkInviteCsvTest {

  @Test
  void parsesRowsWithOptionalHeaderQuotesAndBlankLines() {
    List<Row> rows = parse("﻿" + "email,displayName,roleName\n"
        + "a@example.test,Ada,Tenant Admin\r\n"
        + "\"b@example.test\",\"Lovelace, Ada \"\"Countess\"\"\",\n"
        + "\n"
        + "c@example.test\n");

    assertThat(rows).containsExactly(
        new Row(2, "a@example.test", "Ada", "Tenant Admin", 3),
        new Row(3, "b@example.test", "Lovelace, Ada \"Countess\"", null, 3),
        new Row(5, "c@example.test", null, null, 1));
  }

  @Test
  void aFileWithoutHeaderStartsAtLineOne() {
    assertThat(parse("x@example.test,X\n")).containsExactly(new Row(1, "x@example.test", "X", null, 2));
  }

  @Test
  void quotedFieldsMaySpanLines() {
    assertThat(parse("a@example.test,\"two\nlines\"\nb@example.test\n"))
        .extracting(Row::line, Row::email)
        .containsExactly(org.assertj.core.groups.Tuple.tuple(1, "a@example.test"),
            org.assertj.core.groups.Tuple.tuple(3, "b@example.test"));
  }

  @Test
  void rejectsMoreThanTheMaximumNumberOfRows() {
    String csv = "email\n" + "x@example.test\n".repeat(4);
    assertThat(BulkInviteCsv.parse(stream(csv), 4)).hasSize(4);
    assertThatThrownBy(() -> BulkInviteCsv.parse(stream(csv + "y@example.test\n"), 4))
        .isInstanceOf(BadRequestException.class)
        .extracting("code").isEqualTo("too_many_rows");
  }

  @Test
  void rejectsMalformedAndEmptyFiles() {
    assertThatThrownBy(() -> parse("a@example.test,\"unterminated\n"))
        .isInstanceOf(BadRequestException.class).extracting("code").isEqualTo("invalid_csv");
    assertThatThrownBy(() -> parse("email,displayName\n\n"))
        .isInstanceOf(BadRequestException.class).extracting("code").isEqualTo("empty_file");
  }

  private static List<Row> parse(String csv) {
    return BulkInviteCsv.parse(stream(csv), 5000);
  }

  private static ByteArrayInputStream stream(String csv) {
    return new ByteArrayInputStream(csv.getBytes(StandardCharsets.UTF_8));
  }
}
