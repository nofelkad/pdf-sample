package com.acme.iam.auth;

import static org.assertj.core.api.Assertions.assertThat;

import com.acme.iam.common.security.SecurityTestData;
import com.acme.iam.common.security.SecurityTestEndpoints;
import com.acme.iam.common.test.IntegrationTest;
import com.acme.iam.common.test.PostgresTestBase;
import com.acme.iam.core.revocation.RevocationRegistry;
import java.time.Duration;
import java.time.Instant;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import org.awaitility.Awaitility;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Import;
import org.springframework.jdbc.core.simple.JdbcClient;
import org.springframework.scheduling.concurrent.ThreadPoolTaskScheduler;
import org.springframework.transaction.support.TransactionTemplate;

/**
 * Ruling R13: a caller that already holds an {@code app_user} row lock and then revokes must not deadlock with a
 * concurrent scope revocation that needs that row. Before R13 the scope revocation took the feed lock first and then
 * waited on the row, while the caller waited on the feed lock: PostgreSQL aborted one of them.
 */
@IntegrationTest
@Import(SecurityTestEndpoints.class)
class RevocationConcurrencyIT extends PostgresTestBase {

  @Autowired JdbcClient jdbc;
  @Autowired TransactionTemplate tx;
  @Autowired RevocationService revocations;

  @Test
  void callerHoldingARowLockAndAConcurrentScopeRevocationDoNotDeadlock() throws Exception {
    SecurityTestData data = new SecurityTestData(jdbc);
    UUID account = data.account();
    UUID tenant = data.tenant(account);
    UUID x = data.user(account, tenant);
    UUID z = data.user(account, tenant);
    UUID role = data.role(account, "test.read");
    data.assign(x, role, "TENANT", tenant, null);

    CountDownLatch aHoldsX = new CountDownLatch(1);
    CountDownLatch bIsWaiting = new CountDownLatch(1);

    // A: changes user X (row lock), then - as its last write - revokes user Z.
    CompletableFuture<Integer> a = CompletableFuture.supplyAsync(() -> tx.execute(s -> {
      jdbc.sql("UPDATE app_user SET display_name = 'disabled-by-A' WHERE id = ?").params(x).update();
      aHoldsX.countDown();
      await(bIsWaiting);
      return revocations.revokeUsers(List.of(z), "A");
    }));

    // B: revokes every holder of the role, which includes X.
    await(aHoldsX);
    CompletableFuture<Integer> b = CompletableFuture.supplyAsync(() ->
        tx.execute(s -> revocations.revokeRoleHolders(role, "B")));

    waitUntilSomeoneWaitsOnALock();
    bIsWaiting.countDown();

    assertThat(a.get(30, TimeUnit.SECONDS)).isEqualTo(1);
    assertThat(b.get(30, TimeUnit.SECONDS)).isEqualTo(1);
    assertThat(data.sessionVersion(x)).isEqualTo(2);
    assertThat(data.sessionVersion(z)).isEqualTo(2);
  }

  @Test
  void pollerKeepsRunningWhileEverySharedSchedulerThreadIsBusy() throws Exception {
    int poolSize = taskScheduler.getScheduledThreadPoolExecutor().getCorePoolSize();
    assertThat(poolSize).isEqualTo(4);
    CountDownLatch release = new CountDownLatch(1);
    CountDownLatch busy = new CountDownLatch(poolSize);
    for (int i = 0; i < poolSize; i++) {
      taskScheduler.schedule(() -> {
        busy.countDown();
        await(release);
      }, Instant.now());
    }
    try {
      assertThat(busy.await(10, TimeUnit.SECONDS)).isTrue();
      SecurityTestData data = new SecurityTestData(jdbc);
      UUID account = data.account();
      UUID alice = data.user(account, data.tenant(account));

      tx.executeWithoutResult(s -> revocations.revokeUsers(List.of(alice), "starvation-test"));

      // no manual poll(): the poller's own scheduler must pick it up within a few poll intervals
      Awaitility.await().atMost(Duration.ofSeconds(15)).until(() -> registry.isRevoked(alice, 1));
      assertThat(poller.lastScheduledThreadName()).startsWith(RevocationPoller.THREAD_NAME_PREFIX);
    } finally {
      release.countDown();
    }
  }

  @Autowired ThreadPoolTaskScheduler taskScheduler;
  @Autowired RevocationRegistry registry;
  @Autowired RevocationPoller poller;

  @Test
  void scopeRevocationContinuesPastATargetDeletedConcurrently() throws Exception {
    SecurityTestData data = new SecurityTestData(jdbc);
    UUID account = data.account();
    UUID tenant = data.tenant(account);
    List<UUID> users = java.util.stream.IntStream.range(0, 5).mapToObj(i -> data.user(account, tenant)).toList();
    UUID first = jdbc.sql("SELECT id FROM app_user WHERE account_id = ? ORDER BY id LIMIT 1").params(account)
        .query(UUID.class).single();
    RevocationService smallBatches = new RevocationService(jdbc, auditWriter, 2);
    CountDownLatch deleted = new CountDownLatch(1);
    CountDownLatch revokerWaiting = new CountDownLatch(1);

    // D: deletes the first target (membership + user) and commits only once the revoker waits on that row
    CompletableFuture<Void> d = CompletableFuture.runAsync(() -> tx.executeWithoutResult(s -> {
      jdbc.sql("DELETE FROM user_tenant_membership WHERE app_user = ?").params(first).update();
      jdbc.sql("DELETE FROM app_user WHERE id = ?").params(first).update();
      deleted.countDown();
      await(revokerWaiting);
    }));
    await(deleted);
    CompletableFuture<Integer> r = CompletableFuture.supplyAsync(() ->
        tx.execute(s -> smallBatches.revokeAccountUsers(account, "account.suspended")));
    waitUntilSomeoneWaitsOnALock();
    revokerWaiting.countDown();

    d.get(30, TimeUnit.SECONDS);
    assertThat(r.get(30, TimeUnit.SECONDS)).isEqualTo(4);
    assertThat(users.stream().filter(u -> !u.equals(first)).map(data::sessionVersion)).containsOnly(2);
  }

  @Test
  void secondRevocationInTheSameTransactionFailsFast() {
    SecurityTestData data = new SecurityTestData(jdbc);
    UUID account = data.account();
    UUID tenant = data.tenant(account);
    UUID alice = data.user(account, tenant);
    UUID bob = data.user(account, tenant);

    org.assertj.core.api.Assertions.assertThatThrownBy(() -> tx.executeWithoutResult(s -> {
          revocations.revokeUsers(List.of(alice), "first");
          revocations.revokeUsers(List.of(bob), "second");
        }))
        .isInstanceOf(IllegalStateException.class)
        .hasMessageContaining("at most one revoke* per transaction");
    assertThat(data.sessionVersion(alice)).isEqualTo(1); // rolled back

    // the flag is per transaction: the next transaction may revoke again
    Integer retried = tx.execute(s -> revocations.revokeUsers(List.of(alice, bob), "retry"));
    assertThat(retried).isEqualTo(2);
  }

  @Test
  void openRevocationDoesNotBlockForeignKeyInsertsReferencingTheUser() throws Exception {
    SecurityTestData data = new SecurityTestData(jdbc);
    UUID account = data.account();
    UUID tenant = data.tenant(account);
    UUID alice = data.user(account, tenant);
    CountDownLatch revoked = new CountDownLatch(1);
    CountDownLatch inserted = new CountDownLatch(1);

    CompletableFuture<Void> revoker = CompletableFuture.runAsync(() -> tx.executeWithoutResult(s -> {
      revocations.revokeUsers(List.of(alice), "hold");
      revoked.countDown();
      await(inserted);
    }));
    await(revoked);
    try {
      // a login creating a session (FK user_session.user_id -> app_user) while the revocation is uncommitted
      tx.executeWithoutResult(s -> {
        jdbc.sql("SET LOCAL lock_timeout = '2s'").update();
        jdbc.sql("""
                INSERT INTO user_session (id, user_id, active_tenant_id, refresh_hash, expires_at, version)
                VALUES (?, ?, ?, ?, now() + interval '1 hour', 0)""")
            .params(UUID.randomUUID(), alice, tenant, UUID.randomUUID().toString().getBytes()).update();
      });
    } finally {
      inserted.countDown();
    }
    revoker.get(30, TimeUnit.SECONDS);
  }

  @Test
  void transactionWithoutSynchronizationLeavesNoStaleGuardOnTheThread() {
    SecurityTestData data = new SecurityTestData(jdbc);
    UUID account = data.account();
    UUID tenant = data.tenant(account);
    UUID alice = data.user(account, tenant);
    UUID bob = data.user(account, tenant);
    // a transaction whose manager never activates synchronization; the unproxied service runs inside it directly
    com.acme.iam.common.jdbc.AuditContextTransactionManager noSync =
        new com.acme.iam.common.jdbc.AuditContextTransactionManager(dataSource);
    noSync.setTransactionSynchronization(org.springframework.transaction.support.AbstractPlatformTransactionManager
        .SYNCHRONIZATION_NEVER);
    RevocationService direct = new RevocationService(jdbc, auditWriter, 5000);

    Integer first = new TransactionTemplate(noSync).execute(s -> direct.revokeUsers(List.of(alice), "no-sync"));
    Integer next = tx.execute(s -> revocations.revokeUsers(List.of(bob), "next"));

    assertThat(first).isEqualTo(1);
    assertThat(next).isEqualTo(1);
    assertThat(org.springframework.transaction.support.TransactionSynchronizationManager.getResourceMap()).isEmpty();
  }

  @Test
  void requiresNewInsideAPublishingTransactionTripsTheGuardInsteadOfSelfDeadlocking() {
    SecurityTestData data = new SecurityTestData(jdbc);
    UUID account = data.account();
    UUID tenant = data.tenant(account);
    UUID alice = data.user(account, tenant);
    UUID bob = data.user(account, tenant);
    TransactionTemplate requiresNew = new TransactionTemplate(tx.getTransactionManager());
    requiresNew.setPropagationBehavior(org.springframework.transaction.TransactionDefinition.PROPAGATION_REQUIRES_NEW);

    tx.executeWithoutResult(s -> {
      revocations.revokeUsers(List.of(alice), "outer");
      // the inner transaction would wait forever on the feed lock held by this (suspended) transaction
      org.assertj.core.api.Assertions.assertThatThrownBy(() ->
              requiresNew.executeWithoutResult(inner -> revocations.revokeUsers(List.of(bob), "inner")))
          .isInstanceOf(IllegalStateException.class)
          .hasMessageContaining("at most one revoke* per transaction");
    });

    assertThat(data.sessionVersion(alice)).isEqualTo(2);
    assertThat(data.sessionVersion(bob)).isEqualTo(1);
  }

  @Autowired javax.sql.DataSource dataSource;
  @Autowired com.acme.iam.audit.AuditWriter auditWriter;

  private void waitUntilSomeoneWaitsOnALock() throws InterruptedException {
    Instant deadline = Instant.now().plus(Duration.ofSeconds(10));
    while (Instant.now().isBefore(deadline)) {
      long waiting = jdbc.sql("SELECT count(*) FROM pg_locks WHERE NOT granted").query(Long.class).single();
      if (waiting > 0) {
        return;
      }
      Thread.sleep(20);
    }
    throw new AssertionError("B never blocked on A's row lock");
  }

  private static void await(CountDownLatch latch) {
    try {
      if (!latch.await(30, TimeUnit.SECONDS)) {
        throw new IllegalStateException("latch timeout");
      }
    } catch (InterruptedException e) {
      Thread.currentThread().interrupt();
      throw new IllegalStateException(e);
    }
  }
}
