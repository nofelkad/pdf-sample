package com.acme.iam.assignment;

import static org.assertj.core.api.Assertions.assertThat;

import com.acme.iam.common.test.Fixtures;
import com.acme.iam.common.test.IntegrationTest;
import com.acme.iam.common.test.PostgresTestBase;
import com.acme.iam.product.Product;
import java.lang.reflect.Method;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.UUID;
import net.javacrumbs.shedlock.spring.annotation.SchedulerLock;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.jdbc.core.simple.JdbcClient;

/** P1-10.5: expiry job: expired rows deleted in batches, holders revoked once per batch transaction. */
@IntegrationTest(properties = "iam.assignment.expiry.batch-size=2")
class AssignmentExpiryIT extends PostgresTestBase {

  @Autowired AssignmentExpiryService expiry;
  @Autowired JdbcClient jdbc;
  @Autowired org.springframework.context.ApplicationContext context;

  Fixtures fx;
  Fixtures.Scenario s;
  UUID role;
  AssignmentExpiryJob job;

  @BeforeEach
  void setUp() {
    fx = new Fixtures(jdbc);
    s = fx.scenario();
    role = fx.customRole(Product.IAM_ID, s.accountId());
    job = new AssignmentExpiryJob(expiry);   // not a bean in the test profile (it would delete other tests' fixtures)
    drainOtherExpiredRows();
  }

  /** The singleton test database may hold expired rows of other tests; clear them so batches are predictable. */
  private void drainOtherExpiredRows() {
    job.runOnce();
  }

  private UUID user() {
    return fx.user(s.accountId(), s.tenantId());
  }

  private int sessionVersion(UUID user) {
    return jdbc.sql("SELECT session_version FROM app_user WHERE id = :id").param("id", user).query(Integer.class).single();
  }

  private long assignments(UUID user) {
    return jdbc.sql("SELECT count(*) FROM role_assignment WHERE user_id = :u").param("u", user).query(Long.class).single();
  }

  private long revocationEvents() {
    return jdbc.sql("SELECT count(*) FROM audit_event WHERE action = 'auth.sessions.revoked'")
        .query(Long.class).single();
  }

  @Test
  void deletesExpiredRowsKeepsTheRestAndRevokesTheirHolders() {
    UUID expired = user();
    UUID alsoExpired = user();
    UUID active = user();
    UUID noExpiry = user();
    UUID future = user();
    Instant past = Instant.now().minus(1, ChronoUnit.HOURS);
    fx.assign(expired, role, ScopeType.TENANT, s.tenantId(), past);
    fx.assign(alsoExpired, role, ScopeType.ACCOUNT, s.accountId(), past.minusSeconds(5));
    fx.assign(active, role, ScopeType.TENANT, s.tenantId());
    fx.assign(noExpiry, role, ScopeType.ACCOUNT, s.accountId());
    fx.assign(future, role, ScopeType.TENANT, s.tenantId(), Instant.now().plus(1, ChronoUnit.DAYS));

    int deleted = job.runOnce();

    assertThat(deleted).isEqualTo(2);
    assertThat(assignments(expired)).isZero();
    assertThat(assignments(alsoExpired)).isZero();
    assertThat(assignments(active)).isEqualTo(1);
    assertThat(assignments(noExpiry)).isEqualTo(1);
    assertThat(assignments(future)).isEqualTo(1);
    assertThat(sessionVersion(expired)).isEqualTo(2);
    assertThat(sessionVersion(alsoExpired)).isEqualTo(2);
    assertThat(sessionVersion(active)).isEqualTo(1);
    assertThat(sessionVersion(future)).isEqualTo(1);
    assertThat(jdbc.sql("SELECT count(*) FROM revocation WHERE user_id IN (:ids)").param("ids", java.util.List.of(expired, alsoExpired))
        .query(Long.class).single()).isEqualTo(2);
    assertThat(jdbc.sql("SELECT count(*) FROM audit_event WHERE action = 'iam.role_assignment.delete' "
        + "AND before_state->>'user_id' IN (:a, :b)").param("a", expired.toString()).param("b", alsoExpired.toString())
        .query(Long.class).single()).isEqualTo(2);
  }

  @Test
  void runsInBatchesWithOneRevocationPerBatchTransaction() {
    Instant past = Instant.now().minus(1, ChronoUnit.HOURS);
    UUID heavy = user();               // three expired rows of one user: distinct users are revoked once
    UUID r2 = fx.customRole(Product.IAM_ID, s.accountId());
    UUID r3 = fx.customRole(Product.IAM_ID, s.accountId());
    fx.assign(heavy, role, ScopeType.TENANT, s.tenantId(), past);
    fx.assign(heavy, r2, ScopeType.TENANT, s.tenantId(), past);
    fx.assign(heavy, r3, ScopeType.TENANT, s.tenantId(), past);
    UUID second = user();
    UUID third = user();
    fx.assign(second, role, ScopeType.TENANT, s.tenantId(), past);
    fx.assign(third, role, ScopeType.TENANT, s.tenantId(), past);
    long eventsBefore = revocationEvents();

    int deleted = job.runOnce();   // 5 rows, batch size 2: batches of 2, 2, 1

    assertThat(deleted).isEqualTo(5);
    assertThat(revocationEvents()).isEqualTo(eventsBefore + 3);
    assertThat(assignments(heavy)).isZero();
    assertThat(sessionVersion(heavy)).isBetween(2, 3);   // revoked in one or two of the batches, never per row
    assertThat(sessionVersion(second)).isEqualTo(2);
    assertThat(sessionVersion(third)).isEqualTo(2);
  }

  @Test
  void theJobBeanIsSwitchedOffInTheTestProfile() {
    assertThat(context.getBeansOfType(AssignmentExpiryJob.class)).isEmpty();
  }

  @Test
  void aRunWithNothingToDoWritesNothing() {
    long eventsBefore = revocationEvents();

    assertThat(job.runOnce()).isZero();

    assertThat(revocationEvents()).isEqualTo(eventsBefore);
  }

  @Test
  void theJobIsScheduledEveryFiveMinutesUnderShedLock() throws NoSuchMethodException {
    Method run = AssignmentExpiryJob.class.getMethod("run");

    assertThat(run.getAnnotation(Scheduled.class).fixedDelayString()).contains("PT5M");
    assertThat(run.getAnnotation(SchedulerLock.class).name()).isEqualTo(AssignmentExpiryJob.LOCK_NAME);
  }
}
