package com.acme.iam.assignment;

import static org.assertj.core.api.Assertions.assertThat;
import static org.awaitility.Awaitility.await;
import static org.springframework.http.HttpHeaders.AUTHORIZATION;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.multipart;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;

import com.acme.iam.account.SubscriptionStatus;
import com.acme.iam.common.Ids;
import com.acme.iam.common.test.CapturingNotificationAdapter;
import com.acme.iam.common.test.Fixtures;
import com.acme.iam.common.test.IntegrationTest;
import com.acme.iam.common.test.OrgTestData;
import com.acme.iam.common.test.PostgresTestBase;
import com.acme.iam.common.test.TestTokens;
import com.acme.iam.product.Product;
import com.acme.iam.user.MembershipStatus;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.context.annotation.Import;
import org.springframework.http.MediaType;
import org.springframework.jdbc.core.simple.JdbcClient;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.test.web.servlet.MockMvc;

/**
 * Final review M4: the three ways a role reaches a user, {@code POST /api/users/{id}/assignments}, invite-with-roles
 * ({@code POST /api/tenants/{t}/users}) and bulk invite ({@code POST /api/tenants/{t}/users/bulk}, whose role checks are
 * an SQL re-implementation in {@code BulkInviteService}), give the same outcome for the same grantor, role and tenant:
 * the TenantGuard scope rule for {@code iam.role.assign}, I6 and the R40 product-system-role exemption.
 */
@IntegrationTest
@AutoConfigureMockMvc
@Import(CapturingNotificationAdapter.Config.class)
class AssignmentPathParityIT extends PostgresTestBase {

  /** What a path answered: the HTTP status and code, or for a bulk job its final status and row error code. */
  record Outcome(String result, String code) {
    static Outcome ok() {
      return new Outcome("ok", "");
    }

    static Outcome denied(String code) {
      return new Outcome("denied", code);
    }
  }

  @Autowired MockMvc mvc;
  @Autowired TestTokens tokens;
  @Autowired JdbcClient jdbc;
  @Autowired ObjectMapper json;
  @Autowired PermissionResolver resolver;

  OrgTestData org;
  Fixtures fx;
  UUID account;
  UUID t1;
  UUID t2;

  @BeforeEach
  void setUp() {
    org = new OrgTestData(jdbc);
    fx = org.fixtures();
    account = fx.account();
    t1 = fx.tenant(account);
    t2 = fx.tenant(account);
  }

  /**
   * The grantor holds {@code iam.role.assign} only at TENANT scope in T2 but is active in T1 (and may invite into T2
   * through an ACCOUNT-scope {@code iam.user.manage}). {@code /assignments} refuses T2 ({@code TenantGuard}); before M4
   * invite-with-roles and bulk invite accepted it, because their I6 check reads the grantor's permissions in T2.
   */
  @Test
  void aTenantScopedRoleAssignerCannotAssignInAnotherTenantOnAnyPath() throws Exception {
    UUID grantor = fx.user(account, t1);
    fx.membership(grantor, t2, MembershipStatus.ACTIVE);
    fx.assign(grantor, role("iam.user.manage"), ScopeType.ACCOUNT, account);
    fx.assign(grantor, role("iam.user.manage", "iam.role.assign"), ScopeType.TENANT, t1);
    fx.assign(grantor, role("iam.user.manage", "iam.role.assign", "iam.user.read.tenant"), ScopeType.TENANT, t2);
    UUID granted = role("iam.user.read.tenant");
    String bearer = bearer(grantor, t1);

    assertThat(paths(bearer, t2, granted)).containsOnly(Outcome.denied("scope_exceeded"));
  }

  /** I6: a Tenant Admin hands out a role with a permission it does not hold. */
  @Test
  void i6IsTheSameOnEveryPath() throws Exception {
    UUID tenantAdmin = fx.user(account, t1);
    fx.assign(tenantAdmin, org.tenantAdminRole(), ScopeType.TENANT, t1);
    UUID granted = role("iam.role.manage");

    assertThat(paths(bearer(tenantAdmin, t1), t1, granted)).containsOnly(Outcome.denied("grantor_lacks_permissions"));
  }

  /** R40: a product SYSTEM role whose product is subscribed but switched off in the tenant. */
  @Test
  void r40RefusesAProductRoleThatIsNotEnabledInTheTenantOnEveryPath() throws Exception {
    UUID admin = org.accountAdmin(account, t1);
    UUID product = fx.product();
    fx.subscribe(account, product, SubscriptionStatus.ACTIVE, null);
    fx.enableProduct(t1, product, false);
    UUID productRole = fx.systemRole(product, fx.permission(product));

    assertThat(paths(bearer(admin, t1), t1, productRole)).containsOnly(Outcome.denied("product_not_entitled"));
  }

  /** R40: the same role is assignable on every path once the product is enabled, without holding its permissions. */
  @Test
  void r40GrantsAnEnabledProductRoleOnEveryPath() throws Exception {
    UUID admin = org.accountAdmin(account, t1);
    UUID product = fx.entitledProduct(account, t1);
    UUID productRole = fx.systemRole(product, fx.permission(product));

    assertThat(paths(bearer(admin, t1), t1, productRole)).containsOnly(Outcome.ok());
  }

  // ------------------------------------------------------------------------------------------ the paths

  private List<Outcome> paths(String bearer, UUID tenant, UUID roleId) throws Exception {
    List<Outcome> outcomes = new ArrayList<>();
    outcomes.add(viaAssignments(bearer, tenant, roleId));
    outcomes.add(viaInvite(bearer, tenant, roleId));
    outcomes.add(viaBulk(bearer, tenant, roleId));
    return outcomes;
  }

  private Outcome viaAssignments(String bearer, UUID tenant, UUID roleId) throws Exception {
    UUID target = fx.user(account, tenant);
    return http(mvc.perform(post("/api/users/{id}/assignments", target).header(AUTHORIZATION, bearer)
        .contentType(MediaType.APPLICATION_JSON)
        .content("{\"roleId\":\"%s\",\"scopeType\":\"TENANT\",\"scopeId\":\"%s\"}".formatted(roleId, tenant)))
        .andReturn().getResponse());
  }

  private Outcome viaInvite(String bearer, UUID tenant, UUID roleId) throws Exception {
    return http(mvc.perform(post("/api/tenants/{t}/users", tenant).header(AUTHORIZATION, bearer)
        .contentType(MediaType.APPLICATION_JSON)
        .content("{\"email\":\"p-%s@example.test\",\"roles\":[{\"roleId\":\"%s\",\"scopeType\":\"TENANT\"}]}"
            .formatted(Ids.newId(), roleId)))
        .andReturn().getResponse());
  }

  private Outcome viaBulk(String bearer, UUID tenant, UUID roleId) throws Exception {
    String roleName = jdbc.sql("SELECT name FROM role WHERE id = :id").param("id", roleId).query(String.class)
        .single();
    String csv = "email,displayName,roleName\nb-%s@example.test,B,%s\n".formatted(Ids.newId(), roleName);
    MockHttpServletResponse submitted = mvc.perform(multipart("/api/tenants/{t}/users/bulk", tenant)
            .file(new MockMultipartFile("file", "u.csv", "text/csv", csv.getBytes(StandardCharsets.UTF_8)))
            .header(AUTHORIZATION, bearer))
        .andReturn().getResponse();
    if (submitted.getStatus() != 202) {
      return http(submitted);
    }
    UUID job = UUID.fromString(json.readTree(submitted.getContentAsString()).get("jobId").asText());
    JsonNode[] last = new JsonNode[1];
    await().atMost(Duration.ofSeconds(20)).pollInterval(Duration.ofMillis(100)).until(() -> {
      last[0] = json.readTree(jdbc.sql("""
              SELECT json_build_object('status', status, 'errors', errors)::text FROM bulk_invite_job WHERE id = :id""")
          .param("id", job).query(String.class).single());
      String status = last[0].get("status").asText();
      return status.equals("COMPLETED") || status.equals("FAILED");
    });
    if (last[0].get("status").asText().equals("COMPLETED")) {
      return Outcome.ok();
    }
    return Outcome.denied(last[0].get("errors").get(0).get("code").asText());
  }

  private Outcome http(MockHttpServletResponse response) throws Exception {
    int status = response.getStatus();
    if (status == 200 || status == 201) {
      return Outcome.ok();
    }
    return Outcome.denied(json.readTree(response.getContentAsString()).get("code").asText());
  }

  // ------------------------------------------------------------------------------------------ helpers

  private UUID role(String... permissions) {
    return fx.customRole(Product.IAM_ID, account,
        java.util.Arrays.stream(permissions).map(p -> fx.permission(Product.IAM_ID, p)).toArray(UUID[]::new));
  }

  private String bearer(UUID user, UUID tenant) {
    return tokens.user(user).account(account).tenant(tenant)
        .perms(resolver.resolve(user, tenant).toArray(String[]::new)).bearer();
  }
}
