package com.acme.iam.auth;

import static org.assertj.core.api.Assertions.assertThat;

import com.acme.iam.common.error.ApiException;
import com.acme.iam.common.test.PostgresTestBase;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.CyclicBarrier;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.RepeatedTest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.simple.JdbcClient;

/** Race claims of the session and login code, exercised with real parallel transactions. */
@AuthIT
class AuthConcurrencyIT extends PostgresTestBase {

  @Autowired JdbcClient jdbc;
  @Autowired PasswordService passwords;
  @Autowired LoginService loginService;
  @Autowired SessionService sessionService;

  /**
   * R30 (strict reuse): two refreshes with the same token race; one wins (rotation), the other then finds only the
   * previous hash, which is reuse: it gets 401 and the session is revoked.
   */
  @RepeatedTest(3)
  void twoParallelRefreshesWithTheSameTokenLeaveExactlyOneSuccessAndARevokedSession() throws Exception {
    AuthTestData data = new AuthTestData(jdbc, passwords);
    AuthTestData.TestUser u = data.user();
    AuthTokens login = loginService.login(new LoginCommand(u.email(), u.password(), null), ClientInfo.UNKNOWN);

    List<Object> results = race(2, () -> sessionService.refresh(login.refreshToken(), ClientInfo.UNKNOWN));

    assertThat(results).filteredOn(AuthTokens.class::isInstance).hasSize(1);
    assertThat(results).filteredOn(ApiException.class::isInstance).singleElement()
        .satisfies(e -> assertThat(((ApiException) e).code()).isEqualTo(AuthErrors.INVALID_REFRESH_TOKEN));
    assertThat(data.sessionsOf(u.userId())).singleElement()
        .satisfies(s -> assertThat(s.get("revoked_at")).isNotNull());
    assertThat(data.revocationReasons(u.userId())).containsExactly(SessionService.REASON_REUSE);
  }

  /** N parallel wrong passwords: the user ends up locked and {@code auth.locked} is audited exactly once. */
  @Test
  void parallelBadLoginsLockTheUserAndAuditTheLockExactlyOnce() throws Exception {
    AuthTestData data = new AuthTestData(jdbc, passwords);
    AuthTestData.TestUser u = data.user();

    List<Object> results = race(8,
        () -> loginService.login(new LoginCommand(u.email(), "Wrong-Password-1", null), ClientInfo.UNKNOWN));

    assertThat(results).allSatisfy(r -> assertThat(r).isInstanceOfSatisfying(ApiException.class,
        e -> assertThat(e.code()).isEqualTo(AuthErrors.INVALID_CREDENTIALS)));
    assertThat(jdbc.sql("SELECT locked_until > now() FROM app_user WHERE id = :id").param("id", u.userId())
        .query(Boolean.class).single()).isTrue();
    assertThat(jdbc.sql("SELECT count(*) FROM audit_event WHERE action = 'auth.locked' AND target_id = :id")
        .param("id", u.userId().toString()).query(Long.class).single()).isEqualTo(1);
    assertThat(jdbc.sql("SELECT count(*) FROM audit_event WHERE action = 'auth.login.failed' AND target_id = :id")
        .param("id", u.userId().toString()).query(Long.class).single()).isEqualTo(8);
  }

  /** Runs {@code n} copies of {@code task} released together; returns each result or the exception it threw. */
  private static List<Object> race(int n, Callable<Object> task) throws Exception {
    ExecutorService pool = Executors.newFixedThreadPool(n);
    try {
      CyclicBarrier start = new CyclicBarrier(n);
      List<Future<Object>> futures = new ArrayList<>();
      for (int i = 0; i < n; i++) {
        futures.add(pool.submit(() -> {
          start.await(10, TimeUnit.SECONDS);
          try {
            return task.call();
          } catch (ApiException e) {
            return e;
          }
        }));
      }
      List<Object> results = new ArrayList<>();
      for (Future<Object> future : futures) {
        results.add(future.get(60, TimeUnit.SECONDS));
      }
      return results;
    } finally {
      pool.shutdownNow();
    }
  }
}
