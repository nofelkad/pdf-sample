package com.acme.iam.user;

import static org.assertj.core.api.Assertions.assertThat;
import static org.awaitility.Awaitility.await;
import static org.springframework.http.HttpHeaders.AUTHORIZATION;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;

import com.acme.iam.common.Ids;
import com.acme.iam.common.test.Fixtures;
import com.acme.iam.common.test.IntegrationTest;
import com.acme.iam.common.test.OrgTestData;
import com.acme.iam.common.test.PostgresTestBase;
import com.acme.iam.common.test.TestTokens;
import com.zaxxer.hikari.HikariDataSource;
import io.micrometer.core.instrument.MeterRegistry;
import java.time.Duration;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Import;
import org.springframework.context.annotation.Primary;
import org.springframework.http.MediaType;
import org.springframework.jdbc.core.simple.JdbcClient;
import org.springframework.test.web.servlet.MockMvc;

/**
 * Final review I2: an invitation email is sent off the request thread. While the mail server hangs, the invite request
 * has already answered and holds no database connection; the send completes later and is counted.
 */
@IntegrationTest
@AutoConfigureMockMvc
@Import(InvitationMailIsolationIT.SlowMailConfig.class)
class InvitationMailIsolationIT extends PostgresTestBase {

  /** A mail server that hangs until released. */
  static class SlowNotificationPort implements NotificationPort {
    final CountDownLatch release = new CountDownLatch(1);
    final CountDownLatch entered = new CountDownLatch(1);
    final List<String> delivered = new CopyOnWriteArrayList<>();

    @Override
    public void sendInvitation(String email, String accountName, String rawToken) {
      entered.countDown();
      try {
        release.await(30, TimeUnit.SECONDS);
      } catch (InterruptedException e) {
        Thread.currentThread().interrupt();
        return;
      }
      delivered.add(email);
    }

    @Override
    public void sendPasswordReset(String email, String rawToken) {}
  }

  @TestConfiguration(proxyBeanMethods = false)
  static class SlowMailConfig {
    @Bean
    @Primary
    SlowNotificationPort slowNotificationPort() {
      return new SlowNotificationPort();
    }
  }

  @Autowired MockMvc mvc;
  @Autowired TestTokens tokens;
  @Autowired JdbcClient jdbc;
  @Autowired HikariDataSource dataSource;
  @Autowired SlowNotificationPort mail;
  @Autowired MeterRegistry meters;

  @AfterEach
  void release() {
    mail.release.countDown();
  }

  @Test
  void aHangingMailServerHoldsNeitherTheRequestNorADatabaseConnection() throws Exception {
    OrgTestData org = new OrgTestData(jdbc);
    Fixtures fx = org.fixtures();
    Fixtures.Scenario s = fx.scenario();
    UUID admin = org.accountAdmin(s.accountId(), s.tenantId());
    String email = "slow-" + Ids.newId() + "@example.test";
    double sentBefore = meters.counter(InvitationMailer.SENT_METRIC).count();

    long started = System.nanoTime();
    int status = mvc.perform(post("/api/tenants/{t}/users", s.tenantId())
            .header(AUTHORIZATION, org.adminBearer(tokens, admin, s.accountId(), s.tenantId()))
            .contentType(MediaType.APPLICATION_JSON).content("{\"email\":\"" + email + "\"}"))
        .andReturn().getResponse().getStatus();
    Duration took = Duration.ofNanos(System.nanoTime() - started);

    assertThat(status).isEqualTo(201);
    assertThat(took).as("the request does not wait for the mail server").isLessThan(Duration.ofSeconds(5));
    assertThat(mail.entered.await(10, TimeUnit.SECONDS)).as("the send started").isTrue();
    assertThat(mail.delivered).isEmpty();
    assertThat(dataSource.getHikariPoolMXBean().getActiveConnections())
        .as("no connection is held while the send hangs").isZero();

    mail.release.countDown();
    await().atMost(Duration.ofSeconds(10)).until(() -> mail.delivered.contains(email));
    await().atMost(Duration.ofSeconds(5))
        .until(() -> meters.counter(InvitationMailer.SENT_METRIC).count() >= sentBefore + 1);
  }
}
