package com.acme.iam.common.openapi;

import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;

import com.acme.iam.common.test.IntegrationTest;
import com.acme.iam.common.test.PostgresTestBase;
import java.util.Properties;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.config.YamlPropertiesFactoryBean;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.core.io.ClassPathResource;
import org.springframework.test.web.servlet.MockMvc;

/** P1-11.6: the OpenAPI document and Swagger UI are served in the dev profile only. */
@IntegrationTest
@AutoConfigureMockMvc
class OpenApiDevOnlyIT extends PostgresTestBase {

  @Autowired MockMvc mvc;

  @Test
  void withTheDefaultConfigurationNeitherTheDocumentNorTheUiIsServed() throws Exception {
    for (String path : new String[] {"/v3/api-docs", "/v3/api-docs.yaml", "/swagger-ui.html", "/swagger-ui/index.html"}) {
      int status = mvc.perform(get(path)).andReturn().getResponse().getStatus();
      assertThat(status).as(path).isIn(401, 404);
    }
  }

  @Test
  void onlyTheDevProfileSwitchesSpringdocOn() {
    Properties base = yaml("application.yml");
    Properties dev = yaml("application-dev.yml");

    assertThat(base.getProperty("springdoc.api-docs.enabled")).isEqualTo("false");
    assertThat(base.getProperty("springdoc.swagger-ui.enabled")).isEqualTo("false");
    assertThat(dev.getProperty("springdoc.api-docs.enabled")).isEqualTo("true");
    assertThat(dev.getProperty("springdoc.swagger-ui.enabled")).isEqualTo("true");
  }

  private static Properties yaml(String name) {
    YamlPropertiesFactoryBean factory = new YamlPropertiesFactoryBean();
    factory.setResources(new ClassPathResource(name));
    return factory.getObject();
  }
}
