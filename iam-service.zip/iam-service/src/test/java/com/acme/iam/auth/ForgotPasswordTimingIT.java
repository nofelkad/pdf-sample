package com.acme.iam.auth;

import static org.assertj.core.api.Assertions.assertThat;

import com.acme.iam.common.test.IntegrationTest;
import com.acme.iam.common.test.PostgresTestBase;
import com.acme.iam.user.NotificationPort;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicReference;
import org.awaitility.Awaitility;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Import;
import org.springframework.context.annotation.Primary;
import org.springframework.jdbc.core.simple.JdbcClient;

/**
 * R31: {@code forgot} for a known email must cost the same on the request path as for an unknown one, even when
 * sending mail is slow (stub: 200 ms per mail). Token issue and mail run off the request thread, so the medians stay
 * together; with synchronous mail the known median would be 200 ms higher.
 *
 * <p>The request path is only a few milliseconds, so the tolerance is 10% of the slower median or 5 ms, whichever is
 * larger (pure relative bounds on ~3 ms medians would measure scheduler noise, not the oracle).
 */
@IntegrationTest
@Import({ForgotPasswordTimingIT.SlowMail.class, AuthTestData.Config.class})
@Tag("timing")
class ForgotPasswordTimingIT extends PostgresTestBase {

  static final int WARM_UP = 8;
  static final int ROUNDS = 30;
  static final long MAIL_MILLIS = 200;

  /** A mail adapter that takes {@value #MAIL_MILLIS} ms per mail. */
  @TestConfiguration(proxyBeanMethods = false)
  static class SlowMail {
    static final AtomicInteger RESETS_SENT = new AtomicInteger();
    /** When set, a reset mail to {@code GATED_EMAIL} blocks until the latch opens (max 20 s). */
    static final AtomicReference<String> GATED_EMAIL = new AtomicReference<>();
    static final AtomicReference<CountDownLatch> GATE = new AtomicReference<>();

    @Bean
    @Primary
    NotificationPort slowNotificationPort() {
      return new NotificationPort() {
        @Override
        public void sendInvitation(String email, String accountName, String rawToken) {
          sleep();
        }

        @Override
        public void sendPasswordReset(String email, String rawToken) {
          CountDownLatch gate = GATE.get();
          if (gate != null && email.equalsIgnoreCase(GATED_EMAIL.get())) {
            try {
              gate.await(20, TimeUnit.SECONDS);
            } catch (InterruptedException e) {
              Thread.currentThread().interrupt();
            }
          }
          sleep();
          RESETS_SENT.incrementAndGet();
        }

        private void sleep() {
          try {
            Thread.sleep(MAIL_MILLIS);
          } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
          }
        }
      };
    }
  }

  @Autowired JdbcClient jdbc;
  @Autowired PasswordService passwords;
  @Autowired PasswordFlowService passwordFlows;

  @Test
  void knownAndUnknownEmailsTakeTheSameTimeOnTheRequestPath() {
    AuthTestData.TestUser known = new AuthTestData(jdbc, passwords).user();
    String unknown = "nobody-" + UUID.randomUUID() + "@example.test";
    int sentBefore = SlowMail.RESETS_SENT.get();

    for (int i = 0; i < WARM_UP; i++) {
      attempt(known.email());
      attempt(unknown);
    }
    List<Long> knownTimes = new ArrayList<>();
    List<Long> unknownTimes = new ArrayList<>();
    for (int i = 0; i < ROUNDS; i++) {
      if (i % 2 == 0) {
        knownTimes.add(attempt(known.email()));
        unknownTimes.add(attempt(unknown));
      } else {
        unknownTimes.add(attempt(unknown));
        knownTimes.add(attempt(known.email()));
      }
    }

    double knownMedian = median(knownTimes);
    double unknownMedian = median(unknownTimes);
    double tolerance = Math.max(0.10 * Math.max(knownMedian, unknownMedian), 5e6);
    System.out.printf("forgot timing: median known=%.2f ms, unknown=%.2f ms (tolerance %.2f ms)%n",
        knownMedian / 1e6, unknownMedian / 1e6, tolerance / 1e6);
    assertThat(Math.abs(knownMedian - unknownMedian))
        .as("median known=%.2f ms, unknown=%.2f ms", knownMedian / 1e6, unknownMedian / 1e6)
        .isLessThanOrEqualTo(tolerance);
    // the known requests really did produce mails, just not on the request thread
    Awaitility.await().atMost(Duration.ofSeconds(30))
        .until(() -> SlowMail.RESETS_SENT.get() > sentBefore);
  }

  /**
   * Structural check (the 5 ms timing floor could not see token issue moving back onto the request path): with the
   * worker pinned in a blocked mail send, {@code forgot()} for another known user returns without any
   * {@code PASSWORD_RESET} token having been issued for that user; the token appears once the send is released.
   */
  @Test
  void theResetTokenIsIssuedOffTheRequestPath() {
    AuthTestData data = new AuthTestData(jdbc, passwords);
    AuthTestData.TestUser pinned = data.user();
    AuthTestData.TestUser other = data.user();
    CountDownLatch gate = new CountDownLatch(1);
    SlowMail.GATED_EMAIL.set(pinned.email());
    SlowMail.GATE.set(gate);
    try {
      passwordFlows.forgot(pinned.email(), null, ClientInfo.UNKNOWN);
      // the worker issued the pinned user's token and is now blocked in its mail send
      Awaitility.await().atMost(Duration.ofSeconds(30)).until(() -> resetTokens(pinned) == 1);

      passwordFlows.forgot(other.email(), null, ClientInfo.UNKNOWN);

      assertThat(resetTokens(other)).as("no token issued on the request path").isZero();
    } finally {
      SlowMail.GATE.set(null);
      gate.countDown();
    }
    Awaitility.await().atMost(Duration.ofSeconds(30)).until(() -> resetTokens(other) == 1);
  }

  private long resetTokens(AuthTestData.TestUser user) {
    return jdbc.sql("SELECT count(*) FROM user_token WHERE user_id = :id AND purpose = 'PASSWORD_RESET'")
        .param("id", user.userId()).query(Long.class).single();
  }

  private long attempt(String email) {
    long start = System.nanoTime();
    passwordFlows.forgot(email, null, ClientInfo.UNKNOWN);
    return System.nanoTime() - start;
  }

  private static double median(List<Long> values) {
    List<Long> sorted = values.stream().sorted().toList();
    int n = sorted.size();
    return n % 2 == 1 ? sorted.get(n / 2) : (sorted.get(n / 2 - 1) + sorted.get(n / 2)) / 2.0;
  }
}
