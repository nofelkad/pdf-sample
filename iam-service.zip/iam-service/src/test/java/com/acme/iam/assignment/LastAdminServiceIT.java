package com.acme.iam.assignment;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

import com.acme.iam.account.AccountKind;
import com.acme.iam.account.AccountStatus;
import com.acme.iam.common.error.ConflictException;
import com.acme.iam.common.test.Fixtures;
import com.acme.iam.common.test.IntegrationTest;
import com.acme.iam.common.test.PostgresTestBase;
import com.acme.iam.product.Product;
import com.acme.iam.role.Role;
import com.acme.iam.user.UserStatus;
import java.time.Duration;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.simple.JdbcClient;
import org.springframework.transaction.IllegalTransactionStateException;
import org.springframework.transaction.support.TransactionTemplate;

/** Invariant I7: the last active Account Admin (Platform Admin in the PLATFORM account) cannot be removed. */
@IntegrationTest
class LastAdminServiceIT extends PostgresTestBase {

  @Autowired LastAdminService lastAdmin;
  @Autowired JdbcClient jdbc;
  @Autowired TransactionTemplate tx;

  private Fixtures fx;
  private UUID accountAdmin;
  private UUID platformAdmin;

  @BeforeEach
  void setUp() {
    fx = new Fixtures(jdbc);
    accountAdmin = fx.systemRole(Product.IAM_ID, Role.ACCOUNT_ADMIN);
    platformAdmin = fx.systemRole(Product.IAM_ID, Role.PLATFORM_ADMIN);
  }

  @Test
  void lastAdminCannotBeDisabled() {
    Fixtures.Scenario s = fx.scenario();
    fx.assign(s.userId(), accountAdmin, ScopeType.ACCOUNT, s.accountId());

    assertThatThrownBy(() -> inTx(() -> lastAdmin.requireNotLastAdmin(s.accountId(), s.userId())))
        .isInstanceOfSatisfying(ConflictException.class, e -> assertThat(e.code()).isEqualTo("last_admin"));
  }

  @Test
  void oneOfTwoAdminsCanBeDisabled() {
    Fixtures.Scenario s = fx.scenario();
    UUID other = fx.user(s.accountId(), s.tenantId());
    fx.assign(s.userId(), accountAdmin, ScopeType.ACCOUNT, s.accountId());
    fx.assign(other, accountAdmin, ScopeType.ACCOUNT, s.accountId());

    inTx(() -> lastAdmin.requireNotLastAdmin(s.accountId(), s.userId()));
  }

  @Test
  void invitedOrExpiredAdminsDoNotCount() {
    Fixtures.Scenario s = fx.scenario();
    UUID invited = fx.user(s.accountId(), s.tenantId(), UserStatus.INVITED);
    UUID expired = fx.user(s.accountId(), s.tenantId());
    fx.assign(s.userId(), accountAdmin, ScopeType.ACCOUNT, s.accountId());
    fx.assign(invited, accountAdmin, ScopeType.ACCOUNT, s.accountId());
    fx.assign(expired, accountAdmin, ScopeType.ACCOUNT, s.accountId(), Instant.now().minusSeconds(60));

    assertThatThrownBy(() -> inTx(() -> lastAdmin.requireNotLastAdmin(s.accountId(), s.userId())))
        .isInstanceOf(ConflictException.class);
  }

  /**
   * Ruling R43 (final review I5b): a grant that expires does not keep the account administrable, so it does not count
   * as "another admin": the holder of the only permanent grant cannot remove it or be disabled.
   */
  @Test
  void anExpiringAdminGrantDoesNotCountAsAnotherAdmin() {
    Fixtures.Scenario s = fx.scenario();
    UUID permanent = fx.assign(s.userId(), accountAdmin, ScopeType.ACCOUNT, s.accountId());
    UUID temporary = fx.user(s.accountId(), s.tenantId());
    fx.assign(temporary, accountAdmin, ScopeType.ACCOUNT, s.accountId(), Instant.now().plus(Duration.ofDays(1)));

    assertThatThrownBy(() -> inTx(() -> lastAdmin.requireNotLastAdminAssignment(permanent)))
        .isInstanceOfSatisfying(ConflictException.class, e -> assertThat(e.code()).isEqualTo("last_admin"));
    assertThatThrownBy(() -> inTx(() -> lastAdmin.requireNotLastAdmin(s.accountId(), s.userId())))
        .isInstanceOfSatisfying(ConflictException.class, e -> assertThat(e.code()).isEqualTo("last_admin"));
  }

  @Test
  void theHolderOfOnlyAnExpiringGrantIsNotProtectedAndAPermanentSecondAdminFreesTheFirst() {
    Fixtures.Scenario s = fx.scenario();
    UUID permanent = fx.assign(s.userId(), accountAdmin, ScopeType.ACCOUNT, s.accountId());
    UUID temporary = fx.user(s.accountId(), s.tenantId());
    UUID temporaryGrant = fx.assign(temporary, accountAdmin, ScopeType.ACCOUNT, s.accountId(),
        Instant.now().plus(Duration.ofDays(1)));

    inTx(() -> lastAdmin.requireNotLastAdmin(s.accountId(), temporary));
    inTx(() -> lastAdmin.requireNotLastAdminAssignment(temporaryGrant));

    fx.assign(fx.user(s.accountId(), s.tenantId()), accountAdmin, ScopeType.ACCOUNT, s.accountId());
    inTx(() -> lastAdmin.requireNotLastAdminAssignment(permanent));
  }

  @Test
  void nonAdminsAndTenantScopedAdminsAreNotProtected() {
    Fixtures.Scenario s = fx.scenario();
    UUID tenantScoped = fx.user(s.accountId(), s.tenantId());
    fx.assign(tenantScoped, accountAdmin, ScopeType.TENANT, s.tenantId());

    inTx(() -> lastAdmin.requireNotLastAdmin(s.accountId(), s.userId()));
    inTx(() -> lastAdmin.requireNotLastAdmin(s.accountId(), tenantScoped));
  }

  @Test
  void platformAccountUsesPlatformAdmin() {
    UUID platform = fx.account(AccountKind.PLATFORM, AccountStatus.ACTIVE);
    UUID tenant = fx.tenant(platform);
    UUID operator = fx.user(platform, tenant);
    UUID accountAdminOnly = fx.user(platform, tenant);
    fx.assign(operator, platformAdmin, ScopeType.ACCOUNT, platform);
    fx.assign(accountAdminOnly, accountAdmin, ScopeType.ACCOUNT, platform);

    assertThatThrownBy(() -> inTx(() -> lastAdmin.requireNotLastAdmin(platform, operator)))
        .isInstanceOf(ConflictException.class);
    inTx(() -> lastAdmin.requireNotLastAdmin(platform, accountAdminOnly));
  }

  @Test
  void assignmentLevelCheck() {
    Fixtures.Scenario s = fx.scenario();
    UUID onlyAdminGrant = fx.assign(s.userId(), accountAdmin, ScopeType.ACCOUNT, s.accountId());
    UUID otherRoleGrant = fx.assign(s.userId(), fx.systemRole(Product.IAM_ID), ScopeType.ACCOUNT, s.accountId());

    assertThatThrownBy(() -> inTx(() -> lastAdmin.requireNotLastAdminAssignment(onlyAdminGrant)))
        .isInstanceOfSatisfying(ConflictException.class, e -> assertThat(e.code()).isEqualTo("last_admin"));
    inTx(() -> lastAdmin.requireNotLastAdminAssignment(otherRoleGrant));
    inTx(() -> lastAdmin.requireNotLastAdminAssignment(UUID.randomUUID())); // unknown: nothing to protect

    UUID second = fx.user(s.accountId(), s.tenantId());
    UUID secondGrant = fx.assign(second, accountAdmin, ScopeType.ACCOUNT, s.accountId());
    inTx(() -> lastAdmin.requireNotLastAdminAssignment(onlyAdminGrant));

    UUID expiredGrant = fx.assign(fx.user(s.accountId(), s.tenantId()), accountAdmin, ScopeType.ACCOUNT,
        s.accountId(), Instant.now().minusSeconds(60));
    inTx(() -> lastAdmin.requireNotLastAdminAssignment(expiredGrant));
    assertThat(secondGrant).isNotNull();
  }

  @Test
  void accountThatIsNotTheUsersAccountIsRejectedInsteadOfBypassingI7() {
    Fixtures.Scenario s = fx.scenario();
    fx.assign(s.userId(), accountAdmin, ScopeType.ACCOUNT, s.accountId());
    UUID otherAccount = fx.account();

    assertThatThrownBy(() -> inTx(() -> lastAdmin.requireNotLastAdmin(otherAccount, s.userId())))
        .isInstanceOf(IllegalArgumentException.class)
        .hasMessageContaining("does not belong to account");
  }

  @Test
  void requiresATransaction() {
    Fixtures.Scenario s = fx.scenario();

    assertThatThrownBy(() -> lastAdmin.requireNotLastAdmin(s.accountId(), s.userId()))
        .isInstanceOf(IllegalTransactionStateException.class);
  }

  @Test
  void concurrentDisablesOfTheLastTwoAdminsCannotBothSucceed() throws Exception {
    Fixtures.Scenario s = fx.scenario();
    UUID a = s.userId();
    UUID b = fx.user(s.accountId(), s.tenantId());
    fx.assign(a, accountAdmin, ScopeType.ACCOUNT, s.accountId());
    fx.assign(b, accountAdmin, ScopeType.ACCOUNT, s.accountId());
    CountDownLatch aChecked = new CountDownLatch(1);
    CountDownLatch bWaiting = new CountDownLatch(1);
    List<String> outcomes = Collections.synchronizedList(new ArrayList<>());

    CompletableFuture<Void> disableA = CompletableFuture.runAsync(() -> outcomes.add(disable(s.accountId(), a, () -> {
      aChecked.countDown();
      await(bWaiting);
    })));
    await(aChecked);
    CompletableFuture<Void> disableB = CompletableFuture.runAsync(() -> outcomes.add(disable(s.accountId(), b, () -> { })));
    waitUntilSomeoneWaitsOnALock();
    bWaiting.countDown();

    disableA.get(30, TimeUnit.SECONDS);
    disableB.get(30, TimeUnit.SECONDS);
    assertThat(outcomes).containsExactlyInAnyOrder("disabled", "last_admin");
    assertThat(jdbc.sql("SELECT count(*) FROM app_user WHERE id IN (?, ?) AND status = 'ACTIVE'").params(a, b)
        .query(Long.class).single()).isEqualTo(1L);
  }

  /** Check + status update in one transaction, like UserService.disable will do. */
  private String disable(UUID account, UUID user, Runnable afterCheck) {
    try {
      tx.executeWithoutResult(s -> {
        lastAdmin.requireNotLastAdmin(account, user);
        afterCheck.run();
        jdbc.sql("UPDATE app_user SET status = 'DISABLED' WHERE id = ?").params(user).update();
      });
      return "disabled";
    } catch (ConflictException e) {
      return e.code();
    }
  }

  private void inTx(Runnable check) {
    tx.executeWithoutResult(s -> check.run());
  }

  /**
   * Gives the second disable time to reach the account lock (returns as soon as it waits). Without a lock it would
   * not wait; the outcome assertion then shows both disables succeeding.
   */
  private void waitUntilSomeoneWaitsOnALock() throws InterruptedException {
    Instant deadline = Instant.now().plus(Duration.ofSeconds(3));
    while (Instant.now().isBefore(deadline)) {
      if (jdbc.sql("SELECT count(*) FROM pg_locks WHERE NOT granted").query(Long.class).single() > 0) {
        return;
      }
      Thread.sleep(20);
    }
  }

  private static void await(CountDownLatch latch) {
    try {
      if (!latch.await(30, TimeUnit.SECONDS)) {
        throw new IllegalStateException("latch timeout");
      }
    } catch (InterruptedException e) {
      Thread.currentThread().interrupt();
      throw new IllegalStateException(e);
    }
  }
}
