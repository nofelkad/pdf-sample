package com.acme.iam.assignment;

import static org.assertj.core.api.Assertions.assertThat;

import com.acme.iam.account.AccountStatus;
import com.acme.iam.account.SubscriptionStatus;
import com.acme.iam.common.test.Fixtures;
import com.acme.iam.common.test.JdbcSliceTest;
import com.acme.iam.common.test.PostgresTestBase;
import com.acme.iam.product.Product;
import com.acme.iam.tenant.TenantStatus;
import com.acme.iam.user.MembershipStatus;
import java.time.Instant;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.Set;
import java.util.UUID;
import java.util.stream.Collectors;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Import;
import org.springframework.jdbc.core.simple.JdbcClient;

/**
 * P1-7.4: {@link PermissionResolver} (spec section 5 query). Each case starts from a fully entitled baseline (ACTIVE
 * account, tenant, membership; a non-IAM product subscribed ACTIVE and enabled in the tenant; one IAM and one product
 * permission in a role) and changes exactly one thing.
 */
@JdbcSliceTest
@Import(PermissionResolver.class)
class PermissionResolverTest extends PostgresTestBase {

  @Autowired PermissionResolver resolver;
  @Autowired JdbcClient jdbc;

  Fixtures fx;
  Fixtures.Scenario s;
  UUID product;
  UUID iamPerm;
  UUID productPerm;
  String iamCode;
  String productCode;
  UUID role;

  @BeforeEach
  void baseline() {
    fx = new Fixtures(jdbc);
    s = fx.scenario();
    product = fx.entitledProduct(s.accountId(), s.tenantId());
    iamPerm = fx.permission(Product.IAM_ID);
    productPerm = fx.permission(product);
    iamCode = fx.code(iamPerm);
    productCode = fx.code(productPerm);
    role = fx.systemRole(product, iamPerm, productPerm);
  }

  @Nested
  class Scope {

    @Test
    void tenantScopeAssignmentGrantsInThatTenant() {
      fx.assign(s.userId(), role, ScopeType.TENANT, s.tenantId());
      assertThat(resolver.resolve(s.userId(), s.tenantId())).containsExactlyInAnyOrder(iamCode, productCode);
    }

    @Test
    void tenantScopeAssignmentDoesNotLeakIntoAnotherTenant() {
      UUID other = fx.tenant(s.accountId());
      fx.membership(s.userId(), other, MembershipStatus.ACTIVE);
      fx.enableProduct(other, product, true);
      fx.assign(s.userId(), role, ScopeType.TENANT, s.tenantId());

      assertThat(resolver.resolve(s.userId(), other)).isEmpty();
    }

    @Test
    void accountScopeAssignmentGrantsInEveryTenantWithMembership() {
      UUID other = fx.tenant(s.accountId());
      fx.membership(s.userId(), other, MembershipStatus.ACTIVE);
      fx.enableProduct(other, product, true);
      fx.assign(s.userId(), role, ScopeType.ACCOUNT, s.accountId());

      assertThat(resolver.resolve(s.userId(), s.tenantId())).containsExactlyInAnyOrder(iamCode, productCode);
      assertThat(resolver.resolve(s.userId(), other)).containsExactlyInAnyOrder(iamCode, productCode);
    }

    @Test
    void accountScopeAssignmentOfAnotherAccountGrantsNothing() {
      fx.assign(s.userId(), role, ScopeType.ACCOUNT, fx.account());
      assertThat(resolver.resolve(s.userId(), s.tenantId())).isEmpty();
    }

    @Test
    void unionOfSeveralRolesIsDistinct() {
      UUID iamOnly = fx.systemRole(Product.IAM_ID, iamPerm);
      fx.assign(s.userId(), role, ScopeType.TENANT, s.tenantId());
      fx.assign(s.userId(), iamOnly, ScopeType.ACCOUNT, s.accountId());

      assertThat(resolver.resolve(s.userId(), s.tenantId())).containsExactlyInAnyOrder(iamCode, productCode);
    }
  }

  @Nested
  class Expiry {

    @Test
    void expiredAssignmentGrantsNothing() {
      fx.assign(s.userId(), role, ScopeType.TENANT, s.tenantId(), Instant.now().minus(1, ChronoUnit.MINUTES));
      assertThat(resolver.resolve(s.userId(), s.tenantId())).isEmpty();
    }

    @Test
    void assignmentExpiringInTheFutureGrants() {
      fx.assign(s.userId(), role, ScopeType.TENANT, s.tenantId(), Instant.now().plus(1, ChronoUnit.HOURS));
      assertThat(resolver.resolve(s.userId(), s.tenantId())).containsExactlyInAnyOrder(iamCode, productCode);
    }
  }

  @Nested
  class Entitlement {

    @BeforeEach
    void assign() {
      fx.assign(s.userId(), role, ScopeType.TENANT, s.tenantId());
    }

    @Test
    void disabledTenantProductDropsThatProductOnly() {
      fx.enableProduct(s.tenantId(), product, false);
      assertThat(resolver.resolve(s.userId(), s.tenantId())).containsExactly(iamCode);
    }

    @Test
    void missingTenantProductDropsThatProduct() {
      jdbc.sql("DELETE FROM tenant_product WHERE tenant = :t").param("t", s.tenantId()).update();
      assertThat(resolver.resolve(s.userId(), s.tenantId())).containsExactly(iamCode);
    }

    @Test
    void expiredSubscriptionDropsThatProduct() {
      fx.subscribe(s.accountId(), product, SubscriptionStatus.ACTIVE, LocalDate.now().minusDays(1));
      assertThat(resolver.resolve(s.userId(), s.tenantId())).containsExactly(iamCode);
    }

    @Test
    void subscriptionEndingTodayStillEntitles() {
      fx.subscribe(s.accountId(), product, SubscriptionStatus.ACTIVE, LocalDate.now());
      assertThat(resolver.resolve(s.userId(), s.tenantId())).containsExactlyInAnyOrder(iamCode, productCode);
    }

    @Test
    void trialSubscriptionEntitles() {
      fx.subscribe(s.accountId(), product, SubscriptionStatus.TRIAL, null);
      assertThat(resolver.resolve(s.userId(), s.tenantId())).containsExactlyInAnyOrder(iamCode, productCode);
    }

    @Test
    void suspendedOrExpiredSubscriptionStatusDropsThatProduct() {
      fx.subscribe(s.accountId(), product, SubscriptionStatus.SUSPENDED, null);
      assertThat(resolver.resolve(s.userId(), s.tenantId())).containsExactly(iamCode);
      fx.subscribe(s.accountId(), product, SubscriptionStatus.EXPIRED, null);
      assertThat(resolver.resolve(s.userId(), s.tenantId())).containsExactly(iamCode);
    }

    @Test
    void iamIsAlwaysEntitledWithoutSubscriptionOrTenantSwitch() {
      UUID bareAccount = fx.account();
      UUID bareTenant = fx.tenant(bareAccount);
      UUID bareUser = fx.user(bareAccount, bareTenant);
      fx.assign(bareUser, role, ScopeType.TENANT, bareTenant);

      assertThat(resolver.resolve(bareUser, bareTenant)).containsExactly(iamCode);
    }

    @Test
    void deprecatedPermissionIsNeverGranted() {
      fx.deprecate(productPerm);
      fx.deprecate(iamPerm);
      assertThat(resolver.resolve(s.userId(), s.tenantId())).isEmpty();
    }
  }

  @Nested
  class Status {

    @BeforeEach
    void assign() {
      fx.assign(s.userId(), role, ScopeType.ACCOUNT, s.accountId());
    }

    @Test
    void baselineGrants() {
      assertThat(resolver.resolve(s.userId(), s.tenantId())).containsExactlyInAnyOrder(iamCode, productCode);
    }

    @Test
    void suspendedTenantGrantsNothing() {
      fx.tenantStatus(s.tenantId(), TenantStatus.SUSPENDED);
      assertThat(resolver.resolve(s.userId(), s.tenantId())).isEmpty();
    }

    @Test
    void suspendedAccountGrantsNothing() {
      fx.accountStatus(s.accountId(), AccountStatus.SUSPENDED);
      assertThat(resolver.resolve(s.userId(), s.tenantId())).isEmpty();
    }

    @Test
    void inactiveMembershipGrantsNothing() {
      fx.membership(s.userId(), s.tenantId(), MembershipStatus.SUSPENDED);
      assertThat(resolver.resolve(s.userId(), s.tenantId())).isEmpty();
    }

    @Test
    void missingMembershipGrantsNothingEvenWithAccountScope() {
      UUID other = fx.tenant(s.accountId());
      fx.enableProduct(other, product, true);
      assertThat(resolver.resolve(s.userId(), other)).isEmpty();
    }

    @Test
    void unknownTenantGrantsNothing() {
      assertThat(resolver.resolve(s.userId(), UUID.randomUUID())).isEmpty();
    }
  }

  @Nested
  class Explain {

    @Test
    void explainUsesTheSamePredicateAsResolve() {
      UUID iamOnly = fx.systemRole(Product.IAM_ID, iamPerm);
      UUID expired = fx.systemRole(product, fx.permission(product));
      fx.assign(s.userId(), role, ScopeType.TENANT, s.tenantId());
      fx.assign(s.userId(), iamOnly, ScopeType.ACCOUNT, s.accountId());
      fx.assign(s.userId(), expired, ScopeType.TENANT, s.tenantId(), Instant.now().minusSeconds(1));

      var grants = resolver.explain(s.userId(), s.tenantId());

      assertThat(grants).extracting(PermissionGrant::permission, PermissionGrant::roleId, PermissionGrant::scopeType,
              PermissionGrant::scopeId)
          .containsExactlyInAnyOrder(
              org.assertj.core.groups.Tuple.tuple(iamCode, role, ScopeType.TENANT, s.tenantId()),
              org.assertj.core.groups.Tuple.tuple(productCode, role, ScopeType.TENANT, s.tenantId()),
              org.assertj.core.groups.Tuple.tuple(iamCode, iamOnly, ScopeType.ACCOUNT, s.accountId()));
      assertThat(grants).allSatisfy(g -> assertThat(g.roleName()).isNotBlank());
      Set<String> explained = grants.stream().map(PermissionGrant::permission).collect(Collectors.toSet());
      assertThat(explained).isEqualTo(resolver.resolve(s.userId(), s.tenantId()));
    }

    @Test
    void explainIsEmptyWhenResolveIsEmpty() {
      fx.assign(s.userId(), role, ScopeType.TENANT, s.tenantId());
      fx.tenantStatus(s.tenantId(), TenantStatus.SUSPENDED);
      assertThat(resolver.explain(s.userId(), s.tenantId())).isEmpty();
    }
  }

  /**
   * Ruling R42 (final review I4): a DATA permission ending in {@code .account} means "every record of the account"
   * (iam-client's {@code DataScope}), so it is granted only through an ACCOUNT-scope assignment. A TENANT-scope grant
   * of it grants nothing, in {@code resolve} and {@code explain} alike; its {@code .tenant} sibling is unaffected.
   */
  @Nested
  class AccountDataPermissions {

    UUID readAccount;
    UUID readTenant;
    UUID featureAccount;
    UUID dataRole;

    @BeforeEach
    void dataPermissions() {
      String base = "test.r42" + UUID.randomUUID().toString().substring(0, 8) + ".read";
      readAccount = dataPermission(product, base + ".account", "DATA");
      readTenant = dataPermission(product, base + ".tenant", "DATA");
      featureAccount = dataPermission(product, "test.r42" + UUID.randomUUID().toString().substring(0, 8)
          + ".account", "FEATURE");
      dataRole = fx.systemRole(product, readAccount, readTenant, featureAccount);
    }

    @Test
    void aTenantScopeGrantOfADotAccountDataPermissionGrantsNothing() {
      fx.assign(s.userId(), dataRole, ScopeType.TENANT, s.tenantId());

      assertThat(resolver.resolve(s.userId(), s.tenantId()))
          .containsExactlyInAnyOrder(fx.code(readTenant), fx.code(featureAccount))
          .doesNotContain(fx.code(readAccount));
      assertThat(resolver.explain(s.userId(), s.tenantId())).extracting(PermissionGrant::permission)
          .doesNotContain(fx.code(readAccount));
    }

    @Test
    void anAccountScopeGrantOfItGrantsIt() {
      fx.assign(s.userId(), dataRole, ScopeType.ACCOUNT, s.accountId());

      assertThat(resolver.resolve(s.userId(), s.tenantId()))
          .containsExactlyInAnyOrder(fx.code(readAccount), fx.code(readTenant), fx.code(featureAccount));
    }

    @Test
    void explainEqualsResolveWithBothScopes() {
      UUID onlyAccount = fx.systemRole(product, readAccount);
      fx.assign(s.userId(), dataRole, ScopeType.TENANT, s.tenantId());
      fx.assign(s.userId(), onlyAccount, ScopeType.ACCOUNT, s.accountId());

      var grants = resolver.explain(s.userId(), s.tenantId());

      assertThat(grants.stream().map(PermissionGrant::permission).collect(Collectors.toSet()))
          .isEqualTo(resolver.resolve(s.userId(), s.tenantId()));
      assertThat(grants).filteredOn(g -> g.permission().equals(fx.code(readAccount)))
          .extracting(PermissionGrant::scopeType).containsExactly(ScopeType.ACCOUNT);
    }

    @Test
    void theGrantorViewAtATenantFollowsTheSameRule() {
      fx.assign(s.userId(), dataRole, ScopeType.TENANT, s.tenantId());
      assertThat(resolver.resolveGrantorAtTenant(s.userId(), s.tenantId())).doesNotContain(fx.code(readAccount));
    }

    private UUID dataPermission(UUID productId, String code, String kind) {
      UUID id = UUID.randomUUID();
      jdbc.sql("""
              INSERT INTO permission (id, product_id, code, kind, description, version)
              VALUES (:id, :p, :code, :kind, :code, 0)""")
          .param("id", id).param("p", productId).param("code", code).param("kind", kind).update();
      return id;
    }
  }

  /** R11: what a grantor holds at a tenant for I6. */
  @Nested
  class GrantorAtTenant {

    @Test
    void equalsResolveForAMember() {
      fx.assign(s.userId(), role, ScopeType.TENANT, s.tenantId());
      assertThat(resolver.resolveGrantorAtTenant(s.userId(), s.tenantId()))
          .isEqualTo(resolver.resolve(s.userId(), s.tenantId()))
          .containsExactlyInAnyOrder(iamCode, productCode);
    }

    @Test
    void accountScopeGrantsCountWithoutMembership() {
      UUID other = fx.tenant(s.accountId());
      fx.enableProduct(other, product, true);
      fx.assign(s.userId(), role, ScopeType.ACCOUNT, s.accountId());

      assertThat(resolver.resolve(s.userId(), other)).as("JWT resolution still needs a membership").isEmpty();
      assertThat(resolver.resolveGrantorAtTenant(s.userId(), other)).containsExactlyInAnyOrder(iamCode, productCode);
    }

    @Test
    void accountScopePartIsFilteredByTheTenantsEntitlement() {
      UUID other = fx.tenant(s.accountId());
      fx.enableProduct(other, product, false);
      fx.assign(s.userId(), role, ScopeType.ACCOUNT, s.accountId());
      assertThat(resolver.resolveGrantorAtTenant(s.userId(), other)).containsExactly(iamCode);

      fx.enableProduct(other, product, true);
      fx.subscribe(s.accountId(), product, SubscriptionStatus.ACTIVE, LocalDate.now().minusDays(1));
      assertThat(resolver.resolveGrantorAtTenant(s.userId(), other)).containsExactly(iamCode);
    }

    @Test
    void tenantScopeGrantsStillNeedAnActiveMembership() {
      fx.assign(s.userId(), role, ScopeType.TENANT, s.tenantId());
      fx.membership(s.userId(), s.tenantId(), MembershipStatus.SUSPENDED);
      assertThat(resolver.resolveGrantorAtTenant(s.userId(), s.tenantId())).isEmpty();
    }

    @Test
    void excludesExpiredDeprecatedInactiveTenantAndOtherAccounts() {
      UUID other = fx.tenant(s.accountId());
      fx.enableProduct(other, product, true);
      fx.assign(s.userId(), role, ScopeType.ACCOUNT, fx.account());
      assertThat(resolver.resolveGrantorAtTenant(s.userId(), other)).as("other account").isEmpty();

      fx.assign(s.userId(), role, ScopeType.ACCOUNT, s.accountId(), Instant.now().minusSeconds(1));
      assertThat(resolver.resolveGrantorAtTenant(s.userId(), other)).as("expired").isEmpty();

      UUID live = fx.systemRole(Product.IAM_ID, iamPerm);
      fx.assign(s.userId(), live, ScopeType.ACCOUNT, s.accountId());
      assertThat(resolver.resolveGrantorAtTenant(s.userId(), other)).containsExactly(iamCode);
      fx.tenantStatus(other, TenantStatus.SUSPENDED);
      assertThat(resolver.resolveGrantorAtTenant(s.userId(), other)).as("suspended tenant").isEmpty();
      fx.tenantStatus(other, TenantStatus.ACTIVE);
      fx.deprecate(iamPerm);
      assertThat(resolver.resolveGrantorAtTenant(s.userId(), other)).as("deprecated").isEmpty();
    }
  }

  @Nested
  class AccountScopeResolution {

    @Test
    void onlyAccountScopeAssignmentsCountAndNoMembershipIsNeeded() {
      UUID tenantOnly = fx.systemRole(Product.IAM_ID, fx.permission(Product.IAM_ID));
      fx.assign(s.userId(), tenantOnly, ScopeType.TENANT, s.tenantId());
      fx.assign(s.userId(), role, ScopeType.ACCOUNT, s.accountId());
      fx.removeMembership(s.userId(), s.tenantId());

      assertThat(resolver.resolveAccountScope(s.userId(), s.accountId()))
          .containsExactlyInAnyOrder(iamCode, productCode);
    }

    @Test
    void appliesSubscriptionEntitlementButNotTenantSwitches() {
      fx.assign(s.userId(), role, ScopeType.ACCOUNT, s.accountId());
      fx.enableProduct(s.tenantId(), product, false);
      assertThat(resolver.resolveAccountScope(s.userId(), s.accountId()))
          .containsExactlyInAnyOrder(iamCode, productCode);

      fx.subscribe(s.accountId(), product, SubscriptionStatus.EXPIRED, null);
      assertThat(resolver.resolveAccountScope(s.userId(), s.accountId())).containsExactly(iamCode);
    }

    @Test
    void excludesExpiredDeprecatedAndOtherAccounts() {
      UUID other = fx.account();
      fx.assign(s.userId(), role, ScopeType.ACCOUNT, other);
      assertThat(resolver.resolveAccountScope(s.userId(), s.accountId())).isEmpty();

      fx.assign(s.userId(), role, ScopeType.ACCOUNT, s.accountId(), Instant.now().minusSeconds(1));
      assertThat(resolver.resolveAccountScope(s.userId(), s.accountId())).isEmpty();

      UUID live = fx.systemRole(Product.IAM_ID, iamPerm);
      fx.assign(s.userId(), live, ScopeType.ACCOUNT, s.accountId());
      fx.deprecate(iamPerm);
      assertThat(resolver.resolveAccountScope(s.userId(), s.accountId())).isEmpty();
    }

    @Test
    void suspendedAccountGrantsNothing() {
      fx.assign(s.userId(), role, ScopeType.ACCOUNT, s.accountId());
      fx.accountStatus(s.accountId(), AccountStatus.SUSPENDED);
      assertThat(resolver.resolveAccountScope(s.userId(), s.accountId())).isEmpty();
    }
  }
}
