package com.acme.iam.user;

import static org.assertj.core.api.Assertions.assertThat;
import static org.awaitility.Awaitility.await;
import static org.springframework.http.HttpHeaders.AUTHORIZATION;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.multipart;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import com.acme.iam.assignment.ScopeType;
import com.acme.iam.common.Ids;
import com.acme.iam.common.test.CapturingNotificationAdapter;
import com.acme.iam.common.test.Fixtures;
import com.acme.iam.common.test.IntegrationTest;
import com.acme.iam.common.test.OrgTestData;
import com.acme.iam.common.test.PostgresTestBase;
import com.acme.iam.common.test.TestTokens;
import com.acme.iam.product.Product;
import com.acme.iam.role.Role;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.system.CapturedOutput;
import org.springframework.boot.test.system.OutputCaptureExtension;
import org.springframework.context.annotation.Import;
import org.springframework.jdbc.core.simple.JdbcClient;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.ResultActions;

/** P1-8.4 bulk invite: validate everything first, insert in batches, async job with a status endpoint. */
@IntegrationTest
@AutoConfigureMockMvc
@Import(CapturingNotificationAdapter.Config.class)
@ExtendWith(OutputCaptureExtension.class)
class BulkInviteApiIT extends PostgresTestBase {

  @Autowired MockMvc mvc;
  @Autowired TestTokens tokens;
  @Autowired JdbcClient jdbc;
  @Autowired ObjectMapper json;
  @Autowired CapturingNotificationAdapter mailbox;
  @Autowired BulkInviteService service;

  OrgTestData org;
  Fixtures fx;
  UUID account;
  UUID tenant;
  UUID admin;
  String adminBearer;
  String prefix;

  @BeforeEach
  void setUp() {
    mailbox.clear();
    org = new OrgTestData(jdbc);
    fx = org.fixtures();
    Fixtures.Scenario s = fx.scenario();
    account = s.accountId();
    tenant = s.tenantId();
    admin = org.accountAdmin(account, tenant);
    adminBearer = org.adminBearer(tokens, admin, account, tenant);
    org.tenantAdminRole();
    prefix = "bulk-" + Ids.newId().toString().substring(24);
  }

  @Test
  void invitesEveryRowWithMembershipRoleTokenAndMail() throws Exception {
    String csv = """
        email,displayName,roleName
        %1$s-a@example.test,Ada,tenant admin
        %1$s-b@example.test,"Lovelace, B",
        %1$s-c@example.test
        """.formatted(prefix);

    UUID job = submit(tenant, adminBearer, csv);
    JsonNode done = awaitFinished(job);

    assertThat(done.get("status").asText()).isEqualTo("COMPLETED");
    assertThat(done.get("totalRows").asInt()).isEqualTo(3);
    assertThat(done.get("createdCount").asInt()).isEqualTo(3);
    assertThat(done.get("errors").size()).isZero();

    UUID a = org.userByEmail(account, prefix + "-a@example.test").orElseThrow();
    UUID b = org.userByEmail(account, prefix + "-b@example.test").orElseThrow();
    assertThat(org.userStatus(a)).isEqualTo("INVITED");
    assertThat(org.membershipTenants(b)).containsExactly(tenant);
    assertThat(jdbc.sql("SELECT display_name FROM app_user WHERE id = :id").param("id", b).query(String.class)
        .single()).isEqualTo("Lovelace, B");
    Map<String, Object> grant = jdbc.sql("""
            SELECT role_id, scope_type, scope_id, granted_by FROM role_assignment WHERE user_id = :u""")
        .param("u", a).query().singleRow();
    assertThat(grant).containsEntry("role_id", org.tenantAdminRole()).containsEntry("scope_type", "TENANT")
        .containsEntry("scope_id", tenant).containsEntry("granted_by", admin);
    assertThat(org.assignments(b)).isZero();
    assertThat(org.outstandingTokens(a)).isEqualTo(1);

    await().atMost(Duration.ofSeconds(10)).until(() -> mailbox.sent().size() == 3);
    assertThat(mailbox.lastInvitationToken(prefix + "-c@example.test")).isNotBlank();
  }

  /** Ruling R40: product SYSTEM roles need only iam.role.assign, and the product enabled in the tenant. */
  @Test
  void productSystemRolesNeedRoleAssignAndAnEnabledProduct() throws Exception {
    UUID product = fx.entitledProduct(account, tenant);
    UUID systemRole = fx.systemRole(product, fx.permission(product));
    String roleName = jdbc.sql("SELECT name FROM role WHERE id = :id").param("id", systemRole).query(String.class)
        .single();
    UUID manager = fx.user(account, tenant);
    fx.assign(manager, fx.customRole(Product.IAM_ID, account, fx.permission(Product.IAM_ID, "iam.user.manage"),
        fx.permission(Product.IAM_ID, "iam.role.assign")), ScopeType.ACCOUNT, account);
    String bearer = org.bearer(tokens, manager, account, tenant, "iam.user.manage", "iam.role.assign");

    JsonNode ok = awaitFinished(submit(tenant, bearer, prefix + "-p@example.test,," + roleName + "\n"));
    assertThat(ok.get("status").asText()).as(ok.toString()).isEqualTo("COMPLETED");

    fx.enableProduct(tenant, product, false);
    JsonNode refused = awaitFinished(submit(tenant, bearer, prefix + "-q@example.test,," + roleName + "\n"));
    assertThat(refused.at("/errors/0/code").asText()).isEqualTo("product_not_entitled");
  }

  /** Task 9: a bulk row with a role needs iam.role.assign at the tenant, not only the role's permissions. */
  @Test
  void aRoleColumnNeedsRoleAssign() throws Exception {
    UUID readTenant = fx.permission(Product.IAM_ID, "iam.user.read.tenant");
    UUID manager = fx.user(account, tenant);
    fx.assign(manager, fx.customRole(Product.IAM_ID, account, fx.permission(Product.IAM_ID, "iam.user.manage"),
        readTenant), ScopeType.ACCOUNT, account);
    UUID reader = fx.customRole(Product.IAM_ID, account, readTenant);
    String roleName = jdbc.sql("SELECT name FROM role WHERE id = :id").param("id", reader).query(String.class).single();
    String bearer = org.bearer(tokens, manager, account, tenant, "iam.user.manage", "iam.user.read.tenant");

    JsonNode done = awaitFinished(submit(tenant, bearer, prefix + "-r@example.test,,"  + roleName + "\n"));

    assertThat(done.get("status").asText()).isEqualTo("FAILED");
    assertThat(done.at("/errors/0/code").asText()).isEqualTo("grantor_lacks_permissions");
    assertThat(done.at("/errors/0/message").asText()).contains("iam.role.assign");
  }

  @Test
  void anyInvalidRowFailsTheJobWithAllErrorsAndInsertsNothing() throws Exception {
    UUID existing = fx.user(account, tenant);
    UUID secret = fx.systemRole(Product.IAM_ID, fx.permission(Product.IAM_ID));
    String secretName = jdbc.sql("SELECT name FROM role WHERE id = :id").param("id", secret).query(String.class)
        .single();
    org.platformAdminRole();
    String csv = """
        email,displayName,roleName
        %1$s-ok@example.test,Fine,
        not-an-email,Bad,
        %1$s-dup@example.test,,
        %1$s-DUP@example.test,,
        %2$s,,
        %1$s-role@example.test,,No Such Role
        %1$s-platform@example.test,,%3$s
        %1$s-grantor@example.test,,%4$s
        %1$s-cols@example.test,a,b,c
        %1$s-nul@example.test,Bad\0Name,
        %1$s-bell@example.test\007,,
        """.formatted(prefix, fx.email(existing), Role.PLATFORM_ADMIN, secretName);

    JsonNode done = awaitFinished(submit(tenant, adminBearer, csv));

    assertThat(done.get("status").asText()).isEqualTo("FAILED");
    assertThat(done.get("createdCount").asInt()).isZero();
    Map<Integer, String> errors = new java.util.TreeMap<>();
    done.get("errors").forEach(e -> errors.put(e.get("row").asInt(), e.get("code").asText()));
    assertThat(errors).containsExactlyEntriesOf(new java.util.TreeMap<>(Map.of(
        3, "invalid_email",
        5, "duplicate_in_file",
        6, "user_exists",
        7, "unknown_role",
        8, "platform_role_restricted",
        9, "grantor_lacks_permissions",
        10, "invalid_columns",
        11, "invalid_characters",
        12, "invalid_characters")));
    assertThat(done.get("errorCount").asInt()).isEqualTo(9);
    assertThat(org.userByEmail(account, prefix + "-ok@example.test")).isEmpty();
    assertThat(mailbox.sent()).isEmpty();
  }

  @Test
  void moreThan5000RowsIsRejectedUpFront() throws Exception {
    String csv = IntStream.rangeClosed(1, 5001).mapToObj(i -> prefix + "-" + i + "@example.test")
        .collect(Collectors.joining("\n", "email\n", "\n"));
    upload(tenant, adminBearer, csv)
        .andExpect(status().isBadRequest())
        .andExpect(jsonPath("$.code").value("too_many_rows"));
  }

  @Test
  void theTenantGuardAndAccountBoundaryApply() throws Exception {
    UUID tenantAdmin = fx.user(account, tenant);
    fx.assign(tenantAdmin, org.tenantAdminRole(), ScopeType.TENANT, tenant);
    String bearer = org.bearer(tokens, tenantAdmin, account, tenant, "iam.user.manage");
    upload(fx.tenant(account), bearer, "x@example.test\n")
        .andExpect(status().isForbidden())
        .andExpect(jsonPath("$.code").value("scope_exceeded"));

    UUID job = submit(tenant, adminBearer, prefix + "-z@example.test\n");
    awaitFinished(job);
    Fixtures.Scenario other = fx.scenario();
    String foreign = org.adminBearer(tokens, other.userId(), other.accountId(), other.tenantId());
    mvc.perform(get("/api/bulk-invites/{id}", job).header(AUTHORIZATION, foreign))
        .andExpect(status().isNotFound())
        .andExpect(jsonPath("$.code").value("bulk_invite_not_found"));
  }

  @Test
  void fiveThousandRowsFinishInUnder30Seconds() throws Exception {
    String csv = IntStream.rangeClosed(1, 5000)
        .mapToObj(i -> "%s-%d@example.test,User %d,%s".formatted(prefix, i, i, i % 2 == 0 ? "Tenant Admin" : ""))
        .collect(Collectors.joining("\n", "email,displayName,roleName\n", "\n"));

    long started = System.nanoTime();
    UUID job = submit(tenant, adminBearer, csv);
    JsonNode done = awaitFinished(job, Duration.ofSeconds(60));
    Duration took = Duration.ofNanos(System.nanoTime() - started);

    assertThat(done.get("status").asText()).as(done.toString()).isEqualTo("COMPLETED");
    assertThat(done.get("createdCount").asInt()).isEqualTo(5000);
    assertThat(took).as("bulk invite of 5,000 rows took %s", took).isLessThan(Duration.ofSeconds(30));
    assertThat(jdbc.sql("SELECT count(*) FROM app_user WHERE account_id = :a AND email LIKE :p")
        .param("a", account).param("p", prefix + "-%").query(Long.class).single()).isEqualTo(5000);
    assertThat(jdbc.sql("""
            SELECT count(*) FROM role_assignment ra JOIN app_user u ON u.id = ra.user_id
            WHERE u.account_id = :a AND u.email LIKE :p""")
        .param("a", account).param("p", prefix + "-%").query(Long.class).single()).isEqualTo(2500);
    await().atMost(Duration.ofSeconds(30)).until(() -> mailbox.sent().size() == 5000);
    System.out.printf("bulk invite of 5,000 rows: job finished in %d ms%n", took.toMillis());
  }

  @Test
  void aUserCreatedConcurrentlyFailsTheJobAsUserExistsWithoutLeakingEmails(CapturedOutput output) throws Exception {
    String email = prefix + "-race@example.test";
    service.afterValidationForTests(() -> insertUser(email));
    try {
      JsonNode done = awaitFinished(submit(tenant, adminBearer, email + "\n" + prefix + "-other@example.test\n"));
      assertThat(done.get("status").asText()).isEqualTo("FAILED");
      assertThat(done.at("/errors/0/code").asText()).isEqualTo("user_exists");
      assertThat(done.at("/errors/0/row").asInt()).isZero();
      assertThat(org.userByEmail(account, prefix + "-other@example.test")).isEmpty();
      assertThat(mailbox.sent()).isEmpty();
      assertThat(output.getAll()).contains("bulk_invite").doesNotContain(email);
    } finally {
      service.afterValidationForTests(null);
    }
  }

  @Test
  void r29_staleJobsAreMarkedInterrupted() {
    UUID stale = job("RUNNING", "now() - interval '2 hours'", "now() - interval '2 hours'");
    UUID queued = job("PENDING", null, "now() - interval '2 hours'");
    UUID fresh = job("RUNNING", "now()", "now()");

    assertThat(service.failStaleJobs(Duration.ofMinutes(30))).isGreaterThanOrEqualTo(2);

    for (UUID id : List.of(stale, queued)) {
      BulkInviteService.JobView view = service.get(account, id);
      assertThat(view.status()).isEqualTo(BulkInviteService.JobStatus.FAILED);
      assertThat(view.errors()).extracting(BulkInviteService.RowError::code).containsExactly("job_interrupted");
      assertThat(view.finishedAt()).isNotNull();
    }
    assertThat(service.get(account, fresh).status()).isEqualTo(BulkInviteService.JobStatus.RUNNING);
  }

  @Test
  void r29_aSweptPendingJobNeverRuns() {
    UUID id = job("PENDING", null, "now() - interval '2 hours'");
    service.failStaleJobs(Duration.ofMinutes(30));
    String email = prefix + "-late@example.test";

    service.run(new BulkInviteService.Job(id, account, tenant, admin, 1),
        List.of(new BulkInviteCsv.Row(1, email, null, null, 1)));

    assertThat(org.userByEmail(account, email)).isEmpty();
    BulkInviteService.JobView view = service.get(account, id);
    assertThat(view.status()).isEqualTo(BulkInviteService.JobStatus.FAILED);
    assertThat(view.errors()).extracting(BulkInviteService.RowError::code).containsExactly("job_interrupted");
    assertThat(mailbox.sent()).isEmpty();
  }

  @Test
  void r29_aJobSweptWhileRunningRollsBackAndSendsNothing() {
    UUID id = job("PENDING", null, "now()");
    String email = prefix + "-swept@example.test";
    service.afterValidationForTests(() -> service.failStaleJobs(Duration.ofMinutes(-1))); // cutoff in the future
    try {
      service.run(new BulkInviteService.Job(id, account, tenant, admin, 1),
          List.of(new BulkInviteCsv.Row(1, email, null, null, 1)));
    } finally {
      service.afterValidationForTests(null);
    }

    assertThat(org.userByEmail(account, email)).isEmpty();
    BulkInviteService.JobView view = service.get(account, id);
    assertThat(view.status()).isEqualTo(BulkInviteService.JobStatus.FAILED);
    assertThat(view.createdCount()).isZero();
    assertThat(view.errors()).extracting(BulkInviteService.RowError::code).containsExactly("job_interrupted");
    assertThat(mailbox.sent()).isEmpty();
  }

  private UUID job(String status, String startedAt, String createdAt) {
    UUID id = Ids.newId();
    jdbc.sql("""
            INSERT INTO bulk_invite_job (id, account_id, tenant_id, status, total_rows, created_at, started_at)
            VALUES (:id, :a, :t, :status, 1, %s, %s)""".formatted(createdAt, startedAt == null ? "NULL" : startedAt))
        .param("id", id).param("a", account).param("t", tenant).param("status", status).update();
    return id;
  }

  /** Commits a user with this email (on its own connection), as a concurrent invite would. */
  private void insertUser(String email) {
    jdbc.sql("""
            INSERT INTO app_user (id, account_id, email, status, primary_tenant_id, version)
            VALUES (:id, :a, :e, 'INVITED', :t, 0)""")
        .param("id", Ids.newId()).param("a", account).param("e", email).param("t", tenant).update();
  }

  private UUID submit(UUID tenantId, String bearer, String csv) throws Exception {
    String body = upload(tenantId, bearer, csv)
        .andExpect(status().isAccepted())
        .andReturn().getResponse().getContentAsString();
    return UUID.fromString(json.readTree(body).get("jobId").asText());
  }

  private ResultActions upload(UUID tenantId, String bearer, String csv) throws Exception {
    MockMultipartFile file = new MockMultipartFile("file", "users.csv", "text/csv",
        csv.getBytes(StandardCharsets.UTF_8));
    return mvc.perform(multipart("/api/tenants/{tenantId}/users/bulk", tenantId).file(file)
        .header(AUTHORIZATION, bearer));
  }

  private JsonNode awaitFinished(UUID job) {
    return awaitFinished(job, Duration.ofSeconds(20));
  }

  private JsonNode awaitFinished(UUID job, Duration timeout) {
    List<JsonNode> last = new ArrayList<>(List.of(json.nullNode()));
    await().atMost(timeout).pollInterval(Duration.ofMillis(100)).until(() -> {
      JsonNode node = json.readTree(mvc.perform(get("/api/bulk-invites/{id}", job).header(AUTHORIZATION, adminBearer))
          .andExpect(status().isOk()).andReturn().getResponse().getContentAsString());
      last.set(0, node);
      String status = node.get("status").asText();
      return status.equals("COMPLETED") || status.equals("FAILED");
    });
    return last.get(0);
  }
}
