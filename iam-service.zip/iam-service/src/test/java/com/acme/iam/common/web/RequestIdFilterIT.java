package com.acme.iam.common.web;

import static org.assertj.core.api.Assertions.assertThat;

import com.acme.iam.common.test.IntegrationTest;
import com.acme.iam.common.test.PostgresTestBase;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.util.UUID;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.boot.test.web.server.LocalServerPort;

/** P1-1.4: every HTTP response carries {@code X-Request-Id}, whatever produced it (controller, security, error). */
@IntegrationTest(webEnvironment = WebEnvironment.RANDOM_PORT)
class RequestIdFilterIT extends PostgresTestBase {

  @LocalServerPort int port;

  private final HttpClient http = HttpClient.newHttpClient();

  @Test
  void successfulResponseHasGeneratedRequestId() throws Exception {
    HttpResponse<String> response = get("/actuator/health/liveness", null); // R36: the probe is on every port

    assertThat(response.statusCode()).isEqualTo(200);
    assertThat(requestId(response)).isNotNull();
    assertThat(UUID.fromString(requestId(response)).version()).isEqualTo(7);
  }

  @Test
  void securityRejectionHasRequestId() throws Exception {
    HttpResponse<String> response = get("/api/anything", null);

    assertThat(response.statusCode()).isEqualTo(401);
    assertThat(requestId(response)).isNotBlank();
  }

  @Test
  void errorResponseHasRequestId() throws Exception {
    HttpResponse<String> response = get("/actuator/health/does-not-exist", null);

    assertThat(response.statusCode()).isGreaterThanOrEqualTo(400);
    assertThat(requestId(response)).isNotBlank();
  }

  @Test
  void wellFormedInboundRequestIdIsEchoed() throws Exception {
    HttpResponse<String> response = get("/actuator/health", "client-req_42.a");

    assertThat(requestId(response)).isEqualTo("client-req_42.a");
  }

  @Test
  void malformedInboundRequestIdIsReplaced() throws Exception {
    String tooLong = "x".repeat(65);

    assertThat(requestId(get("/actuator/health", "bad id;drop"))).isNotEqualTo("bad id;drop").isNotBlank();
    assertThat(requestId(get("/actuator/health", tooLong))).isNotEqualTo(tooLong).isNotBlank();
  }

  @Test
  void eachRequestGetsItsOwnId() throws Exception {
    assertThat(requestId(get("/actuator/health", null))).isNotEqualTo(requestId(get("/actuator/health", null)));
  }

  private HttpResponse<String> get(String path, String requestId) throws Exception {
    HttpRequest.Builder request = HttpRequest.newBuilder(URI.create("http://localhost:" + port + path)).GET();
    if (requestId != null) {
      request.header(RequestIdFilter.HEADER, requestId);
    }
    return http.send(request.build(), HttpResponse.BodyHandlers.ofString());
  }

  private static String requestId(HttpResponse<?> response) {
    return response.headers().firstValue(RequestIdFilter.HEADER).orElse(null);
  }
}
