package com.acme.iam.common.security;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

import java.nio.charset.StandardCharsets;
import java.security.GeneralSecurityException;
import java.security.SecureRandom;
import java.util.Arrays;
import java.util.Base64;
import org.junit.jupiter.api.Test;

class MasterKeyCipherTest {

  private static String randomKey(int bytes) {
    byte[] key = new byte[bytes];
    new SecureRandom().nextBytes(key);
    return Base64.getEncoder().encodeToString(key);
  }

  private final MasterKeyCipher cipher = MasterKeyCipher.fromBase64(randomKey(32));
  private final byte[] aad = "kid-1".getBytes(StandardCharsets.UTF_8);

  @Test
  void roundTripsWithRandomIvPrepended() {
    byte[] plain = "private key bytes".getBytes(StandardCharsets.UTF_8);

    byte[] first = cipher.encrypt(plain, aad);
    byte[] second = cipher.encrypt(plain, aad);

    assertThat(first).hasSize(MasterKeyCipher.IV_BYTES + plain.length + MasterKeyCipher.TAG_BYTES);
    assertThat(Arrays.copyOf(first, 12)).isNotEqualTo(Arrays.copyOf(second, 12));
    assertThat(cipher.decrypt(first, aad)).isEqualTo(plain);
    assertThat(cipher.decrypt(second, aad)).isEqualTo(plain);
  }

  @Test
  void tamperingOrWrongAssociatedDataIsDetected() {
    byte[] sealed = cipher.encrypt(new byte[] {1, 2, 3}, aad);
    byte[] tampered = sealed.clone();
    tampered[tampered.length - 1] ^= 1;

    assertThatThrownBy(() -> cipher.decrypt(tampered, aad))
        .isInstanceOf(IllegalStateException.class).hasCauseInstanceOf(GeneralSecurityException.class);
    assertThatThrownBy(() -> cipher.decrypt(sealed, "kid-2".getBytes(StandardCharsets.UTF_8)))
        .isInstanceOf(IllegalStateException.class);
  }

  @Test
  void otherMasterKeyCannotDecrypt() {
    byte[] sealed = cipher.encrypt(new byte[] {1, 2, 3}, aad);

    assertThatThrownBy(() -> MasterKeyCipher.fromBase64(randomKey(32)).decrypt(sealed, aad))
        .isInstanceOf(IllegalStateException.class);
  }

  @Test
  void rejectsMissingOrWrongSizedMasterKey() {
    assertThatThrownBy(() -> MasterKeyCipher.fromBase64(null))
        .isInstanceOf(IllegalStateException.class).hasMessageContaining("iam.security.master-key");
    assertThatThrownBy(() -> MasterKeyCipher.fromBase64(" "))
        .isInstanceOf(IllegalStateException.class).hasMessageContaining("IAM_MASTER_KEY");
    assertThatThrownBy(() -> MasterKeyCipher.fromBase64(randomKey(16)))
        .isInstanceOf(IllegalStateException.class).hasMessageContaining("32 bytes");
    assertThatThrownBy(() -> MasterKeyCipher.fromBase64("not base64 !!"))
        .isInstanceOf(IllegalStateException.class);
  }
}
