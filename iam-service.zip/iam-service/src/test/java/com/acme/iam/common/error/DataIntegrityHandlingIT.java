package com.acme.iam.common.error;

import static org.hamcrest.Matchers.containsString;
import static org.hamcrest.Matchers.not;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import com.acme.iam.account.Account;
import com.acme.iam.account.AccountKind;
import com.acme.iam.account.AccountRepository;
import com.acme.iam.common.Ids;
import com.acme.iam.common.test.IntegrationTest;
import com.acme.iam.common.test.PostgresTestBase;
import com.acme.iam.tenant.Tenant;
import com.acme.iam.tenant.TenantRepository;
import java.util.UUID;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.context.annotation.Import;
import org.springframework.http.MediaType;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * Ruling R12: Spring Data JDBC wraps unique / FK violations in {@code DbActionExecutionException}; the global handler
 * unwraps them to 409 {@code duplicate} / {@code conflict} without leaking database details. Uses real repository
 * saves so the exact exception shape Spring Data JDBC produces is covered.
 */
@IntegrationTest
@AutoConfigureMockMvc
@WithMockUser
class DataIntegrityHandlingIT extends PostgresTestBase {

  @Autowired MockMvc mvc;

  @Test
  void wrappedUniqueViolationIsDuplicate() throws Exception {
    mvc.perform(post("/test/data-integrity/duplicate-slug"))
        .andExpect(status().isConflict())
        .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_PROBLEM_JSON))
        .andExpect(jsonPath("$.code").value("duplicate"))
        .andExpect(jsonPath("$.requestId").isNotEmpty())
        .andExpect(content().string(not(containsString("account_slug_key"))));
  }

  @Test
  void wrappedForeignKeyViolationIsConflict() throws Exception {
    mvc.perform(post("/test/data-integrity/missing-account"))
        .andExpect(status().isConflict())
        .andExpect(jsonPath("$.code").value("conflict"))
        .andExpect(jsonPath("$.requestId").isNotEmpty())
        .andExpect(content().string(not(containsString("tenant_account_id_fkey"))))
        .andExpect(content().string(not(containsString("violates"))));
  }

  @TestConfiguration
  @Import(DataIntegrityTestController.class)
  static class Config {}

  @RestController
  @RequestMapping("/test/data-integrity")
  static class DataIntegrityTestController {

    private final AccountRepository accounts;
    private final TenantRepository tenants;

    DataIntegrityTestController(AccountRepository accounts, TenantRepository tenants) {
      this.accounts = accounts;
      this.tenants = tenants;
    }

    @PostMapping("/duplicate-slug")
    void duplicateSlug() {
      String slug = "dup-" + Ids.newId();
      accounts.save(Account.create("First", slug, AccountKind.CUSTOMER));
      accounts.save(Account.create("Second", slug, AccountKind.CUSTOMER));
    }

    @PostMapping("/missing-account")
    void missingAccount() {
      tenants.save(Tenant.create(UUID.randomUUID(), "Orphan", "orphan-" + Ids.newId()));
    }
  }
}
