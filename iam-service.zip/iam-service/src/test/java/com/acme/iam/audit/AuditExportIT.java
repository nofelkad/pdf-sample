package com.acme.iam.audit;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

import com.acme.iam.audit.AuditEvent.Outcome;
import com.acme.iam.common.Ids;
import com.acme.iam.common.security.SecurityTestData;
import com.acme.iam.common.test.IntegrationTest;
import com.acme.iam.common.test.OrgTestData;
import com.acme.iam.common.test.PostgresTestBase;
import com.acme.iam.common.test.TestTokens;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.lang.management.ManagementFactory;
import java.net.URI;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.time.Clock;
import java.time.Duration;
import java.time.Instant;
import java.time.YearMonth;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicLong;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.boot.test.web.server.LocalServerPort;
import org.springframework.jdbc.core.simple.JdbcClient;
import org.springframework.web.servlet.mvc.method.annotation.RequestMappingHandlerAdapter;
import org.springframework.test.util.ReflectionTestUtils;

/** P1-9.7 (Ruling R21): {@code GET /api/audit/exports.csv}, a streamed synchronous CSV download, itself audited. */
@IntegrationTest(webEnvironment = WebEnvironment.RANDOM_PORT)
class AuditExportIT extends PostgresTestBase {

  private static final String PATH = "/api/audit/exports.csv";
  private static final YearMonth BULK_MONTH = YearMonth.of(2019, 6);

  @LocalServerPort int port;
  @Autowired TestTokens tokens;
  @Autowired JdbcClient jdbc;
  @Autowired ObjectMapper json;
  @Autowired Clock clock;
  @Autowired AuditExportService exports;
  @Autowired AuditQueryService queries;
  @Autowired RequestMappingHandlerAdapter handlerAdapter;

  private final HttpClient http = HttpClient.newHttpClient();
  private final AuditTestPartitions ddl = new AuditTestPartitions();
  private AuditTestData data;
  private SecurityTestData sd;
  private Instant now;
  private Instant started;
  private UUID accountA;
  private UUID accountB;
  private UUID userA;
  private String exporterA;

  @BeforeEach
  void setUp() {
    AuditTestData.ensureRecentPartitions();
    data = new AuditTestData(jdbc);
    // Final review C1: the trigger rows of the fixtures below (account, tenants, users, roles, assignments) now carry
    // their account, so they are visible to these searches. The test events are placed relative to a "now" one hour
    // in the past, and every window ends shortly after it, so the fixtures' real-time rows stay outside.
    started = clock.instant().truncatedTo(ChronoUnit.MICROS);
    now = started.minus(Duration.ofHours(1));
    sd = new SecurityTestData(jdbc);
    accountA = sd.account();
    accountB = sd.account();
    userA = auditor(accountA);
    exporterA = TestTokens.bearer(tokens.user(userA).account(accountA).tenant(Ids.newId())
        .perms("iam.audit.export").mint());
  }

  @AfterEach
  void dropBulkPartition() {
    ddl.drop(BULK_MONTH);
  }

  // ------------------------------------------------------------------------------------------ content

  @Test
  void streamsTheCallersEventsAsRfc4180Csv() throws Exception {
    UUID first = data.event(accountA, "iam.role.update", now.minusSeconds(60)).actor(userA).target("role", "R-1")
        .metadata("{\"why\":\"a, \\\"quoted\\\" value\\nsecond line\"}").insert();
    UUID second = data.event(accountA, "auth.login.failed", now.minusSeconds(30)).outcome("DENIED").insert();
    data.event(accountB, "iam.role.update", now.minusSeconds(45)).insert();

    HttpResponse<String> response = get(exporterA, window(""));

    assertThat(response.statusCode()).isEqualTo(200);
    assertThat(response.headers().firstValue("Content-Type")).hasValueSatisfying(
        v -> assertThat(v).startsWith("text/csv").containsIgnoringCase("utf-8"));
    assertThat(response.headers().firstValue("Content-Disposition")).hasValueSatisfying(
        v -> assertThat(v).startsWith("attachment; filename=\"audit-export-").endsWith(".csv\""));
    assertThat(response.headers().firstValue("Cache-Control")).hasValue("no-store");
    List<List<String>> rows = parseCsv(response.body());
    assertThat(rows.get(0)).containsExactly("event_id", "occurred_at", "received_at", "account_id", "tenant_id",
        "source", "actor_user_id", "actor_type", "actor_ip", "user_agent", "session_id", "request_id", "action",
        "target_type", "target_id", "outcome", "before", "after", "metadata");
    assertThat(rows).hasSize(3);
    assertThat(rows.get(1).get(0)).as("newest first").isEqualTo(second.toString());
    assertThat(rows.get(2).get(0)).isEqualTo(first.toString());
    List<String> row = rows.get(2);
    assertThat(row.get(1)).isEqualTo(now.minusSeconds(60).toString());
    assertThat(row.get(3)).isEqualTo(accountA.toString());
    assertThat(row.get(5)).isEqualTo("IAM");
    assertThat(row.get(6)).isEqualTo(userA.toString());
    assertThat(row.get(7)).isEqualTo("USER");
    assertThat(row.get(8)).isEqualTo("198.51.100.7");
    assertThat(row.get(12)).isEqualTo("iam.role.update");
    assertThat(row.get(14)).isEqualTo("R-1");
    assertThat(json.readTree(row.get(18)).get("why").asText()).isEqualTo("a, \"quoted\" value\nsecond line");
  }

  @Test
  void cellsThatCouldBeInterpretedAsFormulasAreNeutralised() throws Exception {
    List<String> dangerous = List.of("=HYPERLINK(\"http://evil\",\"x\")", "+1+1", "-2+3", "@SUM(A1)", "\tcmd", "\rcmd");
    for (String d : dangerous) {
      data.event(accountA, "x.y", now.minusSeconds(10)).target("doc", d).insert();
    }
    data.event(accountA, "x.y", now.minusSeconds(10)).target("doc", "safe=value+1").insert();

    List<List<String>> rows = parseCsv(get(exporterA, window("")).body());

    List<String> targets = rows.stream().skip(1).map(r -> r.get(14)).toList();
    for (String d : dangerous) {
      assertThat(targets).contains("'" + d);
    }
    assertThat(targets).contains("safe=value+1").noneMatch(t -> "=+-@\t\r".indexOf(t.charAt(0)) >= 0);
  }

  @Test
  void filtersApplyLikeInSearch() throws Exception {
    UUID keep = data.event(accountA, "iam.role.update", now.minusSeconds(60)).outcome("DENIED").insert();
    data.event(accountA, "iam.role.update", now.minusSeconds(50)).insert();
    data.event(accountA, "iam.user.update", now.minusSeconds(40)).outcome("DENIED").insert();

    List<List<String>> rows = parseCsv(get(exporterA, window("&action=iam.role.&outcome=DENIED")).body());

    assertThat(rows).hasSize(2);
    assertThat(rows.get(1).get(0)).isEqualTo(keep.toString());
  }

  @Test
  void anEmptyResultIsJustTheHeader() throws Exception {
    assertThat(parseCsv(get(exporterA, window("")).body())).hasSize(1);
  }

  // ------------------------------------------------------------------------------------------ access

  @Test
  void aCallerSeesOnlyTheirOwnAccount() throws Exception {
    data.event(accountA, "x.a", now.minusSeconds(10)).insert();
    data.event(accountB, "x.b", now.minusSeconds(10)).insert();
    String exporterB = TestTokens.bearer(tokens.user(auditor(accountB)).account(accountB).perms("iam.audit.export").mint());

    List<List<String>> rows = parseCsv(get(exporterB, window("")).body());

    assertThat(rows).hasSize(2);
    assertThat(rows.get(1).get(3)).isEqualTo(accountB.toString());
    assertThat(rows.get(1).get(12)).isEqualTo("x.b");
  }

  @Test
  void anotherAccountMayOnlyBeNamedByAPlatformCaller() throws Exception {
    data.event(accountA, "x.a", now.minusSeconds(10)).insert();
    String exporterB = TestTokens.bearer(tokens.user(auditor(accountB)).account(accountB).perms("iam.audit.export").mint());
    OrgTestData org = new OrgTestData(jdbc);
    String platform = org.platformBearer(tokens, org.platformOperator(), "iam.audit.export", "platform.account.manage");

    HttpResponse<String> denied = get(exporterB, window("&accountId=" + accountA));
    assertThat(denied.statusCode()).isEqualTo(403);
    assertThat(json.readTree(denied.body()).get("code").asText()).isEqualTo("account_filter_forbidden");
    assertThat(auditCount("iam.audit.export.started", accountB)).as("a denied export is not started").isZero();
    assertThat(parseCsv(get(platform, window("&accountId=" + accountA)).body())).hasSize(2);
  }

  @Test
  void permissionsAreEnforced() throws Exception {
    assertThat(get(null, window("")).statusCode()).isEqualTo(401);
    assertThat(get(TestTokens.bearer(tokens.user(Ids.newId()).account(accountA).perms("iam.audit.read").mint()),
        window("")).statusCode()).as("read is not export").isEqualTo(403);
    assertThat(get(TestTokens.bearer(tokens.user(Ids.newId()).account(accountA).mint()), window("")).statusCode())
        .isEqualTo(403);
    assertThat(get(TestTokens.bearer(tokens.appToken("billing-svc", "BILLING")), window("")).statusCode())
        .isEqualTo(403);
  }

  @Test
  void theWindowRulesApplyBeforeAnythingIsStreamed() throws Exception {
    HttpResponse<String> none = get(exporterA, "");
    assertThat(none.statusCode()).isEqualTo(400);
    assertThat(json.readTree(none.body()).get("code").asText()).isEqualTo("window_required");

    HttpResponse<String> wide = get(exporterA, "?from=" + now.minus(Duration.ofDays(93)) + "&to=" + now);
    assertThat(wide.statusCode()).isEqualTo(400);
    assertThat(json.readTree(wide.body()).get("code").asText()).isEqualTo("window_too_large");
    assertThat(auditCount("iam.audit.export.started", accountA)).isZero();
  }

  // ------------------------------------------------------------------------------------------ audit of the export

  @Test
  void theExportIsAuditedWithFiltersAndRowCount() throws Exception {
    for (int i = 0; i < 7; i++) {
      data.event(accountA, "iam.role.update", now.minusSeconds(60 + i)).insert();
    }
    data.event(accountA, "iam.user.update", now.minusSeconds(10)).insert();

    String requestId = "export-" + Ids.newId();
    HttpResponse<String> response = get(exporterA, window("&action=iam.role."), Map.of("X-Request-Id", requestId));
    assertThat(parseCsv(response.body())).hasSize(8);

    List<Map<String, Object>> events = jdbc.sql("""
            SELECT action, actor_user_id, account_id, request_id, outcome, actor_type, target_type, target_id,
                   metadata::text AS metadata
            FROM audit_event WHERE request_id = :rid AND action LIKE 'iam.audit.export%' ORDER BY occurred_at""")
        .param("rid", requestId).query().listOfRows();
    assertThat(events).extracting(e -> e.get("action")).containsExactly("iam.audit.export.started", "iam.audit.exported");
    assertThat(jdbc.sql("SELECT count(*) FROM audit_event WHERE request_id = :rid AND action = 'authz.denied'")
        .param("rid", requestId).query(Long.class).single())
        .as("the async re-dispatch of a streamed response must not be denied").isZero();
    Map<String, Object> done = events.get(1);
    assertThat(done.get("actor_user_id")).isEqualTo(userA);
    assertThat(done.get("account_id")).isEqualTo(accountA);
    assertThat(done.get("outcome")).isEqualTo("SUCCESS");
    assertThat(done.get("actor_type")).isEqualTo("USER");
    assertThat(done.get("target_id")).isEqualTo(events.get(0).get("target_id"));
    JsonNode meta = json.readTree((String) done.get("metadata"));
    assertThat(meta.get("rowCount").asLong()).isEqualTo(7);
    assertThat(meta.get("status").asText()).isEqualTo("completed");
    assertThat(meta.at("/filters/action").asText()).isEqualTo("iam.role.");
    assertThat(meta.at("/filters/accountId").asText()).isEqualTo(accountA.toString());
    assertThat(meta.at("/filters/from").asText()).isNotBlank();
  }

  @Test
  void anAbortedDownloadIsAuditedWithTheRowsSentSoFar() throws Exception {
    for (int i = 0; i < 3_000; i++) {
      data.event(accountA, "bulk.row", now.minusSeconds(100).minusMillis(i)).insert();
    }
    AuditSearchCriteria criteria = criteria(now.minus(Duration.ofDays(1)), now.plusSeconds(1));
    AuditExportService.Export export = withActor(userA, accountA, () -> exports.begin(criteria));
    OutputStream dropsAfter64k = new OutputStream() {
      private int written;

      @Override
      public void write(int b) throws IOException {
        if (++written > 64 * 1024) {
          throw new IOException("Broken pipe");
        }
      }

      @Override
      public void write(byte[] b, int off, int len) throws IOException {
        written += len;
        if (written > 64 * 1024) {
          throw new IOException("Broken pipe");
        }
      }
    };

    assertThatThrownBy(() -> withActor(userA, accountA, () -> {
      export.stream(dropsAfter64k);
      return null;
    })).isInstanceOf(IOException.class);

    JsonNode meta = json.readTree(jdbc.sql("""
            SELECT metadata::text FROM audit_event
            WHERE action = 'iam.audit.exported' AND account_id = :acc""").param("acc", accountA)
        .query(String.class).single());
    assertThat(meta.get("status").asText()).isEqualTo("aborted");
    assertThat(meta.get("rowCount").asLong()).isBetween(1L, 2_999L);
  }

  @Test
  void atMostTwoExportsRunConcurrentlyPerInstance() throws Exception {
    AuditSearchCriteria criteria = criteria(now.minus(Duration.ofDays(1)), now.plusSeconds(1));
    List<AuditExportService.Export> running = new ArrayList<>();
    try {
      running.add(withActor(userA, accountA, () -> exports.begin(criteria)));
      running.add(withActor(userA, accountA, () -> exports.begin(criteria)));
      assertThatThrownBy(() -> withActor(userA, accountA, () -> exports.begin(criteria)))
          .hasMessageContaining("Too many exports");
    } finally {
      for (AuditExportService.Export e : running) {
        withActor(userA, accountA, () -> {
          e.stream(OutputStream.nullOutputStream());
          return null;
        });
      }
    }
    withActor(userA, accountA, () -> exports.begin(criteria)).stream(OutputStream.nullOutputStream());
  }

  @Test
  void theAsyncRequestTimeoutAllowsLongExports() {
    Long timeout = (Long) ReflectionTestUtils.getField(handlerAdapter, "asyncRequestTimeout");
    assertThat(timeout).isGreaterThanOrEqualTo(Duration.ofMinutes(30).toMillis());
  }

  // ------------------------------------------------------------------------------------------ memory

  @Test
  void aHundredThousandRowsStreamInBoundedMemory() throws Exception {
    ddl.create(BULK_MONTH);
    int rows = 100_000;
    jdbc.sql("""
            INSERT INTO audit_event (event_id, occurred_at, account_id, source, actor_type, action, outcome, metadata)
            SELECT gen_random_uuid(), timestamptz '2019-06-01 00:00:00+00' + g * interval '20 seconds', :acc, 'IAM',
                   'SYSTEM', 'bulk.row', 'SUCCESS', jsonb_build_object('n', g, 'pad', repeat('x', 800))
            FROM generate_series(1, :rows) g""")
        .param("acc", accountA).param("rows", rows).update();
    ddl.migrator().sql("ANALYZE audit_event").update();
    Instant from = Instant.parse("2019-06-01T00:00:00Z");
    Instant to = Instant.parse("2019-06-30T00:00:00Z");
    AuditSearchCriteria criteria = criteria(from, to);

    AuditExportService.Export export = withActor(userA, accountA, () -> exports.begin(criteria));
    HeapProbe probe = new HeapProbe(8L * 1024 * 1024);
    long baseline = probe.settledUsedHeap();
    withActor(userA, accountA, () -> {
      export.stream(probe);
      return null;
    });

    long streamedMb = probe.bytes.get() / (1024 * 1024);
    long growthMb = (probe.maxUsed - baseline) / (1024 * 1024);
    System.out.println("EXPORT MEMORY: " + rows + " rows, " + streamedMb + " MB of CSV streamed, "
        + probe.lines.get() + " lines, heap growth after GC at most " + growthMb + " MB (baseline "
        + baseline / (1024 * 1024) + " MB)");
    assertThat(probe.lines.get()).isEqualTo(rows + 1);
    assertThat(streamedMb).as("CSV volume").isGreaterThan(80);
    assertThat(growthMb).as("heap growth while streaming %d MB", streamedMb).isLessThan(40);
  }

  @Test
  void aHundredThousandRowsOverHttpAreCountedWithoutBufferingTheBody() throws Exception {
    ddl.create(BULK_MONTH);
    jdbc.sql("""
            INSERT INTO audit_event (event_id, occurred_at, account_id, source, actor_type, action, outcome)
            SELECT gen_random_uuid(), timestamptz '2019-06-01 00:00:00+00' + g * interval '20 seconds', :acc, 'IAM',
                   'SYSTEM', 'bulk.row', 'SUCCESS'
            FROM generate_series(1, 100000) g""").param("acc", accountA).update();

    HttpRequest request = HttpRequest.newBuilder(URI.create("http://localhost:" + port + PATH
            + "?from=2019-06-01T00:00:00Z&to=2019-06-30T00:00:00Z"))
        .header("Authorization", exporterA).timeout(Duration.ofMinutes(2)).build();
    HttpResponse<InputStream> response = http.send(request, HttpResponse.BodyHandlers.ofInputStream());
    long lines = 0;
    try (InputStream in = response.body()) {
      byte[] buffer = new byte[64 * 1024];
      int n;
      while ((n = in.read(buffer)) > 0) {
        for (int i = 0; i < n; i++) {
          if (buffer[i] == '\n') {
            lines++;
          }
        }
      }
    }

    assertThat(response.statusCode()).isEqualTo(200);
    assertThat(lines).isEqualTo(100_001);
    assertThat(auditCount("iam.audit.exported", accountA)).isEqualTo(1);
  }

  /** Counts bytes and lines, and samples the heap after a GC every {@code every} bytes. */
  private static final class HeapProbe extends OutputStream {
    final AtomicLong bytes = new AtomicLong();
    final AtomicLong lines = new AtomicLong();
    long maxUsed;
    private final long every;
    private long nextSample;

    HeapProbe(long every) {
      this.every = every;
      this.nextSample = every;
    }

    long settledUsedHeap() {
      for (int i = 0; i < 3; i++) {
        System.gc();
      }
      long used = ManagementFactory.getMemoryMXBean().getHeapMemoryUsage().getUsed();
      maxUsed = used;
      return used;
    }

    @Override
    public void write(int b) {
      write(new byte[] {(byte) b}, 0, 1);
    }

    @Override
    public void write(byte[] b, int off, int len) {
      for (int i = off; i < off + len; i++) {
        if (b[i] == '\n') {
          lines.incrementAndGet();
        }
      }
      if (bytes.addAndGet(len) >= nextSample) {
        nextSample += every;
        maxUsed = Math.max(maxUsed, settledUsedHeap());
      }
    }
  }

  // ------------------------------------------------------------------------------------------ helpers

  private <T> T withActor(UUID user, UUID account, java.util.concurrent.Callable<T> action) throws Exception {
    var context = org.springframework.security.core.context.SecurityContextHolder.createEmptyContext();
    context.setAuthentication(new org.springframework.security.oauth2.server.resource.authentication.JwtAuthenticationToken(
        org.springframework.security.oauth2.jwt.Jwt.withTokenValue("t").header("alg", "none")
            .claim("sub", user.toString()).claim("acc", account.toString()).claim("tid", Ids.newId().toString())
            .claim("sid", Ids.newId().toString()).claim("sv", 1).claim("perms", List.of("iam.audit.export")).build(),
        List.of(new org.springframework.security.core.authority.SimpleGrantedAuthority("iam.audit.export"))));
    var previous = org.springframework.security.core.context.SecurityContextHolder.getContext();
    org.springframework.security.core.context.SecurityContextHolder.setContext(context);
    try {
      return action.call();
    } finally {
      org.springframework.security.core.context.SecurityContextHolder.setContext(previous);
    }
  }

  /** A user with iam.audit.export through an ACCOUNT-scope assignment (sees every tenant, Ruling R25). */
  private UUID auditor(UUID account) {
    UUID tenant = sd.tenant(account);
    UUID user = sd.user(account, tenant);
    sd.assign(user, sd.role(account, "iam.audit.export"), "ACCOUNT", account, null);
    return user;
  }

  private AuditSearchCriteria criteria(Instant from, Instant to) throws Exception {
    return withActor(userA, accountA, () -> queries.criteria(
        new AuditFilter(null, null, null, null, null, null, null, from, to, null, null), true, "iam.audit.export"));
  }

  private String window(String extra) {
    return "?from=" + enc(now.minus(Duration.ofDays(5)).toString()) + "&to=" + enc(now.toString()) + extra;
  }

  private HttpResponse<String> get(String bearer, String query) throws Exception {
    return get(bearer, query, Map.of());
  }

  private HttpResponse<String> get(String bearer, String query, Map<String, String> headers) throws Exception {
    HttpRequest.Builder request = HttpRequest.newBuilder(URI.create("http://localhost:" + port + PATH + query))
        .timeout(Duration.ofMinutes(2));
    if (bearer != null) {
      request.header("Authorization", bearer);
    }
    headers.forEach(request::header);
    return http.send(request.build(), HttpResponse.BodyHandlers.ofString(StandardCharsets.UTF_8));
  }

  private long auditCount(String action, UUID account) {
    return jdbc.sql("SELECT count(*) FROM audit_event WHERE action = :a AND (CAST(:acc AS uuid) IS NULL OR account_id = :acc)"
        + " AND occurred_at > :since").param("a", action).param("acc", account)
        .param("since", java.time.OffsetDateTime.ofInstant(started.minusSeconds(1), java.time.ZoneOffset.UTC))
        .query(Long.class).single();
  }

  private static String enc(String s) {
    return URLEncoder.encode(s, StandardCharsets.UTF_8);
  }

  /** Minimal RFC 4180 parser (quoted fields, doubled quotes, CRLF/LF inside quotes). */
  static List<List<String>> parseCsv(String csv) {
    List<List<String>> rows = new ArrayList<>();
    List<String> row = new ArrayList<>();
    StringBuilder cell = new StringBuilder();
    boolean quoted = false;
    for (int i = 0; i < csv.length(); i++) {
      char c = csv.charAt(i);
      if (quoted) {
        if (c == '"') {
          if (i + 1 < csv.length() && csv.charAt(i + 1) == '"') {
            cell.append('"');
            i++;
          } else {
            quoted = false;
          }
        } else {
          cell.append(c);
        }
      } else if (c == '"') {
        quoted = true;
      } else if (c == ',') {
        row.add(cell.toString());
        cell.setLength(0);
      } else if (c == '\r' && i + 1 < csv.length() && csv.charAt(i + 1) == '\n') {
        row.add(cell.toString());
        cell.setLength(0);
        rows.add(row);
        row = new ArrayList<>();
        i++;
      } else {
        cell.append(c);
      }
    }
    if (cell.length() > 0 || !row.isEmpty()) {
      row.add(cell.toString());
      rows.add(row);
    }
    return rows;
  }
}
