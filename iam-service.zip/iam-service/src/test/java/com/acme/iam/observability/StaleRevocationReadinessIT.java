package com.acme.iam.observability;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import com.acme.iam.common.test.IntegrationTest;
import com.acme.iam.common.test.PostgresTestBase;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.test.web.servlet.MockMvc;

/**
 * A stale revocation poller makes {@code readiness} 503 (revocations would not be seen: do not take traffic) but
 * leaves the aggregate {@code /actuator/health} and {@code liveness} alone (a restart would not help).
 * {@code stale-after=PT0S} makes every poll stale at once.
 */
@IntegrationTest(properties = "iam.observability.revocation-stale-after=PT0S")
@AutoConfigureMockMvc
class StaleRevocationReadinessIT extends PostgresTestBase {

  @Autowired MockMvc mvc;

  @Test
  void readinessIsOutOfServiceWhileTheAggregateAndLivenessStayUp() throws Exception {
    mvc.perform(get("/actuator/health/readiness")).andExpect(status().isServiceUnavailable())
        .andExpect(jsonPath("$.status").value("NOT_READY"));
    mvc.perform(get("/actuator/health")).andExpect(status().isOk()).andExpect(jsonPath("$.status").value("UP"));
    mvc.perform(get("/actuator/health/liveness")).andExpect(status().isOk()).andExpect(jsonPath("$.status").value("UP"));
  }
}
