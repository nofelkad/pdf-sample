package com.acme.iam.user;

import static org.assertj.core.api.Assertions.assertThat;

import com.acme.iam.common.test.Fixtures;
import com.acme.iam.common.test.IntegrationTest;
import com.acme.iam.common.test.OrgTestData;
import com.acme.iam.common.test.PostgresTestBase;
import com.acme.iam.common.test.TestTokens;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.nio.charset.StandardCharsets;
import java.util.UUID;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.boot.test.web.server.LocalServerPort;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.jdbc.core.simple.JdbcClient;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.web.client.RestClient;

/**
 * An oversize bulk invite upload is rejected by the servlet container's multipart limit with an RFC 7807 413 carrying
 * {@code code = payload_too_large}. Runs on a real server (MockMvc does not enforce multipart limits) with a 1 KB limit.
 */
@IntegrationTest(webEnvironment = WebEnvironment.RANDOM_PORT,
    properties = {"spring.servlet.multipart.max-file-size=1KB", "spring.servlet.multipart.max-request-size=2KB"})
class BulkInviteUploadLimitIT extends PostgresTestBase {

  @LocalServerPort int port;
  @Autowired TestTokens tokens;
  @Autowired JdbcClient jdbc;
  @Autowired ObjectMapper json;

  @Test
  void anOversizeFileIs413WithAProblemCode() throws Exception {
    OrgTestData org = new OrgTestData(jdbc);
    Fixtures.Scenario s = org.fixtures().scenario();
    UUID admin = org.accountAdmin(s.accountId(), s.tenantId());
    byte[] csv = "x@example.test\n".repeat(400).getBytes(StandardCharsets.UTF_8); // ~6 KB

    LinkedMultiValueMap<String, Object> parts = new LinkedMultiValueMap<>();
    parts.add("file", new ByteArrayResource(csv) {
      @Override
      public String getFilename() {
        return "users.csv";
      }
    });
    ResponseEntity<String> response = RestClient.create("http://localhost:" + port)
        .post().uri("/api/tenants/{t}/users/bulk", s.tenantId())
        .header(HttpHeaders.AUTHORIZATION, org.adminBearer(tokens, admin, s.accountId(), s.tenantId()))
        .contentType(MediaType.MULTIPART_FORM_DATA)
        .body(parts)
        .retrieve()
        .onStatus(status -> true, (request, resp) -> { })
        .toEntity(String.class);

    assertThat(response.getStatusCode().value()).isEqualTo(413);
    assertThat(response.getHeaders().getContentType()).isNotNull();
    assertThat(response.getHeaders().getContentType().isCompatibleWith(MediaType.APPLICATION_PROBLEM_JSON)).isTrue();
    JsonNode body = json.readTree(response.getBody());
    assertThat(body.get("code").asText()).isEqualTo("payload_too_large");
    assertThat(body.get("status").asInt()).isEqualTo(413);
  }
}
