package com.acme.iam.auth;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.assertj.core.api.Assertions.within;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.header;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import com.acme.iam.account.AccountStatus;
import com.acme.iam.common.error.ApiException;
import com.acme.iam.common.test.PostgresTestBase;
import com.acme.iam.core.Claims;
import com.acme.iam.tenant.TenantStatus;
import com.acme.iam.user.MembershipStatus;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.time.Duration;
import java.time.Instant;
import java.time.OffsetDateTime;
import java.time.temporal.ChronoUnit;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.jdbc.core.simple.JdbcClient;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.security.oauth2.jwt.JwtDecoder;
import org.springframework.test.web.servlet.MockMvc;

/** P1-5.2: password login (spec section 4 flow), multi-account choice, lockout, status checks, audit. */
@AuthIT
class LoginIT extends PostgresTestBase {

  @Autowired MockMvc mvc;
  @Autowired ObjectMapper json;
  @Autowired JdbcClient jdbc;
  @Autowired PasswordService passwords;
  @Autowired JwtDecoder jwtDecoder;
  @Autowired LoginService loginService;

  AuthTestData data;
  AuthClient client;

  @BeforeEach
  void setUp() {
    data = new AuthTestData(jdbc, passwords);
    client = new AuthClient(mvc, json);
  }

  @Test
  void loginReturnsBearerAndRefreshTokensAndOpensASession() throws Exception {
    AuthTestData.TestUser u = data.user();
    String perm = data.grantTenantPermission(u.userId(), u.tenantId());
    Instant before = Instant.now();

    var result = client.login(u.email().toUpperCase(), u.password())
        .andExpect(status().isOk())
        .andExpect(header().string("Cache-Control", org.hamcrest.Matchers.containsString("no-store")))
        .andExpect(jsonPath("$.tokenType").value("Bearer"))
        .andExpect(jsonPath("$.expiresIn").value(900))
        .andExpect(jsonPath("$.activeTenantId").value(u.tenantId().toString()))
        .andReturn();
    AuthClient.Tokens tokens = client.tokens(result);

    assertThat(tokens.refreshToken()).matches("[A-Za-z0-9_-]{43}");
    assertThat(tokens.refreshExpiresAt()).isCloseTo(before.plus(30, ChronoUnit.MINUTES), within(1, ChronoUnit.MINUTES));
    Jwt jwt = jwtDecoder.decode(tokens.accessToken());
    assertThat(jwt.getSubject()).isEqualTo(u.userId().toString());
    assertThat(jwt.getClaimAsString(Claims.ACCOUNT)).isEqualTo(u.accountId().toString());
    assertThat(jwt.getClaimAsString(Claims.TENANT)).isEqualTo(u.tenantId().toString());
    assertThat(jwt.getClaimAsStringList(Claims.PERMISSIONS)).containsExactly(perm);
    assertThat(((Number) jwt.getClaim(Claims.SESSION_VERSION)).intValue()).isEqualTo(1);

    Map<String, Object> session = data.sessionByRefresh(tokens.refreshToken());
    assertThat(session.get("id").toString()).isEqualTo(jwt.getClaimAsString(Claims.SESSION));
    assertThat(session.get("user_id")).isEqualTo(u.userId());
    assertThat(session.get("active_tenant_id")).isEqualTo(u.tenantId());
    assertThat(session.get("ip").toString()).isEqualTo(client.ip());
    assertThat(session.get("user_agent")).isEqualTo(AuthClient.USER_AGENT);
    assertThat(session.get("prev_refresh_hash")).isNull();
    assertThat(((java.sql.Timestamp) session.get("expires_at")).toInstant())
        .isCloseTo(before.plus(12, ChronoUnit.HOURS), within(1, ChronoUnit.MINUTES));

    List<Map<String, Object>> audit = data.auditRows(client.lastRequestId(), "auth.login.success");
    assertThat(audit).singleElement().satisfies(row -> {
      assertThat(row).containsEntry("outcome", "SUCCESS").containsEntry("actor_type", "USER")
          .containsEntry("actor_user_id", u.userId()).containsEntry("account_id", u.accountId())
          .containsEntry("tenant_id", u.tenantId()).containsEntry("actor_ip", client.ip())
          .containsEntry("user_agent", AuthClient.USER_AGENT);
      assertThat(row.get("session_id").toString()).isEqualTo(jwt.getClaimAsString(Claims.SESSION));
    });
    assertThat(jdbc.sql("SELECT last_login_at FROM app_user WHERE id = :id").param("id", u.userId())
        .query(OffsetDateTime.class).single()).isNotNull();
  }

  @Test
  void wrongPasswordAndUnknownEmailGiveTheSame401() throws Exception {
    AuthTestData.TestUser u = data.user();

    String wrong = client.login(u.email(), "Wrong-Password-1!")
        .andExpect(status().isUnauthorized())
        .andExpect(jsonPath("$.code").value("invalid_credentials"))
        .andExpect(jsonPath("$.detail").value("Invalid email or password"))
        .andReturn().getResponse().getContentAsString();
    String wrongRequest = client.lastRequestId();
    String unknown = client.login("nobody-" + UUID.randomUUID() + "@example.test", "Wrong-Password-1!")
        .andExpect(status().isUnauthorized())
        .andReturn().getResponse().getContentAsString();
    String unknownRequest = client.lastRequestId();

    assertThat(strip(unknown)).isEqualTo(strip(wrong));
    assertThat(failedLogins(u.userId())).isEqualTo(1);
    assertThat(data.auditRows(wrongRequest, "auth.login.failed")).singleElement().satisfies(row -> {
      assertThat(row).containsEntry("outcome", "FAILURE").containsEntry("actor_type", "ANONYMOUS")
          .containsEntry("account_id", u.accountId()).containsEntry("target_id", u.userId().toString());
      assertThat(row.get("actor_user_id")).isNull();
      assertThat((String) row.get("metadata")).contains(u.email()).contains("invalid_password")
          .doesNotContain("Wrong-Password-1!");
    });
    assertThat(data.auditRows(unknownRequest, "auth.login.failed")).singleElement().satisfies(row -> {
      assertThat(row).containsEntry("actor_type", "ANONYMOUS");
      assertThat(row.get("account_id")).isNull();
      assertThat((String) row.get("metadata")).contains("unknown_user");
    });
  }

  @Test
  void theFifthFailureLocksTheUserAndALockedUserGetsTheSame401EvenWithTheRightPassword() {
    AuthTestData.TestUser u = data.user();
    LoginCommand wrong = new LoginCommand(u.email(), "Wrong-Password-1!", null);
    for (int i = 0; i < 5; i++) {
      assertInvalidCredentials(() -> loginService.login(wrong, ClientInfo.UNKNOWN));
    }

    assertThat(lockedActions(u.userId())).containsExactly("auth.locked");
    assertInvalidCredentials(() -> loginService.login(new LoginCommand(u.email(), u.password(), null), ClientInfo.UNKNOWN));
    assertInvalidCredentials(() -> loginService.login(wrong, ClientInfo.UNKNOWN));
    assertThat(lockedActions(u.userId())).containsExactly("auth.locked"); // audited once, when applied

    jdbc.sql("UPDATE app_user SET locked_until = now() - interval '1 second' WHERE id = :id")
        .param("id", u.userId()).update();
    AuthTokens tokens = loginService.login(new LoginCommand(u.email(), u.password(), null), ClientInfo.UNKNOWN);
    assertThat(tokens.activeTenantId()).isEqualTo(u.tenantId());
    assertThat(failedLogins(u.userId())).isZero();
  }

  @Test
  void theSameEmailInTwoAccountsRequiresChoosingTheAccount() throws Exception {
    AuthTestData.TestUser a = data.user();
    AuthTestData.TestUser b = data.twinInNewAccount(a, a.password());
    List<String> slugs = List.of(data.slug(a.accountId()), data.slug(b.accountId())).stream().sorted().toList();

    client.login(a.email(), a.password())
        .andExpect(status().isConflict())
        .andExpect(jsonPath("$.code").value("account_selection_required"))
        .andExpect(jsonPath("$.accounts.length()").value(2))
        .andExpect(jsonPath("$.accounts[0].slug").value(slugs.get(0)))
        .andExpect(jsonPath("$.accounts[1].slug").value(slugs.get(1)))
        .andExpect(jsonPath("$.accounts[0].name").isNotEmpty());

    client.login(a.email(), a.password(), data.slug(b.accountId()).toUpperCase())
        .andExpect(status().isOk())
        .andExpect(jsonPath("$.activeTenantId").value(b.tenantId().toString()));
  }

  @Test
  void aWrongPasswordInOneAccountStillLogsIntoTheAccountWhosePasswordMatches() throws Exception {
    AuthTestData.TestUser a = data.user();
    AuthTestData.TestUser b = data.twinInNewAccount(a, "Other-Password-77!");

    client.login(a.email(), "Other-Password-77!")
        .andExpect(status().isOk())
        .andExpect(jsonPath("$.activeTenantId").value(b.tenantId().toString()));
    assertThat(failedLogins(a.userId())).isZero();
  }

  @ParameterizedTest
  @ValueSource(strings = {"account_inactive", "tenant_inactive", "membership_inactive"})
  void anInactiveAccountTenantOrMembershipGivesTheSame401AndAuditsTheReason(String reason) throws Exception {
    AuthTestData.TestUser u = data.user();
    switch (reason) {
      case "account_inactive" -> data.fx.accountStatus(u.accountId(), AccountStatus.SUSPENDED);
      case "tenant_inactive" -> data.fx.tenantStatus(u.tenantId(), TenantStatus.SUSPENDED);
      default -> data.fx.membership(u.userId(), u.tenantId(), MembershipStatus.SUSPENDED);
    }

    client.login(u.email(), u.password())
        .andExpect(status().isUnauthorized())
        .andExpect(jsonPath("$.code").value("invalid_credentials"))
        .andExpect(jsonPath("$.detail").value("Invalid email or password"));

    assertThat(data.sessionsOf(u.userId())).isEmpty();
    assertThat(data.auditRows(client.lastRequestId(), "auth.login.failed")).singleElement()
        .satisfies(row -> assertThat((String) row.get("metadata")).contains(reason));
  }

  @Test
  void accountSettingsOverrideTheSessionLifetimes() throws Exception {
    AuthTestData.TestUser u = data.user();
    data.accountSettings(u.accountId(), "{\"session\": {\"absoluteTtl\": \"PT2H\", \"idleTtl\": \"PT5M\"}}");
    Instant before = Instant.now();

    AuthClient.Tokens tokens = client.loginOk(u.email(), u.password());

    assertThat(tokens.refreshExpiresAt()).isCloseTo(before.plus(Duration.ofMinutes(5)), within(1, ChronoUnit.MINUTES));
    assertThat(((java.sql.Timestamp) data.sessionByRefresh(tokens.refreshToken()).get("expires_at")).toInstant())
        .isCloseTo(before.plus(Duration.ofHours(2)), within(1, ChronoUnit.MINUTES));
  }

  @Test
  void flatSessionSettingKeysAreAlsoHonoured() throws Exception {
    AuthTestData.TestUser u = data.user();
    data.accountSettings(u.accountId(), "{\"session.absoluteTtl\": \"PT1H\", \"session.idleTtl\": \"PT10M\"}");
    Instant before = Instant.now();

    AuthClient.Tokens tokens = client.loginOk(u.email(), u.password());

    assertThat(tokens.refreshExpiresAt()).isCloseTo(before.plus(Duration.ofMinutes(10)), within(1, ChronoUnit.MINUTES));
  }

  @Test
  void invalidRequestBodiesAre400() throws Exception {
    client.login("someone@example.test", "")
        .andExpect(status().isBadRequest())
        .andExpect(jsonPath("$.code").value("validation_failed"));
  }

  private static String strip(String problemJson) {
    return problemJson.replaceAll("\"requestId\":\"[^\"]*\"", "").replaceAll("\"instance\":\"[^\"]*\"", "");
  }

  private int failedLogins(UUID userId) {
    return jdbc.sql("SELECT failed_logins FROM app_user WHERE id = :id").param("id", userId)
        .query(Integer.class).single();
  }

  private List<String> lockedActions(UUID userId) {
    return jdbc.sql("SELECT action FROM audit_event WHERE action = 'auth.locked' AND target_id = :id")
        .param("id", userId.toString()).query(String.class).list();
  }

  private static void assertInvalidCredentials(org.assertj.core.api.ThrowableAssert.ThrowingCallable call) {
    assertThatThrownBy(call).isInstanceOfSatisfying(ApiException.class, ex -> {
      assertThat(ex.status()).isEqualTo(HttpStatus.UNAUTHORIZED);
      assertThat(ex.code()).isEqualTo("invalid_credentials");
    });
  }
}
