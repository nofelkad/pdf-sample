package com.acme.iam.architecture;

import com.tngtech.archunit.base.DescribedPredicate;
import com.tngtech.archunit.core.domain.Dependency;
import com.tngtech.archunit.core.domain.JavaAccess;
import com.tngtech.archunit.core.domain.JavaClass;
import com.tngtech.archunit.lang.ArchCondition;
import com.tngtech.archunit.lang.ArchRule;
import com.tngtech.archunit.lang.ConditionEvents;
import com.tngtech.archunit.lang.SimpleConditionEvent;
import com.tngtech.archunit.lang.syntax.ArchRuleDefinition;
import java.util.List;
import java.util.Set;
import javax.sql.DataSource;
import org.springframework.data.jdbc.core.JdbcAggregateOperations;
import org.springframework.data.repository.Repository;
import org.springframework.jdbc.core.JdbcOperations;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcOperations;
import org.springframework.jdbc.core.simple.JdbcClient;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RestController;

/**
 * Package-by-feature rules (spec section 1, P1-1.6), parameterised by the root package so they can be exercised on
 * fixtures. A class's <em>feature</em> is the first package segment below the root ({@code com.acme.iam.role.x.Y}
 * belongs to {@code role}); {@value #SHARED_KERNEL} is the shared kernel every feature may use.
 */
final class ArchitectureRules {

  static final String SHARED_KERNEL = "common";

  private static final List<Class<?>> DATA_ACCESS_APIS = List.of(
      Repository.class, JdbcClient.class, JdbcOperations.class, NamedParameterJdbcOperations.class,
      JdbcAggregateOperations.class, DataSource.class);

  private ArchitectureRules() {}

  /** Repositories ({@code *Repository}, {@code ..repository..}, Spring Data repositories) stay inside their feature. */
  static ArchRule repositoriesAreOnlyUsedInsideTheirFeature(String root) {
    return ArchRuleDefinition.classes()
        .that(areRepositories(root))
        .should(onlyHaveDependentsInTheirOwnFeature(root))
        .allowEmptyShould(true)
        .because("a feature's persistence is private; other features go through its *Service (spec section 1)");
  }

  /** Controllers never touch persistence directly: no repositories, JdbcClient/JdbcTemplate, aggregate template. */
  static ArchRule controllersDoNotAccessPersistence(String root) {
    return ArchRuleDefinition.noClasses()
        .that(areControllers(root))
        .should().dependOnClassesThat(areRepositories(root).or(areDataAccessApis()))
        .allowEmptyShould(true)
        .because("controllers only call services (P1-1.6)");
  }

  /**
   * Controllers reach other features only through their {@code *Service} classes. Calls on records and enums (request
   * and response DTOs, value objects) and on the shared kernel are allowed.
   */
  static ArchRule controllersCallOtherFeaturesOnlyThroughServices(String root) {
    return ArchRuleDefinition.classes()
        .that(areControllers(root))
        .should(onlyCallOtherFeaturesThroughServices(root))
        .allowEmptyShould(true)
        .because("packages talk to each other only through their *Service classes (spec section 1)");
  }

  static List<ArchRule> all(String root) {
    return List.of(
        repositoriesAreOnlyUsedInsideTheirFeature(root),
        controllersDoNotAccessPersistence(root),
        controllersCallOtherFeaturesOnlyThroughServices(root));
  }

  // ----------------------------------------------------------------------------------------------- predicates

  static DescribedPredicate<JavaClass> areRepositories(String root) {
    return DescribedPredicate.describe("are repositories", c ->
        c.getPackageName().startsWith(root + ".")
            && (c.getSimpleName().endsWith("Repository")
                || ("." + c.getPackageName() + ".").contains(".repository.")
                || c.isAssignableTo(Repository.class)));
  }

  static DescribedPredicate<JavaClass> areControllers(String root) {
    return DescribedPredicate.describe("are controllers", c ->
        c.getPackageName().startsWith(root + ".")
            && (c.isAnnotatedWith(RestController.class)
                || c.isAnnotatedWith(Controller.class)
                || c.getSimpleName().endsWith("Controller")));
  }

  private static DescribedPredicate<JavaClass> areDataAccessApis() {
    return DescribedPredicate.describe("are data access APIs " + DATA_ACCESS_APIS.stream()
        .map(Class::getSimpleName).toList(), c -> DATA_ACCESS_APIS.stream().anyMatch(c::isAssignableTo));
  }

  // ----------------------------------------------------------------------------------------------- conditions

  private static ArchCondition<JavaClass> onlyHaveDependentsInTheirOwnFeature(String root) {
    return new ArchCondition<>("only be used from their own feature package") {
      @Override
      public void check(JavaClass repository, ConditionEvents events) {
        String feature = featureOf(root, repository);
        for (Dependency dependency : repository.getDirectDependenciesToSelf()) {
          JavaClass origin = dependency.getOriginClass();
          if (!feature.equals(featureOf(root, origin))) {
            events.add(SimpleConditionEvent.violated(dependency, dependency.getDescription()));
          }
        }
      }
    };
  }

  private static ArchCondition<JavaClass> onlyCallOtherFeaturesThroughServices(String root) {
    return new ArchCondition<>("only call other features through *Service classes") {
      @Override
      public void check(JavaClass controller, ConditionEvents events) {
        String feature = featureOf(root, controller);
        Set<JavaAccess<?>> accesses = controller.getAccessesFromSelf();
        for (JavaAccess<?> access : accesses) {
          JavaClass target = access.getTargetOwner();
          String targetFeature = featureOf(root, target);
          boolean otherFeature = target.getPackageName().startsWith(root + ".")
              && !targetFeature.isEmpty()
              && !targetFeature.equals(feature)
              && !targetFeature.equals(SHARED_KERNEL);
          boolean allowed = target.getSimpleName().endsWith("Service") || target.isRecord() || target.isEnum();
          if (otherFeature && !allowed) {
            events.add(SimpleConditionEvent.violated(access, access.getDescription()));
          }
        }
      }
    };
  }

  /** First package segment below {@code root}; empty for classes outside it or directly in it. */
  static String featureOf(String root, JavaClass javaClass) {
    String pkg = javaClass.getPackageName();
    if (!pkg.startsWith(root + ".")) {
      return "";
    }
    String rest = pkg.substring(root.length() + 1);
    int dot = rest.indexOf('.');
    return dot < 0 ? rest : rest.substring(0, dot);
  }
}
