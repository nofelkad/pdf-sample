package com.acme.iam.auth;

import static org.assertj.core.api.Assertions.assertThat;

import com.acme.iam.common.test.Fixtures;
import com.acme.iam.common.test.IntegrationTest;
import com.acme.iam.common.test.PostgresTestBase;
import com.acme.iam.core.revocation.RevocationRegistry;
import java.time.Clock;
import java.time.Duration;
import java.util.List;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.simple.JdbcClient;
import org.springframework.transaction.support.TransactionTemplate;

/**
 * Task 9 failure modes (IAM restart): a (re)started instance must reject tokens revoked before it started from its
 * very first request. The in-service poller loads the startup window synchronously in {@code start()}, in a lifecycle
 * phase before the web server accepts requests, like the iam-client poller.
 */
@IntegrationTest
class RevocationPollerStartupIT extends PostgresTestBase {

  /** Spring Boot's web server lifecycle phase ({@code WebServerStartStopLifecycle}). */
  private static final int WEB_SERVER_PHASE = Integer.MAX_VALUE - 1;

  @Autowired RevocationService revocations;
  @Autowired TransactionTemplate tx;
  @Autowired JdbcClient jdbc;
  @Autowired Clock clock;

  @Test
  void aStartingPollerKnowsEarlierRevocationsBeforeStartReturns() {
    Fixtures fx = new Fixtures(jdbc);
    Fixtures.Scenario s = fx.scenario();
    int oldSv = jdbc.sql("SELECT session_version FROM app_user WHERE id = :id").param("id", s.userId())
        .query(Integer.class).single();
    tx.executeWithoutResult(t -> revocations.revokeUsers(List.of(s.userId()), "test.restart"));

    RevocationRegistry registry = new RevocationRegistry(clock);
    RevocationPoller restarted = new RevocationPoller(revocations, registry, clock, Duration.ofHours(1),
        Duration.ofMinutes(20), Duration.ofHours(1));
    try {
      restarted.start();

      assertThat(registry.isRevoked(s.userId(), oldSv)).as("revoked before the first request").isTrue();
    } finally {
      restarted.stop();
    }
  }

  @Test
  void startsBeforeTheWebServer() {
    RevocationPoller poller = new RevocationPoller(revocations, new RevocationRegistry(clock), clock,
        Duration.ofSeconds(5), Duration.ofMinutes(20), Duration.ofHours(1));
    assertThat(poller.getPhase()).isLessThan(WEB_SERVER_PHASE);
  }
}
