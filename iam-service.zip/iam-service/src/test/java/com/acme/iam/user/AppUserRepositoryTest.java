package com.acme.iam.user;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

import com.acme.iam.common.Ids;
import com.acme.iam.common.test.Fixtures;
import com.acme.iam.common.test.JdbcSliceTest;
import com.acme.iam.common.test.PostgresTestBase;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.UUID;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.OptimisticLockingFailureException;
import org.springframework.jdbc.core.simple.JdbcClient;

/** P1-3.2: AppUser (+Membership) round trip and optimistic locking. */
@JdbcSliceTest
class AppUserRepositoryTest extends PostgresTestBase {

  @Autowired AppUserRepository users;
  @Autowired JdbcClient jdbc;

  private final Instant now = Instant.now().truncatedTo(ChronoUnit.MICROS);

  @Test
  void roundTripsUserWithMemberships() {
    Fixtures fx = new Fixtures(jdbc);
    UUID account = fx.account();
    UUID primary = fx.tenant(account);
    UUID second = fx.tenant(account);
    String email = "Jane.Doe-" + Ids.newId() + "@Example.test";

    AppUser saved = users.save(AppUser.invite(account, primary, email, "Jane", now)
        .withMembership(new Membership(second, MembershipStatus.SUSPENDED, now)));
    assertThat(saved.id()).isNotNull();
    assertThat(saved.version()).isZero();

    AppUser loaded = users.findById(saved.id()).orElseThrow();
    assertThat(loaded.account()).isEqualTo(account);
    assertThat(loaded.primaryTenant()).isEqualTo(primary);
    assertThat(loaded.email()).isEqualTo(email);
    assertThat(loaded.displayName()).isEqualTo("Jane");
    assertThat(loaded.status()).isEqualTo(UserStatus.INVITED);
    assertThat(loaded.passwordHash()).isNull();
    assertThat(loaded.failedLogins()).isZero();
    assertThat(loaded.sessionVersion()).isEqualTo(1);
    assertThat(loaded.memberships()).containsExactlyInAnyOrder(
        new Membership(primary, MembershipStatus.ACTIVE, now),
        new Membership(second, MembershipStatus.SUSPENDED, now));
    assertThat(loaded.hasActiveMembership(primary)).isTrue();
    assertThat(loaded.hasActiveMembership(second)).isFalse();

    AppUser activated = users.save(loaded.withPassword("$argon2id$fake", now).withStatus(UserStatus.ACTIVE)
        .withoutMembership(second));
    assertThat(activated.version()).isEqualTo(1);
    AppUser reloaded = users.findById(saved.id()).orElseThrow();
    assertThat(reloaded.status()).isEqualTo(UserStatus.ACTIVE);
    assertThat(reloaded.passwordHash()).isEqualTo("$argon2id$fake");
    assertThat(reloaded.passwordChangedAt()).isEqualTo(now);
    assertThat(reloaded.memberships()).extracting(Membership::tenantId).containsExactly(primary);
  }

  @Test
  void emailLookupIsCaseInsensitiveAndAccountScoped() {
    Fixtures fx = new Fixtures(jdbc);
    Fixtures.Scenario s = fx.scenario();
    UUID otherAccount = fx.account();
    String email = fx.email(s.userId());

    assertThat(users.findByAccountAndEmail(s.accountId(), email.toUpperCase())).map(AppUser::id).contains(s.userId());
    assertThat(users.findByAccountAndEmail(otherAccount, email)).isEmpty();
    assertThat(users.findByIdInAccount(s.userId(), s.accountId())).isPresent();
    assertThat(users.findByIdInAccount(s.userId(), otherAccount)).isEmpty();
  }

  @Test
  void concurrentModificationIsRejected() {
    Fixtures fx = new Fixtures(jdbc);
    Fixtures.Scenario s = fx.scenario();
    AppUser first = users.findById(s.userId()).orElseThrow();
    AppUser second = users.findById(s.userId()).orElseThrow();

    users.save(first.withDisplayName("Winner"));

    assertThatThrownBy(() -> users.save(second.withDisplayName("Loser")))
        .isInstanceOf(OptimisticLockingFailureException.class);
    assertThat(users.findById(s.userId()).orElseThrow().displayName()).isEqualTo("Winner");
  }
}
