package com.acme.iam.common.security;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

import com.acme.iam.core.Claims;
import java.util.List;
import java.util.UUID;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Test;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.authentication.AuthenticationCredentialsNotFoundException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.oauth2.jwt.Jwt;

class CurrentUserTest {

  private final CurrentUser currentUser = new CurrentUser();

  @AfterEach
  void clear() {
    SecurityContextHolder.clearContext();
  }

  @Test
  void unauthenticatedAccessThrowsCredentialsNotFound() {
    assertThat(currentUser.isAuthenticated()).isFalse();
    assertThatThrownBy(currentUser::userId).isInstanceOf(AuthenticationCredentialsNotFoundException.class);
    assertThatThrownBy(currentUser::permissions).isInstanceOf(AuthenticationCredentialsNotFoundException.class);
    assertThatThrownBy(currentUser::isApp).isInstanceOf(AuthenticationCredentialsNotFoundException.class);

    SecurityContextHolder.getContext().setAuthentication(UsernamePasswordAuthenticationToken.authenticated("u", "p", List.of()));
    assertThatThrownBy(currentUser::tenantId).isInstanceOf(AuthenticationCredentialsNotFoundException.class);
  }

  @Test
  void readsUserClaims() {
    UUID user = UUID.randomUUID();
    UUID account = UUID.randomUUID();
    UUID tenant = UUID.randomUUID();
    UUID session = UUID.randomUUID();
    authenticate(Jwt.withTokenValue("t").header("alg", "RS256").subject(user.toString())
        .claim(Claims.ACCOUNT, account.toString()).claim(Claims.TENANT, tenant.toString())
        .claim(Claims.SESSION, session.toString()).claim(Claims.SESSION_VERSION, 3L)
        .claim(Claims.PERMISSIONS, List.of("a.b", "internal.revocations.read")).build());

    assertThat(currentUser.isApp()).isFalse();
    assertThat(currentUser.userId()).isEqualTo(user);
    assertThat(currentUser.accountId()).isEqualTo(account);
    assertThat(currentUser.tenantId()).isEqualTo(tenant);
    assertThat(currentUser.sessionId()).isEqualTo(session);
    assertThat(currentUser.sessionVersion()).isEqualTo(3);
    assertThat(currentUser.permissions()).containsExactly("a.b");
    assertThat(currentUser.hasPermission("a.b")).isTrue();
    assertThatThrownBy(currentUser::clientId).isInstanceOf(AccessDeniedException.class);
  }

  @Test
  void applicationTokenHasClientButNoUser() {
    authenticate(Jwt.withTokenValue("t").header("alg", "RS256").subject("app:billing")
        .claim(Claims.TYPE, Claims.TYPE_APP).claim(Claims.PRODUCT, "BILLING")
        .claim(Claims.PERMISSIONS, Claims.APP_PERMISSIONS).build());

    assertThat(currentUser.isApp()).isTrue();
    assertThat(currentUser.clientId()).isEqualTo("billing");
    assertThat(currentUser.productCode()).isEqualTo("BILLING");
    assertThat(currentUser.permissions()).containsExactlyInAnyOrderElementsOf(Claims.APP_PERMISSIONS);
    assertThatThrownBy(currentUser::userId).isInstanceOf(AccessDeniedException.class);
    assertThat(AppCaller.currentClientId()).contains("billing");
  }

  private static void authenticate(Jwt jwt) {
    SecurityContextHolder.getContext().setAuthentication(SecurityConfig.permsConverter().convert(jwt));
  }
}
