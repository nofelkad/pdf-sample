package com.acme.iam.audit;

import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.http.HttpHeaders.AUTHORIZATION;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import com.acme.iam.common.Ids;
import com.acme.iam.common.security.SecurityTestData;
import com.acme.iam.common.test.IntegrationTest;
import com.acme.iam.common.test.OrgTestData;
import com.acme.iam.common.test.PostgresTestBase;
import com.acme.iam.common.test.TestTokens;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.time.Clock;
import java.time.Duration;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.jdbc.core.simple.JdbcClient;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.ResultActions;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;

/** P1-9.5 {@code GET /api/audit/events} and P1-9.6 {@code GET /api/audit/targets/{type}/{id}}. */
@IntegrationTest
@AutoConfigureMockMvc
class AuditSearchIT extends PostgresTestBase {

  private static final String EVENTS = "/api/audit/events";

  @Autowired MockMvc mvc;
  @Autowired TestTokens tokens;
  @Autowired JdbcClient jdbc;
  @Autowired ObjectMapper json;
  @Autowired Clock clock;

  private AuditTestData data;
  private Instant now;
  private UUID accountA;
  private UUID accountB;
  private UUID tenantA1;
  private UUID tenantA2;
  private UUID userA;
  private String readerA;
  private String readerB;

  @BeforeEach
  void setUp() {
    AuditTestData.ensureRecentPartitions();   // idempotent; needs the migrated schema, so not @BeforeAll
    data = new AuditTestData(jdbc);
    // Final review C1: the trigger rows of the fixtures below (account, tenants, users, roles, assignments) now carry
    // their account, so they are visible to these searches. The test events are placed relative to a "now" one hour
    // in the past, and every window ends shortly after it, so the fixtures' real-time rows stay outside.
    now = clock.instant().minus(Duration.ofHours(1)).truncatedTo(ChronoUnit.MICROS);
    SecurityTestData sd = new SecurityTestData(jdbc);
    accountA = sd.account();
    accountB = sd.account();
    tenantA1 = sd.tenant(accountA);
    tenantA2 = sd.tenant(accountA);
    UUID tenantB = sd.tenant(accountB);
    userA = Ids.newId();
    // Auditors: iam.audit.read through an ACCOUNT-scope assignment (Ruling R25), so they see every tenant
    UUID auditorA = sd.user(accountA, tenantA1);
    sd.assign(auditorA, sd.role(accountA, "iam.audit.read"), "ACCOUNT", accountA, null);
    readerA = tokens.user(auditorA).account(accountA).tenant(tenantA1).perms("iam.audit.read").bearer();
    UUID auditorB = sd.user(accountB, tenantB);
    sd.assign(auditorB, sd.role(accountB, "iam.audit.read"), "ACCOUNT", accountB, null);
    readerB = tokens.user(auditorB).account(accountB).tenant(tenantB).perms("iam.audit.read").bearer();
  }

  // --------------------------------------------------------------------------------------- isolation (I10)

  @Test
  void returnsOnlyTheCallersAccountAndAllFields() throws Exception {
    UUID mine = data.event(accountA, "iam.role.update", now.minusSeconds(60)).tenant(tenantA1).actor(userA)
        .target("role", "R-1").metadata("{\"why\":\"test\"}").insert();
    data.event(accountB, "iam.role.update", now.minusSeconds(60)).insert();
    data.event(null, "auth.login.failed", now.minusSeconds(60)).insert();

    JsonNode page = search(readerA, window(now)).andExpect(status().isOk()).andReturn().getResponse()
        .getContentAsString().transform(this::tree);

    assertThat(page.get("items")).hasSize(1);
    JsonNode item = page.get("items").get(0);
    assertThat(item.get("eventId").asText()).isEqualTo(mine.toString());
    assertThat(item.get("accountId").asText()).isEqualTo(accountA.toString());
    assertThat(item.get("tenantId").asText()).isEqualTo(tenantA1.toString());
    assertThat(item.get("actorUserId").asText()).isEqualTo(userA.toString());
    assertThat(item.get("actorType").asText()).isEqualTo("USER");
    assertThat(item.get("source").asText()).isEqualTo("IAM");
    assertThat(item.get("action").asText()).isEqualTo("iam.role.update");
    assertThat(item.get("targetType").asText()).isEqualTo("role");
    assertThat(item.get("targetId").asText()).isEqualTo("R-1");
    assertThat(item.get("outcome").asText()).isEqualTo("SUCCESS");
    assertThat(item.get("actorIp").asText()).isEqualTo("198.51.100.7");
    assertThat(item.get("userAgent").asText()).isEqualTo("JUnit/1.0");
    assertThat(Instant.parse(item.get("occurredAt").asText())).isEqualTo(now.minusSeconds(60));
    assertThat(item.get("receivedAt").asText()).isNotBlank();
    assertThat(item.at("/metadata/why").asText()).isEqualTo("test");
    assertThat(item.at("/before/k").asText()).isEqualTo("before");
    assertThat(item.at("/after/k").asText()).isEqualTo("after");
    assertThat(page.has("nextCursor")).isFalse();
  }

  @Test
  void anotherAccountSeesNothingOfMine() throws Exception {
    data.event(accountA, "iam.role.update", now.minusSeconds(60)).tenant(tenantA1).insert();

    search(readerB, window(now)).andExpect(status().isOk()).andExpect(jsonPath("$.items").isEmpty());
  }

  @Test
  void aTenantIdOfAnotherAccountIsNotFound() throws Exception {
    data.event(accountA, "iam.role.update", now.minusSeconds(60)).tenant(tenantA1).insert();

    search(readerB, window(now).param("tenantId", tenantA1.toString())).andExpect(status().isNotFound())
        .andExpect(jsonPath("$.code").value("tenant_not_found"));
  }

  @Test
  void aNonPlatformCallerMayNotNameAnotherAccount() throws Exception {
    data.event(accountA, "iam.role.update", now.minusSeconds(60)).insert();

    search(readerB, window(now).param("accountId", accountA.toString())).andExpect(status().isForbidden())
        .andExpect(jsonPath("$.code").value("account_filter_forbidden"));
    search(readerB, window(now).param("accountId", accountB.toString())).andExpect(status().isOk());
  }

  @Test
  void aPlatformCallerMayNameAnAccountButOtherwiseSeesOnlyTheirOwn() throws Exception {
    data.event(accountA, "iam.role.update", now.minusSeconds(60)).insert();
    OrgTestData org = new OrgTestData(jdbc);
    String platform = org.platformBearer(tokens, org.platformOperator(), "iam.audit.read", "platform.account.manage");

    search(platform, window(now).param("accountId", accountA.toString())).andExpect(status().isOk())
        .andExpect(jsonPath("$.items.length()").value(1));
    search(platform, window(now)).andExpect(status().isOk())
        .andExpect(jsonPath("$.items[?(@.accountId == '" + accountA + "')]").isEmpty());
  }

  /** Task 9: the platform permission counts only for callers of the PLATFORM account. */
  @Test
  void thePlatformPermissionOutsideThePlatformAccountCannotNameAnotherAccount() throws Exception {
    data.event(accountA, "iam.role.update", now.minusSeconds(60)).insert();
    String forged = tokens.user(Ids.newId()).account(accountB).tenant(Ids.newId())
        .perms("iam.audit.read", "platform.account.manage").bearer();

    search(forged, window(now).param("accountId", accountA.toString())).andExpect(status().isForbidden())
        .andExpect(jsonPath("$.code").value("account_filter_forbidden"));
  }

  @Test
  void platformManageAloneDoesNotGrantReadingAudit() throws Exception {
    String platformOnly = tokens.user(Ids.newId()).account(accountB).perms("platform.account.manage").bearer();

    search(platformOnly, window(now).param("accountId", accountA.toString())).andExpect(status().isForbidden());
  }

  // --------------------------------------------------------------------------------------- authorization

  @Test
  void authenticationAndPermissionAreRequired() throws Exception {
    mvc.perform(window(now)).andExpect(status().isUnauthorized());
    search(tokens.user(Ids.newId()).account(accountA).bearer(), window(now)).andExpect(status().isForbidden());
    search(tokens.user(Ids.newId()).account(accountA).perms("iam.audit.export", "iam.user.manage").bearer(), window(now))
        .andExpect(status().isForbidden());
    search(TestTokens.bearer(tokens.appToken("billing-svc", "BILLING")), window(now))
        .andExpect(status().isForbidden());
  }

  // --------------------------------------------------------------------------------------- filters

  @Test
  void filtersByTenantActorTargetAndOutcome() throws Exception {
    UUID otherUser = Ids.newId();
    UUID e1 = data.event(accountA, "iam.role.update", now.minusSeconds(50)).tenant(tenantA1).actor(userA)
        .target("role", "R-1").insert();
    UUID e2 = data.event(accountA, "iam.role.update", now.minusSeconds(40)).tenant(tenantA2).actor(otherUser)
        .target("role", "R-2").outcome("DENIED").insert();
    UUID e3 = data.event(accountA, "iam.user.update", now.minusSeconds(30)).tenant(tenantA1).actor(otherUser)
        .target("user", "R-1").outcome("FAILURE").insert();

    assertThat(ids(readerA, window(now).param("tenantId", tenantA1.toString()))).containsExactly(e3, e1);
    assertThat(ids(readerA, window(now).param("actorUserId", otherUser.toString()))).containsExactly(e3, e2);
    assertThat(ids(readerA, window(now).param("targetType", "role"))).containsExactly(e2, e1);
    assertThat(ids(readerA, window(now).param("targetType", "role").param("targetId", "R-1"))).containsExactly(e1);
    assertThat(ids(readerA, window(now).param("targetId", "R-1"))).containsExactly(e3, e1);
    assertThat(ids(readerA, window(now).param("outcome", "DENIED"))).containsExactly(e2);
    assertThat(ids(readerA, window(now).param("outcome", "FAILURE").param("tenantId", tenantA1.toString())))
        .containsExactly(e3);
    assertThat(ids(readerA, window(now).param("outcome", "SUCCESS").param("tenantId", tenantA2.toString()))).isEmpty();
  }

  @Test
  void actionIsAPrefixAndWildcardsAreLiteral() throws Exception {
    UUID a = data.event(accountA, "iam.role.update", now.minusSeconds(50)).insert();
    UUID b = data.event(accountA, "iam.role.insert", now.minusSeconds(40)).insert();
    UUID c = data.event(accountA, "iam.user.update", now.minusSeconds(30)).insert();
    UUID underscore = data.event(accountA, "a_b.done", now.minusSeconds(20)).insert();
    UUID lookalike = data.event(accountA, "axb.done", now.minusSeconds(10)).insert();

    assertThat(ids(readerA, window(now).param("action", "iam.role."))).containsExactly(b, a);
    assertThat(ids(readerA, window(now).param("action", "iam."))).containsExactly(c, b, a);
    assertThat(ids(readerA, window(now).param("action", "iam.role.update"))).containsExactly(a);
    assertThat(ids(readerA, window(now).param("action", "role."))).as("a prefix, not a contains").isEmpty();
    assertThat(ids(readerA, window(now).param("action", "a_"))).as("_ is not a wildcard")
        .containsExactly(underscore);
    assertThat(lookalike).isNotNull();
  }

  @Test
  void anActionPrefixMustLookLikeAnAction() throws Exception {
    for (String bad : List.of("x' OR '1'='1", "%", "iam role", "A", "a".repeat(129))) {
      search(readerA, window(now).param("action", bad)).andExpect(status().isBadRequest())
          .andExpect(jsonPath("$.code").value("invalid_action_prefix"));
    }
  }

  @Test
  void injectionAttemptsInOtherFiltersAreJustValues() throws Exception {
    data.event(accountA, "iam.role.update", now.minusSeconds(50)).target("role", "R-1").insert();

    search(readerA, window(now).param("targetId", "R-1' OR '1'='1")).andExpect(status().isOk())
        .andExpect(jsonPath("$.items").isEmpty());
    search(readerA, window(now).param("targetType", "role'; DROP TABLE audit_event; --")).andExpect(status().isOk())
        .andExpect(jsonPath("$.items").isEmpty());
    assertThat(ids(readerA, window(now))).hasSize(1);
  }

  @Test
  void fromIsInclusiveAndToIsExclusive() throws Exception {
    Instant t = now.minus(Duration.ofHours(2));
    UUID atFrom = data.event(accountA, "x.from", t).insert();
    UUID inside = data.event(accountA, "x.inside", t.plusSeconds(30)).insert();
    data.event(accountA, "x.to", t.plusSeconds(60)).insert();
    data.event(accountA, "x.before", t.minusMillis(1)).insert();

    assertThat(ids(readerA, get(EVENTS).param("from", t.toString()).param("to", t.plusSeconds(60).toString())))
        .containsExactly(inside, atFrom);
  }

  // --------------------------------------------------------------------------------------- window

  @Test
  void theWindowIsRequiredAndAtMostNinetyTwoDays() throws Exception {
    Instant to = now.truncatedTo(ChronoUnit.SECONDS);
    search(readerA, get(EVENTS)).andExpect(status().isBadRequest()).andExpect(jsonPath("$.code").value("window_required"));
    search(readerA, get(EVENTS).param("from", to.minusSeconds(60).toString())).andExpect(status().isBadRequest())
        .andExpect(jsonPath("$.code").value("window_required"));
    search(readerA, get(EVENTS).param("to", to.toString())).andExpect(status().isBadRequest())
        .andExpect(jsonPath("$.code").value("window_required"));

    search(readerA, get(EVENTS).param("from", to.minus(Duration.ofDays(92)).toString()).param("to", to.toString()))
        .andExpect(status().isOk());
    search(readerA, get(EVENTS).param("from", to.minus(Duration.ofDays(92)).minusSeconds(1).toString())
        .param("to", to.toString())).andExpect(status().isBadRequest())
        .andExpect(jsonPath("$.code").value("window_too_large"));
    search(readerA, get(EVENTS).param("from", to.toString()).param("to", to.toString())).andExpect(status().isBadRequest())
        .andExpect(jsonPath("$.code").value("invalid_window"));
    search(readerA, get(EVENTS).param("from", to.plusSeconds(5).toString()).param("to", to.toString()))
        .andExpect(status().isBadRequest()).andExpect(jsonPath("$.code").value("invalid_window"));
    search(readerA, get(EVENTS).param("from", "yesterday").param("to", to.toString())).andExpect(status().isBadRequest());
  }

  // --------------------------------------------------------------------------------------- keyset paging

  @Test
  void keysetPagingWalksEveryEventOnceInDescendingOrderEvenWithEqualTimestamps() throws Exception {
    Instant tie = now.minusSeconds(120);
    Set<UUID> expected = new HashSet<>();
    for (int i = 0; i < 4; i++) {
      expected.add(data.event(accountA, "page.tie", tie).insert());
    }
    for (int i = 0; i < 5; i++) {
      expected.add(data.event(accountA, "page.later", now.minusSeconds(100 - i)).insert());
    }
    expected.add(data.event(accountA, "page.tie", tie.minusSeconds(10)).insert());
    expected.add(data.event(accountA, "page.tie", tie.minusSeconds(10)).insert());

    List<UUID> walked = new ArrayList<>();
    List<String> order = new ArrayList<>();
    String cursor = null;
    int pages = 0;
    do {
      MockHttpServletRequestBuilder request = window(now).param("limit", "4");
      if (cursor != null) {
        request.param("cursor", cursor);
      }
      JsonNode page = search(readerA, request).andExpect(status().isOk()).andReturn().getResponse()
          .getContentAsString().transform(this::tree);
      for (JsonNode item : page.get("items")) {
        walked.add(UUID.fromString(item.get("eventId").asText()));
        order.add(item.get("occurredAt").asText() + "|" + item.get("eventId").asText());
      }
      cursor = page.has("nextCursor") ? page.get("nextCursor").asText() : null;
      pages++;
    } while (cursor != null && pages < 10);

    assertThat(pages).isEqualTo(3);
    assertThat(walked).hasSize(11).doesNotHaveDuplicates().containsExactlyInAnyOrderElementsOf(expected);
    List<String> sorted = new ArrayList<>(order);
    sorted.sort((x, y) -> {
      int byTime = Instant.parse(y.substring(0, y.indexOf('|'))).compareTo(Instant.parse(x.substring(0, x.indexOf('|'))));
      return byTime != 0 ? byTime : y.substring(y.indexOf('|')).compareTo(x.substring(x.indexOf('|')));
    });
    assertThat(order).isEqualTo(sorted);
  }

  @Test
  void limitIsCappedAtTwoHundredAndMustBePositive() throws Exception {
    jdbc.sql("""
            INSERT INTO audit_event (event_id, occurred_at, account_id, source, actor_type, action, outcome)
            SELECT gen_random_uuid(), CAST(:base AS timestamptz) - (g * interval '1 second'), :acc, 'IAM', 'SYSTEM',
                   'bulk.row', 'SUCCESS'
            FROM generate_series(1, 205) g""")
        .param("base", now.minusSeconds(10).toString()).param("acc", accountA).update();

    search(readerA, window(now).param("limit", "1000")).andExpect(status().isOk())
        .andExpect(jsonPath("$.items.length()").value(200)).andExpect(jsonPath("$.nextCursor").isNotEmpty());
    search(readerA, window(now)).andExpect(jsonPath("$.items.length()").value(50));
    search(readerA, window(now).param("limit", "0")).andExpect(status().isBadRequest())
        .andExpect(jsonPath("$.code").value("invalid_limit"));
  }

  @Test
  void aMalformedCursorIsABadRequest() throws Exception {
    search(readerA, window(now).param("cursor", "garbage")).andExpect(status().isBadRequest())
        .andExpect(jsonPath("$.code").value("invalid_cursor"));
  }

  // --------------------------------------------------------------------------------------- target history

  @Test
  void targetHistoryListsTheRecordsEventsForTheCallersAccountOnly() throws Exception {
    UUID first = data.event(accountA, "doc.created", now.minus(Duration.ofDays(40))).target("document", "D-1").insert();
    UUID second = data.event(accountA, "doc.updated", now.minus(Duration.ofDays(2))).target("document", "D-1").insert();
    data.event(accountA, "doc.updated", now.minusSeconds(5)).target("document", "D-2").insert();
    data.event(accountB, "doc.updated", now.minusSeconds(5)).target("document", "D-1").insert();

    JsonNode mine = tree(mvc.perform(get("/api/audit/targets/document/D-1").header(AUTHORIZATION, readerA))
        .andExpect(status().isOk()).andReturn().getResponse().getContentAsString());
    assertThat(mine.get("items")).extracting(n -> n.get("eventId").asText())
        .containsExactly(second.toString(), first.toString());

    mvc.perform(get("/api/audit/targets/document/D-1").header(AUTHORIZATION, readerB)).andExpect(status().isOk())
        .andExpect(jsonPath("$.items.length()").value(1))
        .andExpect(jsonPath("$.items[0].accountId").value(accountB.toString()));
  }

  @Test
  void targetHistoryPagesByKeysetAndHonoursAnOptionalWindow() throws Exception {
    for (int i = 0; i < 5; i++) {
      data.event(accountA, "doc.updated", now.minus(Duration.ofDays(i * 20L + 1))).target("document", "D-9").insert();
    }

    JsonNode page1 = tree(mvc.perform(get("/api/audit/targets/document/D-9").param("limit", "2")
        .header(AUTHORIZATION, readerA)).andExpect(status().isOk()).andReturn().getResponse().getContentAsString());
    assertThat(page1.get("items")).hasSize(2);
    JsonNode page2 = tree(mvc.perform(get("/api/audit/targets/document/D-9").param("limit", "2")
        .param("cursor", page1.get("nextCursor").asText()).header(AUTHORIZATION, readerA))
        .andExpect(status().isOk()).andReturn().getResponse().getContentAsString());
    assertThat(page2.get("items")).hasSize(2);
    assertThat(page2.get("items").get(0).get("occurredAt").asText())
        .isLessThan(page1.get("items").get(1).get("occurredAt").asText());

    mvc.perform(get("/api/audit/targets/document/D-9").param("from", now.minus(Duration.ofDays(30)).toString())
            .param("to", now.toString()).header(AUTHORIZATION, readerA))
        .andExpect(status().isOk()).andExpect(jsonPath("$.items.length()").value(2));
  }

  @Test
  void targetHistoryRequiresTheAuditReadPermission() throws Exception {
    mvc.perform(get("/api/audit/targets/document/D-1")).andExpect(status().isUnauthorized());
    mvc.perform(get("/api/audit/targets/document/D-1").header(AUTHORIZATION,
            tokens.user(Ids.newId()).account(accountA).perms("iam.audit.export").bearer()))
        .andExpect(status().isForbidden());
    mvc.perform(get("/api/audit/targets/document/D-1").header(AUTHORIZATION,
            TestTokens.bearer(tokens.appToken("billing-svc", "BILLING"))))
        .andExpect(status().isForbidden());
  }

  @Test
  void targetHistoryOfAnotherAccountsRecordIsEmptyNotAnError() throws Exception {
    data.event(accountA, "doc.updated", now.minusSeconds(5)).target("document", "D-7").insert();

    mvc.perform(get("/api/audit/targets/document/D-7").header(AUTHORIZATION, readerB)).andExpect(status().isOk())
        .andExpect(jsonPath("$.items").isEmpty());
    mvc.perform(get("/api/audit/targets/document/D-7").param("accountId", accountA.toString())
            .header(AUTHORIZATION, readerB))
        .andExpect(status().isForbidden()).andExpect(jsonPath("$.code").value("account_filter_forbidden"));
  }

  // --------------------------------------------------------------------------------------- helpers

  private MockHttpServletRequestBuilder window(Instant to) {
    return get(EVENTS).param("from", to.minus(Duration.ofDays(5)).toString()).param("to", to.plusSeconds(1).toString());
  }

  private ResultActions search(String bearer, MockHttpServletRequestBuilder request) throws Exception {
    return mvc.perform(request.header(AUTHORIZATION, bearer));
  }

  private List<UUID> ids(String bearer, MockHttpServletRequestBuilder request) throws Exception {
    JsonNode page = tree(search(bearer, request).andExpect(status().isOk()).andReturn().getResponse()
        .getContentAsString());
    List<UUID> ids = new ArrayList<>();
    page.get("items").forEach(n -> ids.add(UUID.fromString(n.get("eventId").asText())));
    return ids;
  }

  private JsonNode tree(String s) {
    try {
      return json.readTree(s);
    } catch (Exception e) {
      throw new IllegalStateException(e);
    }
  }
}
