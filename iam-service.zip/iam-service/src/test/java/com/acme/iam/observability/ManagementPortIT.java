package com.acme.iam.observability;

import static org.assertj.core.api.Assertions.assertThat;

import com.acme.iam.common.test.IntegrationTest;
import com.acme.iam.common.test.PostgresTestBase;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.autoconfigure.actuate.observability.AutoConfigureObservability;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.server.LocalManagementPort;
import org.springframework.boot.test.web.server.LocalServerPort;
import org.springframework.test.context.DynamicPropertyRegistry;
import org.springframework.test.context.DynamicPropertySource;

/**
 * Ruling R36 (Task 9): with {@code management.server.port} different from the server port (the production default,
 * 8081), actuator lives on the management port only, unauthenticated; the application port answers nothing but the
 * liveness and readiness probes.
 */
@IntegrationTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@AutoConfigureObservability // Spring Boot tests switch metrics export off unless asked
class ManagementPortIT extends PostgresTestBase {

  private static final HttpClient HTTP = HttpClient.newHttpClient();

  @DynamicPropertySource
  static void managementPort(DynamicPropertyRegistry registry) {
    registry.add("management.server.port", ManagementPortIT::freePort);
  }

  @LocalServerPort int serverPort;
  @LocalManagementPort int managementPort;

  @Test
  void theApplicationPortServesOnlyTheProbes() throws Exception {
    assertThat(managementPort).isNotEqualTo(serverPort);
    assertThat(get(serverPort, "/actuator/health/liveness")).isEqualTo(200);
    assertThat(get(serverPort, "/actuator/health/readiness")).isIn(200, 503);
    assertThat(body(serverPort, "/actuator/health/liveness")).isEqualTo("{\"status\":\"UP\"}");
    for (String hidden : new String[] {"/actuator/prometheus", "/actuator/health", "/actuator/info",
        "/actuator/health/db", "/actuator"}) {
      assertThat(get(serverPort, hidden)).as(hidden).isIn(401, 404);
    }
  }

  @Test
  void theManagementPortServesActuatorWithoutCredentials() throws Exception {
    assertThat(get(managementPort, "/actuator/prometheus")).isEqualTo(200);
    assertThat(body(managementPort, "/actuator/prometheus")).contains("jvm_memory_used_bytes");
    assertThat(get(managementPort, "/actuator/health")).isEqualTo(200);
    assertThat(get(managementPort, "/actuator/health/liveness")).isEqualTo(200);
    assertThat(get(managementPort, "/api/me")).as("the API is not on the management port").isIn(401, 404);
  }

  private static int get(int port, String path) throws Exception {
    return send(port, path).statusCode();
  }

  private static String body(int port, String path) throws Exception {
    return send(port, path).body();
  }

  private static HttpResponse<String> send(int port, String path) throws Exception {
    return HTTP.send(HttpRequest.newBuilder(URI.create("http://localhost:" + port + path)).build(),
        HttpResponse.BodyHandlers.ofString());
  }

  private static int freePort() {
    try (ServerSocket socket = new ServerSocket(0)) {
      return socket.getLocalPort();
    } catch (IOException e) {
      throw new IllegalStateException(e);
    }
  }
}
