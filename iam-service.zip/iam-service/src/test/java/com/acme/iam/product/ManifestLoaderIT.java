package com.acme.iam.product;

import static org.assertj.core.api.Assertions.assertThat;

import com.acme.iam.common.test.IntegrationTest;
import com.acme.iam.common.test.PostgresTestBase;
import java.util.concurrent.atomic.AtomicBoolean;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.ApplicationRunner;
import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Import;
import org.springframework.jdbc.core.simple.JdbcClient;

/** P1-7.3 / R20: the manifest is applied while the context refreshes, before any {@code ApplicationRunner}. */
@IntegrationTest(properties = "iam.registry.manifest=classpath:startup-test-manifest.yaml")
@Import(ManifestLoaderIT.Probe.class)
class ManifestLoaderIT extends PostgresTestBase {

  /** Records, from inside an ApplicationRunner, whether the manifest's product already existed. */
  @TestConfiguration
  static class Probe {
    static final AtomicBoolean PRODUCT_EXISTED_AT_RUNNER_TIME = new AtomicBoolean();

    @Bean
    ApplicationRunner probe(JdbcClient jdbc) {
      return args -> PRODUCT_EXISTED_AT_RUNNER_TIME.set(Boolean.TRUE.equals(
          jdbc.sql("SELECT EXISTS (SELECT 1 FROM product WHERE code = 'STARTUPCHECK')").query(Boolean.class).single()));
    }
  }

  @Autowired JdbcClient jdbc;
  @Autowired ManifestLoader loader;
  @Autowired RegistryService registry;

  @Test
  void theConfiguredManifestIsAppliedBeforeAnyApplicationRunner() {
    assertThat(Probe.PRODUCT_EXISTED_AT_RUNNER_TIME).isTrue();
    assertThat(jdbc.sql("""
            SELECT count(*) FROM permission p JOIN product pr ON pr.id = p.product_id
            WHERE pr.code = 'STARTUPCHECK' AND p.code = 'startupcheck.thing.use' AND NOT p.deprecated""")
        .query(Long.class).single()).isEqualTo(1);
    assertThat(jdbc.sql("""
            SELECT count(*) FROM role r JOIN role_permission rp ON rp.role = r.id JOIN product pr ON pr.id = r.product_id
            WHERE pr.code = 'STARTUPCHECK' AND r.name = 'Startup Admin' AND r.type = 'SYSTEM'""")
        .query(Long.class).single()).isEqualTo(1);
  }

  @Test
  void loadingAgainIsANoOpSoInstancesStartingTogetherAgree() {
    ApplyResult again = registry.apply(loader.load());

    assertThat(again.changed()).isFalse();
  }

  @Test
  void theClasspathManifestOfIamIsTheDefault() {
    assertThat(ManifestLoader.DEFAULT_LOCATION).isEqualTo("classpath:iam-manifest.yaml");
  }
}
