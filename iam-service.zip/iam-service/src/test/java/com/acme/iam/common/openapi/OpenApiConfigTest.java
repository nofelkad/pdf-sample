package com.acme.iam.common.openapi;

import static org.assertj.core.api.Assertions.assertThat;

import io.swagger.v3.oas.models.security.SecurityRequirement;
import java.util.List;
import org.junit.jupiter.api.Test;

/** Security per path, including paths a feature makes public through a {@code PermitAllPaths} bean. */
class OpenApiConfigTest {

  private static List<String> names(List<SecurityRequirement> requirements) {
    return requirements.stream().flatMap(r -> r.keySet().stream()).toList();
  }

  @Test
  void pathsByChain() {
    List<String> none = List.of();
    assertThat(names(OpenApiConfig.requirementsFor("/api/users/{id}", none))).containsExactly("bearerAuth");
    assertThat(names(OpenApiConfig.requirementsFor("/auth/logout", none))).containsExactly("bearerAuth");
    assertThat(OpenApiConfig.requirementsFor("/auth/login", none)).isEmpty();
    assertThat(names(OpenApiConfig.requirementsFor("/internal/token", none))).containsExactly("basicAuth");
    assertThat(names(OpenApiConfig.requirementsFor("/internal/revocations", none))).containsExactly("appBearer");
    assertThat(OpenApiConfig.requirementsFor("/.well-known/jwks.json", none)).isEmpty();
  }

  @Test
  void aPathMadePublicByAPermitAllPathsBeanHasNoSecurity() {
    List<String> open = List.of("/api/public/**", "/internal/ping", "/api/invitations/*");

    assertThat(OpenApiConfig.requirementsFor("/api/public/invitations/{token}", open)).isEmpty();
    assertThat(OpenApiConfig.requirementsFor("/internal/ping", open)).isEmpty();
    assertThat(OpenApiConfig.requirementsFor("/api/invitations/{token}", open)).isEmpty();
    assertThat(names(OpenApiConfig.requirementsFor("/api/users", open))).containsExactly("bearerAuth");
    assertThat(names(OpenApiConfig.requirementsFor("/internal/revocations", open))).containsExactly("appBearer");
  }
}
