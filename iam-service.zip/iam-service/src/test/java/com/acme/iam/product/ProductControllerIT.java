package com.acme.iam.product;

import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.http.HttpHeaders.AUTHORIZATION;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import com.acme.iam.common.Ids;
import com.acme.iam.common.test.IntegrationTest;
import com.acme.iam.common.test.PostgresTestBase;
import com.acme.iam.common.test.TestTokens;
import com.acme.iam.common.web.RequestIdFilter;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.http.MediaType;
import org.springframework.jdbc.core.simple.JdbcClient;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.ResultActions;

/** P1-7.3: manifest upload (application tokens) and the permission catalogue (any authenticated caller). */
@IntegrationTest
@AutoConfigureMockMvc
class ProductControllerIT extends PostgresTestBase {

  @Autowired MockMvc mvc;
  @Autowired TestTokens tokens;
  @Autowired JdbcClient jdbc;

  String code;
  String prefix;
  String app;

  @BeforeEach
  void setUp() {
    code = "T" + Ids.newId().toString().replace("-", "").substring(20).toUpperCase();
    prefix = code.toLowerCase() + ".";
    app = TestTokens.bearer(tokens.appToken("svc-" + code.toLowerCase(), code));
  }

  private String body(String product) {
    return """
        {"product":"%1$s","name":"Test product",
         "permissions":[
           {"code":"%2$sinvoice.approve","kind":"FEATURE","description":"Approve invoices","sensitive":true},
           {"code":"%2$sinvoice.read.tenant","kind":"DATA","description":"Read invoices of the tenant"}],
         "system_roles":[{"name":"Billing Admin","permissions":["%2$s*"],"exclude":[]}]}""".formatted(product, prefix);
  }

  private ResultActions upload(String path, String authorization, String json) throws Exception {
    var request = put("/internal/products/" + path + "/manifest").contentType(MediaType.APPLICATION_JSON).content(json);
    if (authorization != null) {
      request.header(AUTHORIZATION, authorization);
    }
    return mvc.perform(request);
  }

  @Test
  void anApplicationUploadsItsOwnManifestAndAnIdenticalUploadChangesNothing() throws Exception {
    upload(code, app, body(code))
        .andExpect(status().isOk())
        .andExpect(jsonPath("$.product").value(code))
        .andExpect(jsonPath("$.changed").value(true))
        .andExpect(jsonPath("$.permissionsAdded").value(2))
        .andExpect(jsonPath("$.permissionsUpdated").value(0))
        .andExpect(jsonPath("$.permissionsDeprecated").value(0))
        .andExpect(jsonPath("$.rolesChanged").value(1));

    long auditBefore = jdbc.sql("SELECT count(*) FROM audit_event WHERE target_type IN "
        + "('product','permission','role','role_permission')").query(Long.class).single();
    upload(code, app, body(code))
        .andExpect(status().isOk())
        .andExpect(jsonPath("$.changed").value(false))
        .andExpect(jsonPath("$.permissionsAdded").value(0))
        .andExpect(jsonPath("$.rolesChanged").value(0));

    assertThat(jdbc.sql("SELECT count(*) FROM audit_event WHERE target_type IN "
        + "('product','permission','role','role_permission')").query(Long.class).single()).isEqualTo(auditBefore);
    // rows written by the upload are attributed to the application client
    assertThat(jdbc.sql("""
            SELECT DISTINCT source FROM audit_event WHERE action = 'iam.permission.insert'
              AND after_state->>'code' = :c""").param("c", prefix + "invoice.approve").query(String.class).single())
        .isEqualTo("app:svc-" + code.toLowerCase());
  }

  @Test
  void anApplicationCannotUploadAnotherProductsManifest() throws Exception {
    String other = "T" + Ids.newId().toString().replace("-", "").substring(20).toUpperCase();
    String requestId = "mf-mismatch-" + Ids.newId();

    mvc.perform(put("/internal/products/" + other + "/manifest").header(RequestIdFilter.HEADER, requestId)
            .header(AUTHORIZATION, app).contentType(MediaType.APPLICATION_JSON).content(body(other)))
        .andExpect(status().isForbidden())
        .andExpect(jsonPath("$.code").value("product_mismatch"));

    assertThat(jdbc.sql("SELECT metadata->>'reason' FROM audit_event WHERE action = 'authz.denied' "
        + "AND request_id = :r").param("r", requestId).query(String.class).single()).isEqualTo("product_mismatch");
    assertThat(jdbc.sql("SELECT count(*) FROM product WHERE code = :c").param("c", other).query(Long.class).single())
        .isZero();
  }

  @Test
  void iamsManifestIsNeverAcceptedOverHttp() throws Exception {
    String iamApp = TestTokens.bearer(tokens.appToken("iam-svc", "IAM"));

    upload("IAM", iamApp, "{\"product\":\"IAM\",\"permissions\":[],\"system_roles\":[]}")
        .andExpect(status().isForbidden())
        .andExpect(jsonPath("$.code").value("iam_manifest_not_uploadable"));
  }

  @Test
  void aUserTokenAndAnAnonymousCallerCannotUpload() throws Exception {
    String user = tokens.user(Ids.newId()).perms("iam.role.manage", "platform.account.manage").bearer();

    upload(code, user, body(code)).andExpect(status().isForbidden());
    upload(code, null, body(code)).andExpect(status().isUnauthorized());
    assertThat(jdbc.sql("SELECT count(*) FROM product WHERE code = :c").param("c", code).query(Long.class).single())
        .isZero();
  }

  @Test
  void theBodysProductMustEqualThePath() throws Exception {
    String other = "T" + Ids.newId().toString().replace("-", "").substring(20).toUpperCase();

    upload(code, app, body(other))
        .andExpect(status().isBadRequest())
        .andExpect(jsonPath("$.code").value("product_mismatch"));
  }

  @Test
  void anInvalidManifestIsA400WithTheViolations() throws Exception {
    String bad = """
        {"product":"%1$s","permissions":[
           {"code":"%2$sa.b","kind":"WIDGET","description":"d"},
           {"code":"%2$sc.d","kind":"DATA","description":"d"},
           {"code":"other.e.f","kind":"FEATURE","description":"d"},
           {"code":"%2$sg.h","kind":"FEATURE","description":"d"},
           {"code":"%2$sg.h","kind":"FEATURE","description":"d"}]}""".formatted(code, prefix);

    upload(code, app, bad)
        .andExpect(status().isBadRequest())
        .andExpect(jsonPath("$.code").value("invalid_manifest"))
        .andExpect(jsonPath("$.violations.length()").value(4))
        .andExpect(jsonPath("$.violations[?(@ =~ /.*kind.*/)]").isNotEmpty())
        .andExpect(jsonPath("$.violations[?(@ =~ /.*duplicate.*/)]").isNotEmpty());
    upload(code, app, "{not json").andExpect(status().isBadRequest())
        .andExpect(jsonPath("$.code").value("invalid_manifest"));
  }

  @Test
  void oversizedUploadsAreRejectedAs400InvalidManifest() throws Exception {
    String tooLarge = "{\"product\":\"" + code + "\",\"name\":\"" + "x".repeat(ManifestValidator.MAX_BODY_BYTES) + "\"}";
    upload(code, app, tooLarge).andExpect(status().isBadRequest())
        .andExpect(jsonPath("$.code").value("invalid_manifest"))
        .andExpect(jsonPath("$.violations[0]").value(org.hamcrest.Matchers.containsString("larger than")));

    StringBuilder permissions = new StringBuilder();
    for (int i = 0; i <= ManifestValidator.MAX_PERMISSIONS; i++) {
      permissions.append(i == 0 ? "" : ",").append("{\"code\":\"").append(prefix).append("p").append(i)
          .append(".x\",\"kind\":\"FEATURE\",\"description\":\"d\"}");
    }
    upload(code, app, "{\"product\":\"" + code + "\",\"permissions\":[" + permissions + "]}")
        .andExpect(status().isBadRequest())
        .andExpect(jsonPath("$.code").value("invalid_manifest"))
        .andExpect(jsonPath("$.violations[0]").value(org.hamcrest.Matchers.containsString("at most 2000")));
    assertThat(jdbc.sql("SELECT count(*) FROM product WHERE code = :c").param("c", code).query(Long.class).single())
        .isZero();
  }

  // ------------------------------------------------------------------------------------- GET catalogue

  @Test
  void anyAuthenticatedUserMayListAProductsPermissions() throws Exception {
    upload(code, app, body(code)).andExpect(status().isOk());
    upload(code, app, body(code).replace("\"%sinvoice.read.tenant\"".formatted(prefix), "\"%sx.y.own\"".formatted(prefix)))
        .andExpect(status().isOk()); // read.tenant disappears (deprecated), x.y.own is new

    mvc.perform(get("/api/products/" + code + "/permissions").header(AUTHORIZATION, tokens.user(Ids.newId()).bearer()))
        .andExpect(status().isOk())
        .andExpect(jsonPath("$.product").value(code))
        .andExpect(jsonPath("$.name").value("Test product"))
        .andExpect(jsonPath("$.permissions.length()").value(3))
        .andExpect(jsonPath("$.permissions[?(@.code == '%sinvoice.approve')].sensitive".formatted(prefix))
            .value(true))
        .andExpect(jsonPath("$.permissions[?(@.code == '%sinvoice.read.tenant')].deprecated".formatted(prefix))
            .value(true))
        .andExpect(jsonPath("$.permissions[?(@.code == '%sx.y.own')].kind".formatted(prefix)).value("DATA"));
  }

  @Test
  void theCatalogueNeedsAnyValidTokenAndAKnownProduct() throws Exception {
    mvc.perform(get("/api/products/" + code + "/permissions")).andExpect(status().isUnauthorized());
    mvc.perform(get("/api/products/" + code + "/permissions").header(AUTHORIZATION, tokens.user(Ids.newId()).bearer()))
        .andExpect(status().isNotFound())
        .andExpect(jsonPath("$.code").value("product_not_found"));
  }
}
