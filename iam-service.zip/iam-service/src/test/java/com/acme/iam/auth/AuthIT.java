package com.acme.iam.auth;

import com.acme.iam.common.test.CapturingNotificationAdapter;
import com.acme.iam.common.test.IntegrationTest;
import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Inherited;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.context.annotation.Import;

/**
 * Shared context of the authentication ITs (one cached Spring context for all of them): MockMvc, the capturing
 * notification adapter, a stub {@link BreachedPasswordChecker}, {@code 127.0.0.1} as a trusted proxy (so each
 * {@link AuthClient} gets its own client IP through {@code X-Forwarded-For} and rate-limit buckets never collide
 * between tests) and the production rate limits, except refresh (20/min, to keep the 429 test short).
 */
@Target(ElementType.TYPE)
@Retention(RetentionPolicy.RUNTIME)
@Documented
@Inherited
@IntegrationTest(properties = {
    "iam.security.trusted-proxies=127.0.0.1",
    "iam.auth.rate-limit.refresh-per-ip=20"})
@AutoConfigureMockMvc
@Import({CapturingNotificationAdapter.Config.class, AuthTestData.Config.class})
public @interface AuthIT {}
