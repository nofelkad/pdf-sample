package com.acme.iam.auth;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.time.Instant;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ThreadLocalRandom;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.ResultActions;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;

/**
 * MockMvc client for {@code /auth/**} and {@code /api/me}. Each instance has its own client IP (sent as
 * {@code X-Forwarded-For}; {@link AuthIT} trusts 127.0.0.1) and every request gets a fresh {@code X-Request-Id},
 * available as {@link #lastRequestId()} to find the request's audit events.
 */
final class AuthClient {

  static final String USER_AGENT = "AuthClient/1.0 (test)";

  record Tokens(String accessToken, String refreshToken, UUID activeTenantId, long expiresIn, Instant refreshExpiresAt) {
    String bearer() {
      return "Bearer " + accessToken;
    }
  }

  private final MockMvc mvc;
  private final ObjectMapper json;
  private final String ip;
  private String lastRequestId;

  AuthClient(MockMvc mvc, ObjectMapper json) {
    this(mvc, json, randomIp());
  }

  AuthClient(MockMvc mvc, ObjectMapper json, String ip) {
    this.mvc = mvc;
    this.json = json;
    this.ip = ip;
  }

  static String randomIp() {
    ThreadLocalRandom r = ThreadLocalRandom.current();
    return "10." + r.nextInt(256) + "." + r.nextInt(256) + "." + (1 + r.nextInt(254));
  }

  String ip() {
    return ip;
  }

  String lastRequestId() {
    return lastRequestId;
  }

  ResultActions login(String email, String password) throws Exception {
    return login(email, password, null);
  }

  ResultActions login(String email, String password, String account) throws Exception {
    Map<String, Object> body = new LinkedHashMap<>();
    body.put("email", email);
    body.put("password", password);
    if (account != null) {
      body.put("account", account);
    }
    return send(post("/auth/login"), null, body);
  }

  Tokens loginOk(String email, String password) throws Exception {
    return tokens(login(email, password).andReturn());
  }

  ResultActions refresh(String refreshToken) throws Exception {
    return send(post("/auth/refresh"), null, Map.of("refreshToken", refreshToken));
  }

  ResultActions switchTenant(String bearer, UUID tenantId) throws Exception {
    return send(post("/auth/switch-tenant"), bearer, Map.of("tenantId", tenantId.toString()));
  }

  ResultActions logout(String bearer) throws Exception {
    return send(post("/auth/logout"), bearer, null);
  }

  ResultActions logoutAll(String bearer) throws Exception {
    return send(post("/auth/logout-all"), bearer, null);
  }

  ResultActions forgot(String email) throws Exception {
    return send(post("/auth/password/forgot"), null, Map.of("email", email));
  }

  ResultActions reset(String token, String password) throws Exception {
    return send(post("/auth/password/reset"), null, Map.of("token", token, "password", password));
  }

  ResultActions change(String bearer, String current, String next) throws Exception {
    return send(post("/auth/password/change"), bearer, Map.of("currentPassword", current, "newPassword", next));
  }

  ResultActions accept(String token, String password, String displayName) throws Exception {
    Map<String, Object> body = new LinkedHashMap<>();
    body.put("token", token);
    body.put("password", password);
    if (displayName != null) {
      body.put("displayName", displayName);
    }
    return send(post("/auth/invitations/accept"), null, body);
  }

  ResultActions me(String bearer) throws Exception {
    return send(get("/api/me"), bearer, null);
  }

  Tokens tokens(MvcResult result) throws Exception {
    if (result.getResponse().getStatus() != 200) {
      throw new AssertionError("expected 200 but was " + result.getResponse().getStatus() + ": "
          + result.getResponse().getContentAsString());
    }
    JsonNode body = json.readTree(result.getResponse().getContentAsString());
    return new Tokens(body.get("accessToken").asText(), body.get("refreshToken").asText(),
        UUID.fromString(body.get("activeTenantId").asText()), body.get("expiresIn").asLong(),
        Instant.parse(body.get("refreshExpiresAt").asText()));
  }

  JsonNode body(ResultActions actions) throws Exception {
    return json.readTree(actions.andReturn().getResponse().getContentAsString());
  }

  private ResultActions send(MockHttpServletRequestBuilder request, String bearer, Object body) throws Exception {
    lastRequestId = "t-" + UUID.randomUUID();
    request.header("X-Forwarded-For", ip)
        .header(HttpHeaders.USER_AGENT, USER_AGENT)
        .header("X-Request-Id", lastRequestId);
    if (bearer != null) {
      request.header(HttpHeaders.AUTHORIZATION, bearer);
    }
    if (body != null) {
      request.contentType(MediaType.APPLICATION_JSON).content(json.writeValueAsBytes(body));
    }
    return mvc.perform(request);
  }
}
