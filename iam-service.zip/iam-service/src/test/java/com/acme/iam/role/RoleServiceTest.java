package com.acme.iam.role;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatCode;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

import com.acme.iam.common.error.BadRequestException;
import com.acme.iam.common.error.NotFoundException;
import com.acme.iam.common.test.Fixtures;
import com.acme.iam.common.test.JdbcSliceTest;
import com.acme.iam.common.test.PostgresTestBase;
import com.acme.iam.product.ProductService;
import java.util.List;
import java.util.UUID;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Import;
import org.springframework.jdbc.core.simple.JdbcClient;

/** I3 (content): a CUSTOM role may only contain permissions of its own product; plus the I6 helper. */
@JdbcSliceTest
@Import({RoleService.class, ProductService.class})
class RoleServiceTest extends PostgresTestBase {

  @Autowired RoleService roles;
  @Autowired JdbcClient jdbc;

  Fixtures fx;
  UUID product;
  UUID own1;
  UUID own2;

  @BeforeEach
  void setUp() {
    fx = new Fixtures(jdbc);
    product = fx.product();
    own1 = fx.permission(product);
    own2 = fx.permission(product);
  }

  @Test
  void ownProductPermissionsAreAccepted() {
    assertThatCode(() -> roles.validateCustomRolePermissions(product, List.of(own1, own2))).doesNotThrowAnyException();
    assertThatCode(() -> roles.validateCustomRolePermissions(product, List.of())).doesNotThrowAnyException();
  }

  @Test
  void permissionOfAnotherProductIsRejected() {
    UUID foreign = fx.permission(fx.product());
    assertThatThrownBy(() -> roles.validateCustomRolePermissions(product, List.of(own1, foreign)))
        .isInstanceOfSatisfying(BadRequestException.class, e -> {
          assertThat(e.code()).isEqualTo("permission_product_mismatch");
          assertThat(e.properties()).containsEntry("permissionIds", List.of(foreign.toString()));
        });
  }

  @Test
  void unknownPermissionIsRejected() {
    UUID unknown = UUID.randomUUID();
    assertThatThrownBy(() -> roles.validateCustomRolePermissions(product, List.of(own1, unknown)))
        .isInstanceOfSatisfying(BadRequestException.class, e -> {
          assertThat(e.code()).isEqualTo("unknown_permission");
          assertThat(e.properties()).containsEntry("permissionIds", List.of(unknown.toString()));
        });
  }

  @Test
  void grantableCodesSkipDeprecatedPermissions() {
    fx.deprecate(own2);
    Role role = roles.getById(fx.systemRole(product, own1, own2));
    assertThat(roles.grantablePermissionCodes(role)).containsExactly(fx.code(own1));
  }

  @Test
  void unknownRoleIsNotFound() {
    assertThatThrownBy(() -> roles.getById(UUID.randomUUID()))
        .isInstanceOfSatisfying(NotFoundException.class, e -> assertThat(e.code()).isEqualTo("role_not_found"));
  }
}
