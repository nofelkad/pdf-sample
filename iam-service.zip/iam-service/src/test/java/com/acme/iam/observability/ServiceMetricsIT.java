package com.acme.iam.observability;

import static org.assertj.core.api.Assertions.assertThat;

import com.acme.iam.assignment.PermissionResolver;
import com.acme.iam.audit.AuditIngestService;
import com.acme.iam.audit.IngestResult;
import com.acme.iam.auth.RevocationPoller;
import com.acme.iam.auth.RevocationService;
import com.acme.iam.common.Ids;
import com.acme.iam.common.security.SecurityTestData;
import com.acme.iam.common.test.IntegrationTest;
import com.acme.iam.common.test.PostgresTestBase;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import io.micrometer.core.instrument.DistributionSummary;
import io.micrometer.core.instrument.Gauge;
import io.micrometer.core.instrument.MeterRegistry;
import io.micrometer.core.instrument.Timer;
import java.time.Instant;
import java.util.List;
import java.util.UUID;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.simple.JdbcClient;
import org.springframework.transaction.support.TransactionTemplate;

/** P1-11.5: resolver latency, audit ingest lag and revocation lag/freshness meters, fed by the real beans. */
@IntegrationTest(properties = "iam.revocation.poll-interval=PT1H") // only explicit poll() calls apply entries
class ServiceMetricsIT extends PostgresTestBase {

  @Autowired MeterRegistry meters;
  @Autowired PermissionResolver resolver;
  @Autowired AuditIngestService ingest;
  @Autowired ObjectMapper json;
  @Autowired JdbcClient jdbc;
  @Autowired TransactionTemplate tx;
  @Autowired RevocationService revocations;
  @Autowired RevocationPoller poller;
  @Autowired RevocationMetrics revocationMetrics;

  @Test
  void resolveAndExplainAreTimedSeparatelyWithPercentiles() {
    long resolve = resolverCount("resolve");
    long explain = resolverCount("explain");

    resolver.resolve(UUID.randomUUID(), UUID.randomUUID());
    resolver.resolve(UUID.randomUUID(), UUID.randomUUID());
    resolver.explain(UUID.randomUUID(), UUID.randomUUID());

    assertThat(resolverCount("resolve")).isEqualTo(resolve + 2);
    assertThat(resolverCount("explain")).isEqualTo(explain + 1);
    Timer timer = meters.get(MetricNames.PERMISSION_RESOLVE_DURATION).tags("op", "resolve", "outcome", "success").timer();
    assertThat(timer.takeSnapshot().percentileValues()).extracting(v -> v.percentile())
        .containsExactly(0.5, 0.95, 0.99);
  }

  @Test
  void ingestRecordsReceivedMinusOccurredAsADistributionOfSecondsForAcceptedEventsOnly() {
    DistributionSummary summary = meters.get(MetricNames.AUDIT_INGEST_LAG).summary();
    long count = summary.count();
    double total = summary.totalAmount();
    ArrayNode events = json.createArrayNode();
    events.add(event(Ids.newId(), Instant.now().minusSeconds(300).toString(), "doc.viewed"));
    events.add(event(Ids.newId(), Instant.now().minusSeconds(60).toString(), "doc.viewed"));
    events.add(event(Ids.newId(), Instant.now().minusSeconds(60).toString(), "NOT VALID")); // rejected: not counted
    ObjectNode body = json.createObjectNode();
    body.set("events", events);

    IngestResult result = ingest.ingest("BILLING", body);

    assertThat(result.accepted()).isEqualTo(2);
    assertThat(result.rejected()).hasSize(1);
    assertThat(summary.count()).isEqualTo(count + 2);
    assertThat(summary.totalAmount() - total).isBetween(360.0, 380.0);
    assertThat(summary.takeSnapshot().percentileValues()).extracting(v -> v.percentile())
        .containsExactly(0.5, 0.95, 0.99);
  }

  @Test
  void aPollAppliesNewEntriesAndPublishesTheirAgeAndTheFreshnessOfThePoller() {
    SecurityTestData data = new SecurityTestData(jdbc);
    UUID account = data.account();
    UUID user = data.user(account, data.tenant(account));
    tx.executeWithoutResult(status -> revocations.revokeUsers(List.of(user), "user.disabled"));

    poller.poll();

    Gauge lag = meters.get(MetricNames.REVOCATION_LAG).gauge();
    assertThat(lag.value()).as("created after startup: its age when applied").isBetween(0.0, 10.0);
    assertThat(meters.get(MetricNames.REVOCATION_POLL_AGE).gauge().value()).isBetween(0.0, 10.0);
    assertThat(revocationMetrics.lastSuccess()).isNotNull();
  }

  @Test
  void entriesOlderThanThisInstanceAreStartupReplayAndLeaveTheLagAlone() {
    SecurityTestData data = new SecurityTestData(jdbc);
    UUID account = data.account();
    UUID user = data.user(account, data.tenant(account));
    double before = meters.get(MetricNames.REVOCATION_LAG).gauge().value();
    // a revocation that was already 2 hours old when this context started; the background poller is slowed to once an
    // hour (properties above), so only this test's poll() applies it
    tx.executeWithoutResult(status -> {
      revocations.revokeUsers(List.of(user), "user.disabled");
      jdbc.sql("UPDATE revocation SET created_at = now() - interval '2 hours' WHERE user_id = :u")
          .param("u", user).update();
    });

    poller.poll();

    assertThat(meters.get(MetricNames.REVOCATION_LAG).gauge().value()).isEqualTo(before);
  }

  private long resolverCount(String op) {
    Timer t = meters.find(MetricNames.PERMISSION_RESOLVE_DURATION).tags("op", op, "outcome", "success").timer();
    return t == null ? 0 : t.count();
  }

  private ObjectNode event(UUID id, String occurredAt, String action) {
    ObjectNode e = json.createObjectNode();
    e.put("eventId", id.toString());
    e.put("occurredAt", occurredAt);
    e.put("action", action);
    e.put("outcome", "SUCCESS");
    e.put("actorType", "USER");
    return e;
  }
}
