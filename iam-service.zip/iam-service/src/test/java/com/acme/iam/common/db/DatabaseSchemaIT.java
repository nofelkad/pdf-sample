package com.acme.iam.common.db;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

import com.acme.iam.common.Ids;
import com.acme.iam.common.test.IntegrationTest;
import com.acme.iam.common.test.PostgresTestBase;
import java.time.YearMonth;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.UUID;
import java.util.stream.IntStream;
import org.junit.jupiter.api.Test;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;

/**
 * P1-2.1/2.3/2.4 and Ruling R3: the migrated schema, the iam_migrator / iam_app privilege split, append-only audit,
 * partitions, default privileges for future tables, seed data. The Spring context is only used to run Flyway.
 */
@IntegrationTest
class DatabaseSchemaIT extends PostgresTestBase {

  private static final String INSUFFICIENT_PRIVILEGE = "42501";

  private final JdbcTemplate app = new JdbcTemplate(appDataSource());
  private final JdbcTemplate migrator = new JdbcTemplate(migratorDataSource());

  @Test
  void appRoleCannotUpdateDeleteOrTruncateAuditEvent() {
    UUID eventId = insertAuditEventAsApp();

    assertPrivilegeDenied(() -> app.update("UPDATE audit_event SET action = 'tampered' WHERE event_id = ?", eventId));
    assertPrivilegeDenied(() -> app.update("DELETE FROM audit_event WHERE event_id = ?", eventId));
    assertPrivilegeDenied(() -> app.execute("TRUNCATE audit_event"));
  }

  @Test
  void appRoleCannotUpdateAuditPartitionsDirectly() {
    List<String> partitions = auditPartitions();

    assertThat(partitions).isNotEmpty();
    for (String partition : partitions) {
      assertThat(app.queryForObject("SELECT has_table_privilege(?, 'UPDATE')", Boolean.class, partition))
          .as("UPDATE on %s", partition).isFalse();
      assertThat(app.queryForObject("SELECT has_table_privilege(?, 'DELETE')", Boolean.class, partition))
          .as("DELETE on %s", partition).isFalse();
    }
  }

  @Test
  void appRoleCanInsertAndSelectAuditEvent() {
    UUID eventId = insertAuditEventAsApp();

    assertThat(app.queryForObject("SELECT action FROM audit_event WHERE event_id = ?", String.class, eventId))
        .isEqualTo("test.grants");
  }

  @Test
  void ownerUpdatesAreStillBlockedByTheAppendOnlyTrigger() {
    UUID eventId = insertAuditEventAsApp();

    assertThatThrownBy(() -> migrator.update("UPDATE audit_event SET action = 'x' WHERE event_id = ?", eventId))
        .hasMessageContaining("audit_event is append-only");
    assertThatThrownBy(() -> migrator.update("DELETE FROM audit_event WHERE event_id = ?", eventId))
        .hasMessageContaining("audit_event is append-only");
  }

  @Test
  void appRoleHasDmlOnEveryOtherTable() {
    List<String> tables = migrator.queryForList("""
        SELECT c.relname FROM pg_class c JOIN pg_namespace n ON n.oid = c.relnamespace
        WHERE n.nspname = 'public' AND c.relkind = 'r' AND NOT c.relispartition
          AND c.relname NOT IN ('audit_event', 'flyway_schema_history')""", String.class);

    assertThat(tables).contains("account", "app_user", "role_assignment", "revocation", "shedlock", "bucket");
    for (String table : tables) {
      for (String privilege : List.of("SELECT", "INSERT", "UPDATE", "DELETE")) {
        assertThat(app.queryForObject("SELECT has_table_privilege(?, ?)", Boolean.class, table, privilege))
            .as("%s on %s", privilege, table).isTrue();
      }
    }
    assertThat(app.queryForObject(
        "SELECT has_sequence_privilege('revocation_id_seq', 'USAGE')", Boolean.class)).isTrue();
  }

  @Test
  void appRoleCannotRunDdlOrReadFlywayHistory() {
    assertPrivilegeDenied(() -> app.execute("CREATE TABLE app_should_not_create (id int)"));
    assertPrivilegeDenied(() -> app.execute("ALTER TABLE account ADD COLUMN x int"));
    assertPrivilegeDenied(() -> app.execute("DROP TABLE revocation"));
    assertPrivilegeDenied(() -> app.queryForList("SELECT * FROM flyway_schema_history"));
  }

  @Test
  void tablesCreatedLaterByTheMigratorGetAppDmlAutomatically() {
    String table = "later_table_" + Ids.newId().toString().replace("-", "");
    migrator.execute("CREATE TABLE " + table + " (id BIGSERIAL PRIMARY KEY, v TEXT)");
    try {
      app.update("INSERT INTO " + table + " (v) VALUES ('a')");
      app.update("UPDATE " + table + " SET v = 'b'");
      assertThat(app.queryForObject("SELECT v FROM " + table, String.class)).isEqualTo("b");
      app.update("DELETE FROM " + table);
    } finally {
      migrator.execute("DROP TABLE " + table);
    }
  }

  @Test
  void initialPartitionsCoverCurrentMonthPlusThreeAhead() {
    YearMonth now = YearMonth.now(ZoneOffset.UTC);
    List<String> expected = IntStream.rangeClosed(0, 3).mapToObj(i -> partitionName(now.plusMonths(i))).toList();

    assertThat(auditPartitions()).containsAll(expected);
  }

  @Test
  void appRoleCanEnsurePartitionsThroughSecurityDefinerFunction() {
    String fourAhead = partitionName(YearMonth.now(ZoneOffset.UTC).plusMonths(4));

    Integer first = app.queryForObject("SELECT audit_ensure_partitions(4)", Integer.class);
    Integer second = app.queryForObject("SELECT audit_ensure_partitions(4)", Integer.class);

    assertThat(first).isBetween(0, 1);
    assertThat(second).isZero();
    assertThat(auditPartitions()).contains(fourAhead);
    assertThat(app.queryForObject("SELECT has_table_privilege(?, 'UPDATE')", Boolean.class, fourAhead)).isFalse();
    assertThat(app.queryForObject("SELECT has_table_privilege(?, 'INSERT')", Boolean.class, fourAhead)).isTrue();
  }

  @Test
  void ensurePartitionsIsNotExecutableByPublic() {
    Integer publicGrants = migrator.queryForObject("""
        SELECT count(*) FROM pg_proc p, aclexplode(p.proacl) a
        WHERE p.proname = 'audit_ensure_partitions' AND a.grantee = 0""", Integer.class);

    assertThat(publicGrants).isZero();
    assertThat(migrator.queryForObject(
        "SELECT prosecdef FROM pg_proc WHERE proname = 'audit_ensure_partitions'", Boolean.class)).isTrue();
  }

  @Test
  void seedDataIsPresent() {
    assertThat(app.queryForObject("SELECT code FROM product WHERE id = '00000000-0000-7000-8000-000000000001'",
        String.class)).isEqualTo("IAM");
    assertThat(app.queryForObject(
        "SELECT kind || '/' || status FROM account WHERE slug = 'PLATFORM'", String.class))
        .as("slug is CITEXT, so the lookup is case-insensitive").isEqualTo("PLATFORM/ACTIVE");
  }

  private UUID insertAuditEventAsApp() {
    UUID eventId = Ids.newId();
    app.update("""
        INSERT INTO audit_event (event_id, occurred_at, source, actor_type, action, outcome)
        VALUES (?, now(), 'IAM', 'SYSTEM', 'test.grants', 'SUCCESS')""", eventId);
    return eventId;
  }

  private List<String> auditPartitions() {
    return migrator.queryForList(
        "SELECT inhrelid::regclass::text FROM pg_inherits WHERE inhparent = 'audit_event'::regclass", String.class);
  }

  private static String partitionName(YearMonth month) {
    return "audit_event_" + month.format(DateTimeFormatter.ofPattern("'y'yyyy'm'MM"));
  }

  private static void assertPrivilegeDenied(Runnable statement) {
    assertThatThrownBy(statement::run)
        .isInstanceOf(DataAccessException.class)
        .satisfies(e -> assertThat(sqlState(e)).isEqualTo(INSUFFICIENT_PRIVILEGE));
  }

  private static String sqlState(Throwable e) {
    for (Throwable t = e; t != null; t = t.getCause()) {
      if (t instanceof java.sql.SQLException sql) {
        return sql.getSQLState();
      }
    }
    return null;
  }
}
