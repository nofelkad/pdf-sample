package com.acme.iam.assignment;

import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.http.HttpHeaders.AUTHORIZATION;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import com.acme.iam.account.AccountKind;
import com.acme.iam.common.test.Fixtures;
import com.acme.iam.common.test.IntegrationTest;
import com.acme.iam.common.test.PostgresTestBase;
import com.acme.iam.common.test.TestTokens;
import com.acme.iam.product.Product;
import com.acme.iam.role.Role;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.http.MediaType;
import org.springframework.jdbc.core.simple.JdbcClient;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.ResultActions;

/** P1-10.4: assignment API: assign/revoke at ACCOUNT or TENANT scope (I1, I3, I6, I7, I8, I10) and the list endpoints. */
@IntegrationTest
@AutoConfigureMockMvc
class AssignmentControllerIT extends PostgresTestBase {

  @Autowired MockMvc mvc;
  @Autowired TestTokens tokens;
  @Autowired JdbcClient jdbc;
  @Autowired ObjectMapper json;

  Fixtures fx;
  Fixtures.Scenario s;        // account, tenant T1, user A (account admin of the assign permission)
  UUID t1;
  UUID t2;
  UUID permAssign;
  UUID targetRole;            // custom role of A's account holding iam.role.assign
  UUID u;                     // the user roles are assigned to (member of T1)
  String admin;               // A: iam.role.assign, held at ACCOUNT scope
  UUID tenantAdminUser;
  String tenantAdmin;         // iam.role.assign held at TENANT scope (T1) only

  @BeforeEach
  void setUp() {
    fx = new Fixtures(jdbc);
    s = fx.scenario();
    t1 = s.tenantId();
    t2 = fx.tenant(s.accountId());
    permAssign = fx.permission(Product.IAM_ID, "iam.role.assign");
    UUID grantRole = fx.customRole(Product.IAM_ID, s.accountId(), permAssign);
    fx.assign(s.userId(), grantRole, ScopeType.ACCOUNT, s.accountId());
    targetRole = fx.customRole(Product.IAM_ID, s.accountId(), permAssign);
    u = fx.user(s.accountId(), t1);
    admin = tokens.user(s.userId()).account(s.accountId()).tenant(t1).perms("iam.role.assign").bearer();

    tenantAdminUser = fx.user(s.accountId(), t1);
    fx.assign(tenantAdminUser, fx.customRole(Product.IAM_ID, s.accountId(), permAssign), ScopeType.TENANT, t1);
    tenantAdmin = tokens.user(tenantAdminUser).account(s.accountId()).tenant(t1).perms("iam.role.assign").bearer();
  }

  // ------------------------------------------------------------------------------------------- helpers

  private ResultActions assign(String bearer, UUID user, UUID role, ScopeType scope, UUID scopeId, Instant expiresAt)
      throws Exception {
    Map<String, Object> body = new LinkedHashMap<>();
    body.put("roleId", role);
    body.put("scopeType", scope);
    body.put("scopeId", scopeId);
    if (expiresAt != null) {
      body.put("expiresAt", expiresAt.toString());
    }
    return mvc.perform(post("/api/users/" + user + "/assignments").header(AUTHORIZATION, bearer)
        .contentType(MediaType.APPLICATION_JSON).content(json.writeValueAsString(body)));
  }

  private ResultActions getList(String path, String bearer) throws Exception {
    return mvc.perform(get(path).header(AUTHORIZATION, bearer));
  }

  private int sessionVersion(UUID user) {
    return jdbc.sql("SELECT session_version FROM app_user WHERE id = :id").param("id", user).query(Integer.class).single();
  }

  private long assignmentCount(UUID user) {
    return jdbc.sql("SELECT count(*) FROM role_assignment WHERE user_id = :u").param("u", user).query(Long.class).single();
  }

  // ------------------------------------------------------------------------------------------- assign

  @Test
  void assignsATenantScopeRoleAndRecordsTheGrantor() throws Exception {
    assign(admin, u, targetRole, ScopeType.TENANT, t1, null)
        .andExpect(status().isCreated())
        .andExpect(jsonPath("$.userId").value(u.toString()))
        .andExpect(jsonPath("$.roleId").value(targetRole.toString()))
        .andExpect(jsonPath("$.scopeType").value("TENANT"))
        .andExpect(jsonPath("$.scopeId").value(t1.toString()))
        .andExpect(jsonPath("$.grantedBy").value(s.userId().toString()))
        .andExpect(jsonPath("$.roleName").isNotEmpty());

    assertThat(assignmentCount(u)).isEqualTo(1);
  }

  @Test
  void assignsAnAccountScopeRoleWithAFutureExpiry() throws Exception {
    Instant expiry = Instant.now().plus(7, ChronoUnit.DAYS);

    assign(admin, u, targetRole, ScopeType.ACCOUNT, s.accountId(), expiry)
        .andExpect(status().isCreated())
        .andExpect(jsonPath("$.scopeType").value("ACCOUNT"))
        .andExpect(jsonPath("$.expiresAt").isNotEmpty());

    assign(admin, u, targetRole, ScopeType.ACCOUNT, s.accountId(), null)
        .andExpect(status().isConflict()).andExpect(jsonPath("$.code").value("assignment_exists"));
  }

  @Test
  void anExpiryInThePastAndAnIncompleteBodyAreRejected() throws Exception {
    assign(admin, u, targetRole, ScopeType.TENANT, t1, Instant.now().minusSeconds(60))
        .andExpect(status().isBadRequest()).andExpect(jsonPath("$.code").value("invalid_expiry"));
    mvc.perform(post("/api/users/" + u + "/assignments").header(AUTHORIZATION, admin)
            .contentType(MediaType.APPLICATION_JSON).content("{\"scopeType\":\"TENANT\"}"))
        .andExpect(status().isBadRequest()).andExpect(jsonPath("$.code").value("validation_failed"));
    assertThat(assignmentCount(u)).isZero();
  }

  @Test
  void assignIsDeniedWithoutIamRoleAssign() throws Exception {
    String noPermission = tokens.user(s.userId()).account(s.accountId()).tenant(t1).perms("iam.role.manage").bearer();

    assign(noPermission, u, targetRole, ScopeType.TENANT, t1, null).andExpect(status().isForbidden());
    mvc.perform(post("/api/users/" + u + "/assignments").contentType(MediaType.APPLICATION_JSON)
        .content("{}")).andExpect(status().isUnauthorized());
    assertThat(assignmentCount(u)).isZero();
  }

  @Test
  void otherAccountsUsersRolesAndTenantsAreInvisible() throws Exception {
    Fixtures.Scenario other = fx.scenario();
    UUID foreignRole = fx.customRole(Product.IAM_ID, other.accountId(), permAssign);

    assign(admin, other.userId(), targetRole, ScopeType.TENANT, other.tenantId(), null)
        .andExpect(status().isNotFound()).andExpect(jsonPath("$.code").value("tenant_not_found"));
    assign(admin, other.userId(), targetRole, ScopeType.TENANT, t1, null)
        .andExpect(status().isNotFound()).andExpect(jsonPath("$.code").value("user_not_found"));
    assign(admin, u, foreignRole, ScopeType.TENANT, t1, null)
        .andExpect(status().isNotFound()).andExpect(jsonPath("$.code").value("role_not_found"));
    assertThat(assignmentCount(other.userId())).isZero();
  }

  @Test
  void aTenantAdminCannotAssignInAnotherTenantOrAtAccountScope() throws Exception {
    fx.membership(u, t2, com.acme.iam.user.MembershipStatus.ACTIVE);

    assign(tenantAdmin, u, targetRole, ScopeType.TENANT, t2, null)
        .andExpect(status().isForbidden()).andExpect(jsonPath("$.code").value("scope_exceeded"));
    assign(tenantAdmin, u, targetRole, ScopeType.ACCOUNT, s.accountId(), null)
        .andExpect(status().isForbidden()).andExpect(jsonPath("$.code").value("account_scope_required"));
    // inside the active tenant it works
    assign(tenantAdmin, u, targetRole, ScopeType.TENANT, t1, null).andExpect(status().isCreated());
    // the account admin may use the other tenant (account-scope override)
    assign(admin, u, targetRole, ScopeType.TENANT, t2, null).andExpect(status().isCreated());
  }

  @Test
  void aTenantScopeAssignmentNeedsAMembership() throws Exception {
    assign(admin, u, targetRole, ScopeType.TENANT, t2, null)
        .andExpect(status().isConflict()).andExpect(jsonPath("$.code").value("membership_required"));
  }

  @Test
  void aRoleWhosePermissionsTheGrantorLacksCannotBeAssigned() throws Exception {
    UUID stronger = fx.customRole(Product.IAM_ID, s.accountId(), permAssign, fx.permission(Product.IAM_ID));

    assign(admin, u, stronger, ScopeType.TENANT, t1, null)
        .andExpect(status().isForbidden()).andExpect(jsonPath("$.code").value("grantor_lacks_permissions"));
    assertThat(assignmentCount(u)).isZero();
  }

  @Test
  void platformAdminIsNotAssignableInACustomerAccount() throws Exception {
    UUID platformAdmin = fx.systemRole(Product.IAM_ID, Role.PLATFORM_ADMIN);

    assign(admin, u, platformAdmin, ScopeType.ACCOUNT, s.accountId(), null)
        .andExpect(status().isForbidden()).andExpect(jsonPath("$.code").value("platform_role_restricted"));
  }

  // ------------------------------------------------------------------------------------------- revoke

  @Test
  void revokingDeletesTheAssignmentAndRevokesTheUser() throws Exception {
    UUID id = fx.assign(u, targetRole, ScopeType.TENANT, t1);
    UUID bystander = fx.user(s.accountId(), t1);

    mvc.perform(delete("/api/assignments/" + id).header(AUTHORIZATION, admin)).andExpect(status().isNoContent());

    assertThat(assignmentCount(u)).isZero();
    assertThat(sessionVersion(u)).isEqualTo(2);
    assertThat(sessionVersion(bystander)).isEqualTo(1);
    assertThat(jdbc.sql("SELECT count(*) FROM revocation WHERE user_id = :u AND min_sv = 2").param("u", u)
        .query(Long.class).single()).isEqualTo(1);
    mvc.perform(delete("/api/assignments/" + id).header(AUTHORIZATION, admin)).andExpect(status().isNotFound())
        .andExpect(jsonPath("$.code").value("assignment_not_found"));
  }

  @Test
  void theLastAccountAdminCannotBeRevoked() throws Exception {
    UUID accountAdmin = fx.systemRole(Product.IAM_ID, Role.ACCOUNT_ADMIN);
    UUID only = fx.user(s.accountId(), t1);
    UUID grant = fx.assign(only, accountAdmin, ScopeType.ACCOUNT, s.accountId());

    mvc.perform(delete("/api/assignments/" + grant).header(AUTHORIZATION, admin))
        .andExpect(status().isConflict()).andExpect(jsonPath("$.code").value("last_admin"));
    assertThat(assignmentCount(only)).isEqualTo(1);
    assertThat(sessionVersion(only)).isEqualTo(1);

    fx.assign(u, accountAdmin, ScopeType.ACCOUNT, s.accountId());        // a second admin appears
    mvc.perform(delete("/api/assignments/" + grant).header(AUTHORIZATION, admin)).andExpect(status().isNoContent());
    assertThat(sessionVersion(only)).isEqualTo(2);
  }

  @Test
  void revokeIsDeniedWithoutPermissionAndForOtherAccountsAssignments() throws Exception {
    UUID id = fx.assign(u, targetRole, ScopeType.TENANT, t1);
    Fixtures.Scenario other = fx.scenario();
    UUID foreign = fx.assign(other.userId(), targetRole, ScopeType.ACCOUNT, other.accountId());
    String noPermission = tokens.user(s.userId()).account(s.accountId()).tenant(t1).perms("iam.user.manage").bearer();

    mvc.perform(delete("/api/assignments/" + id).header(AUTHORIZATION, noPermission)).andExpect(status().isForbidden());
    mvc.perform(delete("/api/assignments/" + foreign).header(AUTHORIZATION, admin)).andExpect(status().isNotFound());
    mvc.perform(delete("/api/assignments/" + id)).andExpect(status().isUnauthorized());
    assertThat(assignmentCount(u)).isEqualTo(1);
    assertThat(assignmentCount(other.userId())).isEqualTo(1);
  }

  @Test
  void aTenantAdminCannotRevokeAnAccountScopeAssignmentOrAnotherTenants() throws Exception {
    UUID accountScoped = fx.assign(u, targetRole, ScopeType.ACCOUNT, s.accountId());
    fx.membership(u, t2, com.acme.iam.user.MembershipStatus.ACTIVE);
    UUID otherTenant = fx.assign(u, fx.customRole(Product.IAM_ID, s.accountId(), permAssign), ScopeType.TENANT, t2);

    mvc.perform(delete("/api/assignments/" + accountScoped).header(AUTHORIZATION, tenantAdmin))
        .andExpect(status().isForbidden()).andExpect(jsonPath("$.code").value("account_scope_required"));
    mvc.perform(delete("/api/assignments/" + otherTenant).header(AUTHORIZATION, tenantAdmin))
        .andExpect(status().isForbidden()).andExpect(jsonPath("$.code").value("scope_exceeded"));
    assertThat(assignmentCount(u)).isEqualTo(2);
  }

  // ------------------------------------------------------------------------------------------- lists

  @Test
  void listsByUserKeysetPaginatedNewestFirst() throws Exception {
    UUID a1 = fx.assign(u, fx.customRole(Product.IAM_ID, s.accountId(), permAssign), ScopeType.TENANT, t1);
    UUID a2 = fx.assign(u, fx.customRole(Product.IAM_ID, s.accountId(), permAssign), ScopeType.TENANT, t1);
    UUID a3 = fx.assign(u, fx.customRole(Product.IAM_ID, s.accountId(), permAssign), ScopeType.ACCOUNT, s.accountId());

    JsonNode first = json.readTree(getList("/api/users/" + u + "/assignments?limit=2", admin)
        .andExpect(status().isOk()).andExpect(jsonPath("$.items.length()").value(2))
        .andReturn().getResponse().getContentAsString());
    assertThat(first.at("/items/0/id").asText()).isEqualTo(a3.toString());
    assertThat(first.at("/items/1/id").asText()).isEqualTo(a2.toString());
    String cursor = first.get("nextCursor").asText();

    getList("/api/users/" + u + "/assignments?limit=2&cursor=" + cursor, admin)
        .andExpect(status().isOk())
        .andExpect(jsonPath("$.items.length()").value(1))
        .andExpect(jsonPath("$.items[0].id").value(a1.toString()))
        .andExpect(jsonPath("$.nextCursor").doesNotExist());
    getList("/api/users/" + u + "/assignments?cursor=not_a_cursor", admin).andExpect(status().isBadRequest())
        .andExpect(jsonPath("$.code").value("invalid_cursor"));
  }

  @Test
  void listsByRoleOnlyShowAssignmentsOfTheCallersAccount() throws Exception {
    UUID system = fx.systemRole(Product.IAM_ID, "Shared " + UUID.randomUUID());
    Fixtures.Scenario other = fx.scenario(AccountKind.CUSTOMER);
    UUID mine = fx.assign(u, system, ScopeType.TENANT, t1);
    fx.assign(other.userId(), system, ScopeType.ACCOUNT, other.accountId());
    UUID foreignCustom = fx.customRole(Product.IAM_ID, other.accountId(), permAssign);

    getList("/api/roles/" + system + "/assignments", admin)
        .andExpect(status().isOk())
        .andExpect(jsonPath("$.items.length()").value(1))
        .andExpect(jsonPath("$.items[0].id").value(mine.toString()));
    getList("/api/roles/" + foreignCustom + "/assignments", admin).andExpect(status().isNotFound())
        .andExpect(jsonPath("$.code").value("role_not_found"));
  }

  @Test
  void listsByTenantNeedTheActiveTenantOrAnAccountScopeGrant() throws Exception {
    UUID inT1 = fx.assign(u, targetRole, ScopeType.TENANT, t1);
    fx.assign(u, fx.customRole(Product.IAM_ID, s.accountId(), permAssign), ScopeType.ACCOUNT, s.accountId());
    UUID u2 = fx.user(s.accountId(), t2);
    UUID inT2 = fx.assign(u2, targetRole, ScopeType.TENANT, t2);
    Fixtures.Scenario other = fx.scenario();

    getList("/api/tenants/" + t1 + "/assignments", tenantAdmin)
        .andExpect(status().isOk())
        .andExpect(jsonPath("$.items[?(@.id == '%s')]".formatted(inT1)).isNotEmpty())
        .andExpect(jsonPath("$.items[?(@.scopeType == 'ACCOUNT')]").isEmpty());  // tenant scope only
    getList("/api/tenants/" + t2 + "/assignments", admin)                          // account-scope override
        .andExpect(status().isOk()).andExpect(jsonPath("$.items.length()").value(1))
        .andExpect(jsonPath("$.items[0].id").value(inT2.toString()));
    getList("/api/tenants/" + t2 + "/assignments", tenantAdmin).andExpect(status().isForbidden())
        .andExpect(jsonPath("$.code").value("scope_exceeded"));
    getList("/api/tenants/" + other.tenantId() + "/assignments", admin).andExpect(status().isNotFound())
        .andExpect(jsonPath("$.code").value("tenant_not_found"));
  }

  @Test
  void listsAreDeniedWithoutPermissionAndForOtherAccountsUsers() throws Exception {
    Fixtures.Scenario other = fx.scenario();
    String noPermission = tokens.user(s.userId()).account(s.accountId()).tenant(t1).perms("iam.role.manage").bearer();

    for (String path : List.of("/api/users/" + u + "/assignments", "/api/roles/" + targetRole + "/assignments",
        "/api/tenants/" + t1 + "/assignments")) {
      getList(path, noPermission).andExpect(status().isForbidden());
      mvc.perform(get(path)).andExpect(status().isUnauthorized());
    }
    getList("/api/users/" + other.userId() + "/assignments", admin).andExpect(status().isNotFound())
        .andExpect(jsonPath("$.code").value("user_not_found"));
  }
}
