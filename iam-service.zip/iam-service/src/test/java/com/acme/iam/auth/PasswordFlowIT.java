package com.acme.iam.auth;

import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import com.acme.iam.common.test.CapturingNotificationAdapter;
import com.acme.iam.common.test.PostgresTestBase;
import com.acme.iam.core.Claims;
import com.acme.iam.user.MembershipStatus;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.util.UUID;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.simple.JdbcClient;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.security.oauth2.jwt.JwtDecoder;
import org.springframework.test.web.servlet.MockMvc;

/** P1-5.6: forgot / reset / change password. */
@AuthIT
class PasswordFlowIT extends PostgresTestBase {

  static final String NEW_PASSWORD = "Brand-New-Passphrase-9";

  @Autowired MockMvc mvc;
  @Autowired ObjectMapper json;
  @Autowired JdbcClient jdbc;
  @Autowired PasswordService passwords;
  @Autowired JwtDecoder jwtDecoder;
  @Autowired RevocationPoller poller;
  @Autowired CapturingNotificationAdapter mailbox;

  AuthTestData data;
  AuthClient client;
  AuthTestData.TestUser u;

  @BeforeEach
  void setUp() {
    data = new AuthTestData(jdbc, passwords);
    client = new AuthClient(mvc, json);
    u = data.user();
    mailbox.clear();
  }

  @Test
  void forgotAlwaysAnswers202AndOnlyMailsExistingUsers() throws Exception {
    String unknown = "nobody-" + UUID.randomUUID() + "@example.test";

    client.forgot(unknown).andExpect(status().isAccepted());
    assertThat(data.auditOfRequest(client.lastRequestId())).containsExactly("auth.password.forgot/SUCCESS/ANONYMOUS");
    client.forgot(u.email().toUpperCase()).andExpect(status().isAccepted());
    String token = AuthTestData.awaitResetToken(mailbox, u.email(), 1);

    assertThat(mailbox.sent()).singleElement().satisfies(sent -> {
      assertThat(sent.kind()).isEqualTo(CapturingNotificationAdapter.Kind.PASSWORD_RESET);
      assertThat(sent.email()).isEqualTo(u.email());
    });
    assertThat(data.auditRows(client.lastRequestId(), "auth.password.forgot")).singleElement().satisfies(row -> {
      assertThat(row).containsEntry("account_id", u.accountId()).containsEntry("target_id", u.userId().toString());
      assertThat((String) row.get("metadata")).doesNotContain(token);
    });
  }

  @Test
  void aNewResetRequestInvalidatesTheEarlierToken() throws Exception {
    client.forgot(u.email());
    String first = AuthTestData.awaitResetToken(mailbox, u.email(), 1);
    client.forgot(u.email());
    String second = AuthTestData.awaitResetToken(mailbox, u.email(), 2);

    client.reset(first, NEW_PASSWORD).andExpect(status().isBadRequest())
        .andExpect(jsonPath("$.code").value("invalid_token"));
    client.reset(second, NEW_PASSWORD).andExpect(status().isNoContent());
  }

  @Test
  void resetSetsThePasswordRevokesAllSessionsAndIsSingleUse() throws Exception {
    AuthClient.Tokens session = client.loginOk(u.email(), u.password());
    client.forgot(u.email());
    String token = AuthTestData.awaitResetToken(mailbox, u.email(), 1);

    client.reset(token, NEW_PASSWORD).andExpect(status().isNoContent());

    assertThat(data.auditOfRequest(client.lastRequestId()))
        .containsExactly("auth.password.reset/SUCCESS/USER", "auth.sessions.revoked/SUCCESS/SYSTEM");
    assertThat(data.sessionsOf(u.userId())).allSatisfy(s -> assertThat(s.get("revoked_at")).isNotNull());
    assertThat(data.revocationReasons(u.userId())).containsExactly("password_reset");
    client.login(u.email(), u.password()).andExpect(status().isUnauthorized());
    client.login(u.email(), NEW_PASSWORD).andExpect(status().isOk());
    client.reset(token, "Yet-Another-Passphrase-1").andExpect(status().isBadRequest())
        .andExpect(jsonPath("$.code").value("invalid_token"));
    client.refresh(session.refreshToken()).andExpect(status().isUnauthorized());
  }

  @Test
  void aPolicyViolationKeepsTheResetTokenUsable() throws Exception {
    client.forgot(u.email());
    String token = AuthTestData.awaitResetToken(mailbox, u.email(), 1);

    client.reset(token, "short").andExpect(status().isBadRequest())
        .andExpect(jsonPath("$.code").value("password_policy"))
        .andExpect(jsonPath("$.violations[0]").value("too_short"));
    assertThat(data.auditOfRequest(client.lastRequestId())).containsExactly("auth.password.reset/FAILURE/ANONYMOUS");

    client.reset(token, u.password()).andExpect(status().isBadRequest())
        .andExpect(jsonPath("$.violations[0]").value("reused"));
    client.reset(token, NEW_PASSWORD).andExpect(status().isNoContent());
  }

  @Test
  void anUnknownResetTokenIs400() throws Exception {
    client.reset("bogus-token", NEW_PASSWORD).andExpect(status().isBadRequest())
        .andExpect(jsonPath("$.code").value("invalid_token"));
  }

  @Test
  void changeRequiresTheCurrentPassword() throws Exception {
    AuthClient.Tokens tokens = client.loginOk(u.email(), u.password());

    client.change(tokens.bearer(), "Not-The-Current-1", NEW_PASSWORD)
        .andExpect(status().isBadRequest())
        .andExpect(jsonPath("$.code").value("invalid_current_password"));

    assertThat(data.auditOfRequest(client.lastRequestId())).containsExactly("auth.password.changed/FAILURE/USER");
    client.login(u.email(), u.password()).andExpect(status().isOk());
  }

  @Test
  void wrongCurrentPasswordsCountAsFailuresAndTheFifthLocksTheUserAndEndsTheSession() throws Exception {
    AuthClient.Tokens tokens = client.loginOk(u.email(), u.password());
    for (int i = 1; i <= 4; i++) {
      client.change(tokens.bearer(), "Not-The-Current-" + i, NEW_PASSWORD)
          .andExpect(status().isBadRequest())
          .andExpect(jsonPath("$.code").value("invalid_current_password"));
    }
    assertThat(jdbc.sql("SELECT failed_logins FROM app_user WHERE id = :id").param("id", u.userId())
        .query(Integer.class).single()).isEqualTo(4);

    client.change(tokens.bearer(), "Not-The-Current-5", NEW_PASSWORD)
        .andExpect(status().isUnauthorized())
        .andExpect(jsonPath("$.code").value("session_invalid"));

    assertThat(data.auditOfRequest(client.lastRequestId())).containsExactly(
        "auth.password.changed/FAILURE/USER", "auth.locked/DENIED/USER", "auth.sessions.revoked/SUCCESS/USER");
    assertThat(data.session(sid(tokens)).get("revoked_at")).isNotNull();
    assertThat(data.revocationReasons(u.userId())).containsExactly("password_change_lockout");
    assertThat(jdbc.sql("SELECT locked_until > now() FROM app_user WHERE id = :id").param("id", u.userId())
        .query(Boolean.class).single()).isTrue();
    client.login(u.email(), u.password()).andExpect(status().isUnauthorized());
    poller.poll();
    client.change(tokens.bearer(), u.password(), NEW_PASSWORD).andExpect(status().isUnauthorized());
  }

  @Test
  void aLockedUserCannotChangeThePasswordEvenWithTheRightCurrentPassword() throws Exception {
    AuthClient.Tokens tokens = client.loginOk(u.email(), u.password());
    jdbc.sql("UPDATE app_user SET locked_until = now() + interval '10 minutes' WHERE id = :id")
        .param("id", u.userId()).update();

    client.change(tokens.bearer(), u.password(), NEW_PASSWORD)
        .andExpect(status().isForbidden())
        .andExpect(jsonPath("$.code").value("account_locked"));
    client.change(tokens.bearer(), "Not-The-Current-1", NEW_PASSWORD)
        .andExpect(status().isForbidden())
        .andExpect(jsonPath("$.code").value("account_locked"));

    assertThat(passwords.matches(u.password(), jdbc.sql("SELECT password_hash FROM app_user WHERE id = :id")
        .param("id", u.userId()).query(String.class).single())).isTrue();
  }

  @Test
  void changeKeepsTheCurrentSessionRevokesTheOthersAndReturnsFreshTokens() throws Exception {
    AuthClient.Tokens current = client.loginOk(u.email(), u.password());
    AuthClient.Tokens other = client.loginOk(u.email(), u.password());
    int svBefore = data.sessionVersion(u.userId());

    AuthClient.Tokens fresh = client.tokens(client.change(current.bearer(), u.password(), NEW_PASSWORD)
        .andExpect(status().isOk()).andReturn());

    assertThat(data.auditOfRequest(client.lastRequestId()))
        .containsExactly("auth.password.changed/SUCCESS/USER", "auth.sessions.revoked/SUCCESS/USER");
    Jwt jwt = jwtDecoder.decode(fresh.accessToken());
    assertThat(((Number) jwt.getClaim(Claims.SESSION_VERSION)).intValue()).isEqualTo(svBefore + 1);
    assertThat(jwt.getClaimAsString(Claims.SESSION)).isEqualTo(sid(current).toString());
    assertThat(data.session(sid(current)).get("revoked_at")).isNull();
    assertThat(data.session(sid(other)).get("revoked_at")).isNotNull();
    assertThat(data.revocationReasons(u.userId())).containsExactly("password_change");

    poller.poll();
    client.me(current.bearer()).andExpect(status().isUnauthorized());
    client.me(fresh.bearer()).andExpect(status().isOk());
    client.refresh(fresh.refreshToken()).andExpect(status().isOk());
    client.refresh(other.refreshToken()).andExpect(status().isUnauthorized());
    client.login(u.email(), NEW_PASSWORD).andExpect(status().isOk());
  }

  @Test
  void changeIssuesTokensForTheSessionsActiveTenantEvenWithAnOlderAccessToken() throws Exception {
    UUID second = data.fx.tenant(u.accountId());
    data.fx.membership(u.userId(), second, MembershipStatus.ACTIVE);
    AuthClient.Tokens login = client.loginOk(u.email(), u.password());
    client.switchTenant(login.bearer(), second).andExpect(status().isOk());

    // the pre-switch access token (tid = primary tenant) is still valid for its 15 minutes
    AuthClient.Tokens fresh = client.tokens(client.change(login.bearer(), u.password(), NEW_PASSWORD).andReturn());

    assertThat(fresh.activeTenantId()).isEqualTo(second);
    assertThat(jwtDecoder.decode(fresh.accessToken()).getClaimAsString(Claims.TENANT)).isEqualTo(second.toString());
  }

  @Test
  void changeAppliesTheAccountPolicyIncludingTheBreachedCheck() throws Exception {
    data.accountSettings(u.accountId(), "{\"passwordPolicy\": {\"breachedCheck\": true, \"minLength\": 14}}");
    AuthClient.Tokens tokens = client.loginOk(u.email(), u.password());

    client.change(tokens.bearer(), u.password(), "Known-Breached-Passphrase")
        .andExpect(status().isBadRequest())
        .andExpect(jsonPath("$.code").value("password_policy"))
        .andExpect(jsonPath("$.violations[0]").value("breached"));
    client.change(tokens.bearer(), u.password(), "Thirteen-Char")
        .andExpect(status().isBadRequest())
        .andExpect(jsonPath("$.violations[0]").value("too_short"));
  }

  @Test
  void changeNeedsAnAccessToken() throws Exception {
    client.change(null, u.password(), NEW_PASSWORD).andExpect(status().isUnauthorized());
  }

  private UUID sid(AuthClient.Tokens tokens) {
    return UUID.fromString(jwtDecoder.decode(tokens.accessToken()).getClaimAsString(Claims.SESSION));
  }
}
