package com.acme.iam.security;

import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.http.HttpHeaders.AUTHORIZATION;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.multipart;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.patch;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;

import com.acme.iam.account.Account;
import com.acme.iam.assignment.PermissionResolver;
import com.acme.iam.assignment.ScopeType;
import com.acme.iam.common.Ids;
import com.acme.iam.common.test.Fixtures;
import com.acme.iam.common.test.IntegrationTest;
import com.acme.iam.common.test.PostgresTestBase;
import com.acme.iam.common.test.TestTokens;
import com.acme.iam.product.Product;
import com.acme.iam.user.UserStatus;
import java.lang.reflect.Method;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.TreeSet;
import java.util.UUID;
import java.util.function.Function;
import java.util.stream.Stream;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.MethodSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.core.annotation.AnnotatedElementUtils;
import org.springframework.http.MediaType;
import org.springframework.jdbc.core.simple.JdbcClient;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;
import org.springframework.web.method.HandlerMethod;
import org.springframework.web.servlet.mvc.method.RequestMappingInfo;
import org.springframework.web.servlet.mvc.method.annotation.RequestMappingHandlerMapping;

/**
 * P1-11.1 authorization matrix (Task 9). Every {@code /api/**} and {@code /internal/**} endpoint, read from the live
 * {@link RequestMappingHandlerMapping}, must have at least one row in {@link #ROWS}; an endpoint without a row, or a
 * handler without {@code @PreAuthorize} that is not in {@link #AUTHENTICATED_ONLY} / {@link #PUBLIC}, fails the build.
 *
 * <p>Each row is run for five <b>holder dimensions</b> (wave 3 context) and an application token:
 *
 * <ol>
 *   <li>{@link Dim#NONE}: a user of the home account without the permission;
 *   <li>{@link Dim#TENANT_SCOPE}: the permission through a TENANT-scope assignment in the active tenant {@code T1};
 *   <li>{@link Dim#ACCOUNT_SCOPE}: the permission through an ACCOUNT-scope assignment;
 *   <li>{@link Dim#OTHER_ACCOUNT}: an ACCOUNT-scope holder of another account aiming at the home account's resources;
 *   <li>{@link Dim#OTHER_TENANT}: a TENANT-scope holder whose active tenant is {@code T2} of the same account;
 *   <li>{@link Dim#APP}: an application token ({@code typ=app}, only {@code internal.*} authorities).
 * </ol>
 *
 * Tokens carry exactly what login would put in them ({@link PermissionResolver#resolve}). For the platform rows the
 * home account is PLATFORM (tenants {@code T1}/{@code T2} are platform tenants) and the other account is a customer
 * account whose CUSTOM role (forged past I6/I8) contains {@code platform.account.manage}. Every case gets a fresh
 * {@link World}, so destructive requests never affect another case. Only the status is asserted.
 *
 * <p>Requests are minimal valid requests. List endpoints that take a tenant filter name {@code T2}, so a TENANT-scope
 * holder of an account-wide permission becomes visible as a status (403 {@code scope_exceeded}) instead of a filtered
 * 200.
 */
@IntegrationTest
@AutoConfigureMockMvc
class AuthorizationMatrixIT extends PostgresTestBase {

  enum Dim { NONE, TENANT_SCOPE, ACCOUNT_SCOPE, OTHER_ACCOUNT, OTHER_TENANT, APP }

  /** Handlers that are intentionally authenticated-only (no {@code @PreAuthorize}). */
  static final Set<String> AUTHENTICATED_ONLY = Set.of("GET /api/me", "GET /api/products/{code}/permissions",
      "POST /auth/logout", "POST /auth/logout-all", "POST /auth/switch-tenant", "POST /auth/password/change");
  /** Handlers on public paths (no bearer token at all). */
  static final Set<String> PUBLIC = Set.of("POST /internal/token", "POST /auth/login", "POST /auth/refresh",
      "POST /auth/password/forgot", "POST /auth/password/reset", "POST /auth/invitations/accept",
      "GET /.well-known/jwks.json");
  /** The only accepted {@code @PreAuthorize} shapes outside the allowlists (fix round 1). */
  private static final java.util.regex.Pattern HAS_AUTHORITY =
      java.util.regex.Pattern.compile("hasAuthority\\('([a-z0-9_.]+)'\\)");
  private static final java.util.regex.Pattern HAS_ANY_AUTHORITY =
      java.util.regex.Pattern.compile("hasAnyAuthority\\(\\s*'[a-z0-9_.]+'(\\s*,\\s*'[a-z0-9_.]+')*\\s*\\)");

  private static final String PLATFORM = "platform.account.manage";
  private static final String TENANT_MANAGE = "iam.tenant.manage";
  private static final String USER_MANAGE = "iam.user.manage";
  private static final String USER_SHARE = "iam.user.share";
  private static final String READ_ACCOUNT = "iam.user.read.account";
  private static final String READ_TENANT = "iam.user.read.tenant";
  private static final String ROLE_MANAGE = "iam.role.manage";
  private static final String ROLE_ASSIGN = "iam.role.assign";
  private static final String AUDIT_READ = "iam.audit.read";
  private static final String AUDIT_EXPORT = "iam.audit.export";

  /** Statuses for NONE, TENANT_SCOPE, ACCOUNT_SCOPE, OTHER_ACCOUNT, OTHER_TENANT, APP. */
  private static final String DENY_ALL_APP_OK_200 = "403,403,403,403,403,200";

  /** {@code home}: whose resources the request addresses. */
  enum Home { CUSTOMER, PLATFORM }

  record Row(String method, String pattern, String permission, Home home, String expected,
             Function<World, MockHttpServletRequestBuilder> request) {

    String endpoint() {
      return method + " " + pattern;
    }

    int expected(Dim dim) {
      return Integer.parseInt(expected.split(",")[dim.ordinal()].trim());
    }
  }

  record Case(Row row, Dim dim) {
    @Override
    public String toString() {
      return row.endpoint() + " [" + row.permission() + "] " + dim + " -> " + row.expected(dim);
    }
  }

  // ------------------------------------------------------------------------------------------- the table

  static final java.util.List<Row> ROWS = java.util.List.of(
      // ---- platform: PLATFORM account + platform.account.manage at ACCOUNT scope (PlatformGuard)
      row("POST", "/api/platform/accounts", PLATFORM, Home.PLATFORM, "403,403,201,403,403,403",
          w -> json(post("/api/platform/accounts"), ("{\"name\":\"M\",\"slug\":\"m-%s\","
              + "\"defaultTenant\":{\"name\":\"HQ\",\"slug\":\"hq\"},\"defaultUser\":{\"email\":\"a-%s@example.test\"}}")
              .formatted(w.nonce, w.nonce))),
      row("GET", "/api/platform/accounts", PLATFORM, Home.PLATFORM, "403,403,200,403,403,403",
          w -> get("/api/platform/accounts")),
      row("GET", "/api/platform/accounts/{id}", PLATFORM, Home.PLATFORM, "403,403,200,403,403,403",
          w -> get("/api/platform/accounts/{id}", w.customerAccount)),
      row("PATCH", "/api/platform/accounts/{id}", PLATFORM, Home.PLATFORM, "403,403,200,403,403,403",
          w -> json(patch("/api/platform/accounts/{id}", w.customerAccount), "{\"name\":\"Renamed\"}")),
      row("POST", "/api/platform/accounts/{id}/suspend", PLATFORM, Home.PLATFORM, "403,403,200,403,403,403",
          w -> post("/api/platform/accounts/{id}/suspend", w.customerAccount)),
      row("POST", "/api/platform/accounts/{id}/reactivate", PLATFORM, Home.PLATFORM, "403,403,200,403,403,403",
          w -> post("/api/platform/accounts/{id}/reactivate", w.customerAccount)),
      row("POST", "/api/platform/accounts/{id}/close", PLATFORM, Home.PLATFORM, "403,403,200,403,403,403",
          w -> post("/api/platform/accounts/{id}/close", w.customerAccount)),
      row("PUT", "/api/platform/accounts/{id}/products", PLATFORM, Home.PLATFORM, "403,403,200,403,403,403",
          w -> json(put("/api/platform/accounts/{id}/products", w.customerAccount), "{\"products\":[]}")),
      row("POST", "/api/platform/app-clients", PLATFORM, Home.PLATFORM, "403,403,201,403,403,403",
          w -> json(post("/api/platform/app-clients"), "{\"clientId\":\"mxn-%s\",\"productCode\":\"BILLING\"}"
              .formatted(w.nonce))),
      row("GET", "/api/platform/app-clients", PLATFORM, Home.PLATFORM, "403,403,200,403,403,403",
          w -> get("/api/platform/app-clients")),
      row("DELETE", "/api/platform/app-clients/{id}", PLATFORM, Home.PLATFORM, "403,403,204,403,403,403",
          w -> delete("/api/platform/app-clients/{id}", w.appClient)),
      row("POST", "/api/platform/app-clients/{id}/disable", PLATFORM, Home.PLATFORM, "403,403,200,403,403,403",
          w -> post("/api/platform/app-clients/{id}/disable", w.appClient)),
      row("POST", "/api/platform/app-clients/{id}/rotate-secret", PLATFORM, Home.PLATFORM, "403,403,200,403,403,403",
          w -> post("/api/platform/app-clients/{id}/rotate-secret", w.appClient)),
      row("POST", "/api/platform/accounts/{id}/sessions/revoke", PLATFORM, Home.PLATFORM, "403,403,200,403,403,403",
          w -> post("/api/platform/accounts/{id}/sessions/revoke", w.customerAccount)),
      // R43: platform recovery of an account's admin
      row("POST", "/api/platform/accounts/{id}/admins", PLATFORM, Home.PLATFORM, "403,403,200,403,403,403",
          w -> json(post("/api/platform/accounts/{id}/admins", w.customerAccount),
              "{\"email\":\"r-%s@example.test\",\"tenantId\":\"%s\"}".formatted(w.nonce, w.customerTenant))),
      // R46: tenant creation is a platform operation
      row("POST", "/api/platform/accounts/{id}/tenants", PLATFORM, Home.PLATFORM, "403,403,201,403,403,403",
          w -> json(post("/api/platform/accounts/{id}/tenants", w.customerAccount),
              "{\"name\":\"T\",\"slug\":\"pt-%s\"}".formatted(w.nonce))),

      // ---- tenants: account-level objects, ACCOUNT scope required for every endpoint
      row("GET", "/api/tenants", TENANT_MANAGE, Home.CUSTOMER, "403,403,200,200,403,403",
          w -> get("/api/tenants")),
      row("GET", "/api/tenants/{id}", TENANT_MANAGE, Home.CUSTOMER, "403,403,200,404,403,403",
          w -> get("/api/tenants/{id}", w.t1)),
      row("PATCH", "/api/tenants/{id}", TENANT_MANAGE, Home.CUSTOMER, "403,403,200,404,403,403",
          w -> json(patch("/api/tenants/{id}", w.t1), "{\"name\":\"Renamed\"}")),
      row("POST", "/api/tenants/{id}/suspend", TENANT_MANAGE, Home.CUSTOMER, "403,403,200,404,403,403",
          w -> post("/api/tenants/{id}/suspend", w.t1)),
      row("POST", "/api/tenants/{id}/reactivate", TENANT_MANAGE, Home.CUSTOMER, "403,403,200,404,403,403",
          w -> post("/api/tenants/{id}/reactivate", w.t1)),
      row("POST", "/api/tenants/{id}/archive", TENANT_MANAGE, Home.CUSTOMER, "403,403,200,404,403,403",
          w -> post("/api/tenants/{id}/archive", w.t1)),
      row("PUT", "/api/tenants/{id}/products", TENANT_MANAGE, Home.CUSTOMER, "403,403,200,404,403,403",
          w -> json(put("/api/tenants/{id}/products", w.t1), "{\"products\":[]}")),

      // ---- users (targets: user = ACTIVE member of T1 only; shared = primary T1 + member of T2; invited = INVITED in T1)
      // R42: a .account DATA permission granted at TENANT scope grants nothing (403 from @PreAuthorize)
      row("GET", "/api/users", READ_ACCOUNT, Home.CUSTOMER, "403,403,200,404,403,403",
          w -> get("/api/users").param("tenantId", w.t2.toString())),
      row("GET", "/api/users", READ_TENANT, Home.CUSTOMER, "403,403,403,404,200,403",
          w -> get("/api/users").param("tenantId", w.t2.toString())),
      row("GET", "/api/users/{id}", READ_ACCOUNT, Home.CUSTOMER, "403,403,200,404,403,403",
          w -> get("/api/users/{id}", w.user)),
      row("GET", "/api/users/{id}", READ_TENANT, Home.CUSTOMER, "403,200,200,404,404,403",
          w -> get("/api/users/{id}", w.user)),
      row("PATCH", "/api/users/{id}", USER_MANAGE, Home.CUSTOMER, "403,200,200,404,403,403",
          w -> json(patch("/api/users/{id}", w.user), "{\"displayName\":\"Renamed\"}")),
      row("POST", "/api/users/{id}/disable", USER_MANAGE, Home.CUSTOMER, "403,200,200,404,403,403",
          w -> post("/api/users/{id}/disable", w.user)),
      row("POST", "/api/users/{id}/enable", USER_MANAGE, Home.CUSTOMER, "403,200,200,404,403,403",
          w -> post("/api/users/{id}/enable", w.user)),
      row("POST", "/api/users/{id}/deprovision", USER_MANAGE, Home.CUSTOMER, "403,200,200,404,403,403",
          w -> post("/api/users/{id}/deprovision", w.user)),
      row("POST", "/api/users/{id}/invitation/resend", USER_MANAGE, Home.CUSTOMER, "403,200,200,404,403,403",
          w -> post("/api/users/{id}/invitation/resend", w.invited)),
      row("POST", "/api/users/{id}/memberships", USER_SHARE, Home.CUSTOMER, "403,403,201,404,403,403",
          w -> json(post("/api/users/{id}/memberships", w.user), "{\"tenantId\":\"%s\"}".formatted(w.t2))),
      row("DELETE", "/api/users/{id}/memberships/{tenantId}", USER_SHARE, Home.CUSTOMER, "403,403,204,404,204,403",
          w -> delete("/api/users/{id}/memberships/{tenantId}", w.shared, w.t2)),
      row("POST", "/api/users/{id}/unlock", USER_MANAGE, Home.CUSTOMER, "403,200,200,404,403,403",
          w -> post("/api/users/{id}/unlock", w.user)),
      row("POST", "/api/users/{id}/sessions/revoke", "iam.session.revoke", Home.CUSTOMER, "403,200,200,404,403,403",
          w -> post("/api/users/{id}/sessions/revoke", w.user)),
      // a real change: the shared user (primary T1, member of T2) moves its primary tenant to T2
      row("PUT", "/api/users/{id}/primary-tenant", USER_MANAGE, Home.CUSTOMER, "403,403,200,404,403,403",
          w -> json(put("/api/users/{id}/primary-tenant", w.shared), "{\"tenantId\":\"%s\"}".formatted(w.t2))),

      // ---- invitations into a tenant
      row("POST", "/api/tenants/{tenantId}/users", USER_MANAGE, Home.CUSTOMER, "403,201,201,404,403,403",
          w -> json(post("/api/tenants/{tenantId}/users", w.t1), "{\"email\":\"i-%s@example.test\"}".formatted(w.nonce))),
      row("POST", "/api/tenants/{tenantId}/users/bulk", USER_MANAGE, Home.CUSTOMER, "403,202,202,404,403,403",
          w -> multipart("/api/tenants/{tenantId}/users/bulk", w.t1).file(new MockMultipartFile("file", "u.csv",
              "text/csv", ("b-" + w.nonce + "@example.test,B,\n").getBytes()))),
      row("GET", "/api/bulk-invites/{jobId}", USER_MANAGE, Home.CUSTOMER, "403,200,200,404,403,403",
          w -> get("/api/bulk-invites/{jobId}", w.bulkJob)),

      // ---- roles: CUSTOM roles are account-wide, so writes need ACCOUNT scope; reads are open to role.manage/assign
      row("GET", "/api/roles", ROLE_MANAGE, Home.CUSTOMER, "403,200,200,200,200,403",
          w -> get("/api/roles")),
      row("GET", "/api/roles", ROLE_ASSIGN, Home.CUSTOMER, "403,200,200,200,200,403",
          w -> get("/api/roles")),
      row("GET", "/api/roles/{id}", ROLE_MANAGE, Home.CUSTOMER, "403,200,200,404,200,403",
          w -> get("/api/roles/{id}", w.role)),
      row("GET", "/api/roles/{id}", ROLE_ASSIGN, Home.CUSTOMER, "403,200,200,404,200,403",
          w -> get("/api/roles/{id}", w.role)),
      row("POST", "/api/roles", ROLE_MANAGE, Home.CUSTOMER, "403,403,201,201,403,403",
          w -> json(post("/api/roles"), "{\"productCode\":\"IAM\",\"name\":\"R %s\",\"permissionCodes\":[]}"
              .formatted(w.nonce))),
      row("PATCH", "/api/roles/{id}", ROLE_MANAGE, Home.CUSTOMER, "403,403,200,404,403,403",
          w -> json(patch("/api/roles/{id}", w.role), "{\"name\":\"Renamed %s\"}".formatted(w.nonce))),
      row("PUT", "/api/roles/{id}/permissions", ROLE_MANAGE, Home.CUSTOMER, "403,403,200,404,403,403",
          w -> json(put("/api/roles/{id}/permissions", w.role), "{\"permissionCodes\":[]}")),
      row("DELETE", "/api/roles/{id}", ROLE_MANAGE, Home.CUSTOMER, "403,403,204,404,403,403",
          w -> delete("/api/roles/{id}", w.freeRole)),

      // ---- assignments
      row("POST", "/api/users/{userId}/assignments", ROLE_ASSIGN, Home.CUSTOMER, "403,201,201,404,403,403",
          w -> json(post("/api/users/{userId}/assignments", w.user),
              "{\"roleId\":\"%s\",\"scopeType\":\"TENANT\",\"scopeId\":\"%s\"}".formatted(w.emptyRole, w.t1))),
      row("DELETE", "/api/assignments/{id}", ROLE_ASSIGN, Home.CUSTOMER, "403,204,204,404,403,403",
          w -> delete("/api/assignments/{id}", w.assignment)),
      row("GET", "/api/users/{userId}/assignments", ROLE_ASSIGN, Home.CUSTOMER, "403,200,200,404,404,403",
          w -> get("/api/users/{userId}/assignments", w.user)),
      row("GET", "/api/roles/{roleId}/assignments", ROLE_ASSIGN, Home.CUSTOMER, "403,200,200,404,200,403",
          w -> get("/api/roles/{roleId}/assignments", w.role)),
      row("GET", "/api/tenants/{tenantId}/assignments", ROLE_ASSIGN, Home.CUSTOMER, "403,200,200,404,403,403",
          w -> get("/api/tenants/{tenantId}/assignments", w.t1)),

      // ---- explain
      row("GET", "/api/users/{id}/effective-permissions", READ_ACCOUNT, Home.CUSTOMER, "403,403,200,404,403,403",
          w -> get("/api/users/{id}/effective-permissions", w.user)),
      row("GET", "/api/users/{id}/effective-permissions", READ_TENANT, Home.CUSTOMER, "403,200,200,404,404,403",
          w -> get("/api/users/{id}/effective-permissions", w.user)),

      // ---- audit (R25: tenant filter T2)
      row("GET", "/api/audit/events", AUDIT_READ, Home.CUSTOMER, "403,403,200,404,200,403",
          w -> window(get("/api/audit/events"), w).param("tenantId", w.t2.toString())),
      row("GET", "/api/audit/targets/{type}/{id}", AUDIT_READ, Home.CUSTOMER, "403,200,200,200,200,403",
          w -> get("/api/audit/targets/{type}/{id}", "app_user", w.user)),
      row("GET", "/api/audit/exports.csv", AUDIT_EXPORT, Home.CUSTOMER, "403,403,200,404,200,403",
          w -> window(get("/api/audit/exports.csv"), w).param("tenantId", w.t2.toString())),

      // ---- authenticated-only
      row("GET", "/api/me", null, Home.CUSTOMER, "200,200,200,200,200,403",
          w -> get("/api/me")),
      row("GET", "/api/products/{code}/permissions", null, Home.CUSTOMER, "200,200,200,200,200,200",
          w -> get("/api/products/{code}/permissions", "IAM")),

      // ---- /internal/**: application tokens only (user tokens never carry internal.* authorities)
      row("GET", "/internal/revocations", "internal.revocations.read", Home.CUSTOMER, DENY_ALL_APP_OK_200,
          w -> get("/internal/revocations").param("since", "0")),
      row("POST", "/internal/audit/events", "internal.audit.write", Home.CUSTOMER, DENY_ALL_APP_OK_200,
          w -> json(post("/internal/audit/events"), "{\"events\":[]}")),
      row("PUT", "/internal/products/{code}/manifest", "internal.manifest.write", Home.CUSTOMER, DENY_ALL_APP_OK_200,
          w -> json(put("/internal/products/{code}/manifest", w.productCode),
              "{\"product\":\"%s\",\"name\":\"Matrix\",\"permissions\":[],\"system_roles\":[]}".formatted(w.productCode))),
      // public: client credentials only; a bearer token is ignored, no Basic credentials = 401 invalid_client
      row("POST", "/internal/token", null, Home.CUSTOMER, "401,401,401,401,401,401",
          w -> post("/internal/token").contentType(MediaType.APPLICATION_FORM_URLENCODED)
              .param("grant_type", "client_credentials")));

  static Stream<Case> cases() {
    return ROWS.stream().flatMap(r -> Arrays.stream(Dim.values()).map(d -> new Case(r, d)));
  }

  // ---------------------------------------------------------------------------------------------- tests

  @Autowired MockMvc mvc;
  @Autowired TestTokens tokens;
  @Autowired JdbcClient jdbc;
  @Autowired PermissionResolver resolver;
  @Autowired @Qualifier("requestMappingHandlerMapping") RequestMappingHandlerMapping mappings;

  /**
   * Every /api/** and /internal/** endpoint has a row and every row is a real endpoint; every /auth/** and
   * /.well-known/** endpoint is PUBLIC or AUTHENTICATED_ONLY, the authenticated /auth ones have an {@link #AUTH_ROWS}
   * row and are exactly {@code SecurityConfig.AUTH_AUTHENTICATED_PATHS}; a row without a permission is allowlisted.
   */
  @Test
  void everyEndpointIsInTheTable() {
    Set<String> live = apiEndpoints().keySet();
    Set<String> table = new TreeSet<>();
    ROWS.forEach(r -> table.add(r.endpoint()));
    Set<String> api = new TreeSet<>();
    Set<String> auth = new TreeSet<>();
    live.forEach(e -> (e.contains(" /api/") || e.contains(" /internal/") ? api : auth).add(e));

    assertThat(api).as("endpoints without a row in AuthorizationMatrixIT.ROWS").isSubsetOf(table);
    assertThat(table).as("rows without an endpoint").isSubsetOf(live);
    Set<String> allowlisted = new TreeSet<>(PUBLIC);
    allowlisted.addAll(AUTHENTICATED_ONLY);
    assertThat(auth).as("/auth/** and /.well-known/** endpoints must be PUBLIC or AUTHENTICATED_ONLY")
        .isSubsetOf(allowlisted);
    Set<String> authenticatedAuth = new TreeSet<>();
    AUTHENTICATED_ONLY.stream().filter(e -> e.contains(" /auth/")).forEach(authenticatedAuth::add);
    assertThat(authenticatedAuth).as("AUTHENTICATED_ONLY /auth endpoints == SecurityConfig.AUTH_AUTHENTICATED_PATHS")
        .isEqualTo(new TreeSet<>(Arrays.stream(com.acme.iam.common.security.SecurityConfig.AUTH_AUTHENTICATED_PATHS)
            .map(path -> "POST " + path).toList()));
    assertThat(AUTH_ROWS.stream().map(r -> "POST " + r.path()).toList())
        .containsExactlyInAnyOrderElementsOf(authenticatedAuth);
    ROWS.stream().filter(r -> r.permission() == null)
        .forEach(r -> assertThat(AUTHENTICATED_ONLY.contains(r.endpoint()) || PUBLIC.contains(r.endpoint()))
            .as(r.endpoint() + " has no permission but is not allowlisted").isTrue());
  }

  /**
   * Every handler has an explicit {@code @PreAuthorize} naming the row's permission, unless it is listed as
   * authenticated-only or public; an unannotated handler fails the build.
   */
  @Test
  void everyHandlerHasAnExplicitPreAuthorize() {
    Map<String, Method> live = apiEndpoints();
    java.util.List<String> problems = new ArrayList<>();
    live.forEach((endpoint, method) -> {
      PreAuthorize pre = AnnotatedElementUtils.findMergedAnnotation(method, PreAuthorize.class);
      if (pre == null) {
        pre = AnnotatedElementUtils.findMergedAnnotation(method.getDeclaringClass(), PreAuthorize.class);
      }
      problems.addAll(preAuthorizeProblems(endpoint, pre == null ? null : pre.value()));
    });
    assertThat(problems).isEmpty();
  }

  /**
   * Fix round 1: the expression is parsed, not searched. Outside the allowlists only an exact
   * {@code hasAuthority('p')} or {@code hasAnyAuthority('p', 'q')} is accepted, and its authorities must be exactly
   * the permissions of the endpoint's rows; {@code permitAll()}, {@code isAuthenticated()}, {@code or}, {@code true}
   * and anything else fail. AUTHENTICATED_ONLY handlers may carry {@code isAuthenticated()}; PUBLIC ones nothing.
   */
  static java.util.List<String> preAuthorizeProblems(String endpoint, String expression) {
    java.util.List<String> problems = new ArrayList<>();
    String value = expression == null ? null : expression.trim();
    if (PUBLIC.contains(endpoint)) {
      if (value != null) {
        problems.add(endpoint + ": public but annotated with " + value);
      }
      return problems;
    }
    if (AUTHENTICATED_ONLY.contains(endpoint)) {
      if (value != null && !value.equals("isAuthenticated()")) {
        problems.add(endpoint + ": authenticated-only but annotated with " + value);
      }
      return problems;
    }
    if (value == null) {
      problems.add(endpoint + ": no @PreAuthorize and not allowlisted");
      return problems;
    }
    Set<String> authorities = new TreeSet<>();
    if (HAS_AUTHORITY.matcher(value).matches()) {
      java.util.regex.Matcher m = HAS_AUTHORITY.matcher(value);
      m.matches();
      authorities.add(m.group(1));
    } else if (HAS_ANY_AUTHORITY.matcher(value).matches()) {
      java.util.regex.Matcher q = java.util.regex.Pattern.compile("'([a-z0-9_.]+)'").matcher(value);
      while (q.find()) {
        authorities.add(q.group(1));
      }
    } else {
      problems.add(endpoint + ": @PreAuthorize(" + value + ") is not an exact hasAuthority/hasAnyAuthority");
      return problems;
    }
    Set<String> rowPermissions = new TreeSet<>();
    ROWS.stream().filter(r -> r.endpoint().equals(endpoint) && r.permission() != null)
        .forEach(r -> rowPermissions.add(r.permission()));
    if (!authorities.equals(rowPermissions)) {
      problems.add(endpoint + ": @PreAuthorize(" + value + ") authorities " + authorities + " != rows "
          + rowPermissions);
    }
    return problems;
  }

  /** The gate itself: what it accepts and what it rejects. */
  @Test
  void theGateRejectsAnythingButExactAuthorityChecks() {
    String endpoint = "GET /api/roles";
    assertThat(preAuthorizeProblems(endpoint, "hasAnyAuthority('iam.role.manage','iam.role.assign')")).isEmpty();
    assertThat(preAuthorizeProblems(endpoint, "hasAnyAuthority('iam.role.manage', 'iam.role.assign')")).isEmpty();
    for (String loophole : new String[] {"permitAll()", "isAuthenticated()", "true",
        "hasAuthority('iam.role.manage') or true", "hasAuthority('iam.role.manage') or permitAll()",
        "hasAuthority('iam.role.manage')", "hasAnyAuthority('iam.role.manage','iam.role.assign','x.y')",
        "!hasAuthority('iam.role.manage')", "hasRole('ADMIN')"}) {
      assertThat(preAuthorizeProblems(endpoint, loophole)).as(loophole).isNotEmpty();
    }
    assertThat(preAuthorizeProblems(endpoint, null)).isNotEmpty();
    assertThat(preAuthorizeProblems("GET /api/me", "isAuthenticated()")).isEmpty();
    assertThat(preAuthorizeProblems("GET /api/me", "permitAll()")).isNotEmpty();
    assertThat(preAuthorizeProblems("POST /auth/login", "isAuthenticated()")).isNotEmpty();
  }

  // ------------------------------------------------------------------- the authenticated /auth endpoints

  enum AuthDim { NO_TOKEN, VALID_TOKEN, REVOKED_TOKEN }

  record AuthRow(String path, int validStatus, Function<UUID, String> body) {}

  private static final String AUTH_PASSWORD = "Correct-Horse-42!";

  static final java.util.List<AuthRow> AUTH_ROWS = java.util.List.of(
      new AuthRow("/auth/logout", 204, tenant -> null),
      new AuthRow("/auth/logout-all", 204, tenant -> null),
      new AuthRow("/auth/switch-tenant", 200, tenant -> "{\"tenantId\":\"" + tenant + "\"}"),
      new AuthRow("/auth/password/change", 200,
          tenant -> "{\"currentPassword\":\"" + AUTH_PASSWORD + "\",\"newPassword\":\"Another-Horse-43!\"}"));


  record AuthCase(AuthRow row, AuthDim dim) {
    @Override
    public String toString() {
      return "POST " + row.path() + " " + dim;
    }
  }

  static Stream<AuthCase> authCases() {
    return AUTH_ROWS.stream().flatMap(r -> Arrays.stream(AuthDim.values()).map(d -> new AuthCase(r, d)));
  }

  @Autowired com.acme.iam.auth.PasswordService passwords;
  @Autowired com.acme.iam.auth.RevocationService revocations;
  @Autowired com.acme.iam.auth.RevocationPoller poller;
  @Autowired org.springframework.transaction.support.TransactionTemplate tx;
  @Autowired com.fasterxml.jackson.databind.ObjectMapper json;

  /** The four bearer-protected /auth endpoints: 401 without a token and with a revoked one, success with a valid one. */
  @ParameterizedTest(name = "{0}")
  @MethodSource("authCases")
  void authenticatedAuthEndpoints(AuthCase c) throws Exception {
    Fixtures fx = new Fixtures(jdbc);
    Fixtures.Scenario s = fx.scenario();
    jdbc.sql("UPDATE app_user SET password_hash = :h WHERE id = :id").param("h", passwords.hash(AUTH_PASSWORD))
        .param("id", s.userId()).update();
    String ip = "10.9." + (int) (Math.random() * 250) + "." + (1 + (int) (Math.random() * 250));
    String login = mvc.perform(post("/auth/login").with(r -> { r.setRemoteAddr(ip); return r; })
            .contentType(MediaType.APPLICATION_JSON)
            .content("{\"email\":\"" + fx.email(s.userId()) + "\",\"password\":\"" + AUTH_PASSWORD + "\"}"))
        .andReturn().getResponse().getContentAsString();
    String access = json.readTree(login).path("accessToken").asText();
    assertThat(access).as(login).isNotBlank();
    if (c.dim() == AuthDim.REVOKED_TOKEN) {
      tx.executeWithoutResult(t -> revocations.revokeUsers(java.util.List.of(s.userId()), "matrix.revoked"));
      poller.poll();
    }
    MockHttpServletRequestBuilder request = post(c.row().path()).with(r -> { r.setRemoteAddr(ip); return r; });
    String body = c.row().body().apply(s.tenantId());
    if (body != null) {
      request.contentType(MediaType.APPLICATION_JSON).content(body);
    }
    if (c.dim() != AuthDim.NO_TOKEN) {
      request.header(AUTHORIZATION, TestTokens.bearer(access));
    }

    int status = mvc.perform(request).andReturn().getResponse().getStatus();

    assertThat(status).as(c.toString()).isEqualTo(c.dim() == AuthDim.VALID_TOKEN ? c.row().validStatus() : 401);
  }

  /** PUBLIC /auth and /.well-known endpoints are reachable without a token (the security chain lets them through). */
  @Test
  void publicAuthEndpointsNeedNoToken() throws Exception {
    for (String endpoint : PUBLIC) {
      if (!endpoint.contains(" /auth/") && !endpoint.contains(" /.well-known/")) {
        continue;
      }
      String[] parts = endpoint.split(" ");
      MockHttpServletRequestBuilder request = parts[0].equals("GET") ? get(parts[1])
          : post(parts[1]).contentType(MediaType.APPLICATION_JSON).content("{}");
      int status = mvc.perform(request.with(r -> { r.setRemoteAddr("10.8.0." + (1 + (int) (Math.random() * 250)));
        return r; })).andReturn().getResponse().getStatus();
      assertThat(status).as(endpoint).isNotIn(401, 403);
    }
  }

  @ParameterizedTest(name = "{0}")
  @MethodSource("cases")
  void matrix(Case c) throws Exception {
    World w = world(c.row().home());
    MockHttpServletRequestBuilder request = c.row().request().apply(w);
    request.header(AUTHORIZATION, bearer(c, w));

    var response = mvc.perform(request).andReturn().getResponse();
    int status = response.getStatus();

    assertThat(status).as(c.toString()).isEqualTo(c.row().expected(c.dim()));
    if (c.dim() == Dim.OTHER_ACCOUNT && status == 200) {
      // fix round 1: a 200 for another account's caller must not carry any of the home account's ids
      String body = response.getContentAsString();
      for (UUID id : w.homeIds()) {
        assertThat(body).as(c + ": leaks " + id).doesNotContain(id.toString());
      }
    }
  }

  // ------------------------------------------------------------------------------------------ the world

  /** Fresh resources for one case. */
  final class World {
    final Fixtures fx = new Fixtures(jdbc);
    final String nonce = Ids.newId().toString().substring(24);
    final UUID home;
    final UUID t1;
    final UUID t2;
    final UUID other;
    final UUID otherTenant;
    // customer targets (in the home account)
    UUID user;
    UUID shared;
    UUID invited;
    UUID role;
    UUID emptyRole;
    UUID freeRole;
    UUID assignment;
    UUID bulkJob;
    // platform targets
    UUID customerAccount;
    UUID customerTenant;
    UUID appClient;
    final String productCode = "MX" + nonce.toUpperCase();

    /** Every id of the home account's world (customer or platform), for the cross-account leak check. */
    java.util.List<UUID> homeIds() {
      return Stream.of(home, t1, t2, user, shared, invited, role, emptyRole, freeRole, assignment, bulkJob,
          customerAccount, customerTenant, appClient).filter(java.util.Objects::nonNull).toList();
    }

    World(Home kind) {
      home = kind == Home.PLATFORM ? Account.PLATFORM_ID : fx.account();
      t1 = fx.tenant(home);
      t2 = fx.tenant(home);
      other = fx.account();
      otherTenant = fx.tenant(other);
      if (kind == Home.PLATFORM) {
        customerAccount = fx.account();
        customerTenant = fx.tenant(customerAccount);
        appClient = Ids.newId();
        jdbc.sql("""
                INSERT INTO app_client (id, client_id, product_code, secret_hash, status, version)
                VALUES (:id, :cid, 'BILLING', :hash, 'ACTIVE', 0)""")
            .param("id", appClient).param("cid", "mx-" + nonce).param("hash", new byte[32]).update();
        return;
      }
      user = fx.user(home, t1);
      shared = fx.user(home, t1);
      fx.membership(shared, t2, com.acme.iam.user.MembershipStatus.ACTIVE);
      invited = fx.user(home, t1, UserStatus.INVITED);
      role = fx.customRole(Product.IAM_ID, home, fx.permission(Product.IAM_ID, READ_TENANT));
      emptyRole = fx.customRole(Product.IAM_ID, home);
      freeRole = fx.customRole(Product.IAM_ID, home);
      assignment = fx.assign(user, role, ScopeType.TENANT, t1);
      bulkJob = Ids.newId();
      jdbc.sql("""
              INSERT INTO bulk_invite_job (id, account_id, tenant_id, status, total_rows)
              VALUES (:id, :a, :t, 'COMPLETED', 0)""")
          .param("id", bulkJob).param("a", home).param("t", t1).update();
    }
  }

  private World world(Home home) {
    return new World(home);
  }

  /** The caller of a case: a real user with real assignments, and a token that holds what login would give it. */
  private String bearer(Case c, World w) {
    Row row = c.row();
    if (c.dim() == Dim.APP) {
      return TestTokens.bearer(tokens.appToken("matrix-" + w.nonce, w.productCode));
    }
    Fixtures fx = w.fx;
    UUID account = c.dim() == Dim.OTHER_ACCOUNT ? w.other : w.home;
    UUID tenant = switch (c.dim()) {
      case OTHER_ACCOUNT -> w.otherTenant;
      case OTHER_TENANT -> w.t2;
      default -> w.t1;
    };
    UUID caller = fx.user(account, tenant);
    if (row.permission() != null && !row.permission().startsWith("internal.") && c.dim() != Dim.NONE) {
      UUID holderRole = fx.customRole(Product.IAM_ID, account, fx.permission(Product.IAM_ID, row.permission()));
      switch (c.dim()) {
        case TENANT_SCOPE, OTHER_TENANT -> fx.assign(caller, holderRole, ScopeType.TENANT, tenant);
        case ACCOUNT_SCOPE, OTHER_ACCOUNT -> fx.assign(caller, holderRole, ScopeType.ACCOUNT, account);
        default -> throw new IllegalStateException();
      }
    }
    String[] perms = resolver.resolve(caller, tenant).toArray(String[]::new);
    return tokens.user(caller).account(account).tenant(tenant).perms(perms).bearer();
  }

  // ------------------------------------------------------------------------------------------ helpers

  /** {@code METHOD pattern} → handler method, for every /api/** and /internal/** mapping. */
  private Map<String, Method> apiEndpoints() {
    Map<String, Method> endpoints = new TreeMap<>();
    for (Map.Entry<RequestMappingInfo, HandlerMethod> e : mappings.getHandlerMethods().entrySet()) {
      RequestMappingInfo info = e.getKey();
      Set<String> patterns = info.getPathPatternsCondition() != null
          ? info.getPathPatternsCondition().getPatternValues() : info.getPatternValues();
      for (String pattern : patterns) {
        if (!pattern.startsWith("/api/") && !pattern.startsWith("/internal/") && !pattern.startsWith("/auth/")
            && !pattern.startsWith("/.well-known/")) {
          continue;
        }
        Set<org.springframework.web.bind.annotation.RequestMethod> methods = info.getMethodsCondition().getMethods();
        assertThat(methods).as(pattern + " must declare its HTTP method").isNotEmpty();
        methods.forEach(m -> endpoints.put(m.name() + " " + pattern, e.getValue().getMethod()));
      }
    }
    return endpoints;
  }

  private static Row row(String method, String pattern, String permission, Home home, String expected,
                         Function<World, MockHttpServletRequestBuilder> request) {
    return new Row(method, pattern, permission, home, expected, request);
  }

  private static MockHttpServletRequestBuilder json(MockHttpServletRequestBuilder request, String body) {
    return request.contentType(MediaType.APPLICATION_JSON).content(body);
  }

  private static MockHttpServletRequestBuilder window(MockHttpServletRequestBuilder request, World w) {
    Instant now = Instant.now().truncatedTo(ChronoUnit.SECONDS);
    return request.param("from", now.minus(1, ChronoUnit.HOURS).toString()).param("to", now.plusSeconds(60).toString());
  }
}
