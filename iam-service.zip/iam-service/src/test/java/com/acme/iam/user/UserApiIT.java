package com.acme.iam.user;

import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.http.HttpHeaders.AUTHORIZATION;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.patch;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import com.acme.iam.assignment.ScopeType;
import com.acme.iam.common.test.Fixtures;
import com.acme.iam.common.test.IntegrationTest;
import com.acme.iam.common.test.OrgTestData;
import com.acme.iam.common.test.PostgresTestBase;
import com.acme.iam.common.test.TestTokens;
import com.acme.iam.product.Product;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.http.MediaType;
import org.springframework.jdbc.core.simple.JdbcClient;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;

/**
 * P1-8.1 user API: list with data scope, get, profile update, disable/enable/deprovision; invariants I7 (disable
 * path), I9 and I10.
 */
@IntegrationTest
@AutoConfigureMockMvc
class UserApiIT extends PostgresTestBase {

  @Autowired MockMvc mvc;
  @Autowired TestTokens tokens;
  @Autowired JdbcClient jdbc;
  @Autowired ObjectMapper json;
  @Autowired UserTokenService userTokens;

  OrgTestData org;
  Fixtures fx;
  UUID account;
  UUID tenantA;
  UUID tenantB;
  UUID admin;
  String adminBearer;

  @BeforeEach
  void setUp() {
    org = new OrgTestData(jdbc);
    fx = org.fixtures();
    Fixtures.Scenario s = fx.scenario();
    account = s.accountId();
    tenantA = s.tenantId();
    tenantB = fx.tenant(account);
    admin = org.accountAdmin(account, tenantA);
    adminBearer = org.adminBearer(tokens, admin, account, tenantA);
  }

  @Nested
  class ListAndGet {

    @Test
    void accountScopeSeesEveryUserOfTheAccountAndNoOther() throws Exception {
      UUID inB = fx.user(account, tenantB);
      UUID foreign = fx.scenario().userId();

      List<String> ids = listIds(get("/api/users?limit=200"), org.bearer(tokens, admin, account, tenantA,
          "iam.user.read.account"));
      assertThat(ids).contains(admin.toString(), inB.toString()).doesNotContain(foreign.toString());
    }

    @Test
    void tenantScopeIsForcedToTheActiveTenant() throws Exception {
      UUID inA = fx.user(account, tenantA);
      UUID inB = fx.user(account, tenantB);
      String reader = org.bearer(tokens, admin, account, tenantA, "iam.user.read.tenant");

      List<String> ids = listIds(get("/api/users?limit=200"), reader);
      assertThat(ids).contains(inA.toString()).doesNotContain(inB.toString());
      assertThat(listIds(get("/api/users?tenantId=" + tenantA), reader)).contains(inA.toString());

      mvc.perform(get("/api/users?tenantId=" + tenantB).header(AUTHORIZATION, reader))
          .andExpect(status().isForbidden())
          .andExpect(jsonPath("$.code").value("scope_exceeded"));
    }

    @Test
    void accountScopeMayFilterByTenantStatusAndRole() throws Exception {
      UUID inB = fx.user(account, tenantB, UserStatus.DISABLED);
      String reader = org.bearer(tokens, admin, account, tenantA, "iam.user.read.account");
      assertThat(listIds(get("/api/users?tenantId=" + tenantB + "&status=DISABLED"), reader))
          .containsExactly(inB.toString());
      assertThat(listIds(get("/api/users?roleId=" + org.accountAdminRole()), reader)).contains(admin.toString())
          .doesNotContain(inB.toString());
    }

    @Test
    void getRespectsDataScopeAndAccount() throws Exception {
      UUID inB = fx.user(account, tenantB);
      mvc.perform(get("/api/users/{id}", inB).header(AUTHORIZATION,
              org.bearer(tokens, admin, account, tenantA, "iam.user.read.account")))
          .andExpect(status().isOk())
          .andExpect(jsonPath("$.email").value(fx.email(inB)))
          .andExpect(jsonPath("$.memberships[0].tenantId").value(tenantB.toString()))
          .andExpect(jsonPath("$.memberships[0].primary").value(true))
          .andExpect(jsonPath("$.passwordHash").doesNotExist());
      mvc.perform(get("/api/users/{id}", inB).header(AUTHORIZATION,
              org.bearer(tokens, admin, account, tenantA, "iam.user.read.tenant")))
          .andExpect(status().isNotFound())
          .andExpect(jsonPath("$.code").value("user_not_found"));
      UUID foreign = fx.scenario().userId();
      mvc.perform(get("/api/users/{id}", foreign).header(AUTHORIZATION, adminBearer))
          .andExpect(status().isNotFound());
    }

    @Test
    void requiresAUserReadPermission() throws Exception {
      mvc.perform(get("/api/users").header(AUTHORIZATION,
              org.bearer(tokens, admin, account, tenantA, "iam.tenant.manage")))
          .andExpect(status().isForbidden());
    }
  }

  @Nested
  class Writes {

    @Test
    void updatesTheDisplayName() throws Exception {
      UUID user = fx.user(account, tenantA);
      mvc.perform(patch("/api/users/{id}", user).header(AUTHORIZATION, adminBearer)
              .contentType(MediaType.APPLICATION_JSON).content("{\"displayName\":\"Grace Hopper\"}"))
          .andExpect(status().isOk())
          .andExpect(jsonPath("$.displayName").value("Grace Hopper"));
    }

    @Test
    void disableRevokesTokensAndEnableRestores() throws Exception {
      UUID user = fx.user(account, tenantA);
      jdbc.sql("UPDATE app_user SET password_hash = 'x' WHERE id = :id").param("id", user).update();
      int sv = org.sessionVersion(user);

      perform(post("/api/users/{id}/disable", user)).andExpect(status().isOk())
          .andExpect(jsonPath("$.status").value("DISABLED"));
      assertThat(org.sessionVersion(user)).isEqualTo(sv + 1);
      assertThat(org.revocations(user)).isEqualTo(1);

      perform(post("/api/users/{id}/enable", user)).andExpect(status().isOk())
          .andExpect(jsonPath("$.status").value("ACTIVE"));
    }

    @Test
    void enablingADisabledUserWithoutPasswordReturnsToInvited() throws Exception {
      UUID user = fx.user(account, tenantA, UserStatus.DISABLED);
      perform(post("/api/users/{id}/enable", user)).andExpect(status().isOk())
          .andExpect(jsonPath("$.status").value("INVITED"));
    }

    @Test
    void disableInvalidatesOutstandingInvitations() throws Exception {
      UUID user = fx.user(account, tenantA, UserStatus.INVITED);
      userTokens.issue(user, TokenPurpose.INVITE, Duration.ofDays(7), null);
      perform(post("/api/users/{id}/disable", user)).andExpect(status().isOk());
      assertThat(org.outstandingTokens(user)).isZero();
    }

    @Test
    void i7_theLastActiveAccountAdminCannotBeDisabledOrDeprovisioned() throws Exception {
      perform(post("/api/users/{id}/disable", admin))
          .andExpect(status().isConflict())
          .andExpect(jsonPath("$.code").value("last_admin"));
      perform(post("/api/users/{id}/deprovision", admin))
          .andExpect(status().isConflict())
          .andExpect(jsonPath("$.code").value("last_admin"));
      assertThat(org.userStatus(admin)).isEqualTo("ACTIVE");
      assertThat(org.revocations(admin)).isZero();

      UUID second = org.accountAdmin(account, tenantA);
      perform(post("/api/users/{id}/disable", admin)).andExpect(status().isOk());
      assertThat(org.userStatus(second)).isEqualTo("ACTIVE");
    }

    @Test
    void i9_deprovisionKeepsTheRowAndPrimaryMembershipButRemovesAccess() throws Exception {
      UUID user = fx.user(account, tenantA);
      String email = fx.email(user);
      fx.membership(user, tenantB, MembershipStatus.ACTIVE);
      UUID perm = fx.permission(Product.IAM_ID);
      fx.assign(user, fx.systemRole(Product.IAM_ID, perm), ScopeType.TENANT, tenantB);
      fx.assign(user, fx.systemRole(Product.IAM_ID, perm), ScopeType.ACCOUNT, account);
      userTokens.issue(user, TokenPurpose.PASSWORD_RESET, Duration.ofMinutes(30), null);

      perform(post("/api/users/{id}/deprovision", user)).andExpect(status().isOk())
          .andExpect(jsonPath("$.status").value("DEPROVISIONED"))
          .andExpect(jsonPath("$.email").value(email));

      assertThat(org.userStatus(user)).isEqualTo("DEPROVISIONED");
      assertThat(org.assignments(user)).isZero();
      assertThat(org.membershipTenants(user)).containsExactly(tenantA);
      assertThat(jdbc.sql("SELECT status FROM user_tenant_membership WHERE app_user = :u").param("u", user)
          .query(String.class).single()).as("primary membership kept but SUSPENDED").isEqualTo("SUSPENDED");
      assertThat(org.revocations(user)).isEqualTo(1);
      assertThat(org.outstandingTokens(user)).isZero();

      perform(post("/api/users/{id}/enable", user))
          .andExpect(status().isConflict())
          .andExpect(jsonPath("$.code").value("user_deprovisioned"));
      perform(post("/api/users/{id}/disable", user))
          .andExpect(status().isConflict())
          .andExpect(jsonPath("$.code").value("user_deprovisioned"));
    }

    @Test
    void i10_usersOfAnotherAccountAreNotFound() throws Exception {
      Fixtures.Scenario other = fx.scenario();
      perform(post("/api/users/{id}/disable", other.userId()))
          .andExpect(status().isNotFound())
          .andExpect(jsonPath("$.code").value("user_not_found"));
      assertThat(org.userStatus(other.userId())).isEqualTo("ACTIVE");
    }

    @Test
    void writesRequireUserManage() throws Exception {
      UUID user = fx.user(account, tenantA);
      mvc.perform(post("/api/users/{id}/disable", user).header(AUTHORIZATION,
              org.bearer(tokens, admin, account, tenantA, "iam.user.read.account")))
          .andExpect(status().isForbidden());
    }
  }

  /**
   * Ruling R28: account-wide user actions need the permission at ACCOUNT scope, except on a tenant-local target (every
   * ACTIVE membership in the caller's active tenant, no ACCOUNT-scope assignment, not the caller for status changes).
   */
  @Nested
  class TenantScopedManager {

    UUID tenantAdmin;
    String bearer;

    @BeforeEach
    void tenantAdmin() {
      tenantAdmin = fx.user(account, tenantA);
      List<String> perms = new ArrayList<>(OrgTestData.TENANT_ADMIN_PERMISSIONS);
      perms.add("iam.user.share");
      UUID role = fx.systemRole(Product.IAM_ID,
          perms.stream().map(c -> fx.permission(Product.IAM_ID, c)).toArray(UUID[]::new));
      fx.assign(tenantAdmin, role, ScopeType.TENANT, tenantA);
      bearer = org.bearer(tokens, tenantAdmin, account, tenantA, perms.toArray(String[]::new));
    }

    @Test
    void aTenantLocalUserIsManageable() throws Exception {
      UUID local = fx.user(account, tenantA);
      fx.membership(local, tenantB, MembershipStatus.SUSPENDED); // only ACTIVE memberships count
      as(post("/api/users/{id}/disable", local)).andExpect(status().isOk());
      as(post("/api/users/{id}/enable", local)).andExpect(status().isOk());
      as(patch("/api/users/{id}", local).contentType(MediaType.APPLICATION_JSON).content("{\"displayName\":\"L\"}"))
          .andExpect(status().isOk());
    }

    @Test
    void anAccountAdminInTheSameTenantIsOutOfReach() throws Exception {
      org.accountAdmin(account, tenantA); // a second admin, so I7 is not what stops it
      for (String action : List.of("disable", "deprovision", "enable")) {
        as(post("/api/users/{id}/" + action, admin))
            .andExpect(status().isForbidden())
            .andExpect(jsonPath("$.code").value("account_scope_required"));
      }
      as(patch("/api/users/{id}", admin).contentType(MediaType.APPLICATION_JSON).content("{\"displayName\":\"x\"}"))
          .andExpect(status().isForbidden());
      assertThat(org.userStatus(admin)).isEqualTo("ACTIVE");
      assertThat(org.assignments(admin)).isEqualTo(1);
    }

    @Test
    void usersOfOtherTenantsAndSharedUsersAreOutOfReach() throws Exception {
      UUID inB = fx.user(account, tenantB);
      as(post("/api/users/{id}/disable", inB))
          .andExpect(status().isForbidden())
          .andExpect(jsonPath("$.code").value("account_scope_required"));

      UUID shared = fx.user(account, tenantA);
      fx.membership(shared, tenantB, MembershipStatus.ACTIVE);
      as(post("/api/users/{id}/deprovision", shared)).andExpect(status().isForbidden());
      as(put("/api/users/{id}/primary-tenant", shared).contentType(MediaType.APPLICATION_JSON)
          .content("{\"tenantId\":\"%s\"}".formatted(tenantA))).andExpect(status().isForbidden());
      assertThat(org.userStatus(shared)).isEqualTo("ACTIVE");
    }

    @Test
    void shareThenDeprovisionIsBlocked() throws Exception {
      UUID victim = fx.user(account, tenantB);
      as(post("/api/users/{id}/memberships", victim).contentType(MediaType.APPLICATION_JSON)
          .content("{\"tenantId\":\"%s\"}".formatted(tenantA)))
          .andExpect(status().isForbidden())
          .andExpect(jsonPath("$.code").value("account_scope_required"));
      assertThat(org.membershipTenants(victim)).containsExactly(tenantB);
      as(post("/api/users/{id}/deprovision", victim)).andExpect(status().isForbidden());
      assertThat(org.userStatus(victim)).isEqualTo("ACTIVE");
    }

    @Test
    void notOneselfForStatusChanges() throws Exception {
      as(post("/api/users/{id}/disable", tenantAdmin))
          .andExpect(status().isForbidden())
          .andExpect(jsonPath("$.code").value("account_scope_required"));
      as(patch("/api/users/{id}", tenantAdmin).contentType(MediaType.APPLICATION_JSON)
          .content("{\"displayName\":\"Me\"}")).andExpect(status().isOk());
    }

    private org.springframework.test.web.servlet.ResultActions as(MockHttpServletRequestBuilder request)
        throws Exception {
      return mvc.perform(request.header(AUTHORIZATION, bearer));
    }
  }

  private org.springframework.test.web.servlet.ResultActions perform(MockHttpServletRequestBuilder request)
      throws Exception {
    return mvc.perform(request.header(AUTHORIZATION, adminBearer));
  }

  private List<String> listIds(MockHttpServletRequestBuilder request, String bearer) throws Exception {
    JsonNode page = json.readTree(mvc.perform(request.header(AUTHORIZATION, bearer))
        .andExpect(status().isOk()).andReturn().getResponse().getContentAsString());
    List<String> ids = new ArrayList<>();
    page.get("items").forEach(item -> ids.add(item.get("id").asText()));
    return ids;
  }
}
