package com.acme.iam.common.jdbc;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

import com.acme.iam.assignment.AssignmentAdminService;
import com.acme.iam.common.test.Fixtures;
import com.acme.iam.common.test.IntegrationTest;
import com.acme.iam.common.test.OrgTestData;
import com.acme.iam.common.test.PostgresTestBase;
import com.acme.iam.product.RegistryService;
import com.acme.iam.role.RoleAdminService;
import com.acme.iam.user.MembershipService;
import com.acme.iam.user.UserAdminService;
import java.lang.reflect.Method;
import java.sql.SQLException;
import java.time.Duration;
import java.util.Arrays;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;
import org.awaitility.Awaitility;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.boot.test.system.CapturedOutput;
import org.springframework.boot.test.system.OutputCaptureExtension;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Import;
import org.springframework.dao.CannotAcquireLockException;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.jdbc.core.simple.JdbcClient;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.support.TransactionTemplate;

/**
 * Task 9 (deferred fix E2): {@link RetryOnDeadlock} re-runs a whole transaction that PostgreSQL aborted with a
 * deadlock. The deadlock is real: two transactions take two advisory locks in opposite order, PostgreSQL's deadlock
 * detector (after {@code deadlock_timeout}, 1 s) aborts one of them with SQLSTATE 40P01.
 */
@IntegrationTest
@Import(DeadlockRetryIT.Config.class)
@ExtendWith(OutputCaptureExtension.class)
class DeadlockRetryIT extends PostgresTestBase {

  @TestConfiguration
  static class Config {
    @Bean
    LockTaker lockTaker(JdbcClient jdbc) {
      return new LockTaker(jdbc);
    }
  }

  /** Test-only transactional service. */
  static class LockTaker {
    private final JdbcClient jdbc;
    private final AtomicInteger attempts = new AtomicInteger();

    public AtomicInteger attempts() {
      return attempts;
    }

    LockTaker(JdbcClient jdbc) {
      this.jdbc = jdbc;
    }

    @RetryOnDeadlock
    @Transactional
    public void lockBoth(long first, long second, CountDownLatch bothHoldTheirFirstLock) throws InterruptedException {
      attempts.incrementAndGet();
      jdbc.sql("SELECT pg_advisory_xact_lock(:k)").param("k", first).query().singleRow();
      bothHoldTheirFirstLock.countDown();
      bothHoldTheirFirstLock.await(10, TimeUnit.SECONDS);
      jdbc.sql("SELECT pg_advisory_xact_lock(:k)").param("k", second).query().singleRow();
    }

    @RetryOnDeadlock
    @Transactional
    public void alwaysDeadlocks() {
      attempts.incrementAndGet();
      throw new CannotAcquireLockException("forced", new SQLException("deadlock detected", "40P01"));
    }

    @RetryOnDeadlock
    @Transactional
    public void failsOtherwise() {
      attempts.incrementAndGet();
      throw new DataIntegrityViolationException("x", new SQLException("unique", "23505"));
    }
  }

  @Autowired LockTaker locks;
  @Autowired TransactionTemplate tx;
  @Autowired JdbcClient jdbc;
  @Autowired UserAdminService users;

  @Test
  void aRealDeadlockIsRetriedAndBothTransactionsCommit() throws Exception {
    locks.attempts().set(0);
    long a = System.nanoTime();
    long b = a + 1;
    CountDownLatch latch = new CountDownLatch(2);

    CompletableFuture<Void> one = CompletableFuture.runAsync(() -> call(() -> locks.lockBoth(a, b, latch)));
    CompletableFuture<Void> two = CompletableFuture.runAsync(() -> call(() -> locks.lockBoth(b, a, latch)));

    CompletableFuture.allOf(one, two).get(30, TimeUnit.SECONDS);
    assertThat(locks.attempts().get()).as("the deadlock victim ran a second time").isEqualTo(3);
  }

  /**
   * Fix round 1: the retry wiring on a production entry point. {@code UserAdminService.disable} takes the last-admin
   * advisory lock, then the target's row lock. A concurrent transaction holds that row lock and then asks for the
   * advisory lock: a real 40P01. The service started waiting first, so its deadlock check fires first and it is the
   * victim; {@code @RetryOnDeadlock} re-runs it after the other transaction commits, and the user ends DISABLED.
   */
  @Test
  void aRealEntryPointIsRetriedAfterADeadlock(CapturedOutput output) throws Exception {
    OrgTestData org = new OrgTestData(jdbc);
    Fixtures fx = org.fixtures();
    Fixtures.Scenario s = fx.scenario();
    UUID admin = org.accountAdmin(s.accountId(), s.tenantId());
    UUID target = s.userId();
    CountDownLatch rowLocked = new CountDownLatch(1);
    CountDownLatch serviceWaiting = new CountDownLatch(1);

    CompletableFuture<Void> other = CompletableFuture.runAsync(() -> tx.executeWithoutResult(t -> {
      jdbc.sql("SELECT 1 FROM app_user WHERE id = :id FOR UPDATE").param("id", target).query().singleRow();
      rowLocked.countDown();
      await(serviceWaiting);
      jdbc.sql("SELECT pg_advisory_xact_lock(hashtext('iam:last_admin'), hashtext(CAST(:a AS text)))")
          .param("a", s.accountId()).query().singleRow();
    }));
    await(rowLocked);
    CompletableFuture<String> disable = CompletableFuture.supplyAsync(() -> {
      Fixtures.actAs(admin, s.accountId(), s.tenantId());
      try {
        return users.disable(s.accountId(), target).status().name();
      } finally {
        Fixtures.clearActor();
      }
    });
    Awaitility.await().atMost(Duration.ofSeconds(10)).until(() -> jdbc.sql("""
        SELECT count(*) FROM pg_locks WHERE NOT granted AND locktype IN ('tuple', 'transactionid')""")
        .query(Long.class).single() > 0);
    serviceWaiting.countDown();

    other.get(30, TimeUnit.SECONDS);
    assertThat(disable.get(30, TimeUnit.SECONDS)).isEqualTo("DISABLED");
    assertThat(output.getOut()).contains("UserAdminService.disable(..) hit SQLSTATE 40P01 (attempt 1 of 3)");
  }

  private static void await(CountDownLatch latch) {
    try {
      if (!latch.await(20, TimeUnit.SECONDS)) {
        throw new IllegalStateException("latch timed out");
      }
    } catch (InterruptedException e) {
      Thread.currentThread().interrupt();
      throw new IllegalStateException(e);
    }
  }

  @Test
  void givesUpAfterThreeAttempts() {
    locks.attempts().set(0);
    assertThatThrownBy(locks::alwaysDeadlocks).isInstanceOf(CannotAcquireLockException.class);
    assertThat(locks.attempts().get()).isEqualTo(DeadlockRetryAspect.MAX_ATTEMPTS);
  }

  @Test
  void otherFailuresAreNotRetried() {
    locks.attempts().set(0);
    assertThatThrownBy(locks::failsOtherwise).isInstanceOf(DataIntegrityViolationException.class);
    assertThat(locks.attempts().get()).isEqualTo(1);
  }

  @Test
  void insideAnOuterTransactionOnlyTheOuterEntryPointMayRetry() {
    locks.attempts().set(0);
    assertThatThrownBy(() -> tx.executeWithoutResult(s -> locks.alwaysDeadlocks()))
        .isInstanceOf(CannotAcquireLockException.class);
    assertThat(locks.attempts().get()).isEqualTo(1);
  }

  @Test
  void serviceEntryPointsThatCanDeadlockAreAnnotated() {
    List<Class<?>> services = List.of(AssignmentAdminService.class, RoleAdminService.class, UserAdminService.class,
        MembershipService.class, RegistryService.class);
    List<String> expected = List.of(
        "AssignmentAdminService.assign", "AssignmentAdminService.revoke",
        "RoleAdminService.update", "RoleAdminService.setPermissions", "RoleAdminService.delete",
        "UserAdminService.disable", "UserAdminService.enable", "UserAdminService.deprovision",
        "UserAdminService.unlock", "RoleAdminService.create",
        "MembershipService.add", "MembershipService.remove", "MembershipService.changePrimary",
        "RegistryService.apply");
    List<String> annotated = services.stream().flatMap(c -> Arrays.stream(c.getDeclaredMethods()))
        .filter(m -> m.isAnnotationPresent(RetryOnDeadlock.class))
        .map(m -> m.getDeclaringClass().getSimpleName() + "." + m.getName())
        .distinct().toList();
    assertThat(annotated).containsExactlyInAnyOrderElementsOf(expected);
    for (Class<?> service : services) {
      for (Method m : service.getDeclaredMethods()) {
        if (m.isAnnotationPresent(RetryOnDeadlock.class)) {
          assertThat(m.isAnnotationPresent(Transactional.class)).as(m + " is a transaction entry point").isTrue();
        }
      }
    }
  }

  @Test
  void sqlStateIsFoundInTheCauseChain() {
    assertThat(DeadlockRetryAspect.retryableSqlState(
        new CannotAcquireLockException("x", new SQLException("d", "40P01")))).isEqualTo("40P01");
    assertThat(DeadlockRetryAspect.retryableSqlState(
        new IllegalStateException(new RuntimeException(new SQLException("s", "40001"))))).isEqualTo("40001");
    assertThat(DeadlockRetryAspect.retryableSqlState(new RuntimeException(new SQLException("u", "23505")))).isNull();
    assertThat(DeadlockRetryAspect.retryableSqlState(new RuntimeException("no sql"))).isNull();
  }

  private interface Body {
    void run() throws Exception;
  }

  private static void call(Body body) {
    try {
      body.run();
    } catch (RuntimeException e) {
      throw e;
    } catch (Exception e) {
      throw new IllegalStateException(e);
    }
  }
}
