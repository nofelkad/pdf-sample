package com.acme.iam.auth;

import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import com.acme.iam.common.test.PostgresTestBase;
import com.acme.iam.common.test.TestTokens;
import com.acme.iam.user.MembershipStatus;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.util.List;
import java.util.UUID;
import java.util.stream.Stream;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.simple.JdbcClient;
import org.springframework.test.web.servlet.MockMvc;

/** P1-5.9: {@code GET /api/me} (authenticated only, no permission required). */
@AuthIT
class MeIT extends PostgresTestBase {

  @Autowired MockMvc mvc;
  @Autowired ObjectMapper json;
  @Autowired JdbcClient jdbc;
  @Autowired PasswordService passwords;
  @Autowired TestTokens testTokens;

  AuthTestData data;
  AuthClient client;

  @BeforeEach
  void setUp() {
    data = new AuthTestData(jdbc, passwords);
    client = new AuthClient(mvc, json);
  }

  @Test
  void returnsProfileAccountActiveTenantMembershipsAndSortedTokenPermissions() throws Exception {
    AuthTestData.TestUser u = data.user();
    UUID second = data.fx.tenant(u.accountId());
    data.fx.membership(u.userId(), second, MembershipStatus.SUSPENDED);
    String p1 = data.grantTenantPermission(u.userId(), u.tenantId());
    String p2 = data.grantTenantPermission(u.userId(), u.tenantId());
    List<String> sorted = Stream.of(p1, p2).sorted().toList();
    AuthClient.Tokens tokens = client.loginOk(u.email(), u.password());

    client.me(tokens.bearer())
        .andExpect(status().isOk())
        .andExpect(jsonPath("$.user.id").value(u.userId().toString()))
        .andExpect(jsonPath("$.user.email").value(u.email()))
        .andExpect(jsonPath("$.user.displayName").isNotEmpty())
        .andExpect(jsonPath("$.user.status").value("ACTIVE"))
        .andExpect(jsonPath("$.account.id").value(u.accountId().toString()))
        .andExpect(jsonPath("$.account.slug").value(data.slug(u.accountId())))
        .andExpect(jsonPath("$.account.name").value(data.accountName(u.accountId())))
        .andExpect(jsonPath("$.activeTenant.id").value(u.tenantId().toString()))
        .andExpect(jsonPath("$.activeTenant.slug").isNotEmpty())
        .andExpect(jsonPath("$.memberships.length()").value(2))
        .andExpect(jsonPath("$.memberships[?(@.tenantId == '" + u.tenantId() + "')].primary").value(true))
        .andExpect(jsonPath("$.memberships[?(@.tenantId == '" + u.tenantId() + "')].status").value("ACTIVE"))
        .andExpect(jsonPath("$.memberships[?(@.tenantId == '" + second + "')].primary").value(false))
        .andExpect(jsonPath("$.memberships[?(@.tenantId == '" + second + "')].status").value("SUSPENDED"))
        .andExpect(jsonPath("$.memberships[0].name").isNotEmpty())
        .andExpect(jsonPath("$.permissions").value(org.hamcrest.Matchers.contains(sorted.toArray())));
  }

  @Test
  void permissionsComeFromTheTokenNotFromTheDatabase() throws Exception {
    AuthTestData.TestUser u = data.user();
    String bearer = testTokens.user(u.userId()).account(u.accountId()).tenant(u.tenantId())
        .perms("z.perm", "a.perm").bearer();

    client.me(bearer).andExpect(status().isOk())
        .andExpect(jsonPath("$.permissions").value(org.hamcrest.Matchers.contains("a.perm", "z.perm")));
  }

  @Test
  void requiresAnAccessToken() throws Exception {
    client.me(null).andExpect(status().isUnauthorized());
  }
}
