package com.acme.iam.security;

import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.http.HttpHeaders.AUTHORIZATION;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import com.acme.iam.assignment.PermissionResolver;
import com.acme.iam.assignment.ScopeType;
import com.acme.iam.common.test.Fixtures;
import com.acme.iam.common.test.IntegrationTest;
import com.acme.iam.common.test.PostgresTestBase;
import com.acme.iam.common.test.TestTokens;
import com.acme.iam.product.Product;
import com.acme.iam.user.MembershipStatus;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.util.HashSet;
import java.util.Set;
import java.util.UUID;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.jdbc.core.simple.JdbcClient;
import org.springframework.test.web.servlet.MockMvc;

/**
 * Task 9, the recurring defect class from the content side (the matrix only sees statuses): list endpoints answer a
 * TENANT-scope holder of an account-wide permission with the active tenant's slice only.
 */
@IntegrationTest
@AutoConfigureMockMvc
class TenantScopeVisibilityIT extends PostgresTestBase {

  @Autowired MockMvc mvc;
  @Autowired TestTokens tokens;
  @Autowired JdbcClient jdbc;
  @Autowired PermissionResolver resolver;
  @Autowired ObjectMapper json;

  Fixtures fx;
  UUID account;
  UUID t1;
  UUID t2;
  UUID inT1;
  UUID inT2;
  UUID inBoth;
  UUID role;

  @BeforeEach
  void world() {
    fx = new Fixtures(jdbc);
    account = fx.account();
    t1 = fx.tenant(account);
    t2 = fx.tenant(account);
    inT1 = fx.user(account, t1);
    inT2 = fx.user(account, t2);
    inBoth = fx.user(account, t1);
    fx.membership(inBoth, t2, MembershipStatus.ACTIVE);
    role = fx.customRole(Product.IAM_ID, account);
  }

  private String tenantScopedHolder(String permission) {
    UUID caller = fx.user(account, t1);
    fx.assign(caller, fx.customRole(Product.IAM_ID, account, fx.permission(Product.IAM_ID, permission)),
        ScopeType.TENANT, t1);
    return tokens.user(caller).account(account).tenant(t1)
        .perms(resolver.resolve(caller, t1).toArray(String[]::new)).bearer();
  }

  private JsonNode getJson(String path, String bearer) throws Exception {
    return json.readTree(mvc.perform(get(path).header(AUTHORIZATION, bearer)).andExpect(status().isOk())
        .andReturn().getResponse().getContentAsString());
  }

  private static Set<String> ids(JsonNode page, String field) {
    Set<String> ids = new HashSet<>();
    page.get("items").forEach(i -> ids.add(i.get(field).asText()));
    return ids;
  }

  @Test
  void assignmentsOfARoleAreLimitedToTheActiveTenant() throws Exception {
    UUID a1 = fx.assign(inT1, role, ScopeType.TENANT, t1);
    UUID a2 = fx.assign(inT2, role, ScopeType.TENANT, t2);
    UUID accountWideOfT2Member = fx.assign(inT2, role, ScopeType.ACCOUNT, account);
    UUID accountWideOfBoth = fx.assign(inBoth, role, ScopeType.ACCOUNT, account);

    Set<String> seen = ids(getJson("/api/roles/" + role + "/assignments", tenantScopedHolder("iam.role.assign")), "id");

    assertThat(seen).containsExactlyInAnyOrder(a1.toString(), accountWideOfBoth.toString())
        .doesNotContain(a2.toString(), accountWideOfT2Member.toString());
  }

  @Test
  void assignmentsOfAUserAreThoseThatApplyInTheActiveTenant() throws Exception {
    UUID inT1Grant = fx.assign(inBoth, role, ScopeType.TENANT, t1);
    UUID inT2Grant = fx.assign(inBoth, fx.customRole(Product.IAM_ID, account), ScopeType.TENANT, t2);
    UUID accountGrant = fx.assign(inBoth, fx.customRole(Product.IAM_ID, account), ScopeType.ACCOUNT, account);

    Set<String> seen = ids(getJson("/api/users/" + inBoth + "/assignments", tenantScopedHolder("iam.role.assign")),
        "id");

    assertThat(seen).containsExactlyInAnyOrder(inT1Grant.toString(), accountGrant.toString())
        .doesNotContain(inT2Grant.toString());
  }

  /**
   * Ruling R42: a TENANT-scope grant of {@code iam.user.read.account} (a {@code .account} DATA permission) grants
   * nothing, so it never reaches the token and the list is refused outright. The tenant slice comes from
   * {@code iam.user.read.tenant}.
   */
  @Test
  void aTenantScopeAccountReadGrantsNothingAndTheTenantReadSeesTheActiveTenantsMembers() throws Exception {
    mvc.perform(get("/api/users?limit=200").header(AUTHORIZATION, tenantScopedHolder("iam.user.read.account")))
        .andExpect(status().isForbidden());

    Set<String> seen = ids(getJson("/api/users?limit=200", tenantScopedHolder("iam.user.read.tenant")), "id");

    assertThat(seen).contains(inT1.toString(), inBoth.toString()).doesNotContain(inT2.toString());
  }
}
