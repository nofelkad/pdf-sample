package com.acme.iam.auth;

import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import com.acme.iam.account.AccountStatus;
import com.acme.iam.common.test.PostgresTestBase;
import com.acme.iam.core.Claims;
import com.acme.iam.user.TokenPurpose;
import com.acme.iam.user.UserTokenService;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.time.Duration;
import java.util.Map;
import java.util.UUID;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.simple.JdbcClient;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.security.oauth2.jwt.JwtDecoder;
import org.springframework.test.web.servlet.MockMvc;

/** {@code POST /auth/invitations/accept}: INVITE token → password → ACTIVE → logged in. */
@AuthIT
class InvitationAcceptIT extends PostgresTestBase {

  static final String PASSWORD = "Invited-Passphrase-123";

  @Autowired MockMvc mvc;
  @Autowired ObjectMapper json;
  @Autowired JdbcClient jdbc;
  @Autowired PasswordService passwords;
  @Autowired UserTokenService userTokens;
  @Autowired JwtDecoder jwtDecoder;

  AuthTestData data;
  AuthClient client;
  AuthTestData.TestUser admin;
  UUID invited;
  String email;

  @BeforeEach
  void setUp() {
    data = new AuthTestData(jdbc, passwords);
    client = new AuthClient(mvc, json);
    admin = data.user();
    invited = data.invitedUser(admin.accountId(), admin.tenantId());
    email = data.fx.email(invited);
  }

  @Test
  void acceptingActivatesTheUserSetsThePasswordAndLogsIn() throws Exception {
    String token = invite(invited);

    AuthClient.Tokens tokens = client.tokens(client.accept(token, PASSWORD, "Jane Invited")
        .andExpect(status().isOk())
        .andExpect(jsonPath("$.tokenType").value("Bearer"))
        .andExpect(jsonPath("$.activeTenantId").value(admin.tenantId().toString()))
        .andReturn());

    Map<String, Object> user = jdbc.sql("SELECT status, display_name, password_hash FROM app_user WHERE id = :id")
        .param("id", invited).query().singleRow();
    assertThat(user).containsEntry("status", "ACTIVE").containsEntry("display_name", "Jane Invited");
    assertThat(passwords.matches(PASSWORD, (String) user.get("password_hash"))).isTrue();
    Jwt jwt = jwtDecoder.decode(tokens.accessToken());
    assertThat(jwt.getSubject()).isEqualTo(invited.toString());
    assertThat(data.sessionByRefresh(tokens.refreshToken())).containsEntry("user_id", invited);
    assertThat(data.auditRows(client.lastRequestId(), "auth.invitation.accepted")).singleElement()
        .satisfies(row -> assertThat(row).containsEntry("outcome", "SUCCESS").containsEntry("actor_user_id", invited)
            .containsEntry("account_id", admin.accountId())
            .containsEntry("session_id", UUID.fromString(jwt.getClaimAsString(Claims.SESSION))));

    client.accept(token, PASSWORD, null).andExpect(status().isBadRequest())
        .andExpect(jsonPath("$.code").value("invalid_token"));
    client.login(email, PASSWORD).andExpect(status().isOk());
  }

  @Test
  void aPolicyViolationLeavesTheUserInvitedAndTheTokenUsable() throws Exception {
    String token = invite(invited);

    client.accept(token, "too-short", null).andExpect(status().isBadRequest())
        .andExpect(jsonPath("$.code").value("password_policy"));
    assertThat(data.auditOfRequest(client.lastRequestId()))
        .containsExactly("auth.invitation.accepted/FAILURE/ANONYMOUS");
    assertThat(userStatus(invited)).isEqualTo("INVITED");

    client.accept(token, PASSWORD, null).andExpect(status().isOk());
    assertThat(userStatus(invited)).isEqualTo("ACTIVE");
  }

  @Test
  void aResetTokenCannotAcceptAnInvitation() throws Exception {
    String token = userTokens.issue(invited, TokenPurpose.PASSWORD_RESET, Duration.ofMinutes(30), null).rawToken();

    client.accept(token, PASSWORD, null).andExpect(status().isBadRequest())
        .andExpect(jsonPath("$.code").value("invalid_token"));
  }

  @Test
  void anInviteForAnAlreadyActiveUserIsInvalid() throws Exception {
    String token = invite(admin.userId());

    client.accept(token, PASSWORD, null).andExpect(status().isBadRequest())
        .andExpect(jsonPath("$.code").value("invalid_token"));
    client.login(admin.email(), admin.password()).andExpect(status().isOk());
  }

  @Test
  void anInactiveAccountCannotAcceptAndTheUserStaysInvited() throws Exception {
    String token = invite(invited);
    data.fx.accountStatus(admin.accountId(), AccountStatus.SUSPENDED);

    client.accept(token, PASSWORD, null).andExpect(status().isForbidden())
        .andExpect(jsonPath("$.code").value("access_inactive"));
    assertThat(userStatus(invited)).isEqualTo("INVITED");
  }

  private String invite(UUID user) {
    return userTokens.issue(user, TokenPurpose.INVITE, Duration.ofDays(7), admin.userId()).rawToken();
  }

  private String userStatus(UUID user) {
    return jdbc.sql("SELECT status FROM app_user WHERE id = :id").param("id", user).query(String.class).single();
  }
}
