package com.acme.iam.product;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

import com.acme.iam.product.Manifest.ManifestPermission;
import com.acme.iam.product.Manifest.ManifestRole;
import java.io.ByteArrayInputStream;
import java.nio.charset.StandardCharsets;
import java.util.List;
import org.junit.jupiter.api.Test;

/** P1-7.1: manifest format and its validation rules. */
class ManifestValidatorTest {

  private static ManifestPermission perm(String code, String kind) {
    return new ManifestPermission(code, kind, "d", false, false);
  }

  private static Manifest billing(ManifestPermission... perms) {
    return new Manifest("BILLING", "Billing", List.of(perms), List.of());
  }

  @Test
  void aWellFormedManifestHasNoViolations() {
    Manifest m = new Manifest("BILLING", null, List.of(
        perm("billing.invoice.approve", "FEATURE"),
        perm("billing.invoice.read.tenant", "DATA"),
        perm("billing.invoice.read.own", "DATA"),
        perm("billing.invoice.read.account", "DATA")),
        List.of(new ManifestRole("Billing Admin", List.of("billing.*"), List.of("billing.invoice.read.own")),
            new ManifestRole("Approver", List.of("billing.invoice.approve"), List.of())));

    assertThat(ManifestValidator.validate(m)).isEmpty();
  }

  @Test
  void duplicateCodesAreReported() {
    assertThat(ManifestValidator.validate(billing(perm("billing.a.b", "FEATURE"), perm("billing.a.b", "FEATURE"))))
        .anyMatch(v -> v.contains("duplicate") && v.contains("billing.a.b"));
  }

  @Test
  void aCodeOutsideTheProductNamespaceIsReported() {
    assertThat(ManifestValidator.validate(billing(perm("crm.contact.read", "FEATURE"))))
        .anyMatch(v -> v.contains("crm.contact.read") && v.contains("billing."));
  }

  @Test
  void unknownKindIsReported() {
    assertThat(ManifestValidator.validate(billing(perm("billing.a.b", "WIDGET"), perm("billing.c.d", null))))
        .anyMatch(v -> v.contains("billing.a.b") && v.contains("kind"))
        .anyMatch(v -> v.contains("billing.c.d") && v.contains("kind"));
  }

  @Test
  void dataPermissionsNeedAScopeSuffix() {
    assertThat(ManifestValidator.validate(billing(
        perm("billing.invoice.read", "DATA"),
        perm("billing.invoice.read.tenant", "DATA"),
        perm("billing.invoice.list.own", "DATA"),
        perm("billing.invoice.sum.account", "DATA"))))
        .singleElement().satisfies(v -> assertThat(v).contains("billing.invoice.read").contains(".own"));
  }

  @Test
  void aFeaturePermissionNeedsNoScopeSuffix() {
    assertThat(ManifestValidator.validate(billing(perm("billing.invoice.read", "FEATURE")))).isEmpty();
  }

  @Test
  void malformedCodeProductAndDescriptionAreReported() {
    Manifest m = new Manifest("billing", null,
        List.of(new ManifestPermission("Billing.X", "FEATURE", " ", false, false)), List.of());
    assertThat(ManifestValidator.validate(m)).anyMatch(v -> v.contains("product"));
    Manifest m2 = new Manifest("BILLING", null,
        List.of(new ManifestPermission("billing.Bad Code", "FEATURE", null, false, false)), List.of());
    assertThat(ManifestValidator.validate(m2)).anyMatch(v -> v.contains("billing.Bad Code"))
        .anyMatch(v -> v.contains("description"));
  }

  @Test
  void roleReferencesAreChecked() {
    Manifest m = new Manifest("BILLING", null, List.of(perm("billing.a.b", "FEATURE")), List.of(
        new ManifestRole("R1", List.of("billing.missing"), List.of()),        // exact code not declared
        new ManifestRole("R2", List.of("iam.*"), List.of()),                  // foreign namespace
        new ManifestRole("R3", List.of("bill*", "*", ".*"), List.of()),       // malformed wildcards
        new ManifestRole("r1", List.of("billing.a.b"), List.of("iam.user.manage")), // duplicate name, foreign exclude
        new ManifestRole(" ", List.of(), List.of())));                        // blank name
    List<String> violations = ManifestValidator.validate(m);

    assertThat(violations)
        .anyMatch(v -> v.contains("R1") && v.contains("billing.missing"))
        .anyMatch(v -> v.contains("R2") && v.contains("iam.*"))
        .anyMatch(v -> v.contains("R3") && v.contains("bill*"))
        .anyMatch(v -> v.contains("R3") && v.contains("'*'"))
        .anyMatch(v -> v.contains("R3") && v.contains("'.*'"))
        .anyMatch(v -> v.contains("duplicate") && v.contains("r1"))
        .anyMatch(v -> v.contains("iam.user.manage"))
        .anyMatch(v -> v.contains("name"));
  }

  @Test
  void iamMayAlsoUsePlatformCodesButNobodyElseMayClaimPlatformOrIam() {
    Manifest iam = new Manifest("IAM", null, List.of(perm("platform.account.manage", "FEATURE"),
        perm("iam.user.manage", "FEATURE")),
        List.of(new ManifestRole("Platform Admin", List.of("platform.*", "iam.*"), List.of("platform.x"))));
    assertThat(ManifestValidator.validate(iam)).isEmpty();

    assertThat(ManifestValidator.validate(new Manifest("PLATFORM", null, List.of(), List.of())))
        .anyMatch(v -> v.contains("reserved"));
    assertThat(ManifestValidator.validate(billing(perm("platform.account.manage", "FEATURE"))))
        .anyMatch(v -> v.contains("platform.account.manage"));
  }

  @Test
  void oversizedManifestsAreRejectedWithASingleViolationPerLimit() {
    List<ManifestPermission> many = new java.util.ArrayList<>();
    for (int i = 0; i <= ManifestValidator.MAX_PERMISSIONS; i++) {
      many.add(perm("billing.p" + i + ".x", "FEATURE"));
    }
    List<ManifestRole> roles = new java.util.ArrayList<>();
    for (int i = 0; i <= ManifestValidator.MAX_SYSTEM_ROLES; i++) {
      roles.add(new ManifestRole("R" + i, List.of(), List.of()));
    }

    assertThat(ManifestValidator.validate(new Manifest("BILLING", null, many, List.of())))
        .singleElement().satisfies(v -> assertThat(v).contains("at most 2000 permissions"));
    assertThat(ManifestValidator.validate(new Manifest("BILLING", null, List.of(), roles)))
        .singleElement().satisfies(v -> assertThat(v).contains("at most 200 system roles"));
    assertThat(ManifestValidator.validate(new Manifest("BILLING", null,
        many.subList(0, ManifestValidator.MAX_PERMISSIONS), roles.subList(0, ManifestValidator.MAX_SYSTEM_ROLES))))
        .isEmpty();
  }

  @Test
  void requireValidThrowsInvalidManifestWithAllViolations() {
    assertThatThrownBy(() -> ManifestValidator.requireValid(
        billing(perm("billing.a.b", "X"), perm("crm.c.d", "FEATURE"))))
        .isInstanceOfSatisfying(InvalidManifestException.class, e -> {
          assertThat(e.code()).isEqualTo("invalid_manifest");
          assertThat(e.violations()).hasSize(2);
          assertThat(e.properties()).containsKey("violations");
        });
  }

  @Test
  void yamlAndJsonBindTheSameFieldNames() {
    String yaml = """
        product: BILLING
        name: Billing
        permissions:
          - { code: billing.invoice.approve, kind: FEATURE, description: Approve, sensitive: true }
          - { code: billing.invoice.export, kind: FEATURE, description: Export, audit_read: true }
        system_roles:
          - { name: Billing Admin, permissions: [ "billing.*" ], exclude: [ billing.invoice.export ] }
        """;
    String json = """
        {"product":"BILLING","name":"Billing","permissions":[
          {"code":"billing.invoice.approve","kind":"FEATURE","description":"Approve","sensitive":true},
          {"code":"billing.invoice.export","kind":"FEATURE","description":"Export","audit_read":true}],
         "system_roles":[{"name":"Billing Admin","permissions":["billing.*"],"exclude":["billing.invoice.export"]}]}""";

    Manifest fromYaml = ManifestParser.parseYaml(new ByteArrayInputStream(yaml.getBytes(StandardCharsets.UTF_8)));
    Manifest fromJson = ManifestParser.parseJson(json);

    assertThat(fromYaml).isEqualTo(fromJson);
    assertThat(fromJson.permissions().get(0).sensitive()).isTrue();
    assertThat(fromJson.permissions().get(1).auditRead()).isTrue();
    assertThat(fromJson.systemRoles()).singleElement().satisfies(r -> {
      assertThat(r.permissions()).containsExactly("billing.*");
      assertThat(r.exclude()).containsExactly("billing.invoice.export");
    });
    assertThat(ManifestValidator.validate(fromJson)).isEmpty();
  }

  @Test
  void malformedOrUnknownFieldsAreInvalidManifests() {
    assertThatThrownBy(() -> ManifestParser.parseJson("{\"product\":\"BILLING\",\"sytem_roles\":[]}"))
        .isInstanceOfSatisfying(InvalidManifestException.class,
            e -> assertThat(e.violations()).singleElement().satisfies(v -> assertThat(v).contains("sytem_roles")));
    assertThatThrownBy(() -> ManifestParser.parseJson("{not json"))
        .isInstanceOf(InvalidManifestException.class);
    assertThatThrownBy(() -> ManifestParser.parseJson("{\"permissions\":[{\"code\":\"x\",\"sensitive\":\"maybe\"}]}"))
        .isInstanceOf(InvalidManifestException.class);
  }
}
