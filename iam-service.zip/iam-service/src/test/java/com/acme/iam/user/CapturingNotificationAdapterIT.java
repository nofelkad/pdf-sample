package com.acme.iam.user;

import static org.assertj.core.api.Assertions.assertThat;

import com.acme.iam.common.test.CapturingNotificationAdapter;
import com.acme.iam.common.test.IntegrationTest;
import com.acme.iam.common.test.PostgresTestBase;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Import;

/** The test-only capturing adapter replaces the default port in a full context and records raw tokens. */
@IntegrationTest
@Import(CapturingNotificationAdapter.Config.class)
class CapturingNotificationAdapterIT extends PostgresTestBase {

  @Autowired NotificationPort port;
  @Autowired CapturingNotificationAdapter mailbox;

  @Test
  void capturesTokensForEndToEndTests() {
    mailbox.clear();
    port.sendInvitation("Jane@Example.test", "Acme", "invite-token");
    port.sendPasswordReset("jane@example.test", "reset-token");

    assertThat(port).isSameAs(mailbox);
    assertThat(mailbox.lastInvitationToken("jane@example.test")).isEqualTo("invite-token");
    assertThat(mailbox.lastPasswordResetToken("JANE@example.test")).isEqualTo("reset-token");
    assertThat(mailbox.sent()).hasSize(2);
  }
}
