package com.acme.iam.audit;

import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.http.HttpHeaders.AUTHORIZATION;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.patch;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;

import com.acme.iam.account.Account;
import com.acme.iam.assignment.PermissionResolver;
import com.acme.iam.assignment.ScopeType;
import com.acme.iam.common.Ids;
import com.acme.iam.common.test.CapturingNotificationAdapter;
import com.acme.iam.common.test.Fixtures;
import com.acme.iam.common.test.IntegrationTest;
import com.acme.iam.common.test.OrgTestData;
import com.acme.iam.common.test.PostgresTestBase;
import com.acme.iam.common.test.TestTokens;
import com.acme.iam.product.Product;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.context.annotation.Import;
import org.springframework.http.MediaType;
import org.springframework.jdbc.core.simple.JdbcClient;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;

/**
 * Final review C1: audit rows carry the account and tenant of the <b>affected resource</b>, not those of the actor's
 * token, so tenant-scoped audit search (ruling R25) shows each tenant its own changes and an account's auditors see
 * what platform operators did to it.
 */
@IntegrationTest
@AutoConfigureMockMvc
@Import(CapturingNotificationAdapter.Config.class)
class AuditAttributionIT extends PostgresTestBase {

  @Autowired MockMvc mvc;
  @Autowired TestTokens tokens;
  @Autowired JdbcClient jdbc;
  @Autowired ObjectMapper json;
  @Autowired PermissionResolver resolver;

  OrgTestData org;
  Fixtures fx;
  Instant start;

  @BeforeEach
  void setUp() {
    AuditTestData.ensureRecentPartitions();
    org = new OrgTestData(jdbc);
    fx = org.fixtures();
    start = Instant.now().minusSeconds(5).truncatedTo(ChronoUnit.SECONDS);
  }

  // ------------------------------------------------------------------------- scenario 1: another tenant

  /** An Account Admin active in T2 invites a user into T3: the rows belong to T3, not T2. */
  @Test
  void anInvitationIntoAnotherTenantIsAuditedInThatTenant() throws Exception {
    UUID account = fx.account();
    UUID t2 = fx.tenant(account);
    UUID t3 = fx.tenant(account);
    UUID admin = org.accountAdmin(account, t2);
    UUID tenantAdminRole = org.tenantAdminRole();

    JsonNode invited = body(mvc.perform(json(post("/api/tenants/{t}/users", t3), """
            {"email":"c1-%s@example.test","roles":[{"roleId":"%s","scopeType":"TENANT"}]}"""
            .formatted(Ids.newId(), tenantAdminRole))
        .header(AUTHORIZATION, bearer(admin, account, t2))), 201);
    UUID user = UUID.fromString(invited.at("/user/id").asText());
    UUID assignment = UUID.fromString(invited.at("/assignmentIds/0").asText());

    assertThat(stamp("iam.app_user.insert", user.toString())).containsExactly(account, t3);
    assertThat(stamp("iam.user_tenant_membership.insert", user + ":" + t3)).containsExactly(account, t3);
    assertThat(stamp("iam.role_assignment.insert", assignment.toString())).containsExactly(account, t3);

    // R25 tenant-scoped audit search: T3's Tenant Admin sees the invitation, T2's does not
    String t3Admin = tenantAdmin(account, t3, tenantAdminRole);
    String t2Admin = tenantAdmin(account, t2, tenantAdminRole);
    assertThat(actions(search(t3Admin, "&targetType=app_user&targetId=" + user)))
        .as("R46: the returned activation link is audited in the invited tenant too")
        .containsExactlyInAnyOrder("iam.app_user.insert", "iam.invitation.link_issued");
    assertThat(search(t2Admin, "&targetType=app_user&targetId=" + user)).isEmpty();
    assertThat(actions(search(t3Admin, "&targetType=role_assignment&targetId=" + assignment)))
        .containsExactly("iam.role_assignment.insert");
    assertThat(search(t2Admin, "&targetType=role_assignment&targetId=" + assignment)).isEmpty();
  }

  /** A force logout by an Account Admin active in T2 of a user who lives in T3 is the user's (T3's) event. */
  @Test
  void aForceLogoutIsAuditedWithTheTargetUsersTenant() throws Exception {
    UUID account = fx.account();
    UUID t2 = fx.tenant(account);
    UUID t3 = fx.tenant(account);
    UUID admin = org.accountAdmin(account, t2);
    UUID user = fx.user(account, t3);

    body(mvc.perform(post("/api/users/{id}/sessions/revoke", user).header(AUTHORIZATION, bearer(admin, account, t2))),
        200);

    assertThat(stamp("auth.sessions.force_logout", user.toString())).containsExactly(account, t3);
    assertThat(stamp("auth.sessions.revoked", user.toString())).containsExactly(account, t3);
  }

  /** Rows the row itself cannot place in a tenant (an ACCOUNT-scope grant) fall back to the actor's tenant. */
  @Test
  void anAccountLevelRowFallsBackToTheActorsTenantInsideTheActorsAccount() throws Exception {
    UUID account = fx.account();
    UUID t2 = fx.tenant(account);
    UUID admin = org.accountAdmin(account, t2);
    UUID user = fx.user(account, t2);
    UUID role = fx.customRole(Product.IAM_ID, account, fx.permission(Product.IAM_ID, "iam.user.read.tenant"));

    JsonNode created = body(mvc.perform(json(post("/api/users/{id}/assignments", user),
            "{\"roleId\":\"%s\",\"scopeType\":\"ACCOUNT\",\"scopeId\":\"%s\"}".formatted(role, account))
        .header(AUTHORIZATION, bearer(admin, account, t2))), 201);

    assertThat(stamp("iam.role_assignment.insert", created.get("id").asText())).containsExactly(account, t2);
  }

  // ------------------------------------------------------------------------- scenario 2: another account

  /** Platform operations on customer account X are X's events, visible to X's auditors and to accountId=X. */
  @Test
  void platformOperationsOnAnAccountAreAuditedInThatAccount() throws Exception {
    OrgTestData.Operator operator = org.platformOperator();
    org.accountAdminRole();
    String platform = org.bearer(tokens, operator.userId(), Account.PLATFORM_ID, operator.tenantId(),
        OrgTestData.PLATFORM_PERMISSION, "iam.audit.read");
    String slug = "c1-" + Ids.newId().toString().substring(24);

    JsonNode created = body(mvc.perform(json(post("/api/platform/accounts"),
            ("{\"name\":\"C1\",\"slug\":\"%s\",\"defaultTenant\":{\"name\":\"HQ\",\"slug\":\"hq\"},"
                + "\"defaultUser\":{\"email\":\"admin-%s@example.test\"}}").formatted(slug, slug))
        .header(AUTHORIZATION, platform)), 201);
    UUID x = UUID.fromString(created.at("/account/id").asText());
    UUID defaultTenant = UUID.fromString(created.at("/defaultTenant/id").asText());
    UUID bootstrapAdmin = UUID.fromString(created.at("/defaultUser/id").asText());
    UUID product = fx.product();
    String code = jdbc.sql("SELECT code FROM product WHERE id = :id").param("id", product).query(String.class).single();
    body(mvc.perform(json(put("/api/platform/accounts/{id}/products", x),
            "{\"products\":[{\"code\":\"%s\",\"status\":\"ACTIVE\",\"startsAt\":\"2026-01-01\"}]}".formatted(code))
        .header(AUTHORIZATION, platform)), 200);
    body(mvc.perform(json(patch("/api/platform/accounts/{id}", x), "{\"name\":\"C1 renamed\"}")
        .header(AUTHORIZATION, platform)), 200);
    body(mvc.perform(post("/api/platform/accounts/{id}/suspend", x).header(AUTHORIZATION, platform)), 200);

    assertThat(stamp("iam.account.insert", x.toString())).containsExactly(x, null);
    assertThat(stamp("iam.tenant.insert", defaultTenant.toString())).containsExactly(x, defaultTenant);
    assertThat(stamp("iam.app_user.insert", bootstrapAdmin.toString())).containsExactly(x, defaultTenant);
    UUID grant = jdbc.sql("SELECT id FROM role_assignment WHERE user_id = :u").param("u", bootstrapAdmin)
        .query(UUID.class).single();
    assertThat(stamp("iam.role_assignment.insert", grant.toString())).containsExactly(x, null);
    assertThat(stampsOf("iam.account_product.insert", x + ":" + product)).isNotEmpty().allSatisfy(s ->
        assertThat(s).containsExactly(x, null));
    assertThat(stampsOf("iam.account.update", x.toString())).isNotEmpty().allSatisfy(s ->
        assertThat(s).containsExactly(x, null));
    assertThat(stamp("auth.sessions.revoked", bootstrapAdmin.toString())).containsExactly(x, defaultTenant);
    assertThat(jdbc.sql("""
            SELECT count(*) FROM audit_event WHERE occurred_at >= :from AND account_id = :p
              AND (target_id = :x OR target_id LIKE :xp)""")
        .param("from", start.atOffset(java.time.ZoneOffset.UTC)).param("p", Account.PLATFORM_ID)
        .param("x", x.toString()).param("xp", x + ":%").query(Long.class).single())
        .as("nothing about X is filed under the PLATFORM account").isZero();

    // X's own account-scope auditor sees the platform's changes ...
    UUID auditor = fx.user(x, defaultTenant);
    fx.assign(auditor, fx.customRole(Product.IAM_ID, x, fx.permission(Product.IAM_ID, "iam.audit.read")),
        ScopeType.ACCOUNT, x);
    String auditorBearer = tokens.user(auditor).account(x).tenant(defaultTenant).perms("iam.audit.read").bearer();
    assertThat(actions(search(auditorBearer, "&targetType=account&targetId=" + x)))
        .contains("iam.account.insert", "iam.account.update");
    // ... and so does a platform search filtered by accountId=X
    assertThat(actions(search(platform, "&accountId=" + x + "&targetType=account&targetId=" + x)))
        .contains("iam.account.insert", "iam.account.update");
    assertThat(actions(search(platform, "&accountId=" + x + "&targetType=app_user&targetId=" + bootstrapAdmin)))
        .contains("iam.app_user.insert", "auth.sessions.revoked");
  }

  /** The platform force logout of every user of account X is X's event. */
  @Test
  void aPlatformAccountForceLogoutIsAuditedInTheTargetAccount() throws Exception {
    OrgTestData.Operator operator = org.platformOperator();
    String platform = org.platformBearer(tokens, operator);
    UUID x = fx.account();
    UUID tenant = fx.tenant(x);
    fx.user(x, tenant);
    fx.user(x, tenant);

    body(mvc.perform(post("/api/platform/accounts/{id}/sessions/revoke", x).header(AUTHORIZATION, platform)), 200);

    assertThat(stamp("auth.sessions.force_logout", x.toString())).containsExactly(x, null);
    assertThat(stamp("auth.sessions.revoked", "account", x.toString())).containsExactly(x, null);
  }

  // ------------------------------------------------------------------------------------------ helpers

  private String bearer(UUID user, UUID account, UUID tenant) {
    return tokens.user(user).account(account).tenant(tenant)
        .perms(resolver.resolve(user, tenant).toArray(String[]::new)).bearer();
  }

  /** A Tenant Admin of {@code tenant} (TENANT-scope assignment), as a bearer active in that tenant. */
  private String tenantAdmin(UUID account, UUID tenant, UUID tenantAdminRole) {
    UUID user = fx.user(account, tenant);
    fx.assign(user, tenantAdminRole, ScopeType.TENANT, tenant);
    return bearer(user, account, tenant);
  }

  /** {@code [account_id, tenant_id]} of the single event with this action and target id. */
  private List<UUID> stamp(String action, String targetId) {
    List<List<UUID>> stamps = stampsOf(action, targetId);
    assertThat(stamps).as(action + " " + targetId).hasSize(1);
    return stamps.get(0);
  }

  private List<UUID> stamp(String action, String targetType, String targetId) {
    List<List<UUID>> stamps = jdbc.sql("""
            SELECT account_id, tenant_id FROM audit_event
            WHERE occurred_at >= :from AND action = :a AND target_type = :tt AND target_id = :t""")
        .param("from", start.atOffset(java.time.ZoneOffset.UTC)).param("a", action).param("tt", targetType)
        .param("t", targetId)
        .query((rs, i) -> pair(rs.getObject("account_id", UUID.class), rs.getObject("tenant_id", UUID.class))).list();
    assertThat(stamps).as(action + " " + targetType + " " + targetId).hasSize(1);
    return stamps.get(0);
  }

  private List<List<UUID>> stampsOf(String action, String targetId) {
    return jdbc.sql("""
            SELECT account_id, tenant_id FROM audit_event
            WHERE occurred_at >= :from AND action = :a AND target_id = :t""")
        .param("from", start.atOffset(java.time.ZoneOffset.UTC)).param("a", action).param("t", targetId)
        .query((rs, i) -> pair(rs.getObject("account_id", UUID.class), rs.getObject("tenant_id", UUID.class))).list();
  }

  private static List<UUID> pair(UUID a, UUID b) {
    List<UUID> pair = new ArrayList<>();
    pair.add(a);
    pair.add(b);
    return pair;
  }

  private JsonNode search(String bearer, String extra) throws Exception {
    String query = "?from=" + start + "&to=" + Instant.now().plusSeconds(60).truncatedTo(ChronoUnit.SECONDS) + extra;
    return body(mvc.perform(get("/api/audit/events" + query).header(AUTHORIZATION, bearer)), 200).get("items");
  }

  private static List<String> actions(JsonNode items) {
    List<String> actions = new ArrayList<>();
    items.forEach(n -> actions.add(n.get("action").asText()));
    return actions;
  }

  private JsonNode body(org.springframework.test.web.servlet.ResultActions result, int status) throws Exception {
    var response = result.andReturn().getResponse();
    assertThat(response.getStatus()).as(response.getContentAsString()).isEqualTo(status);
    String content = response.getContentAsString();
    return content.isEmpty() ? json.createObjectNode() : json.readTree(content);
  }

  private static MockHttpServletRequestBuilder json(MockHttpServletRequestBuilder request, String body) {
    return request.contentType(MediaType.APPLICATION_JSON).content(body);
  }
}
