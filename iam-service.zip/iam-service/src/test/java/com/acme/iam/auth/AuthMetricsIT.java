package com.acme.iam.auth;

import static org.assertj.core.api.Assertions.assertThat;

import com.acme.iam.audit.AuditEvent;
import com.acme.iam.audit.AuditEvent.Outcome;
import com.acme.iam.audit.AuditWriter;
import com.acme.iam.common.test.PostgresTestBase;
import com.acme.iam.observability.MetricNames;
import com.acme.iam.user.MembershipStatus;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.micrometer.core.instrument.Counter;
import io.micrometer.core.instrument.MeterRegistry;
import io.micrometer.core.instrument.Timer;
import java.util.UUID;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.simple.JdbcClient;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.support.TransactionTemplate;

/**
 * P1-11.5: login, lockout, refresh and tenant-switch meters, fed by the real flows. Counters are asserted as deltas
 * because the registry is shared by every test of the cached context.
 */
@AuthIT
class AuthMetricsIT extends PostgresTestBase {

  @Autowired MockMvc mvc;
  @Autowired ObjectMapper json;
  @Autowired JdbcClient jdbc;
  @Autowired PasswordService passwords;
  @Autowired MeterRegistry meters;
  @Autowired AuditWriter auditWriter;
  @Autowired PlatformTransactionManager transactionManager;

  AuthTestData data;
  AuthClient client;

  @BeforeEach
  void setUp() {
    data = new AuthTestData(jdbc, passwords);
    client = new AuthClient(mvc, json);
  }

  @Test
  void aSuccessfulLoginIsCountedWithOutcomeSuccess() throws Exception {
    AuthTestData.TestUser u = data.user();
    double before = logins("success", "ok");

    client.loginOk(u.email(), u.password());

    assertThat(logins("success", "ok")).isEqualTo(before + 1);
  }

  @Test
  void failedLoginsAreCountedByReason() throws Exception {
    AuthTestData.TestUser u = data.user();
    double wrong = logins("failure", "invalid_password");
    double unknown = logins("failure", "unknown_user");

    client.login(u.email(), "Wrong-Password-1!");
    client.login("nobody-" + UUID.randomUUID() + "@example.test", "Wrong-Password-1!");

    assertThat(logins("failure", "invalid_password")).isEqualTo(wrong + 1);
    assertThat(logins("failure", "unknown_user")).isEqualTo(unknown + 1);
  }

  @Test
  void theFailureThatAppliesTheLockIsCountedAsALockout() throws Exception {
    AuthTestData.TestUser u = data.user();
    double lockouts = counter(MetricNames.AUTH_LOCKOUTS);

    for (int i = 0; i < 4; i++) { // iam.auth.lockout.max-attempts = 5
      client.login(u.email(), "Wrong-Password-1!");
    }
    assertThat(counter(MetricNames.AUTH_LOCKOUTS)).isEqualTo(lockouts);
    client.login(u.email(), "Wrong-Password-1!");

    assertThat(counter(MetricNames.AUTH_LOCKOUTS)).isEqualTo(lockouts + 1);
  }

  @Test
  void aLoginAgainstALockedUserIsCountedAsLockedNotAsANewLockout() throws Exception {
    AuthTestData.TestUser u = data.user();
    jdbc.sql("UPDATE app_user SET locked_until = now() + interval '15 minutes' WHERE id = :id")
        .param("id", u.userId()).update();
    double lockouts = counter(MetricNames.AUTH_LOCKOUTS);
    double locked = logins("failure", "locked");

    client.login(u.email(), u.password()); // right password, but locked

    assertThat(logins("failure", "locked")).isEqualTo(locked + 1);
    assertThat(counter(MetricNames.AUTH_LOCKOUTS)).isEqualTo(lockouts);
  }

  @Test
  void aRolledBackLoginAuditEventIsNotCounted() {
    // the counters follow committed audit events only: nothing is counted for a transaction that rolls back
    double before = logins("failure", "unknown_user");
    new TransactionTemplate(transactionManager).executeWithoutResult(status -> {
      auditWriter.write(AuditEvent.builder(AuthAuditService.LOGIN_FAILED).anonymous().outcome(Outcome.FAILURE)
          .metadata("reason", "unknown_user").build());
      status.setRollbackOnly();
    });
    assertThat(logins("failure", "unknown_user")).isEqualTo(before);

    new TransactionTemplate(transactionManager).executeWithoutResult(status ->
        auditWriter.write(AuditEvent.builder(AuthAuditService.LOGIN_FAILED).anonymous().outcome(Outcome.FAILURE)
            .metadata("reason", "unknown_user").build()));
    assertThat(logins("failure", "unknown_user")).isEqualTo(before + 1);
  }

  @Test
  void aReasonOutsideTheKnownListIsCountedAsOtherAndNeverBecomesATag() {
    double other = logins("failure", "other");

    new TransactionTemplate(transactionManager).executeWithoutResult(status ->
        auditWriter.write(AuditEvent.builder(AuthAuditService.LOGIN_FAILED).anonymous().outcome(Outcome.FAILURE)
            .metadata("reason", "made_up_reason_" + UUID.randomUUID().toString().replace('-', '_')).build()));
    new TransactionTemplate(transactionManager).executeWithoutResult(status ->
        auditWriter.write(AuditEvent.builder(AuthAuditService.LOGIN_FAILED).anonymous().outcome(Outcome.FAILURE).build()));

    assertThat(logins("failure", "other")).isEqualTo(other + 2);
    assertThat(meters.find(MetricNames.AUTH_LOGINS).counters())
        .extracting(c -> c.getId().getTag("reason"))
        .noneMatch(reason -> reason != null && reason.startsWith("made_up_reason"));
  }

  @Test
  void loginRefreshAndTenantSwitchLatencyAreTimedWithPercentiles() throws Exception {
    AuthTestData.TestUser u = data.user();
    UUID second = data.fx.tenant(u.accountId());
    data.fx.membership(u.userId(), second, MembershipStatus.ACTIVE);
    long loginCount = timerCount(MetricNames.AUTH_LOGIN_DURATION, "success");
    long refreshCount = timerCount(MetricNames.AUTH_REFRESH_DURATION, "success");
    long switchCount = timerCount(MetricNames.AUTH_TENANT_SWITCH_DURATION, "success");

    AuthClient.Tokens tokens = client.loginOk(u.email(), u.password());
    AuthClient.Tokens refreshed = client.tokens(client.refresh(tokens.refreshToken()).andReturn());
    client.tokens(client.switchTenant(refreshed.bearer(), second).andReturn());

    assertThat(timerCount(MetricNames.AUTH_LOGIN_DURATION, "success")).isEqualTo(loginCount + 1);
    assertThat(timerCount(MetricNames.AUTH_REFRESH_DURATION, "success")).isEqualTo(refreshCount + 1);
    assertThat(timerCount(MetricNames.AUTH_TENANT_SWITCH_DURATION, "success")).isEqualTo(switchCount + 1);
    Timer refresh = meters.get(MetricNames.AUTH_REFRESH_DURATION).tag("outcome", "success").timer();
    assertThat(refresh.takeSnapshot().percentileValues()).extracting(v -> v.percentile())
        .containsExactly(0.5, 0.95, 0.99);
  }

  @Test
  void failedRefreshesAreTimedAsErrorsAndReuseOfARotatedTokenIsCounted() throws Exception {
    AuthTestData.TestUser u = data.user();
    AuthClient.Tokens tokens = client.loginOk(u.email(), u.password());
    long errors = timerCount(MetricNames.AUTH_REFRESH_DURATION, "error");
    double reuse = counter(MetricNames.AUTH_REFRESH_REUSE_DETECTED);

    client.tokens(client.refresh(tokens.refreshToken()).andReturn());
    client.refresh(tokens.refreshToken()); // the rotated-out token again: reuse, 401

    assertThat(counter(MetricNames.AUTH_REFRESH_REUSE_DETECTED)).isEqualTo(reuse + 1);
    assertThat(timerCount(MetricNames.AUTH_REFRESH_DURATION, "error")).isEqualTo(errors + 1);
  }

  // ------------------------------------------------------------------------------------------------ helpers

  private double logins(String outcome, String reason) {
    Counter c = meters.find(MetricNames.AUTH_LOGINS).tags("outcome", outcome, "reason", reason).counter();
    return c == null ? 0 : c.count();
  }

  private double counter(String name) {
    Counter c = meters.find(name).counter();
    return c == null ? 0 : c.count();
  }

  private long timerCount(String name, String outcome) {
    Timer t = meters.find(name).tag("outcome", outcome).timer();
    return t == null ? 0 : t.count();
  }
}
