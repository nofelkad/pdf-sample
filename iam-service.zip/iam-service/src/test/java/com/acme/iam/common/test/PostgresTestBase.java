package com.acme.iam.common.test;

import javax.sql.DataSource;
import org.springframework.jdbc.datasource.SimpleDriverDataSource;
import org.springframework.test.context.DynamicPropertyRegistry;
import org.springframework.test.context.DynamicPropertySource;
import org.testcontainers.containers.PostgreSQLContainer;
import org.testcontainers.utility.DockerImageName;

/**
 * Base class for every test that needs PostgreSQL. Starts one {@code postgres:16-alpine} container per JVM (singleton,
 * never stopped explicitly; Testcontainers' Ryuk removes it) with the real role model:
 *
 * <ul>
 *   <li>{@value #MIGRATOR_USER} owns the database; Flyway connects as this role ({@code spring.flyway.user}).
 *   <li>{@value #APP_USER} is the application datasource (DML only, INSERT/SELECT on {@code audit_event}).
 * </ul>
 *
 * Combine with {@link IntegrationTest} or {@link JdbcSliceTest}. The {@code test} profile points the datasource at an
 * unresolvable host, so a test that forgets to extend this class fails fast instead of touching a local database.
 */
public abstract class PostgresTestBase {

  public static final String DATABASE = "iam_db";
  public static final String ADMIN_USER = "iam_admin";
  public static final String ADMIN_PASSWORD = "iam_admin_test";
  public static final String MIGRATOR_USER = "iam_migrator";
  public static final String MIGRATOR_PASSWORD = "iam_migrator_test";
  public static final String APP_USER = "iam_app";
  public static final String APP_PASSWORD = "iam_app_test";

  protected static final PostgreSQLContainer<?> POSTGRES =
      new PostgreSQLContainer<>(DockerImageName.parse("postgres:16-alpine"))
          .withDatabaseName(DATABASE)
          .withUsername(ADMIN_USER)
          .withPassword(ADMIN_PASSWORD)
          .withInitScript("db/test-init-roles.sql");

  static {
    POSTGRES.start();
  }

  @DynamicPropertySource
  static void postgresProperties(DynamicPropertyRegistry registry) {
    registry.add("spring.datasource.url", PostgresTestBase::jdbcUrl);
    registry.add("spring.datasource.username", () -> APP_USER);
    registry.add("spring.datasource.password", () -> APP_PASSWORD);
    registry.add("spring.flyway.url", PostgresTestBase::jdbcUrl);
    registry.add("spring.flyway.user", () -> MIGRATOR_USER);
    registry.add("spring.flyway.password", () -> MIGRATOR_PASSWORD);
  }

  public static String jdbcUrl() {
    return POSTGRES.getJdbcUrl();
  }

  /** Unpooled connections as {@value #APP_USER} (the application role). */
  public static DataSource appDataSource() {
    return dataSource(APP_USER, APP_PASSWORD);
  }

  /** Unpooled connections as {@value #MIGRATOR_USER} (owner of all schema objects). */
  public static DataSource migratorDataSource() {
    return dataSource(MIGRATOR_USER, MIGRATOR_PASSWORD);
  }

  /** Unpooled connections as the container superuser. Use sparingly (e.g. inspecting catalogs). */
  public static DataSource adminDataSource() {
    return dataSource(ADMIN_USER, ADMIN_PASSWORD);
  }

  private static DataSource dataSource(String user, String password) {
    return new SimpleDriverDataSource(new org.postgresql.Driver(), jdbcUrl(), user, password);
  }
}
