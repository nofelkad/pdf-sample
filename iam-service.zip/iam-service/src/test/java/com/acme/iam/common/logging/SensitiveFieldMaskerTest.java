package com.acme.iam.common.logging;

import static net.logstash.logback.argument.StructuredArguments.kv;
import static org.assertj.core.api.Assertions.assertThat;

import ch.qos.logback.classic.Level;
import ch.qos.logback.classic.Logger;
import ch.qos.logback.classic.LoggerContext;
import ch.qos.logback.classic.spi.LoggingEvent;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import net.logstash.logback.encoder.LogstashEncoder;
import net.logstash.logback.mask.MaskingJsonGeneratorDecorator;
import org.junit.jupiter.api.Test;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;

/**
 * Task 9 security review (Task 1 minor): the JSON log masking matches field names by substring, so
 * {@code clientSecret}, {@code newPassword}, {@code currentPassword}, {@code x-api-token} are masked too, not only
 * exact {@code password}/{@code secret}/{@code token}.
 */
class SensitiveFieldMaskerTest {

  private static String encode(LoggingEvent event) {
    LoggerContext context = (LoggerContext) LoggerFactory.getILoggerFactory();
    LogstashEncoder encoder = new LogstashEncoder();
    encoder.setContext(context);
    MaskingJsonGeneratorDecorator masking = new MaskingJsonGeneratorDecorator();
    masking.addFieldMasker(new SensitiveFieldMasker());
    masking.start();
    encoder.setJsonGeneratorDecorator(masking);
    encoder.start();
    return new String(encoder.encode(event), StandardCharsets.UTF_8);
  }

  private static LoggingEvent event(Object... arguments) {
    Logger logger = ((LoggerContext) LoggerFactory.getILoggerFactory()).getLogger("test");
    return new LoggingEvent("test", logger, Level.INFO, "something happened", null, arguments);
  }

  @Test
  void fieldsWhoseNameContainsASensitiveWordAreMasked() {
    String json = encode(event(kv("clientSecret", "c-s3cret"), kv("newPassword", "n-pw"),
        kv("currentPassword", "c-pw"), kv("refresh_token", "r-tok"), kv("X-Api-Token", "api-tok"),
        kv("passwordHash", "$argon2"), kv("privateKey", "pk"), kv("Authorization", "Basic abc"),
        kv("tenantId", "t-1")));

    assertThat(json).doesNotContain("c-s3cret", "n-pw", "c-pw", "r-tok", "api-tok", "$argon2", "\"pk\"", "Basic abc")
        .contains("\"tenantId\":\"t-1\"");
  }

  @Test
  void mdcFieldsAreMaskedToo() {
    MDC.put("sessionToken", "mdc-secret");
    try {
      LoggingEvent event = event();
      assertThat(encode(event)).doesNotContain("mdc-secret");
    } finally {
      MDC.clear();
    }
  }

  @Test
  void theJsonAppenderUsesTheMasker() throws Exception {
    String config = Files.readString(Path.of("src/main/resources/logback-spring.xml"));
    assertThat(config).contains("<fieldMasker class=\"" + SensitiveFieldMasker.class.getName() + "\"/>");
  }
}
