package com.acme.iam.user;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.within;

import com.acme.iam.account.AccountKind;
import com.acme.iam.account.AccountStatus;
import com.acme.iam.common.test.Fixtures;
import com.acme.iam.common.test.JdbcSliceTest;
import com.acme.iam.common.test.PostgresTestBase;
import java.time.Duration;
import java.time.Instant;
import java.time.OffsetDateTime;
import java.time.temporal.ChronoUnit;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Import;
import org.springframework.jdbc.core.simple.JdbcClient;

/** R19: credential and login-bookkeeping writes on {@code app_user} through targeted UPDATEs. */
@JdbcSliceTest
@Import({UserCredentialService.class, UserTokenService.class})
class UserCredentialServiceTest extends PostgresTestBase {

  @Autowired UserCredentialService service;
  @Autowired UserTokenService tokens;
  @Autowired JdbcClient jdbc;

  Fixtures fx;
  Fixtures.Scenario s;
  String email;

  @BeforeEach
  void setUp() {
    fx = new Fixtures(jdbc);
    s = fx.scenario();
    email = fx.email(s.userId());
  }

  @Test
  void loginCandidatesAreActiveUsersWithTheEmailAcrossAccountsCaseInsensitively() {
    UUID other = fx.account();
    UUID otherTenant = fx.tenant(other);
    UUID twin = fx.user(other, otherTenant);
    setEmail(twin, email.toUpperCase());
    UUID invited = fx.user(fx.account(), s.tenantId(), UserStatus.INVITED);
    setEmail(invited, "Invited-" + email);
    String slug = slug(s.accountId());

    List<LoginCandidate> all = service.findLoginCandidates(email.toUpperCase(), null);
    List<LoginCandidate> inAccount = service.findLoginCandidates(email, slug.toUpperCase());

    assertThat(all).extracting(LoginCandidate::userId).containsExactlyInAnyOrder(s.userId(), twin);
    assertThat(inAccount).singleElement().satisfies(c -> {
      assertThat(c.userId()).isEqualTo(s.userId());
      assertThat(c.accountId()).isEqualTo(s.accountId());
      assertThat(c.accountSlug()).isEqualTo(slug);
      assertThat(c.primaryTenantId()).isEqualTo(s.tenantId());
    });
    assertThat(service.findLoginCandidates(email, "no-such-account")).isEmpty();
  }

  @Test
  void disabledUsersAreNotCandidates() {
    jdbc.sql("UPDATE app_user SET status = 'DISABLED' WHERE id = :id").param("id", s.userId()).update();
    assertThat(service.findLoginCandidates(email, null)).isEmpty();
  }

  @Test
  void theFifthConsecutiveFailureLocksForTheLockDurationAndResetsTheCounter() {
    Instant before = Instant.now();
    for (int i = 1; i <= 4; i++) {
      assertThat(service.recordFailedLogin(s.userId(), 5, Duration.ofMinutes(15))).isFalse();
      assertThat(failedLogins()).isEqualTo(i);
    }

    assertThat(service.recordFailedLogin(s.userId(), 5, Duration.ofMinutes(15))).isTrue();

    assertThat(failedLogins()).isZero();
    assertThat(lockedUntil()).isCloseTo(before.plus(15, ChronoUnit.MINUTES), within(30, ChronoUnit.SECONDS));
    assertThat(service.findLoginCandidates(email, null).get(0).isLocked(Instant.now())).isTrue();
    // while locked nothing changes
    assertThat(service.recordFailedLogin(s.userId(), 5, Duration.ofMinutes(15))).isFalse();
    assertThat(failedLogins()).isZero();
  }

  @Test
  void anExpiredLockStartsCountingAgain() {
    jdbc.sql("UPDATE app_user SET locked_until = now() - interval '1 minute' WHERE id = :id")
        .param("id", s.userId()).update();

    assertThat(service.recordFailedLogin(s.userId(), 5, Duration.ofMinutes(15))).isFalse();
    assertThat(failedLogins()).isEqualTo(1);
  }

  @Test
  void successfulLoginResetsCountersAndStampsLastLoginWithoutAnAuditTriggerRow() {
    service.recordFailedLogin(s.userId(), 5, Duration.ofMinutes(15));
    long auditBefore = auditRows();

    service.recordSuccessfulLogin(s.userId());

    Map<String, Object> row = jdbc.sql("SELECT failed_logins, locked_until, last_login_at FROM app_user WHERE id = :id")
        .param("id", s.userId()).query().singleRow();
    assertThat(row.get("failed_logins")).isEqualTo(0);
    assertThat(row.get("locked_until")).isNull();
    assertThat(row.get("last_login_at")).isNotNull();
    assertThat(auditRows()).isEqualTo(auditBefore);
  }

  @Test
  void successfulLoginBookkeepingRefusesALockedUser() {
    jdbc.sql("UPDATE app_user SET locked_until = now() + interval '5 minutes', failed_logins = 0 WHERE id = :id")
        .param("id", s.userId()).update();

    assertThat(service.recordSuccessfulLogin(s.userId())).isFalse();

    assertThat(jdbc.sql("SELECT locked_until IS NOT NULL AND last_login_at IS NULL FROM app_user WHERE id = :id")
        .param("id", s.userId()).query(Boolean.class).single()).isTrue();
  }

  @Test
  void setPasswordUpdatesHashBumpsVersionRecordsHistoryAndClearsLock() {
    service.recordFailedLogin(s.userId(), 1, Duration.ofMinutes(15));
    long versionBefore = version();

    service.setPassword(s.userId(), "$argon2id$first", 5);
    service.setPassword(s.userId(), "$argon2id$second", 5);

    Map<String, Object> row = jdbc.sql(
            "SELECT password_hash, password_changed_at, locked_until, failed_logins FROM app_user WHERE id = :id")
        .param("id", s.userId()).query().singleRow();
    assertThat(row.get("password_hash")).isEqualTo("$argon2id$second");
    assertThat(row.get("password_changed_at")).isNotNull();
    assertThat(row.get("locked_until")).isNull();
    assertThat(version()).isEqualTo(versionBefore + 2);
    assertThat(service.passwordHashesToAvoid(s.userId(), 5)).containsExactly("$argon2id$second", "$argon2id$first");
  }

  @Test
  void conditionalSetPasswordOnlyReplacesTheExpectedCurrentHash() {
    service.setPassword(s.userId(), "$argon2id$one", 5);

    assertThat(service.setPassword(s.userId(), "$argon2id$two", 5, "$argon2id$stale")).isFalse();
    assertThat(currentHash()).isEqualTo("$argon2id$one");
    assertThat(service.passwordHashesToAvoid(s.userId(), 5)).containsExactly("$argon2id$one");

    assertThat(service.setPassword(s.userId(), "$argon2id$two", 5, "$argon2id$one")).isTrue();
    assertThat(currentHash()).isEqualTo("$argon2id$two");
  }

  @Test
  void peeksTheOwnerOfAUsableTokenWithoutConsumingIt() {
    IssuedToken reset = tokens.issue(s.userId(), TokenPurpose.PASSWORD_RESET, Duration.ofMinutes(30), null);

    assertThat(service.usableTokenOwner(reset.rawToken(), TokenPurpose.PASSWORD_RESET)).contains(s.userId());
    assertThat(service.usableTokenOwner(reset.rawToken(), TokenPurpose.PASSWORD_RESET)).contains(s.userId());
    assertThat(service.usableTokenOwner(reset.rawToken(), TokenPurpose.INVITE)).isEmpty();
    assertThat(service.usableTokenOwner("unknown", TokenPurpose.PASSWORD_RESET)).isEmpty();
    tokens.consume(reset.rawToken(), TokenPurpose.PASSWORD_RESET);
    assertThat(service.usableTokenOwner(reset.rawToken(), TokenPurpose.PASSWORD_RESET)).isEmpty();
  }

  @Test
  void historyIsTrimmedToTheKeepCount() {
    for (int i = 1; i <= 4; i++) {
      service.setPassword(s.userId(), "$argon2id$" + i, 2);
    }

    assertThat(jdbc.sql("SELECT count(*) FROM password_history WHERE user_id = :id").param("id", s.userId())
        .query(Long.class).single()).isEqualTo(2);
    assertThat(service.passwordHashesToAvoid(s.userId(), 10)).containsExactly("$argon2id$4", "$argon2id$3");
  }

  @Test
  void activatesAnInvitedUserWithPasswordAndDisplayName() {
    UUID invited = fx.user(s.accountId(), s.tenantId(), UserStatus.INVITED);

    assertThat(service.activateInvited(invited, "$argon2id$x", "Jane Doe", 5)).isTrue();
    assertThat(service.activateInvited(invited, "$argon2id$y", null, 5)).isFalse();

    Map<String, Object> row = jdbc.sql("SELECT status, password_hash, display_name FROM app_user WHERE id = :id")
        .param("id", invited).query().singleRow();
    assertThat(row).containsEntry("status", "ACTIVE").containsEntry("password_hash", "$argon2id$x")
        .containsEntry("display_name", "Jane Doe");
    assertThat(service.passwordHashesToAvoid(invited, 5)).containsExactly("$argon2id$x");
  }

  @Test
  void activationKeepsTheExistingDisplayNameWhenNoneIsGiven() {
    UUID invited = fx.user(s.accountId(), s.tenantId(), UserStatus.INVITED);
    String before = jdbc.sql("SELECT display_name FROM app_user WHERE id = :id").param("id", invited)
        .query(String.class).single();

    service.activateInvited(invited, "$argon2id$x", null, 5);

    assertThat(jdbc.sql("SELECT display_name FROM app_user WHERE id = :id").param("id", invited)
        .query(String.class).single()).isEqualTo(before);
  }

  @Test
  void candidatesOfAnInactiveAccountAreStillReturned() {
    // account/tenant status is checked after the password matches (spec section 4 step 5)
    UUID suspended = fx.account(AccountKind.CUSTOMER, AccountStatus.SUSPENDED);
    UUID user = fx.user(suspended, fx.tenant(suspended));
    setEmail(user, "Susp-" + email);

    assertThat(service.findLoginCandidates("susp-" + email, null)).extracting(LoginCandidate::userId)
        .containsExactly(user);
  }

  private void setEmail(UUID user, String value) {
    jdbc.sql("UPDATE app_user SET email = :email WHERE id = :id").param("email", value).param("id", user).update();
  }

  private String slug(UUID account) {
    return jdbc.sql("SELECT slug FROM account WHERE id = :id").param("id", account).query(String.class).single();
  }

  private int failedLogins() {
    return jdbc.sql("SELECT failed_logins FROM app_user WHERE id = :id").param("id", s.userId())
        .query(Integer.class).single();
  }

  private Instant lockedUntil() {
    return jdbc.sql("SELECT locked_until FROM app_user WHERE id = :id").param("id", s.userId())
        .query(OffsetDateTime.class).single().toInstant();
  }

  private String currentHash() {
    return jdbc.sql("SELECT password_hash FROM app_user WHERE id = :id").param("id", s.userId())
        .query(String.class).single();
  }

  private long version() {
    return jdbc.sql("SELECT version FROM app_user WHERE id = :id").param("id", s.userId()).query(Long.class).single();
  }

  private long auditRows() {
    return jdbc.sql("SELECT count(*) FROM audit_event WHERE target_id = :id").param("id", s.userId().toString())
        .query(Long.class).single();
  }
}
