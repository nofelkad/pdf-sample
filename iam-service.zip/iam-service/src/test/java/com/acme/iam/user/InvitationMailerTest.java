package com.acme.iam.user;

import static org.assertj.core.api.Assertions.assertThat;
import static org.awaitility.Awaitility.await;

import com.acme.iam.user.InvitationService.PendingInvitation;
import io.micrometer.core.instrument.simple.SimpleMeterRegistry;
import java.time.Duration;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import org.junit.jupiter.api.Test;

/** Final review I2: the bounded invitation sender drops, times out and counts instead of blocking callers. */
class InvitationMailerTest {

  private final SimpleMeterRegistry meters = new SimpleMeterRegistry();

  @Test
  void submitNeverBlocksAndAFullQueueDropsAndCounts() throws Exception {
    CountDownLatch release = new CountDownLatch(1);
    List<String> delivered = new CopyOnWriteArrayList<>();
    InvitationMailer mailer = new InvitationMailer(port(release, delivered),
        new InvitationMailerProperties(1, 2, Duration.ofSeconds(30)), meters);
    try {
      long started = System.nanoTime();
      mailer.submit(List.of(invite("a"), invite("b"), invite("c"), invite("d"), invite("e")));
      assertThat(Duration.ofNanos(System.nanoTime() - started)).isLessThan(Duration.ofSeconds(1));

      // one in flight, two queued, two dropped
      await().atMost(Duration.ofSeconds(5)).until(() -> counter(InvitationMailer.DROPPED_METRIC) == 2);
      assertThat(meters.get(InvitationMailer.QUEUED_METRIC).gauge().value()).isEqualTo(2);

      release.countDown();
      await().atMost(Duration.ofSeconds(5)).until(() -> delivered.size() == 3);
      await().atMost(Duration.ofSeconds(5)).until(() -> counter(InvitationMailer.SENT_METRIC) == 3);
    } finally {
      release.countDown();
      mailer.destroy();
    }
  }

  @Test
  void aHungSendIsCancelledAfterTheTimeoutAndTheNextOneProceeds() throws Exception {
    CountDownLatch never = new CountDownLatch(1);
    List<String> delivered = new CopyOnWriteArrayList<>();
    NotificationPort port = new NotificationPort() {
      @Override
      public void sendInvitation(String email, String accountName, String rawToken) {
        if (email.startsWith("hang")) {
          try {
            never.await();
          } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            return;
          }
        }
        delivered.add(email);
      }

      @Override
      public void sendPasswordReset(String email, String rawToken) {}
    };
    InvitationMailer mailer = new InvitationMailer(port, new InvitationMailerProperties(1, 10,
        Duration.ofMillis(200)), meters);
    try {
      mailer.submit(List.of(invite("hang"), invite("ok")));

      await().atMost(Duration.ofSeconds(5)).until(() -> delivered.contains("ok@example.test"));
      assertThat(counter(InvitationMailer.TIMEOUT_METRIC)).isEqualTo(1);
      assertThat(counter(InvitationMailer.SENT_METRIC)).isEqualTo(1);
    } finally {
      mailer.destroy();
    }
  }

  @Test
  void aFailingSendIsCountedAndDoesNotStopTheQueue() throws Exception {
    List<String> delivered = new CopyOnWriteArrayList<>();
    NotificationPort port = new NotificationPort() {
      @Override
      public void sendInvitation(String email, String accountName, String rawToken) {
        if (email.startsWith("bad")) {
          throw new IllegalStateException("smtp 421");
        }
        delivered.add(email);
      }

      @Override
      public void sendPasswordReset(String email, String rawToken) {}
    };
    InvitationMailer mailer = new InvitationMailer(port, new InvitationMailerProperties(1, 10,
        Duration.ofSeconds(5)), meters);
    try {
      mailer.submit(List.of(invite("bad"), invite("good")));

      await().atMost(Duration.ofSeconds(5)).until(() -> delivered.contains("good@example.test"));
      await().atMost(Duration.ofSeconds(5)).until(() -> counter(InvitationMailer.FAILED_METRIC) == 1);
    } finally {
      mailer.destroy();
    }
  }

  private double counter(String name) {
    return meters.get(name).counter().count();
  }

  private static PendingInvitation invite(String local) {
    return new PendingInvitation(local + "@example.test", "Acme", "raw-" + local);
  }

  private static NotificationPort port(CountDownLatch release, List<String> delivered) {
    return new NotificationPort() {
      @Override
      public void sendInvitation(String email, String accountName, String rawToken) {
        try {
          release.await(30, TimeUnit.SECONDS);
        } catch (InterruptedException e) {
          Thread.currentThread().interrupt();
          return;
        }
        delivered.add(email);
      }

      @Override
      public void sendPasswordReset(String email, String rawToken) {}
    };
  }
}
