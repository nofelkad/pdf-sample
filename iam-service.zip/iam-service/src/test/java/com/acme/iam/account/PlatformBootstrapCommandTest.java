package com.acme.iam.account;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoInteractions;
import static org.mockito.Mockito.when;

import com.acme.iam.account.PlatformBootstrapService.AlreadyBootstrappedException;
import com.acme.iam.account.PlatformBootstrapService.Result;
import com.acme.iam.common.Ids;
import com.acme.iam.user.IssuedToken;
import com.acme.iam.user.NotificationPort;
import com.acme.iam.user.NotificationProperties;
import com.acme.iam.user.NotificationProperties.Mode;
import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.nio.charset.StandardCharsets;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.boot.DefaultApplicationArguments;

/** P1-6.4 command-line handling of {@code --bootstrap-platform-admin email=...} (Ruling R23 for the output). */
class PlatformBootstrapCommandTest {

  private final PlatformBootstrapService service = mock(PlatformBootstrapService.class);
  private final NotificationPort notifications = mock(NotificationPort.class);
  private final ByteArrayOutputStream out = new ByteArrayOutputStream();
  private final ByteArrayOutputStream err = new ByteArrayOutputStream();
  private final List<Integer> exits = new ArrayList<>();
  private final Result result = new Result(Ids.newId(), Ids.newId(), "ops@example.test", "Platform",
      new IssuedToken(Ids.newId(), "RAW-TOKEN", Instant.parse("2026-10-17T00:00:00Z")), false);

  @BeforeEach
  void setUp() {
    when(service.bootstrap("ops@example.test")).thenReturn(result);
  }

  @Test
  void doesNothingWithoutTheOption() {
    command(Mode.LOG).run(new DefaultApplicationArguments("--server.port=0"));
    assertThat(exits).isEmpty();
    verifyNoInteractions(service);
  }

  @Test
  void logModePrintsTheAcceptLinkToStdoutAndExitsZero() {
    command(Mode.LOG).run(new DefaultApplicationArguments("--bootstrap-platform-admin", "email=ops@example.test"));
    assertThat(exits).containsExactly(0);
    assertThat(out.toString(StandardCharsets.UTF_8))
        .contains("ops@example.test")
        .contains("https://iam.example.test/accept?token=RAW-TOKEN");
    verify(notifications, never()).sendInvitation(anyString(), anyString(), anyString());
  }

  @Test
  void theEmailMayAlsoBeTheOptionValue() {
    command(Mode.LOG).run(new DefaultApplicationArguments("--bootstrap-platform-admin=email=ops@example.test"));
    assertThat(exits).containsExactly(0);
  }

  @Test
  void smtpModeEmailsAndNeverPrintsTheToken() {
    command(Mode.SMTP).run(new DefaultApplicationArguments("--bootstrap-platform-admin", "email=ops@example.test"));
    assertThat(exits).containsExactly(0);
    verify(notifications).sendInvitation("ops@example.test", "Platform", "RAW-TOKEN");
    assertThat(out.toString(StandardCharsets.UTF_8)).doesNotContain("RAW-TOKEN");
  }

  @Test
  void refusesToRunTwiceWithExitCodeTwo() {
    when(service.bootstrap("ops@example.test")).thenThrow(new AlreadyBootstrappedException("already done"));
    command(Mode.LOG).run(new DefaultApplicationArguments("--bootstrap-platform-admin", "email=ops@example.test"));
    assertThat(exits).containsExactly(2);
    assertThat(err.toString(StandardCharsets.UTF_8)).contains("already done");
  }

  @Test
  void aMissingEmailOrAFailureExitsOne() {
    command(Mode.LOG).run(new DefaultApplicationArguments("--bootstrap-platform-admin"));
    when(service.bootstrap("ops@example.test")).thenThrow(new IllegalStateException("roles not loaded"));
    command(Mode.LOG).run(new DefaultApplicationArguments("--bootstrap-platform-admin", "email=ops@example.test"));
    assertThat(exits).containsExactly(1, 1);
    assertThat(err.toString(StandardCharsets.UTF_8)).contains("email=").contains("roles not loaded");
  }

  @Test
  void aReissuedInvitationIsDeliveredAgainAndExitsZero() {
    when(service.bootstrap("ops@example.test")).thenReturn(new Result(result.userId(), result.tenantId(),
        result.email(), result.accountName(), result.token(), true));
    command(Mode.LOG).run(new DefaultApplicationArguments("--bootstrap-platform-admin", "email=ops@example.test"));
    assertThat(exits).containsExactly(0);
    assertThat(out.toString(StandardCharsets.UTF_8)).contains("new invitation").contains("RAW-TOKEN");
  }

  @Test
  void aFailedEmailExitsOneWithARerunHintAndNoToken() {
    doThrow(new IllegalStateException("smtp down: ops@example.test"))
        .when(notifications).sendInvitation(anyString(), anyString(), anyString());
    command(Mode.SMTP).run(new DefaultApplicationArguments("--bootstrap-platform-admin", "email=ops@example.test"));
    assertThat(exits).containsExactly(1);
    assertThat(err.toString(StandardCharsets.UTF_8)).contains("run the same command again");
    assertThat(out.toString(StandardCharsets.UTF_8) + err.toString(StandardCharsets.UTF_8))
        .doesNotContain("RAW-TOKEN");
  }

  private PlatformBootstrapCommand command(Mode mode) {
    NotificationProperties properties = new NotificationProperties(mode, "no-reply@iam.local",
        "https://iam.example.test/accept?token={token}", "https://iam.example.test/reset?token={token}", true);
    return new PlatformBootstrapCommand(service, properties, notifications,
        new PrintStream(out, true, StandardCharsets.UTF_8), new PrintStream(err, true, StandardCharsets.UTF_8),
        exits::add);
  }
}
