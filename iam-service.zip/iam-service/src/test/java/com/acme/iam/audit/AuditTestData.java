package com.acme.iam.audit;

import com.acme.iam.common.Ids;
import java.time.Instant;
import java.time.OffsetDateTime;
import java.time.YearMonth;
import java.time.ZoneOffset;
import java.util.UUID;
import org.springframework.jdbc.core.simple.JdbcClient;
import org.springframework.lang.Nullable;

/** Inserts audit rows with plain SQL (as the application role, which may INSERT into {@code audit_event}). */
final class AuditTestData {

  private final JdbcClient jdbc;

  AuditTestData(JdbcClient jdbc) {
    this.jdbc = jdbc;
  }

  /** Makes sure the previous three months have partitions, so tests may place events up to ~90 days back. */
  static void ensureRecentPartitions() {
    AuditTestPartitions ddl = new AuditTestPartitions();
    YearMonth now = YearMonth.now(ZoneOffset.UTC);
    ddl.create(now.minusMonths(1));
    ddl.create(now.minusMonths(2));
    ddl.create(now.minusMonths(3));
  }

  Row event(UUID account, String action, Instant occurredAt) {
    return new Row(account, action, occurredAt);
  }

  final class Row {
    private final UUID account;
    private final String action;
    private final Instant occurredAt;
    private UUID eventId = Ids.newId();
    private UUID tenant;
    private UUID actor;
    private String targetType;
    private String targetId;
    private String outcome = "SUCCESS";
    private String metadata;

    private Row(UUID account, String action, Instant occurredAt) {
      this.account = account;
      this.action = action;
      this.occurredAt = occurredAt;
    }

    Row id(UUID id) {
      this.eventId = id;
      return this;
    }

    Row tenant(@Nullable UUID tenant) {
      this.tenant = tenant;
      return this;
    }

    Row actor(@Nullable UUID actor) {
      this.actor = actor;
      return this;
    }

    Row target(String type, String id) {
      this.targetType = type;
      this.targetId = id;
      return this;
    }

    Row outcome(String outcome) {
      this.outcome = outcome;
      return this;
    }

    Row metadata(String json) {
      this.metadata = json;
      return this;
    }

    UUID insert() {
      jdbc.sql("""
              INSERT INTO audit_event (event_id, occurred_at, account_id, tenant_id, source, actor_user_id, actor_type,
                                       action, target_type, target_id, outcome, metadata, before_state, after_state,
                                       actor_ip, user_agent)
              VALUES (:id, :at, :account, :tenant, 'IAM', :actor, CASE WHEN CAST(:actor AS uuid) IS NULL THEN 'SYSTEM' ELSE 'USER' END,
                      :action, :tt, :tid, :outcome, CAST(:metadata AS jsonb), CAST('{"k":"before"}' AS jsonb),
                      CAST('{"k":"after"}' AS jsonb), CAST('198.51.100.7' AS inet), 'JUnit/1.0')""")
          .param("id", eventId)
          .param("at", OffsetDateTime.ofInstant(occurredAt, ZoneOffset.UTC))
          .param("account", account)
          .param("tenant", tenant)
          .param("actor", actor)
          .param("action", action)
          .param("tt", targetType)
          .param("tid", targetId)
          .param("outcome", outcome)
          .param("metadata", metadata)
          .update();
      return eventId;
    }
  }
}
