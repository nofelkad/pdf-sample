package com.acme.iam.common.jdbc;

import static org.assertj.core.api.Assertions.assertThat;

import com.acme.iam.common.RequestActor;
import com.acme.iam.common.test.PostgresTestBase;
import java.sql.Connection;
import java.util.Map;
import java.util.UUID;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.slf4j.MDC;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.SingleConnectionDataSource;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.security.oauth2.server.resource.authentication.JwtAuthenticationToken;
import org.springframework.transaction.support.TransactionTemplate;

/**
 * P1-1.5: the actor is visible to SQL as transaction-local settings inside a transaction and gone after commit and
 * rollback, on the very same physical connection (so nothing leaks between pooled connections).
 */
class AuditContextTransactionManagerTest extends PostgresTestBase {

  private static final String SETTINGS_SQL = """
      SELECT current_setting('app.user_id', true)    AS user_id,
             current_setting('app.account_id', true) AS account_id,
             current_setting('app.tenant_id', true)  AS tenant_id,
             current_setting('app.request_id', true) AS request_id,
             current_setting('app.session_id', true) AS session_id
      """;

  private final UUID userId = UUID.randomUUID();
  private final UUID accountId = UUID.randomUUID();
  private final UUID tenantId = UUID.randomUUID();
  private final UUID sessionId = UUID.randomUUID();

  private SingleConnectionDataSource dataSource;
  private JdbcTemplate jdbc;
  private TransactionTemplate tx;

  @BeforeEach
  void setUp() throws Exception {
    Connection connection = appDataSource().getConnection();
    dataSource = new SingleConnectionDataSource(connection, true);
    jdbc = new JdbcTemplate(dataSource);
    tx = new TransactionTemplate(new AuditContextTransactionManager(dataSource));
  }

  @AfterEach
  void tearDown() {
    SecurityContextHolder.clearContext();
    MDC.clear();
    dataSource.destroy();
  }

  @Test
  void actorIsVisibleInsideTransactionAndClearedAfterCommit() {
    authenticate();
    MDC.put(RequestActor.MDC_REQUEST_ID, "req-123");

    Map<String, Object> inside = tx.execute(status -> jdbc.queryForMap(SETTINGS_SQL));

    assertThat(inside)
        .containsEntry("user_id", userId.toString())
        .containsEntry("account_id", accountId.toString())
        .containsEntry("tenant_id", tenantId.toString())
        .containsEntry("request_id", "req-123")
        .containsEntry("session_id", sessionId.toString());
    assertAllSettingsEmpty(jdbc.queryForMap(SETTINGS_SQL));
  }

  @Test
  void actorIsClearedAfterRollback() {
    authenticate();

    tx.executeWithoutResult(status -> {
      assertThat(jdbc.queryForObject("SELECT current_setting('app.user_id', true)", String.class))
          .isEqualTo(userId.toString());
      status.setRollbackOnly();
    });

    assertAllSettingsEmpty(jdbc.queryForMap(SETTINGS_SQL));
  }

  @Test
  void withoutJwtTheActorIsSystemAndSettingsAreEmpty() {
    Map<String, Object> inside = tx.execute(status -> jdbc.queryForMap(SETTINGS_SQL));

    assertAllSettingsEmpty(inside);
  }

  @Test
  void nextTransactionOnSameConnectionDoesNotInheritPreviousActor() {
    authenticate();
    tx.executeWithoutResult(status -> jdbc.queryForMap(SETTINGS_SQL));
    SecurityContextHolder.clearContext();

    Map<String, Object> second = tx.execute(status -> jdbc.queryForMap(SETTINGS_SQL));

    assertAllSettingsEmpty(second);
  }

  private void authenticate() {
    Jwt jwt = Jwt.withTokenValue("t")
        .header("alg", "none")
        .subject(userId.toString())
        .claim("acc", accountId.toString())
        .claim("tid", tenantId.toString())
        .claim("sid", sessionId.toString())
        .build();
    SecurityContextHolder.getContext().setAuthentication(new JwtAuthenticationToken(jwt));
  }

  /** Unset custom settings read as NULL (never set on this connection) or '' (set earlier, reset at tx end). */
  private static void assertAllSettingsEmpty(Map<String, Object> settings) {
    assertThat(settings.values()).allSatisfy(v -> assertThat(v == null || "".equals(v)).as("value %s", v).isTrue());
  }
}
