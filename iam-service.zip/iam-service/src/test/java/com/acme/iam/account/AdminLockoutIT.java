package com.acme.iam.account;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.springframework.http.HttpHeaders.AUTHORIZATION;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;

import com.acme.iam.assignment.PermissionResolver;
import com.acme.iam.assignment.ScopeType;
import com.acme.iam.common.Ids;
import com.acme.iam.common.error.BadRequestException;
import com.acme.iam.common.test.CapturingNotificationAdapter;
import com.acme.iam.common.test.Fixtures;
import com.acme.iam.common.test.IntegrationTest;
import com.acme.iam.common.test.OrgTestData;
import com.acme.iam.common.test.PostgresTestBase;
import com.acme.iam.common.test.TestTokens;
import com.acme.iam.tenant.TenantStatus;
import com.acme.iam.user.MembershipStatus;
import com.acme.iam.user.TokenPurpose;
import com.acme.iam.user.UserStatus;
import com.acme.iam.user.UserTokenService;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.time.Duration;
import java.time.Instant;
import java.util.Map;
import java.util.UUID;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.context.annotation.Import;
import org.springframework.http.MediaType;
import org.springframework.jdbc.core.simple.JdbcClient;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;
import org.springframework.transaction.support.TransactionTemplate;

/**
 * Final review I5 / ruling R43: an account cannot lock out its last admins by suspending or archiving their primary
 * tenant, and a platform operator can recover an account that has no usable admin
 * ({@code POST /api/platform/accounts/{id}/admins}).
 */
@IntegrationTest
@AutoConfigureMockMvc
@Import(CapturingNotificationAdapter.Config.class)
class AdminLockoutIT extends PostgresTestBase {

  @Autowired MockMvc mvc;
  @Autowired TestTokens tokens;
  @Autowired JdbcClient jdbc;
  @Autowired ObjectMapper json;
  @Autowired PermissionResolver resolver;
  @Autowired CapturingNotificationAdapter mailbox;
  @Autowired UserTokenService userTokens;
  @Autowired TransactionTemplate tx;

  OrgTestData org;
  Fixtures fx;
  UUID account;
  UUID home;
  UUID admin;
  String adminBearer;
  String platform;

  @BeforeEach
  void setUp() {
    mailbox.clear();
    org = new OrgTestData(jdbc);
    fx = org.fixtures();
    account = fx.account();
    home = fx.tenant(account);
    admin = org.accountAdmin(account, home);
    adminBearer = org.bearer(tokens, admin, account, home, "iam.tenant.manage");
    platform = org.platformBearer(tokens, org.platformOperator());
  }

  // --------------------------------------------------------------------- (a) tenant suspension / archive

  @Test
  void suspendingOrArchivingThePrimaryTenantOfEveryAdminIsLastAdmin() throws Exception {
    for (String action : new String[] {"suspend", "archive"}) {
      MockHttpServletResponse r = call(post("/api/tenants/{id}/" + action, home).header(AUTHORIZATION, adminBearer));

      assertThat(r.getStatus()).as(action).isEqualTo(409);
      assertThat(code(r)).isEqualTo("last_admin");
      assertThat(tenantStatus(home)).isEqualTo("ACTIVE");
    }
  }

  @Test
  void anAdminWhosePrimaryTenantIsElsewhereLetsTheTenantBeSuspended() throws Exception {
    UUID elsewhere = fx.tenant(account);
    org.accountAdmin(account, elsewhere);

    assertThat(call(post("/api/tenants/{id}/suspend", home).header(AUTHORIZATION, adminBearer)).getStatus())
        .isEqualTo(200);
    assertThat(tenantStatus(home)).isEqualTo("SUSPENDED");
  }

  @Test
  void anAdminElsewhereOnlyCountsWhenThatTenantIsActiveAndTheirGrantPermanent() throws Exception {
    UUID suspendedTenant = fx.tenant(account, TenantStatus.SUSPENDED);
    org.accountAdmin(account, suspendedTenant);
    UUID other = fx.tenant(account);
    UUID expiring = fx.user(account, other);
    fx.assign(expiring, org.accountAdminRole(), ScopeType.ACCOUNT, account, Instant.now().plus(Duration.ofDays(1)));

    MockHttpServletResponse r = call(post("/api/tenants/{id}/suspend", home).header(AUTHORIZATION, adminBearer));

    assertThat(r.getStatus()).isEqualTo(409);
    assertThat(code(r)).isEqualTo("last_admin");
  }

  @Test
  void aTenantWithoutAdminsIsSuspendedAsBefore() throws Exception {
    UUID other = fx.tenant(account);
    fx.user(account, other);

    assertThat(call(post("/api/tenants/{id}/suspend", other).header(AUTHORIZATION, adminBearer)).getStatus())
        .isEqualTo(200);
    assertThat(call(post("/api/tenants/{id}/archive", other).header(AUTHORIZATION, adminBearer)).getStatus())
        .isEqualTo(200);
  }

  // --------------------------------------------------------------------- (c) platform recovery endpoint

  @Test
  void recoveryReactivatesASuspendedTenantInvitesANewUserAndGrantsAccountAdmin() throws Exception {
    fx.tenantStatus(home, TenantStatus.SUSPENDED); // the lock-out: every admin's primary tenant is suspended
    String email = "rescue-" + Ids.newId() + "@example.test";

    JsonNode body = recover(account, email, home, 200);

    UUID rescued = UUID.fromString(body.get("userId").asText());
    assertThat(body.get("invited").asBoolean()).isTrue();
    assertThat(body.get("tenantReactivated").asBoolean()).isTrue();
    assertThat(tenantStatus(home)).isEqualTo("ACTIVE");
    assertThat(org.userStatus(rescued)).isEqualTo("INVITED");
    assertThat(org.membershipTenants(rescued)).containsExactly(home);
    assertThat(permanentAdminGrant(rescued)).isTrue();
    String raw = mailbox.lastInvitationToken(email);
    UUID consumedBy = tx.execute(s -> userTokens.consume(raw, TokenPurpose.INVITE).user());
    assertThat(consumedBy).isEqualTo(rescued);
    assertThat(resolver.resolve(rescued, home)).contains("iam.user.manage", "iam.tenant.manage");
    // audited, in the recovered account
    Map<String, Object> event = jdbc.sql("""
            SELECT account_id, tenant_id, actor_type, metadata->>'invited' AS invited FROM audit_event
            WHERE action = 'iam.account.admin_recovered' AND target_id = :u""")
        .param("u", rescued.toString()).query().singleRow();
    assertThat(event).containsEntry("account_id", account).containsEntry("tenant_id", home)
        .containsEntry("actor_type", "USER").containsEntry("invited", "true");
    assertThat(jdbc.sql("""
            SELECT count(*) FROM audit_event WHERE action = 'iam.role_assignment.insert' AND account_id = :a
              AND after_state->>'user_id' = :u""")
        .param("a", account).param("u", rescued.toString()).query(Long.class).single()).isEqualTo(1);
  }

  @Test
  void recoveryReusesAndReactivatesADisabledUserAndMakesAnExpiringGrantPermanent() throws Exception {
    UUID other = fx.tenant(account);
    UUID user = fx.user(account, home, UserStatus.DISABLED);
    jdbc.sql("UPDATE app_user SET password_hash = 'x' WHERE id = :u").param("u", user).update();
    fx.membership(user, other, MembershipStatus.SUSPENDED);
    fx.assign(user, org.accountAdminRole(), ScopeType.ACCOUNT, account, Instant.now().plus(Duration.ofDays(2)));
    fx.tenantStatus(home, TenantStatus.SUSPENDED);

    JsonNode body = recover(account, fx.email(user).toUpperCase(), other, 200);

    assertThat(body.get("userId").asText()).isEqualTo(user.toString());
    assertThat(body.get("invited").asBoolean()).isFalse();
    assertThat(body.get("userReactivated").asBoolean()).isTrue();
    assertThat(body.get("tenantReactivated").asBoolean()).isFalse();
    assertThat(org.userStatus(user)).isEqualTo("ACTIVE");
    assertThat(jdbc.sql("SELECT status FROM user_tenant_membership WHERE app_user = :u AND tenant_id = :t")
        .param("u", user).param("t", other).query(String.class).single()).isEqualTo("ACTIVE");
    assertThat(jdbc.sql("SELECT primary_tenant_id FROM app_user WHERE id = :u").param("u", user).query(UUID.class)
        .single()).as("the suspended primary tenant is replaced by the recovery tenant").isEqualTo(other);
    assertThat(permanentAdminGrant(user)).isTrue();
    assertThat(jdbc.sql("SELECT count(*) FROM role_assignment WHERE user_id = :u").param("u", user)
        .query(Long.class).single()).isEqualTo(1);
    assertThat(resolver.resolve(user, other)).contains("iam.user.manage");
  }

  @Test
  void anInvitedUserGetsAFreshInvitation() throws Exception {
    UUID invited = fx.user(account, home, UserStatus.INVITED);

    JsonNode body = recover(account, fx.email(invited), home, 200);

    assertThat(body.get("invited").asBoolean()).isTrue();
    assertThat(body.get("invitationExpiresAt").isNull()).isFalse();
    assertThat(mailbox.lastInvitationToken(fx.email(invited))).isNotBlank();
    assertThat(permanentAdminGrant(invited)).isTrue();
  }

  @Test
  void anArchivedTenantADeprovisionedUserAndAClosedOrPlatformAccountAreConflicts() throws Exception {
    UUID archived = fx.tenant(account, TenantStatus.ARCHIVED);
    assertThat(code(recoverRaw(account, "a-" + Ids.newId() + "@example.test", archived, 409)))
        .isEqualTo("tenant_not_active");

    UUID gone = fx.user(account, home, UserStatus.DEPROVISIONED);
    assertThat(code(recoverRaw(account, fx.email(gone), home, 409))).isEqualTo("user_deprovisioned");
    assertThat(permanentAdminGrant(gone)).isFalse();

    UUID closed = fx.account(AccountKind.CUSTOMER, AccountStatus.CLOSED);
    assertThat(code(recoverRaw(closed, "c-" + Ids.newId() + "@example.test", fx.tenant(closed), 409)))
        .isEqualTo("account_closed");

    assertThat(code(recoverRaw(Account.PLATFORM_ID, "p-" + Ids.newId() + "@example.test",
        fx.tenant(Account.PLATFORM_ID), 409))).isEqualTo("platform_account_protected");
  }

  @Test
  void unknownAccountsAndTenantsOfAnotherAccountAreNotFound() throws Exception {
    assertThat(code(recoverRaw(UUID.randomUUID(), "x@example.test", home, 404))).isEqualTo("account_not_found");
    assertThat(code(recoverRaw(account, "x@example.test", fx.tenant(fx.account()), 404)))
        .isEqualTo("tenant_not_found");
  }

  @Test
  void onlyPlatformOperatorsMayRecover() throws Exception {
    MockHttpServletResponse r = call(json(post("/api/platform/accounts/{id}/admins", account),
        "{\"email\":\"x@example.test\",\"tenantId\":\"%s\"}".formatted(home))
        .header(AUTHORIZATION, org.bearer(tokens, admin, account, home, "platform.account.manage")));
    assertThat(r.getStatus()).isEqualTo(403);
    assertThat(code(r)).isEqualTo("platform_account_required");
  }

  // ------------------------------------------------------------------------------------------ helpers

  // --------------------------------------------------------------------- (c) activation link (R46)

  @Test
  void recoveringWithANewEmailReturnsAWorkingLink() throws Exception {
    String email = "rescue-" + Ids.newId() + "@example.test";

    MockHttpServletResponse r = recoverRaw(account, email, home, 200);
    assertThat(r.getHeader("Cache-Control")).isEqualTo("no-store");
    JsonNode body = json.readTree(r.getContentAsString());

    assertThat(body.get("invited").asBoolean()).isTrue();
    String link = body.at("/activation/link").asText();
    String raw = mailbox.lastInvitationToken(email);
    assertThat(link).endsWith("token=" + raw);
    UUID user = UUID.fromString(body.get("userId").asText());
    UUID consumedBy = tx.execute(s -> userTokens.consume(raw, TokenPurpose.INVITE).user());
    assertThat(consumedBy).isEqualTo(user);
    assertThat(linkAudits(user, "admin_recovery")).isEqualTo(1);
  }

  @Test
  void aReInvitedAdminGetsALinkAndOnlyTheNewestWorks() throws Exception {
    UUID invited = fx.user(account, home, UserStatus.INVITED);
    String email = fx.email(invited);

    JsonNode first = recover(account, email, home, 200);
    mailbox.awaitCount(CapturingNotificationAdapter.Kind.INVITATION, email, 1);
    JsonNode second = recover(account, email, home, 200);
    mailbox.awaitCount(CapturingNotificationAdapter.Kind.INVITATION, email, 2);

    String firstRaw = tokenOf(first.at("/activation/link").asText());
    String secondRaw = tokenOf(second.at("/activation/link").asText());
    assertThat(secondRaw).isNotEqualTo(firstRaw).isEqualTo(mailbox.lastInvitationToken(email));
    assertThatThrownBy(() -> tx.execute(s -> userTokens.consume(firstRaw, TokenPurpose.INVITE)))
        .isInstanceOf(BadRequestException.class);
    UUID consumedBy = tx.execute(s -> userTokens.consume(secondRaw, TokenPurpose.INVITE).user());
    assertThat(consumedBy).isEqualTo(invited);
    assertThat(linkAudits(invited, "admin_recovery")).isEqualTo(2);
    assertThat(linkAudits(invited, "resend")).isZero();
  }

  @Test
  void recoveringAnActiveUserReturnsNoLink() throws Exception {
    UUID active = fx.user(account, home);
    JsonNode body = recover(account, fx.email(active), home, 200);
    assertThat(body.get("invited").asBoolean()).isFalse();
    assertThat(body.has("activation")).isFalse();
  }

  private long linkAudits(UUID user, String via) {
    return jdbc.sql("SELECT count(*) FROM audit_event WHERE action = 'iam.invitation.link_issued' "
            + "AND target_id = :u AND metadata->>'via' = :via")
        .param("u", user.toString()).param("via", via).query(Long.class).single();
  }

  private static String tokenOf(String link) {
    return link.substring(link.indexOf("token=") + "token=".length());
  }

  private JsonNode recover(UUID accountId, String email, UUID tenantId, int status) throws Exception {
    return json.readTree(recoverRaw(accountId, email, tenantId, status).getContentAsString());
  }

  private MockHttpServletResponse recoverRaw(UUID accountId, String email, UUID tenantId, int status)
      throws Exception {
    MockHttpServletResponse r = call(json(post("/api/platform/accounts/{id}/admins", accountId),
        "{\"email\":\"%s\",\"tenantId\":\"%s\"}".formatted(email, tenantId)).header(AUTHORIZATION, platform));
    assertThat(r.getStatus()).as(r.getContentAsString()).isEqualTo(status);
    return r;
  }

  private boolean permanentAdminGrant(UUID user) {
    return jdbc.sql("""
            SELECT EXISTS (SELECT 1 FROM role_assignment ra JOIN role r ON r.id = ra.role_id
                           WHERE ra.user_id = :u AND r.name = 'Account Admin' AND r.type = 'SYSTEM'
                             AND ra.scope_type = 'ACCOUNT' AND ra.scope_id = :a AND ra.expires_at IS NULL)""")
        .param("u", user).param("a", account).query(Boolean.class).single();
  }

  private String tenantStatus(UUID tenant) {
    return jdbc.sql("SELECT status FROM tenant WHERE id = :t").param("t", tenant).query(String.class).single();
  }

  private MockHttpServletResponse call(MockHttpServletRequestBuilder request) throws Exception {
    return mvc.perform(request).andReturn().getResponse();
  }

  private String code(MockHttpServletResponse response) throws Exception {
    return json.readTree(response.getContentAsString()).get("code").asText();
  }

  private static MockHttpServletRequestBuilder json(MockHttpServletRequestBuilder request, String body) {
    return request.contentType(MediaType.APPLICATION_JSON).content(body);
  }
}
