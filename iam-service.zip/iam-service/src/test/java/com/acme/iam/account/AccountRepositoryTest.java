package com.acme.iam.account;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.assertj.core.api.Assertions.within;

import com.acme.iam.common.test.Fixtures;
import com.acme.iam.common.test.JdbcSliceTest;
import com.acme.iam.common.test.PostgresTestBase;
import com.acme.iam.common.Ids;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.OptimisticLockingFailureException;
import org.springframework.jdbc.core.simple.JdbcClient;

/** P1-3.1: Account (+AccountProduct) round trip. */
@JdbcSliceTest
class AccountRepositoryTest extends PostgresTestBase {

  @Autowired AccountRepository accounts;
  @Autowired JdbcClient jdbc;

  @Test
  void roundTripsAccountWithSubscriptionsAndSettings() {
    UUID product = new Fixtures(jdbc).product();
    String slug = "acme-" + Ids.newId();
    Account created = Account.create("Acme", slug, AccountKind.CUSTOMER)
        .withSettings(Map.of("passwordPolicy", Map.of("minLength", 12), "refreshIdleMinutes", 30))
        .withProducts(Set.of(new AccountProduct(product, SubscriptionStatus.TRIAL, LocalDate.of(2026, 1, 1),
            LocalDate.of(2026, 12, 31))));

    Account saved = accounts.save(created);
    assertThat(saved.id()).isNotNull();
    assertThat(saved.id().version()).as("UUIDv7").isEqualTo(7);
    assertThat(saved.version()).isZero();

    Account loaded = accounts.findById(saved.id()).orElseThrow();
    assertThat(loaded.name()).isEqualTo("Acme");
    assertThat(loaded.slug()).isEqualTo(slug);
    assertThat(loaded.kind()).isEqualTo(AccountKind.CUSTOMER);
    assertThat(loaded.status()).isEqualTo(AccountStatus.ACTIVE);
    assertThat(loaded.settings()).containsEntry("refreshIdleMinutes", 30)
        .containsEntry("passwordPolicy", Map.of("minLength", 12));
    assertThat(loaded.products()).containsExactly(new AccountProduct(product, SubscriptionStatus.TRIAL,
        LocalDate.of(2026, 1, 1), LocalDate.of(2026, 12, 31)));
    assertThat(loaded.createdAt()).isCloseTo(saved.createdAt(), within(1, ChronoUnit.MICROS));
    assertThat(loaded.updatedAt()).isNotNull();

    Account updated = accounts.save(loaded.withStatus(AccountStatus.SUSPENDED).withProducts(Set.of()));
    assertThat(updated.version()).isEqualTo(1);
    Account reloaded = accounts.findById(saved.id()).orElseThrow();
    assertThat(reloaded.status()).isEqualTo(AccountStatus.SUSPENDED);
    assertThat(reloaded.products()).isEmpty();
  }

  @Test
  void findsBySlugCaseInsensitively() {
    String slug = "MixedCase-" + Ids.newId();
    Account saved = accounts.save(Account.create("Mixed", slug, AccountKind.CUSTOMER));
    assertThat(accounts.findBySlug(slug.toLowerCase())).map(Account::id).contains(saved.id());
  }

  @Test
  void seededPlatformAccountIsReadable() {
    Account platform = accounts.findById(Account.PLATFORM_ID).orElseThrow();
    assertThat(platform.isPlatform()).isTrue();
    assertThat(platform.settings()).isEmpty();
  }

  @Test
  void staleVersionIsRejected() {
    Account saved = accounts.save(Account.create("Stale", "stale-" + Ids.newId(), AccountKind.CUSTOMER));
    accounts.save(saved.withName("First"));
    assertThatThrownBy(() -> accounts.save(saved.withName("Second")))
        .isInstanceOf(OptimisticLockingFailureException.class);
  }
}
