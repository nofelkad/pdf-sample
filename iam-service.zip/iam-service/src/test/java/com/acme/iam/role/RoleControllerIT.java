package com.acme.iam.role;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.springframework.http.HttpHeaders.AUTHORIZATION;
import static org.springframework.http.HttpHeaders.LOCATION;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.patch;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.header;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import com.acme.iam.account.SubscriptionStatus;
import com.acme.iam.assignment.ScopeType;
import com.acme.iam.common.error.ForbiddenException;
import com.acme.iam.common.test.Fixtures;
import com.acme.iam.common.test.IntegrationTest;
import com.acme.iam.common.test.PostgresTestBase;
import com.acme.iam.common.test.TestTokens;
import com.acme.iam.product.Product;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.TimeUnit;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.http.MediaType;
import org.springframework.jdbc.core.simple.JdbcClient;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.ResultActions;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;
import org.springframework.transaction.support.TransactionTemplate;

/** P1-10.3: role API: visibility, I3, I6 (role editing), I8, revocation of holders, delete guard. */
@IntegrationTest
@AutoConfigureMockMvc
class RoleControllerIT extends PostgresTestBase {

  @Autowired MockMvc mvc;
  @Autowired TestTokens tokens;
  @Autowired JdbcClient jdbc;
  @Autowired ObjectMapper json;
  @Autowired RoleAdminService admin;
  @Autowired TransactionTemplate tx;

  Fixtures fx;
  Fixtures.Scenario s;           // the caller's account / tenant / user
  UUID product;                  // a product the account is subscribed to
  UUID p1;
  UUID p2;
  UUID p3;                       // held by nobody: the caller cannot grant it
  String c1;
  String c2;
  String c3;
  String manager;                // iam.role.manage

  @BeforeEach
  void setUp() {
    fx = new Fixtures(jdbc);
    s = fx.scenario();
    product = fx.product();
    fx.subscribe(s.accountId(), product, SubscriptionStatus.ACTIVE, null);
    fx.enableProduct(s.tenantId(), product, true);
    p1 = fx.permission(product);
    p2 = fx.permission(product);
    p3 = fx.permission(product);
    c1 = fx.code(p1);
    c2 = fx.code(p2);
    c3 = fx.code(p3);
    // the caller holds p1 and p2 at ACCOUNT scope, and iam.role.manage at ACCOUNT scope (Task 9: role writes need it)
    fx.assign(s.userId(), fx.systemRole(product, p1, p2), ScopeType.ACCOUNT, s.accountId());
    fx.assign(s.userId(), roleManageRole(), ScopeType.ACCOUNT, s.accountId());
    manager = tokens.user(s.userId()).account(s.accountId()).tenant(s.tenantId()).perms("iam.role.manage").bearer();
  }

  // ------------------------------------------------------------------------------------------- helpers

  private ResultActions send(MockHttpServletRequestBuilder request, String bearer, Object body) throws Exception {
    request.header(AUTHORIZATION, bearer);
    if (body != null) {
      request.contentType(MediaType.APPLICATION_JSON).content(body instanceof String str ? str : json.writeValueAsString(body));
    }
    return mvc.perform(request);
  }

  private String createBody(String name, String... codes) throws Exception {
    return json.writeValueAsString(java.util.Map.of("productCode", productCode(product), "name", name,
        "description", "desc", "permissionCodes", List.of(codes)));
  }

  private String productCode(UUID id) {
    return jdbc.sql("SELECT code FROM product WHERE id = :id").param("id", id).query(String.class).single();
  }

  private UUID createRole(String name, String... codes) throws Exception {
    String id = json.readTree(send(post("/api/roles"), manager, createBody(name, codes))
        .andExpect(status().isCreated()).andReturn().getResponse().getContentAsString()).get("id").asText();
    return UUID.fromString(id);
  }

  private int sessionVersion(UUID user) {
    return jdbc.sql("SELECT session_version FROM app_user WHERE id = :id").param("id", user).query(Integer.class).single();
  }

  private long rolePermissionAudit() {
    return jdbc.sql("SELECT count(*) FROM audit_event WHERE target_type = 'role_permission'").query(Long.class).single();
  }

  // ------------------------------------------------------------------------------------------- create

  @Test
  void createsACustomRoleInTheCallersAccount() throws Exception {
    ResultActions created = send(post("/api/roles"), manager, createBody("Invoice Clerk", c1, c2))
        .andExpect(status().isCreated())
        .andExpect(jsonPath("$.name").value("Invoice Clerk"))
        .andExpect(jsonPath("$.type").value("CUSTOM"))
        .andExpect(jsonPath("$.accountId").value(s.accountId().toString()))
        .andExpect(jsonPath("$.productCode").value(productCode(product)))
        .andExpect(jsonPath("$.createdAt").isNotEmpty())
        .andExpect(jsonPath("$.updatedAt").isNotEmpty())
        .andExpect(jsonPath("$.permissions.length()").value(2));
    String id = json.readTree(created.andReturn().getResponse().getContentAsString()).get("id").asText();
    created.andExpect(header().string(LOCATION, "/api/roles/" + id));

    assertThat(jdbc.sql("SELECT type || ':' || account_id FROM role WHERE id = CAST(:id AS uuid)").param("id", id)
        .query(String.class).single()).isEqualTo("CUSTOM:" + s.accountId());
    assertThat(jdbc.sql("SELECT count(*) FROM role_permission WHERE role = CAST(:id AS uuid)").param("id", id)
        .query(Long.class).single()).isEqualTo(2);
  }

  @Test
  void createIsDeniedWithoutIamRoleManage() throws Exception {
    String noPermission = tokens.user(s.userId()).account(s.accountId()).tenant(s.tenantId()).perms("iam.role.assign").bearer();

    send(post("/api/roles"), noPermission, createBody("Nope", c1)).andExpect(status().isForbidden());
    send(post("/api/roles"), tokens.user(s.userId()).bearer(), createBody("Nope", c1)).andExpect(status().isForbidden());
    mvc.perform(post("/api/roles").contentType(MediaType.APPLICATION_JSON).content(createBody("Nope", c1)))
        .andExpect(status().isUnauthorized());
  }

  @Test
  void aCustomRoleMayOnlyHoldPermissionsOfItsOwnProduct() throws Exception {
    UUID otherProduct = fx.product();
    fx.subscribe(s.accountId(), otherProduct, SubscriptionStatus.ACTIVE, null);
    UUID foreign = fx.permission(otherProduct);
    fx.assign(s.userId(), fx.systemRole(otherProduct, foreign), ScopeType.ACCOUNT, s.accountId());

    send(post("/api/roles"), manager, createBody("Mixed", c1, fx.code(foreign)))
        .andExpect(status().isBadRequest())
        .andExpect(jsonPath("$.code").value("permission_product_mismatch"))
        .andExpect(jsonPath("$.permissionIds[0]").value(foreign.toString()));
  }

  @Test
  void unknownAndDeprecatedPermissionsAreRejected() throws Exception {
    send(post("/api/roles"), manager, createBody("Ghost", c1, "no.such.code"))
        .andExpect(status().isBadRequest())
        .andExpect(jsonPath("$.code").value("unknown_permission"))
        .andExpect(jsonPath("$.permissionCodes[0]").value("no.such.code"));

    fx.deprecate(p2);
    send(post("/api/roles"), manager, createBody("Old", c1, c2))
        .andExpect(status().isBadRequest())
        .andExpect(jsonPath("$.code").value("permission_deprecated"))
        .andExpect(jsonPath("$.permissionCodes[0]").value(c2));
  }

  @Test
  void theProductMustBeIamOrSubscribed() throws Exception {
    UUID unsubscribed = fx.product();
    UUID perm = fx.permission(unsubscribed);
    String body = json.writeValueAsString(java.util.Map.of("productCode", productCode(unsubscribed), "name", "X",
        "permissionCodes", List.of(fx.code(perm))));

    send(post("/api/roles"), manager, body).andExpect(status().isBadRequest())
        .andExpect(jsonPath("$.code").value("product_not_subscribed"));
    send(post("/api/roles"), manager, body.replace(productCode(unsubscribed), "NOSUCHPRODUCT"))
        .andExpect(status().isNotFound()).andExpect(jsonPath("$.code").value("product_not_found"));

    fx.subscribe(s.accountId(), unsubscribed, SubscriptionStatus.EXPIRED, null);
    send(post("/api/roles"), manager, body).andExpect(status().isBadRequest())
        .andExpect(jsonPath("$.code").value("product_not_subscribed"));

    // IAM needs no subscription (the caller holds the IAM permission at account scope)
    UUID iamPerm = fx.permission(Product.IAM_ID, "iam.audit.read");
    fx.assign(s.userId(), fx.systemRole(Product.IAM_ID, iamPerm), ScopeType.ACCOUNT, s.accountId());
    send(post("/api/roles"), manager, json.writeValueAsString(java.util.Map.of("productCode", "IAM",
        "name", "Audit Reader " + s.userId(), "permissionCodes", List.of("iam.audit.read"))))
        .andExpect(status().isCreated());
  }

  @Test
  void permissionsTheCallerDoesNotHoldAtAccountScopeCannotBeAdded() throws Exception {
    send(post("/api/roles"), manager, createBody("Too strong", c1, c3))
        .andExpect(status().isForbidden())
        .andExpect(jsonPath("$.code").value("grantor_lacks_permissions"))
        .andExpect(jsonPath("$.missingPermissions[0]").value(c3));
    // a tenant-scope grant does not count: role editing needs the permissions at ACCOUNT scope
    UUID tenantOnly = fx.user(s.accountId(), s.tenantId());
    fx.assign(tenantOnly, roleManageRole(), ScopeType.ACCOUNT, s.accountId());
    fx.assign(tenantOnly, fx.systemRole(product, p3), ScopeType.TENANT, s.tenantId());
    String tenantAdmin = tokens.user(tenantOnly).account(s.accountId()).tenant(s.tenantId()).perms("iam.role.manage").bearer();
    send(post("/api/roles"), tenantAdmin, createBody("Tenant only", c3))
        .andExpect(status().isForbidden()).andExpect(jsonPath("$.code").value("grantor_lacks_permissions"));
  }

  /** Task 9: CUSTOM roles are account-wide; iam.role.manage through a TENANT-scope assignment only reads them. */
  @Test
  void roleWritesNeedRoleManageAtAccountScope() throws Exception {
    UUID own = createRole("Account wide", c1);
    UUID tenantScoped = fx.user(s.accountId(), s.tenantId());
    fx.assign(tenantScoped, roleManageRole(), ScopeType.TENANT, s.tenantId());
    String bearer = tokens.user(tenantScoped).account(s.accountId()).tenant(s.tenantId()).perms("iam.role.manage")
        .bearer();

    send(post("/api/roles"), bearer, createBody("Nope", c1)).andExpect(status().isForbidden())
        .andExpect(jsonPath("$.code").value("account_scope_required"));
    send(patch("/api/roles/" + own), bearer, java.util.Map.of("name", "Renamed")).andExpect(status().isForbidden())
        .andExpect(jsonPath("$.code").value("account_scope_required"));
    send(put("/api/roles/" + own + "/permissions"), bearer, java.util.Map.of("permissionCodes", java.util.List.of()))
        .andExpect(status().isForbidden()).andExpect(jsonPath("$.code").value("account_scope_required"));
    send(delete("/api/roles/" + own), bearer, null).andExpect(status().isForbidden())
        .andExpect(jsonPath("$.code").value("account_scope_required"));
    send(get("/api/roles/" + own), bearer, null).andExpect(status().isOk());
  }

  private UUID roleManageRole() {
    return fx.systemRole(Product.IAM_ID, fx.permission(Product.IAM_ID, "iam.role.manage"));
  }

  @Test
  void roleNamesAreUniquePerProductAndAccountIgnoringCase() throws Exception {
    createRole("Reviewer", c1);

    send(post("/api/roles"), manager, createBody("reviewer", c1)).andExpect(status().isConflict())
        .andExpect(jsonPath("$.code").value("role_name_exists"));
    send(post("/api/roles"), manager, createBody(" ", c1)).andExpect(status().isBadRequest())
        .andExpect(jsonPath("$.code").value("validation_failed"));
  }

  // ------------------------------------------------------------------------------------------- read

  @Test
  void listsSystemRolesAndOwnCustomRolesOnly() throws Exception {
    UUID own = createRole("Mine", c1);
    Fixtures.Scenario other = fx.scenario();
    UUID foreign = fx.customRole(product, other.accountId(), p1);
    UUID assignee = fx.user(s.accountId(), s.tenantId());
    fx.assign(assignee, own, ScopeType.TENANT, s.tenantId());
    fx.assign(other.userId(), foreign, ScopeType.ACCOUNT, other.accountId());

    String body = send(get("/api/roles").param("productCode", productCode(product)), manager, null)
        .andExpect(status().isOk())
        .andReturn().getResponse().getContentAsString();

    assertThat(body).contains(own.toString()).doesNotContain(foreign.toString());
    send(get("/api/roles").param("productCode", productCode(product)).param("type", "CUSTOM"), manager, null)
        .andExpect(jsonPath("$.items.length()").value(1))
        .andExpect(jsonPath("$.items[0].id").value(own.toString()))
        .andExpect(jsonPath("$.items[0].assignmentCount").value(1))
        .andExpect(jsonPath("$.items[0].permissionCount").value(1));
    send(get("/api/roles").param("productCode", "NOSUCHPRODUCT"), manager, null).andExpect(status().isNotFound());
  }

  @Test
  void rolesCanBeListedWithAssignPermissionToo_ButNotWithoutAnyRolePermission() throws Exception {
    String assigner = tokens.user(s.userId()).account(s.accountId()).tenant(s.tenantId()).perms("iam.role.assign").bearer();
    String nobody = tokens.user(s.userId()).account(s.accountId()).tenant(s.tenantId()).perms("iam.user.manage").bearer();

    send(get("/api/roles").param("productCode", productCode(product)), assigner, null).andExpect(status().isOk());
    send(get("/api/roles"), nobody, null).andExpect(status().isForbidden());
    mvc.perform(get("/api/roles")).andExpect(status().isUnauthorized());
  }

  @Test
  void getReturnsTheRoleWithItsPermissionsAndHidesOtherAccountsRoles() throws Exception {
    UUID own = createRole("Mine", c1, c2);
    Fixtures.Scenario other = fx.scenario();
    UUID foreign = fx.customRole(product, other.accountId(), p1);
    UUID system = fx.systemRole(product, p1);

    send(get("/api/roles/" + own), manager, null).andExpect(status().isOk())
        .andExpect(jsonPath("$.permissions.length()").value(2))
        .andExpect(jsonPath("$.permissions[0].code").isNotEmpty())
        .andExpect(jsonPath("$.permissions[0].kind").value("FEATURE"));
    send(get("/api/roles/" + system), manager, null).andExpect(status().isOk())
        .andExpect(jsonPath("$.type").value("SYSTEM"));
    send(get("/api/roles/" + foreign), manager, null).andExpect(status().isNotFound())
        .andExpect(jsonPath("$.code").value("role_not_found"));
    send(get("/api/roles/" + UUID.randomUUID()), manager, null).andExpect(status().isNotFound());
  }

  // ------------------------------------------------------------------------------------------- update

  @Test
  void patchRenamesWithoutTouchingPermissions() throws Exception {
    UUID id = createRole("Old name", c1, c2);
    long auditBefore = rolePermissionAudit();

    send(patch("/api/roles/" + id), manager, "{\"name\":\"New name\",\"description\":\"New description\"}")
        .andExpect(status().isOk())
        .andExpect(jsonPath("$.name").value("New name"))
        .andExpect(jsonPath("$.description").value("New description"))
        .andExpect(jsonPath("$.permissions.length()").value(2));
    send(patch("/api/roles/" + id), manager, "{\"description\":\"Only text\"}")
        .andExpect(jsonPath("$.name").value("New name")).andExpect(jsonPath("$.description").value("Only text"));

    assertThat(rolePermissionAudit()).isEqualTo(auditBefore);   // no delete+insert churn
    send(patch("/api/roles/" + id), manager, "{}").andExpect(status().isBadRequest())
        .andExpect(jsonPath("$.code").value("empty_update"));
    createRole("Taken", c1);
    send(patch("/api/roles/" + id), manager, "{\"name\":\"taken\"}").andExpect(status().isConflict())
        .andExpect(jsonPath("$.code").value("role_name_exists"));
  }

  @Test
  void systemRolesAreReadOnlyAndOtherAccountsRolesAreInvisible() throws Exception {
    UUID system = fx.systemRole(product, p1);
    UUID foreign = fx.customRole(product, fx.scenario().accountId(), p1);

    send(patch("/api/roles/" + system), manager, "{\"name\":\"Hacked\"}").andExpect(status().isForbidden())
        .andExpect(jsonPath("$.code").value("system_role_read_only"));
    send(put("/api/roles/" + system + "/permissions"), manager, "{\"permissionCodes\":[]}")
        .andExpect(status().isForbidden()).andExpect(jsonPath("$.code").value("system_role_read_only"));
    send(delete("/api/roles/" + system), manager, null).andExpect(status().isForbidden())
        .andExpect(jsonPath("$.code").value("system_role_read_only"));

    send(patch("/api/roles/" + foreign), manager, "{\"name\":\"Hacked\"}").andExpect(status().isNotFound());
    send(put("/api/roles/" + foreign + "/permissions"), manager, "{\"permissionCodes\":[]}").andExpect(status().isNotFound());
    send(delete("/api/roles/" + foreign), manager, null).andExpect(status().isNotFound());
    assertThat(jdbc.sql("SELECT count(*) FROM role WHERE id IN (:ids)").param("ids", List.of(system, foreign))
        .query(Long.class).single()).isEqualTo(2);
  }

  @Test
  void refusingAWriteToASystemRoleTakesNoRowLock() {
    UUID system = fx.systemRole(product, p1);

    // the refused calls mark the surrounding transaction rollback-only, so its commit reports that; the assertions
    // inside run first and an AssertionError would propagate instead
    assertThatThrownBy(() -> tx.execute(status -> {
      assertThatThrownBy(() -> admin.update(s.accountId(), system, "Hacked", null))
          .isInstanceOfSatisfying(ForbiddenException.class, e -> assertThat(e.code()).isEqualTo("system_role_read_only"));
      assertThatThrownBy(() -> admin.delete(s.accountId(), system)).isInstanceOf(ForbiddenException.class);
      // the refusing transaction is still open: another connection must be able to lock the row at once
      Boolean lockable = CompletableFuture.supplyAsync(() -> jdbc.sql(
              "SELECT count(*) = 1 FROM (SELECT id FROM role WHERE id = :id FOR UPDATE NOWAIT) r")
          .param("id", system).query(Boolean.class).single()).orTimeout(20, TimeUnit.SECONDS).join();
      assertThat(lockable).isTrue();
      return null;
    })).isInstanceOf(org.springframework.transaction.UnexpectedRollbackException.class);
  }

  @Test
  void writesAreDeniedWithoutIamRoleManage() throws Exception {
    UUID id = createRole("Guarded", c1);
    String assigner = tokens.user(s.userId()).account(s.accountId()).tenant(s.tenantId()).perms("iam.role.assign").bearer();

    send(patch("/api/roles/" + id), assigner, "{\"name\":\"X\"}").andExpect(status().isForbidden());
    send(put("/api/roles/" + id + "/permissions"), assigner, "{\"permissionCodes\":[]}").andExpect(status().isForbidden());
    send(delete("/api/roles/" + id), assigner, null).andExpect(status().isForbidden());
  }

  // ------------------------------------------------------------------------------- permissions + revocation

  @Test
  void changingTheRolesPermissionsRevokesEveryHolderOnce() throws Exception {
    UUID id = createRole("Holder role", c1);
    UUID h1 = fx.user(s.accountId(), s.tenantId());
    UUID h2 = fx.user(s.accountId(), s.tenantId());
    UUID bystander = fx.user(s.accountId(), s.tenantId());
    fx.assign(h1, id, ScopeType.TENANT, s.tenantId());
    fx.assign(h2, id, ScopeType.ACCOUNT, s.accountId());
    long events = jdbc.sql("SELECT count(*) FROM audit_event WHERE action = 'auth.sessions.revoked'")
        .query(Long.class).single();

    send(put("/api/roles/" + id + "/permissions"), manager, "{\"permissionCodes\":[\"" + c1 + "\",\"" + c2 + "\"]}")
        .andExpect(status().isOk())
        .andExpect(jsonPath("$.permissions.length()").value(2));

    assertThat(sessionVersion(h1)).isEqualTo(2);
    assertThat(sessionVersion(h2)).isEqualTo(2);
    assertThat(sessionVersion(bystander)).isEqualTo(1);
    assertThat(jdbc.sql("SELECT count(*) FROM revocation WHERE user_id IN (:ids)").param("ids", List.of(h1, h2))
        .query(Long.class).single()).isEqualTo(2);
    assertThat(jdbc.sql("SELECT count(*) FROM audit_event WHERE action = 'auth.sessions.revoked'")
        .query(Long.class).single()).isEqualTo(events + 1);
  }

  @Test
  void shrinkingRevokesHoldersAndAnUnchangedSetRevokesNobody() throws Exception {
    UUID id = createRole("Shrinker", c1, c2);
    UUID holder = fx.user(s.accountId(), s.tenantId());
    fx.assign(holder, id, ScopeType.TENANT, s.tenantId());
    long auditBefore = rolePermissionAudit();

    send(put("/api/roles/" + id + "/permissions"), manager, "{\"permissionCodes\":[\"" + c2 + "\",\"" + c1 + "\"]}")
        .andExpect(status().isOk());
    assertThat(sessionVersion(holder)).isEqualTo(1);        // same set in another order: nothing written
    assertThat(rolePermissionAudit()).isEqualTo(auditBefore);

    send(put("/api/roles/" + id + "/permissions"), manager, "{\"permissionCodes\":[\"" + c1 + "\"]}")
        .andExpect(status().isOk()).andExpect(jsonPath("$.permissions.length()").value(1));
    assertThat(sessionVersion(holder)).isEqualTo(2);
    assertThat(jdbc.sql("SELECT count(*) FROM role_permission WHERE role = :id").param("id", id).query(Long.class)
        .single()).isEqualTo(1);
  }

  @Test
  void permissionEditsEnforceI3AndI6() throws Exception {
    UUID id = createRole("Editable", c1);
    UUID holder = fx.user(s.accountId(), s.tenantId());
    fx.assign(holder, id, ScopeType.TENANT, s.tenantId());
    UUID foreign = fx.permission(fx.product());

    send(put("/api/roles/" + id + "/permissions"), manager, "{\"permissionCodes\":[\"" + c1 + "\",\"" + c3 + "\"]}")
        .andExpect(status().isForbidden()).andExpect(jsonPath("$.code").value("grantor_lacks_permissions"))
        .andExpect(jsonPath("$.missingPermissions[0]").value(c3));
    send(put("/api/roles/" + id + "/permissions"), manager, "{\"permissionCodes\":[\"" + fx.code(foreign) + "\"]}")
        .andExpect(status().isBadRequest()).andExpect(jsonPath("$.code").value("permission_product_mismatch"));
    assertThat(sessionVersion(holder)).isEqualTo(1);       // nothing changed, nobody revoked

    // removing a permission the caller does not hold is allowed (no I6 on removal)
    jdbc.sql("INSERT INTO role_permission (role, permission_id) VALUES (:r, :p)").param("r", id).param("p", p3).update();
    send(put("/api/roles/" + id + "/permissions"), manager, "{\"permissionCodes\":[\"" + c1 + "\"]}")
        .andExpect(status().isOk());
    assertThat(sessionVersion(holder)).isEqualTo(2);
  }

  // ------------------------------------------------------------------------------------------- delete

  @Test
  void aRoleThatIsAssignedCannotBeDeleted() throws Exception {
    UUID id = createRole("In use", c1);
    UUID u1 = fx.user(s.accountId(), s.tenantId());
    UUID u2 = fx.user(s.accountId(), s.tenantId());
    UUID a1 = fx.assign(u1, id, ScopeType.TENANT, s.tenantId());
    fx.assign(u2, id, ScopeType.ACCOUNT, s.accountId());

    send(delete("/api/roles/" + id), manager, null).andExpect(status().isConflict())
        .andExpect(jsonPath("$.code").value("role_in_use"))
        .andExpect(jsonPath("$.count").value(2));

    jdbc.sql("DELETE FROM role_assignment WHERE role_id = :id").param("id", id).update();
    send(delete("/api/roles/" + id), manager, null).andExpect(status().isNoContent());
    assertThat(jdbc.sql("SELECT count(*) FROM role WHERE id = :id").param("id", id).query(Long.class).single()).isZero();
    assertThat(jdbc.sql("SELECT count(*) FROM role_permission WHERE role = :id").param("id", id).query(Long.class)
        .single()).isZero();
    send(delete("/api/roles/" + id), manager, null).andExpect(status().isNotFound());
    assertThat(a1).isNotNull();
  }
}
