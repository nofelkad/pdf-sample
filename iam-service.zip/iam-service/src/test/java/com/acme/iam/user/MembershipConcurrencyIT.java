package com.acme.iam.user;

import static org.assertj.core.api.Assertions.assertThat;

import com.acme.iam.assignment.AssignmentService;
import com.acme.iam.assignment.ScopeType;
import com.acme.iam.common.error.ConflictException;
import com.acme.iam.common.security.CodedAccessDeniedException;
import com.acme.iam.common.test.Fixtures;
import com.acme.iam.common.test.IntegrationTest;
import com.acme.iam.common.test.OrgTestData;
import com.acme.iam.common.test.PostgresTestBase;
import com.acme.iam.product.Product;
import java.time.Duration;
import java.time.Instant;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.simple.JdbcClient;
import org.springframework.transaction.support.TransactionTemplate;

/**
 * I2 under concurrency: a TENANT-scope assignment racing with the removal of that membership never survives the
 * removal (committed data, real transactions on two connections).
 */
@IntegrationTest
class MembershipConcurrencyIT extends PostgresTestBase {

  @Autowired MembershipService memberships;
  @Autowired AssignmentService assignments;
  @Autowired UserAdminService userAdmin;
  @Autowired JdbcClient jdbc;
  @Autowired TransactionTemplate tx;

  Fixtures fx;
  UUID account;
  UUID tenantB;
  UUID user;
  UUID role;

  @BeforeEach
  void setUp() {
    fx = new Fixtures(jdbc);
    Fixtures.Scenario s = fx.scenario();
    account = s.accountId();
    user = s.userId();
    tenantB = fx.tenant(account);
    fx.membership(user, tenantB, MembershipStatus.ACTIVE);
    role = fx.systemRole(Product.IAM_ID, fx.permission(Product.IAM_ID));
  }

  @Test
  void aRemovalWaitingOnAnInFlightAssignmentAlsoDeletesIt() throws Exception {
    CountDownLatch assigned = new CountDownLatch(1);
    CountDownLatch release = new CountDownLatch(1);

    CompletableFuture<Void> assign = CompletableFuture.runAsync(() -> tx.executeWithoutResult(s -> {
      assignments.grantAsSystem(user, role, ScopeType.TENANT, tenantB, null, null); // holds the membership FOR SHARE
      assigned.countDown();
      await(release);
    }));
    await(assigned);
    CompletableFuture<Void> remove = CompletableFuture.runAsync(() -> memberships.remove(account, user, tenantB));
    waitUntilSomeoneWaitsOnALock();
    release.countDown();

    assign.get(30, TimeUnit.SECONDS);
    remove.get(30, TimeUnit.SECONDS);
    assertThat(tenantScopeAssignmentsInB()).isZero();
    assertThat(jdbc.sql("SELECT count(*) FROM user_tenant_membership WHERE app_user = :u AND tenant_id = :t")
        .param("u", user).param("t", tenantB).query(Long.class).single()).isZero();
  }

  @Test
  void anAssignmentWaitingOnAnInFlightRemovalIsRefused() throws Exception {
    CountDownLatch removed = new CountDownLatch(1);
    CountDownLatch release = new CountDownLatch(1);

    CompletableFuture<Void> remove = CompletableFuture.runAsync(() -> tx.executeWithoutResult(s -> {
      jdbc.sql("DELETE FROM user_tenant_membership WHERE app_user = :u AND tenant_id = :t")
          .param("u", user).param("t", tenantB).update(); // what MembershipService.remove does first
      removed.countDown();
      await(release);
    }));
    await(removed);
    CompletableFuture<String> assign = CompletableFuture.supplyAsync(() -> {
      try {
        assignments.grantAsSystem(user, role, ScopeType.TENANT, tenantB, null, null);
        return "assigned";
      } catch (ConflictException e) {
        return e.code();
      }
    });
    waitUntilSomeoneWaitsOnALock();
    release.countDown();

    remove.get(30, TimeUnit.SECONDS);
    assertThat(assign.get(30, TimeUnit.SECONDS)).isEqualTo("membership_required");
    assertThat(tenantScopeAssignmentsInB()).isZero();
  }

  @Test
  void i9_deprovisionWaitsForAnInFlightTenantAssignmentAndRemovesIt() throws Exception {
    UUID tenantA = jdbc.sql("SELECT primary_tenant_id FROM app_user WHERE id = :u").param("u", user)
        .query(UUID.class).single();
    CountDownLatch assigned = new CountDownLatch(1);
    CountDownLatch release = new CountDownLatch(1);

    CompletableFuture<Void> assign = CompletableFuture.runAsync(() -> tx.executeWithoutResult(s -> {
      assignments.grantAsSystem(user, role, ScopeType.TENANT, tenantA, null, null); // primary membership FOR SHARE
      assigned.countDown();
      await(release);
    }));
    await(assigned);
    UUID admin = new OrgTestData(jdbc).accountAdmin(account, tenantA);
    CompletableFuture<Void> deprovision = CompletableFuture.runAsync(() -> {
      Fixtures.actAs(admin, account, tenantA); // the in-transaction R28 re-check needs the acting user
      try {
        userAdmin.deprovision(account, user);
      } finally {
        Fixtures.clearActor();
      }
    });
    waitUntilSomeoneWaitsOnALock();
    release.countDown();

    assign.get(30, TimeUnit.SECONDS);
    deprovision.get(30, TimeUnit.SECONDS);
    assertThat(jdbc.sql("SELECT count(*) FROM role_assignment WHERE user_id = :u").param("u", user)
        .query(Long.class).single()).isZero();

    // afterwards the user is DEPROVISIONED (and its primary membership SUSPENDED), so any grant fails; since Task 9 the
    // status check (user_not_active) comes before I1 (membership_required)
    assertThat(jdbc.sql("SELECT status FROM user_tenant_membership WHERE app_user = :u AND tenant_id = :t")
        .param("u", user).param("t", tenantA).query(String.class).single()).isEqualTo("SUSPENDED");
    String outcome;
    try {
      assignments.grantAsSystem(user, role, ScopeType.TENANT, tenantA, null, null);
      outcome = "assigned";
    } catch (ConflictException e) {
      outcome = e.code();
    }
    assertThat(outcome).isEqualTo("user_not_active");
  }

  /**
   * R28 in the transaction: a Tenant Admin's disable of a tenant-local user races with an account-scope grant to that
   * user. The grant locks the user row first, the disable waits for it and then sees a user that is no longer
   * tenant-local.
   */
  @Test
  void r28_aConcurrentAccountScopeGrantMakesATenantAdminsDisableFail() throws Exception {
    UUID tenantA = jdbc.sql("SELECT primary_tenant_id FROM app_user WHERE id = :u").param("u", user)
        .query(UUID.class).single();
    UUID local = fx.user(account, tenantA);
    UUID tenantAdmin = tenantAdmin(tenantA);
    CountDownLatch granted = new CountDownLatch(1);
    CountDownLatch release = new CountDownLatch(1);

    CompletableFuture<Void> grant = CompletableFuture.runAsync(() -> tx.executeWithoutResult(s -> {
      assignments.grantAsSystem(local, role, ScopeType.ACCOUNT, account, null, null);
      granted.countDown();
      await(release);
    }));
    await(granted);
    CompletableFuture<String> disable = CompletableFuture.supplyAsync(() -> disableAs(tenantAdmin, tenantA, local));
    waitUntilSomeoneWaitsOnALock();
    release.countDown();

    grant.get(30, TimeUnit.SECONDS);
    assertThat(disable.get(30, TimeUnit.SECONDS)).isEqualTo("account_scope_required");
    assertThat(status(local)).isEqualTo("ACTIVE");
  }

  /** Same race with a share into another tenant (by an account-scope admin) instead of a grant. */
  @Test
  void r28_aConcurrentShareMakesATenantAdminsDisableFail() throws Exception {
    UUID tenantA = jdbc.sql("SELECT primary_tenant_id FROM app_user WHERE id = :u").param("u", user)
        .query(UUID.class).single();
    UUID local = fx.user(account, tenantA);
    UUID tenantAdmin = tenantAdmin(tenantA);
    CountDownLatch shared = new CountDownLatch(1);
    CountDownLatch release = new CountDownLatch(1);

    CompletableFuture<Void> share = CompletableFuture.runAsync(() -> tx.executeWithoutResult(s -> {
      memberships.add(account, local, tenantB);
      shared.countDown();
      await(release);
    }));
    await(shared);
    CompletableFuture<String> disable = CompletableFuture.supplyAsync(() -> disableAs(tenantAdmin, tenantA, local));
    waitUntilSomeoneWaitsOnALock();
    release.countDown();

    share.get(30, TimeUnit.SECONDS);
    assertThat(disable.get(30, TimeUnit.SECONDS)).isEqualTo("account_scope_required");
    assertThat(status(local)).isEqualTo("ACTIVE");
  }

  /** A member of {@code tenant} holding {@code iam.user.manage} at TENANT scope only. */
  private UUID tenantAdmin(UUID tenant) {
    UUID admin = fx.user(account, tenant);
    UUID manage = fx.systemRole(Product.IAM_ID, fx.permission(Product.IAM_ID, "iam.user.manage"));
    fx.assign(admin, manage, ScopeType.TENANT, tenant);
    return admin;
  }

  private String disableAs(UUID actor, UUID activeTenant, UUID target) {
    Fixtures.actAs(actor, account, activeTenant);
    try {
      userAdmin.disable(account, target);
      return "disabled";
    } catch (CodedAccessDeniedException e) {
      return e.code();
    } finally {
      Fixtures.clearActor();
    }
  }

  private String status(UUID userId) {
    return jdbc.sql("SELECT status FROM app_user WHERE id = :u").param("u", userId).query(String.class).single();
  }

  private long tenantScopeAssignmentsInB() {
    return jdbc.sql("""
            SELECT count(*) FROM role_assignment WHERE user_id = :u AND scope_type = 'TENANT' AND scope_id = :t""")
        .param("u", user).param("t", tenantB).query(Long.class).single();
  }

  private void waitUntilSomeoneWaitsOnALock() throws InterruptedException {
    Instant deadline = Instant.now().plus(Duration.ofSeconds(3));
    while (Instant.now().isBefore(deadline)) {
      if (jdbc.sql("SELECT count(*) FROM pg_locks WHERE NOT granted").query(Long.class).single() > 0) {
        return;
      }
      Thread.sleep(20);
    }
  }

  private static void await(CountDownLatch latch) {
    try {
      if (!latch.await(30, TimeUnit.SECONDS)) {
        throw new IllegalStateException("latch timeout");
      }
    } catch (InterruptedException e) {
      Thread.currentThread().interrupt();
      throw new IllegalStateException(e);
    }
  }
}
