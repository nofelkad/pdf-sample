package com.acme.iam.audit;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

import ch.qos.logback.classic.Level;
import ch.qos.logback.classic.Logger;
import ch.qos.logback.classic.spi.ILoggingEvent;
import ch.qos.logback.core.read.ListAppender;
import com.acme.iam.common.test.IntegrationTest;
import com.acme.iam.common.test.PostgresTestBase;
import io.micrometer.core.instrument.MeterRegistry;
import java.time.Clock;
import java.time.YearMonth;
import java.time.ZoneOffset;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.atomic.AtomicInteger;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.simple.JdbcClient;

/** P1-9.2 (partition job) and P1-9.3 (retention job + the SECURITY DEFINER detach function, Ruling R3). */
@IntegrationTest
class AuditPartitionJobsIT extends PostgresTestBase {

  private static final YearMonth OLD_1 = YearMonth.of(2015, 3);
  private static final YearMonth OLD_2 = YearMonth.of(2015, 4);

  @Autowired JdbcClient jdbc;
  @Autowired AuditPartitionService partitionService;
  @Autowired AuditPartitions partitions;
  @Autowired AuditWriter auditWriter;
  @Autowired MeterRegistry meters;
  @Autowired Clock clock;

  private final AuditTestPartitions ddl = new AuditTestPartitions();
  private ListAppender<ILoggingEvent> logs;

  @BeforeEach
  void setUp() {
    logs = new ListAppender<>();
    logs.start();
    ((Logger) LoggerFactory.getLogger(AuditPartitionService.class)).addAppender(logs);
  }

  @AfterEach
  void tearDown() {
    ((Logger) LoggerFactory.getLogger(AuditPartitionService.class)).detachAppender(logs);
    ddl.drop(OLD_1);
    ddl.drop(OLD_2);
    ddl.migrator().sql("DROP TABLE IF EXISTS audit_event_y2016m01").update();
    partitionService.ensurePartitions();   // restore the horizon whatever a test did
  }

  private YearMonth now() {
    return YearMonth.now(clock.withZone(ZoneOffset.UTC));
  }

  // ------------------------------------------------------------------------------------------ P1-9.2

  @Test
  void startupAndDailyJobKeepThreeFutureMonths() {
    partitionService.ensurePartitions();

    YearMonth current = now();
    assertThat(partitions.existing()).contains(current, current.plusMonths(1), current.plusMonths(2),
        current.plusMonths(3));
    assertThat(gauge()).isEqualTo(3.0);
  }

  @Test
  void ensureCreatesTheMissingMonthsAndIsIdempotent() {
    YearMonth current = now();
    ddl.drop(current.plusMonths(2));
    ddl.drop(current.plusMonths(3));

    assertThat(partitionService.ensurePartitions()).isEqualTo(2);
    assertThat(gauge()).isEqualTo(3.0);
    assertThat(partitionService.ensurePartitions()).isZero();
  }

  @Test
  void gaugeDropsAndErrorIsLoggedWhenFewerThanTwoFutureMonthsExist() {
    YearMonth current = now();
    ddl.drop(current.plusMonths(3));
    ddl.drop(current.plusMonths(2));
    ddl.drop(current.plusMonths(1));

    assertThat(partitionService.refreshGauge()).isZero();

    assertThat(gauge()).isZero();
    assertThat(logs.list).anySatisfy(e -> {
      assertThat(e.getLevel()).isEqualTo(Level.ERROR);
      assertThat(e.getFormattedMessage()).contains("future audit_event partition");
    });
  }

  @Test
  void noErrorWhenTheHorizonIsHealthy() {
    partitionService.ensurePartitions();
    logs.list.clear();

    partitionService.refreshGauge();

    assertThat(logs.list).noneMatch(e -> e.getLevel() == Level.ERROR);
  }

  @Test
  void concurrentCallersDoNotFailAndCreateEachPartitionOnce() throws Exception {
    YearMonth current = now();
    ddl.drop(current.plusMonths(3));
    ddl.drop(current.plusMonths(2));
    AtomicInteger created = new AtomicInteger();

    ExecutorService pool = Executors.newFixedThreadPool(4);
    try {
      List<Callable<Integer>> calls = new ArrayList<>();
      for (int i = 0; i < 12; i++) {
        calls.add(() -> jdbc.sql("SELECT audit_ensure_partitions(3)").query(Integer.class).single());
      }
      for (Future<Integer> f : pool.invokeAll(calls)) {
        created.addAndGet(f.get());   // rethrows a DDL race as ExecutionException
      }
    } finally {
      pool.shutdownNow();
    }

    assertThat(created.get()).isEqualTo(2);
    assertThat(partitions.existing()).contains(current.plusMonths(2), current.plusMonths(3));
  }

  @Test
  void ensureStaysSecurityDefiner() {
    var row = jdbc.sql("""
            SELECT prosecdef, pg_get_userbyid(proowner) AS owner,
                   array_to_string(proconfig, ',') AS config, has_function_privilege('iam_app', oid, 'EXECUTE') AS app,
                   has_function_privilege('public', oid, 'EXECUTE') AS everyone
            FROM pg_proc WHERE proname = 'audit_ensure_partitions'""")
        .query().singleRow();

    assertThat(row.get("prosecdef")).isEqualTo(true);
    assertThat(row.get("owner")).isEqualTo(MIGRATOR_USER);
    assertThat((String) row.get("config")).contains("search_path=public, pg_temp");
    assertThat(row.get("app")).isEqualTo(true);
    assertThat(row.get("everyone")).isEqualTo(false);
  }

  // ------------------------------------------------------------------------------------------ P1-9.3

  @Test
  void detachFunctionDropsAnOldPartitionAsTheAppRole() {
    ddl.create(OLD_1);

    boolean dropped = jdbc.sql("SELECT audit_detach_partition(:n)").param("n", AuditPartitions.nameOf(OLD_1))
        .query(Boolean.class).single();

    assertThat(dropped).isTrue();
    assertThat(ddl.exists(OLD_1)).isFalse();
    assertThat(partitions.existing()).doesNotContain(OLD_1);
  }

  @Test
  void detachFunctionReturnsFalseForAnUnknownValidName() {
    assertThat(jdbc.sql("SELECT audit_detach_partition('audit_event_y2001m01')").query(Boolean.class).single())
        .isFalse();
  }

  @Test
  void detachFunctionRejectsBadNames() {
    for (String bad : List.of("audit_event_y2015m13", "audit_event_y2015m00", "audit_event_y15m03", "audit_event",
        "account", "pg_class", "audit_event_y2015m03; DROP TABLE account", "AUDIT_EVENT_Y2015M03",
        "public.audit_event_y2015m03", "")) {
      assertThatThrownBy(() -> jdbc.sql("SELECT audit_detach_partition(:n)").param("n", bad).query().singleValue())
          .as(bad)
          .isInstanceOf(DataAccessException.class)
          .hasMessageContaining("invalid audit partition name");
    }
    assertThat(jdbc.sql("SELECT count(*) FROM account").query(Long.class).single()).isNotNull();   // still there
  }

  @Test
  void detachFunctionRefusesATableThatIsNotAChildOfAuditEvent() {
    ddl.migrator().sql("CREATE TABLE audit_event_y2016m01 (LIKE audit_event)").update();

    assertThatThrownBy(() -> jdbc.sql("SELECT audit_detach_partition('audit_event_y2016m01')").query().singleValue())
        .isInstanceOf(DataAccessException.class)
        .hasMessageContaining("is not a partition of audit_event");
    assertThat(ddl.exists("audit_event_y2016m01")).isTrue();
  }

  @Test
  void detachFunctionRefusesRecentPartitions() {
    for (YearMonth recent : List.of(now(), now().minusMonths(1), now().plusMonths(1))) {
      String name = AuditPartitions.nameOf(recent);
      assertThatThrownBy(() -> jdbc.sql("SELECT audit_detach_partition(:n)").param("n", name).query().singleValue())
          .as(name)
          .isInstanceOf(DataAccessException.class)
          .hasMessageContaining("less than 90 days ago");
    }
  }

  @Test
  void appRoleCannotDetachOrDropAPartitionDirectly() {
    ddl.create(OLD_1);

    assertThatThrownBy(() -> jdbc.sql("ALTER TABLE audit_event DETACH PARTITION " + AuditPartitions.nameOf(OLD_1)).update())
        .isInstanceOf(DataAccessException.class).rootCause().hasMessageContaining("must be owner");
    assertThatThrownBy(() -> jdbc.sql("DROP TABLE " + AuditPartitions.nameOf(OLD_1)).update())
        .isInstanceOf(DataAccessException.class).rootCause().hasMessageContaining("must be owner");
    assertThat(ddl.exists(OLD_1)).isTrue();
  }

  @Test
  void retentionWithTheRefusingHookDropsNothing() {
    ddl.create(OLD_1);
    ddl.create(OLD_2);
    AuditRetentionService service = retention(new RefusingArchiveHook(), "P1Y");

    assertThat(service.enforce()).isEmpty();

    assertThat(ddl.exists(OLD_1)).isTrue();
    assertThat(ddl.exists(OLD_2)).isTrue();
  }

  @Test
  void retentionDropsOnlyPartitionsTheHookArchived() {
    ddl.create(OLD_1);
    ddl.create(OLD_2);
    List<String> offered = new ArrayList<>();
    AuditArchiveHook onlyFirst = name -> {
      offered.add(name);
      return name.equals(AuditPartitions.nameOf(OLD_1));
    };

    List<String> dropped = retention(onlyFirst, "P1Y").enforce();

    assertThat(dropped).containsExactly(AuditPartitions.nameOf(OLD_1));
    assertThat(offered).contains(AuditPartitions.nameOf(OLD_1), AuditPartitions.nameOf(OLD_2));
    assertThat(ddl.exists(OLD_1)).isFalse();
    assertThat(ddl.exists(OLD_2)).isTrue();
  }

  @Test
  void retentionOffersPartitionsOldestFirstAndNeverTheCurrentOnes() {
    ddl.create(OLD_2);
    ddl.create(OLD_1);
    List<String> offered = new ArrayList<>();

    retention(name -> {
      offered.add(name);
      return false;
    }, "P1Y").enforce();

    assertThat(offered).containsSubsequence(AuditPartitions.nameOf(OLD_1), AuditPartitions.nameOf(OLD_2));
    assertThat(offered).doesNotContain(AuditPartitions.nameOf(now()), AuditPartitions.nameOf(now().plusMonths(1)));
  }

  @Test
  void aHookThatThrowsKeepsThePartitionAndDoesNotStopTheRun() {
    ddl.create(OLD_1);
    ddl.create(OLD_2);
    AuditArchiveHook flaky = name -> {
      if (name.equals(AuditPartitions.nameOf(OLD_1))) {
        throw new IllegalStateException("pg_dump failed");
      }
      return true;
    };

    List<String> dropped = retention(flaky, "P1Y").enforce();

    assertThat(dropped).containsExactly(AuditPartitions.nameOf(OLD_2));
    assertThat(ddl.exists(OLD_1)).isTrue();
  }

  @Test
  void retentionKeepsPartitionsInsideThePeriod() {
    YearMonth threeMonthsAgo = now().minusMonths(4);
    ddl.create(threeMonthsAgo);
    try {
      List<String> dropped = retention(name -> true, "P1Y").enforce();

      assertThat(dropped).doesNotContain(AuditPartitions.nameOf(threeMonthsAgo));
      assertThat(ddl.exists(threeMonthsAgo)).isTrue();
    } finally {
      ddl.drop(threeMonthsAgo);
    }
  }

  @Test
  void retentionWritesAnAuditEventForEveryDroppedPartition() {
    ddl.create(OLD_1);

    retention(name -> true, "P1Y").enforce();

    var event = jdbc.sql("""
            SELECT actor_type, source, outcome, metadata->>'retention' AS retention
            FROM audit_event WHERE action = 'iam.audit.partition.dropped' AND target_id = :n""")
        .param("n", AuditPartitions.nameOf(OLD_1)).query().singleRow();
    assertThat(event).containsEntry("actor_type", "SYSTEM").containsEntry("source", "IAM")
        .containsEntry("outcome", "SUCCESS").containsEntry("retention", "P1Y");
  }

  @Test
  void retentionBelowTheNinetyDayFloorIsRejectedAtStartup() {
    assertThatThrownBy(() -> retention(name -> true, "P30D")).isInstanceOf(IllegalArgumentException.class)
        .hasMessageContaining("at least 90 days");
    assertThatThrownBy(() -> retention(name -> true, "P-1Y")).isInstanceOf(IllegalArgumentException.class);
    retention(name -> true, "P90D");
  }

  @Test
  void defaultRetentionIsSevenYears() {
    ddl.create(OLD_1);   // 2015 is more than 7 years before 2026-10, but the default hook refuses
    assertThat(retention(new RefusingArchiveHook(), "P7Y").expired()).contains(OLD_1);
    assertThat(retention(new RefusingArchiveHook(), "P7Y").expired()).doesNotContain(now().minusYears(1));
  }

  private AuditRetentionService retention(AuditArchiveHook hook, String period) {
    return new AuditRetentionService(jdbc, partitions, hook, auditWriter, clock, period);
  }

  private double gauge() {
    return meters.get(AuditPartitionService.GAUGE).gauge().value();
  }
}
