package com.acme.iam.auth;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.List;
import org.junit.jupiter.api.Test;
import org.springframework.mock.web.MockHttpServletRequest;

/**
 * Client IP (R35): {@code getRemoteAddr()} unless the peer is a trusted proxy; then the right-most
 * {@code X-Forwarded-For} entry that is not itself a trusted proxy (proxies append, so the left entries are
 * client-controlled).
 */
class ClientInfoResolverTest {

  @Test
  void usesTheRemoteAddressWhenNoProxyIsTrusted() {
    MockHttpServletRequest request = request("10.0.0.5", "203.0.113.9");

    ClientInfo info = new ClientInfoResolver(List.of()).resolve(request);

    assertThat(info.ip()).isEqualTo("10.0.0.5");
  }

  @Test
  void usesTheRightMostForwardedForEntryWhenThePeerIsATrustedProxy() {
    MockHttpServletRequest request = request("10.0.0.5", "203.0.113.9");

    ClientInfo info = new ClientInfoResolver(List.of("10.0.0.5")).resolve(request);

    assertThat(info.ip()).isEqualTo("203.0.113.9");
  }

  @Test
  void aSpoofedLeftMostEntryIsIgnored() {
    // the client sent "X-Forwarded-For: 1.1.1.1"; the load balancer appended the real peer
    MockHttpServletRequest request = request("10.0.0.5", "1.1.1.1, 203.0.113.9");

    ClientInfo info = new ClientInfoResolver(List.of("10.0.0.5")).resolve(request);

    assertThat(info.ip()).isEqualTo("203.0.113.9");
  }

  @Test
  void readsEveryForwardedForHeaderLineNotJustTheFirst() {
    // the client sent its own (spoofed) line; a proxy such as HAProxy added a second line instead of appending
    MockHttpServletRequest request = request("10.0.0.5", "1.1.1.1, 2.2.2.2");
    request.addHeader("X-Forwarded-For", "203.0.113.9");

    ClientInfo info = new ClientInfoResolver(List.of("10.0.0.5")).resolve(request);

    assertThat(info.ip()).isEqualTo("203.0.113.9");
  }

  @Test
  void skipsTrustedProxiesInTheChainFromTheRight() {
    MockHttpServletRequest request = request("10.0.0.5", "1.1.1.1, 203.0.113.9, 10.0.0.7");

    ClientInfo info = new ClientInfoResolver(List.of("10.0.0.5", "10.0.0.7")).resolve(request);

    assertThat(info.ip()).isEqualTo("203.0.113.9");
  }

  @Test
  void ignoresForwardedForFromAnUntrustedPeer() {
    MockHttpServletRequest request = request("198.51.100.1", "203.0.113.9");

    ClientInfo info = new ClientInfoResolver(List.of("10.0.0.5")).resolve(request);

    assertThat(info.ip()).isEqualTo("198.51.100.1");
  }

  @Test
  void fallsBackToThePeerWhenTheRelevantForwardedEntryIsNotAnIp() {
    MockHttpServletRequest request = request("10.0.0.5", "1.2.3.4, evil.example");

    ClientInfo info = new ClientInfoResolver(List.of("10.0.0.5")).resolve(request);

    assertThat(info.ip()).isEqualTo("10.0.0.5");
  }

  @Test
  void capturesAndTruncatesTheUserAgent() {
    MockHttpServletRequest request = request("10.0.0.5", null);
    request.addHeader("User-Agent", "x".repeat(2000));

    ClientInfo info = new ClientInfoResolver(List.of()).resolve(request);

    assertThat(info.userAgent()).hasSize(ClientInfo.MAX_USER_AGENT);
  }

  // ------------------------------------------------------------------------- final review I3: CIDR ranges

  @Test
  void aCidrRangeTrustsEveryPeerInsideIt() {
    ClientInfoResolver resolver = new ClientInfoResolver(List.of("10.0.0.0/8", "192.168.1.0/24"));

    assertThat(resolver.resolve(request("10.20.30.40", "203.0.113.9")).ip()).isEqualTo("203.0.113.9");
    assertThat(resolver.resolve(request("192.168.1.254", "203.0.113.9")).ip()).isEqualTo("203.0.113.9");
    assertThat(resolver.resolve(request("192.168.2.1", "203.0.113.9")).ip()).as("outside /24").isEqualTo("192.168.2.1");
    assertThat(resolver.resolve(request("11.0.0.1", "203.0.113.9")).ip()).as("outside /8").isEqualTo("11.0.0.1");
  }

  @Test
  void cidrRangesAlsoSkipProxiesInTheForwardedChain() {
    ClientInfoResolver resolver = new ClientInfoResolver(List.of("10.0.0.0/16"));

    ClientInfo info = resolver.resolve(request("10.0.1.1", "1.1.1.1, 203.0.113.9, 10.0.200.3, 10.0.7.7"));

    assertThat(info.ip()).isEqualTo("203.0.113.9");
  }

  @Test
  void ipv6RangesAndEquivalentSpellingsMatch() {
    ClientInfoResolver resolver = new ClientInfoResolver(List.of("fd00::/8", "::1"));

    assertThat(resolver.resolve(request("fd12:3456::1", "2001:db8::7")).ip()).isEqualTo("2001:db8::7");
    assertThat(resolver.resolve(request("0:0:0:0:0:0:0:1", "203.0.113.9")).ip()).isEqualTo("203.0.113.9");
    assertThat(resolver.resolve(request("fe80::1", "203.0.113.9")).ip()).isEqualTo("fe80::1");
    assertThat(resolver.resolve(request("10.0.0.1", "203.0.113.9")).ip()).as("IPv4 never matches IPv6 ranges")
        .isEqualTo("10.0.0.1");
  }

  @Test
  void aSlashZeroRangeTrustsEveryone() {
    assertThat(new ClientInfoResolver(List.of("0.0.0.0/0")).resolve(request("8.8.8.8", "203.0.113.9")).ip())
        .isEqualTo("203.0.113.9");
  }

  @Test
  void malformedEntriesFailAtStartup() {
    for (String bad : List.of("10.0.0.0/33", "10.0.0/8", "lb.internal", "10.0.0.0/x", "::/129")) {
      org.assertj.core.api.Assertions.assertThatThrownBy(() -> new ClientInfoResolver(List.of(bad)))
          .as(bad).isInstanceOf(IllegalArgumentException.class).hasMessageContaining("trusted-proxies");
    }
  }

  @Test
  void warnsOnlyOutsideDevLocalAndTestWhenNoProxyIsTrusted() {
    org.springframework.mock.env.MockEnvironment prod = new org.springframework.mock.env.MockEnvironment();
    org.springframework.mock.env.MockEnvironment dev = new org.springframework.mock.env.MockEnvironment();
    dev.setActiveProfiles("dev");
    org.springframework.mock.env.MockEnvironment test = new org.springframework.mock.env.MockEnvironment();
    test.setActiveProfiles("test");

    assertThat(ClientInfoResolver.missingProxiesWarning(prod, List.of())).isPresent();
    assertThat(ClientInfoResolver.missingProxiesWarning(prod, List.of("10.0.0.0/8"))).isEmpty();
    assertThat(ClientInfoResolver.missingProxiesWarning(dev, List.of())).isEmpty();
    assertThat(ClientInfoResolver.missingProxiesWarning(test, List.of())).isEmpty();
  }

  private static MockHttpServletRequest request(String remote, String forwardedFor) {
    MockHttpServletRequest request = new MockHttpServletRequest();
    request.setRemoteAddr(remote);
    if (forwardedFor != null) {
      request.addHeader("X-Forwarded-For", forwardedFor);
    }
    return request;
  }
}
