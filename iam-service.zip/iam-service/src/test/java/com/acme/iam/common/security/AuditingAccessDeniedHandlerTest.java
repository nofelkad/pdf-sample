package com.acme.iam.common.security;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;

import com.acme.iam.audit.AuditEvent;
import com.acme.iam.audit.AuditWriter;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.util.Map;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.security.core.context.SecurityContextHolder;

/** Task 9 (deferred fix E5): the reserved metadata keys of {@code authz.denied} cannot be overwritten. */
class AuditingAccessDeniedHandlerTest {

  private final AuditWriter writer = mock(AuditWriter.class);
  private final AuditingAccessDeniedHandler handler =
      new AuditingAccessDeniedHandler(writer, new SecurityProblemWriter(new ObjectMapper()));

  @AfterEach
  void clear() {
    SecurityContextHolder.clearContext();
  }

  @Test
  void reservedKeysWinOverCodedMetadata() throws Exception {
    MockHttpServletRequest request = new MockHttpServletRequest("DELETE", "/api/roles/1");
    CodedAccessDeniedException denied = new CodedAccessDeniedException("scope_exceeded", "no",
        Map.of("method", "GET", "path", "/forged", "reason", "forged", "tenantId", "t-1"));

    handler.handle(request, new MockHttpServletResponse(), denied);

    ArgumentCaptor<AuditEvent> event = ArgumentCaptor.forClass(AuditEvent.class);
    verify(writer).writeIndependently(event.capture());
    assertThat(event.getValue().metadata())
        .containsEntry("method", "DELETE")
        .containsEntry("path", "/api/roles/1")
        .containsEntry("reason", "scope_exceeded")
        .containsEntry("tenantId", "t-1");
  }
}
