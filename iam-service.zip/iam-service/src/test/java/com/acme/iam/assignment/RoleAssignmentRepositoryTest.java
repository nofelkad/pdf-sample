package com.acme.iam.assignment;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

import com.acme.iam.common.test.Fixtures;
import com.acme.iam.common.test.JdbcSliceTest;
import com.acme.iam.common.test.PostgresTestBase;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.UUID;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.dao.OptimisticLockingFailureException;
import org.springframework.jdbc.core.simple.JdbcClient;

/** P1-3.3: RoleAssignment round trip. */
@JdbcSliceTest
class RoleAssignmentRepositoryTest extends PostgresTestBase {

  @Autowired RoleAssignmentRepository assignments;
  @Autowired JdbcClient jdbc;

  @Test
  void roundTripsAssignment() {
    Fixtures fx = new Fixtures(jdbc);
    Fixtures.Scenario s = fx.scenario();
    UUID role = fx.systemRole(fx.product());
    Instant expires = Instant.now().plus(7, ChronoUnit.DAYS).truncatedTo(ChronoUnit.MICROS);

    RoleAssignment saved = assignments.save(
        RoleAssignment.create(s.userId(), role, ScopeType.TENANT, s.tenantId(), s.userId(), expires));
    assertThat(saved.version()).isZero();
    assertThat(saved.grantedAt()).isNotNull();

    RoleAssignment loaded = assignments.findById(saved.id()).orElseThrow();
    assertThat(loaded.user()).isEqualTo(s.userId());
    assertThat(loaded.role()).isEqualTo(role);
    assertThat(loaded.scopeType()).isEqualTo(ScopeType.TENANT);
    assertThat(loaded.scopeId()).isEqualTo(s.tenantId());
    assertThat(loaded.grantor()).isEqualTo(s.userId());
    assertThat(loaded.expiresAt()).isEqualTo(expires);
    assertThat(loaded.isExpired(Instant.now())).isFalse();

    assertThat(assignments.findAllByUser(s.userId())).extracting(RoleAssignment::id).containsExactly(saved.id());
    assertThat(assignments.findAllByRole(role)).extracting(RoleAssignment::id).containsExactly(saved.id());

    assertThatThrownBy(() -> assignments.save(
        RoleAssignment.create(s.userId(), role, ScopeType.TENANT, s.tenantId(), null, null)))
        .hasCauseInstanceOf(DuplicateKeyException.class);
  }

  @Test
  void staleVersionIsRejected() {
    Fixtures fx = new Fixtures(jdbc);
    Fixtures.Scenario s = fx.scenario();
    RoleAssignment saved = assignments.save(RoleAssignment.create(s.userId(), fx.systemRole(fx.product()),
        ScopeType.ACCOUNT, s.accountId(), null, null));
    RoleAssignment extended = new RoleAssignment(saved.id(), saved.userId(), saved.roleId(), saved.scopeType(),
        saved.scopeId(), saved.grantedBy(), saved.grantedAt(), Instant.now().plusSeconds(60), saved.version());
    assignments.save(extended);
    assertThatThrownBy(() -> assignments.save(extended)).isInstanceOf(OptimisticLockingFailureException.class);
  }
}
