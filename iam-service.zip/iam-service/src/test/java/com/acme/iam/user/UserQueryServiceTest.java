package com.acme.iam.user;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

import com.acme.iam.assignment.ScopeType;
import com.acme.iam.common.error.BadRequestException;
import com.acme.iam.common.paging.KeysetPage;
import com.acme.iam.common.test.Fixtures;
import com.acme.iam.common.test.JdbcSliceTest;
import com.acme.iam.common.test.PostgresTestBase;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Import;
import org.springframework.jdbc.core.simple.JdbcClient;

/** P1-3.4: user list read model. */
@JdbcSliceTest
@Import(UserQueryService.class)
class UserQueryServiceTest extends PostgresTestBase {

  @Autowired UserQueryService query;
  @Autowired JdbcClient jdbc;

  Fixtures fx;
  UUID account;
  UUID tenant;

  @BeforeEach
  void setUp() {
    fx = new Fixtures(jdbc);
    account = fx.account();
    tenant = fx.tenant(account);
  }

  @Test
  void listsOnlyTheAccountsUsersNewestFirst() {
    UUID u1 = fx.user(account, tenant);
    UUID u2 = fx.user(account, tenant);
    UUID u3 = fx.user(account, tenant);
    UUID other = fx.account();
    fx.user(other, fx.tenant(other));
    // distinct timestamps; u2 is the newest, u1 the oldest
    setCreatedAt(u1, "2026-01-01T00:00:00Z");
    setCreatedAt(u2, "2026-03-01T00:00:00Z");
    setCreatedAt(u3, "2026-02-01T00:00:00Z");

    KeysetPage<UserSummary> page = query.list(account, UserListFilter.NONE, null, null);

    assertThat(page.items()).extracting(UserSummary::id).containsExactly(u2, u3, u1);
    assertThat(page.nextCursor()).isNull();
    UserSummary first = page.items().getFirst();
    assertThat(first.email()).isEqualTo(fx.email(u2));
    assertThat(first.status()).isEqualTo(UserStatus.ACTIVE);
    assertThat(first.primaryTenantId()).isEqualTo(tenant);
    assertThat(first.createdAt()).isEqualTo(Instant.parse("2026-03-01T00:00:00Z"));
  }

  @Test
  void keysetPagesCoverEveryUserExactlyOnceIncludingTimestampTies() {
    List<UUID> created = new ArrayList<>();
    for (int i = 0; i < 7; i++) {
      created.add(fx.user(account, tenant)); // same transaction: identical created_at, id breaks the tie
    }

    List<UUID> seen = new ArrayList<>();
    String cursor = null;
    int pages = 0;
    do {
      KeysetPage<UserSummary> page = query.list(account, UserListFilter.NONE, cursor, 3);
      assertThat(page.items()).hasSizeLessThanOrEqualTo(3);
      page.items().forEach(u -> seen.add(u.id()));
      cursor = page.nextCursor();
      pages++;
    } while (cursor != null);

    assertThat(pages).isEqualTo(3);
    assertThat(seen).containsExactlyElementsOf(created.reversed());
  }

  @Test
  void filtersByStatus() {
    UUID active = fx.user(account, tenant);
    UUID disabled = fx.user(account, tenant, UserStatus.DISABLED);

    assertThat(query.list(account, new UserListFilter(null, UserStatus.DISABLED, null), null, null).items())
        .extracting(UserSummary::id).containsExactly(disabled);
    assertThat(query.list(account, new UserListFilter(null, UserStatus.ACTIVE, null), null, null).items())
        .extracting(UserSummary::id).containsExactly(active);
  }

  @Test
  void filtersByTenantMembership() {
    UUID second = fx.tenant(account);
    UUID inFirst = fx.user(account, tenant);
    UUID inSecond = fx.user(account, second);
    UUID inBoth = fx.user(account, tenant);
    fx.membership(inBoth, second, MembershipStatus.SUSPENDED);

    assertThat(query.list(account, new UserListFilter(second, null, null), null, null).items())
        .extracting(UserSummary::id).containsExactlyInAnyOrder(inSecond, inBoth);
    assertThat(query.list(account, new UserListFilter(tenant, null, null), null, null).items())
        .extracting(UserSummary::id).containsExactlyInAnyOrder(inFirst, inBoth);
  }

  @Test
  void filtersByRoleIgnoringExpiredAndOtherTenantsWhenTenantIsGiven() {
    UUID second = fx.tenant(account);
    UUID role = fx.customRole(fx.product(), account);
    UUID tenantHolder = fx.user(account, tenant);
    UUID accountHolder = fx.user(account, tenant);
    UUID secondTenantHolder = fx.user(account, tenant);
    fx.membership(secondTenantHolder, second, MembershipStatus.ACTIVE);
    UUID expiredHolder = fx.user(account, tenant);
    fx.user(account, tenant); // no role
    fx.assign(tenantHolder, role, ScopeType.TENANT, tenant);
    fx.assign(accountHolder, role, ScopeType.ACCOUNT, account);
    fx.assign(secondTenantHolder, role, ScopeType.TENANT, second);
    fx.assign(expiredHolder, role, ScopeType.TENANT, tenant, Instant.now().minusSeconds(60));

    assertThat(query.list(account, new UserListFilter(null, null, role), null, null).items())
        .extracting(UserSummary::id).containsExactlyInAnyOrder(tenantHolder, accountHolder, secondTenantHolder);
    assertThat(query.list(account, new UserListFilter(tenant, null, role), null, null).items())
        .extracting(UserSummary::id).containsExactlyInAnyOrder(tenantHolder, accountHolder);
  }

  @Test
  void rejectsMalformedCursorAndLimit() {
    assertThatThrownBy(() -> query.list(account, UserListFilter.NONE, "not-a-cursor", null))
        .isInstanceOfSatisfying(BadRequestException.class, e -> assertThat(e.code()).isEqualTo("invalid_cursor"));
    assertThatThrownBy(() -> query.list(account, UserListFilter.NONE, null, 0))
        .isInstanceOfSatisfying(BadRequestException.class, e -> assertThat(e.code()).isEqualTo("invalid_limit"));
  }

  private void setCreatedAt(UUID user, String instant) {
    jdbc.sql("UPDATE app_user SET created_at = CAST(:at AS timestamptz) WHERE id = :id")
        .param("at", instant).param("id", user).update();
  }
}
