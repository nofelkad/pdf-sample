package com.acme.iam.role;

import static org.assertj.core.api.Assertions.assertThat;

import com.acme.iam.assignment.ScopeType;
import com.acme.iam.common.paging.KeysetPage;
import com.acme.iam.common.test.Fixtures;
import com.acme.iam.common.test.JdbcSliceTest;
import com.acme.iam.common.test.PostgresTestBase;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Import;
import org.springframework.jdbc.core.simple.JdbcClient;

/** P1-3.4: role list read model with assignment counts. */
@JdbcSliceTest
@Import(RoleQueryService.class)
class RoleQueryServiceTest extends PostgresTestBase {

  @Autowired RoleQueryService query;
  @Autowired JdbcClient jdbc;

  Fixtures fx;
  Fixtures.Scenario s;
  UUID product;

  @BeforeEach
  void setUp() {
    fx = new Fixtures(jdbc);
    s = fx.scenario();
    product = fx.product(); // fresh product: only this test's roles match the product filter
  }

  @Test
  void listsSystemAndOwnCustomRolesWithCountsScopedToTheAccount() {
    UUID p1 = fx.permission(product);
    UUID p2 = fx.permission(product);
    UUID system = fx.systemRole(product, p1, p2);
    UUID own = fx.customRole(product, s.accountId(), p1);
    Fixtures.Scenario other = fx.scenario();
    UUID foreign = fx.customRole(product, other.accountId(), p1);

    UUID second = fx.tenant(s.accountId());
    UUID u2 = fx.user(s.accountId(), second);
    fx.assign(s.userId(), system, ScopeType.TENANT, s.tenantId());
    fx.assign(u2, system, ScopeType.TENANT, second);
    fx.assign(u2, system, ScopeType.ACCOUNT, s.accountId());
    fx.assign(s.userId(), own, ScopeType.ACCOUNT, s.accountId(), Instant.now().minusSeconds(5)); // expired
    fx.assign(other.userId(), system, ScopeType.TENANT, other.tenantId()); // other account: not counted
    fx.assign(other.userId(), foreign, ScopeType.ACCOUNT, other.accountId());

    KeysetPage<RoleSummary> page = query.list(s.accountId(), new RoleListFilter(product, null), null, null);

    assertThat(page.items()).extracting(RoleSummary::id).containsExactlyInAnyOrder(system, own);
    RoleSummary sys = page.items().stream().filter(r -> r.id().equals(system)).findFirst().orElseThrow();
    assertThat(sys.type()).isEqualTo(RoleType.SYSTEM);
    assertThat(sys.accountId()).isNull();
    assertThat(sys.productId()).isEqualTo(product);
    assertThat(sys.productCode()).isNotBlank();
    assertThat(sys.permissionCount()).isEqualTo(2);
    assertThat(sys.assignmentCount()).isEqualTo(3);
    RoleSummary custom = page.items().stream().filter(r -> r.id().equals(own)).findFirst().orElseThrow();
    assertThat(custom.accountId()).isEqualTo(s.accountId());
    assertThat(custom.permissionCount()).isEqualTo(1);
    assertThat(custom.assignmentCount()).isZero();

    assertThat(query.list(other.accountId(), new RoleListFilter(product, null), null, null).items())
        .filteredOn(r -> r.id().equals(system)).singleElement()
        .extracting(RoleSummary::assignmentCount).isEqualTo(1L);
  }

  @Test
  void filtersByTypeAndPaginates() {
    List<UUID> customs = new ArrayList<>();
    for (int i = 0; i < 5; i++) {
      customs.add(fx.customRole(product, s.accountId()));
    }
    fx.systemRole(product);

    List<UUID> seen = new ArrayList<>();
    String cursor = null;
    do {
      KeysetPage<RoleSummary> page = query.list(s.accountId(), new RoleListFilter(product, RoleType.CUSTOM), cursor, 2);
      page.items().forEach(r -> seen.add(r.id()));
      cursor = page.nextCursor();
    } while (cursor != null);

    assertThat(seen).containsExactlyElementsOf(customs.reversed());
    assertThat(query.list(s.accountId(), new RoleListFilter(product, RoleType.SYSTEM), null, null).items())
        .hasSize(1);
  }
}
