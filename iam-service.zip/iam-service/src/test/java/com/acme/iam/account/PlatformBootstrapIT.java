package com.acme.iam.account;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

import com.acme.iam.account.PlatformBootstrapService.AlreadyBootstrappedException;
import com.acme.iam.account.PlatformBootstrapService.Result;
import com.acme.iam.assignment.ScopeType;
import com.acme.iam.common.Ids;
import com.acme.iam.common.test.Fixtures;
import com.acme.iam.common.test.IntegrationTest;
import com.acme.iam.common.test.OrgTestData;
import com.acme.iam.common.test.PostgresTestBase;
import com.acme.iam.product.Product;
import com.acme.iam.role.Role;
import com.acme.iam.role.RoleService;
import com.acme.iam.user.TokenPurpose;
import com.acme.iam.user.UserTokenService;
import java.util.Map;
import java.util.UUID;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.simple.JdbcClient;
import org.springframework.test.context.DynamicPropertyRegistry;
import org.springframework.test.context.DynamicPropertySource;
import org.springframework.transaction.support.TransactionTemplate;

/**
 * P1-6.4 bootstrap on a <b>fresh database</b> (its own database in the shared container, migrated by its own context),
 * because "refuses to run twice" depends on global state (the {@code platform} tenant, any Platform Admin assignment)
 * that other tests of the shared database may create.
 *
 * <p>Deliberately does not extend {@link PostgresTestBase}: it registers its own datasource properties for the fresh
 * database and only borrows the container.
 */
@IntegrationTest
class PlatformBootstrapIT {

  private static final String DATABASE = "iam_bootstrap_" + Ids.newId().toString().replace("-", "").substring(20);

  static {
    JdbcTemplate admin = new JdbcTemplate(PostgresTestBase.adminDataSource());
    admin.execute("CREATE DATABASE " + DATABASE + " OWNER " + PostgresTestBase.MIGRATOR_USER);
    admin.execute("REVOKE ALL ON DATABASE " + DATABASE + " FROM PUBLIC");
    admin.execute("GRANT CONNECT, TEMPORARY ON DATABASE " + DATABASE + " TO " + PostgresTestBase.APP_USER);
  }

  @DynamicPropertySource
  static void freshDatabase(DynamicPropertyRegistry registry) {
    String url = PostgresTestBase.jdbcUrl().replace("/" + PostgresTestBase.DATABASE, "/" + DATABASE);
    registry.add("spring.datasource.url", () -> url);
    registry.add("spring.datasource.username", () -> PostgresTestBase.APP_USER);
    registry.add("spring.datasource.password", () -> PostgresTestBase.APP_PASSWORD);
    registry.add("spring.flyway.url", () -> url);
    registry.add("spring.flyway.user", () -> PostgresTestBase.MIGRATOR_USER);
    registry.add("spring.flyway.password", () -> PostgresTestBase.MIGRATOR_PASSWORD);
  }

  @Autowired PlatformBootstrapService service;
  @Autowired JdbcClient jdbc;
  @Autowired UserTokenService userTokens;
  @Autowired TransactionTemplate tx;
  @Autowired RoleService roles;

  @Test
  void createsThePlatformTenantAndAnInvitedPlatformAdminOnceOnly() {
    OrgTestData org = new OrgTestData(jdbc);
    Fixtures fx = org.fixtures();
    if (roles.findSystemRole(Product.IAM_ID, Role.PLATFORM_ADMIN).isEmpty()) {
      // without Task 6's startup registry (R20) the fresh database has no system roles yet
      assertThatThrownBy(() -> service.bootstrap("ops@example.test"))
          .as("system roles not loaded yet")
          .isInstanceOf(IllegalStateException.class);
    }
    UUID platformAdmin = org.platformAdminRole();

    // an existing Platform Admin assignment means the platform is already bootstrapped
    UUID otherTenant = fx.tenant(Account.PLATFORM_ID);
    UUID someone = fx.user(Account.PLATFORM_ID, otherTenant);
    UUID existing = fx.assign(someone, platformAdmin, ScopeType.ACCOUNT, Account.PLATFORM_ID);
    assertThatThrownBy(() -> service.bootstrap("ops@example.test"))
        .isInstanceOf(AlreadyBootstrappedException.class);
    jdbc.sql("DELETE FROM role_assignment WHERE id = :id").param("id", existing).update();

    Result result = service.bootstrap("ops@example.test");

    Map<String, Object> tenant = jdbc.sql("SELECT account_id, slug::text AS slug, status FROM tenant WHERE id = :id")
        .param("id", result.tenantId()).query().singleRow();
    assertThat(tenant).containsEntry("account_id", Account.PLATFORM_ID).containsEntry("slug", "platform")
        .containsEntry("status", "ACTIVE");
    assertThat(org.userStatus(result.userId())).isEqualTo("INVITED");
    assertThat(org.membershipTenants(result.userId())).containsExactly(result.tenantId());
    Map<String, Object> grant = jdbc.sql("""
            SELECT role_id, scope_type, scope_id FROM role_assignment WHERE user_id = :u""")
        .param("u", result.userId()).query().singleRow();
    assertThat(grant).containsEntry("role_id", platformAdmin).containsEntry("scope_type", "ACCOUNT")
        .containsEntry("scope_id", Account.PLATFORM_ID);
    assertThat(result.accountName()).isEqualTo("Platform");
    UUID consumedBy = tx.execute(s -> userTokens.consume(result.token().rawToken(), TokenPurpose.INVITE).user());
    assertThat(consumedBy).isEqualTo(result.userId());

    assertThat(result.reissued()).isFalse();

    // the invitation was lost (e.g. the email failed): re-running with the same email issues a new token
    Result again = service.bootstrap("OPS@example.test");
    assertThat(again.reissued()).isTrue();
    assertThat(again.userId()).isEqualTo(result.userId());
    assertThat(again.tenantId()).isEqualTo(result.tenantId());
    assertThat(org.outstandingTokens(result.userId())).isEqualTo(1);
    UUID reconsumedBy = tx.execute(s -> userTokens.consume(again.token().rawToken(), TokenPurpose.INVITE).user());
    assertThat(reconsumedBy).isEqualTo(result.userId());

    assertThatThrownBy(() -> service.bootstrap("second@example.test"))
        .isInstanceOf(AlreadyBootstrappedException.class);
    assertThat(org.userByEmail(Account.PLATFORM_ID, "second@example.test")).isEmpty();

    jdbc.sql("UPDATE app_user SET status = 'ACTIVE' WHERE id = :id").param("id", result.userId()).update();
    assertThatThrownBy(() -> service.bootstrap("ops@example.test"))
        .as("once the Platform Admin accepted, nothing is reissued")
        .isInstanceOf(AlreadyBootstrappedException.class);
  }
}
