package com.acme.iam.auth;

import static org.assertj.core.api.Assertions.assertThat;

import com.sun.net.httpserver.HttpServer;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.URI;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

/** HIBP range API (k-anonymity): only the first 5 hex chars of the SHA-1 leave the process. */
class HibpBreachedPasswordCheckerTest {

  // SHA-1("password") = 5BAA61E4C9B93F3F0682250B6CF8331B7EE68FD8
  static final String BODY = """
      0018A45C4D1DEF81644B54AB7F969B88D65:1\r
      1E4C9B93F3F0682250B6CF8331B7EE68FD8:3861493\r
      011053FD0102E94D6AE2F8B83D76FAF94F6:0\r
      """;

  HttpServer server;
  final List<String> paths = new CopyOnWriteArrayList<>();
  final List<String> queries = new CopyOnWriteArrayList<>();
  volatile int status = 200;
  HibpBreachedPasswordChecker checker;

  @BeforeEach
  void start() throws Exception {
    server = HttpServer.create(new InetSocketAddress(InetAddress.getLoopbackAddress(), 0), 0);
    server.createContext("/range/", exchange -> {
      paths.add(exchange.getRequestURI().getPath());
      queries.add(String.valueOf(exchange.getRequestURI().getQuery()));
      byte[] body = BODY.getBytes(StandardCharsets.UTF_8);
      exchange.sendResponseHeaders(status, body.length);
      exchange.getResponseBody().write(body);
      exchange.close();
    });
    server.start();
    checker = new HibpBreachedPasswordChecker(
        URI.create("http://127.0.0.1:" + server.getAddress().getPort() + "/range/"), Duration.ofSeconds(2));
  }

  @AfterEach
  void stop() {
    server.stop(0);
  }

  @Test
  void sendsOnlyTheFiveCharPrefixAndMatchesTheSuffixLocally() {
    assertThat(checker.isBreached("password")).isTrue();

    assertThat(paths).containsExactly("/range/5BAA6");
    assertThat(queries).containsExactly("null");
  }

  @Test
  void suffixNotInTheRangeIsNotBreached() {
    // same prefix space is irrelevant: the stub returns the same body, the suffix of this password is absent
    assertThat(checker.isBreached("a much longer and unusual passphrase 42")).isFalse();
    assertThat(paths).hasSize(1).allSatisfy(p -> assertThat(p).matches("/range/[0-9A-F]{5}"));
  }

  @Test
  void zeroCountPaddingEntriesAreNotBreaches() {
    HibpBreachedPasswordChecker.Range range = HibpBreachedPasswordChecker.Range.parse(BODY);
    assertThat(range.count("011053FD0102E94D6AE2F8B83D76FAF94F6")).isZero();
    assertThat(range.count("1E4C9B93F3F0682250B6CF8331B7EE68FD8")).isEqualTo(3861493);
  }

  @Test
  void failsOpenWhenTheServiceIsUnavailable() {
    status = 503;
    assertThat(checker.isBreached("password")).isFalse();
  }
}
