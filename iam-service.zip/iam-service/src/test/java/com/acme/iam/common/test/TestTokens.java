package com.acme.iam.common.test;

import com.acme.iam.common.Ids;
import com.acme.iam.common.security.AccessTokenClaims;
import com.acme.iam.common.security.JwtIssuer;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;
import java.util.UUID;
import org.springframework.stereotype.Component;

/**
 * Mints real RS256 tokens signed by the running application's {@link JwtIssuer} (Ruling R10), for MockMvc / HTTP
 * tests. Picked up by component scanning in every {@code @IntegrationTest} context; inject it with
 * {@code @Autowired TestTokens tokens}.
 *
 * <pre>{@code
 * String jwt = tokens.user(userId).account(accountId).tenant(tenantId).perms("iam.user.manage").mint();
 * mvc.perform(get("/api/...").header(AUTHORIZATION, TestTokens.bearer(jwt)));
 *
 * String full = tokens.accessToken(userId, accountId, tenantId, sessionId, 3, "iam.role.assign");
 * String app = tokens.appToken("billing-service", "BILLING");   // typ=app, perms = internal.*
 * }</pre>
 *
 * The referenced user/account/tenant need not exist unless the code under test reads them (TenantGuard, services).
 */
@Component
public class TestTokens {

  private final JwtIssuer issuer;

  public TestTokens(JwtIssuer issuer) {
    this.issuer = issuer;
  }

  /** {@code "Bearer " + token}, for the {@code Authorization} header. */
  public static String bearer(String token) {
    return "Bearer " + token;
  }

  /** A user access token with exactly the given claims. */
  public String accessToken(UUID userId, UUID accountId, UUID tenantId, UUID sessionId, int sv, String... perms) {
    return accessToken(new AccessTokenClaims(userId, accountId, tenantId, sessionId, sv, Arrays.asList(perms)));
  }

  public String accessToken(AccessTokenClaims claims) {
    return issuer.issueAccessToken(claims).tokenValue();
  }

  /** An application token ({@code sub=app:<clientId>}, {@code typ=app}, {@code perms} = the internal set). */
  public String appToken(String clientId, String productCode) {
    return issuer.issueAppToken(clientId, productCode).tokenValue();
  }

  /** Builder with random account/tenant/session ids, {@code sv = 1} and no permissions unless set. */
  public UserToken user(UUID userId) {
    return new UserToken(userId);
  }

  public final class UserToken {
    private final UUID userId;
    private UUID accountId = Ids.newId();
    private UUID tenantId = Ids.newId();
    private UUID sessionId = Ids.newId();
    private int sv = 1;
    private final List<String> perms = new ArrayList<>();

    private UserToken(UUID userId) {
      this.userId = Objects.requireNonNull(userId, "userId");
    }

    public UserToken account(UUID accountId) {
      this.accountId = accountId;
      return this;
    }

    public UserToken tenant(UUID tenantId) {
      this.tenantId = tenantId;
      return this;
    }

    public UserToken session(UUID sessionId) {
      this.sessionId = sessionId;
      return this;
    }

    public UserToken sv(int sv) {
      this.sv = sv;
      return this;
    }

    public UserToken perms(String... perms) {
      this.perms.addAll(Arrays.asList(perms));
      return this;
    }

    public AccessTokenClaims claims() {
      return new AccessTokenClaims(userId, accountId, tenantId, sessionId, sv, perms);
    }

    public String mint() {
      return accessToken(claims());
    }

    /** {@code "Bearer " + mint()}. */
    public String bearer() {
      return TestTokens.bearer(mint());
    }
  }
}
