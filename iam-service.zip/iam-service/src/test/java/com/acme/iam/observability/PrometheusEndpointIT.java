package com.acme.iam.observability;

import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import com.acme.iam.common.test.IntegrationTest;
import com.acme.iam.common.test.PostgresTestBase;
import java.util.List;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.actuate.observability.AutoConfigureObservability;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.test.web.servlet.MockMvc;

/** P1-11.5: every documented meter is scrapeable at {@code /actuator/prometheus} from a freshly started instance. */
@IntegrationTest
@AutoConfigureMockMvc
@AutoConfigureObservability
class PrometheusEndpointIT extends PostgresTestBase {

  /**
   * Regular expressions over the exposition text, one per series of docs/observability.md that the iam-service
   * registers (the common tag {@code application} is sorted in with the others, hence {@code [^}]*}).
   */
  static final List<String> EXPECTED = List.of(
      "(?m)^iam_auth_logins_total\\{[^}]*outcome=\"success\"[^}]*reason=\"ok\"",
      "(?m)^iam_auth_logins_total\\{[^}]*outcome=\"failure\"[^}]*reason=\"invalid_password\"",
      "(?m)^iam_auth_lockouts_total",
      "(?m)^iam_auth_refresh_reuse_detected_total",
      "(?m)^iam_auth_login_duration_seconds_count\\{[^}]*outcome=\"success\"",
      "(?m)^iam_auth_refresh_duration_seconds_count\\{[^}]*outcome=\"error\"",
      "(?m)^iam_auth_tenant_switch_duration_seconds_count",
      "(?m)^iam_permission_resolve_duration_seconds_count\\{[^}]*op=\"resolve\"",
      "(?m)^iam_permission_resolve_duration_seconds_count\\{[^}]*op=\"explain\"",
      "(?m)^iam_permission_resolve_duration_seconds\\{[^}]*op=\"resolve\"[^}]*quantile=\"0.95\"",
      "(?m)^iam_revocation_lag_seconds",
      "(?m)^iam_revocation_poll_age_seconds",
      "(?m)^iam_revocation_poll_failures_total",
      "(?m)^iam_audit_ingest_lag_seconds_count",
      "(?m)^iam_audit_ingest_lag_seconds\\{[^}]*quantile=\"0.99\"",
      "(?m)^iam_auth_password_reset_send_timeouts_total",
      "(?m)^iam_auth_password_reset_dropped_total",
      "(?m)^iam_audit_partitions_months_ahead");

  @Autowired MockMvc mvc;

  @Test
  void theEndpointIsReachableWithoutAuthenticationAndExposesEveryDocumentedMeter() throws Exception {
    String body = mvc.perform(get("/actuator/prometheus")).andExpect(status().isOk())
        .andReturn().getResponse().getContentAsString();

    assertThat(EXPECTED).allSatisfy(series -> assertThat(body).as(series).containsPattern(series));
  }
}
