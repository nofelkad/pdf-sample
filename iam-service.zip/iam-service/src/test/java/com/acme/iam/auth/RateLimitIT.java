package com.acme.iam.auth;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.header;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import com.acme.iam.common.test.PostgresTestBase;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ThreadLocalRandom;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.simple.JdbcClient;
import org.springframework.test.web.servlet.MockMvc;

/** P1-5.7: Bucket4j (PostgreSQL) limits — 10/min per IP, 5/min per email; 429 with {@code Retry-After}. */
@AuthIT
class RateLimitIT extends PostgresTestBase {

  @Autowired MockMvc mvc;
  @Autowired ObjectMapper json;
  @Autowired JdbcClient jdbc;
  @Autowired PasswordService passwords;
  @Autowired RateLimitBucketPurgeJob purgeJob;
  @Autowired AuthRateLimiter rateLimiter;

  AuthTestData data;

  @BeforeEach
  void setUp() {
    data = new AuthTestData(jdbc, passwords);
  }

  @Test
  void theSixthLoginForOneEmailWithinAMinuteIs429WithRetryAfterAndAudited() throws Exception {
    AuthTestData.TestUser u = data.user();
    for (int i = 0; i < 5; i++) {
      new AuthClient(mvc, json).login(u.email(), "Wrong-Password-" + i).andExpect(status().isUnauthorized());
    }
    AuthClient client = new AuthClient(mvc, json);

    client.login(u.email().toUpperCase(), "Wrong-Password-x")
        .andExpect(status().isTooManyRequests())
        .andExpect(header().string("Retry-After", org.hamcrest.Matchers.matchesPattern("[1-9][0-9]*")))
        .andExpect(jsonPath("$.code").value("rate_limited"));

    List<Map<String, Object>> rows = data.auditRows(client.lastRequestId(), "auth.rate_limited");
    assertThat(rows).singleElement().satisfies(row -> {
      assertThat(row).containsEntry("outcome", "DENIED").containsEntry("actor_type", "ANONYMOUS")
          .containsEntry("actor_ip", client.ip());
      assertThat((String) row.get("metadata")).contains("\"scope\": \"login\"").contains("\"limit\": \"email\"")
          .contains(u.email()).doesNotContain("Wrong-Password");
    });
    // the rejected attempt did not reach the password check
    assertThat(data.auditOfRequest(client.lastRequestId())).containsExactly("auth.rate_limited/DENIED/ANONYMOUS");
  }

  @Test
  void theEleventhLoginFromOneIpWithinAMinuteIs429() throws Exception {
    AuthClient client = new AuthClient(mvc, json);
    for (int i = 0; i < 10; i++) {
      client.login("nobody-" + UUID.randomUUID() + "@example.test", "Wrong-Password-1").andExpect(status().isUnauthorized());
    }

    client.login("nobody-" + UUID.randomUUID() + "@example.test", "Wrong-Password-1")
        .andExpect(status().isTooManyRequests())
        .andExpect(header().exists("Retry-After"));
    assertThat(data.auditRows(client.lastRequestId(), "auth.rate_limited")).singleElement()
        .satisfies(row -> assertThat((String) row.get("metadata")).contains("\"limit\": \"ip\""));
    // another client IP is unaffected
    new AuthClient(mvc, json).login("nobody@example.test", "Wrong-Password-1").andExpect(status().isUnauthorized());
  }

  @Test
  void forgotIsLimitedPerEmail() throws Exception {
    String email = "forgot-" + UUID.randomUUID() + "@example.test";
    for (int i = 0; i < 5; i++) {
      new AuthClient(mvc, json).forgot(email).andExpect(status().isAccepted());
    }

    new AuthClient(mvc, json).forgot(email.toUpperCase()).andExpect(status().isTooManyRequests())
        .andExpect(header().exists("Retry-After"));
  }

  @Test
  void resetIsLimitedPerIp() throws Exception {
    AuthClient client = new AuthClient(mvc, json);
    for (int i = 0; i < 10; i++) {
      client.reset("bogus-" + i, "Some-Passphrase-123").andExpect(status().isBadRequest());
    }

    client.reset("bogus", "Some-Passphrase-123").andExpect(status().isTooManyRequests());
  }

  @Test
  void refreshIsLimitedPerIpAtItsOwnLimit() throws Exception {
    AuthClient client = new AuthClient(mvc, json);
    for (int i = 0; i < 20; i++) {
      client.refresh("bogus-" + i).andExpect(status().isUnauthorized());
    }

    client.refresh("bogus").andExpect(status().isTooManyRequests()).andExpect(header().exists("Retry-After"));
  }

  @Test
  void aBucketIsAuditedOnlyOnItsFirstRejectionPerWindow() throws Exception {
    AuthTestData.TestUser u = data.user();
    for (int i = 0; i < 5; i++) {
      new AuthClient(mvc, json).login(u.email(), "Wrong-Password-" + i);
    }
    for (int i = 0; i < 3; i++) {
      new AuthClient(mvc, json).login(u.email(), "Wrong-Password-x").andExpect(status().isTooManyRequests());
    }

    assertThat(jdbc.sql("""
            SELECT count(*) FROM audit_event
            WHERE action = 'auth.rate_limited' AND metadata->>'email' = :email""")
        .param("email", u.email().toLowerCase()).query(Long.class).single()).isEqualTo(1);
  }

  @Test
  void ipv6ClientsAreLimitedPerSlash64() throws Exception {
    int third = ThreadLocalRandom.current().nextInt(0x10000);
    int fourth = ThreadLocalRandom.current().nextInt(0x10000);
    String prefix = String.format("2001:db8:%x:%x", third, fourth);
    String otherPrefix = String.format("2001:db8:%x:%x", third, (fourth + 1) & 0xffff);
    AuthClient first = new AuthClient(mvc, json, prefix + "::1");
    for (int i = 0; i < 10; i++) {
      first.login("nobody-" + UUID.randomUUID() + "@example.test", "Wrong-Password-1")
          .andExpect(status().isUnauthorized());
    }

    // same /64, different interface id and non-canonical spelling
    new AuthClient(mvc, json, prefix.replace("2001:db8:", "2001:0db8:") + ":0:0:0:ffff")
        .login("nobody-" + UUID.randomUUID() + "@example.test", "Wrong-Password-1")
        .andExpect(status().isTooManyRequests());
    // another /64 is unaffected
    new AuthClient(mvc, json, otherPrefix + "::1")
        .login("nobody-" + UUID.randomUUID() + "@example.test", "Wrong-Password-1")
        .andExpect(status().isUnauthorized());
  }

  @Test
  void anUnknownClientIpSharesNoBucketButTheEmailLimitStillApplies() {
    for (int i = 0; i < 15; i++) {
      rateLimiter.check(AuthRateLimiter.Scope.LOGIN, ClientInfo.UNKNOWN, "nobody-" + UUID.randomUUID() + "@x.test");
    }
    String email = "limited-" + UUID.randomUUID() + "@x.test";
    for (int i = 0; i < 5; i++) {
      rateLimiter.check(AuthRateLimiter.Scope.LOGIN, ClientInfo.UNKNOWN, email);
    }
    assertThatThrownBy(() -> rateLimiter.check(AuthRateLimiter.Scope.LOGIN, ClientInfo.UNKNOWN, email))
        .isInstanceOf(RateLimitedException.class);
    assertThat(jdbc.sql("SELECT count(*) FROM bucket WHERE id LIKE '%:ip:unknown'").query(Long.class).single())
        .isZero();
  }

  @Test
  void passwordChangeIsLimitedPerUser() throws Exception {
    AuthTestData.TestUser u = data.user();
    AuthClient.Tokens tokens = new AuthClient(mvc, json).loginOk(u.email(), u.password());
    for (int i = 0; i < 10; i++) {
      // a fresh client IP each time: the limit is per user
      new AuthClient(mvc, json).change(tokens.bearer(), "Wrong-Current-" + i, "Brand-New-Passphrase-9");
    }

    AuthClient client = new AuthClient(mvc, json);
    client.change(tokens.bearer(), u.password(), "Brand-New-Passphrase-9")
        .andExpect(status().isTooManyRequests())
        .andExpect(header().exists("Retry-After"));
    assertThat(data.auditRows(client.lastRequestId(), "auth.rate_limited")).singleElement()
        .satisfies(row -> assertThat((String) row.get("metadata")).contains("\"limit\": \"user\""));
  }

  @Test
  void thePurgeJobDeletesExpiredBucketsOnly() {
    String expired = "test:expired:" + UUID.randomUUID();
    String live = "test:live:" + UUID.randomUUID();
    jdbc.sql("INSERT INTO bucket (id, state, expires_at) VALUES (:id, NULL, 1)").param("id", expired).update();
    jdbc.sql("INSERT INTO bucket (id, state, expires_at) VALUES (:id, NULL, :at)").param("id", live)
        .param("at", System.currentTimeMillis() + 3_600_000L).update();

    purgeJob.purge();

    assertThat(jdbc.sql("SELECT id FROM bucket WHERE id IN (:ids)").param("ids", List.of(expired, live))
        .query(String.class).list()).containsExactly(live);
  }

  @Test
  void bucketsLiveInThePostgresBucketTableWithoutRawEmails() throws Exception {
    AuthTestData.TestUser u = data.user();
    new AuthClient(mvc, json).login(u.email(), "Wrong-Password-1");

    List<String> ids = jdbc.sql("SELECT id FROM bucket WHERE id LIKE 'login:%'").query(String.class).list();
    assertThat(ids).isNotEmpty().noneMatch(id -> id.contains(u.email()));
    assertThat(jdbc.sql("SELECT count(*) FROM bucket WHERE expires_at IS NOT NULL").query(Long.class).single())
        .isPositive();
  }
}
