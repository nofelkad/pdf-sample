package com.acme.iam.common.jdbc;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.within;

import com.acme.iam.common.test.JdbcSliceTest;
import com.acme.iam.common.test.PostgresTestBase;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.Map;
import java.util.UUID;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.Id;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.annotation.Version;
import org.springframework.data.domain.AuditorAware;
import org.springframework.data.jdbc.core.JdbcAggregateTemplate;
import org.springframework.data.relational.core.mapping.Table;
import org.springframework.jdbc.core.simple.JdbcClient;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.security.oauth2.server.resource.authentication.JwtAuthenticationToken;
import org.springframework.transaction.PlatformTransactionManager;

/**
 * P1-1.5: converters (JSONB, CITEXT, enums), UUIDv7 id assignment, auditing columns, primary transaction manager.
 * Uses throw-away records mapped onto the real {@code account} and {@code tenant} tables (rolled back per test).
 */
@JdbcSliceTest
class JdbcConfigTest extends PostgresTestBase {

  enum Kind { CUSTOMER, PLATFORM }

  @Table("account")
  record TestAccount(
      @Id UUID id, String name, String slug, Kind kind, String status, Map<String, Object> settings,
      @Version Long version, @CreatedDate Instant createdAt, @LastModifiedDate Instant updatedAt) {

    TestAccount withName(String newName) {
      return new TestAccount(id, newName, slug, kind, status, settings, version, createdAt, updatedAt);
    }
  }

  @Table("tenant")
  record TestTenant(
      @Id UUID id, UUID accountId, String name, String slug, String status, JsonNode settings,
      @Version Long version, @CreatedDate Instant createdAt, @LastModifiedDate Instant updatedAt) {}

  @Autowired JdbcAggregateTemplate aggregates;
  @Autowired JdbcClient jdbc;
  @Autowired ObjectMapper objectMapper;
  @Autowired PlatformTransactionManager transactionManager;
  @Autowired AuditorAware<UUID> auditorAware;

  @AfterEach
  void clear() {
    SecurityContextHolder.clearContext();
  }

  @Test
  void primaryTransactionManagerIsTheAuditContextOne() {
    assertThat(transactionManager).isInstanceOf(AuditContextTransactionManager.class);
  }

  @Test
  void nullIdIsReplacedByUuidV7AndNullVersionMeansInsert() {
    TestAccount saved = aggregates.save(account("Acme", "acme-ids", Map.of()));

    assertThat(saved.id()).isNotNull();
    assertThat(saved.id().version()).isEqualTo(7);
    assertThat(saved.version()).isNotNull();
    assertThat(aggregates.findById(saved.id(), TestAccount.class)).isNotNull();
  }

  @Test
  void auditingColumnsAreFilledOnInsertAndUpdate() {
    TestAccount saved = aggregates.save(account("Acme", "acme-auditing", Map.of()));

    assertThat(saved.createdAt()).isCloseTo(Instant.now(), within(5, ChronoUnit.SECONDS));
    assertThat(saved.updatedAt()).isNotNull();

    TestAccount updated = aggregates.save(saved.withName("Acme 2"));
    assertThat(updated.version()).isEqualTo(saved.version() + 1);
    assertThat(updated.updatedAt()).isAfterOrEqualTo(saved.updatedAt());
  }

  @Test
  void jsonbRoundTripsAsMap() {
    Map<String, Object> settings = Map.of(
        "passwordPolicy", Map.of("minLength", 12, "history", 5),
        "accessTokenTtlSeconds", 900);

    TestAccount saved = aggregates.save(account("Acme", "acme-json-map", settings));

    assertThat(aggregates.findById(saved.id(), TestAccount.class).settings()).isEqualTo(settings);
    assertThat(jdbc.sql("SELECT settings->'passwordPolicy'->>'minLength' FROM account WHERE id = :id")
        .param("id", saved.id()).query(String.class).single()).isEqualTo("12");
  }

  @Test
  void jsonbRoundTripsAsJsonNode() throws Exception {
    TestAccount owner = aggregates.save(account("Acme", "acme-json-node", Map.of()));
    JsonNode settings = objectMapper.readTree("{\"theme\":\"dark\",\"limits\":[1,2,3]}");

    TestTenant saved = aggregates.save(
        new TestTenant(null, owner.id(), "Main", "main", "ACTIVE", settings, null, null, null));

    assertThat(aggregates.findById(saved.id(), TestTenant.class).settings()).isEqualTo(settings);
  }

  @Test
  void citextIsReadAsStringAndComparedCaseInsensitively() {
    TestAccount saved = aggregates.save(account("Acme", "Acme-CiText", Map.of()));

    assertThat(aggregates.findById(saved.id(), TestAccount.class).slug()).isEqualTo("Acme-CiText");
    assertThat(jdbc.sql("SELECT id FROM account WHERE slug = :slug").param("slug", "ACME-citext")
        .query(UUID.class).optional()).contains(saved.id());
  }

  @Test
  void enumsAreStoredByName() {
    TestAccount saved = aggregates.save(account("Acme", "acme-enum", Map.of()));

    assertThat(jdbc.sql("SELECT kind FROM account WHERE id = :id").param("id", saved.id())
        .query(String.class).single()).isEqualTo("CUSTOMER");
    assertThat(aggregates.findById(saved.id(), TestAccount.class).kind()).isEqualTo(Kind.CUSTOMER);
  }

  @Test
  void auditorIsTheJwtSubject() {
    assertThat(auditorAware.getCurrentAuditor()).isEmpty();

    UUID user = UUID.randomUUID();
    SecurityContextHolder.getContext().setAuthentication(new JwtAuthenticationToken(
        Jwt.withTokenValue("t").header("alg", "none").subject(user.toString()).build()));

    assertThat(auditorAware.getCurrentAuditor()).contains(user);
  }

  private static TestAccount account(String name, String slug, Map<String, Object> settings) {
    return new TestAccount(null, name, slug, Kind.CUSTOMER, "ACTIVE", settings, null, null, null);
  }
}
