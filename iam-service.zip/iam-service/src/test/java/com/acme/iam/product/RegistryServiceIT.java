package com.acme.iam.product;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

import com.acme.iam.assignment.ScopeType;
import com.acme.iam.common.Ids;
import com.acme.iam.common.test.Fixtures;
import com.acme.iam.common.test.IntegrationTest;
import com.acme.iam.common.test.PostgresTestBase;
import com.acme.iam.product.Manifest.ManifestPermission;
import com.acme.iam.product.Manifest.ManifestRole;
import java.io.IOException;
import java.io.InputStream;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ClassPathResource;
import org.springframework.jdbc.core.simple.JdbcClient;
import org.springframework.transaction.support.TransactionTemplate;

/** P1-7.2: {@code RegistryService.apply}: idempotent upsert, deprecation, role rebuild, revocation of holders. */
@IntegrationTest
class RegistryServiceIT extends PostgresTestBase {

  /** Every audit row of any kind: nothing else writes audit events while a single test runs. */
  private static final String AUDIT_COUNT = "SELECT count(*) FROM audit_event";

  @Autowired RegistryService registry;
  @Autowired JdbcClient jdbc;
  @Autowired TransactionTemplate tx;

  Fixtures fx;
  String code;      // product code, e.g. T1A2B3C4D5E6F
  String prefix;    // "t1a2b3c4d5e6f."

  @BeforeEach
  void setUp() {
    fx = new Fixtures(jdbc);
    code = "T" + Ids.newId().toString().replace("-", "").substring(20).toUpperCase();
    prefix = code.toLowerCase() + ".";
  }

  // ------------------------------------------------------------------------------------------- helpers

  private ManifestPermission feature(String name) {
    return new ManifestPermission(prefix + name, "FEATURE", "Does " + name, false, false);
  }

  private ManifestPermission data(String name) {
    return new ManifestPermission(prefix + name, "DATA", "Reads " + name, false, false);
  }

  private Manifest manifest(List<ManifestPermission> perms, ManifestRole... roles) {
    return new Manifest(code, null, perms, List.of(roles));
  }

  private ManifestRole role(String name, List<String> permissions, List<String> exclude) {
    return new ManifestRole(name, permissions, exclude);
  }

  private UUID productId() {
    return jdbc.sql("SELECT id FROM product WHERE code = :c").param("c", code).query(UUID.class).single();
  }

  private UUID roleId(String name) {
    return jdbc.sql("SELECT id FROM role WHERE product_id = :p AND type = 'SYSTEM' AND name = :n")
        .param("p", productId()).param("n", name).query(UUID.class).single();
  }

  private Set<String> roleCodes(String name) {
    return Set.copyOf(jdbc.sql("""
            SELECT p.code FROM role_permission rp JOIN permission p ON p.id = rp.permission_id
            JOIN role r ON r.id = rp.role WHERE r.product_id = :p AND r.name = :n""")
        .param("p", productId()).param("n", name).query(String.class).list());
  }

  private boolean deprecated(String permissionCode) {
    return jdbc.sql("SELECT deprecated FROM permission WHERE code = :c").param("c", permissionCode)
        .query(Boolean.class).single();
  }

  private long auditRows() {
    return jdbc.sql(AUDIT_COUNT).query(Long.class).single();
  }

  private int sessionVersion(UUID user) {
    return jdbc.sql("SELECT session_version FROM app_user WHERE id = :id").param("id", user)
        .query(Integer.class).single();
  }

  // ------------------------------------------------------------------------------------------- tests

  @Test
  void firstApplyCreatesProductPermissionsAndExpandedSystemRoles() {
    Manifest m = manifest(
        List.of(feature("invoice.approve"), feature("invoice.export"), data("invoice.read.tenant")),
        role("Billing Admin", List.of(prefix + "*"), List.of(prefix + "invoice.export")),
        role("Approver", List.of(prefix + "invoice.approve"), List.of()));

    ApplyResult result = registry.apply(m);

    assertThat(result).isEqualTo(new ApplyResult(code, true, 3, 0, 0, 2));
    assertThat(jdbc.sql("SELECT name FROM product WHERE code = :c").param("c", code).query(String.class).single())
        .isEqualTo(code);
    assertThat(roleCodes("Billing Admin")).containsExactlyInAnyOrder(prefix + "invoice.approve",
        prefix + "invoice.read.tenant");
    assertThat(roleCodes("Approver")).containsExactly(prefix + "invoice.approve");
    assertThat(jdbc.sql("SELECT kind FROM permission WHERE code = :c").param("c", prefix + "invoice.read.tenant")
        .query(String.class).single()).isEqualTo("DATA");
  }

  @Test
  void applyingTheSameManifestTwiceChangesNothingAndWritesNoAuditRows() {
    Manifest m = manifest(List.of(feature("a.b"), feature("c.d")),
        role("Admin", List.of(prefix + "*"), List.of()));
    registry.apply(m);
    long before = auditRows();

    ApplyResult again = registry.apply(m);

    assertThat(again).isEqualTo(new ApplyResult(code, false, 0, 0, 0, 0));
    assertThat(auditRows()).isEqualTo(before);
  }

  @Test
  void aNewNameRenamesTheProductAndAnAbsentNameKeepsIt() {
    registry.apply(new Manifest(code, "Billing", List.of(), List.of()));
    assertThat(jdbc.sql("SELECT name FROM product WHERE code = :c").param("c", code).query(String.class).single())
        .isEqualTo("Billing");

    assertThat(registry.apply(new Manifest(code, null, List.of(), List.of())).changed()).isFalse();
    assertThat(registry.apply(new Manifest(code, "Billing", List.of(), List.of())).changed()).isFalse();
    assertThat(registry.apply(new Manifest(code, "Invoicing", List.of(), List.of())).changed()).isTrue();
    assertThat(jdbc.sql("SELECT name FROM product WHERE code = :c").param("c", code).query(String.class).single())
        .isEqualTo("Invoicing");
  }

  @Test
  void changedPermissionAttributesAreUpdatedOnly() {
    registry.apply(manifest(List.of(feature("a.b"), feature("c.d"))));

    ManifestPermission changed = new ManifestPermission(prefix + "a.b", "FEATURE", "New text", true, true);
    ApplyResult result = registry.apply(manifest(List.of(changed, feature("c.d"))));

    assertThat(result).isEqualTo(new ApplyResult(code, true, 0, 1, 0, 0));
    Map<String, Object> row = jdbc.sql("SELECT description, sensitive, audit_read FROM permission WHERE code = :c")
        .param("c", prefix + "a.b").query().singleRow();
    assertThat(row).containsEntry("description", "New text").containsEntry("sensitive", true)
        .containsEntry("audit_read", true);
  }

  @Test
  void aPermissionMissingFromTheManifestIsDeprecatedAndAReappearingOneIsUndeprecated() {
    registry.apply(manifest(List.of(feature("a.b"), feature("c.d")),
        role("Admin", List.of(prefix + "*"), List.of())));
    assertThat(roleCodes("Admin")).hasSize(2);

    ApplyResult dropped = registry.apply(manifest(List.of(feature("a.b")),
        role("Admin", List.of(prefix + "*"), List.of())));

    assertThat(dropped).isEqualTo(new ApplyResult(code, true, 0, 0, 1, 1));
    assertThat(deprecated(prefix + "c.d")).isTrue();
    assertThat(deprecated(prefix + "a.b")).isFalse();
    assertThat(roleCodes("Admin")).containsExactly(prefix + "a.b");   // deprecated permissions leave system roles

    ApplyResult back = registry.apply(manifest(List.of(feature("a.b"), feature("c.d")),
        role("Admin", List.of(prefix + "*"), List.of())));

    assertThat(back).isEqualTo(new ApplyResult(code, true, 0, 1, 0, 1));
    assertThat(deprecated(prefix + "c.d")).isFalse();
    assertThat(roleCodes("Admin")).hasSize(2);
  }

  @Test
  void aChangedSystemRoleRevokesItsHoldersWithASingleRevocation() {
    registry.apply(manifest(List.of(feature("a.b"), feature("c.d")),
        role("Admin", List.of(prefix + "*"), List.of()),
        role("Viewer", List.of(prefix + "a.b", prefix + "c.d"), List.of()),
        role("Stable", List.of(prefix + "a.b"), List.of())));
    Fixtures.Scenario s = fx.scenario();
    UUID admin = s.userId();
    UUID viewer = fx.user(s.accountId(), s.tenantId());
    UUID stable = fx.user(s.accountId(), s.tenantId());
    UUID outsider = fx.user(s.accountId(), s.tenantId());
    fx.assign(admin, roleId("Admin"), ScopeType.TENANT, s.tenantId());
    fx.assign(viewer, roleId("Viewer"), ScopeType.TENANT, s.tenantId());
    fx.assign(stable, roleId("Stable"), ScopeType.TENANT, s.tenantId());
    long auditBefore = jdbc.sql("SELECT count(*) FROM audit_event WHERE action = 'auth.sessions.revoked'")
        .query(Long.class).single();

    ApplyResult result = registry.apply(manifest(List.of(feature("a.b"), feature("c.d")),
        role("Admin", List.of(prefix + "a.b"), List.of()),
        role("Viewer", List.of(prefix + "*"), List.of(prefix + "c.d")),
        role("Stable", List.of(prefix + "a.b"), List.of())));

    assertThat(result.rolesChanged()).isEqualTo(2);
    assertThat(sessionVersion(admin)).isEqualTo(2);
    assertThat(sessionVersion(viewer)).isEqualTo(2);
    assertThat(sessionVersion(stable)).isEqualTo(1);
    assertThat(sessionVersion(outsider)).isEqualTo(1);
    assertThat(jdbc.sql("SELECT count(*) FROM revocation WHERE user_id IN (:ids) AND min_sv = 2")
        .param("ids", List.of(admin, viewer)).query(Long.class).single()).isEqualTo(2);
    // one revocation event for the whole apply, listing both holders
    assertThat(jdbc.sql("SELECT count(*) FROM audit_event WHERE action = 'auth.sessions.revoked'")
        .query(Long.class).single()).isEqualTo(auditBefore + 1);
    assertThat(jdbc.sql("""
            SELECT metadata->>'count' FROM audit_event WHERE action = 'auth.sessions.revoked'
            ORDER BY occurred_at DESC LIMIT 1""").query(String.class).single()).isEqualTo("2");
  }

  @Test
  void deprecatingAPermissionRevokesHoldersOfCustomRolesThatContainIt() {
    registry.apply(manifest(List.of(feature("a.b"), feature("c.d"))));
    Fixtures.Scenario s = fx.scenario();
    UUID product = productId();
    UUID keeps = jdbc.sql("SELECT id FROM permission WHERE code = :c").param("c", prefix + "a.b")
        .query(UUID.class).single();
    UUID dropped = jdbc.sql("SELECT id FROM permission WHERE code = :c").param("c", prefix + "c.d")
        .query(UUID.class).single();
    UUID custom = fx.customRole(product, s.accountId(), dropped);
    UUID unaffectedCustom = fx.customRole(product, s.accountId(), keeps);
    UUID holder = s.userId();
    UUID other = fx.user(s.accountId(), s.tenantId());
    fx.assign(holder, custom, ScopeType.ACCOUNT, s.accountId());
    fx.assign(other, unaffectedCustom, ScopeType.ACCOUNT, s.accountId());

    ApplyResult result = registry.apply(manifest(List.of(feature("a.b"))));

    assertThat(result.permissionsDeprecated()).isEqualTo(1);
    assertThat(sessionVersion(holder)).isEqualTo(2);
    assertThat(sessionVersion(other)).isEqualTo(1);
  }

  @Test
  void aNewlyCreatedRoleOrAnUnchangedOneRevokesNobody() {
    Fixtures.Scenario s = fx.scenario();
    registry.apply(manifest(List.of(feature("a.b")), role("Admin", List.of(prefix + "*"), List.of())));
    fx.assign(s.userId(), roleId("Admin"), ScopeType.ACCOUNT, s.accountId());

    registry.apply(manifest(List.of(feature("a.b")), role("Admin", List.of(prefix + "*"), List.of())));

    assertThat(sessionVersion(s.userId())).isEqualTo(1);
  }

  @Test
  void aSystemRoleMissingFromTheManifestStaysInPlace() {
    registry.apply(manifest(List.of(feature("a.b")),
        role("Admin", List.of(prefix + "*"), List.of()), role("Old", List.of(prefix + "a.b"), List.of())));

    ApplyResult result = registry.apply(manifest(List.of(feature("a.b")),
        role("Admin", List.of(prefix + "*"), List.of())));

    assertThat(result.changed()).isFalse();
    assertThat(roleCodes("Old")).containsExactly(prefix + "a.b");
  }

  @Test
  void aCodeAlreadyRegisteredByAnotherProductIsRejectedAndNothingIsWritten() {
    registry.apply(manifest(List.of(feature("a.b"))));
    String otherCode = "T" + Ids.newId().toString().replace("-", "").substring(20).toUpperCase();
    // another product tries to take billing's code: impossible by prefix, so simulate with a direct clash on IAM's
    Manifest clash = new Manifest(otherCode, null, List.of(
        new ManifestPermission(otherCode.toLowerCase() + ".x.y", "FEATURE", "d", false, false)), List.of());
    registry.apply(clash);
    jdbc.sql("UPDATE permission SET product_id = (SELECT id FROM product WHERE code = :c) WHERE code = :perm")
        .param("c", code).param("perm", otherCode.toLowerCase() + ".x.y").update();

    assertThatThrownBy(() -> registry.apply(clash))
        .isInstanceOfSatisfying(InvalidManifestException.class, e -> assertThat(e.violations())
            .singleElement().satisfies(v -> assertThat(v).contains(otherCode.toLowerCase() + ".x.y")
                .contains("another product")));
  }

  @Test
  void anInvalidManifestIsRejectedBeforeAnythingIsWritten() {
    Manifest bad = manifest(List.of(feature("a.b"), new ManifestPermission(prefix + "c.d", "DATA", "d", false, false)));
    long before = auditRows();

    assertThatThrownBy(() -> registry.apply(bad)).isInstanceOfSatisfying(InvalidManifestException.class,
        e -> assertThat(e.violations()).singleElement().satisfies(v -> assertThat(v).contains(".own")));

    assertThat(jdbc.sql("SELECT count(*) FROM product WHERE code = :c").param("c", code).query(Long.class).single())
        .isZero();
    assertThat(auditRows()).isEqualTo(before);
  }

  @Test
  void concurrentAppliesOfTheSameNewProductSerialise() throws Exception {
    Manifest m = manifest(List.of(feature("a.b"), feature("c.d")),
        role("Admin", List.of(prefix + "*"), List.of()));
    CountDownLatch go = new CountDownLatch(1);
    List<CompletableFuture<ApplyResult>> runs = List.of(
        CompletableFuture.supplyAsync(() -> awaitThen(go, m)), CompletableFuture.supplyAsync(() -> awaitThen(go, m)),
        CompletableFuture.supplyAsync(() -> awaitThen(go, m)));
    go.countDown();

    List<ApplyResult> results = runs.stream().map(f -> f.orTimeout(60, TimeUnit.SECONDS).join()).toList();

    assertThat(results.stream().filter(ApplyResult::changed)).hasSize(1);
    assertThat(jdbc.sql("SELECT count(*) FROM permission WHERE product_id = :p").param("p", productId())
        .query(Long.class).single()).isEqualTo(2);
  }

  private ApplyResult awaitThen(CountDownLatch go, Manifest m) {
    try {
      go.await();
    } catch (InterruptedException e) {
      throw new IllegalStateException(e);
    }
    return registry.apply(m);
  }

  // ------------------------------------------------------------------------------------ IAM's own manifest

  @Test
  void fixturesUndeprecateAFixedIamCodeThatTheManifestDeprecated() throws IOException {
    Manifest iam;
    try (InputStream in = new ClassPathResource("iam-manifest.yaml").getInputStream()) {
      iam = ManifestParser.parseYaml(in);
    }
    String fixed = "test.fixed." + code.toLowerCase() + ".code";   // an IAM permission that is not in the manifest
    UUID id = fx.permission(Product.IAM_ID, fixed);

    tx.execute(status -> {
      registry.apply(iam);   // what any later test context does at startup
      assertThat(jdbc.sql("SELECT deprecated FROM permission WHERE id = :id").param("id", id)
          .query(Boolean.class).single()).isTrue();
      assertThat(fx.permission(Product.IAM_ID, fixed)).isEqualTo(id);
      assertThat(jdbc.sql("SELECT deprecated FROM permission WHERE id = :id").param("id", id)
          .query(Boolean.class).single()).isFalse();
      status.setRollbackOnly();
      return null;
    });
  }

  @Test
  void iamsOwnManifestParsesValidAndReapplyingItChangesNothing() throws IOException {
    Manifest iam;
    try (InputStream in = new ClassPathResource("iam-manifest.yaml").getInputStream()) {
      iam = ManifestParser.parseYaml(in);
    }
    assertThat(ManifestValidator.validate(iam)).isEmpty();
    assertThat(iam.permissions()).hasSize(11);

    // The IAM product is shared with every other test: assert inside a transaction that is rolled back, so the
    // deprecations this apply performs on other tests' IAM permissions do not outlive it.
    tx.execute(status -> {
      registry.apply(iam);   // normalises whatever other tests added to the shared system roles
      assertIamState(registry.apply(iam));
      status.setRollbackOnly();
      return null;
    });
  }

  private void assertIamState(ApplyResult again) {
    assertThat(again).isEqualTo(new ApplyResult("IAM", false, 0, 0, 0, 0));
    UUID iamId = Product.IAM_ID;
    assertThat(jdbc.sql("SELECT count(*) FROM permission WHERE product_id = :p AND NOT deprecated")
        .param("p", iamId).query(Long.class).single()).isEqualTo(11);
    assertThat(jdbc.sql("SELECT name FROM product WHERE id = :p").param("p", iamId).query(String.class).single())
        .isEqualTo("Identity & Access");   // the manifest has no name: V3's stays
    assertThat(iamRoleCodes("Platform Admin")).hasSize(11).contains("platform.account.manage", "iam.audit.export");
    assertThat(iamRoleCodes("Account Admin")).hasSize(10).doesNotContain("platform.account.manage");
    assertThat(iamRoleCodes("Tenant Admin")).containsExactlyInAnyOrder("iam.user.manage", "iam.user.read.tenant",
        "iam.role.assign", "iam.session.revoke", "iam.audit.read");
    assertThat(iamRoleCodes("Auditor")).containsExactlyInAnyOrder("iam.audit.read", "iam.user.read.account");
    assertThat(jdbc.sql("SELECT description FROM permission WHERE code = 'iam.tenant.manage'")
        .query(String.class).single()).isEqualTo("Update, suspend, archive tenants and switch their products");
    assertThat(jdbc.sql("SELECT sensitive FROM permission WHERE code = 'platform.account.manage'")
        .query(Boolean.class).single()).isTrue();
    assertThat(jdbc.sql("SELECT audit_read FROM permission WHERE code = 'iam.audit.export'")
        .query(Boolean.class).single()).isTrue();
    assertThat(jdbc.sql("SELECT kind FROM permission WHERE code = 'iam.user.read.tenant'")
        .query(String.class).single()).isEqualTo("DATA");
  }

  private Set<String> iamRoleCodes(String name) {
    return Set.copyOf(jdbc.sql("""
            SELECT p.code FROM role_permission rp JOIN permission p ON p.id = rp.permission_id
            JOIN role r ON r.id = rp.role WHERE r.product_id = :p AND r.type = 'SYSTEM' AND r.name = :n""")
        .param("p", Product.IAM_ID).param("n", name).query(String.class).list());
  }
}
