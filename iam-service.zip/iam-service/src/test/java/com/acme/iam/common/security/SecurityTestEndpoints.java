package com.acme.iam.common.security;

import com.acme.iam.common.Ids;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.UUID;
import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Import;
import org.springframework.jdbc.core.simple.JdbcClient;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.transaction.support.TransactionTemplate;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * Test-only endpoints shared by the security integration tests. Every test class imports this same configuration so
 * they share one cached application context.
 */
@TestConfiguration(proxyBeanMethods = false)
@Import(SecurityTestEndpoints.Endpoints.class)
public class SecurityTestEndpoints {

  public static final String READ = "/api/test/secured/read";
  public static final String ANY_OF = "/api/test/secured/any-of";
  public static final String ME = "/api/test/me";
  public static final String TENANT = "/api/test/tenants/{tenantId}";
  public static final String TENANT_WITH_PERMISSION = "/api/test/tenants/{tenantId}/users";
  public static final String INTERNAL_WRITE = "/internal/test/products";
  public static final String PUBLIC = "/api/test/public/ping";

  /** Exercises the {@link PermitAllPaths} extension point. */
  @Bean
  PermitAllPaths testPublicPaths() {
    return new PermitAllPaths("/api/test/public/**");
  }

  @RestController
  static class Endpoints {

    private final CurrentUser currentUser;
    private final TenantGuard tenantGuard;
    private final JdbcClient jdbc;
    private final TransactionTemplate tx;

    Endpoints(CurrentUser currentUser, TenantGuard tenantGuard, JdbcClient jdbc, TransactionTemplate tx) {
      this.currentUser = currentUser;
      this.tenantGuard = tenantGuard;
      this.jdbc = jdbc;
      this.tx = tx;
    }

    @GetMapping(PUBLIC)
    Map<String, String> publicPing() {
      return Map.of("result", "ok");
    }

    @GetMapping(READ)
    @PreAuthorize("hasAuthority('test.read')")
    Map<String, String> read() {
      return Map.of("result", "ok");
    }

    @GetMapping(ANY_OF)
    @PreAuthorize("hasAnyAuthority('test.a', 'test.b')")
    Map<String, String> anyOf() {
      return Map.of("result", "ok");
    }

    @GetMapping(ME)
    @PreAuthorize("isAuthenticated()")
    Map<String, Object> me() {
      Map<String, Object> body = new LinkedHashMap<>();
      body.put("app", currentUser.isApp());
      if (currentUser.isApp()) {
        body.put("clientId", currentUser.clientId());
      } else {
        body.put("userId", currentUser.userId());
        body.put("accountId", currentUser.accountId());
        body.put("tenantId", currentUser.tenantId());
        body.put("sessionId", currentUser.sessionId());
        body.put("sv", currentUser.sessionVersion());
      }
      body.put("perms", currentUser.permissions());
      return body;
    }

    @GetMapping(TENANT)
    @PreAuthorize("hasAuthority('test.read')")
    Map<String, String> tenant(@PathVariable UUID tenantId) {
      tenantGuard.requireActive(tenantId, "test.read");
      return Map.of("result", "ok");
    }

    @GetMapping(TENANT_WITH_PERMISSION)
    @PreAuthorize("hasAuthority('iam.user.manage')")
    Map<String, String> tenantWithPermission(@PathVariable UUID tenantId) {
      tenantGuard.requireActive(tenantId, "iam.user.manage");
      return Map.of("result", "ok");
    }

    /** Writes an audited row (product) as the caller, for the R9 app-attribution test. */
    @PostMapping(INTERNAL_WRITE)
    @PreAuthorize("hasAuthority('internal.manifest.write')")
    Map<String, String> internalWrite() {
      UUID id = Ids.newId();
      tx.executeWithoutResult(s -> jdbc.sql("INSERT INTO product (id, code, name, version) VALUES (?, ?, ?, 0)")
          .params(id, "T" + id.toString().replace("-", "").substring(20).toUpperCase(), "Test product")
          .update());
      return Map.of("id", id.toString());
    }
  }
}
