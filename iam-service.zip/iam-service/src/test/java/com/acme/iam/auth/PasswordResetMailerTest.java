package com.acme.iam.auth;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import com.acme.iam.user.IssuedToken;
import com.acme.iam.user.NotificationPort;
import com.acme.iam.user.TokenPurpose;
import com.acme.iam.user.UserTokenService;
import io.micrometer.core.instrument.simple.SimpleMeterRegistry;
import java.time.Duration;
import java.time.Instant;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.function.Supplier;
import org.awaitility.Awaitility;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Test;

/** Off-request-thread reset mails: bounded queue with a drop counter, and a timeout per send. */
class PasswordResetMailerTest {

  final SimpleMeterRegistry meters = new SimpleMeterRegistry();
  final CountDownLatch release = new CountDownLatch(1);
  final List<String> sent = new CopyOnWriteArrayList<>();
  PasswordResetMailer mailer;

  @AfterEach
  void tearDown() throws Exception {
    release.countDown();
    if (mailer != null) {
      mailer.destroy();
    }
  }

  @Test
  void aFullQueueDropsTheResetCountsItAndNeverRunsItOnTheCaller() {
    mailer = mailer(1, Duration.ofSeconds(10), blockingPort(email -> true));

    mailer.dispatch(List.of(target("a@x.test"))); // taken by the worker, blocks in send
    mailer.dispatch(List.of(target("b@x.test"))); // queued (capacity 1)
    long start = System.nanoTime();
    mailer.dispatch(List.of(target("c@x.test"))); // rejected

    assertThat(System.nanoTime() - start).isLessThan(TimeUnit.SECONDS.toNanos(1));
    assertThat(meters.counter(PasswordResetMailer.DROPPED_METRIC).count()).isEqualTo(1.0);
  }

  @Test
  void aHungSendTimesOutSoTheWorkerMovesOn() {
    mailer = mailer(10, Duration.ofMillis(200), blockingPort(email -> email.startsWith("hung")));

    mailer.dispatch(List.of(target("hung@x.test")));
    mailer.dispatch(List.of(target("next@x.test")));

    Awaitility.await().atMost(Duration.ofSeconds(5)).until(() -> sent.contains("next@x.test"));
  }

  private PasswordResetMailer mailer(int queueCapacity, Duration sendTimeout, NotificationPort port) {
    UserTokenService tokens = mock(UserTokenService.class);
    when(tokens.issue(any(), eq(TokenPurpose.PASSWORD_RESET), any(), any()))
        .thenAnswer(inv -> new IssuedToken(UUID.randomUUID(), "raw-" + UUID.randomUUID(), Instant.now()));
    AuthTransactions tx = mock(AuthTransactions.class);
    when(tx.write(any())).thenAnswer(inv -> ((Supplier<?>) inv.getArgument(0)).get());
    return new PasswordResetMailer(tokens, port, tx, Duration.ofMinutes(30),
        new AuthProperties.MailExecutor(1, queueCapacity, sendTimeout), meters);
  }

  private NotificationPort blockingPort(java.util.function.Predicate<String> blocks) {
    NotificationPort port = mock(NotificationPort.class);
    org.mockito.Mockito.doAnswer(inv -> {
      String email = inv.getArgument(0);
      if (blocks.test(email)) {
        release.await(30, TimeUnit.SECONDS);
      }
      sent.add(email);
      return null;
    }).when(port).sendPasswordReset(anyString(), anyString());
    return port;
  }

  private static PasswordResetMailer.Target target(String email) {
    return new PasswordResetMailer.Target(UUID.randomUUID(), email);
  }
}
