package com.acme.iam.tenant;

import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.http.HttpHeaders.AUTHORIZATION;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.patch;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;

import com.acme.iam.account.SubscriptionStatus;
import com.acme.iam.common.Ids;
import com.acme.iam.common.test.Fixtures;
import com.acme.iam.common.test.IntegrationTest;
import com.acme.iam.common.test.OrgTestData;
import com.acme.iam.common.test.PostgresTestBase;
import com.acme.iam.common.test.TestTokens;
import java.util.List;
import java.util.UUID;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.http.MediaType;
import org.springframework.jdbc.core.simple.JdbcClient;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;

/**
 * Final review M6: renaming, re-configuring and changing the status of a tenant or an account are targeted UPDATEs of
 * that one row. Saving the aggregate instead rewrote (delete + insert) every {@code tenant_product} /
 * {@code account_product} child row, and the trigger audited each of those as a change that never happened.
 */
@IntegrationTest
@AutoConfigureMockMvc
class TargetedUpdateAuditIT extends PostgresTestBase {

  @Autowired MockMvc mvc;
  @Autowired TestTokens tokens;
  @Autowired JdbcClient jdbc;

  OrgTestData org;
  Fixtures fx;
  UUID account;
  UUID tenant;
  String admin;
  String platform;

  @BeforeEach
  void setUp() {
    org = new OrgTestData(jdbc);
    fx = org.fixtures();
    account = fx.account();
    UUID home = fx.tenant(account);
    tenant = fx.tenant(account);
    UUID p1 = fx.product();
    UUID p2 = fx.product();
    fx.subscribe(account, p1, SubscriptionStatus.ACTIVE, null);
    fx.subscribe(account, p2, SubscriptionStatus.ACTIVE, null);
    fx.enableProduct(tenant, p1, true);
    fx.enableProduct(tenant, p2, true);
    UUID user = org.accountAdmin(account, home);
    admin = org.bearer(tokens, user, account, home, "iam.tenant.manage");
    platform = org.platformBearer(tokens, org.platformOperator());
  }

  @Test
  void aTenantRenameWritesExactlyOneAuditRow() throws Exception {
    List<String> actions = run(admin, json(patch("/api/tenants/{id}", tenant), "{\"name\":\"Renamed\"}"));

    assertThat(actions).containsExactly("iam.tenant.update");
    assertThat(jdbc.sql("SELECT name FROM tenant WHERE id = :t").param("t", tenant).query(String.class).single())
        .isEqualTo("Renamed");
  }

  @Test
  void tenantSettingsAndStatusChangesTouchOnlyTheTenantRow() throws Exception {
    assertThat(run(admin, json(patch("/api/tenants/{id}", tenant), "{\"settings\":{\"theme\":\"dark\"}}")))
        .containsExactly("iam.tenant.update");
    assertThat(run(admin, post("/api/tenants/{id}/suspend", tenant))).containsExactly("iam.tenant.update");
    assertThat(run(admin, post("/api/tenants/{id}/reactivate", tenant))).containsExactly("iam.tenant.update");
    assertThat(run(admin, post("/api/tenants/{id}/archive", tenant))).containsExactly("iam.tenant.update");
    assertThat(jdbc.sql("SELECT count(*) FROM tenant_product WHERE tenant = :t AND enabled").param("t", tenant)
        .query(Long.class).single()).isEqualTo(2);
    assertThat(jdbc.sql("SELECT settings->>'theme' FROM tenant WHERE id = :t").param("t", tenant)
        .query(String.class).single()).isEqualTo("dark");
  }

  @Test
  void accountRenameSuspendReactivateAndCloseTouchOnlyTheAccountRow() throws Exception {
    assertThat(run(platform, json(patch("/api/platform/accounts/{id}", account), "{\"name\":\"Renamed\"}")))
        .containsExactly("iam.account.update");
    assertThat(run(platform, json(patch("/api/platform/accounts/{id}", account),
        "{\"settings\":{\"passwordPolicy\":{\"minLength\":14}}}"))).containsExactly("iam.account.update");
    assertThat(run(platform, post("/api/platform/accounts/{id}/suspend", account)))
        .contains("iam.account.update").doesNotContain("iam.account_product.delete", "iam.account_product.insert");
    assertThat(run(platform, post("/api/platform/accounts/{id}/reactivate", account)))
        .containsExactly("iam.account.update");
    assertThat(run(platform, post("/api/platform/accounts/{id}/close", account)))
        .contains("iam.account.update").doesNotContain("iam.account_product.delete", "iam.account_product.insert");
    assertThat(jdbc.sql("SELECT count(*) FROM account_product WHERE account = :a").param("a", account)
        .query(Long.class).single()).isEqualTo(2);
    assertThat(jdbc.sql("SELECT name || ':' || status FROM account WHERE id = :a").param("a", account)
        .query(String.class).single()).isEqualTo("Renamed:CLOSED");
  }

  /** The IAM data-change rows ({@code iam.*}) a request wrote, in order. */
  private List<String> run(String bearer, MockHttpServletRequestBuilder request) throws Exception {
    String requestId = "m6-" + Ids.newId();
    int status = mvc.perform(request.header(AUTHORIZATION, bearer).header("X-Request-Id", requestId))
        .andReturn().getResponse().getStatus();
    assertThat(status).isEqualTo(200);
    return jdbc.sql("""
            SELECT action FROM audit_event WHERE request_id = :r AND action LIKE 'iam.%'
            ORDER BY occurred_at, action""")
        .param("r", requestId).query(String.class).list();
  }

  private static MockHttpServletRequestBuilder json(MockHttpServletRequestBuilder request, String body) {
    return request.contentType(MediaType.APPLICATION_JSON).content(body);
  }
}
