package com.acme.iam.auth;

import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import com.acme.iam.common.test.CapturingNotificationAdapter;
import com.acme.iam.common.test.PostgresTestBase;
import com.acme.iam.user.MembershipStatus;
import com.acme.iam.user.TokenPurpose;
import com.acme.iam.user.UserTokenService;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.time.Duration;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.simple.JdbcClient;
import org.springframework.test.web.servlet.MockMvc;

/**
 * Task 4 "done when": login → refresh → reuse of the old refresh token revokes the session → switch tenant → logout
 * → next request 401; forgot/reset through the captured mail; and every section 4 endpoint emits its {@code auth.*}
 * audit event.
 */
@AuthIT
class AuthFlowE2EIT extends PostgresTestBase {

  @Autowired MockMvc mvc;
  @Autowired ObjectMapper json;
  @Autowired JdbcClient jdbc;
  @Autowired PasswordService passwords;
  @Autowired RevocationPoller poller;
  @Autowired CapturingNotificationAdapter mailbox;
  @Autowired UserTokenService userTokens;

  AuthTestData data;
  AuthClient client;

  @BeforeEach
  void setUp() {
    data = new AuthTestData(jdbc, passwords);
    client = new AuthClient(mvc, json);
    mailbox.clear();
  }

  @Test
  void loginRefreshReuseSwitchTenantLogout() throws Exception {
    AuthTestData.TestUser u = data.user();
    UUID second = data.fx.tenant(u.accountId());
    data.fx.membership(u.userId(), second, MembershipStatus.ACTIVE);

    // login
    AuthClient.Tokens login = client.loginOk(u.email(), u.password());
    client.me(login.bearer()).andExpect(status().isOk())
        .andExpect(jsonPath("$.activeTenant.id").value(u.tenantId().toString()));

    // refresh rotates
    AuthClient.Tokens refreshed = client.tokens(client.refresh(login.refreshToken()).andReturn());
    client.me(refreshed.bearer()).andExpect(status().isOk());

    // reusing the old refresh token revokes the whole session (and the user's access tokens)
    client.refresh(login.refreshToken()).andExpect(status().isUnauthorized())
        .andExpect(jsonPath("$.code").value("invalid_refresh_token"));
    client.refresh(refreshed.refreshToken()).andExpect(status().isUnauthorized());
    poller.poll();
    client.me(refreshed.bearer()).andExpect(status().isUnauthorized())
        .andExpect(jsonPath("$.code").value("token_revoked"));

    // a new login works again; switch tenant
    AuthClient.Tokens again = client.loginOk(u.email(), u.password());
    AuthClient.Tokens switched = client.tokens(client.switchTenant(again.bearer(), second).andReturn());
    assertThat(switched.activeTenantId()).isEqualTo(second);
    client.me(switched.bearer()).andExpect(status().isOk())
        .andExpect(jsonPath("$.activeTenant.id").value(second.toString()));

    // logout → the next request with that access token is 401
    client.logout(switched.bearer()).andExpect(status().isNoContent());
    poller.poll();
    client.me(switched.bearer()).andExpect(status().isUnauthorized());
    client.refresh(switched.refreshToken()).andExpect(status().isUnauthorized());
  }

  @Test
  void forgotAndResetThroughTheMailedLink() throws Exception {
    AuthTestData.TestUser u = data.user();
    AuthClient.Tokens before = client.loginOk(u.email(), u.password());

    client.forgot(u.email()).andExpect(status().isAccepted());
    String token = AuthTestData.awaitResetToken(mailbox, u.email(), 1);
    client.reset(token, "Reset-Passphrase-2026").andExpect(status().isNoContent());

    poller.poll();
    client.me(before.bearer()).andExpect(status().isUnauthorized());
    client.login(u.email(), u.password()).andExpect(status().isUnauthorized());
    AuthClient.Tokens after = client.loginOk(u.email(), "Reset-Passphrase-2026");
    client.me(after.bearer()).andExpect(status().isOk());
  }

  @Test
  void everySection4EndpointEmitsItsAuthAuditEvent() throws Exception {
    AuthTestData.TestUser u = data.user();
    UUID second = data.fx.tenant(u.accountId());
    data.fx.membership(u.userId(), second, MembershipStatus.ACTIVE);
    UUID invited = data.invitedUser(u.accountId(), u.tenantId());
    String invite = userTokens.issue(invited, TokenPurpose.INVITE, Duration.ofDays(7), u.userId()).rawToken();
    Map<String, List<String>> events = new LinkedHashMap<>();

    client.login(u.email(), "Wrong-Password-1");
    record(events, "POST /auth/login (failed)");
    AuthClient.Tokens login = client.loginOk(u.email(), u.password());
    record(events, "POST /auth/login");
    AuthClient.Tokens refreshed = client.tokens(client.refresh(login.refreshToken()).andReturn());
    record(events, "POST /auth/refresh");
    AuthClient.Tokens switched = client.tokens(client.switchTenant(refreshed.bearer(), second).andReturn());
    record(events, "POST /auth/switch-tenant");
    AuthClient.Tokens changed = client.tokens(client.change(switched.bearer(), u.password(), "Changed-Passphrase-1")
        .andReturn());
    record(events, "POST /auth/password/change");
    client.logout(changed.bearer());
    record(events, "POST /auth/logout");
    AuthClient.Tokens other = client.loginOk(u.email(), "Changed-Passphrase-1");
    client.logoutAll(other.bearer());
    record(events, "POST /auth/logout-all");
    client.forgot(u.email());
    record(events, "POST /auth/password/forgot");
    client.reset(AuthTestData.awaitResetToken(mailbox, u.email(), 1), "Reset-Passphrase-77");
    record(events, "POST /auth/password/reset");
    client.accept(invite, "Accepted-Passphrase-1", null);
    record(events, "POST /auth/invitations/accept");

    assertThat(events).containsExactly(
        Map.entry("POST /auth/login (failed)", List.of("auth.login.failed/FAILURE/ANONYMOUS")),
        Map.entry("POST /auth/login", List.of("auth.login.success/SUCCESS/USER")),
        Map.entry("POST /auth/refresh", List.of("auth.refresh/SUCCESS/USER")),
        Map.entry("POST /auth/switch-tenant", List.of("auth.tenant.switched/SUCCESS/USER")),
        Map.entry("POST /auth/password/change",
            List.of("auth.password.changed/SUCCESS/USER", "auth.sessions.revoked/SUCCESS/USER")),
        Map.entry("POST /auth/logout", List.of("auth.logout/SUCCESS/USER", "auth.sessions.revoked/SUCCESS/USER")),
        Map.entry("POST /auth/logout-all",
            List.of("auth.logout_all/SUCCESS/USER", "auth.sessions.revoked/SUCCESS/USER")),
        Map.entry("POST /auth/password/forgot", List.of("auth.password.forgot/SUCCESS/ANONYMOUS")),
        Map.entry("POST /auth/password/reset",
            List.of("auth.password.reset/SUCCESS/USER", "auth.sessions.revoked/SUCCESS/SYSTEM")),
        Map.entry("POST /auth/invitations/accept", List.of("auth.invitation.accepted/SUCCESS/USER")));
  }

  private void record(Map<String, List<String>> events, String endpoint) {
    events.put(endpoint, new ArrayList<>(data.auditOfRequest(client.lastRequestId())));
  }
}
