package com.acme.iam.auth;

import static org.assertj.core.api.Assertions.assertThat;

import com.acme.iam.common.error.ApiException;
import com.acme.iam.common.test.PostgresTestBase;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.time.Duration;
import java.util.UUID;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import org.awaitility.Awaitility;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.simple.JdbcClient;

/**
 * Deterministic races on the {@code app_user} row: a second connection holds an <em>uncommitted</em> UPDATE of the row
 * while the flow under test runs; once the flow is blocked on that row lock (seen through {@code pg_blocking_pids}),
 * the second connection commits and PostgreSQL re-evaluates the flow's conditional UPDATE against the new row.
 */
@AuthIT
class AuthRowLockRaceIT extends PostgresTestBase {

  @Autowired JdbcClient jdbc;
  @Autowired PasswordService passwords;
  @Autowired LoginService loginService;
  @Autowired PasswordFlowService passwordFlows;

  /** A correct guess must not clear a lock that a concurrent failed attempt is applying (uncommitted). */
  @Test
  void aCorrectPasswordDoesNotClearALockAppliedConcurrently() throws Exception {
    AuthTestData data = new AuthTestData(jdbc, passwords);
    AuthTestData.TestUser u = data.user();

    Object result = whileRowLocked(u.userId(),
        "UPDATE app_user SET locked_until = now() + interval '15 minutes', failed_logins = 0 WHERE id = ?",
        () -> loginService.login(new LoginCommand(u.email(), u.password(), null), ClientInfo.UNKNOWN));

    assertThat(result).isInstanceOfSatisfying(ApiException.class,
        e -> assertThat(e.code()).isEqualTo(AuthErrors.INVALID_CREDENTIALS));
    assertThat(jdbc.sql("SELECT locked_until > now() FROM app_user WHERE id = :id").param("id", u.userId())
        .query(Boolean.class).single()).isTrue();
    assertThat(data.sessionsOf(u.userId())).isEmpty();
    assertThat(jdbc.sql("""
            SELECT metadata->>'reason' FROM audit_event
            WHERE action = 'auth.login.failed' AND target_id = :id""")
        .param("id", u.userId().toString()).query(String.class).list()).containsExactly("locked");
  }

  /** A password changed between verification and storage: 409, nothing written, audited. */
  @Test
  void aConcurrentPasswordChangeMakesTheChange409AndIsAudited() throws Exception {
    AuthTestData data = new AuthTestData(jdbc, passwords);
    AuthTestData.TestUser u = data.user();
    AuthTokens login = loginService.login(new LoginCommand(u.email(), u.password(), null), ClientInfo.UNKNOWN);
    UUID sessionId = (UUID) data.sessionByRefresh(login.refreshToken()).get("id");
    Caller caller = new Caller(u.userId(), u.accountId(), u.tenantId(), sessionId);
    String concurrentHash = passwords.hash("Somebody-Elses-Passphrase-1");

    Object result = whileRowLocked(u.userId(),
        "UPDATE app_user SET password_hash = '" + concurrentHash + "' WHERE id = ?",
        () -> passwordFlows.change(caller, u.password(), "Brand-New-Passphrase-9", ClientInfo.UNKNOWN));

    assertThat(result).isInstanceOfSatisfying(ApiException.class,
        e -> assertThat(e.code()).isEqualTo(AuthErrors.CONCURRENT_MODIFICATION));
    assertThat(jdbc.sql("SELECT password_hash FROM app_user WHERE id = :id").param("id", u.userId())
        .query(String.class).single()).isEqualTo(concurrentHash);
    assertThat(data.session(sessionId).get("revoked_at")).isNull();
    assertThat(data.revocationReasons(u.userId())).isEmpty();
    assertThat(jdbc.sql("""
            SELECT outcome || '/' || (metadata->>'reason') FROM audit_event
            WHERE action = 'auth.password.change_failed' AND target_id = :id""")
        .param("id", u.userId().toString()).query(String.class).list())
        .containsExactly("FAILURE/concurrent_modification");
  }

  /**
   * Holds {@code update} (uncommitted) on the user's row, starts {@code flow}, waits until the flow is blocked by that
   * row lock, commits, and returns the flow's result or the {@link ApiException} it threw.
   */
  private static Object whileRowLocked(UUID userId, String update, Callable<Object> flow) throws Exception {
    ExecutorService pool = Executors.newSingleThreadExecutor();
    try (Connection holder = appDataSource().getConnection()) {
      holder.setAutoCommit(false);
      try (PreparedStatement statement = holder.prepareStatement(update)) {
        statement.setObject(1, userId);
        assertThat(statement.executeUpdate()).isEqualTo(1);
      }
      int holderPid = pid(holder);
      Future<Object> running = pool.submit(() -> {
        try {
          return flow.call();
        } catch (ApiException e) {
          return e;
        }
      });
      Awaitility.await().atMost(Duration.ofSeconds(20)).pollInterval(Duration.ofMillis(20))
          .until(() -> blockedBy(holderPid) > 0);
      holder.commit();
      return running.get(30, TimeUnit.SECONDS);
    } finally {
      pool.shutdownNow();
    }
  }

  private static int pid(Connection connection) throws Exception {
    try (PreparedStatement statement = connection.prepareStatement("SELECT pg_backend_pid()");
         ResultSet rs = statement.executeQuery()) {
      rs.next();
      return rs.getInt(1);
    }
  }

  private static long blockedBy(int pid) {
    return JdbcClient.create(adminDataSource())
        .sql("SELECT count(*) FROM pg_stat_activity WHERE :pid = ANY(pg_blocking_pids(pid))")
        .param("pid", pid).query(Long.class).single();
  }
}
