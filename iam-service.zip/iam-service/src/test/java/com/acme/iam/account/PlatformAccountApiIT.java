package com.acme.iam.account;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.within;
import static org.hamcrest.Matchers.startsWith;
import static org.springframework.http.HttpHeaders.AUTHORIZATION;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.patch;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.header;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import com.acme.iam.assignment.PermissionResolver;
import com.acme.iam.assignment.ScopeType;
import com.acme.iam.common.Ids;
import com.acme.iam.common.test.CapturingNotificationAdapter;
import com.acme.iam.common.test.Fixtures;
import com.acme.iam.common.test.IntegrationTest;
import com.acme.iam.common.test.OrgTestData;
import com.acme.iam.common.test.PostgresTestBase;
import com.acme.iam.common.test.TestTokens;
import com.acme.iam.user.ActivationLinks;
import com.acme.iam.user.TokenPurpose;
import com.acme.iam.user.UserTokenService;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.time.OffsetDateTime;
import java.time.temporal.ChronoUnit;
import java.util.Map;
import java.util.UUID;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.context.annotation.Import;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.jdbc.core.simple.JdbcClient;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.transaction.support.TransactionTemplate;

/**
 * P1-6.1 platform account API ({@code platform.account.manage}, PLATFORM callers only) and P1-6.2 account bootstrap:
 * one call yields an account with a default tenant and an invited Account Admin.
 */
@IntegrationTest
@AutoConfigureMockMvc
@Import(CapturingNotificationAdapter.Config.class)
class PlatformAccountApiIT extends PostgresTestBase {

  private static final String ACCOUNTS = "/api/platform/accounts";
  private static final String PASSWORD = "Activated-Passphrase-123";

  @Autowired MockMvc mvc;
  @Autowired TestTokens tokens;
  @Autowired JdbcClient jdbc;
  @Autowired ObjectMapper json;
  @Autowired CapturingNotificationAdapter mailbox;
  @Autowired UserTokenService userTokens;
  @Autowired PermissionResolver resolver;
  @Autowired TransactionTemplate tx;

  OrgTestData org;
  Fixtures fx;
  UUID operator;
  String bearer;
  UUID product;
  String productCode;

  @BeforeEach
  void setUp() {
    mailbox.clear();
    org = new OrgTestData(jdbc);
    fx = org.fixtures();
    org.accountAdminRole();
    UUID platformTenant = fx.tenant(Account.PLATFORM_ID);
    operator = fx.user(Account.PLATFORM_ID, platformTenant);
    fx.assign(operator, org.platformAdminRole(), ScopeType.ACCOUNT, Account.PLATFORM_ID);
    bearer = org.bearer(tokens, operator, Account.PLATFORM_ID, platformTenant, OrgTestData.PLATFORM_PERMISSION);
    product = fx.product();
    productCode = jdbc.sql("SELECT code FROM product WHERE id = :id").param("id", product).query(String.class).single();
  }

  @Test
  void bootstrapCreatesAccountDefaultTenantAndInvitedAccountAdmin() throws Exception {
    String slug = slug();
    String email = "admin-" + slug + "@example.test";
    String suspendedCode = code(fx.product());

    JsonNode created = create("""
        {"name":"Acme","slug":"%s","defaultTenant":{"name":"Acme HQ","slug":"hq"},
         "defaultUser":{"email":"%s","displayName":"Ada"},
         "products":[{"code":"%s","status":"ACTIVE","startsAt":"2026-01-01"},
                     {"code":"%s","status":"SUSPENDED","startsAt":"2026-01-01"}]}"""
        .formatted(slug, email, productCode, suspendedCode));

    UUID accountId = UUID.fromString(created.at("/account/id").asText());
    UUID tenantId = UUID.fromString(created.at("/defaultTenant/id").asText());
    UUID adminId = UUID.fromString(created.at("/defaultUser/id").asText());
    assertThat(created.at("/account/kind").asText()).isEqualTo("CUSTOMER");
    assertThat(created.at("/account/products").size()).isEqualTo(2);
    assertThat(created.at("/defaultTenant/name").asText()).isEqualTo("Acme HQ");
    assertThat(created.at("/defaultTenant/slug").asText()).isEqualTo("hq");
    assertThat(created.at("/defaultUser/email").asText()).isEqualTo(email);
    assertThat(created.at("/defaultUser/status").asText()).isEqualTo("INVITED");

    // default tenant: name and slug from the request, only the entitled product switched on (I5)
    Map<String, Object> tenant = jdbc.sql("""
            SELECT account_id, name, slug::text AS slug, status FROM tenant WHERE id = :id""")
        .param("id", tenantId).query().singleRow();
    assertThat(tenant).containsEntry("account_id", accountId).containsEntry("name", "Acme HQ")
        .containsEntry("slug", "hq").containsEntry("status", "ACTIVE");
    assertThat(jdbc.sql("SELECT product_id FROM tenant_product WHERE tenant = :t AND enabled")
        .param("t", tenantId).query(UUID.class).list()).containsExactly(product);

    // admin: INVITED, primary membership, Account Admin at ACCOUNT scope granted by the operator
    assertThat(org.userStatus(adminId)).isEqualTo("INVITED");
    assertThat(org.membershipTenants(adminId)).containsExactly(tenantId);
    Map<String, Object> grant = jdbc.sql("""
            SELECT ra.scope_type, ra.scope_id, ra.granted_by, r.name FROM role_assignment ra
            JOIN role r ON r.id = ra.role_id WHERE ra.user_id = :u""").param("u", adminId).query().singleRow();
    assertThat(grant).containsEntry("scope_type", "ACCOUNT").containsEntry("scope_id", accountId)
        .containsEntry("granted_by", operator).containsEntry("name", "Account Admin");
    assertThat(resolver.resolve(adminId, tenantId)).contains("iam.user.manage", "iam.tenant.manage");

    // invitation: one INVITE token valid for 7 days; the response link and the email carry the same token
    assertThat(org.outstandingInviteExpiry(adminId).toInstant())
        .isCloseTo(OffsetDateTime.now().plusDays(7).toInstant(), within(1, ChronoUnit.MINUTES));
    String linkToken = tokenOf(created.at("/activation/link").asText());
    CapturingNotificationAdapter.Sent sent = mailbox.last(CapturingNotificationAdapter.Kind.INVITATION, email)
        .orElseThrow();
    assertThat(sent.accountName()).isEqualTo("Acme");
    assertThat(sent.rawToken()).isEqualTo(linkToken);
    UUID consumedBy = tx.execute(s -> userTokens.consume(linkToken, TokenPurpose.INVITE).user());
    assertThat(consumedBy).isEqualTo(adminId);

    // audited once, without the token
    Map<String, Object> audited = jdbc.sql("""
            SELECT account_id, tenant_id, metadata::text AS metadata FROM audit_event
            WHERE action = :a AND target_id = :u""")
        .param("a", ActivationLinks.AUDIT_ACTION).param("u", adminId.toString()).query().singleRow();
    assertThat(audited).containsEntry("account_id", accountId).containsEntry("tenant_id", tenantId);
    assertThat((String) audited.get("metadata")).contains("account_create").doesNotContain(linkToken);
  }

  @Test
  void bootstrapUsesTheRequestedTenantAndReturnsAWorkingLink() throws Exception {
    String slug = slug();
    String email = "admin-" + slug + "@example.test";
    String response = mvc.perform(post(ACCOUNTS).header(AUTHORIZATION, bearer).contentType(MediaType.APPLICATION_JSON)
            .content(body(slug, "HQ", email)))
        .andExpect(status().isCreated())
        .andExpect(header().string(HttpHeaders.CACHE_CONTROL, "no-store"))
        .andExpect(jsonPath("$.defaultTenant.slug").value("hq"))
        .andExpect(jsonPath("$.activation.expiresAt").isNotEmpty())
        .andReturn().getResponse().getContentAsString();
    String token = tokenOf(json.readTree(response).at("/activation/link").asText());

    mvc.perform(post("/auth/invitations/accept").contentType(MediaType.APPLICATION_JSON)
            .content("{\"token\":\"%s\",\"password\":\"%s\"}".formatted(token, PASSWORD)))
        .andExpect(status().isOk())
        .andExpect(jsonPath("$.accessToken").isNotEmpty());
    mvc.perform(post("/auth/login").contentType(MediaType.APPLICATION_JSON)
            .content("{\"email\":\"%s\",\"password\":\"%s\"}".formatted(email, PASSWORD)))
        .andExpect(status().isOk());
  }

  @Test
  void aFailedBootstrapLeavesNothingBehindAndSendsNoMail() throws Exception {
    String slug = slug();
    String email = "admin-" + slug + "@example.test";
    mvc.perform(post(ACCOUNTS).header(AUTHORIZATION, bearer).contentType(MediaType.APPLICATION_JSON)
            .content("""
                {"name":"Acme","slug":"%s","defaultTenant":{"name":"HQ","slug":"hq"},
                 "defaultUser":{"email":"%s"},
                 "products":[{"code":"NO_SUCH_PRODUCT","status":"ACTIVE","startsAt":"2026-01-01"}]}"""
                .formatted(slug, email)))
        .andExpect(status().isBadRequest())
        .andExpect(jsonPath("$.code").value("unknown_product"));
    assertThat(jdbc.sql("SELECT count(*) FROM account WHERE slug = :s").param("s", slug).query(Long.class).single())
        .isZero();
    assertThat(mailbox.sent()).isEmpty();
    assertThat(jdbc.sql("""
            SELECT count(*) FROM audit_event WHERE action = :a AND metadata->>'via' = 'account_create'
              AND account_id NOT IN (SELECT id FROM account)""")
        .param("a", ActivationLinks.AUDIT_ACTION).query(Long.class).single()).isZero();
  }

  @Test
  void onlyPlatformCallersMayManageAccounts() throws Exception {
    Fixtures.Scenario customer = fx.scenario();
    String customerBearer = org.bearer(tokens, customer.userId(), customer.accountId(), customer.tenantId(),
        OrgTestData.PLATFORM_PERMISSION);
    mvc.perform(get(ACCOUNTS).header(AUTHORIZATION, customerBearer))
        .andExpect(status().isForbidden())
        .andExpect(jsonPath("$.code").value("platform_account_required"));

    String withoutPermission = org.bearer(tokens, operator, Account.PLATFORM_ID, Ids.newId(), "iam.tenant.manage");
    mvc.perform(get(ACCOUNTS).header(AUTHORIZATION, withoutPermission)).andExpect(status().isForbidden());
  }

  /** Task 9: the platform permission held at TENANT scope of a platform tenant does not reach other accounts. */
  @Test
  void aTenantScopePlatformGrantIsNotEnough() throws Exception {
    UUID tenant = fx.tenant(Account.PLATFORM_ID);
    UUID user = fx.user(Account.PLATFORM_ID, tenant);
    fx.assign(user, org.platformAdminRole(), ScopeType.TENANT, tenant);
    String tenantScoped = org.bearer(tokens, user, Account.PLATFORM_ID, tenant, OrgTestData.PLATFORM_PERMISSION);

    mvc.perform(get(ACCOUNTS).header(AUTHORIZATION, tenantScoped))
        .andExpect(status().isForbidden())
        .andExpect(jsonPath("$.code").value("account_scope_required"));
  }

  @Test
  void listGetAndUpdate() throws Exception {
    UUID a = fx.account();
    UUID b = fx.account();
    JsonNode page = body(mvc.perform(get(ACCOUNTS + "?limit=1").header(AUTHORIZATION, bearer))
        .andExpect(status().isOk()).andReturn().getResponse().getContentAsString());
    assertThat(page.at("/items/0/id").asText()).isEqualTo(b.toString());
    mvc.perform(get(ACCOUNTS + "?limit=1&cursor=" + page.get("nextCursor").asText()).header(AUTHORIZATION, bearer))
        .andExpect(status().isOk())
        .andExpect(jsonPath("$.items[0].id").value(a.toString()));

    mvc.perform(get(ACCOUNTS + "/{id}", a).header(AUTHORIZATION, bearer))
        .andExpect(status().isOk())
        .andExpect(jsonPath("$.status").value("ACTIVE"));
    mvc.perform(patch(ACCOUNTS + "/{id}", a).header(AUTHORIZATION, bearer).contentType(MediaType.APPLICATION_JSON)
            .content("{\"name\":\"Renamed\",\"settings\":{\"passwordMinLength\":14}}"))
        .andExpect(status().isOk())
        .andExpect(jsonPath("$.name").value("Renamed"))
        .andExpect(jsonPath("$.settings.passwordMinLength").value(14));
    mvc.perform(get(ACCOUNTS + "/{id}", Ids.newId()).header(AUTHORIZATION, bearer))
        .andExpect(status().isNotFound())
        .andExpect(jsonPath("$.code").value("account_not_found"));
  }

  @Test
  void suspendAndCloseRevokeAllUsersOfTheAccount() throws Exception {
    Fixtures.Scenario s = fx.scenario();
    UUID second = fx.user(s.accountId(), fx.tenant(s.accountId()));
    Fixtures.Scenario other = fx.scenario();

    mvc.perform(post(ACCOUNTS + "/{id}/suspend", s.accountId()).header(AUTHORIZATION, bearer))
        .andExpect(status().isOk())
        .andExpect(jsonPath("$.status").value("SUSPENDED"));
    assertThat(org.revocations(s.userId())).isEqualTo(1);
    assertThat(org.revocations(second)).isEqualTo(1);
    assertThat(org.revocations(other.userId())).isZero();

    mvc.perform(post(ACCOUNTS + "/{id}/reactivate", s.accountId()).header(AUTHORIZATION, bearer))
        .andExpect(status().isOk())
        .andExpect(jsonPath("$.status").value("ACTIVE"));
    assertThat(org.revocations(s.userId())).isEqualTo(1);

    mvc.perform(post(ACCOUNTS + "/{id}/close", s.accountId()).header(AUTHORIZATION, bearer))
        .andExpect(status().isOk())
        .andExpect(jsonPath("$.status").value("CLOSED"));
    assertThat(org.revocations(s.userId())).isEqualTo(2);

    mvc.perform(post(ACCOUNTS + "/{id}/reactivate", s.accountId()).header(AUTHORIZATION, bearer))
        .andExpect(status().isConflict())
        .andExpect(jsonPath("$.code").value("account_closed"));
  }

  @Test
  void thePlatformAccountCannotBeSuspendedOrClosed() throws Exception {
    mvc.perform(post(ACCOUNTS + "/{id}/suspend", Account.PLATFORM_ID).header(AUTHORIZATION, bearer))
        .andExpect(status().isConflict())
        .andExpect(jsonPath("$.code").value("platform_account_protected"));
    mvc.perform(post(ACCOUNTS + "/{id}/close", Account.PLATFORM_ID).header(AUTHORIZATION, bearer))
        .andExpect(status().isConflict());
  }

  @Test
  void shrinkingProductsDisablesTenantSwitchesAndRevokesButGrowingDoesNot() throws Exception {
    Fixtures.Scenario s = fx.scenario();
    fx.subscribe(s.accountId(), product, SubscriptionStatus.ACTIVE, null);
    fx.enableProduct(s.tenantId(), product, true);
    String extra = code(fx.product());

    mvc.perform(put(ACCOUNTS + "/{id}/products", s.accountId()).header(AUTHORIZATION, bearer)
            .contentType(MediaType.APPLICATION_JSON)
            .content("""
                {"products":[{"code":"%s","status":"ACTIVE","startsAt":"2026-01-01"},
                             {"code":"%s","status":"TRIAL","startsAt":"2026-01-01","endsAt":"2099-12-31"}]}"""
                .formatted(productCode, extra)))
        .andExpect(status().isOk())
        .andExpect(jsonPath("$.products.length()").value(2));
    assertThat(org.revocations(s.userId())).isZero();

    mvc.perform(put(ACCOUNTS + "/{id}/products", s.accountId()).header(AUTHORIZATION, bearer)
            .contentType(MediaType.APPLICATION_JSON)
            .content("""
                {"products":[{"code":"%s","status":"SUSPENDED","startsAt":"2026-01-01"}]}""".formatted(productCode)))
        .andExpect(status().isOk());
    assertThat(org.revocations(s.userId())).isEqualTo(1);
    assertThat(jdbc.sql("SELECT enabled FROM tenant_product WHERE tenant = :t AND product_id = :p")
        .param("t", s.tenantId()).param("p", product).query(Boolean.class).single()).isFalse();
  }

  @Test
  void theOperatorCreatesATenantInACustomerAccount() throws Exception {
    Fixtures.Scenario s = fx.scenario();
    fx.subscribe(s.accountId(), product, SubscriptionStatus.ACTIVE, null);
    String slug = "t-" + Ids.newId().toString().substring(24);

    mvc.perform(post(ACCOUNTS + "/{id}/tenants", s.accountId()).header(AUTHORIZATION, bearer)
            .contentType(MediaType.APPLICATION_JSON)
            .content("""
                {"name":"Europe","slug":"%s","products":[{"code":"%s","enabled":true}]}""".formatted(slug, productCode)))
        .andExpect(status().isCreated())
        .andExpect(header().string(HttpHeaders.LOCATION,
            startsWith("/api/platform/accounts/" + s.accountId() + "/tenants/")))
        .andExpect(jsonPath("$.accountId").value(s.accountId().toString()))
        .andExpect(jsonPath("$.name").value("Europe"))
        .andExpect(jsonPath("$.status").value("ACTIVE"))
        .andExpect(jsonPath("$.products[0].productCode").value(productCode));
    assertThat(jdbc.sql("SELECT count(*) FROM app_user WHERE primary_tenant_id IN "
            + "(SELECT id FROM tenant WHERE account_id = :a AND slug = :s)")
        .param("a", s.accountId()).param("s", slug).query(Long.class).single()).as("no user is created").isZero();
  }

  @Test
  void theOperatorCanAddATenantToThePlatformAccount() throws Exception {
    mvc.perform(post(ACCOUNTS + "/{id}/tenants", Account.PLATFORM_ID).header(AUTHORIZATION, bearer)
            .contentType(MediaType.APPLICATION_JSON)
            .content("{\"name\":\"Ops\",\"slug\":\"ops-%s\"}".formatted(Ids.newId().toString().substring(24))))
        .andExpect(status().isCreated());
  }

  @Test
  void tenantCreationNeedsAnActiveAccountAndAFreeSlug() throws Exception {
    String request = "{\"name\":\"N\",\"slug\":\"n-%s\"}".formatted(Ids.newId().toString().substring(24));
    mvc.perform(post(ACCOUNTS + "/{id}/tenants", Ids.newId()).header(AUTHORIZATION, bearer)
            .contentType(MediaType.APPLICATION_JSON).content(request))
        .andExpect(status().isNotFound())
        .andExpect(jsonPath("$.code").value("account_not_found"));
    for (AccountStatus inactive : new AccountStatus[] {AccountStatus.SUSPENDED, AccountStatus.CLOSED}) {
      UUID account = fx.account(AccountKind.CUSTOMER, inactive);
      mvc.perform(post(ACCOUNTS + "/{id}/tenants", account).header(AUTHORIZATION, bearer)
              .contentType(MediaType.APPLICATION_JSON).content(request))
          .andExpect(status().isConflict())
          .andExpect(jsonPath("$.code").value("account_not_active"));
    }
    UUID active = fx.account();
    mvc.perform(post(ACCOUNTS + "/{id}/tenants", active).header(AUTHORIZATION, bearer)
        .contentType(MediaType.APPLICATION_JSON).content(request)).andExpect(status().isCreated());
    mvc.perform(post(ACCOUNTS + "/{id}/tenants", active).header(AUTHORIZATION, bearer)
            .contentType(MediaType.APPLICATION_JSON).content(request))
        .andExpect(status().isConflict())
        .andExpect(jsonPath("$.code").value("slug_taken"));
  }

  @Test
  void aCustomerAccountAdminCannotCreateTenantsAnyMore() throws Exception {
    Fixtures.Scenario s = fx.scenario();
    UUID admin = org.accountAdmin(s.accountId(), s.tenantId());
    String adminBearer = org.bearer(tokens, admin, s.accountId(), s.tenantId(), "iam.tenant.manage");
    String request = "{\"name\":\"N\",\"slug\":\"n-%s\"}".formatted(Ids.newId().toString().substring(24));

    mvc.perform(post("/api/tenants").header(AUTHORIZATION, adminBearer)
            .contentType(MediaType.APPLICATION_JSON).content(request))
        .andExpect(status().isMethodNotAllowed());
    mvc.perform(post(ACCOUNTS + "/{id}/tenants", s.accountId()).header(AUTHORIZATION, adminBearer)
            .contentType(MediaType.APPLICATION_JSON).content(request))
        .andExpect(status().isForbidden());
  }

  @Test
  void slugMustBeUnique() throws Exception {
    String slug = slug();
    create(body(slug, "hq", "a-" + slug + "@example.test"));
    mvc.perform(post(ACCOUNTS).header(AUTHORIZATION, bearer).contentType(MediaType.APPLICATION_JSON)
            .content(body(slug.toUpperCase(), "hq", "b-" + slug + "@example.test")))
        .andExpect(status().isConflict())
        .andExpect(jsonPath("$.code").value("slug_taken"));
  }

  @Test
  void validatesTheRequest() throws Exception {
    for (String invalid : new String[] {
        "{\"name\":\"\",\"slug\":\"Bad Slug\",\"defaultTenant\":{\"name\":\"HQ\",\"slug\":\"hq\"},"
            + "\"defaultUser\":{\"email\":\"a@example.test\"}}",
        "{\"name\":\"Acme\",\"slug\":\"acme-x\",\"defaultUser\":{\"email\":\"a@example.test\"}}",
        "{\"name\":\"Acme\",\"slug\":\"acme-x\",\"defaultTenant\":{\"name\":\"HQ\",\"slug\":\"hq\"}}",
        "{\"name\":\"Acme\",\"slug\":\"acme-x\",\"defaultTenant\":{\"name\":\"\",\"slug\":\"-bad\"},"
            + "\"defaultUser\":{\"email\":\"a@example.test\"}}",
        "{\"name\":\"Acme\",\"slug\":\"acme-x\",\"defaultTenant\":{\"name\":\"HQ\",\"slug\":\"hq\"},"
            + "\"defaultUser\":{\"email\":\"not-an-email\"}}"}) {
      mvc.perform(post(ACCOUNTS).header(AUTHORIZATION, bearer).contentType(MediaType.APPLICATION_JSON)
              .content(invalid))
          .andExpect(status().isBadRequest())
          .andExpect(jsonPath("$.code").value("validation_failed"));
    }
  }

  @Test
  void aClosedAccountRejectsWrites() throws Exception {
    UUID closed = fx.account(AccountKind.CUSTOMER, AccountStatus.CLOSED);
    mvc.perform(patch(ACCOUNTS + "/{id}", closed).header(AUTHORIZATION, bearer)
            .contentType(MediaType.APPLICATION_JSON).content("{\"name\":\"X\"}"))
        .andExpect(status().isConflict())
        .andExpect(jsonPath("$.code").value("account_closed"));
    mvc.perform(put(ACCOUNTS + "/{id}/products", closed).header(AUTHORIZATION, bearer)
            .contentType(MediaType.APPLICATION_JSON).content("{\"products\":[]}"))
        .andExpect(status().isConflict())
        .andExpect(jsonPath("$.code").value("account_closed"));
  }

  private JsonNode create(String request) throws Exception {
    return body(mvc.perform(post(ACCOUNTS).header(AUTHORIZATION, bearer).contentType(MediaType.APPLICATION_JSON)
            .content(request))
        .andExpect(status().isCreated())
        .andReturn().getResponse().getContentAsString());
  }

  private static String body(String slug, String tenantSlug, String email) {
    return """
        {"name":"Acme","slug":"%s","defaultTenant":{"name":"Acme HQ","slug":"%s"},
         "defaultUser":{"email":"%s","displayName":"Ada"}}""".formatted(slug, tenantSlug, email);
  }

  /** The raw token in an activation link ({@code …?token=<raw>}). */
  private static String tokenOf(String link) {
    assertThat(link).startsWith("http").contains("token=");
    return link.substring(link.indexOf("token=") + "token=".length());
  }

  private String slug() {
    return "acme-" + Ids.newId().toString().substring(24);
  }

  private String code(UUID productId) {
    return jdbc.sql("SELECT code FROM product WHERE id = :id").param("id", productId).query(String.class).single();
  }

  private JsonNode body(String content) throws Exception {
    return json.readTree(content);
  }
}
