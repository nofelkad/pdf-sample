package com.acme.iam.appclient;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.Test;

/** Task 9 (deferred fix E5): attacker-supplied client ids are stripped of control and format characters. */
class AppClientServiceTest {

  @Test
  void invalidClientIdLosesControlAndFormatCharacters() {
    // U+202E RIGHT-TO-LEFT OVERRIDE, U+200B ZERO WIDTH SPACE, U+FEFF BOM, U+2066 LRI are \p{Cf}; \n and \u0007 are Cntrl
    String raw = "evil‮admin​﻿⁦x\n\u0007y";

    assertThat(AppClientService.sanitizeInvalidClientId(raw)).isEqualTo("eviladminxy");
  }

  @Test
  void invalidClientIdIsTruncated() {
    assertThat(AppClientService.sanitizeInvalidClientId("A".repeat(100))).hasSize(64);
  }
}
