package com.acme.iam.assignment;

import static org.assertj.core.api.Assertions.assertThat;

import com.acme.iam.common.test.PlanTestData;
import com.acme.iam.common.test.PostgresTestBase;
import java.util.Map;
import java.util.UUID;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.core.simple.JdbcClient;

/**
 * P1-7.4 index review: on {@link PlanTestData} (two accounts of 5,000 users / 20,000 assignments each, analyzed) the
 * resolver queries must use index lookups only. Logs {@code EXPLAIN (ANALYZE, BUFFERS)}. The full-scale target
 * (p95 &lt; 15 ms at 1M users / 5M assignments) is measured by the Task 10 load test.
 */
class PermissionResolverPlanIT extends PostgresTestBase {

  private static final Logger log = LoggerFactory.getLogger(PermissionResolverPlanIT.class);

  static PlanTestData data;
  static UUID account;
  static UUID noiseAccount;

  @BeforeAll
  static void seed() {
    data = new PlanTestData().migrate();
    account = data.seedAccount();
    noiseAccount = data.seedAccount();
    data.analyze();
  }

  @AfterAll
  static void cleanUp() {
    data.delete(account);
    data.delete(noiseAccount);
  }

  @Test
  void resolverUsesIndexesOnly() {
    Map<String, Object> user = data.sampleUser(account);
    String plan = data.explain(PermissionResolver.RESOLVE_SQL,
        Map.of("userId", user.get("id"), "tenantId", user.get("primary_tenant_id")));
    log.info("EXPLAIN resolve:\n{}", plan);

    assertThat(plan).doesNotContain("Seq Scan on role_assignment")
        .doesNotContain("Seq Scan on role_permission")
        .doesNotContain("Seq Scan on permission")
        .doesNotContain("Seq Scan on user_tenant_membership");
    assertThat(new PermissionResolver(JdbcClient.create(appDataSource()))
        .resolve((UUID) user.get("id"), (UUID) user.get("primary_tenant_id"))).hasSize(15);
  }

  @Test
  void explainQueryUsesIndexesOnly() {
    Map<String, Object> user = data.sampleUser(account);
    String plan = data.explain(PermissionResolver.EXPLAIN_SQL,
        Map.of("userId", user.get("id"), "tenantId", user.get("primary_tenant_id")));
    log.info("EXPLAIN explain:\n{}", plan);
    assertThat(plan).doesNotContain("Seq Scan on role_assignment").doesNotContain("Seq Scan on role_permission");
  }

  @Test
  void grantorAtTenantQueryUsesIndexesOnly() {
    Map<String, Object> user = data.sampleUser(account);
    String plan = data.explain(PermissionResolver.GRANTOR_AT_TENANT_SQL,
        Map.of("userId", user.get("id"), "tenantId", user.get("primary_tenant_id")));
    log.info("EXPLAIN resolveGrantorAtTenant:\n{}", plan);
    assertThat(plan).doesNotContain("Seq Scan on role_assignment").doesNotContain("Seq Scan on role_permission")
        .doesNotContain("Seq Scan on user_tenant_membership");
  }

  @Test
  void accountScopeResolverUsesIndexesOnly() {
    Map<String, Object> user = data.sampleUser(account);
    String plan = data.explain(PermissionResolver.ACCOUNT_SCOPE_SQL,
        Map.of("userId", user.get("id"), "accountId", account));
    log.info("EXPLAIN resolveAccountScope:\n{}", plan);
    assertThat(plan).doesNotContain("Seq Scan on role_assignment").doesNotContain("Seq Scan on role_permission");
  }
}
