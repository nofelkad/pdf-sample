package com.acme.iam.observability;

import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import com.acme.iam.auth.RevocationPoller;
import com.acme.iam.common.test.IntegrationTest;
import com.acme.iam.common.test.PostgresTestBase;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.actuate.health.HealthEndpointGroups;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.test.web.servlet.MockMvc;

/** P1-11.5: {@code liveness} is the process only, {@code readiness} adds db, revocation freshness and signing key. */
@IntegrationTest
@AutoConfigureMockMvc
class HealthGroupsIT extends PostgresTestBase {

  @Autowired MockMvc mvc;
  @Autowired HealthEndpointGroups groups;
  @Autowired RevocationPoller poller;

  @Test
  void livenessIsTheProcessOnlyAndReadinessAddsTheDependencies() {
    assertThat(groups.get("liveness").isMember("livenessState")).isTrue();
    assertThat(groups.get("liveness").isMember("db")).isFalse();
    assertThat(groups.get("liveness").isMember("revocationFreshness")).isFalse();
    assertThat(groups.get("liveness").isMember("signingKey")).isFalse();

    assertThat(groups.get("readiness").isMember("readinessState")).isTrue();
    assertThat(groups.get("readiness").isMember("db")).isTrue();
    assertThat(groups.get("readiness").isMember("revocationFreshness")).isTrue();
    assertThat(groups.get("readiness").isMember("signingKey")).isTrue();
  }

  @Test
  void livenessAndReadinessAreUpOnceTheRevocationPollerHasRun() throws Exception {
    poller.poll();

    mvc.perform(get("/actuator/health/liveness")).andExpect(status().isOk()).andExpect(jsonPath("$.status").value("UP"));
    mvc.perform(get("/actuator/health/readiness")).andExpect(status().isOk())
        .andExpect(jsonPath("$.status").value("UP"));
    mvc.perform(get("/actuator/health")).andExpect(status().isOk()).andExpect(jsonPath("$.status").value("UP"));
  }
}
