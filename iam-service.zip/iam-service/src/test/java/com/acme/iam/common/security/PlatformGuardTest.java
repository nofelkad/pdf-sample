package com.acme.iam.common.security;

import static org.assertj.core.api.Assertions.assertThat;

import com.acme.iam.account.Account;
import org.junit.jupiter.api.Test;

class PlatformGuardTest {

  @Test
  void platformAccountIdMatchesTheSeededAccount() {
    assertThat(PlatformGuard.PLATFORM_ACCOUNT_ID).isEqualTo(Account.PLATFORM_ID);
  }
}
