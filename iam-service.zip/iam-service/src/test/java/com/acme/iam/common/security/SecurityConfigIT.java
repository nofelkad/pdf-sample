package com.acme.iam.common.security;

import static org.assertj.core.api.Assertions.assertThat;
import static org.hamcrest.Matchers.containsString;
import static org.hamcrest.Matchers.not;
import static org.springframework.http.HttpHeaders.AUTHORIZATION;
import static org.springframework.http.HttpHeaders.WWW_AUTHENTICATE;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.header;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import com.acme.iam.common.Ids;
import com.acme.iam.common.test.IntegrationTest;
import com.acme.iam.common.test.PostgresTestBase;
import com.acme.iam.common.test.TestTokens;
import com.acme.iam.common.web.RequestIdFilter;
import com.acme.iam.core.Claims;
import com.nimbusds.jose.JWSAlgorithm;
import com.nimbusds.jose.JWSHeader;
import com.nimbusds.jose.crypto.MACSigner;
import com.nimbusds.jose.crypto.RSASSASigner;
import com.nimbusds.jose.jwk.RSAKey;
import com.nimbusds.jose.jwk.gen.RSAKeyGenerator;
import com.nimbusds.jwt.JWTClaimsSet;
import com.nimbusds.jwt.SignedJWT;
import java.time.Instant;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.context.annotation.Import;
import org.springframework.http.MediaType;
import org.springframework.jdbc.core.simple.JdbcClient;
import org.springframework.test.web.servlet.MockMvc;

/** P1-4.3 / P1-4.5: filter chains, JWT validation, method security, RFC 7807 401/403, authz.denied audit. */
@IntegrationTest
@AutoConfigureMockMvc
@Import(SecurityTestEndpoints.class)
class SecurityConfigIT extends PostgresTestBase {

  @Autowired MockMvc mvc;
  @Autowired TestTokens tokens;
  @Autowired SigningKeyService keys;
  @Autowired SecurityProperties properties;
  @Autowired JdbcClient jdbc;

  @Test
  void preAuthorizeAllowsHolderOfThePermission() throws Exception {
    mvc.perform(get(SecurityTestEndpoints.READ).header(AUTHORIZATION, tokens.user(Ids.newId()).perms("test.read").bearer()))
        .andExpect(status().isOk())
        .andExpect(jsonPath("$.result").value("ok"));
    mvc.perform(get(SecurityTestEndpoints.ANY_OF).header(AUTHORIZATION, tokens.user(Ids.newId()).perms("test.b").bearer()))
        .andExpect(status().isOk());
  }

  @Test
  void preAuthorizeDeniesWithoutThePermissionAndAuditsAuthzDenied() throws Exception {
    UUID userId = Ids.newId();
    UUID accountId = Ids.newId();
    UUID tenantId = Ids.newId();
    String requestId = "deny-" + Ids.newId();

    mvc.perform(get(SecurityTestEndpoints.READ)
            .header(RequestIdFilter.HEADER, requestId)
            .header(AUTHORIZATION, tokens.user(userId).account(accountId).tenant(tenantId).perms("other.perm").bearer()))
        .andExpect(status().isForbidden())
        .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_PROBLEM_JSON))
        .andExpect(jsonPath("$.status").value(403))
        .andExpect(jsonPath("$.code").value("forbidden"))
        .andExpect(jsonPath("$.requestId").value(requestId));

    Map<String, Object> row = jdbc.sql("""
            SELECT actor_user_id, actor_type, account_id, tenant_id, outcome, source, request_id,
                   metadata->>'method' AS method, metadata->>'path' AS path,
                   metadata->>'requiredAuthority' AS required
            FROM audit_event WHERE action = 'authz.denied' AND request_id = :rid""")
        .param("rid", requestId).query().singleRow();
    assertThat(row)
        .containsEntry("actor_user_id", userId)
        .containsEntry("actor_type", "USER")
        .containsEntry("account_id", accountId)
        .containsEntry("tenant_id", tenantId)
        .containsEntry("outcome", "DENIED")
        .containsEntry("source", "IAM")
        .containsEntry("method", "GET")
        .containsEntry("path", SecurityTestEndpoints.READ)
        .containsEntry("required", "test.read");
  }

  @Test
  void denialOfAnyAuthorityExpressionRecordsAllCandidates() throws Exception {
    String requestId = "deny-any-" + Ids.newId();

    mvc.perform(get(SecurityTestEndpoints.ANY_OF).header(RequestIdFilter.HEADER, requestId)
            .header(AUTHORIZATION, tokens.user(Ids.newId()).bearer()))
        .andExpect(status().isForbidden());

    String required = jdbc.sql("SELECT metadata->>'requiredAuthority' FROM audit_event "
            + "WHERE action = 'authz.denied' AND request_id = :rid")
        .param("rid", requestId).query(String.class).single();
    assertThat(required).isEqualTo("test.a,test.b");
  }

  @Test
  void missingTokenIs401ProblemAndIsNotAudited() throws Exception {
    String requestId = "anon-" + Ids.newId();

    mvc.perform(get(SecurityTestEndpoints.READ).header(RequestIdFilter.HEADER, requestId))
        .andExpect(status().isUnauthorized())
        .andExpect(header().string(WWW_AUTHENTICATE, "Bearer"))
        .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_PROBLEM_JSON))
        .andExpect(jsonPath("$.code").value("unauthorized"))
        .andExpect(jsonPath("$.status").value(401))
        .andExpect(jsonPath("$.requestId").value(requestId));

    assertThat(jdbc.sql("SELECT count(*) FROM audit_event WHERE request_id = :rid")
        .param("rid", requestId).query(Long.class).single()).isZero();
  }

  @Test
  void unknownApiPathStillRequiresAuthentication() throws Exception {
    mvc.perform(get("/api/does-not-exist"))
        .andExpect(status().isUnauthorized())
        .andExpect(jsonPath("$.code").value("unauthorized"));
  }

  @Test
  void garbageTokenIs401InvalidToken() throws Exception {
    mvc.perform(get(SecurityTestEndpoints.READ).header(AUTHORIZATION, "Bearer not.a.jwt"))
        .andExpect(status().isUnauthorized())
        .andExpect(header().string(WWW_AUTHENTICATE, containsString("error=\"invalid_token\"")))
        .andExpect(jsonPath("$.code").value("invalid_token"));
  }

  @Test
  void invalidTokenIsAuditedWithoutTheToken() throws Exception {
    String requestId = "badtok-" + Ids.newId();
    String token = signWithActiveKey(userClaims("https://evil.example", Instant.now().plusSeconds(300)));

    mvc.perform(get(SecurityTestEndpoints.READ).header(RequestIdFilter.HEADER, requestId)
            .header(AUTHORIZATION, TestTokens.bearer(token)))
        .andExpect(status().isUnauthorized());

    Map<String, Object> row = jdbc.sql("""
            SELECT action, outcome, actor_type, actor_user_id, metadata->>'method' AS method,
                   metadata->>'path' AS path, metadata->>'error' AS error, metadata::text AS metadata
            FROM audit_event WHERE request_id = :rid""")
        .param("rid", requestId).query().singleRow();
    assertThat(row)
        .containsEntry("action", "auth.token.invalid")
        .containsEntry("outcome", "DENIED")
        .containsEntry("actor_type", "ANONYMOUS")
        .containsEntry("method", "GET")
        .containsEntry("path", SecurityTestEndpoints.READ);
    assertThat(row.get("actor_user_id")).isNull();
    assertThat((String) row.get("error")).isNotBlank();
    assertThat((String) row.get("metadata")).doesNotContain(token).doesNotContain(token.substring(0, 30));
  }

  @Test
  void tokenSignedByAnUnknownKeyIsRejected() throws Exception {
    RSAKey foreign = new RSAKeyGenerator(2048).keyID(keys.activeKeyId()).generate();

    String token = sign(new JWSHeader.Builder(JWSAlgorithm.RS256).keyID(foreign.getKeyID()).build(),
        userClaims(properties.issuer(), Instant.now().plusSeconds(300)), new RSASSASigner(foreign));

    mvc.perform(get(SecurityTestEndpoints.READ).header(AUTHORIZATION, TestTokens.bearer(token)))
        .andExpect(status().isUnauthorized())
        .andExpect(jsonPath("$.code").value("invalid_token"));
  }

  @Test
  void onlyRs256IsAccepted() throws Exception {
    byte[] secret = new byte[32];
    String hs256 = sign(new JWSHeader.Builder(JWSAlgorithm.HS256).keyID(keys.activeKeyId()).build(),
        userClaims(properties.issuer(), Instant.now().plusSeconds(300)), new MACSigner(secret));
    String rs512 = sign(new JWSHeader.Builder(JWSAlgorithm.RS512).keyID(keys.activeKeyId()).build(),
        userClaims(properties.issuer(), Instant.now().plusSeconds(300)), new RSASSASigner(keys.activeSigningKey()));

    mvc.perform(get(SecurityTestEndpoints.READ).header(AUTHORIZATION, TestTokens.bearer(hs256)))
        .andExpect(status().isUnauthorized());
    mvc.perform(get(SecurityTestEndpoints.READ).header(AUTHORIZATION, TestTokens.bearer(rs512)))
        .andExpect(status().isUnauthorized());
  }

  @Test
  void wrongIssuerIsRejected() throws Exception {
    String token = signWithActiveKey(userClaims("https://evil.example", Instant.now().plusSeconds(300)));

    mvc.perform(get(SecurityTestEndpoints.READ).header(AUTHORIZATION, TestTokens.bearer(token)))
        .andExpect(status().isUnauthorized())
        .andExpect(jsonPath("$.code").value("invalid_token"));
  }

  @Test
  void expiryIsEnforcedWithSixtySecondsOfClockSkew() throws Exception {
    String withinSkew = signWithActiveKey(userClaims(properties.issuer(), Instant.now().minusSeconds(30)));
    String beyondSkew = signWithActiveKey(userClaims(properties.issuer(), Instant.now().minusSeconds(90)));

    mvc.perform(get(SecurityTestEndpoints.READ).header(AUTHORIZATION, TestTokens.bearer(withinSkew)))
        .andExpect(status().isOk());
    mvc.perform(get(SecurityTestEndpoints.READ).header(AUTHORIZATION, TestTokens.bearer(beyondSkew)))
        .andExpect(status().isUnauthorized());
  }

  @Test
  void tokenWithoutExpiryIsRejected() throws Exception {
    JWTClaimsSet claims = new JWTClaimsSet.Builder(userClaims(properties.issuer(), Instant.now().plusSeconds(60)))
        .expirationTime(null).build();

    mvc.perform(get(SecurityTestEndpoints.READ).header(AUTHORIZATION, TestTokens.bearer(signWithActiveKey(claims))))
        .andExpect(status().isUnauthorized());
  }

  @Test
  void userTokenWithoutSessionVersionIsRejected() throws Exception {
    JWTClaimsSet claims = new JWTClaimsSet.Builder(userClaims(properties.issuer(), Instant.now().plusSeconds(60)))
        .claim(Claims.SESSION_VERSION, null).build();

    mvc.perform(get(SecurityTestEndpoints.READ).header(AUTHORIZATION, TestTokens.bearer(signWithActiveKey(claims))))
        .andExpect(status().isUnauthorized())
        .andExpect(jsonPath("$.code").value("invalid_token"));
  }

  @Test
  void issuedAccessTokenCarriesExactlyTheSpecClaims() throws Exception {
    UUID userId = Ids.newId();
    String token = tokens.user(userId).sv(7).perms("b.perm", "a.perm").mint();

    SignedJWT jwt = SignedJWT.parse(token);
    assertThat(jwt.getHeader().getAlgorithm()).isEqualTo(JWSAlgorithm.RS256);
    assertThat(jwt.getJWTClaimsSet().getClaims().keySet())
        .containsExactlyInAnyOrder("iss", "sub", "acc", "tid", "sid", "sv", "perms", "iat", "exp", "jti");
    assertThat(jwt.getJWTClaimsSet().getIssuer()).isEqualTo(properties.issuer());
    assertThat(jwt.getJWTClaimsSet().getSubject()).isEqualTo(userId.toString());
    assertThat(jwt.getJWTClaimsSet().getLongClaim("sv")).isEqualTo(7L);
    assertThat(jwt.getJWTClaimsSet().getStringListClaim("perms")).containsExactly("a.perm", "b.perm");
    long ttl = jwt.getJWTClaimsSet().getExpirationTime().getTime() - jwt.getJWTClaimsSet().getIssueTime().getTime();
    assertThat(ttl).isEqualTo(properties.accessTokenTtl().toMillis());
  }

  @Test
  void currentUserExposesTheTokenClaims() throws Exception {
    UUID userId = Ids.newId();
    UUID accountId = Ids.newId();
    UUID tenantId = Ids.newId();
    UUID sessionId = Ids.newId();

    mvc.perform(get(SecurityTestEndpoints.ME).header(AUTHORIZATION,
            TestTokens.bearer(tokens.accessToken(userId, accountId, tenantId, sessionId, 4, "x.read"))))
        .andExpect(status().isOk())
        .andExpect(jsonPath("$.app").value(false))
        .andExpect(jsonPath("$.userId").value(userId.toString()))
        .andExpect(jsonPath("$.accountId").value(accountId.toString()))
        .andExpect(jsonPath("$.tenantId").value(tenantId.toString()))
        .andExpect(jsonPath("$.sessionId").value(sessionId.toString()))
        .andExpect(jsonPath("$.sv").value(4))
        .andExpect(jsonPath("$.perms[0]").value("x.read"));
  }

  @Test
  void userTokensNeverCarryInternalAuthorities() throws Exception {
    mvc.perform(post(SecurityTestEndpoints.INTERNAL_WRITE)
            .header(AUTHORIZATION, tokens.user(Ids.newId()).perms(Claims.PERM_INTERNAL_MANIFEST_WRITE).bearer()))
        .andExpect(status().isForbidden());
  }

  @Test
  void appTokensOnlyCarryInternalAuthorities() throws Exception {
    mvc.perform(get(SecurityTestEndpoints.ME).header(AUTHORIZATION, TestTokens.bearer(tokens.appToken("billing-svc", "BILLING"))))
        .andExpect(status().isOk())
        .andExpect(jsonPath("$.app").value(true))
        .andExpect(jsonPath("$.clientId").value("billing-svc"))
        .andExpect(jsonPath("$.perms.length()").value(Claims.APP_PERMISSIONS.size()));
  }

  @Test
  void jwksAndPublicAuthEndpointsIgnoreBearerTokens() throws Exception {
    mvc.perform(get("/.well-known/jwks.json").header(AUTHORIZATION, "Bearer garbage"))
        .andExpect(status().isOk());
    mvc.perform(post("/auth/test-public-path-does-not-exist").header(AUTHORIZATION, "Bearer garbage"))
        .andExpect(status().is(not(401)));
  }

  @Test
  void authenticatedAuthEndpointsRequireAToken() throws Exception {
    for (String path : SecurityConfig.AUTH_AUTHENTICATED_PATHS) {
      mvc.perform(post(path))
          .andExpect(status().isUnauthorized())
          .andExpect(jsonPath("$.code").value("unauthorized"));
    }
  }

  @Test
  void permitAllPathsBeanOpensAPathAndIgnoresBearerTokensThere() throws Exception {
    mvc.perform(get(SecurityTestEndpoints.PUBLIC)).andExpect(status().isOk());
    mvc.perform(get(SecurityTestEndpoints.PUBLIC).header(AUTHORIZATION, "Bearer garbage")).andExpect(status().isOk());
  }

  @Test
  void actuatorHealthStaysPublic() throws Exception {
    mvc.perform(get("/actuator/health")).andExpect(status().isOk());
  }

  // ------------------------------------------------------------------------------------------------ helpers

  private static JWTClaimsSet userClaims(String issuer, Instant expiresAt) {
    Instant now = Instant.now();
    return new JWTClaimsSet.Builder()
        .issuer(issuer)
        .subject(Ids.newId().toString())
        .claim(Claims.ACCOUNT, Ids.newId().toString())
        .claim(Claims.TENANT, Ids.newId().toString())
        .claim(Claims.SESSION, Ids.newId().toString())
        .claim(Claims.SESSION_VERSION, 1)
        .claim(Claims.PERMISSIONS, List.of("test.read"))
        .issueTime(Date.from(now.minusSeconds(600)))
        .expirationTime(Date.from(expiresAt))
        .jwtID(Ids.newId().toString())
        .build();
  }

  private String signWithActiveKey(JWTClaimsSet claims) throws Exception {
    return sign(new JWSHeader.Builder(JWSAlgorithm.RS256).keyID(keys.activeKeyId()).build(), claims,
        new RSASSASigner(keys.activeSigningKey()));
  }

  private static String sign(JWSHeader header, JWTClaimsSet claims, com.nimbusds.jose.JWSSigner signer)
      throws Exception {
    SignedJWT jwt = new SignedJWT(header, claims);
    jwt.sign(signer);
    return jwt.serialize();
  }
}
