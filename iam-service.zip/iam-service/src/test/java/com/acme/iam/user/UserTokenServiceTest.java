package com.acme.iam.user;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.assertj.core.api.Assertions.within;

import com.acme.iam.common.error.BadRequestException;
import com.acme.iam.common.error.NotFoundException;
import com.acme.iam.common.test.Fixtures;
import com.acme.iam.common.test.JdbcSliceTest;
import com.acme.iam.common.test.PostgresTestBase;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.time.Duration;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.CyclicBarrier;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.assertj.core.api.ThrowableAssert.ThrowingCallable;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Import;
import org.springframework.jdbc.core.simple.JdbcClient;

/** {@link UserTokenService}: 256-bit base64url tokens, SHA-256 at rest, single use, purpose-bound, expiring. */
@JdbcSliceTest
@Import(UserTokenService.class)
class UserTokenServiceTest extends PostgresTestBase {

  @Autowired UserTokenService service;
  @Autowired UserTokenRepository repository;
  @Autowired JdbcClient jdbc;

  UUID user;
  UUID admin;

  @BeforeEach
  void setUp() {
    Fixtures fx = new Fixtures(jdbc);
    Fixtures.Scenario s = fx.scenario();
    user = s.userId();
    admin = fx.user(s.accountId(), s.tenantId());
  }

  @Test
  void issuesA256BitBase64UrlTokenAndStoresOnlyItsSha256() throws Exception {
    Instant before = Instant.now();
    IssuedToken issued = service.issue(user, TokenPurpose.INVITE, Duration.ofDays(7), admin);

    assertThat(issued.rawToken()).hasSize(43).matches("[A-Za-z0-9_-]{43}");
    assertThat(Base64.getUrlDecoder().decode(issued.rawToken())).hasSize(32);
    assertThat(issued.expiresAt()).isCloseTo(before.plus(7, ChronoUnit.DAYS), within(5, ChronoUnit.SECONDS));
    assertThat(issued.toString()).doesNotContain(issued.rawToken());

    UserToken stored = repository.findById(issued.tokenId()).orElseThrow();
    byte[] expectedHash = MessageDigest.getInstance("SHA-256")
        .digest(issued.rawToken().getBytes(StandardCharsets.US_ASCII));
    assertThat(stored.tokenHash()).isEqualTo(expectedHash);
    assertThat(stored.user()).isEqualTo(user);
    assertThat(stored.purpose()).isEqualTo(TokenPurpose.INVITE);
    assertThat(stored.createdBy().getId()).isEqualTo(admin);
    assertThat(stored.usedAt()).isNull();
    String rawColumns = jdbc.sql("SELECT encode(token_hash, 'escape') FROM user_token WHERE id = :id")
        .param("id", issued.tokenId()).query(String.class).single();
    assertThat(rawColumns).doesNotContain(issued.rawToken());
  }

  @Test
  void tokensAreUnique() {
    String a = service.issue(user, TokenPurpose.INVITE, Duration.ofDays(1), null).rawToken();
    String b = service.issue(user, TokenPurpose.INVITE, Duration.ofDays(1), null).rawToken();
    assertThat(a).isNotEqualTo(b);
  }

  @Test
  void consumesOnce() {
    IssuedToken issued = service.issue(user, TokenPurpose.PASSWORD_RESET, Duration.ofMinutes(30), null);

    UserToken consumed = service.consume(issued.rawToken(), TokenPurpose.PASSWORD_RESET);
    assertThat(consumed.id()).isEqualTo(issued.tokenId());
    assertThat(consumed.user()).isEqualTo(user);
    assertThat(consumed.usedAt()).isNotNull();

    expectInvalid(() -> service.consume(issued.rawToken(), TokenPurpose.PASSWORD_RESET));
  }

  @Test
  void purposeIsBinding() {
    IssuedToken issued = service.issue(user, TokenPurpose.INVITE, Duration.ofDays(7), null);
    expectInvalid(() -> service.consume(issued.rawToken(), TokenPurpose.PASSWORD_RESET));
    assertThat(service.consume(issued.rawToken(), TokenPurpose.INVITE).id()).isEqualTo(issued.tokenId());
  }

  @Test
  void expiredTokenIsRejected() {
    String raw = "expired-" + UUID.randomUUID();
    repository.save(UserToken.create(user, TokenPurpose.PASSWORD_RESET, UserTokenService.hash(raw),
        Instant.now().minusSeconds(1), null));
    expectInvalid(() -> service.consume(raw, TokenPurpose.PASSWORD_RESET));
  }

  @Test
  void unknownOrBlankTokenIsRejected() {
    expectInvalid(() -> service.consume("no-such-token", TokenPurpose.INVITE));
    expectInvalid(() -> service.consume("", TokenPurpose.INVITE));
    expectInvalid(() -> service.consume(null, TokenPurpose.INVITE));
  }

  @Test
  void invalidateOutstandingAffectsOnlyThatPurpose() {
    IssuedToken invite1 = service.issue(user, TokenPurpose.INVITE, Duration.ofDays(7), null);
    IssuedToken invite2 = service.issue(user, TokenPurpose.INVITE, Duration.ofDays(7), null);
    IssuedToken reset = service.issue(user, TokenPurpose.PASSWORD_RESET, Duration.ofMinutes(30), null);

    assertThat(service.invalidateOutstanding(user, TokenPurpose.INVITE)).isEqualTo(2);

    expectInvalid(() -> service.consume(invite1.rawToken(), TokenPurpose.INVITE));
    expectInvalid(() -> service.consume(invite2.rawToken(), TokenPurpose.INVITE));
    assertThat(service.consume(reset.rawToken(), TokenPurpose.PASSWORD_RESET)).isNotNull();
  }

  @Test
  void unknownUserIsNotFound() {
    assertThatThrownBy(() -> service.issue(UUID.randomUUID(), TokenPurpose.INVITE, Duration.ofDays(7), null))
        .isInstanceOfSatisfying(NotFoundException.class, e -> assertThat(e.code()).isEqualTo("user_not_found"));
  }

  /**
   * Two threads consume the same committed token at the same time: exactly one wins. Runs outside the test
   * transaction so each consume commits on its own connection; the loser blocks on the row lock, then re-checks
   * {@code used_at IS NULL} and updates nothing.
   */
  @Test
  @Transactional(propagation = Propagation.NOT_SUPPORTED)
  void concurrentConsumersExactlyOneWins() throws Exception {
    Fixtures fx = new Fixtures(jdbc);
    UUID committedUser = fx.scenario().userId();
    String raw = service.issue(committedUser, TokenPurpose.PASSWORD_RESET, Duration.ofMinutes(30), null).rawToken();

    int threads = 2;
    CyclicBarrier start = new CyclicBarrier(threads);
    ExecutorService pool = Executors.newFixedThreadPool(threads);
    try {
      List<Future<String>> results = new ArrayList<>();
      for (int i = 0; i < threads; i++) {
        results.add(pool.submit(() -> {
          start.await(10, TimeUnit.SECONDS);
          try {
            service.consume(raw, TokenPurpose.PASSWORD_RESET);
            return "ok";
          } catch (BadRequestException e) {
            return e.code();
          }
        }));
      }
      List<String> outcomes = new ArrayList<>();
      for (Future<String> f : results) {
        outcomes.add(f.get(30, TimeUnit.SECONDS));
      }
      assertThat(outcomes).containsExactlyInAnyOrder("ok", "invalid_token");
    } finally {
      pool.shutdownNow();
    }
    assertThat(repository.findByTokenHash(UserTokenService.hash(raw)).orElseThrow().usedAt()).isNotNull();
  }

  @Test
  void ttlMustBePositive() {
    assertThatThrownBy(() -> service.issue(user, TokenPurpose.INVITE, Duration.ZERO, null))
        .isInstanceOf(IllegalArgumentException.class);
  }

  private static void expectInvalid(ThrowingCallable call) {
    assertThatThrownBy(call).isInstanceOfSatisfying(BadRequestException.class,
        e -> assertThat(e.code()).isEqualTo("invalid_token"));
  }
}
