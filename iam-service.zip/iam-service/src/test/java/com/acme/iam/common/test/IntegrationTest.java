package com.acme.iam.common.test;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Inherited;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.core.annotation.AliasFor;
import org.springframework.test.context.ActiveProfiles;

/**
 * Full application context ({@code @SpringBootTest}) with the {@code test} profile. Use on classes extending
 * {@link PostgresTestBase}:
 *
 * <pre>{@code
 * @IntegrationTest
 * class RoleServiceIT extends PostgresTestBase { ... }
 *
 * @IntegrationTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
 * class LoginHttpIT extends PostgresTestBase { ... }
 * }</pre>
 */
@Target(ElementType.TYPE)
@Retention(RetentionPolicy.RUNTIME)
@Documented
@Inherited
@SpringBootTest
@ActiveProfiles("test")
public @interface IntegrationTest {

  @AliasFor(annotation = SpringBootTest.class, attribute = "webEnvironment")
  SpringBootTest.WebEnvironment webEnvironment() default SpringBootTest.WebEnvironment.MOCK;

  @AliasFor(annotation = SpringBootTest.class, attribute = "properties")
  String[] properties() default {};
}
