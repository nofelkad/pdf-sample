package com.acme.iam.security;

import static org.springframework.http.HttpHeaders.AUTHORIZATION;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import com.acme.iam.assignment.ScopeType;
import com.acme.iam.common.test.Fixtures;
import com.acme.iam.common.test.IntegrationTest;
import com.acme.iam.common.test.OrgTestData;
import com.acme.iam.common.test.PostgresTestBase;
import com.acme.iam.common.test.TestTokens;
import com.acme.iam.product.Product;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.UUID;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.jdbc.core.simple.JdbcClient;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;

/**
 * Task 9 security review: the dynamic filters (audit search/export, user, role, tenant and account lists) bind every
 * value; SQL in a filter value is data. Every query composes fixed fragments only (see also
 * {@code AccountFilterScanTest}).
 */
@IntegrationTest
@AutoConfigureMockMvc
class SqlInjectionIT extends PostgresTestBase {

  private static final String[] PAYLOADS = {
      "' OR '1'='1", "x'; DELETE FROM app_user; --", "%' OR 1=1 --", "\\\\' OR 1=1", "1) OR (1=1"};

  @Autowired MockMvc mvc;
  @Autowired TestTokens tokens;
  @Autowired JdbcClient jdbc;

  String bearer;

  @BeforeEach
  void caller() {
    OrgTestData org = new OrgTestData(jdbc);
    Fixtures fx = org.fixtures();
    Fixtures.Scenario s = fx.scenario();
    fx.assign(s.userId(), fx.customRole(Product.IAM_ID, s.accountId(), fx.permission(Product.IAM_ID, "iam.audit.read"),
        fx.permission(Product.IAM_ID, "iam.user.read.account"), fx.permission(Product.IAM_ID, "iam.role.manage"),
        fx.permission(Product.IAM_ID, "iam.tenant.manage")), ScopeType.ACCOUNT, s.accountId());
    bearer = org.bearer(tokens, s.userId(), s.accountId(), s.tenantId(), "iam.audit.read", "iam.user.read.account",
        "iam.role.manage", "iam.tenant.manage");
  }

  private MockHttpServletRequestBuilder auditSearch() {
    Instant now = Instant.now().truncatedTo(ChronoUnit.SECONDS);
    return get("/api/audit/events").param("from", now.minusSeconds(3600).toString()).param("to", now.toString())
        .header(AUTHORIZATION, bearer);
  }

  @Test
  void auditFilterValuesAreData() throws Exception {
    for (String payload : PAYLOADS) {
      var response = mvc.perform(auditSearch().param("targetType", payload).param("targetId", payload))
          .andReturn().getResponse();
      org.assertj.core.api.Assertions.assertThat(response.getStatus()).as(payload + " " + response.getContentAsString())
          .isEqualTo(200);
      // the action prefix is a LIKE pattern: anything outside [a-z0-9_.] is refused before SQL
      mvc.perform(auditSearch().param("action", payload)).andExpect(status().isBadRequest())
          .andExpect(jsonPath("$.code").value("invalid_action_prefix"));
      mvc.perform(auditSearch().param("cursor", payload)).andExpect(status().isBadRequest())
          .andExpect(jsonPath("$.code").value("invalid_cursor"));
    }
    // path values (';' and '%' never reach a controller: the firewall answers 400 first)
    mvc.perform(get("/api/audit/targets/{type}/{id}", PAYLOADS[0], PAYLOADS[4]).header(AUTHORIZATION, bearer))
        .andExpect(status().isOk()).andExpect(jsonPath("$.items").isEmpty());
    mvc.perform(get("/api/audit/targets/{type}/{id}", "x", PAYLOADS[1]).header(AUTHORIZATION, bearer))
        .andExpect(status().isBadRequest());
  }

  @Test
  void enumAndUuidFiltersRejectSql() throws Exception {
    for (String payload : PAYLOADS) {
      mvc.perform(get("/api/users").param("status", payload).header(AUTHORIZATION, bearer))
          .andExpect(status().isBadRequest());
      mvc.perform(get("/api/users").param("tenantId", payload).header(AUTHORIZATION, bearer))
          .andExpect(status().isBadRequest());
      mvc.perform(get("/api/roles").param("type", payload).header(AUTHORIZATION, bearer))
          .andExpect(status().isBadRequest());
      mvc.perform(get("/api/tenants").param("status", payload).header(AUTHORIZATION, bearer))
          .andExpect(status().isBadRequest());
      mvc.perform(get("/api/users").param("cursor", payload).header(AUTHORIZATION, bearer))
          .andExpect(status().isBadRequest());
    }
  }

  @Test
  void productCodeInAPathIsData() throws Exception {
    var roles = mvc.perform(get("/api/roles").param("productCode", PAYLOADS[0]).header(AUTHORIZATION, bearer))
        .andReturn().getResponse();
    org.assertj.core.api.Assertions.assertThat(roles.getStatus()).as(roles.getContentAsString()).isEqualTo(404);
    mvc.perform(get("/api/products/{code}/permissions", PAYLOADS[0]).header(AUTHORIZATION, bearer))
        .andExpect(status().isNotFound());
    mvc.perform(get("/api/users/{id}", UUID.randomUUID()).header(AUTHORIZATION, bearer))
        .andExpect(status().isNotFound());
  }
}
