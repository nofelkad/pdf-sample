package com.acme.iam.auth;

import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.http.HttpHeaders.AUTHORIZATION;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import com.acme.iam.assignment.ScopeType;
import com.acme.iam.common.test.Fixtures;
import com.acme.iam.common.test.OrgTestData;
import com.acme.iam.common.test.TestTokens;
import com.acme.iam.common.test.PostgresTestBase;
import com.acme.iam.product.Product;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.time.OffsetDateTime;
import java.util.Map;
import java.util.UUID;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.simple.JdbcClient;
import org.springframework.test.web.servlet.MockMvc;

/**
 * Task 9, rulings R37 (force logout of a user and of a whole account) and R38 (unlock): admin operations on sessions
 * and lockout, with the R28 scope rule and audit.
 */
@AuthIT
class AdminSessionControlIT extends PostgresTestBase {

  @Autowired MockMvc mvc;
  @Autowired ObjectMapper json;
  @Autowired JdbcClient jdbc;
  @Autowired TestTokens tokens;
  @Autowired PasswordService passwords;
  @Autowired RevocationPoller poller;

  AuthTestData data;
  OrgTestData org;
  Fixtures fx;

  @BeforeEach
  void setUp() {
    data = new AuthTestData(jdbc, passwords);
    org = new OrgTestData(jdbc);
    fx = org.fixtures();
  }

  private String holder(UUID account, UUID tenant, ScopeType scope, String... perms) {
    UUID user = fx.user(account, tenant);
    UUID[] ids = java.util.Arrays.stream(perms).map(p -> fx.permission(Product.IAM_ID, p)).toArray(UUID[]::new);
    fx.assign(user, fx.customRole(Product.IAM_ID, account, ids), scope, scope == ScopeType.ACCOUNT ? account : tenant);
    return org.bearer(tokens, user, account, tenant, perms);
  }

  private long openSessions(UUID user) {
    return jdbc.sql("SELECT count(*) FROM user_session WHERE user_id = :u AND revoked_at IS NULL").param("u", user)
        .query(Long.class).single();
  }

  @Test
  void forceLogoutRevokesEverySessionAndEveryAccessTokenOfTheUser() throws Exception {
    AuthTestData.TestUser target = data.user();
    AuthClient laptop = new AuthClient(mvc, json);
    AuthClient phone = new AuthClient(mvc, json);
    AuthClient.Tokens first = laptop.loginOk(target.email(), target.password());
    AuthClient.Tokens second = phone.loginOk(target.email(), target.password());
    assertThat(openSessions(target.userId())).isEqualTo(2);
    String admin = holder(target.accountId(), target.tenantId(), ScopeType.ACCOUNT, "iam.session.revoke");

    mvc.perform(post("/api/users/{id}/sessions/revoke", target.userId()).header(AUTHORIZATION, admin))
        .andExpect(status().isOk())
        .andExpect(jsonPath("$.userId").value(target.userId().toString()))
        .andExpect(jsonPath("$.sessionsRevoked").value(2));

    assertThat(openSessions(target.userId())).isZero();
    laptop.refresh(first.refreshToken()).andExpect(status().isUnauthorized());
    poller.poll();
    mvc.perform(get("/api/me").header(AUTHORIZATION, second.bearer())).andExpect(status().isUnauthorized())
        .andExpect(jsonPath("$.code").value("token_revoked"));
    Map<String, Object> audit = jdbc.sql("""
            SELECT outcome, metadata->>'sessions_revoked' AS sessions FROM audit_event
            WHERE action = 'auth.sessions.force_logout' AND target_id = :t""")
        .param("t", target.userId().toString()).query().singleRow();
    assertThat(audit).containsEntry("outcome", "SUCCESS").containsEntry("sessions", "2");
    assertThat(jdbc.sql("""
            SELECT count(*) FROM audit_event WHERE action = 'auth.sessions.revoked'
              AND metadata->>'reason' = 'admin_force_logout' AND account_id = :a""")
        .param("a", target.accountId()).query(Long.class).single()).isEqualTo(1);
  }

  @Test
  void forceLogoutFollowsR28() throws Exception {
    AuthTestData.TestUser local = data.user();
    UUID other = fx.tenant(local.accountId());
    UUID spanning = fx.user(local.accountId(), local.tenantId());
    fx.membership(spanning, other, com.acme.iam.user.MembershipStatus.ACTIVE);
    String tenantScoped = holder(local.accountId(), local.tenantId(), ScopeType.TENANT, "iam.session.revoke");

    mvc.perform(post("/api/users/{id}/sessions/revoke", local.userId()).header(AUTHORIZATION, tenantScoped))
        .andExpect(status().isOk());
    mvc.perform(post("/api/users/{id}/sessions/revoke", spanning).header(AUTHORIZATION, tenantScoped))
        .andExpect(status().isForbidden()).andExpect(jsonPath("$.code").value("account_scope_required"));
    Fixtures.Scenario foreign = fx.scenario();
    mvc.perform(post("/api/users/{id}/sessions/revoke", foreign.userId()).header(AUTHORIZATION, tenantScoped))
        .andExpect(status().isNotFound());
  }

  @Test
  void aPlatformOperatorForcesTheWholeAccountOut() throws Exception {
    AuthTestData.TestUser one = data.user();
    AuthTestData.TestUser two = data.user(one.accountId(), one.tenantId());
    AuthTestData.TestUser bystander = data.user();
    new AuthClient(mvc, json).loginOk(one.email(), one.password());
    AuthClient.Tokens twoTokens = new AuthClient(mvc, json).loginOk(two.email(), two.password());
    new AuthClient(mvc, json).loginOk(bystander.email(), bystander.password());
    String operator = org.platformBearer(tokens, org.platformOperator());

    mvc.perform(post("/api/platform/accounts/{id}/sessions/revoke", one.accountId()).header(AUTHORIZATION, operator))
        .andExpect(status().isOk())
        .andExpect(jsonPath("$.accountId").value(one.accountId().toString()))
        .andExpect(jsonPath("$.sessionsRevoked").value(2))
        .andExpect(jsonPath("$.usersRevoked").value(2));

    assertThat(openSessions(one.userId()) + openSessions(two.userId())).isZero();
    assertThat(openSessions(bystander.userId())).isEqualTo(1);
    poller.poll();
    mvc.perform(get("/api/me").header(AUTHORIZATION, twoTokens.bearer())).andExpect(status().isUnauthorized());
    mvc.perform(post("/api/platform/accounts/{id}/sessions/revoke", UUID.randomUUID()).header(AUTHORIZATION, operator))
        .andExpect(status().isNotFound()).andExpect(jsonPath("$.code").value("account_not_found"));
    String customer = holder(one.accountId(), one.tenantId(), ScopeType.ACCOUNT, "platform.account.manage");
    mvc.perform(post("/api/platform/accounts/{id}/sessions/revoke", one.accountId()).header(AUTHORIZATION, customer))
        .andExpect(status().isForbidden()).andExpect(jsonPath("$.code").value("platform_account_required"));
  }

  @Test
  void unlockClearsTheLockoutAndIsAudited() throws Exception {
    AuthTestData.TestUser locked = data.user();
    jdbc.sql("UPDATE app_user SET failed_logins = 3, locked_until = :until WHERE id = :id")
        .param("until", OffsetDateTime.now().plusMinutes(10)).param("id", locked.userId()).update();
    AuthClient client = new AuthClient(mvc, json);
    client.login(locked.email(), locked.password()).andExpect(status().isUnauthorized());
    String admin = holder(locked.accountId(), locked.tenantId(), ScopeType.ACCOUNT, "iam.user.manage");

    mvc.perform(post("/api/users/{id}/unlock", locked.userId()).header(AUTHORIZATION, admin))
        .andExpect(status().isOk())
        .andExpect(jsonPath("$.id").value(locked.userId().toString()));

    Map<String, Object> row = jdbc.sql("SELECT failed_logins, locked_until FROM app_user WHERE id = :id")
        .param("id", locked.userId()).query().singleRow();
    assertThat(row.get("failed_logins")).isEqualTo(0);
    assertThat(row.get("locked_until")).isNull();
    client.login(locked.email(), locked.password()).andExpect(status().isOk());
    assertThat(jdbc.sql("""
            SELECT metadata->>'was_locked' FROM audit_event WHERE action = 'auth.unlocked' AND target_id = :t""")
        .param("t", locked.userId().toString()).query(String.class).single()).isEqualTo("true");
  }

  @Test
  void unlockFollowsR28() throws Exception {
    AuthTestData.TestUser local = data.user();
    UUID other = fx.tenant(local.accountId());
    UUID spanning = fx.user(local.accountId(), local.tenantId());
    fx.membership(spanning, other, com.acme.iam.user.MembershipStatus.ACTIVE);
    String tenantScoped = holder(local.accountId(), local.tenantId(), ScopeType.TENANT, "iam.user.manage");

    mvc.perform(post("/api/users/{id}/unlock", local.userId()).header(AUTHORIZATION, tenantScoped))
        .andExpect(status().isOk());
    mvc.perform(post("/api/users/{id}/unlock", spanning).header(AUTHORIZATION, tenantScoped))
        .andExpect(status().isForbidden()).andExpect(jsonPath("$.code").value("account_scope_required"));
  }
}
