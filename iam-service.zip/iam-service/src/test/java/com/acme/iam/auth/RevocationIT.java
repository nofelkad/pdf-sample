package com.acme.iam.auth;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.springframework.http.HttpHeaders.AUTHORIZATION;
import static org.springframework.http.HttpHeaders.WWW_AUTHENTICATE;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.header;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import com.acme.iam.common.security.SecurityTestData;
import com.acme.iam.common.security.SecurityTestEndpoints;
import com.acme.iam.common.test.IntegrationTest;
import com.acme.iam.common.test.PostgresTestBase;
import com.acme.iam.common.test.TestTokens;
import com.acme.iam.core.revocation.RevocationEntry;
import com.acme.iam.core.revocation.RevocationRegistry;
import java.time.Duration;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.context.annotation.Import;
import org.springframework.http.MediaType;
import org.springframework.jdbc.core.simple.JdbcClient;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.transaction.IllegalTransactionStateException;
import org.springframework.transaction.support.TransactionTemplate;

/** P1-10.1 / P1-10.2: set-based revocation, feed, purge, in-service poller and RevocationFilter. */
@IntegrationTest
@AutoConfigureMockMvc
@Import(SecurityTestEndpoints.class)
class RevocationIT extends PostgresTestBase {

  @Autowired MockMvc mvc;
  @Autowired TestTokens tokens;
  @Autowired JdbcClient jdbc;
  @Autowired TransactionTemplate tx;
  @Autowired RevocationService revocations;
  @Autowired RevocationPoller poller;
  @Autowired RevocationRegistry registry;
  @Autowired com.acme.iam.audit.AuditWriter auditWriter;

  private SecurityTestData data;
  private UUID account;
  private UUID tenant;

  @BeforeEach
  void setUp() {
    data = new SecurityTestData(jdbc);
    account = data.account();
    tenant = data.tenant(account);
  }

  @Test
  void revokeUsersBumpsSessionVersionAndAppendsFeedRowsInTheCallersTransaction() {
    UUID alice = data.user(account, tenant);
    UUID bob = data.user(account, tenant);

    Integer count = tx.execute(s -> revocations.revokeUsers(List.of(alice, bob, alice), "user.disabled"));

    assertThat(count).isEqualTo(2);
    assertThat(data.sessionVersion(alice)).isEqualTo(2);
    assertThat(feedRows(alice)).containsExactly(Map.of("min_sv", 2, "reason", "user.disabled"));
    assertThat(feedRows(bob)).containsExactly(Map.of("min_sv", 2, "reason", "user.disabled"));
  }

  @Test
  void oneRevocationWritesOneSummaryAuditEventAndNoPerUserTriggerRows() {
    UUID bulkTenant = data.tenant(account);
    List<UUID> users = java.util.stream.IntStream.range(0, 3).mapToObj(i -> data.user(account, bulkTenant)).toList();
    String requestId = "rev-audit-" + UUID.randomUUID();

    withRequestId(requestId, () -> tx.executeWithoutResult(s -> revocations.revokeTenantMembers(bulkTenant, "tenant.suspended")));

    List<Map<String, Object>> rows = jdbc.sql("""
            SELECT action, outcome, target_type, target_id, metadata->>'reason' AS reason,
                   (metadata->>'count')::int AS count, metadata->'user_ids' AS user_ids
            FROM audit_event WHERE request_id = ?""")
        .params(requestId).query().listOfRows();
    assertThat(rows).hasSize(1);
    assertThat(rows.get(0))
        .containsEntry("action", "auth.sessions.revoked")
        .containsEntry("outcome", "SUCCESS")
        .containsEntry("reason", "tenant.suspended")
        .containsEntry("count", 3)
        .containsEntry("target_type", "tenant")
        .containsEntry("target_id", bulkTenant.toString());
    assertThat(rows.get(0).get("user_ids").toString()).contains(users.get(0).toString(), users.get(2).toString());
  }

  @Test
  void singleUserRevocationTargetsTheUser() {
    UUID alice = data.user(account, tenant);
    String requestId = "rev-audit-1-" + UUID.randomUUID();

    withRequestId(requestId, () -> tx.executeWithoutResult(s -> revocations.revokeUsers(List.of(alice), "admin.force_logout")));

    Map<String, Object> row = jdbc.sql("SELECT action, target_type, target_id FROM audit_event WHERE request_id = ?")
        .params(requestId).query().singleRow();
    assertThat(row).containsEntry("action", "auth.sessions.revoked")
        .containsEntry("target_type", "app_user").containsEntry("target_id", alice.toString());
  }

  @Test
  void auditedUserIdsAreCappedAt1000() {
    assertThat(RevocationService.cappedIds(java.util.stream.IntStream.range(0, 1500)
        .mapToObj(i -> new UUID(0, i)).toList())).hasSize(1000);
  }

  @Test
  void revocationRollsBackWithTheCaller() {
    UUID alice = data.user(account, tenant);

    assertThatThrownBy(() -> tx.executeWithoutResult(s -> {
      revocations.revokeUsers(List.of(alice), "rolled back");
      throw new IllegalStateException("caller fails");
    })).isInstanceOf(IllegalStateException.class);

    assertThat(data.sessionVersion(alice)).isEqualTo(1);
    assertThat(feedRows(alice)).isEmpty();
  }

  @Test
  void revocationRequiresAnExistingTransaction() {
    UUID alice = data.user(account, tenant);

    assertThatThrownBy(() -> revocations.revokeUsers(List.of(alice), "no tx"))
        .isInstanceOf(IllegalTransactionStateException.class);
  }

  @Test
  void scopeRevocationsHitEveryAffectedUserOnce() {
    UUID otherTenant = data.tenant(account);
    UUID alice = data.user(account, tenant);
    UUID bob = data.user(account, otherTenant);
    data.membership(bob, tenant);
    UUID carol = data.user(account, otherTenant);
    UUID outsider = data.user(data.account(), data.tenant(data.account()));
    UUID role = data.role(account, "test.read");
    data.assign(alice, role, "TENANT", tenant, null);
    data.assign(alice, role, "ACCOUNT", account, null);
    data.assign(carol, role, "TENANT", otherTenant, null);

    assertThat(inTx(() -> revocations.revokeTenantMembers(tenant, "tenant.suspended"))).isEqualTo(2);
    assertThat(List.of(data.sessionVersion(alice), data.sessionVersion(bob), data.sessionVersion(carol)))
        .containsExactly(2, 2, 1);

    assertThat(inTx(() -> revocations.revokeRoleHolders(role, "role.updated"))).isEqualTo(2);
    assertThat(List.of(data.sessionVersion(alice), data.sessionVersion(bob), data.sessionVersion(carol)))
        .containsExactly(3, 2, 2);

    assertThat(inTx(() -> revocations.revokeAccountUsers(account, "account.suspended"))).isEqualTo(3);
    assertThat(List.of(data.sessionVersion(alice), data.sessionVersion(bob), data.sessionVersion(carol)))
        .containsExactly(4, 3, 3);
    assertThat(data.sessionVersion(outsider)).isEqualTo(1);
    assertThat(feedRows(alice)).extracting(r -> r.get("min_sv")).containsExactly(2, 3, 4);
  }

  @Test
  void bulkRevocationRunsInBatches() {
    UUID bulkTenant = data.tenant(account);
    List<UUID> users = java.util.stream.IntStream.range(0, 7).mapToObj(i -> data.user(account, bulkTenant)).toList();
    RevocationService smallBatches = new RevocationService(jdbc, auditWriter, 3);

    Integer count = tx.execute(s -> smallBatches.revokeTenantMembers(bulkTenant, "bulk"));
    Integer listed = tx.execute(s -> smallBatches.revokeUsers(users, "bulk-list"));

    assertThat(count).isEqualTo(7);
    assertThat(listed).isEqualTo(7);
    assertThat(users).allSatisfy(u -> assertThat(data.sessionVersion(u)).isEqualTo(3));
  }

  @Test
  void feedPagesByCursorAndStartCursorCoversTheLookback() {
    UUID alice = data.user(account, tenant);
    UUID bob = data.user(account, tenant);
    long before = revocations.startCursor(Duration.ZERO);
    tx.executeWithoutResult(s -> revocations.revokeUsers(List.of(alice), "one"));
    tx.executeWithoutResult(s -> revocations.revokeUsers(List.of(bob), "two"));

    List<RevocationEntry> page1 = revocations.since(before, 1);
    List<RevocationEntry> page2 = revocations.since(page1.get(0).id(), 10);

    assertThat(page1).extracting(RevocationEntry::userId).containsExactly(alice);
    assertThat(page2).extracting(RevocationEntry::userId).containsExactly(bob);
    assertThat(page2.get(0).minSv()).isEqualTo(2);
    assertThat(revocations.startCursor(Duration.ofMinutes(20))).isLessThan(page1.get(0).id());
    assertThat(revocations.startCursor(Duration.ZERO)).isEqualTo(page2.get(0).id());
  }

  @Test
  void purgeDeletesRowsOlderThanTheRetention() {
    UUID alice = data.user(account, tenant);
    jdbc.sql("INSERT INTO revocation (user_id, min_sv, reason, created_at) VALUES (?, 5, 'old', now() - interval '2 hours')")
        .params(alice).update();
    tx.executeWithoutResult(s -> revocations.revokeUsers(List.of(alice), "recent"));

    int purged = revocations.purge(Duration.ofHours(1));

    assertThat(purged).isGreaterThanOrEqualTo(1);
    assertThat(feedRows(alice)).extracting(r -> r.get("reason")).containsExactly("recent");
  }

  @Test
  void revokedTokenIsRejectedAfterThePollOnApiAndAuthChains() throws Exception {
    UUID alice = data.user(account, tenant);
    String token = tokens.user(alice).account(account).tenant(tenant).sv(1).mint();
    mvc.perform(get(SecurityTestEndpoints.ME).header(AUTHORIZATION, TestTokens.bearer(token)))
        .andExpect(status().isOk());

    tx.executeWithoutResult(s -> revocations.revokeUsers(List.of(alice), "admin.force_logout"));
    poller.poll();

    assertThat(registry.isRevoked(alice, 1)).isTrue();
    mvc.perform(get(SecurityTestEndpoints.ME).header(AUTHORIZATION, TestTokens.bearer(token)))
        .andExpect(status().isUnauthorized())
        .andExpect(header().string(WWW_AUTHENTICATE, org.hamcrest.Matchers.startsWith("Bearer error=\"token_revoked\"")))
        .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_PROBLEM_JSON))
        .andExpect(jsonPath("$.code").value("token_revoked"))
        .andExpect(jsonPath("$.requestId").isNotEmpty());
    mvc.perform(post("/auth/logout").header(AUTHORIZATION, TestTokens.bearer(token)))
        .andExpect(status().isUnauthorized())
        .andExpect(jsonPath("$.code").value("token_revoked"));

    String fresh = tokens.user(alice).account(account).tenant(tenant).sv(2).mint();
    mvc.perform(get(SecurityTestEndpoints.ME).header(AUTHORIZATION, TestTokens.bearer(fresh)))
        .andExpect(status().isOk());
  }

  @Test
  void internalTokenReadsTheFeedButUserTokensCannot() throws Exception {
    UUID alice = data.user(account, tenant);
    long cursor = revocations.startCursor(Duration.ZERO);
    tx.executeWithoutResult(s -> revocations.revokeUsers(List.of(alice), "feed"));
    String app = TestTokens.bearer(tokens.appToken("billing-svc", "BILLING"));

    mvc.perform(get("/internal/revocations").param("since", String.valueOf(cursor)).header(AUTHORIZATION, app))
        .andExpect(status().isOk())
        .andExpect(jsonPath("$.entries.length()").value(1))
        .andExpect(jsonPath("$.entries[0].userId").value(alice.toString()))
        .andExpect(jsonPath("$.entries[0].minSv").value(2))
        .andExpect(jsonPath("$.entries[0].id").isNumber())
        .andExpect(jsonPath("$.cursor").value(revocations.since(cursor, 1).get(0).id()));

    // without since: the last 20 minutes (poller startup)
    mvc.perform(get("/internal/revocations").header(AUTHORIZATION, app))
        .andExpect(status().isOk())
        .andExpect(jsonPath("$.entries[?(@.userId == '" + alice + "')]").exists());

    mvc.perform(get("/internal/revocations").header(AUTHORIZATION, tokens.user(alice).sv(2).bearer()))
        .andExpect(status().isForbidden());
    mvc.perform(get("/internal/revocations"))
        .andExpect(status().isUnauthorized());
    mvc.perform(get("/internal/revocations").param("since", "-1").header(AUTHORIZATION, app))
        .andExpect(status().isBadRequest());
  }

  private static void withRequestId(String requestId, Runnable action) {
    org.slf4j.MDC.put("requestId", requestId);
    try {
      action.run();
    } finally {
      org.slf4j.MDC.remove("requestId");
    }
  }

  private int inTx(java.util.function.IntSupplier revocation) {
    return tx.execute(s -> revocation.getAsInt());
  }

  private List<Map<String, Object>> feedRows(UUID user) {
    return jdbc.sql("SELECT min_sv, reason FROM revocation WHERE user_id = ? ORDER BY id")
        .params(user).query().listOfRows();
  }
}
