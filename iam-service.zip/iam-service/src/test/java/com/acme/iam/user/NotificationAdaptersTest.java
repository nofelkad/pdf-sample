package com.acme.iam.user;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.springframework.boot.test.context.runner.ApplicationContextRunner;
import org.springframework.boot.test.system.CapturedOutput;
import org.springframework.boot.test.system.OutputCaptureExtension;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;

/** {@link NotificationPort} adapters and their selection by {@code iam.notification.mode}. */
@ExtendWith(OutputCaptureExtension.class)
class NotificationAdaptersTest {

  private static final String TOKEN = "s3cr3t-T0ken_value-that-must-not-leak-xxxxx";

  private final ApplicationContextRunner runner = new ApplicationContextRunner()
      .withUserConfiguration(NotificationConfig.class);

  @Test
  void loggingIsTheDefaultAdapter() {
    runner.run(ctx -> assertThat(ctx).getBean(NotificationPort.class).isInstanceOf(LoggingNotificationAdapter.class));
    runner.withPropertyValues("iam.notification.mode=log")
        .run(ctx -> assertThat(ctx).getBean(NotificationPort.class).isInstanceOf(LoggingNotificationAdapter.class));
  }

  @Test
  void smtpModeSelectsTheSmtpAdapter() {
    runner.withPropertyValues("iam.notification.mode=smtp", "iam.notification.invitation-url=https://app.acme.test/invite?t={token}",
        "iam.notification.password-reset-url=https://app.acme.test/reset?t={token}")
        .withBean(JavaMailSender.class, () -> mock(JavaMailSender.class))
        .run(ctx -> {
          assertThat(ctx).hasSingleBean(NotificationPort.class);
          assertThat(ctx).getBean(NotificationPort.class).isInstanceOf(SmtpNotificationAdapter.class);
        });
  }

  @Test
  void modeBindsRelaxedly() {
    runner.withPropertyValues("iam.notification.mode=SMTP", "iam.notification.invitation-url=https://app.acme.test/invite?t={token}",
        "iam.notification.password-reset-url=https://app.acme.test/reset?t={token}")
        .withBean(JavaMailSender.class, () -> mock(JavaMailSender.class))
        .run(ctx -> assertThat(ctx).getBean(NotificationPort.class).isInstanceOf(SmtpNotificationAdapter.class));
    runner.withPropertyValues("iam.notification.mode=Log")
        .run(ctx -> assertThat(ctx).getBean(NotificationPort.class).isInstanceOf(LoggingNotificationAdapter.class));
  }

  @Test
  void unknownModeFailsAtStartup() {
    runner.withPropertyValues("iam.notification.mode=smpt").run(ctx -> {
      assertThat(ctx).hasFailed();
      assertThat(ctx.getStartupFailure()).hasStackTraceContaining("iam.notification.mode");
    });
  }

  @Test
  void smtpModeWithoutAMailServerFailsFast() {
    runner.withPropertyValues("iam.notification.mode=smtp",
        "iam.notification.invitation-url=https://app.acme.test/invite?t={token}",
        "iam.notification.password-reset-url=https://app.acme.test/reset?t={token}").run(ctx -> {
      assertThat(ctx).hasFailed();
      assertThat(ctx.getStartupFailure()).hasStackTraceContaining("spring.mail.host");
    });
  }

  // ----------------------------------------------------------------- ruling R44 (final review M5)

  @Test
  void smtpModeWithLocalhostLinksFailsFast() {
    runner.withPropertyValues("iam.notification.mode=smtp")
        .withBean(JavaMailSender.class, () -> mock(JavaMailSender.class))
        .run(ctx -> {
          assertThat(ctx).hasFailed();
          assertThat(ctx.getStartupFailure()).hasStackTraceContaining("iam.notification.invitation-url");
        });
    for (String local : new String[] {"http://127.0.0.1:3000/a?t={token}", "http://[::1]/a?t={token}",
        "https://LOCALHOST/a?t={token}", "http://app.localhost/a?t={token}"}) {
      runner.withPropertyValues("iam.notification.mode=smtp", "iam.notification.invitation-url=" + local,
              "iam.notification.password-reset-url=https://app.acme.test/reset?t={token}")
          .withBean(JavaMailSender.class, () -> mock(JavaMailSender.class))
          .run(ctx -> assertThat(ctx).as(local).hasFailed());
    }
  }

  @Test
  void smtpModeWithAMissingOrRelativeLinkFailsFast() {
    for (String bad : new String[] {"", "/invite?t={token}", "https://app.acme.test/invite"}) {
      runner.withPropertyValues("iam.notification.mode=smtp", "iam.notification.invitation-url=https://app.acme.test/i?t={token}",
              "iam.notification.password-reset-url=" + bad)
          .withBean(JavaMailSender.class, () -> mock(JavaMailSender.class))
          .run(ctx -> {
            assertThat(ctx).as("'" + bad + "'").hasFailed();
            assertThat(ctx.getStartupFailure()).hasStackTraceContaining("iam.notification.password-reset-url");
          });
    }
  }

  @Test
  void logModeWarnsOutsideTheDevLocalAndTestProfiles(CapturedOutput output) {
    runner.withPropertyValues("spring.profiles.active=dev").run(ctx -> assertThat(ctx).hasNotFailed());
    runner.withPropertyValues("spring.profiles.active=test").run(ctx -> assertThat(ctx).hasNotFailed());
    assertThat(output.getAll()).doesNotContain("iam.notification.mode=log");

    runner.withPropertyValues("spring.profiles.active=prod").run(ctx -> assertThat(ctx).hasNotFailed());
    assertThat(output.getAll()).contains("iam.notification.mode=log");
  }

  @Test
  void loggingAdapterNeverLogsTheTokenAndMasksTheAddress(CapturedOutput output) {
    LoggingNotificationAdapter adapter = new LoggingNotificationAdapter();
    adapter.sendInvitation("jane.doe@example.test", "Acme", TOKEN);
    adapter.sendPasswordReset("jane.doe@example.test", TOKEN);

    assertThat(output.getAll()).contains("notification.invitation", "notification.password_reset", "j***@example.test")
        .doesNotContain(TOKEN)
        .doesNotContain("jane.doe@");
  }

  @Test
  void smtpAdapterSendsLinksAndNeverLogsTheToken(CapturedOutput output) {
    JavaMailSender mail = mock(JavaMailSender.class);
    NotificationProperties properties = new NotificationProperties(NotificationProperties.Mode.SMTP, "iam@acme.test",
        "https://app.acme.test/invite?t={token}", "https://app.acme.test/reset?t={token}", true);
    SmtpNotificationAdapter adapter = new SmtpNotificationAdapter(mail, properties);

    adapter.sendInvitation("jane@example.test", "Acme", TOKEN);
    adapter.sendPasswordReset("jane@example.test", TOKEN);

    ArgumentCaptor<SimpleMailMessage> sent = ArgumentCaptor.forClass(SimpleMailMessage.class);
    verify(mail, org.mockito.Mockito.times(2)).send(sent.capture());
    SimpleMailMessage invitation = sent.getAllValues().get(0);
    assertThat(invitation.getTo()).containsExactly("jane@example.test");
    assertThat(invitation.getFrom()).isEqualTo("iam@acme.test");
    assertThat(invitation.getSubject()).contains("Acme");
    assertThat(invitation.getText()).contains("https://app.acme.test/invite?t=" + TOKEN);
    assertThat(sent.getAllValues().get(1).getText()).contains("https://app.acme.test/reset?t=" + TOKEN);
    assertThat(output.getAll()).doesNotContain(TOKEN);
  }
}
