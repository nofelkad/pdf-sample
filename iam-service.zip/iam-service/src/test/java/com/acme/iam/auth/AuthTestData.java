package com.acme.iam.auth;

import com.acme.iam.assignment.ScopeType;
import com.acme.iam.common.test.CapturingNotificationAdapter;
import com.acme.iam.common.test.Fixtures;
import com.acme.iam.user.UserStatus;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.time.Duration;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import org.awaitility.Awaitility;
import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Primary;
import org.springframework.jdbc.core.simple.JdbcClient;

/** SQL fixtures for the authentication tests: users with real Argon2 passwords, sessions, audit rows. */
final class AuthTestData {

  static final String PASSWORD = "Correct-Horse-42!";
  /** The stub breached checker reports every password containing this marker. */
  static final String BREACHED_MARKER = "breached";

  /** Test beans: a stub breached-password checker (no network). */
  @TestConfiguration(proxyBeanMethods = false)
  static class Config {
    @Bean
    @Primary
    BreachedPasswordChecker stubBreachedPasswordChecker() {
      return raw -> raw.toLowerCase().contains(BREACHED_MARKER);
    }
  }

  record TestUser(UUID accountId, UUID tenantId, UUID userId, String email, String password) {}

  final JdbcClient jdbc;
  final Fixtures fx;
  final PasswordService passwords;

  AuthTestData(JdbcClient jdbc, PasswordService passwords) {
    this.jdbc = jdbc;
    this.fx = new Fixtures(jdbc);
    this.passwords = passwords;
  }

  /** ACTIVE account → ACTIVE tenant → ACTIVE user with {@link #PASSWORD}. */
  TestUser user() {
    Fixtures.Scenario s = fx.scenario();
    setPassword(s.userId(), PASSWORD);
    return new TestUser(s.accountId(), s.tenantId(), s.userId(), fx.email(s.userId()), PASSWORD);
  }

  /** Another ACTIVE user with {@link #PASSWORD} in the given account and primary tenant. */
  TestUser user(UUID accountId, UUID tenantId) {
    UUID id = fx.user(accountId, tenantId);
    setPassword(id, PASSWORD);
    return new TestUser(accountId, tenantId, id, fx.email(id), PASSWORD);
  }

  /** A user in a new account with the same email as {@code twin} and the given password. */
  TestUser twinInNewAccount(TestUser twin, String password) {
    UUID account = fx.account();
    UUID tenant = fx.tenant(account);
    UUID id = fx.user(account, tenant);
    jdbc.sql("UPDATE app_user SET email = :email WHERE id = :id").param("email", twin.email()).param("id", id).update();
    setPassword(id, password);
    return new TestUser(account, tenant, id, twin.email(), password);
  }

  UUID invitedUser(UUID accountId, UUID tenantId) {
    return fx.user(accountId, tenantId, UserStatus.INVITED);
  }

  void setPassword(UUID userId, String raw) {
    jdbc.sql("UPDATE app_user SET password_hash = :hash WHERE id = :id")
        .param("hash", passwords.hash(raw)).param("id", userId).update();
  }

  String slug(UUID accountId) {
    return jdbc.sql("SELECT slug FROM account WHERE id = :id").param("id", accountId).query(String.class).single();
  }

  String accountName(UUID accountId) {
    return jdbc.sql("SELECT name FROM account WHERE id = :id").param("id", accountId).query(String.class).single();
  }

  void accountSettings(UUID accountId, String json) {
    jdbc.sql("UPDATE account SET settings = CAST(:json AS jsonb) WHERE id = :id")
        .param("json", json).param("id", accountId).update();
  }

  /**
   * A permission of a fresh product (subscribed by the tenant's account and enabled in the tenant), granted to the
   * user at TENANT scope through a system role.
   */
  String grantTenantPermission(UUID userId, UUID tenantId) {
    UUID accountId = jdbc.sql("SELECT account_id FROM tenant WHERE id = :id").param("id", tenantId)
        .query(UUID.class).single();
    UUID product = fx.entitledProduct(accountId, tenantId);
    UUID permission = fx.permission(product);
    UUID role = fx.systemRole(product, permission);
    fx.assign(userId, role, ScopeType.TENANT, tenantId);
    return fx.code(permission);
  }

  int sessionVersion(UUID userId) {
    return jdbc.sql("SELECT session_version FROM app_user WHERE id = :id").param("id", userId)
        .query(Integer.class).single();
  }

  Map<String, Object> sessionByRefresh(String rawRefresh) {
    return jdbc.sql("SELECT * FROM user_session WHERE refresh_hash = :h").param("h", sha256(rawRefresh))
        .query().singleRow();
  }

  Map<String, Object> session(UUID sessionId) {
    return jdbc.sql("SELECT * FROM user_session WHERE id = :id").param("id", sessionId).query().singleRow();
  }

  List<Map<String, Object>> sessionsOf(UUID userId) {
    return jdbc.sql("SELECT * FROM user_session WHERE user_id = :id ORDER BY created_at").param("id", userId)
        .query().listOfRows();
  }

  List<String> revocationReasons(UUID userId) {
    return jdbc.sql("SELECT reason FROM revocation WHERE user_id = :id ORDER BY id").param("id", userId)
        .query(String.class).list();
  }

  /**
   * {@code action/outcome/actor_type} of the {@code auth.*} audit events of one request, in insertion order (trigger
   * rows such as {@code iam.app_user.update} are left out).
   */
  List<String> auditOfRequest(String requestId) {
    return jdbc.sql("""
            SELECT action || '/' || outcome || '/' || actor_type FROM audit_event
            WHERE request_id = :rid AND action LIKE 'auth.%' ORDER BY occurred_at, event_id""")
        .param("rid", requestId).query(String.class).list();
  }

  /** Full audit rows of one action for one request. */
  List<Map<String, Object>> auditRows(String requestId, String action) {
    return jdbc.sql("""
            SELECT action, outcome, actor_type, actor_user_id, account_id, tenant_id, session_id,
                   host(actor_ip) AS actor_ip, user_agent, target_type, target_id, metadata::text AS metadata
            FROM audit_event WHERE request_id = :rid AND action = :action ORDER BY occurred_at, event_id""")
        .param("rid", requestId).param("action", action).query().listOfRows();
  }

  /**
   * Waits until {@code count} password-reset mails to {@code email} were sent (they are issued and mailed off the
   * request thread, R31) and returns the newest token.
   */
  static String awaitResetToken(CapturingNotificationAdapter mailbox, String email, int count) {
    Awaitility.await().atMost(Duration.ofSeconds(10)).pollInterval(Duration.ofMillis(20)).until(() ->
        mailbox.sent().stream().filter(m -> m.kind() == CapturingNotificationAdapter.Kind.PASSWORD_RESET
            && m.email().equalsIgnoreCase(email)).count() >= count);
    return mailbox.lastPasswordResetToken(email);
  }

  static byte[] sha256(String raw) {
    try {
      return MessageDigest.getInstance("SHA-256").digest(raw.getBytes(StandardCharsets.US_ASCII));
    } catch (Exception e) {
      throw new IllegalStateException(e);
    }
  }
}
