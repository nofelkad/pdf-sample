package com.acme.iam.user;

import static org.assertj.core.api.Assertions.assertThat;

import com.acme.iam.common.test.Fixtures;
import com.acme.iam.common.test.JdbcSliceTest;
import com.acme.iam.common.test.PostgresTestBase;
import java.security.SecureRandom;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.simple.JdbcClient;

/** P1-3.2: UserToken round trip and the atomic single-use update. */
@JdbcSliceTest
class UserTokenRepositoryTest extends PostgresTestBase {

  @Autowired UserTokenRepository tokens;
  @Autowired JdbcClient jdbc;

  @Test
  void roundTripsAndConsumesOnce() {
    Fixtures fx = new Fixtures(jdbc);
    Fixtures.Scenario s = fx.scenario();
    byte[] hash = new byte[32];
    new SecureRandom().nextBytes(hash);
    Instant now = Instant.now().truncatedTo(ChronoUnit.MICROS);

    UserToken saved = tokens.save(UserToken.create(s.userId(), TokenPurpose.INVITE, hash, now.plusSeconds(3600),
        s.userId()));
    assertThat(saved.id()).isNotNull();

    UserToken loaded = tokens.findByTokenHash(hash).orElseThrow();
    assertThat(loaded.id()).isEqualTo(saved.id());
    assertThat(loaded.user()).isEqualTo(s.userId());
    assertThat(loaded.purpose()).isEqualTo(TokenPurpose.INVITE);
    assertThat(loaded.tokenHash()).isEqualTo(hash);
    assertThat(loaded.expiresAt()).isEqualTo(now.plusSeconds(3600));
    assertThat(loaded.usedAt()).isNull();
    assertThat(loaded.createdBy().getId()).isEqualTo(s.userId());
    assertThat(loaded.createdAt()).isNotNull();

    assertThat(tokens.markUsed(hash, TokenPurpose.PASSWORD_RESET.name(), now)).as("wrong purpose").isZero();
    assertThat(tokens.markUsed(hash, TokenPurpose.INVITE.name(), now)).isEqualTo(1);
    assertThat(tokens.markUsed(hash, TokenPurpose.INVITE.name(), now)).as("already used").isZero();
    assertThat(tokens.findByTokenHash(hash).orElseThrow().usedAt()).isEqualTo(now);
  }
}
