package com.acme.iam.common.security;

import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.http.HttpHeaders.ACCESS_CONTROL_ALLOW_ORIGIN;
import static org.springframework.http.HttpHeaders.ACCESS_CONTROL_REQUEST_HEADERS;
import static org.springframework.http.HttpHeaders.ACCESS_CONTROL_REQUEST_METHOD;
import static org.springframework.http.HttpHeaders.AUTHORIZATION;
import static org.springframework.http.HttpHeaders.CACHE_CONTROL;
import static org.springframework.http.HttpHeaders.ORIGIN;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.options;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.header;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import com.acme.iam.common.test.IntegrationTest;
import com.acme.iam.common.test.PostgresTestBase;
import java.util.List;
import org.hamcrest.Matchers;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.ResultActions;

/**
 * Task 9 security review: CORS is denied by default and opened only for {@code iam.security.cors.allowed-origins};
 * every response carries HSTS, {@code nosniff}, frame denial and a restrictive CSP; {@code /auth/**} responses are
 * {@code no-store}.
 */
@IntegrationTest(properties = "iam.security.cors.allowed-origins=https://admin.example.test")
@AutoConfigureMockMvc
class HttpHardeningIT extends PostgresTestBase {

  private static final String ALLOWED = "https://admin.example.test";

  @Autowired MockMvc mvc;

  @Test
  void corsPreflightFromAnAllowedOriginIsAnswered() throws Exception {
    mvc.perform(options("/api/me").header(ORIGIN, ALLOWED).header(ACCESS_CONTROL_REQUEST_METHOD, "GET")
            .header(ACCESS_CONTROL_REQUEST_HEADERS, "authorization"))
        .andExpect(status().isOk())
        .andExpect(header().string(ACCESS_CONTROL_ALLOW_ORIGIN, ALLOWED))
        .andExpect(header().doesNotExist("Access-Control-Allow-Credentials"));
    mvc.perform(post("/auth/login").header(ORIGIN, ALLOWED).contentType(MediaType.APPLICATION_JSON)
            .content("{\"email\":\"nobody@example.test\",\"password\":\"x\"}"))
        .andExpect(header().string(ACCESS_CONTROL_ALLOW_ORIGIN, ALLOWED));
  }

  @Test
  void corsFromAnyOtherOriginIsRefused() throws Exception {
    mvc.perform(options("/api/me").header(ORIGIN, "https://evil.example").header(ACCESS_CONTROL_REQUEST_METHOD, "GET"))
        .andExpect(status().isForbidden())
        .andExpect(header().doesNotExist(ACCESS_CONTROL_ALLOW_ORIGIN));
    mvc.perform(get("/.well-known/jwks.json").header(ORIGIN, "https://evil.example"))
        .andExpect(status().isForbidden())
        .andExpect(header().doesNotExist(ACCESS_CONTROL_ALLOW_ORIGIN));
  }

  @Test
  void corsIsDeniedByDefault() {
    CorsProperties none = new CorsProperties(List.of());
    MockHttpServletRequest request = new MockHttpServletRequest("OPTIONS", "/api/me");
    request.addHeader(ORIGIN, ALLOWED);

    assertThat(SecurityConfig.corsSource(none).getCorsConfiguration(request)).isNull();
  }

  @Test
  void securityHeadersOnEveryChain() throws Exception {
    for (ResultActions response : List.of(
        mvc.perform(post("/auth/login").contentType(MediaType.APPLICATION_JSON)
            .content("{\"email\":\"nobody@example.test\",\"password\":\"x\"}")),
        mvc.perform(get("/api/me")),
        mvc.perform(get("/api/me").header(AUTHORIZATION, "Bearer junk")),
        mvc.perform(get("/.well-known/jwks.json")),
        mvc.perform(get("/internal/revocations")))) {
      common(response)
          .andExpect(header().string("Content-Security-Policy", "default-src 'none'; frame-ancestors 'none'"));
    }
    // the fallback chain (actuator, error page, springdoc UI) keeps the headers but not the JSON-only CSP
    for (ResultActions response : List.of(mvc.perform(get("/actuator/health")), mvc.perform(get("/no-such-path")))) {
      common(response);
    }
  }

  private static ResultActions common(ResultActions response) throws Exception {
    return response
        .andExpect(header().string("X-Content-Type-Options", "nosniff"))
        .andExpect(header().string("X-Frame-Options", "DENY"))
        .andExpect(header().string("Strict-Transport-Security", "max-age=31536000 ; includeSubDomains"))
        .andExpect(header().string("Referrer-Policy", "no-referrer"));
  }

  @Test
  void authResponsesAreNeverCached() throws Exception {
    mvc.perform(post("/auth/login").contentType(MediaType.APPLICATION_JSON)
            .content("{\"email\":\"nobody@example.test\",\"password\":\"x\"}"))
        .andExpect(header().string(CACHE_CONTROL, Matchers.containsString("no-store")));
    mvc.perform(post("/auth/password/forgot").contentType(MediaType.APPLICATION_JSON)
            .content("{\"email\":\"nobody@example.test\"}"))
        .andExpect(header().string(CACHE_CONTROL, Matchers.containsString("no-store")));
    mvc.perform(post("/auth/refresh").contentType(MediaType.APPLICATION_JSON).content("{\"refreshToken\":\"junk\"}"))
        .andExpect(header().string(CACHE_CONTROL, Matchers.containsString("no-store")));
  }
}
