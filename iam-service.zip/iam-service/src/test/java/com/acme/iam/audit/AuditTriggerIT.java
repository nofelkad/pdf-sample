package com.acme.iam.audit;

import static org.assertj.core.api.Assertions.assertThat;

import com.acme.iam.common.Ids;
import com.acme.iam.common.RequestActor;
import com.acme.iam.common.test.IntegrationTest;
import com.acme.iam.common.test.PostgresTestBase;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.security.oauth2.server.resource.authentication.JwtAuthenticationToken;
import org.springframework.transaction.support.TransactionTemplate;

/**
 * P1-2.2: every INSERT/UPDATE/DELETE on an audited table yields exactly one {@code audit_event} row carrying the
 * transaction-local actor; login bookkeeping updates on {@code app_user} yield none; secrets are stripped; the
 * auth-side tables have no trigger. Runs as {@code iam_app} through the primary (audit-context) transaction manager.
 */
@IntegrationTest
class AuditTriggerIT extends PostgresTestBase {

  @Autowired JdbcTemplate jdbc;
  @Autowired TransactionTemplate tx;

  private final UUID actorUser = UUID.randomUUID();
  private final UUID actorAccount = UUID.randomUUID();
  private final UUID actorTenant = UUID.randomUUID();
  private final UUID actorSession = UUID.randomUUID();

  // fixture rows (created as SYSTEM)
  private UUID account;
  private UUID product;
  private UUID tenant;
  private UUID user;
  private UUID permission;
  private UUID role;

  @BeforeEach
  void fixture() {
    account = Ids.newId();
    product = Ids.newId();
    tenant = Ids.newId();
    user = Ids.newId();
    permission = Ids.newId();
    role = Ids.newId();
    tx.executeWithoutResult(s -> {
      insertAccount(account);
      insertProduct(product);
      insertTenant(tenant, account);
      insertUser(user, account, tenant);
      insertPermission(permission, product);
      insertRole(role, product);
    });
    authenticate();
  }

  @AfterEach
  void clear() {
    SecurityContextHolder.clearContext();
    MDC.clear();
  }

  @Test
  void account() {
    UUID id = Ids.newId();
    assertOneAuditRow("iam.account.insert", id.toString(), () -> insertAccount(id));
    assertOneAuditRow("iam.account.update", id.toString(),
        () -> jdbc.update("UPDATE account SET name = 'Renamed', version = version + 1 WHERE id = ?", id));
    assertOneAuditRow("iam.account.delete", id.toString(), () -> jdbc.update("DELETE FROM account WHERE id = ?", id));
  }

  @Test
  void product() {
    UUID id = Ids.newId();
    assertOneAuditRow("iam.product.insert", id.toString(), () -> insertProduct(id));
    assertOneAuditRow("iam.product.update", id.toString(),
        () -> jdbc.update("UPDATE product SET name = 'Renamed' WHERE id = ?", id));
    assertOneAuditRow("iam.product.delete", id.toString(), () -> jdbc.update("DELETE FROM product WHERE id = ?", id));
  }

  @Test
  void accountProduct() {
    String target = account + ":" + product;
    assertOneAuditRow("iam.account_product.insert", target, () -> jdbc.update(
        "INSERT INTO account_product (account, product_id, status, starts_at) VALUES (?, ?, 'ACTIVE', current_date)",
        account, product));
    assertOneAuditRow("iam.account_product.update", target, () -> jdbc.update(
        "UPDATE account_product SET status = 'SUSPENDED' WHERE account = ? AND product_id = ?", account, product));
    assertOneAuditRow("iam.account_product.delete", target, () -> jdbc.update(
        "DELETE FROM account_product WHERE account = ? AND product_id = ?", account, product));
  }

  @Test
  void tenant() {
    UUID id = Ids.newId();
    assertOneAuditRow("iam.tenant.insert", id.toString(), () -> insertTenant(id, account));
    assertOneAuditRow("iam.tenant.update", id.toString(),
        () -> jdbc.update("UPDATE tenant SET status = 'SUSPENDED', version = version + 1 WHERE id = ?", id));
    assertOneAuditRow("iam.tenant.delete", id.toString(), () -> jdbc.update("DELETE FROM tenant WHERE id = ?", id));
  }

  @Test
  void tenantProduct() {
    String target = tenant + ":" + product;
    assertOneAuditRow("iam.tenant_product.insert", target, () -> jdbc.update(
        "INSERT INTO tenant_product (tenant, product_id) VALUES (?, ?)", tenant, product));
    assertOneAuditRow("iam.tenant_product.update", target, () -> jdbc.update(
        "UPDATE tenant_product SET enabled = false WHERE tenant = ? AND product_id = ?", tenant, product));
    assertOneAuditRow("iam.tenant_product.delete", target, () -> jdbc.update(
        "DELETE FROM tenant_product WHERE tenant = ? AND product_id = ?", tenant, product));
  }

  @Test
  void permission() {
    UUID id = Ids.newId();
    assertOneAuditRow("iam.permission.insert", id.toString(), () -> insertPermission(id, product));
    assertOneAuditRow("iam.permission.update", id.toString(),
        () -> jdbc.update("UPDATE permission SET deprecated = true WHERE id = ?", id));
    assertOneAuditRow("iam.permission.delete", id.toString(),
        () -> jdbc.update("DELETE FROM permission WHERE id = ?", id));
  }

  @Test
  void appUser() {
    UUID id = Ids.newId();
    assertOneAuditRow("iam.app_user.insert", id.toString(), () -> insertUser(id, account, tenant));
    assertOneAuditRow("iam.app_user.update", id.toString(),
        () -> jdbc.update("UPDATE app_user SET display_name = 'New Name', version = version + 1 WHERE id = ?", id));
    assertOneAuditRow("iam.app_user.delete", id.toString(), () -> jdbc.update("DELETE FROM app_user WHERE id = ?", id));
  }

  @Test
  void appUserLoginBookkeepingIsNotAudited() {
    assertAuditRows(0, () -> jdbc.update("""
        UPDATE app_user SET last_login_at = now(), failed_logins = failed_logins + 1, locked_until = now(),
                            updated_at = now(), version = version + 1
        WHERE id = ?""", user));
    assertAuditRows(0, () -> jdbc.update("UPDATE app_user SET failed_logins = 0 WHERE id = ?", user));
  }

  @Test
  void appUserPasswordHashIsStrippedFromAuditState() {
    List<Map<String, Object>> rows = assertOneAuditRow("iam.app_user.update", user.toString(), () -> jdbc.update(
        "UPDATE app_user SET password_hash = 'argon2-secret', status = 'ACTIVE' WHERE id = ?", user));

    assertThat((String) rows.get(0).get("before_state")).doesNotContain("password_hash");
    assertThat((String) rows.get(0).get("after_state")).doesNotContain("password_hash").doesNotContain("argon2");
  }

  @Test
  void userTenantMembership() {
    String target = user + ":" + tenant;
    assertOneAuditRow("iam.user_tenant_membership.insert", target, () -> jdbc.update(
        "INSERT INTO user_tenant_membership (app_user, tenant_id) VALUES (?, ?)", user, tenant));
    assertOneAuditRow("iam.user_tenant_membership.update", target, () -> jdbc.update(
        "UPDATE user_tenant_membership SET status = 'SUSPENDED' WHERE app_user = ? AND tenant_id = ?", user, tenant));
    assertOneAuditRow("iam.user_tenant_membership.delete", target, () -> jdbc.update(
        "DELETE FROM user_tenant_membership WHERE app_user = ? AND tenant_id = ?", user, tenant));
  }

  @Test
  void role() {
    UUID id = Ids.newId();
    assertOneAuditRow("iam.role.insert", id.toString(), () -> insertRole(id, product));
    assertOneAuditRow("iam.role.update", id.toString(),
        () -> jdbc.update("UPDATE role SET description = 'changed', version = version + 1 WHERE id = ?", id));
    assertOneAuditRow("iam.role.delete", id.toString(), () -> jdbc.update("DELETE FROM role WHERE id = ?", id));
  }

  @Test
  void rolePermission() {
    UUID other = Ids.newId();
    tx.executeWithoutResult(s -> insertPermission(other, product));
    assertOneAuditRow("iam.role_permission.insert", role + ":" + permission, () -> jdbc.update(
        "INSERT INTO role_permission (role, permission_id) VALUES (?, ?)", role, permission));
    assertOneAuditRow("iam.role_permission.update", role + ":" + other, () -> jdbc.update(
        "UPDATE role_permission SET permission_id = ? WHERE role = ? AND permission_id = ?", other, role, permission));
    assertOneAuditRow("iam.role_permission.delete", role + ":" + other, () -> jdbc.update(
        "DELETE FROM role_permission WHERE role = ? AND permission_id = ?", role, other));
  }

  @Test
  void roleAssignment() {
    UUID id = Ids.newId();
    assertOneAuditRow("iam.role_assignment.insert", id.toString(), () -> jdbc.update("""
        INSERT INTO role_assignment (id, user_id, role_id, scope_type, scope_id, version)
        VALUES (?, ?, ?, 'TENANT', ?, 0)""", id, user, role, tenant));
    assertOneAuditRow("iam.role_assignment.update", id.toString(), () -> jdbc.update(
        "UPDATE role_assignment SET expires_at = now() + interval '1 day', version = version + 1 WHERE id = ?", id));
    assertOneAuditRow("iam.role_assignment.delete", id.toString(),
        () -> jdbc.update("DELETE FROM role_assignment WHERE id = ?", id));
  }

  @Test
  void signingKeyWithoutPrivateMaterial() {
    String kid = "kid-" + Ids.newId();
    List<Map<String, Object>> inserted = assertOneAuditRow("iam.signing_key.insert", kid, () -> jdbc.update(
        "INSERT INTO signing_key (kid, public_jwk, private_enc, status) VALUES (?, '{\"kty\":\"RSA\"}'::jsonb, ?, 'PUBLISHED')",
        kid, new byte[] {1, 2, 3}));
    assertThat((String) inserted.get(0).get("after_state")).doesNotContain("private_enc");
    assertOneAuditRow("iam.signing_key.update", kid,
        () -> jdbc.update("UPDATE signing_key SET status = 'RETIRED' WHERE kid = ?", kid)); // one ACTIVE key (V7)
    assertOneAuditRow("iam.signing_key.delete", kid, () -> jdbc.update("DELETE FROM signing_key WHERE kid = ?", kid));
  }

  @Test
  void authTablesHaveNoTrigger() {
    UUID session = Ids.newId();
    assertAuditRows(0, () -> jdbc.update("""
        INSERT INTO user_session (id, user_id, active_tenant_id, refresh_hash, expires_at, version)
        VALUES (?, ?, ?, ?, now() + interval '1 day', 0)""", session, user, tenant, new byte[] {9}));
    assertAuditRows(0, () -> jdbc.update("""
        INSERT INTO user_token (id, user_id, purpose, token_hash, expires_at)
        VALUES (?, ?, 'INVITE', ?, now() + interval '1 day')""", Ids.newId(), user, new byte[] {8}));
    assertAuditRows(0, () -> jdbc.update(
        "INSERT INTO password_history (user_id, password_hash) VALUES (?, 'h')", user));
    assertAuditRows(0, () -> jdbc.update(
        "INSERT INTO revocation (user_id, min_sv, reason) VALUES (?, 2, 'test')", user));
  }

  @Test
  void auditRowCarriesTheTransactionActor() {
    UUID id = Ids.newId();
    Map<String, Object> row = assertOneAuditRow("iam.product.insert", id.toString(), () -> insertProduct(id)).get(0);

    assertThat(row)
        .containsEntry("actor_user_id", actorUser)
        .containsEntry("actor_type", "USER")
        .containsEntry("account_id", actorAccount)
        .containsEntry("tenant_id", actorTenant)
        .containsEntry("session_id", actorSession)
        .containsEntry("source", "IAM")
        .containsEntry("outcome", "SUCCESS")
        .containsEntry("target_type", "product");
    assertThat(row.get("before_state")).isNull();
    assertThat((String) row.get("after_state")).contains(id.toString());
  }

  @Test
  void withoutJwtTheTriggerRecordsSystemActor() {
    SecurityContextHolder.clearContext();
    UUID id = Ids.newId();

    Map<String, Object> row = assertOneAuditRow("iam.product.insert", id.toString(), () -> insertProduct(id)).get(0);

    assertThat(row).containsEntry("actor_type", "SYSTEM");
    assertThat(row.get("actor_user_id")).isNull();
  }

  // ---------------------------------------------------------------------------------------------------------------

  /** Runs {@code statement} in its own transaction under a fresh request id; exactly one row with that action. */
  private List<Map<String, Object>> assertOneAuditRow(String action, String targetId, Runnable statement) {
    List<Map<String, Object>> rows = assertAuditRows(1, statement);
    assertThat(rows.get(0)).containsEntry("action", action).containsEntry("target_id", targetId);
    return rows;
  }

  private List<Map<String, Object>> assertAuditRows(int expected, Runnable statement) {
    String requestId = "trg-" + Ids.newId();
    MDC.put(RequestActor.MDC_REQUEST_ID, requestId);
    try {
      tx.executeWithoutResult(s -> statement.run());
    } finally {
      MDC.remove(RequestActor.MDC_REQUEST_ID);
    }
    List<Map<String, Object>> rows = jdbc.queryForList("""
        SELECT action, target_type, target_id, actor_user_id, actor_type, account_id, tenant_id, session_id,
               source, outcome, before_state::text AS before_state, after_state::text AS after_state
        FROM audit_event WHERE request_id = ?""", requestId);
    assertThat(rows).hasSize(expected);
    return rows;
  }

  private void authenticate() {
    Jwt jwt = Jwt.withTokenValue("t").header("alg", "none").subject(actorUser.toString())
        .claim("acc", actorAccount.toString()).claim("tid", actorTenant.toString())
        .claim("sid", actorSession.toString()).build();
    SecurityContextHolder.getContext().setAuthentication(new JwtAuthenticationToken(jwt));
  }

  private void insertAccount(UUID id) {
    jdbc.update("INSERT INTO account (id, name, slug, status, version) VALUES (?, 'Acme', ?, 'ACTIVE', 0)",
        id, "acme-" + id);
  }

  private void insertProduct(UUID id) {
    jdbc.update("INSERT INTO product (id, code, name, version) VALUES (?, ?, 'Product', 0)", id, "P-" + id);
  }

  private void insertTenant(UUID id, UUID accountId) {
    jdbc.update("INSERT INTO tenant (id, account_id, name, slug, status, version) VALUES (?, ?, 'T', ?, 'ACTIVE', 0)",
        id, accountId, "t-" + id);
  }

  private void insertUser(UUID id, UUID accountId, UUID tenantId) {
    jdbc.update("""
        INSERT INTO app_user (id, account_id, email, status, primary_tenant_id, version)
        VALUES (?, ?, ?, 'INVITED', ?, 0)""", id, accountId, id + "@example.com", tenantId);
  }

  private void insertPermission(UUID id, UUID productId) {
    jdbc.update("""
        INSERT INTO permission (id, product_id, code, kind, description, version)
        VALUES (?, ?, ?, 'FEATURE', 'test', 0)""", id, productId, "test.perm." + id);
  }

  private void insertRole(UUID id, UUID productId) {
    jdbc.update("INSERT INTO role (id, product_id, name, type, version) VALUES (?, ?, ?, 'SYSTEM', 0)",
        id, productId, "Role " + id);
  }
}
