package com.acme.iam.audit;

import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.http.HttpHeaders.AUTHORIZATION;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import com.acme.iam.common.Ids;
import com.acme.iam.common.test.IntegrationTest;
import com.acme.iam.common.test.PostgresTestBase;
import com.acme.iam.common.test.TestTokens;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import java.time.Clock;
import java.time.Duration;
import java.time.Instant;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.http.MediaType;
import org.springframework.jdbc.core.simple.JdbcClient;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.ResultActions;

/** P1-9.4: {@code POST /internal/audit/events}, the batch ingest used by iam-client's outbox relay. */
@IntegrationTest
@AutoConfigureMockMvc
class AuditIngestIT extends PostgresTestBase {

  private static final String PATH = "/internal/audit/events";

  @Autowired MockMvc mvc;
  @Autowired TestTokens tokens;
  @Autowired JdbcClient jdbc;
  @Autowired ObjectMapper json;
  @Autowired Clock clock;

  private String appToken;

  @BeforeEach
  void setUp() {
    appToken = TestTokens.bearer(tokens.appToken("billing-svc", "BILLING"));
  }

  // ------------------------------------------------------------------------------------- happy path

  @Test
  void storesTheBatchWithSourceFromTheTokenAndAppliesTheDenyList() throws Exception {
    UUID id = Ids.newId();
    UUID account = Ids.newId();
    ObjectNode event = event(id, "invoice.approved");
    event.put("accountId", account.toString());
    event.put("source", "IAM");   // spoof attempt: must be ignored
    event.put("actorIp", "203.0.113.9, 10.0.0.1");
    event.put("targetType", "invoice").put("targetId", "INV-1");
    event.putObject("metadata").put("amount", 12).put("apiToken", "t0p").putObject("nested").put("Password", "pw");
    event.putObject("before").put("status", "DRAFT").put("secretKey", "s3");
    event.putObject("after").put("status", "APPROVED");

    send(appToken, batch(event))
        .andExpect(status().isOk())
        .andExpect(jsonPath("$.accepted").value(1))
        .andExpect(jsonPath("$.duplicates").value(0))
        .andExpect(jsonPath("$.rejected").isEmpty());

    Map<String, Object> row = jdbc.sql("""
            SELECT source, account_id, actor_type, host(actor_ip) AS ip, outcome, target_type, target_id,
                   metadata::text AS metadata, before_state::text AS before, after_state::text AS after
            FROM audit_event WHERE event_id = :id""").param("id", id).query().singleRow();
    assertThat(row).containsEntry("source", "BILLING").containsEntry("account_id", account)
        .containsEntry("actor_type", "SYSTEM").containsEntry("ip", "203.0.113.9").containsEntry("outcome", "SUCCESS")
        .containsEntry("target_type", "invoice").containsEntry("target_id", "INV-1");
    JsonNode metadata = json.readTree((String) row.get("metadata"));
    assertThat(metadata.get("amount").asInt()).isEqualTo(12);
    assertThat(metadata.get("apiToken").asText()).isEqualTo("[REDACTED]");
    assertThat(metadata.at("/nested/Password").asText()).isEqualTo("[REDACTED]");
    assertThat(json.readTree((String) row.get("before")).get("secretKey").asText()).isEqualTo("[REDACTED]");
    assertThat(json.readTree((String) row.get("after")).get("status").asText()).isEqualTo("APPROVED");
    assertThat((String) row.get("metadata")).doesNotContain("t0p").doesNotContain("\"pw\"");
  }

  @Test
  void aRetriedBatchYieldsDuplicatesAndNeverAnError() throws Exception {
    ArrayNode events = events(event(Ids.newId(), "doc.viewed"), event(Ids.newId(), "doc.viewed"),
        event(Ids.newId(), "doc.viewed"));

    send(appToken, body(events)).andExpect(status().isOk())
        .andExpect(jsonPath("$.accepted").value(3)).andExpect(jsonPath("$.duplicates").value(0));
    send(appToken, body(events)).andExpect(status().isOk())
        .andExpect(jsonPath("$.accepted").value(0)).andExpect(jsonPath("$.duplicates").value(3))
        .andExpect(jsonPath("$.rejected").isEmpty());
  }

  @Test
  void aPartiallyKnownBatchSplitsIntoAcceptedAndDuplicates() throws Exception {
    ObjectNode known = event(Ids.newId(), "doc.viewed");
    send(appToken, batch(known)).andExpect(jsonPath("$.accepted").value(1));

    send(appToken, batch(known, event(Ids.newId(), "doc.viewed"), event(Ids.newId(), "doc.viewed")))
        .andExpect(jsonPath("$.accepted").value(2)).andExpect(jsonPath("$.duplicates").value(1));
  }

  @Test
  void theSameEventIdTwiceInOneBatchCountsOnceAndOneDuplicate() throws Exception {
    UUID id = Ids.newId();
    ObjectNode first = event(id, "doc.viewed");
    ObjectNode second = first.deepCopy();

    send(appToken, batch(first, second)).andExpect(jsonPath("$.accepted").value(1))
        .andExpect(jsonPath("$.duplicates").value(1)).andExpect(jsonPath("$.rejected").isEmpty());
  }

  @Test
  void anEmptyBatchIsFine() throws Exception {
    send(appToken, batch()).andExpect(status().isOk()).andExpect(jsonPath("$.accepted").value(0))
        .andExpect(jsonPath("$.duplicates").value(0));
  }

  @Test
  void optionalFieldsMayBeAbsentOrNull() throws Exception {
    UUID id = Ids.newId();
    ObjectNode event = json.createObjectNode();
    event.put("eventId", id.toString()).put("occurredAt", Instant.now().toString()).put("action", "a.b")
        .put("outcome", "FAILURE").put("actorType", "ANONYMOUS");
    event.putNull("accountId").putNull("actorUserId").putNull("before").putNull("metadata");

    send(appToken, batch(event)).andExpect(jsonPath("$.accepted").value(1));

    assertThat(jdbc.sql("SELECT outcome || '/' || actor_type FROM audit_event WHERE event_id = :id")
        .param("id", id).query(String.class).single()).isEqualTo("FAILURE/ANONYMOUS");
  }

  // ------------------------------------------------------------------------------------- batch limits

  @Test
  void fiveHundredEventsAreAcceptedAndMoreAreRefusedWholesale() throws Exception {
    ObjectNode[] ok = new ObjectNode[500];
    for (int i = 0; i < ok.length; i++) {
      ok[i] = event(Ids.newId(), "bulk.ok");
    }
    send(appToken, batch(ok)).andExpect(status().isOk()).andExpect(jsonPath("$.accepted").value(500));

    ObjectNode[] tooMany = new ObjectNode[501];
    for (int i = 0; i < tooMany.length; i++) {
      tooMany[i] = event(Ids.newId(), "bulk.too_many");
    }
    send(appToken, batch(tooMany)).andExpect(status().isBadRequest()).andExpect(jsonPath("$.code").value("batch_too_large"));
    assertThat(jdbc.sql("SELECT count(*) FROM audit_event WHERE action = 'bulk.too_many'").query(Long.class).single())
        .isZero();
  }

  @Test
  void aBodyOverOneMegabyteIsRefusedBeforeItIsParsed() throws Exception {
    ObjectNode big = event(Ids.newId(), "big.event");
    big.putObject("metadata").put("blob", "x".repeat(1_100_000));

    send(appToken, batch(big)).andExpect(status().isPayloadTooLarge())
        .andExpect(jsonPath("$.code").value("payload_too_large"));
  }

  @Test
  void malformedBodiesAreBadRequests() throws Exception {
    mvc.perform(post(PATH).header(AUTHORIZATION, appToken).contentType(MediaType.APPLICATION_JSON).content("{not json"))
        .andExpect(status().isBadRequest()).andExpect(jsonPath("$.code").value("invalid_body"));
    mvc.perform(post(PATH).header(AUTHORIZATION, appToken).contentType(MediaType.APPLICATION_JSON).content("{}"))
        .andExpect(status().isBadRequest()).andExpect(jsonPath("$.code").value("invalid_body"));
    mvc.perform(post(PATH).header(AUTHORIZATION, appToken).contentType(MediaType.APPLICATION_JSON)
            .content("{\"events\":{}}"))
        .andExpect(status().isBadRequest()).andExpect(jsonPath("$.code").value("invalid_body"));
    mvc.perform(post(PATH).header(AUTHORIZATION, appToken).contentType(MediaType.APPLICATION_JSON).content("[]"))
        .andExpect(status().isBadRequest()).andExpect(jsonPath("$.code").value("invalid_body"));
  }

  // ------------------------------------------------------------------------------------- per-event validation

  @Test
  void invalidEventsAreRejectedIndividuallyAndTheRestIsStored() throws Exception {
    ObjectNode good = event(Ids.newId(), "good.event");
    ObjectNode noAction = event(Ids.newId(), "x");
    noAction.remove("action");
    ObjectNode badAction = event(Ids.newId(), "Bad Action!");
    ObjectNode longAction = event(Ids.newId(), "a".repeat(129));
    ObjectNode badOutcome = event(Ids.newId(), "x.y");
    badOutcome.put("outcome", "MAYBE");
    ObjectNode noOutcome = event(Ids.newId(), "x.y");
    noOutcome.remove("outcome");
    ObjectNode badActor = event(Ids.newId(), "x.y");
    badActor.put("actorType", "ROBOT");
    ObjectNode noActor = event(Ids.newId(), "x.y");
    noActor.remove("actorType");
    ObjectNode noTime = event(Ids.newId(), "x.y");
    noTime.remove("occurredAt");
    ObjectNode badTime = event(Ids.newId(), "x.y");
    badTime.put("occurredAt", "yesterday");
    ObjectNode badAccount = event(Ids.newId(), "x.y");
    badAccount.put("accountId", "not-a-uuid");
    ObjectNode longAgent = event(Ids.newId(), "x.y");
    longAgent.put("userAgent", "u".repeat(513));
    ObjectNode nulChar = event(Ids.newId(), "x.y");
    nulChar.putObject("metadata").put("k", "a\u0000b");
    ObjectNode notObject = event(Ids.newId(), "x.y");
    notObject.put("metadata", "text");
    ObjectNode hugePayload = event(Ids.newId(), "x.y");
    hugePayload.putObject("after").put("blob", "z".repeat(40_000));
    ObjectNode noId = event(Ids.newId(), "x.y");
    noId.remove("eventId");
    ObjectNode badId = event(Ids.newId(), "x.y");
    badId.put("eventId", "123");

    JsonNode result = send(appToken, batch(good, noAction, badAction, longAction, badOutcome, noOutcome, badActor,
        noActor, noTime, badTime, badAccount, longAgent, nulChar, notObject, hugePayload, noId, badId))
        .andExpect(status().isOk())
        .andReturn().getResponse().getContentAsString().transform(this::tree);

    assertThat(result.get("accepted").asInt()).isEqualTo(1);
    assertThat(result.get("duplicates").asInt()).isZero();
    Map<UUID, String> reasons = new java.util.HashMap<>();
    List<String> reasonsWithoutId = new java.util.ArrayList<>();
    for (JsonNode r : result.get("rejected")) {
      if (r.hasNonNull("eventId") && r.get("eventId").asText().length() == 36) {
        reasons.put(UUID.fromString(r.get("eventId").asText()), r.get("reason").asText());
      } else {
        reasonsWithoutId.add(r.get("index").asInt() + ":" + r.get("reason").asText());
      }
    }
    assertThat(reasons).containsEntry(id(noAction), "missing_action")
        .containsEntry(id(badAction), "invalid_action")
        .containsEntry(id(longAction), "invalid_action")
        .containsEntry(id(badOutcome), "invalid_outcome")
        .containsEntry(id(noOutcome), "missing_outcome")
        .containsEntry(id(badActor), "invalid_actor_type")
        .containsEntry(id(noActor), "missing_actor_type")
        .containsEntry(id(noTime), "missing_occurred_at")
        .containsEntry(id(badTime), "invalid_occurred_at")
        .containsEntry(id(badAccount), "invalid_account_id")
        .containsEntry(id(longAgent), "field_too_long")
        .containsEntry(id(nulChar), "invalid_characters")
        .containsEntry(id(notObject), "invalid_payload")
        .containsEntry(id(hugePayload), "payload_too_large");
    assertThat(reasonsWithoutId).containsExactlyInAnyOrder("15:missing_event_id", "16:invalid_event_id");
    assertThat(jdbc.sql("SELECT count(*) FROM audit_event WHERE event_id = :id").param("id", id(good))
        .query(Long.class).single()).isEqualTo(1);
  }

  @Test
  void occurredAtMustFallInAnExistingPartitionAndNotBeMoreThanFiveMinutesAhead() throws Exception {
    Instant now = clock.instant();
    ObjectNode justAhead = event(Ids.newId(), "range.ok").put("occurredAt", now.plus(Duration.ofMinutes(4)).toString());
    ObjectNode tooFarAhead = event(Ids.newId(), "range.bad").put("occurredAt", now.plus(Duration.ofMinutes(6)).toString());
    ObjectNode nextYear = event(Ids.newId(), "range.bad").put("occurredAt", now.plus(Duration.ofDays(400)).toString());
    ObjectNode ancient = event(Ids.newId(), "range.bad").put("occurredAt", "2001-01-01T00:00:00Z");
    ObjectNode withOffset = event(Ids.newId(), "range.ok").put("occurredAt",
        now.atOffset(java.time.ZoneOffset.ofHours(5)).toString());

    JsonNode result = send(appToken, batch(justAhead, tooFarAhead, nextYear, ancient, withOffset))
        .andExpect(status().isOk()).andReturn().getResponse().getContentAsString().transform(this::tree);

    assertThat(result.get("accepted").asInt()).isEqualTo(2);
    assertThat(result.get("rejected")).hasSize(3);
    for (JsonNode r : result.get("rejected")) {
      assertThat(r.get("reason").asText()).isEqualTo("occurred_at_out_of_range");
    }
    assertThat(jdbc.sql("SELECT count(*) FROM audit_event WHERE action = 'range.bad'").query(Long.class).single())
        .isZero();
  }

  @Test
  void eventsOlderThanTheRetentionCutoffAreRejectedEvenWhenAPartitionStillExists() throws Exception {
    AuditTestPartitions ddl = new AuditTestPartitions();
    java.time.ZonedDateTime utc = clock.instant().atZone(java.time.ZoneOffset.UTC);
    Instant expired = utc.minusYears(7).minusDays(2).toInstant();    // past the default P7Y retention
    Instant inside = utc.minusYears(7).plusDays(2).toInstant();      // still retained
    java.util.Set<java.time.YearMonth> months = new java.util.LinkedHashSet<>();
    months.add(java.time.YearMonth.from(expired.atZone(java.time.ZoneOffset.UTC)));
    months.add(java.time.YearMonth.from(inside.atZone(java.time.ZoneOffset.UTC)));
    months.forEach(ddl::create);   // so only the retention rule can reject the expired one
    try {
      ObjectNode tooOld = event(Ids.newId(), "retention.expired").put("occurredAt", expired.toString());
      ObjectNode kept = event(Ids.newId(), "retention.kept").put("occurredAt", inside.toString());

      JsonNode result = send(appToken, batch(tooOld, kept)).andExpect(status().isOk()).andReturn().getResponse()
          .getContentAsString().transform(this::tree);

      assertThat(result.get("accepted").asInt()).isEqualTo(1);
      assertThat(result.get("rejected")).hasSize(1);
      assertThat(result.at("/rejected/0/reason").asText()).isEqualTo("occurred_at_out_of_range");
      assertThat(result.at("/rejected/0/eventId").asText()).isEqualTo(id(tooOld).toString());
      assertThat(jdbc.sql("SELECT count(*) FROM audit_event WHERE action = 'retention.expired'").query(Long.class)
          .single()).isZero();
    } finally {
      months.forEach(ddl::drop);
    }
  }

  @Test
  void duplicatesIsSubmittedMinusInsertedMinusRejected() throws Exception {
    ObjectNode known = event(Ids.newId(), "mix.known");
    send(appToken, batch(known));
    ObjectNode bad = event(Ids.newId(), "BAD");

    send(appToken, batch(known, bad, event(Ids.newId(), "mix.new"), event(Ids.newId(), "mix.new")))
        .andExpect(jsonPath("$.accepted").value(2)).andExpect(jsonPath("$.duplicates").value(1))
        .andExpect(jsonPath("$.rejected.length()").value(1));
  }

  // ------------------------------------------------------------------------------------- authorization

  @Test
  void aCallerWithoutATokenIsUnauthorized() throws Exception {
    mvc.perform(post(PATH).contentType(MediaType.APPLICATION_JSON).content(json.writeValueAsString(batch())))
        .andExpect(status().isUnauthorized());
  }

  @Test
  void userTokensAreForbiddenEvenWithAuditPermissions() throws Exception {
    String userToken = tokens.user(Ids.newId()).perms("iam.audit.read", "iam.audit.export", "internal.audit.write")
        .bearer();

    send(userToken, batch(event(Ids.newId(), "a.b"))).andExpect(status().isForbidden());
  }

  @Test
  void eachProductGetsItsOwnSource() throws Exception {
    UUID id = Ids.newId();
    send(TestTokens.bearer(tokens.appToken("crm-svc", "CRM")), batch(event(id, "contact.created")))
        .andExpect(jsonPath("$.accepted").value(1));

    assertThat(jdbc.sql("SELECT source FROM audit_event WHERE event_id = :id").param("id", id).query(String.class)
        .single()).isEqualTo("CRM");
  }

  // ------------------------------------------------------------------------------------- helpers

  private ResultActions send(String bearer, JsonNode body) throws Exception {
    return mvc.perform(post(PATH).header(AUTHORIZATION, bearer).contentType(MediaType.APPLICATION_JSON)
        .content(json.writeValueAsString(body)));
  }

  private ObjectNode batch(ObjectNode... events) {
    return body(events(events));
  }

  private ObjectNode body(ArrayNode events) {
    ObjectNode body = json.createObjectNode();
    body.set("events", events);
    return body;
  }

  private ArrayNode events(ObjectNode... events) {
    ArrayNode array = json.createArrayNode();
    for (ObjectNode e : events) {
      array.add(e);
    }
    return array;
  }

  private ObjectNode event(UUID id, String action) {
    ObjectNode e = json.createObjectNode();
    e.put("eventId", id.toString());
    e.put("occurredAt", clock.instant().toString());
    e.put("action", action);
    e.put("outcome", "SUCCESS");
    e.put("actorType", "SYSTEM");
    return e;
  }

  private static UUID id(ObjectNode event) {
    return UUID.fromString(event.get("eventId").asText());
  }

  private JsonNode tree(String s) {
    try {
      return json.readTree(s);
    } catch (Exception e) {
      throw new IllegalStateException(e);
    }
  }
}
