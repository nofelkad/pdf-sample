package com.acme.iam.common.test;

import com.acme.iam.account.AccountKind;
import com.acme.iam.account.AccountStatus;
import com.acme.iam.account.SubscriptionStatus;
import com.acme.iam.assignment.ScopeType;
import com.acme.iam.common.Ids;
import com.acme.iam.common.RequestActor;
import com.acme.iam.product.PermissionKind;
import com.acme.iam.product.Product;
import com.acme.iam.tenant.TenantStatus;
import com.acme.iam.user.MembershipStatus;
import com.acme.iam.user.UserStatus;
import java.time.Instant;
import java.time.LocalDate;
import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.UUID;
import javax.sql.DataSource;
import org.springframework.jdbc.core.simple.JdbcClient;
import org.springframework.lang.Nullable;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.security.oauth2.server.resource.authentication.JwtAuthenticationToken;

/**
 * Test-data builder writing rows with plain SQL (no services, no invariants), so any test can set up exactly the state
 * it needs, including states the services would refuse.
 *
 * <pre>{@code
 * @Autowired JdbcClient jdbc;
 * Fixtures fx = new Fixtures(jdbc);
 *
 * Fixtures.Scenario s = fx.scenario();                 // ACTIVE account -> ACTIVE tenant -> ACTIVE user + membership
 * UUID read = fx.permission(Product.IAM_ID);           // random code under IAM
 * UUID role = fx.systemRole(Product.IAM_ID, read);     // random name
 * fx.assign(s.userId(), role, ScopeType.TENANT, s.tenantId());
 * Fixtures.actAs(s.userId(), s.accountId(), s.tenantId());   // RequestActor.current() is now this user
 * }</pre>
 *
 * Every generated name, slug, email and code is unique, so tests sharing the singleton database never collide.
 * Writes run in the caller's transaction if there is one (e.g. {@code @JdbcSliceTest}, rolled back), otherwise they
 * auto-commit. Remember {@link #clearActor()} in {@code @AfterEach} when using {@link #actAs}.
 */
public final class Fixtures {

  private final JdbcClient jdbc;

  public Fixtures(JdbcClient jdbc) {
    this.jdbc = jdbc;
  }

  public Fixtures(DataSource dataSource) {
    this(JdbcClient.create(dataSource));
  }

  /** account (ACTIVE, CUSTOMER) → tenant (ACTIVE) → user (ACTIVE) with an ACTIVE membership in that tenant. */
  public record Scenario(UUID accountId, UUID tenantId, UUID userId) {}

  public Scenario scenario() {
    return scenario(AccountKind.CUSTOMER);
  }

  public Scenario scenario(AccountKind kind) {
    UUID account = account(kind, AccountStatus.ACTIVE);
    UUID tenant = tenant(account);
    UUID user = user(account, tenant);
    return new Scenario(account, tenant, user);
  }

  // ------------------------------------------------------------------------------------------------ accounts

  public UUID account() {
    return account(AccountKind.CUSTOMER, AccountStatus.ACTIVE);
  }

  public UUID account(AccountKind kind, AccountStatus status) {
    UUID id = Ids.newId();
    jdbc.sql("INSERT INTO account (id, name, slug, kind, status, version) VALUES (:id, :name, :slug, :kind, :status, 0)")
        .param("id", id)
        .param("name", "Account " + shortId(id))
        .param("slug", "acc-" + id)
        .param("kind", kind.name())
        .param("status", status.name())
        .update();
    return id;
  }

  public void accountStatus(UUID accountId, AccountStatus status) {
    jdbc.sql("UPDATE account SET status = :status, version = version + 1 WHERE id = :id")
        .param("status", status.name()).param("id", accountId).update();
  }

  /** Upserts the account's subscription to the product. */
  public void subscribe(UUID accountId, UUID productId, SubscriptionStatus status, @Nullable LocalDate endsAt) {
    jdbc.sql("""
            INSERT INTO account_product (account, product_id, status, starts_at, ends_at)
            VALUES (:account, :product, :status, current_date - 30, :endsAt)
            ON CONFLICT (account, product_id) DO UPDATE SET status = EXCLUDED.status, ends_at = EXCLUDED.ends_at""")
        .param("account", accountId)
        .param("product", productId)
        .param("status", status.name())
        .param("endsAt", endsAt)
        .update();
  }

  // ------------------------------------------------------------------------------------------------- tenants

  public UUID tenant(UUID accountId) {
    return tenant(accountId, TenantStatus.ACTIVE);
  }

  public UUID tenant(UUID accountId, TenantStatus status) {
    UUID id = Ids.newId();
    jdbc.sql("""
            INSERT INTO tenant (id, account_id, name, slug, status, version)
            VALUES (:id, :account, :name, :slug, :status, 0)""")
        .param("id", id)
        .param("account", accountId)
        .param("name", "Tenant " + shortId(id))
        .param("slug", "ten-" + id)
        .param("status", status.name())
        .update();
    return id;
  }

  public void tenantStatus(UUID tenantId, TenantStatus status) {
    jdbc.sql("UPDATE tenant SET status = :status, version = version + 1 WHERE id = :id")
        .param("status", status.name()).param("id", tenantId).update();
  }

  /** Upserts the tenant's switch for the product. */
  public void enableProduct(UUID tenantId, UUID productId, boolean enabled) {
    jdbc.sql("""
            INSERT INTO tenant_product (tenant, product_id, enabled) VALUES (:tenant, :product, :enabled)
            ON CONFLICT (tenant, product_id) DO UPDATE SET enabled = EXCLUDED.enabled""")
        .param("tenant", tenantId).param("product", productId).param("enabled", enabled).update();
  }

  /**
   * A product with a random code, ACTIVE-subscribed by {@code accountId} and enabled in {@code tenantId}: the usual
   * "entitled non-IAM product" setup.
   */
  public UUID entitledProduct(UUID accountId, UUID tenantId) {
    UUID product = product();
    subscribe(accountId, product, SubscriptionStatus.ACTIVE, null);
    enableProduct(tenantId, product, true);
    return product;
  }

  // ------------------------------------------------------------------------------------ products/permissions

  /** A product with a random code. Use {@link Product#IAM_ID} for IAM. */
  public UUID product() {
    UUID id = Ids.newId();
    return product("P" + shortId(id).toUpperCase());
  }

  /** Find-or-create the product with this code. */
  public UUID product(String code) {
    jdbc.sql("INSERT INTO product (id, code, name, version) VALUES (:id, :code, :code, 0) ON CONFLICT (code) DO NOTHING")
        .param("id", Ids.newId()).param("code", code).update();
    return jdbc.sql("SELECT id FROM product WHERE code = :code").param("code", code).query(UUID.class).single();
  }

  /** A FEATURE permission with a random code under the product. */
  public UUID permission(UUID productId) {
    return permission(productId, "test." + shortId(Ids.newId()) + ".perm");
  }

  /**
   * Find-or-create the permission with this code (global unique) under the product. An existing permission that is
   * deprecated is un-deprecated (the startup manifest load deprecates IAM permissions that are not in
   * {@code iam-manifest.yaml}, so a fixed test code would otherwise depend on test order); a live one is not written.
   */
  public UUID permission(UUID productId, String code) {
    jdbc.sql("""
            INSERT INTO permission (id, product_id, code, kind, description, version)
            VALUES (:id, :product, :code, :kind, :code, 0)
            ON CONFLICT (code) DO UPDATE SET deprecated = false, version = permission.version + 1
            WHERE permission.deprecated""")
        .param("id", Ids.newId())
        .param("product", productId)
        .param("code", code)
        .param("kind", PermissionKind.FEATURE.name())
        .update();
    return jdbc.sql("SELECT id FROM permission WHERE code = :code").param("code", code).query(UUID.class).single();
  }

  public void deprecate(UUID permissionId) {
    jdbc.sql("UPDATE permission SET deprecated = true, version = version + 1 WHERE id = :id")
        .param("id", permissionId).update();
  }

  public String code(UUID permissionId) {
    return jdbc.sql("SELECT code FROM permission WHERE id = :id").param("id", permissionId).query(String.class).single();
  }

  public List<String> codes(UUID... permissionIds) {
    return Arrays.stream(permissionIds).map(this::code).toList();
  }

  // ------------------------------------------------------------------------------------------------- users

  /** An ACTIVE user with an ACTIVE membership in its primary tenant. */
  public UUID user(UUID accountId, UUID primaryTenantId) {
    return user(accountId, primaryTenantId, UserStatus.ACTIVE);
  }

  public UUID user(UUID accountId, UUID primaryTenantId, UserStatus status) {
    UUID id = Ids.newId();
    jdbc.sql("""
            INSERT INTO app_user (id, account_id, email, display_name, status, primary_tenant_id, version)
            VALUES (:id, :account, :email, :name, :status, :tenant, 0)""")
        .param("id", id)
        .param("account", accountId)
        .param("email", "u-" + id + "@example.test")
        .param("name", "User " + shortId(id))
        .param("status", status.name())
        .param("tenant", primaryTenantId)
        .update();
    membership(id, primaryTenantId, MembershipStatus.ACTIVE);
    return id;
  }

  public String email(UUID userId) {
    return jdbc.sql("SELECT email FROM app_user WHERE id = :id").param("id", userId).query(String.class).single();
  }

  /** Upserts the membership. */
  public void membership(UUID userId, UUID tenantId, MembershipStatus status) {
    jdbc.sql("""
            INSERT INTO user_tenant_membership (app_user, tenant_id, status) VALUES (:user, :tenant, :status)
            ON CONFLICT (app_user, tenant_id) DO UPDATE SET status = EXCLUDED.status""")
        .param("user", userId).param("tenant", tenantId).param("status", status.name()).update();
  }

  public void removeMembership(UUID userId, UUID tenantId) {
    jdbc.sql("DELETE FROM user_tenant_membership WHERE app_user = :user AND tenant_id = :tenant")
        .param("user", userId).param("tenant", tenantId).update();
  }

  // ------------------------------------------------------------------------------------------------- roles

  /** A SYSTEM role with a random name. */
  public UUID systemRole(UUID productId, UUID... permissionIds) {
    return systemRole(productId, "Role " + shortId(Ids.newId()), permissionIds);
  }

  /**
   * Find-or-create the SYSTEM role with this name (names are unique per product), then grant it the permissions
   * (idempotent). Use this for well-known names such as {@code Role.PLATFORM_ADMIN}.
   */
  public UUID systemRole(UUID productId, String name, UUID... permissionIds) {
    UUID existing = jdbc.sql("""
            SELECT id FROM role WHERE product_id = :product AND type = 'SYSTEM' AND lower(name) = lower(CAST(:name AS text))""")
        .param("product", productId).param("name", name).query(UUID.class).optional().orElse(null);
    UUID id = existing != null ? existing : insertRole(productId, name, "SYSTEM", null);
    grant(id, Arrays.asList(permissionIds));
    return id;
  }

  /** A CUSTOM role of the account with a random name. */
  public UUID customRole(UUID productId, UUID accountId, UUID... permissionIds) {
    UUID id = insertRole(productId, "Custom " + shortId(Ids.newId()), "CUSTOM", accountId);
    grant(id, Arrays.asList(permissionIds));
    return id;
  }

  public void grant(UUID roleId, Collection<UUID> permissionIds) {
    for (UUID permission : permissionIds) {
      jdbc.sql("INSERT INTO role_permission (role, permission_id) VALUES (:role, :perm) ON CONFLICT DO NOTHING")
          .param("role", roleId).param("perm", permission).update();
    }
  }

  private UUID insertRole(UUID productId, String name, String type, @Nullable UUID accountId) {
    UUID id = Ids.newId();
    jdbc.sql("""
            INSERT INTO role (id, product_id, name, type, account_id, version)
            VALUES (:id, :product, :name, :type, :account, 0)""")
        .param("id", id)
        .param("product", productId)
        .param("name", name)
        .param("type", type)
        .param("account", accountId)
        .update();
    return id;
  }

  // ------------------------------------------------------------------------------------------- assignments

  public UUID assign(UUID userId, UUID roleId, ScopeType scopeType, UUID scopeId) {
    return assign(userId, roleId, scopeType, scopeId, null);
  }

  /** Inserts an assignment directly (no invariants checked); {@code expiresAt} may lie in the past. */
  public UUID assign(UUID userId, UUID roleId, ScopeType scopeType, UUID scopeId, @Nullable Instant expiresAt) {
    UUID id = Ids.newId();
    jdbc.sql("""
            INSERT INTO role_assignment (id, user_id, role_id, scope_type, scope_id, expires_at, version)
            VALUES (:id, :user, :role, :scopeType, :scopeId, :expiresAt, 0)""")
        .param("id", id)
        .param("user", userId)
        .param("role", roleId)
        .param("scopeType", scopeType.name())
        .param("scopeId", scopeId)
        .param("expiresAt", expiresAt == null ? null : OffsetDateTime.ofInstant(expiresAt, ZoneOffset.UTC))
        .update();
    return id;
  }

  // ------------------------------------------------------------------------------------------------- actor

  /**
   * Makes {@link RequestActor#current()} return this user (a JWT authentication with {@code sub/acc/tid}) on the
   * current thread. A {@code null} account or tenant omits that claim.
   */
  public static void actAs(UUID userId, @Nullable UUID accountId, @Nullable UUID tenantId) {
    Jwt.Builder jwt = Jwt.withTokenValue("test-token")
        .header("alg", "none")
        .subject(userId.toString())
        .issuedAt(Instant.now())
        .expiresAt(Instant.now().plusSeconds(900));
    if (accountId != null) {
      jwt.claim(RequestActor.CLAIM_ACCOUNT, accountId.toString());
    }
    if (tenantId != null) {
      jwt.claim(RequestActor.CLAIM_TENANT, tenantId.toString());
    }
    SecurityContextHolder.getContext().setAuthentication(new JwtAuthenticationToken(jwt.build(), List.of()));
  }

  public static void clearActor() {
    SecurityContextHolder.clearContext();
  }

  private static String shortId(UUID id) {
    String s = id.toString().replace("-", "");
    return s.substring(s.length() - 12);
  }
}
