package com.acme.iam.security;

import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.http.HttpHeaders.AUTHORIZATION;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.patch;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;

import com.acme.iam.assignment.PermissionResolver;
import com.acme.iam.assignment.ScopeType;
import com.acme.iam.common.Ids;
import com.acme.iam.common.test.Fixtures;
import com.acme.iam.common.test.IntegrationTest;
import com.acme.iam.common.test.OrgTestData;
import com.acme.iam.common.test.PostgresTestBase;
import com.acme.iam.common.test.TestTokens;
import com.acme.iam.product.Product;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.http.MediaType;
import org.springframework.jdbc.core.simple.JdbcClient;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;

/**
 * Final review I1 (spec section 6, "every denial"): authorization denials raised by services as 403
 * {@code ApiException}s (I6 {@code grantor_lacks_permissions}, I8 {@code platform_role_restricted},
 * {@code system_role_read_only}, R40 {@code product_not_entitled}, ...) are audited as {@code authz.denied} exactly
 * like {@code @PreAuthorize} denials, the audit row survives the request transaction's rollback, and the response body
 * is unchanged.
 */
@IntegrationTest
@AutoConfigureMockMvc
class ServiceDenialAuditIT extends PostgresTestBase {

  @Autowired MockMvc mvc;
  @Autowired TestTokens tokens;
  @Autowired JdbcClient jdbc;
  @Autowired ObjectMapper json;
  @Autowired PermissionResolver resolver;

  Fixtures fx;
  OrgTestData org;
  UUID account;
  UUID tenant;

  @BeforeEach
  void setUp() {
    org = new OrgTestData(jdbc);
    fx = org.fixtures();
    account = fx.account();
    tenant = fx.tenant(account);
  }

  /** I6 escalation: a Tenant Admin tries (twice) to hand out a role holding a permission it lacks. */
  @Test
  void aRepeatedI6EscalationAttemptIsAuditedEveryTime() throws Exception {
    UUID tenantAdmin = fx.user(account, tenant);
    fx.assign(tenantAdmin, org.tenantAdminRole(), ScopeType.TENANT, tenant);
    UUID victim = fx.user(account, tenant);
    UUID powerful = fx.customRole(Product.IAM_ID, account, fx.permission(Product.IAM_ID, "iam.role.manage"));
    String bearer = bearer(tenantAdmin);

    for (int attempt = 1; attempt <= 2; attempt++) {
      String requestId = "i6-" + attempt + "-" + Ids.newId();
      MockHttpServletResponse response = mvc.perform(json(post("/api/users/{id}/assignments", victim),
              "{\"roleId\":\"%s\",\"scopeType\":\"TENANT\",\"scopeId\":\"%s\"}".formatted(powerful, tenant))
          .header(AUTHORIZATION, bearer).header("X-Request-Id", requestId)).andReturn().getResponse();

      assertThat(response.getStatus()).isEqualTo(403);
      assertThat(json.readTree(response.getContentAsString()).get("code").asText())
          .isEqualTo("grantor_lacks_permissions");
      assertThat(json.readTree(response.getContentAsString()).get("missingPermissions").get(0).asText())
          .as("the body keeps the exception's properties").isEqualTo("iam.role.manage");
      Map<String, Object> denied = denial(requestId);
      assertThat(denied).containsEntry("actor_user_id", tenantAdmin).containsEntry("account_id", account)
          .containsEntry("outcome", "DENIED").containsEntry("reason", "grantor_lacks_permissions")
          .containsEntry("path", "/api/users/" + victim + "/assignments").containsEntry("method", "POST");
    }
    assertThat(jdbc.sql("SELECT count(*) FROM role_assignment WHERE user_id = :u AND role_id = :r")
        .param("u", victim).param("r", powerful).query(Long.class).single()).as("the grant rolled back").isZero();
    assertThat(jdbc.sql("""
            SELECT count(*) FROM audit_event WHERE action = 'authz.denied' AND actor_user_id = :u
              AND metadata->>'reason' = 'grantor_lacks_permissions'""")
        .param("u", tenantAdmin).query(Long.class).single()).isEqualTo(2);
  }

  /** {@code system_role_read_only}: editing a SYSTEM role through the API. */
  @Test
  void editingASystemRoleIsAnAuditedDenial() throws Exception {
    UUID admin = org.accountAdmin(account, tenant);
    String requestId = "sys-" + Ids.newId();

    MockHttpServletResponse response = mvc.perform(json(patch("/api/roles/{id}", org.tenantAdminRole()),
            "{\"name\":\"Renamed\"}").header(AUTHORIZATION, bearer(admin)).header("X-Request-Id", requestId))
        .andReturn().getResponse();

    assertThat(response.getStatus()).isEqualTo(403);
    assertThat(json.readTree(response.getContentAsString()).get("code").asText()).isEqualTo("system_role_read_only");
    assertThat(denial(requestId)).containsEntry("reason", "system_role_read_only");
  }

  /** {@code platform_role_restricted} (I8): Platform Admin outside the PLATFORM account. */
  @Test
  void assigningPlatformAdminInACustomerAccountIsAnAuditedDenial() throws Exception {
    UUID admin = org.accountAdmin(account, tenant);
    UUID target = fx.user(account, tenant);
    String requestId = "i8-" + Ids.newId();

    MockHttpServletResponse response = mvc.perform(json(post("/api/users/{id}/assignments", target),
            "{\"roleId\":\"%s\",\"scopeType\":\"ACCOUNT\",\"scopeId\":\"%s\"}".formatted(org.platformAdminRole(),
                account)).header(AUTHORIZATION, bearer(admin)).header("X-Request-Id", requestId))
        .andReturn().getResponse();

    assertThat(response.getStatus()).isEqualTo(403);
    assertThat(json.readTree(response.getContentAsString()).get("code").asText())
        .isIn("platform_role_restricted", "grantor_lacks_permissions");
    assertThat(denial(requestId).get("reason")).isEqualTo(json.readTree(response.getContentAsString()).get("code")
        .asText());
  }

  /** Auth-flow 403s are already audited as auth.* events and are not doubled as authz.denied. */
  @Test
  void selfAuditedAuthDenialsAreNotDoubled() throws Exception {
    UUID user = fx.user(account, tenant);
    UUID otherTenant = fx.tenant(account);
    String requestId = "switch-" + Ids.newId();

    MockHttpServletResponse response = mvc.perform(json(post("/auth/switch-tenant"),
            "{\"tenantId\":\"%s\"}".formatted(otherTenant)).header(AUTHORIZATION, bearer(user))
            .header("X-Request-Id", requestId))
        .andReturn().getResponse();

    assertThat(response.getStatus()).isIn(401, 403);
    assertThat(jdbc.sql("SELECT count(*) FROM audit_event WHERE request_id = :r AND action = 'authz.denied'")
        .param("r", requestId).query(Long.class).single()).isZero();
  }

  // ------------------------------------------------------------------------------------------ helpers

  private Map<String, Object> denial(String requestId) {
    List<Map<String, Object>> rows = jdbc.sql("""
            SELECT actor_user_id, account_id, outcome, metadata->>'reason' AS reason, metadata->>'path' AS path,
                   metadata->>'method' AS method
            FROM audit_event WHERE request_id = :r AND action = 'authz.denied'""")
        .param("r", requestId).query().listOfRows();
    assertThat(rows).as("authz.denied rows of " + requestId).hasSize(1);
    return rows.get(0);
  }

  private String bearer(UUID user) {
    return tokens.user(user).account(account).tenant(tenant)
        .perms(resolver.resolve(user, tenant).toArray(String[]::new)).bearer();
  }

  private static MockHttpServletRequestBuilder json(MockHttpServletRequestBuilder request, String body) {
    return request.contentType(MediaType.APPLICATION_JSON).content(body);
  }
}
