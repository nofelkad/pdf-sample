package com.acme.iam.audit;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;

import com.acme.iam.common.error.ApiException;
import java.io.ByteArrayOutputStream;
import java.time.Clock;
import java.time.Instant;
import java.util.Map;
import java.util.UUID;
import javax.sql.DataSource;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.web.context.request.ServletWebRequest;

/**
 * Final review M8: the export concurrency permit is taken on the request thread by {@code begin} and released when the
 * {@code StreamingResponseBody} finishes. When the body never runs (the MVC task executor rejects it, or the async
 * request times out or fails before it starts) the async completion callback must release it instead, or every such
 * request permanently lowers the instance's export capacity until all exports answer 429.
 */
class AuditExportPermitTest {

  private final AuditWriter auditWriter = mock(AuditWriter.class);
  private final AuditExportService service = new AuditExportService(mock(DataSource.class),
      mock(PlatformTransactionManager.class), auditWriter, Clock.systemUTC(), 1);
  private final AuditSearchCriteria criteria = new AuditSearchCriteria(UUID.randomUUID(), null, null, null, null,
      null, null, Instant.now().minusSeconds(60), Instant.now(), null, 50);

  @Test
  void anExportWhoseBodyNeverRunsGivesItsPermitBackOnAsyncCompletion() throws Exception {
    AuditExportService.Export export = service.begin(criteria);
    MockHttpServletRequest request = new MockHttpServletRequest();
    request.setAttribute(AuditExportService.EXPORT_ATTRIBUTE, export);
    assertThatThrownBy(() -> service.begin(criteria)).isInstanceOfSatisfying(ApiException.class,
        e -> assertThat(e.code()).isEqualTo(AuditExportService.BUSY));

    new AuditExportService.PermitReleasingInterceptor().afterCompletion(new ServletWebRequest(request), () -> null);

    assertThat(service.begin(criteria)).as("the permit came back").isNotNull();
    @SuppressWarnings("unchecked")
    ArgumentCaptor<Map<String, ?>> metadata = ArgumentCaptor.forClass(Map.class);
    verify(auditWriter).read(eq(AuditExportService.ACTION_EXPORTED), eq(AuditExportService.TARGET_TYPE), any(),
        metadata.capture());
    assertThat(metadata.getValue().get("status")).isEqualTo("abandoned");
  }

  @Test
  void anAbandonedExportNeverStreamsAndReleasesOnlyOnce() throws Exception {
    AuditExportService.Export export = service.begin(criteria);
    assertThat(export.abandonIfNotStarted()).isTrue();
    assertThat(export.abandonIfNotStarted()).isFalse();

    ByteArrayOutputStream out = new ByteArrayOutputStream();
    export.stream(out);

    assertThat(out.size()).as("nothing is written for an abandoned export").isZero();
    service.begin(criteria);
    assertThatThrownBy(() -> service.begin(criteria)).as("exactly one permit, released exactly once")
        .isInstanceOf(ApiException.class);
  }
}
