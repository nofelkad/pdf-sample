package com.acme.iam.architecture;

import com.tngtech.archunit.core.domain.JavaClasses;
import com.tngtech.archunit.core.importer.ClassFileImporter;
import com.tngtech.archunit.core.importer.ImportOption;
import com.tngtech.archunit.lang.ArchRule;
import java.util.stream.Stream;
import org.junit.jupiter.api.DynamicTest;
import org.junit.jupiter.api.TestFactory;

/** P1-1.6: package-by-feature rules on the production code of {@code com.acme.iam}; the build fails on violation. */
class ArchitectureTest {

  private static final String ROOT = "com.acme.iam";

  private static final JavaClasses PRODUCTION = new ClassFileImporter()
      .withImportOption(ImportOption.Predefined.DO_NOT_INCLUDE_TESTS)
      .importPackages(ROOT);

  @TestFactory
  Stream<DynamicTest> productionCodeFollowsTheFeatureRules() {
    return ArchitectureRules.all(ROOT).stream()
        .map(rule -> DynamicTest.dynamicTest(rule.getDescription(), () -> check(rule)));
  }

  private static void check(ArchRule rule) {
    rule.check(PRODUCTION);
  }
}
