package com.acme.iam.observability;

import static org.assertj.core.api.Assertions.assertThat;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import org.junit.jupiter.api.Test;

/** "Dashboard exists" (P1-11.5): the Grafana JSON is valid and covers every meter, and docs/observability.md lists them. */
class ObservabilityDocsTest {

  private static final Path DOCS = Path.of("..", "docs");

  /** Prometheus base names of the meters of {@link MetricNames} (counters without suffix, timers without _seconds). */
  private static final List<String> DASHBOARD_SERIES = List.of(
      "iam_auth_logins_total", "iam_auth_lockouts_total", "iam_auth_refresh_reuse_detected_total",
      "iam_auth_login_duration_seconds", "iam_auth_refresh_duration_seconds",
      "iam_auth_tenant_switch_duration_seconds", "iam_permission_resolve_duration_seconds",
      "iam_revocation_lag_seconds", "iam_revocation_poll_age_seconds", "iam_revocation_poll_failures_total",
      "iam_audit_ingest_lag_seconds", "iam_auth_password_reset_send_timeouts_total",
      "iam_auth_password_reset_dropped_total", "iam_audit_partitions_months_ahead",
      "iam_client_audit_outbox_depth", "iam_client_audit_outbox_oldest_age_seconds",
      "iam_client_audit_relay_failures", "iam_client_revocation_poll_age_seconds");

  @Test
  void theDashboardIsValidJsonWithAQueryForEveryMeter() throws Exception {
    JsonNode dashboard = new ObjectMapper().readTree(Files.readString(DOCS.resolve("dashboards/iam-service.json")));

    List<String> expressions = new ArrayList<>();
    dashboard.get("panels").forEach(panel -> panel.path("targets").forEach(t -> expressions.add(t.path("expr").asText())));

    assertThat(dashboard.get("title").asText()).isEqualTo("IAM service");
    assertThat(dashboard.get("panels").size()).isGreaterThan(20);
    assertThat(DASHBOARD_SERIES).allSatisfy(series ->
        assertThat(expressions).as("a panel queries " + series).anyMatch(expr -> expr.contains(series)));
  }

  @Test
  void everyMeterNameOfTheCodeIsDocumented() throws Exception {
    String doc = Files.readString(DOCS.resolve("observability.md"));
    for (Field field : MetricNames.class.getDeclaredFields()) {
      if (Modifier.isStatic(field.getModifiers()) && field.getType() == String.class) {
        String name = (String) field.get(null);
        assertThat(doc).as("docs/observability.md documents " + name).contains("`" + name + "`");
      }
    }
  }
}
