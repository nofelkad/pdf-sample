package com.acme.iam.common.error;

import static org.hamcrest.Matchers.containsString;
import static org.hamcrest.Matchers.not;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.header;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import com.acme.iam.common.test.IntegrationTest;
import com.acme.iam.common.test.PostgresTestBase;
import com.acme.iam.common.web.RequestIdFilter;
import jakarta.validation.Valid;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import java.util.Map;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.context.annotation.Import;
import org.springframework.http.MediaType;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/** P1-1.4: RFC 7807 rendering with {@code code} and {@code requestId}. */
@IntegrationTest
@AutoConfigureMockMvc
@WithMockUser
class GlobalExceptionHandlerIT extends PostgresTestBase {

  @Autowired MockMvc mvc;

  @Test
  void apiExceptionBecomesProblemDetailWithCodeRequestIdAndProperties() throws Exception {
    mvc.perform(get("/test/errors/not-found").header(RequestIdFilter.HEADER, "rid-1"))
        .andExpect(status().isNotFound())
        .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_PROBLEM_JSON))
        .andExpect(header().string(RequestIdFilter.HEADER, "rid-1"))
        .andExpect(jsonPath("$.status").value(404))
        .andExpect(jsonPath("$.title").value("Not Found"))
        .andExpect(jsonPath("$.detail").value("Tenant not found"))
        .andExpect(jsonPath("$.code").value("tenant_not_found"))
        .andExpect(jsonPath("$.requestId").value("rid-1"))
        .andExpect(jsonPath("$.tenantId").value("t-1"));
  }

  @Test
  void conflictUsesItsCode() throws Exception {
    mvc.perform(get("/test/errors/conflict"))
        .andExpect(status().isConflict())
        .andExpect(jsonPath("$.code").value("last_admin"))
        .andExpect(jsonPath("$.requestId").isNotEmpty());
  }

  @Test
  void beanValidationFailureListsFieldErrors() throws Exception {
    mvc.perform(post("/test/errors/validate").contentType(MediaType.APPLICATION_JSON)
            .content("{\"name\":\"\",\"email\":\"not-an-email\"}"))
        .andExpect(status().isBadRequest())
        .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_PROBLEM_JSON))
        .andExpect(jsonPath("$.code").value("validation_failed"))
        .andExpect(jsonPath("$.requestId").isNotEmpty())
        .andExpect(jsonPath("$.errors.length()").value(2))
        .andExpect(jsonPath("$.errors[?(@.field == 'name')]").exists())
        .andExpect(jsonPath("$.errors[?(@.field == 'email')]").exists());
  }

  @Test
  void malformedJsonIsBadRequestWithDerivedCode() throws Exception {
    mvc.perform(post("/test/errors/validate").contentType(MediaType.APPLICATION_JSON).content("{oops"))
        .andExpect(status().isBadRequest())
        .andExpect(jsonPath("$.code").value("bad_request"))
        .andExpect(jsonPath("$.requestId").isNotEmpty());
  }

  @Test
  void unexpectedExceptionIsGeneric500WithoutLeakingTheMessage() throws Exception {
    mvc.perform(get("/test/errors/boom"))
        .andExpect(status().isInternalServerError())
        .andExpect(jsonPath("$.code").value("internal_error"))
        .andExpect(jsonPath("$.detail").value("Internal error"))
        .andExpect(content().string(not(containsString("secret-internal-detail"))));
  }

  @Test
  void accessDeniedIsLeftToSpringSecurity() throws Exception {
    mvc.perform(get("/test/errors/denied"))
        .andExpect(status().isForbidden())
        .andExpect(header().exists(RequestIdFilter.HEADER));
  }

  @Test
  void unknownPathIsNotFoundProblem() throws Exception {
    mvc.perform(get("/test/errors/no-such-endpoint"))
        .andExpect(status().isNotFound())
        .andExpect(jsonPath("$.code").value("not_found"));
  }

  @TestConfiguration
  @Import(ErrorTestController.class)
  static class Config {}

  record Body(@NotBlank String name, @Email String email) {}

  @RestController
  @RequestMapping("/test/errors")
  static class ErrorTestController {

    @GetMapping("/not-found")
    void notFound() {
      throw new NotFoundException("tenant_not_found", "Tenant not found", Map.of("tenantId", "t-1"));
    }

    @GetMapping("/conflict")
    void conflict() {
      throw new ConflictException("last_admin", "The last account admin cannot be removed");
    }

    @PostMapping("/validate")
    void validate(@Valid @RequestBody Body body) {}

    @GetMapping("/boom")
    void boom() {
      throw new IllegalStateException("secret-internal-detail");
    }

    @GetMapping("/denied")
    void denied() {
      throw new AccessDeniedException("nope");
    }
  }
}
