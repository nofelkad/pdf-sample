package com.acme.iam.tenant;

import static org.assertj.core.api.Assertions.assertThat;

import com.acme.iam.account.AccountAdminService;
import com.acme.iam.account.AccountAdminService.SubscriptionRequest;
import com.acme.iam.account.SubscriptionStatus;
import com.acme.iam.common.test.Fixtures;
import com.acme.iam.common.test.IntegrationTest;
import com.acme.iam.common.test.PostgresTestBase;
import com.acme.iam.tenant.TenantAdminService.ProductSwitch;
import java.time.Duration;
import java.time.Instant;
import java.time.LocalDate;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.simple.JdbcClient;
import org.springframework.transaction.support.TransactionTemplate;

/** I5 under concurrency: enabling a product in a tenant races with the account losing that subscription. */
@IntegrationTest
class TenantProductRaceIT extends PostgresTestBase {

  @Autowired TenantAdminService tenantAdmin;
  @Autowired AccountAdminService accountAdmin;
  @Autowired JdbcClient jdbc;
  @Autowired TransactionTemplate tx;

  @Test
  void aSubscriptionShrinkWaitsForAnInFlightEnableAndThenSwitchesItOff() throws Exception {
    Fixtures fx = new Fixtures(jdbc);
    Fixtures.Scenario s = fx.scenario();
    UUID product = fx.product();
    fx.subscribe(s.accountId(), product, SubscriptionStatus.ACTIVE, null);
    String code = jdbc.sql("SELECT code FROM product WHERE id = :id").param("id", product).query(String.class)
        .single();
    CountDownLatch enabled = new CountDownLatch(1);
    CountDownLatch release = new CountDownLatch(1);

    CompletableFuture<Void> enable = CompletableFuture.runAsync(() -> tx.executeWithoutResult(t -> {
      tenantAdmin.setProducts(s.accountId(), s.tenantId(), List.of(new ProductSwitch(code, true)));
      enabled.countDown();
      await(release);
    }));
    await(enabled);
    CompletableFuture<Void> shrink = CompletableFuture.runAsync(() -> accountAdmin.setProducts(s.accountId(),
        List.of(new SubscriptionRequest(code, SubscriptionStatus.SUSPENDED, LocalDate.now().minusDays(1), null))));
    waitUntilSomeoneWaitsOnALock();
    release.countDown();

    enable.get(30, TimeUnit.SECONDS);
    shrink.get(30, TimeUnit.SECONDS);
    assertThat(jdbc.sql("SELECT enabled FROM tenant_product WHERE tenant = :t AND product_id = :p")
        .param("t", s.tenantId()).param("p", product).query(Boolean.class).single())
        .as("I5: no enabled switch for a product the account is no longer entitled to").isFalse();
  }

  private void waitUntilSomeoneWaitsOnALock() throws InterruptedException {
    Instant deadline = Instant.now().plus(Duration.ofSeconds(3));
    while (Instant.now().isBefore(deadline)) {
      if (jdbc.sql("SELECT count(*) FROM pg_locks WHERE NOT granted").query(Long.class).single() > 0) {
        return;
      }
      Thread.sleep(20);
    }
  }

  private static void await(CountDownLatch latch) {
    try {
      if (!latch.await(30, TimeUnit.SECONDS)) {
        throw new IllegalStateException("latch timeout");
      }
    } catch (InterruptedException e) {
      Thread.currentThread().interrupt();
      throw new IllegalStateException(e);
    }
  }
}
