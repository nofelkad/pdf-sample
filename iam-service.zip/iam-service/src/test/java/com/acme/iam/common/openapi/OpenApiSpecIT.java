package com.acme.iam.common.openapi;

import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import com.acme.iam.common.test.IntegrationTest;
import com.acme.iam.common.test.PostgresTestBase;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.TreeMap;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.method.HandlerMethod;
import org.springframework.web.servlet.mvc.method.RequestMappingInfo;
import org.springframework.web.servlet.mvc.method.annotation.RequestMappingHandlerMapping;

/**
 * P1-11.6: the OpenAPI document generates, lists every controller route, documents the security schemes, and the copy
 * committed as {@code docs/openapi.json} is current. springdoc is on only for this test (and in the dev profile).
 *
 * <p>Refresh the committed file after an API change with
 * {@code IAM_OPENAPI_UPDATE=true ./gradlew :iam-service:test --tests '*OpenApiSpecIT'}, then commit it.
 */
@IntegrationTest(properties = "springdoc.api-docs.enabled=true")
@AutoConfigureMockMvc
class OpenApiSpecIT extends PostgresTestBase {

  static final Path COMMITTED = Path.of("..", "docs", "openapi.json");

  @Autowired MockMvc mvc;
  @Autowired ObjectMapper json;
  @Autowired @Qualifier("requestMappingHandlerMapping") RequestMappingHandlerMapping mappings;

  @Test
  void theSpecListsEveryControllerRouteOfTheService() throws Exception {
    JsonNode paths = spec().get("paths");
    List<String> missing = new ArrayList<>();
    int routes = 0;
    for (Map.Entry<RequestMappingInfo, HandlerMethod> entry : mappings.getHandlerMethods().entrySet()) {
      if (!entry.getValue().getBeanType().getName().startsWith("com.acme.iam.")) {
        continue;
      }
      for (String pattern : entry.getKey().getPathPatternsCondition().getPatternValues()) {
        for (RequestMethod method : entry.getKey().getMethodsCondition().getMethods()) {
          routes++;
          JsonNode operation = paths.path(pattern).path(method.name().toLowerCase(Locale.ROOT));
          if (operation.isMissingNode()) {
            missing.add(method + " " + pattern + " (" + entry.getValue().getShortLogMessage() + ")");
          }
        }
      }
    }
    assertThat(routes).as("controller routes found").isGreaterThan(40);
    assertThat(missing).as("routes missing from /v3/api-docs").isEmpty();
  }

  @Test
  void operationIdsAreUnique() throws Exception {
    List<String> ids = new ArrayList<>();
    spec().get("paths").forEach(item -> item.forEach(op -> ids.add(op.path("operationId").asText())));
    assertThat(ids).doesNotContainNull().doesNotHaveDuplicates();
    assertThat(ids).noneMatch(id -> id.matches(".*_\\d+$"));
  }

  @Test
  void theThreeSecuritySchemesAreDeclared() throws Exception {
    JsonNode schemes = spec().at("/components/securitySchemes");

    assertThat(schemes.path("bearerAuth").path("type").asText()).isEqualTo("http");
    assertThat(schemes.path("bearerAuth").path("scheme").asText()).isEqualTo("bearer");
    assertThat(schemes.path("bearerAuth").path("bearerFormat").asText()).isEqualTo("JWT");
    assertThat(schemes.path("basicAuth").path("type").asText()).isEqualTo("http");
    assertThat(schemes.path("basicAuth").path("scheme").asText()).isEqualTo("basic");
    assertThat(schemes.path("appBearer").path("type").asText()).isEqualTo("http");
    assertThat(schemes.path("appBearer").path("scheme").asText()).isEqualTo("bearer");
    assertThat(schemes.path("appBearer").path("bearerFormat").asText()).isEqualTo("JWT");
  }

  @Test
  void everyOperationNamesTheSchemeOfItsFilterChain() throws Exception {
    JsonNode paths = spec().get("paths");

    assertThat(schemesOf(paths, "/api/me", "get")).containsExactly("bearerAuth");
    assertThat(schemesOf(paths, "/api/users", "get")).containsExactly("bearerAuth");
    assertThat(schemesOf(paths, "/auth/logout", "post")).containsExactly("bearerAuth");
    assertThat(schemesOf(paths, "/auth/switch-tenant", "post")).containsExactly("bearerAuth");
    assertThat(schemesOf(paths, "/internal/token", "post")).containsExactly("basicAuth");
    assertThat(schemesOf(paths, "/internal/revocations", "get")).containsExactly("appBearer");
    assertThat(schemesOf(paths, "/internal/audit/events", "post")).containsExactly("appBearer");
    // public endpoints say so explicitly ("security": [] overrides any default)
    assertThat(paths.at("/~1auth~1login/post/security").isArray()).isTrue();
    assertThat(paths.at("/~1auth~1login/post/security")).isEmpty();
    assertThat(paths.at("/~1.well-known~1jwks.json/get/security")).isEmpty();
    assertThat(paths.at("/~1.well-known~1jwks.json/get/security").isArray()).isTrue();

    paths.fieldNames().forEachRemaining(path -> {
      if (path.startsWith("/api/")) {
        paths.get(path).forEach(op -> assertThat(op.at("/security/0").has("bearerAuth")).as(path).isTrue());
      }
      if (path.startsWith("/internal/") && !path.equals("/internal/token")) {
        paths.get(path).forEach(op -> assertThat(op.at("/security/0").has("appBearer")).as(path).isTrue());
      }
    });
  }

  @Test
  void theCommittedSpecIsCurrent() throws Exception {
    String generated = normalised(spec());
    if ("true".equalsIgnoreCase(System.getenv("IAM_OPENAPI_UPDATE"))) {
      Files.writeString(COMMITTED, generated, StandardCharsets.UTF_8);
      return;
    }
    assertThat(Files.exists(COMMITTED)).as("docs/openapi.json exists").isTrue();
    String committed = Files.readString(COMMITTED, StandardCharsets.UTF_8);
    assertThat(committed)
        .as("docs/openapi.json is stale. Regenerate it with: "
            + "IAM_OPENAPI_UPDATE=true ./gradlew :iam-service:test --tests '*OpenApiSpecIT' and commit the result")
        .isEqualTo(generated);
  }

  // ------------------------------------------------------------------------------------------------ helpers

  private JsonNode spec() throws Exception {
    String body = mvc.perform(get("/v3/api-docs")).andExpect(status().isOk())
        .andReturn().getResponse().getContentAsString();
    return json.readTree(body);
  }

  private static List<String> schemesOf(JsonNode paths, String path, String method) {
    List<String> names = new ArrayList<>();
    JsonNode security = paths.path(path).path(method).path("security");
    assertThat(security.isArray()).as(method + " " + path + " has a security array").isTrue();
    security.forEach(requirement -> requirement.fieldNames().forEachRemaining(names::add));
    return names;
  }

  /** Pretty-printed with every object's keys sorted, so the file does not depend on route registration order. */
  private String normalised(JsonNode spec) throws IOException {
    ObjectMapper mapper = json.copy().enable(SerializationFeature.INDENT_OUTPUT);
    return mapper.writeValueAsString(sorted(spec, mapper)) + "\n";
  }

  private static JsonNode sorted(JsonNode node, ObjectMapper mapper) {
    if (node.isObject()) {
      ObjectNode out = mapper.createObjectNode();
      new TreeMap<String, JsonNode>(toMap(node)).forEach((k, v) -> out.set(k, sorted(v, mapper)));
      return out;
    }
    if (node.isArray()) {
      List<JsonNode> items = new ArrayList<>();
      node.forEach(v -> items.add(sorted(v, mapper)));
      // order that carries no meaning is fixed too: string lists (required, enum, tags) and parameters (by in, name)
      if (items.stream().allMatch(JsonNode::isTextual)) {
        items.sort(Comparator.comparing(JsonNode::asText));
      } else if (items.stream().allMatch(v -> v.isObject() && v.has("name") && v.has("in"))) {
        items.sort(Comparator.comparing((JsonNode v) -> v.get("in").asText()).thenComparing(v -> v.get("name").asText()));
      }
      ArrayNode out = mapper.createArrayNode();
      items.forEach(out::add);
      return out;
    }
    return node;
  }

  private static Map<String, JsonNode> toMap(JsonNode object) {
    Map<String, JsonNode> map = new TreeMap<>();
    object.properties().forEach(e -> map.put(e.getKey(), e.getValue()));
    return map;
  }
}
