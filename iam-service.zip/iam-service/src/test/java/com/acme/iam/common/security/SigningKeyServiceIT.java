package com.acme.iam.common.security;

import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.http.HttpHeaders.AUTHORIZATION;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import com.acme.iam.common.Ids;
import com.acme.iam.common.test.IntegrationTest;
import com.acme.iam.common.test.PostgresTestBase;
import com.acme.iam.common.test.TestTokens;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.nimbusds.jwt.SignedJWT;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.DefaultApplicationArguments;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.context.annotation.Import;
import org.springframework.jdbc.core.simple.JdbcClient;
import org.springframework.test.web.servlet.MockMvc;

/** P1-4.1 / P1-4.2: key storage, JWKS endpoint, rotation lifecycle with overlap. */
@IntegrationTest
@AutoConfigureMockMvc
@Import(SecurityTestEndpoints.class)
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
class SigningKeyServiceIT extends PostgresTestBase {

  @Autowired MockMvc mvc;
  @Autowired SigningKeyService keys;
  @Autowired TestTokens tokens;
  @Autowired JdbcClient jdbc;
  @Autowired ObjectMapper json;
  @Autowired SecurityProperties properties;

  @Test
  @Order(1)
  void startupCreatedExactlyOneActiveKeyWithEncryptedPrivatePart() {
    List<Map<String, Object>> active = jdbc.sql(
        "SELECT kid, public_jwk::text AS jwk, private_enc FROM signing_key WHERE status = 'ACTIVE'").query().listOfRows();

    assertThat(active).hasSize(1);
    String kid = (String) active.get(0).get("kid");
    assertThat(kid).isEqualTo(keys.activeKeyId());
    assertThat(java.util.UUID.fromString(kid).version()).isEqualTo(7);
    assertThat((String) active.get(0).get("jwk")).contains("\"kty\": \"RSA\"").doesNotContain("\"d\"");
    byte[] sealed = (byte[]) active.get(0).get("private_enc");
    assertThat(sealed.length).isGreaterThan(MasterKeyCipher.IV_BYTES + MasterKeyCipher.TAG_BYTES + 1000);
    assertThat(keys.activeSigningKey().isPrivate()).isTrue();
    assertThat(keys.activeSigningKey().size()).isEqualTo(2048);
  }

  @Test
  @Order(2)
  void jwksIsPublicAndHasNoPrivateParameters() throws Exception {
    mvc.perform(get("/.well-known/jwks.json"))
        .andExpect(status().isOk())
        .andExpect(jsonPath("$.keys[?(@.kid == '" + keys.activeKeyId() + "')].kty").value("RSA"))
        .andExpect(jsonPath("$.keys[?(@.kid == '" + keys.activeKeyId() + "')].alg").value("RS256"))
        .andExpect(jsonPath("$.keys[?(@.kid == '" + keys.activeKeyId() + "')].use").value("sig"))
        .andExpect(jsonPath("$.keys[*].d").doesNotExist())
        .andExpect(jsonPath("$.keys[*].p").doesNotExist());
  }

  @Test
  @Order(3)
  void rotationKeepsTokensOfTheOldKeyValidDuringOverlapThenRetiresIt() throws Exception {
    String oldKid = keys.activeKeyId();
    String oldToken = tokens.user(Ids.newId()).perms("test.read").mint();
    assertThat(kidOf(oldToken)).isEqualTo(oldKid);

    // Runbook rotation: the new key is published first, signing continues with the old key.
    String newKid = keys.rotateNow();
    assertThat(statusOf(newKid)).isEqualTo("PUBLISHED");
    assertThat(jwksKids()).contains(oldKid, newKid);
    assertThat(kidOf(tokens.user(Ids.newId()).mint())).isEqualTo(oldKid);

    // Lead time not elapsed yet: no promotion.
    keys.runLifecycle();
    assertThat(keys.activeKeyId()).isEqualTo(oldKid);

    // Publish lead (24 h) elapsed: new key becomes ACTIVE, old one stays PUBLISHED (overlap).
    shiftCreatedAt(newKid, properties.keyPublishLead().plusMinutes(1));
    keys.runLifecycle();
    assertThat(keys.activeKeyId()).isEqualTo(newKid);
    assertThat(statusOf(oldKid)).isEqualTo("PUBLISHED");
    assertThat(statusOf(newKid)).isEqualTo("ACTIVE");
    assertThat(jwksKids()).contains(oldKid, newKid);

    String newToken = tokens.user(Ids.newId()).perms("test.read").mint();
    assertThat(kidOf(newToken)).isEqualTo(newKid);
    mvc.perform(get(SecurityTestEndpoints.READ).header(AUTHORIZATION, TestTokens.bearer(oldToken)))
        .andExpect(status().isOk());
    mvc.perform(get(SecurityTestEndpoints.READ).header(AUTHORIZATION, TestTokens.bearer(newToken)))
        .andExpect(status().isOk());

    // Still within max token age + margin after demotion: not retired.
    keys.runLifecycle();
    assertThat(statusOf(oldKid)).isEqualTo("PUBLISHED");

    // Every token the old key signed has expired: it is retired and leaves the JWKS.
    shiftDemotedAt(oldKid, keys.retireAfter().plusMinutes(1));
    keys.runLifecycle();
    assertThat(statusOf(oldKid)).isEqualTo("RETIRED");
    assertThat(jwksKids()).contains(newKid).doesNotContain(oldKid);
    mvc.perform(get(SecurityTestEndpoints.READ).header(AUTHORIZATION, TestTokens.bearer(oldToken)))
        .andExpect(status().isUnauthorized());
  }

  @Test
  @Order(4)
  void lifecycleJobPublishesASuccessorWhenTheActiveKeyIsDue() throws Exception {
    String activeKid = keys.activeKeyId();
    jdbc.sql("UPDATE signing_key SET activated_at = activated_at - make_interval(secs => :s) WHERE kid = :kid")
        .param("s", properties.keyRotationInterval().plusDays(1).toSeconds())
        .param("kid", activeKid)
        .update();

    keys.runLifecycle();

    List<String> pending = jdbc.sql("SELECT kid FROM signing_key WHERE status = 'PUBLISHED' AND created_at > "
            + "(SELECT created_at FROM signing_key WHERE kid = :kid)")
        .param("kid", activeKid).query(String.class).list();
    assertThat(pending).hasSize(1);
    assertThat(jwksKids()).contains(pending.get(0));
    assertThat(keys.activeKeyId()).isEqualTo(activeKid);

    keys.runLifecycle(); // idempotent: a successor already exists
    assertThat(jdbc.sql("SELECT count(*) FROM signing_key WHERE status = 'PUBLISHED' AND created_at > "
            + "(SELECT created_at FROM signing_key WHERE kid = :kid)")
        .param("kid", activeKid).query(Long.class).single()).isEqualTo(1L);
  }

  @Test
  @Order(5)
  void demotedKeyThatPredatesV7IsNeitherRetiredEarlyNorPromotedAgain() throws Exception {
    // An ACTIVE key created before V7 has activated_at = NULL.
    String legacyKid = keys.activeKeyId();
    jdbc.sql("UPDATE signing_key SET activated_at = NULL, created_at = created_at - interval '100 days' WHERE kid = :kid")
        .param("kid", legacyKid).update();
    String legacyToken = tokens.user(Ids.newId()).perms("test.read").mint();
    jdbc.sql("UPDATE signing_key SET status = 'RETIRED', retired_at = now() WHERE status = 'PUBLISHED'").update();
    String successor = keys.rotateNow();
    shiftCreatedAt(successor, properties.keyPublishLead().plusMinutes(1));

    keys.runLifecycle(); // promotes the successor, demotes the legacy key
    assertThat(keys.activeKeyId()).isEqualTo(successor);
    keys.rotateNow();    // a newer, not yet ready successor exists
    keys.runLifecycle();

    assertThat(statusOf(legacyKid)).isEqualTo("PUBLISHED");
    assertThat(keys.activeKeyId()).isEqualTo(successor);
    mvc.perform(get(SecurityTestEndpoints.READ).header(AUTHORIZATION, TestTokens.bearer(legacyToken)))
        .andExpect(status().isOk());
  }

  @Test
  @Order(6)
  void rotationCommandPublishesANewKeyAndExitsOnlyWhenRequested() throws Exception {
    List<Integer> exitCodes = new ArrayList<>();
    SigningKeyRotationCommand command = new SigningKeyRotationCommand(keys, exitCodes::add);
    long before = publishedCount();

    command.run(new DefaultApplicationArguments("--server.port=0"));
    assertThat(exitCodes).isEmpty();
    assertThat(publishedCount()).isEqualTo(before);

    command.run(new DefaultApplicationArguments("--" + SigningKeyRotationCommand.OPTION));
    assertThat(exitCodes).containsExactly(0);
    assertThat(publishedCount()).isEqualTo(before + 1);
    assertThat(rotationCommand).isNotNull(); // registered as an ApplicationRunner in the running app
  }

  @Autowired SigningKeyRotationCommand rotationCommand;

  private long publishedCount() {
    return jdbc.sql("SELECT count(*) FROM signing_key WHERE status = 'PUBLISHED'").query(Long.class).single();
  }

  private void shiftCreatedAt(String kid, Duration by) {
    jdbc.sql("UPDATE signing_key SET created_at = created_at - make_interval(secs => :s) WHERE kid = :kid")
        .param("s", by.toSeconds()).param("kid", kid).update();
  }

  private void shiftDemotedAt(String kid, Duration by) {
    jdbc.sql("UPDATE signing_key SET demoted_at = demoted_at - make_interval(secs => :s) WHERE kid = :kid")
        .param("s", by.toSeconds()).param("kid", kid).update();
  }

  private String statusOf(String kid) {
    return jdbc.sql("SELECT status FROM signing_key WHERE kid = :kid").param("kid", kid).query(String.class).single();
  }

  private List<String> jwksKids() throws Exception {
    String body = mvc.perform(get("/.well-known/jwks.json")).andReturn().getResponse().getContentAsString();
    List<String> kids = new ArrayList<>();
    for (JsonNode key : json.readTree(body).get("keys")) {
      kids.add(key.get("kid").asText());
    }
    return kids;
  }

  private static String kidOf(String token) throws Exception {
    return SignedJWT.parse(token).getHeader().getKeyID();
  }
}
