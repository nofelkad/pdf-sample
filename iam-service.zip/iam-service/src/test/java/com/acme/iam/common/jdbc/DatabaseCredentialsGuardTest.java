package com.acme.iam.common.jdbc;

import static org.assertj.core.api.Assertions.assertThatCode;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

import org.junit.jupiter.api.Test;
import org.springframework.boot.SpringApplication;
import org.springframework.mock.env.MockEnvironment;

/** Task 9 security review: the well-known local passwords never reach a non-local deployment. */
class DatabaseCredentialsGuardTest {

  private final DatabaseCredentialsGuard guard = new DatabaseCredentialsGuard();

  private static MockEnvironment env(String appPassword, String migratorPassword, String... profiles) {
    MockEnvironment env = new MockEnvironment();
    if (appPassword != null) {
      env.setProperty("spring.datasource.password", appPassword);
    }
    if (migratorPassword != null) {
      env.setProperty("spring.flyway.password", migratorPassword);
    }
    env.setActiveProfiles(profiles);
    return env;
  }

  @Test
  void theLocalDefaultsFailOutsideDevAndTest() {
    assertThatThrownBy(() -> guard.postProcessEnvironment(env("iam_app", "s3cret-m"), new SpringApplication()))
        .isInstanceOf(IllegalStateException.class).hasMessageContaining("spring.datasource.password");
    assertThatThrownBy(() -> guard.postProcessEnvironment(env("s3cret-a", "iam_migrator", "prod"), new SpringApplication()))
        .isInstanceOf(IllegalStateException.class).hasMessageContaining("spring.flyway.password");
  }

  @Test
  void missingPasswordsFailOutsideDevAndTest() {
    assertThatThrownBy(() -> guard.postProcessEnvironment(env(null, "s3cret-m"), new SpringApplication()))
        .isInstanceOf(IllegalStateException.class).hasMessageContaining("IAM_DB_APP_PASSWORD");
  }

  @Test
  void devLocalAndTestProfilesMayUseThem() {
    for (String profile : new String[] {"dev", "local", "test"}) {
      assertThatCode(() -> guard.postProcessEnvironment(env("iam_app", "iam_migrator", profile), new SpringApplication()))
          .doesNotThrowAnyException();
    }
  }

  @Test
  void realPasswordsPass() {
    assertThatCode(() -> guard.postProcessEnvironment(env("s3cret-a", "s3cret-m", "prod"), new SpringApplication()))
        .doesNotThrowAnyException();
  }
}
