package com.acme.iam.observability;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import com.acme.iam.common.test.IntegrationTest;
import com.acme.iam.common.test.PostgresTestBase;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.actuate.observability.AutoConfigureObservability;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.test.web.servlet.MockMvc;

/** {@code iam.observability.metrics-public=false}: the scrape endpoint falls back to "authenticated" (401). */
@IntegrationTest(properties = "iam.observability.metrics-public=false")
@AutoConfigureMockMvc
@AutoConfigureObservability
class PrometheusLockedDownIT extends PostgresTestBase {

  @Autowired MockMvc mvc;

  @Test
  void theEndpointRequiresAuthentication() throws Exception {
    mvc.perform(get("/actuator/prometheus")).andExpect(status().isUnauthorized());
  }
}
