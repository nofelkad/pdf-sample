package com.acme.iam.auth;

import static org.assertj.core.api.Assertions.assertThat;

import java.time.Duration;
import java.util.Map;
import org.junit.jupiter.api.Test;

/** Per-account session lifetimes from {@code account.settings}, clamped to sane bounds. */
class SessionTtlTest {

  static final AuthProperties.Session DEFAULTS =
      new AuthProperties.Session(Duration.ofHours(12), Duration.ofMinutes(30));

  @Test
  void defaultsWithoutSettings() {
    assertThat(SessionTtl.from(Map.of(), DEFAULTS))
        .isEqualTo(new SessionTtl(Duration.ofHours(12), Duration.ofMinutes(30)));
  }

  @Test
  void nestedAndFlatKeysOverride() {
    assertThat(SessionTtl.from(Map.of("session", Map.of("absoluteTtl", "PT2H", "idleTtl", "PT5M")), DEFAULTS))
        .isEqualTo(new SessionTtl(Duration.ofHours(2), Duration.ofMinutes(5)));
    assertThat(SessionTtl.from(Map.of("session.idleTtl", "PT10M"), DEFAULTS))
        .isEqualTo(new SessionTtl(Duration.ofHours(12), Duration.ofMinutes(10)));
  }

  @Test
  void malformedValuesTakeTheDefaults() {
    assertThat(SessionTtl.from(Map.of("session", Map.of("absoluteTtl", "forever", "idleTtl", "-PT5M")), DEFAULTS))
        .isEqualTo(new SessionTtl(Duration.ofHours(12), Duration.ofMinutes(30)));
  }

  @Test
  void absoluteIsCappedAtSevenDaysAndIdleAtAbsolute() {
    assertThat(SessionTtl.from(Map.of("session", Map.of("absoluteTtl", "P30D", "idleTtl", "P10D")), DEFAULTS))
        .isEqualTo(new SessionTtl(Duration.ofDays(7), Duration.ofDays(7)));
    assertThat(SessionTtl.from(Map.of("session", Map.of("absoluteTtl", "PT1H", "idleTtl", "PT2H")), DEFAULTS))
        .isEqualTo(new SessionTtl(Duration.ofHours(1), Duration.ofHours(1)));
  }
}
