package com.acme.iam.assignment;

import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.http.HttpHeaders.AUTHORIZATION;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import com.acme.iam.account.SubscriptionStatus;
import com.acme.iam.common.test.Fixtures;
import com.acme.iam.common.test.IntegrationTest;
import com.acme.iam.common.test.PostgresTestBase;
import com.acme.iam.common.test.TestTokens;
import com.acme.iam.product.Product;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.util.HashSet;
import java.util.Set;
import java.util.UUID;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.jdbc.core.simple.JdbcClient;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.ResultActions;

/** P1-10.6: explain endpoint; its permission codes equal {@code PermissionResolver.resolve}. */
@IntegrationTest
@AutoConfigureMockMvc
class EffectivePermissionsIT extends PostgresTestBase {

  @Autowired MockMvc mvc;
  @Autowired TestTokens tokens;
  @Autowired JdbcClient jdbc;
  @Autowired ObjectMapper json;
  @Autowired PermissionResolver resolver;

  Fixtures fx;
  Fixtures.Scenario s;
  UUID t1;
  UUID t2;
  UUID target;          // the user being explained, member of t1 only
  UUID product;
  UUID roleA;
  UUID roleB;
  String accountReader;
  String tenantReader;

  @BeforeEach
  void setUp() {
    fx = new Fixtures(jdbc);
    s = fx.scenario();
    t1 = s.tenantId();
    t2 = fx.tenant(s.accountId());
    product = fx.entitledProduct(s.accountId(), t1);
    fx.enableProduct(t2, product, true);
    UUID p1 = fx.permission(product);
    UUID p2 = fx.permission(product);
    UUID p3 = fx.permission(Product.IAM_ID);
    roleA = fx.systemRole(product, p1, p2);
    roleB = fx.systemRole(product, p2, p3);   // p2 is granted twice: by both roles
    target = fx.user(s.accountId(), t1);
    fx.assign(target, roleA, ScopeType.TENANT, t1);
    fx.assign(target, roleB, ScopeType.ACCOUNT, s.accountId());

    UUID reader = s.userId();
    UUID readAccount = fx.permission(Product.IAM_ID, "iam.user.read.account");
    fx.assign(reader, fx.systemRole(Product.IAM_ID, readAccount), ScopeType.ACCOUNT, s.accountId());
    accountReader = tokens.user(reader).account(s.accountId()).tenant(t1).perms("iam.user.read.account").bearer();
    tenantReader = tokens.user(reader).account(s.accountId()).tenant(t1).perms("iam.user.read.tenant").bearer();
  }

  private ResultActions explain(UUID user, UUID tenant, String bearer) throws Exception {
    var request = get("/api/users/" + user + "/effective-permissions");
    if (tenant != null) {
      request.param("tenantId", tenant.toString());
    }
    return mvc.perform(request.header(AUTHORIZATION, bearer));
  }

  @Test
  void explainsEveryPermissionWithItsGrantsAndEqualsTheResolver() throws Exception {
    JsonNode body = json.readTree(explain(target, t1, accountReader)
        .andExpect(status().isOk())
        .andExpect(jsonPath("$.userId").value(target.toString()))
        .andExpect(jsonPath("$.tenantId").value(t1.toString()))
        .andReturn().getResponse().getContentAsString());

    Set<String> codes = new HashSet<>();
    body.get("permissions").forEach(p -> codes.add(p.get("code").asText()));
    assertThat(codes).isEqualTo(resolver.resolve(target, t1)).hasSize(3);

    JsonNode shared = null;
    for (JsonNode p : body.get("permissions")) {
      if (p.get("grants").size() == 2) {
        shared = p;
      }
    }
    assertThat(shared).as("the permission granted by both roles").isNotNull();
    Set<String> grants = new HashSet<>();
    shared.get("grants").forEach(g -> grants.add(g.get("roleId").asText() + "|" + g.get("scopeType").asText() + "|"
        + g.get("scopeId").asText() + "|" + g.get("roleName").asText()));
    assertThat(grants).containsExactlyInAnyOrder(
        roleA + "|TENANT|" + t1 + "|" + roleName(roleA),
        roleB + "|ACCOUNT|" + s.accountId() + "|" + roleName(roleB));
  }

  private String roleName(UUID id) {
    return jdbc.sql("SELECT name FROM role WHERE id = :id").param("id", id).query(String.class).single();
  }

  @Test
  void tenantIdDefaultsToTheActiveTenantAndAnOtherTenantShowsOnlyAccountScopeGrants() throws Exception {
    fx.membership(target, t2, com.acme.iam.user.MembershipStatus.ACTIVE);

    JsonNode inT2 = json.readTree(explain(target, t2, accountReader).andExpect(status().isOk())
        .andReturn().getResponse().getContentAsString());
    Set<String> codes = new HashSet<>();
    inT2.get("permissions").forEach(p -> codes.add(p.get("code").asText()));
    assertThat(codes).isEqualTo(resolver.resolve(target, t2)).hasSize(2);   // roleB only: roleA is tenant t1

    explain(target, null, accountReader).andExpect(status().isOk())
        .andExpect(jsonPath("$.tenantId").value(t1.toString()));
  }

  @Test
  void aTenantLevelReaderMayExplainMembersOfTheirActiveTenantOnly() throws Exception {
    explain(target, t1, tenantReader).andExpect(status().isOk());
    explain(target, null, tenantReader).andExpect(status().isOk());

    explain(target, t2, tenantReader).andExpect(status().isForbidden())
        .andExpect(jsonPath("$.code").value("scope_exceeded"));
    UUID notMember = fx.user(s.accountId(), t2);
    explain(notMember, t1, tenantReader).andExpect(status().isNotFound())
        .andExpect(jsonPath("$.code").value("user_not_found"));
    explain(notMember, t1, accountReader).andExpect(status().isOk())          // account level: no membership needed
        .andExpect(jsonPath("$.permissions.length()").value(0));
  }

  @Test
  void anotherTenantNeedsAnAccountScopeGrantNotJustAnAccountReadPermissionInTheToken() throws Exception {
    UUID tenantScopedReader = fx.user(s.accountId(), t1);
    fx.assign(tenantScopedReader, fx.systemRole(Product.IAM_ID, fx.permission(Product.IAM_ID, "iam.user.read.account")),
        ScopeType.TENANT, t1);
    String token = tokens.user(tenantScopedReader).account(s.accountId()).tenant(t1)
        .perms("iam.user.read.account").bearer();

    explain(target, t1, token).andExpect(status().isOk());
    explain(target, t2, token).andExpect(status().isForbidden()).andExpect(jsonPath("$.code").value("scope_exceeded"));
  }

  @Test
  void aTokenWithoutAnActiveTenantNeedsAnExplicitTenantId() throws Exception {
    var noTid = org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.jwt()
        .jwt(j -> j.subject(s.userId().toString()).claim("acc", s.accountId().toString()).claim("sv", 1))
        .authorities(new org.springframework.security.core.authority.SimpleGrantedAuthority("iam.user.read.account"));

    mvc.perform(get("/api/users/" + target + "/effective-permissions").with(noTid))
        .andExpect(status().isBadRequest())
        .andExpect(jsonPath("$.code").value("tenant_required"));
  }

  @Test
  void deniedWithoutAReadPermissionAndForOtherAccounts() throws Exception {
    String none = tokens.user(s.userId()).account(s.accountId()).tenant(t1).perms("iam.role.assign").bearer();
    Fixtures.Scenario other = fx.scenario();

    explain(target, t1, none).andExpect(status().isForbidden());
    mvc.perform(get("/api/users/" + target + "/effective-permissions")).andExpect(status().isUnauthorized());
    explain(other.userId(), t1, accountReader).andExpect(status().isNotFound())
        .andExpect(jsonPath("$.code").value("user_not_found"));
    explain(target, other.tenantId(), accountReader).andExpect(status().isNotFound())
        .andExpect(jsonPath("$.code").value("tenant_not_found"));
    explain(UUID.randomUUID(), t1, accountReader).andExpect(status().isNotFound());
  }

  @Test
  void aSuspendedTenantOrExpiredSubscriptionYieldsNoPermissionsExactlyLikeTheResolver() throws Exception {
    fx.subscribe(s.accountId(), product, SubscriptionStatus.EXPIRED, null);

    JsonNode body = json.readTree(explain(target, t1, accountReader).andExpect(status().isOk())
        .andReturn().getResponse().getContentAsString());

    Set<String> codes = new HashSet<>();
    body.get("permissions").forEach(p -> codes.add(p.get("code").asText()));
    assertThat(codes).isEqualTo(resolver.resolve(target, t1)).hasSize(1);   // only the IAM permission remains
  }
}
