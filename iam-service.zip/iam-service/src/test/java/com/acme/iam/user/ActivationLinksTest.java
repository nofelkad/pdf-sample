package com.acme.iam.user;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoInteractions;

import com.acme.iam.audit.AuditEvent;
import com.acme.iam.audit.AuditWriter;
import java.time.Instant;
import java.util.UUID;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;

/** Ruling R46: activation links in API responses are built from the email template and audited without the token. */
class ActivationLinksTest {

  private static final UUID ACCOUNT = UUID.randomUUID();
  private static final UUID TENANT = UUID.randomUUID();
  private static final UUID USER = UUID.randomUUID();
  private static final IssuedToken TOKEN =
      new IssuedToken(UUID.randomUUID(), "raw-abc", Instant.parse("2026-10-20T00:00:00Z"));

  private final AuditWriter audit = mock(AuditWriter.class);

  @Test
  void buildsTheLinkFromTheInvitationTemplateAndAuditsWithoutTheToken() {
    Activation activation = links(true).issue(TOKEN, ACCOUNT, TENANT, USER, ActivationLinks.Via.INVITE);

    assertThat(activation.link()).isEqualTo("https://app.test/accept?token=raw-abc");
    assertThat(activation.expiresAt()).isEqualTo(TOKEN.expiresAt());
    assertThat(activation.toString()).doesNotContain("raw-abc");

    ArgumentCaptor<AuditEvent> captor = ArgumentCaptor.forClass(AuditEvent.class);
    verify(audit).write(captor.capture());
    AuditEvent event = captor.getValue();
    assertThat(event.action()).isEqualTo("iam.invitation.link_issued");
    assertThat(event.accountId()).isEqualTo(ACCOUNT);
    assertThat(event.tenantId()).isEqualTo(TENANT);
    assertThat(event.targetType()).isEqualTo("app_user");
    assertThat(event.targetId()).isEqualTo(USER.toString());
    assertThat(event.metadata()).containsEntry("via", "invite")
        .containsEntry("expires_at", "2026-10-20T00:00:00Z");
    assertThat(event.metadata().toString()).doesNotContain("raw-abc").doesNotContain("token=");
  }

  @Test
  void returnsNothingAndAuditsNothingWhenSwitchedOff() {
    assertThat(links(false).issue(TOKEN, ACCOUNT, TENANT, USER, ActivationLinks.Via.RESEND)).isNull();
    verifyNoInteractions(audit);
  }

  @Test
  void viaCodesAreSnakeCase() {
    assertThat(ActivationLinks.Via.ACCOUNT_CREATE.code()).isEqualTo("account_create");
    assertThat(ActivationLinks.Via.ADMIN_RECOVERY.code()).isEqualTo("admin_recovery");
  }

  private ActivationLinks links(boolean expose) {
    return new ActivationLinks(new NotificationProperties(NotificationProperties.Mode.LOG, "no-reply@iam.local",
        "https://app.test/accept?token={token}", "https://app.test/reset?token={token}", expose), audit);
  }
}
