package com.acme.iam.user;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.assertj.core.api.Assertions.within;
import static org.springframework.http.HttpHeaders.AUTHORIZATION;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.header;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import com.acme.iam.assignment.ScopeType;
import com.acme.iam.common.Ids;
import com.acme.iam.common.error.BadRequestException;
import com.acme.iam.common.test.CapturingNotificationAdapter;
import com.acme.iam.common.test.Fixtures;
import com.acme.iam.common.test.IntegrationTest;
import com.acme.iam.common.test.OrgTestData;
import com.acme.iam.common.test.PostgresTestBase;
import com.acme.iam.common.test.TestTokens;
import com.acme.iam.product.Product;
import com.acme.iam.tenant.TenantStatus;
import com.acme.iam.user.InvitationService.PendingInvitation;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.time.OffsetDateTime;
import java.time.temporal.ChronoUnit;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.context.annotation.Import;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.jdbc.core.simple.JdbcClient;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.ResultActions;
import org.springframework.transaction.support.TransactionTemplate;

/** P1-8.2 invitations: INVITED user + membership + optional roles in one transaction, email after commit, resend. */
@IntegrationTest
@AutoConfigureMockMvc
@Import(CapturingNotificationAdapter.Config.class)
class InvitationApiIT extends PostgresTestBase {

  @Autowired MockMvc mvc;
  @Autowired TestTokens tokens;
  @Autowired JdbcClient jdbc;
  @Autowired ObjectMapper json;
  @Autowired CapturingNotificationAdapter mailbox;
  @Autowired UserTokenService userTokens;
  @Autowired InvitationService invitations;
  @Autowired TransactionTemplate tx;

  OrgTestData org;
  Fixtures fx;
  UUID account;
  UUID tenant;
  UUID admin;
  String adminBearer;
  String email;

  @BeforeEach
  void setUp() {
    mailbox.clear();
    org = new OrgTestData(jdbc);
    fx = org.fixtures();
    Fixtures.Scenario s = fx.scenario();
    account = s.accountId();
    tenant = s.tenantId();
    admin = org.accountAdmin(account, tenant);
    adminBearer = org.adminBearer(tokens, admin, account, tenant);
    email = "new-" + Ids.newId() + "@example.test";
  }

  @Test
  void invitesWithRolesInOneTransactionAndEmailsAfterCommit() throws Exception {
    UUID tenantAdminRole = org.tenantAdminRole();
    JsonNode body = json.readTree(invite(tenant, adminBearer, """
        {"email":"%s","displayName":"Jane","roles":[{"roleId":"%s","scopeType":"TENANT"}]}"""
        .formatted(email, tenantAdminRole))
        .andExpect(status().isCreated())
        .andExpect(jsonPath("$.user.status").value("INVITED"))
        .andExpect(jsonPath("$.user.primaryTenantId").value(tenant.toString()))
        .andExpect(jsonPath("$.assignmentIds.length()").value(1))
        .andExpect(header().string(HttpHeaders.CACHE_CONTROL, "no-store"))
        .andExpect(jsonPath("$.activation.expiresAt").isNotEmpty())
        .andReturn().getResponse().getContentAsString());
    UUID user = UUID.fromString(body.at("/user/id").asText());

    assertThat(org.membershipTenants(user)).containsExactly(tenant);
    Map<String, Object> grant = jdbc.sql("""
            SELECT role_id, scope_type, scope_id, granted_by FROM role_assignment WHERE user_id = :u""")
        .param("u", user).query().singleRow();
    assertThat(grant).containsEntry("role_id", tenantAdminRole).containsEntry("scope_type", "TENANT")
        .containsEntry("scope_id", tenant).containsEntry("granted_by", admin);
    assertThat(org.outstandingInviteExpiry(user).toInstant())
        .isCloseTo(OffsetDateTime.now().plusDays(7).toInstant(), within(1, ChronoUnit.MINUTES));

    String raw = mailbox.lastInvitationToken(email);
    UUID consumedBy = tx.execute(s -> userTokens.consume(raw, TokenPurpose.INVITE).user());
    assertThat(consumedBy).isEqualTo(user);

    assertThat(body.at("/activation/link").asText()).endsWith("token=" + raw);
    assertThat(jdbc.sql("SELECT count(*) FROM audit_event WHERE action = 'iam.invitation.link_issued' "
            + "AND target_id = :u AND metadata->>'via' = 'invite'")
        .param("u", user.toString()).query(Long.class).single()).isEqualTo(1);
  }

  @Test
  void aRoleTheGrantorDoesNotHoldRollsTheWholeInvitationBack() throws Exception {
    UUID strangePerm = fx.permission(Product.IAM_ID);
    UUID role = fx.systemRole(Product.IAM_ID, strangePerm);

    invite(tenant, adminBearer, """
        {"email":"%s","roles":[{"roleId":"%s","scopeType":"ACCOUNT"}]}""".formatted(email, role))
        .andExpect(status().isForbidden())
        .andExpect(jsonPath("$.code").value("grantor_lacks_permissions"));

    assertThat(org.userByEmail(account, email)).isEmpty();
    assertThat(mailbox.sent()).isEmpty();
  }

  @Test
  void anExistingEmailIsAConflict() throws Exception {
    UUID existing = fx.user(account, tenant);
    invite(tenant, adminBearer, "{\"email\":\"%s\"}".formatted(fx.email(existing).toUpperCase()))
        .andExpect(status().isConflict())
        .andExpect(jsonPath("$.code").value("user_exists"));
  }

  @Test
  void aSuspendedTenantCannotInvite() throws Exception {
    UUID suspended = fx.tenant(account, TenantStatus.SUSPENDED);
    invite(suspended, adminBearer, "{\"email\":\"%s\"}".formatted(email))
        .andExpect(status().isConflict())
        .andExpect(jsonPath("$.code").value("tenant_not_active"));
  }

  @Test
  void theTenantGuardAppliesToThePathTenant() throws Exception {
    UUID other = fx.tenant(account);
    UUID tenantAdmin = fx.user(account, tenant);
    fx.assign(tenantAdmin, org.tenantAdminRole(), ScopeType.TENANT, tenant);
    String bearer = org.bearer(tokens, tenantAdmin, account, tenant, "iam.user.manage");

    invite(other, bearer, "{\"email\":\"%s\"}".formatted(email))
        .andExpect(status().isForbidden())
        .andExpect(jsonPath("$.code").value("scope_exceeded"));
    invite(fx.scenario().tenantId(), bearer, "{\"email\":\"%s\"}".formatted(email))
        .andExpect(status().isNotFound())
        .andExpect(jsonPath("$.code").value("tenant_not_found"));
    invite(tenant, bearer, "{\"email\":\"%s\"}".formatted(email)).andExpect(status().isCreated());
  }

  @Test
  void validatesTheEmail() throws Exception {
    invite(tenant, adminBearer, "{\"email\":\"nope\"}")
        .andExpect(status().isBadRequest())
        .andExpect(jsonPath("$.code").value("validation_failed"));
  }

  @Test
  void resendInvalidatesTheOldTokenAndIssuesANewOne() throws Exception {
    JsonNode body = json.readTree(invite(tenant, adminBearer, "{\"email\":\"%s\"}".formatted(email))
        .andExpect(status().isCreated()).andReturn().getResponse().getContentAsString());
    UUID user = UUID.fromString(body.at("/user/id").asText());
    String first = mailbox.lastInvitationToken(email);

    JsonNode resent = json.readTree(mvc.perform(post("/api/users/{id}/invitation/resend", user)
            .header(AUTHORIZATION, adminBearer))
        .andExpect(status().isOk())
        .andExpect(header().string(HttpHeaders.CACHE_CONTROL, "no-store"))
        .andExpect(jsonPath("$.invitationExpiresAt").isNotEmpty())
        .andReturn().getResponse().getContentAsString());
    mailbox.awaitCount(CapturingNotificationAdapter.Kind.INVITATION, email, 2); // sent asynchronously (I2)
    String second = mailbox.lastInvitationToken(email);
    assertThat(resent.at("/activation/link").asText()).endsWith("token=" + second);
    assertThat(second).isNotEqualTo(first);
    assertThat(org.outstandingTokens(user)).isEqualTo(1);

    assertThatThrownBy(() -> tx.execute(s -> userTokens.consume(first, TokenPurpose.INVITE)))
        .isInstanceOf(BadRequestException.class);
    UUID consumedBy = tx.execute(s -> userTokens.consume(second, TokenPurpose.INVITE).user());
    assertThat(consumedBy).isEqualTo(user);
  }

  /**
   * R46 final review: a re-sent invitation returns the link only to a caller who holds, at the same scope, every
   * permission of every role the invitee holds; a weaker user manager only triggers the email (no I6 bypass).
   */
  @Test
  void aWeakerUserManagerResendsWithoutGettingTheLink() throws Exception {
    UUID invitedAdmin = fx.user(account, tenant, UserStatus.INVITED);
    fx.assign(invitedAdmin, org.accountAdminRole(), ScopeType.ACCOUNT, account);
    UUID helpdesk = fx.user(account, tenant);
    UUID manageOnly = fx.systemRole(Product.IAM_ID, fx.permission(Product.IAM_ID, "iam.user.manage"));
    fx.assign(helpdesk, manageOnly, ScopeType.ACCOUNT, account);
    String helpdeskBearer = org.bearer(tokens, helpdesk, account, tenant, "iam.user.manage");

    mvc.perform(post("/api/users/{id}/invitation/resend", invitedAdmin).header(AUTHORIZATION, helpdeskBearer))
        .andExpect(status().isOk())
        .andExpect(jsonPath("$.invitationExpiresAt").isNotEmpty())
        .andExpect(jsonPath("$.activation").doesNotExist());
    assertThat(mailbox.lastInvitationToken(fx.email(invitedAdmin))).as("still emailed").isNotBlank();
    assertThat(jdbc.sql("SELECT count(*) FROM audit_event WHERE action = 'iam.invitation.link_issued' "
            + "AND target_id = :u").param("u", invitedAdmin.toString()).query(Long.class).single()).isZero();

    // the Account Admin holds every permission of the invitee's role, so it gets the link
    mvc.perform(post("/api/users/{id}/invitation/resend", invitedAdmin).header(AUTHORIZATION, adminBearer))
        .andExpect(status().isOk())
        .andExpect(jsonPath("$.activation.link").isNotEmpty());
  }

  @Test
  void resendIsOnlyForInvitedUsers() throws Exception {
    UUID active = fx.user(account, tenant);
    mvc.perform(post("/api/users/{id}/invitation/resend", active).header(AUTHORIZATION, adminBearer))
        .andExpect(status().isConflict())
        .andExpect(jsonPath("$.code").value("not_invited"));
  }

  @Test
  void notificationsAreSentOnlyAfterCommit() {
    PendingInvitation pending = new PendingInvitation(email, "Acme", "raw-token");
    assertThatThrownBy(() -> tx.executeWithoutResult(s -> {
      invitations.notifyAfterCommit(List.of(pending));
      throw new IllegalStateException("rollback");
    })).isInstanceOf(IllegalStateException.class);
    assertThat(mailbox.sent()).isEmpty();

    tx.executeWithoutResult(s -> {
      invitations.notifyAfterCommit(List.of(pending));
      assertThat(mailbox.sent()).isEmpty();
    });
    assertThat(mailbox.lastInvitationToken(email)).isEqualTo("raw-token"); // waits for the asynchronous send (I2)
    assertThat(pending.toString()).doesNotContain("raw-token");
  }

  private ResultActions invite(UUID tenantId, String bearer, String body) throws Exception {
    return mvc.perform(post("/api/tenants/{tenantId}/users", tenantId).header(AUTHORIZATION, bearer)
        .contentType(MediaType.APPLICATION_JSON).content(body));
  }
}
