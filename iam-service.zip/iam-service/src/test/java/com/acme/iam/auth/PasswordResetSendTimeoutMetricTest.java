package com.acme.iam.auth;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import com.acme.iam.observability.MetricNames;
import com.acme.iam.user.IssuedToken;
import com.acme.iam.user.NotificationPort;
import com.acme.iam.user.TokenPurpose;
import com.acme.iam.user.UserTokenService;
import io.micrometer.core.instrument.simple.SimpleMeterRegistry;
import java.time.Duration;
import java.time.Instant;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.function.Supplier;
import org.awaitility.Awaitility;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Test;

/** P1-11.5: a reset mail whose send hits {@code send-timeout} is counted (it used to be a WARN log line only). */
class PasswordResetSendTimeoutMetricTest {

  final SimpleMeterRegistry meters = new SimpleMeterRegistry();
  final CountDownLatch release = new CountDownLatch(1);
  PasswordResetMailer mailer;

  @AfterEach
  void tearDown() throws Exception {
    release.countDown();
    if (mailer != null) {
      mailer.destroy();
    }
  }

  @Test
  void aSendThatTimesOutIsCountedAndASendThatCompletesIsNot() {
    UserTokenService tokens = mock(UserTokenService.class);
    when(tokens.issue(any(), eq(TokenPurpose.PASSWORD_RESET), any(), any()))
        .thenAnswer(inv -> new IssuedToken(UUID.randomUUID(), "raw-" + UUID.randomUUID(), Instant.now()));
    AuthTransactions tx = mock(AuthTransactions.class);
    when(tx.write(any())).thenAnswer(inv -> ((Supplier<?>) inv.getArgument(0)).get());
    NotificationPort port = mock(NotificationPort.class);
    org.mockito.Mockito.doAnswer(inv -> {
      if (((String) inv.getArgument(0)).startsWith("hung")) {
        release.await(30, TimeUnit.SECONDS);
      }
      return null;
    }).when(port).sendPasswordReset(anyString(), anyString());
    mailer = new PasswordResetMailer(tokens, port, tx, Duration.ofMinutes(30),
        new AuthProperties.MailExecutor(1, 10, Duration.ofMillis(200)), meters);

    mailer.dispatch(List.of(new PasswordResetMailer.Target(UUID.randomUUID(), "ok@x.test")));
    mailer.dispatch(List.of(new PasswordResetMailer.Target(UUID.randomUUID(), "hung@x.test")));

    Awaitility.await().atMost(Duration.ofSeconds(5))
        .untilAsserted(() -> assertThat(meters.get(MetricNames.PASSWORD_RESET_SEND_TIMEOUTS).counter().count())
            .isEqualTo(1.0));
  }
}
