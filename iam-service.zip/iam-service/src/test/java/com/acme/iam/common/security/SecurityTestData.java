package com.acme.iam.common.security;

import com.acme.iam.common.Ids;
import java.sql.Timestamp;
import java.time.Instant;
import java.util.UUID;
import org.springframework.jdbc.core.simple.JdbcClient;
import org.springframework.lang.Nullable;

/**
 * Plain-SQL fixtures for the security tests (aggregates/repositories belong to Task 2). Each call autocommits and is
 * audited as SYSTEM. Slugs are random, so tests never collide.
 */
public final class SecurityTestData {

  public static final UUID IAM_PRODUCT = UUID.fromString("00000000-0000-7000-8000-000000000001");

  private final JdbcClient jdbc;

  public SecurityTestData(JdbcClient jdbc) {
    this.jdbc = jdbc;
  }

  public UUID account() {
    UUID id = Ids.newId();
    jdbc.sql("INSERT INTO account (id, name, slug, status, version) VALUES (?, 'Acme', ?, 'ACTIVE', 0)")
        .params(id, "acc-" + id).update();
    return id;
  }

  public UUID tenant(UUID account) {
    UUID id = Ids.newId();
    jdbc.sql("INSERT INTO tenant (id, account_id, name, slug, status, version) VALUES (?, ?, 'T', ?, 'ACTIVE', 0)")
        .params(id, account, "t-" + id).update();
    return id;
  }

  /** An ACTIVE user with membership in {@code primaryTenant}; {@code session_version = 1}. */
  public UUID user(UUID account, UUID primaryTenant) {
    UUID id = Ids.newId();
    jdbc.sql("""
            INSERT INTO app_user (id, account_id, email, status, primary_tenant_id, version)
            VALUES (?, ?, ?, 'ACTIVE', ?, 0)""")
        .params(id, account, id + "@example.com", primaryTenant).update();
    membership(id, primaryTenant);
    return id;
  }

  public void membership(UUID user, UUID tenant) {
    jdbc.sql("INSERT INTO user_tenant_membership (app_user, tenant_id) VALUES (?, ?)").params(user, tenant).update();
  }

  /** The IAM permission {@code code}, created when missing. */
  public UUID permission(String code) {
    return jdbc.sql("""
            INSERT INTO permission (id, product_id, code, kind, description, version)
            VALUES (?, ?, ?, 'FEATURE', 'test', 0)
            ON CONFLICT (code) DO UPDATE SET code = EXCLUDED.code, deprecated = false
            RETURNING id""")
        .params(Ids.newId(), IAM_PRODUCT, code).query(UUID.class).single();
  }

  /** A CUSTOM IAM role of {@code account} holding {@code permissions}. */
  public UUID role(UUID account, String... permissions) {
    UUID id = Ids.newId();
    jdbc.sql("INSERT INTO role (id, product_id, name, type, account_id, version) VALUES (?, ?, ?, 'CUSTOM', ?, 0)")
        .params(id, IAM_PRODUCT, "role-" + id, account).update();
    for (String code : permissions) {
      jdbc.sql("INSERT INTO role_permission (role, permission_id) VALUES (?, ?)").params(id, permission(code)).update();
    }
    return id;
  }

  public UUID assign(UUID user, UUID role, String scopeType, UUID scopeId, @Nullable Instant expiresAt) {
    UUID id = Ids.newId();
    jdbc.sql("""
            INSERT INTO role_assignment (id, user_id, role_id, scope_type, scope_id, expires_at, version)
            VALUES (:id, :user, :role, :scopeType, :scopeId, :expiresAt, 0)""")
        .param("id", id).param("user", user).param("role", role).param("scopeType", scopeType)
        .param("scopeId", scopeId)
        .param("expiresAt", expiresAt == null ? null : Timestamp.from(expiresAt), java.sql.Types.TIMESTAMP)
        .update();
    return id;
  }

  public int sessionVersion(UUID user) {
    return jdbc.sql("SELECT session_version FROM app_user WHERE id = ?").params(user).query(Integer.class).single();
  }
}
