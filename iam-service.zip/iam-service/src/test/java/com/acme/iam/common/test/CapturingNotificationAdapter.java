package com.acme.iam.common.test;

import com.acme.iam.user.NotificationPort;
import java.time.Duration;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.CopyOnWriteArrayList;
import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Primary;
import org.springframework.lang.Nullable;

/**
 * Test-only {@link NotificationPort} that records every notification, raw token included, so end-to-end tests can
 * follow invitation and password-reset links.
 *
 * <pre>{@code
 * @IntegrationTest
 * @Import(CapturingNotificationAdapter.Config.class)
 * class InvitationIT extends PostgresTestBase {
 *   @Autowired CapturingNotificationAdapter mailbox;
 *
 *   @BeforeEach void reset() { mailbox.clear(); }
 *
 *   @Test void acceptsInvitation() {
 *     // ... invite jane@example.test ...
 *     String token = mailbox.lastInvitationToken("jane@example.test");
 *   }
 * }
 * }</pre>
 *
 * The {@link Config} bean is {@link Primary}, so it wins over the default logging adapter.
 */
public class CapturingNotificationAdapter implements NotificationPort {

  public enum Kind {
    INVITATION,
    PASSWORD_RESET
  }

  /** One recorded notification. {@code accountName} is {@code null} for password resets. */
  public record Sent(Kind kind, String email, @Nullable String accountName, String rawToken) {}

  /** How long {@link #last} waits for an asynchronous notification. */
  public static final Duration WAIT = Duration.ofSeconds(10);

  private final List<Sent> sent = new CopyOnWriteArrayList<>();

  @Override
  public void sendInvitation(String email, String accountName, String rawToken) {
    sent.add(new Sent(Kind.INVITATION, email, accountName, rawToken));
  }

  @Override
  public void sendPasswordReset(String email, String rawToken) {
    sent.add(new Sent(Kind.PASSWORD_RESET, email, null, rawToken));
  }

  /** Everything recorded since the last {@link #clear()}, oldest first. */
  public List<Sent> sent() {
    return List.copyOf(sent);
  }

  /**
   * The most recent notification of this kind to this address (case-insensitive). Invitations and password resets are
   * sent asynchronously after commit (final review I2, ruling R31), so this waits up to {@link #WAIT} for the first
   * one to arrive; use {@link #awaitCount} when an earlier notification to the same address already exists.
   */
  public Optional<Sent> last(Kind kind, String email) {
    long deadline = System.nanoTime() + WAIT.toNanos();
    while (true) {
      Optional<Sent> found = sent.reversed().stream()
          .filter(s -> s.kind() == kind && s.email().equalsIgnoreCase(email))
          .findFirst();
      if (found.isPresent() || System.nanoTime() > deadline) {
        return found;
      }
      pause();
    }
  }

  /** Waits up to {@link #WAIT} until at least {@code count} notifications of this kind went to this address. */
  public void awaitCount(Kind kind, String email, int count) {
    long deadline = System.nanoTime() + WAIT.toNanos();
    while (sent.stream().filter(s -> s.kind() == kind && s.email().equalsIgnoreCase(email)).count() < count) {
      if (System.nanoTime() > deadline) {
        throw new AssertionError("Fewer than " + count + " " + kind + " notifications sent to " + email);
      }
      pause();
    }
  }

  private static void pause() {
    try {
      Thread.sleep(20);
    } catch (InterruptedException e) {
      Thread.currentThread().interrupt();
      throw new AssertionError("interrupted", e);
    }
  }

  /** @throws AssertionError if no invitation was sent to {@code email} */
  public String lastInvitationToken(String email) {
    return last(Kind.INVITATION, email).map(Sent::rawToken)
        .orElseThrow(() -> new AssertionError("No invitation sent to " + email));
  }

  /** @throws AssertionError if no password reset was sent to {@code email} */
  public String lastPasswordResetToken(String email) {
    return last(Kind.PASSWORD_RESET, email).map(Sent::rawToken)
        .orElseThrow(() -> new AssertionError("No password reset sent to " + email));
  }

  public void clear() {
    sent.clear();
  }

  /** Import this to replace the active {@link NotificationPort} with a capturing one. */
  @TestConfiguration(proxyBeanMethods = false)
  public static class Config {

    @Bean
    @Primary
    public CapturingNotificationAdapter capturingNotificationAdapter() {
      return new CapturingNotificationAdapter();
    }
  }
}
