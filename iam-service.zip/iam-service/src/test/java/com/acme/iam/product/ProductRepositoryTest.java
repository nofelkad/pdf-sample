package com.acme.iam.product;

import static org.assertj.core.api.Assertions.assertThat;

import com.acme.iam.common.Ids;
import com.acme.iam.common.test.JdbcSliceTest;
import com.acme.iam.common.test.PostgresTestBase;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;

/** P1-3.1: Product and Permission round trips. */
@JdbcSliceTest
class ProductRepositoryTest extends PostgresTestBase {

  @Autowired ProductRepository products;
  @Autowired PermissionRepository permissions;

  @Test
  void roundTripsProduct() {
    String code = "BILLING_" + Ids.newId().toString().substring(24);
    Product saved = products.save(Product.create(code, "Billing"));
    assertThat(saved.version()).isZero();

    assertThat(products.findByCode(code)).contains(saved);
    products.save(saved.withName("Billing & Invoicing"));
    assertThat(products.findById(saved.id()).orElseThrow())
        .extracting(Product::name, Product::version).containsExactly("Billing & Invoicing", 1L);
  }

  @Test
  void seededIamProductIsReadable() {
    Product iam = products.findById(Product.IAM_ID).orElseThrow();
    assertThat(iam.isIam()).isTrue();
    assertThat(products.findByCode(Product.IAM_CODE)).contains(iam);
  }

  @Test
  void roundTripsPermission() {
    Product product = products.save(Product.create("P_" + Ids.newId().toString().substring(24), "P"));
    String code = "p." + Ids.newId() + ".invoice.read.tenant";
    Permission saved = permissions.save(
        Permission.create(product.id(), code, PermissionKind.DATA, "Read invoices").withFlags(true, true, false));

    Permission loaded = permissions.findByCode(code).orElseThrow();
    assertThat(loaded).isEqualTo(saved);
    assertThat(loaded.product()).isEqualTo(product.id());
    assertThat(loaded.kind()).isEqualTo(PermissionKind.DATA);
    assertThat(loaded.sensitive()).isTrue();
    assertThat(loaded.auditRead()).isTrue();
    assertThat(loaded.deprecated()).isFalse();

    permissions.save(loaded.withFlags(true, true, true));
    assertThat(permissions.findAllByProduct(product.id())).singleElement()
        .extracting(Permission::deprecated, Permission::version).containsExactly(true, 1L);
  }
}
