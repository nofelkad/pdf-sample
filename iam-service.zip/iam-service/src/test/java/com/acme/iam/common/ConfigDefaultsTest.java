package com.acme.iam.common;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.List;
import org.junit.jupiter.api.Test;
import org.springframework.boot.env.YamlPropertySourceLoader;
import org.springframework.core.env.PropertySource;
import org.springframework.core.io.ClassPathResource;

/** Task 9 security review / failure modes: the shipped {@code application.yml} defaults. */
class ConfigDefaultsTest {

  private static PropertySource<?> yaml(String name) throws Exception {
    List<PropertySource<?>> sources = new YamlPropertySourceLoader().load(name, new ClassPathResource(name));
    return sources.get(0);
  }

  @Test
  void databasePasswordsHaveNoDefaultOutsideTheDevProfile() throws Exception {
    PropertySource<?> main = yaml("application.yml");
    assertThat(String.valueOf(main.getProperty("spring.datasource.password"))).isEqualTo("${IAM_DB_APP_PASSWORD}");
    assertThat(String.valueOf(main.getProperty("spring.flyway.password"))).isEqualTo("${IAM_DB_MIGRATOR_PASSWORD}");

    PropertySource<?> dev = yaml("application-dev.yml");
    assertThat(String.valueOf(dev.getProperty("spring.datasource.password"))).contains(":iam_app}");
    assertThat(String.valueOf(dev.getProperty("spring.flyway.password"))).contains(":iam_migrator}");
  }

  /**
   * Fix round 1: the {@code local} profile (load-test script, CLI from a checkout) only supplies the docker-compose
   * passwords; with it the shipped configuration starts against compose, and the guard lets it through.
   */
  @Test
  void theLocalProfileOnlySuppliesTheComposePasswordsAndPassesTheGuard() throws Exception {
    PropertySource<?> local = yaml("application-local.yml");
    assertThat(((org.springframework.core.env.EnumerablePropertySource<?>) local).getPropertyNames())
        .containsExactlyInAnyOrder("spring.datasource.password", "spring.flyway.password");

    org.springframework.core.env.StandardEnvironment env = new org.springframework.core.env.StandardEnvironment();
    env.getPropertySources().addLast(local);
    env.getPropertySources().addLast(yaml("application.yml"));
    env.setActiveProfiles("local", "plain-logs");
    new com.acme.iam.common.jdbc.DatabaseCredentialsGuard()
        .postProcessEnvironment(env, new org.springframework.boot.SpringApplication());
    assertThat(env.getProperty("spring.datasource.password")).isEqualTo("iam_app");
    assertThat(env.getProperty("spring.flyway.password")).isEqualTo("iam_migrator");
  }

  /** The documented local flows activate a profile that has the compose passwords. */
  @Test
  void localScriptsAndDocsUseTheLocalOrDevProfile() throws Exception {
    java.nio.file.Path root = java.nio.file.Path.of("..");
    assertThat(java.nio.file.Files.readString(root.resolve("load-test/scripts/start-iam.sh")))
        .contains("--spring.profiles.active=local,plain-logs");
    assertThat(java.nio.file.Files.readString(root.resolve("docs/runbooks/key-rotation.md")))
        .contains("--spring.profiles.active=local");
    assertThat(java.nio.file.Files.readString(root.resolve("docs/local-development.md")))
        .contains("SPRING_PROFILES_ACTIVE=dev ./gradlew :iam-service:bootRun");
  }

  @Test
  void smtpHasConnectReadAndWriteTimeouts() throws Exception {
    PropertySource<?> main = yaml("application.yml");
    assertThat(main.getProperty("spring.mail.properties.mail.smtp.connectiontimeout")).isNotNull();
    assertThat(main.getProperty("spring.mail.properties.mail.smtp.timeout")).isNotNull();
    assertThat(main.getProperty("spring.mail.properties.mail.smtp.writetimeout")).isNotNull();
  }

  @Test
  void databaseCallsAreBoundedSoAnOutageFailsFastInsteadOfHanging() throws Exception {
    PropertySource<?> main = yaml("application.yml");
    assertThat(main.getProperty("spring.datasource.hikari.connection-timeout")).isNotNull();
    assertThat(main.getProperty("spring.datasource.hikari.validation-timeout")).isNotNull();
    assertThat(main.getProperty("spring.datasource.hikari.data-source-properties.connectTimeout")).isNotNull();
    assertThat(main.getProperty("spring.datasource.hikari.data-source-properties.socketTimeout")).isNotNull();
  }

  @Test
  void corsIsClosedByDefault() throws Exception {
    PropertySource<?> main = yaml("application.yml");
    assertThat(String.valueOf(main.getProperty("iam.security.cors.allowed-origins"))).isEqualTo("${IAM_CORS_ALLOWED_ORIGINS:}");
  }
}
