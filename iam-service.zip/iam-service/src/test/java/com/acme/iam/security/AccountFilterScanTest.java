package com.acme.iam.security;

import static org.assertj.core.api.Assertions.assertThat;

import java.io.IOException;
import java.lang.reflect.Method;
import java.lang.reflect.Parameter;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.TreeSet;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Stream;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.config.BeanDefinition;
import org.springframework.context.annotation.ClassPathScanningCandidateComponentProvider;
import org.springframework.core.type.filter.AssignableTypeFilter;
import org.springframework.data.jdbc.repository.query.Query;
import org.springframework.data.repository.Repository;

/**
 * Invariant I10 (spec section 5): "All queries in admin services are filtered by the caller's {@code acc}. A test
 * asserts that no repository method lacks an account filter." (Task 9, deliverable B.)
 *
 * <p>Two scans over the tables that hold account-owned rows ({@link #ACCOUNT_OWNED}):
 *
 * <ol>
 *   <li><b>Repositories (reflection):</b> every {@code @Query} method of a Spring Data repository whose SQL reads or
 *       writes one of those tables must contain an account predicate; every derived query method of a repository of
 *       an account-owned aggregate must take an {@code accountId} parameter.
 *   <li><b>Hand-written SQL (source text):</b> every SQL statement in {@code src/main/java} (string literals and text
 *       blocks, adjacent {@code "a" + "b"} literals merged) that selects, updates or deletes rows of those tables, or
 *       inserts from a {@code SELECT}, must contain an account predicate.
 * </ol>
 *
 * An <b>account predicate</b> is {@code account_id =}/{@code account_id IN} on any alias, or an ACCOUNT-scope
 * {@code scope_id = :account…} comparison. Statements that legitimately have none are listed in {@link #ALLOWLIST} with
 * the reason; an entry that no longer matches anything fails the test, so the list cannot rot.
 */
class AccountFilterScanTest {

  /** Tables whose rows belong to one account (directly or through tenant/user). */
  static final Set<String> ACCOUNT_OWNED = Set.of("tenant", "app_user", "user_tenant_membership", "role",
      "role_assignment", "audit_event", "bulk_invite_job", "user_session", "user_token");

  private static final Pattern TABLE_USE = Pattern.compile(
      "(?i)\\b(?:from|join|update|into)\\s+(" + String.join("|", ACCOUNT_OWNED) + ")\\b(?!\\s*\\()");
  private static final Pattern STATEMENT = Pattern.compile("(?i)\\b(select|update|delete|insert)\\b");
  private static final Pattern ACCOUNT_PREDICATE = Pattern.compile(
      "(?i)\\baccount_id\\s*(=|in\\b)|\\bscope_id\\s*=\\s*:account\\w*");

  /** Why a statement may lack an account predicate. */
  enum Reason {
    AUTH("authentication lookup by a secret (token / refresh hash) or by the authenticated user's own id: the caller "
        + "has no account context yet, or the row is the caller's own"),
    JOB("cluster job or system flow without a caller (expiry, retention, revocation feed, bulk job worker, bootstrap)"),
    PLATFORM("platform operation (platform.account.manage, PlatformGuard): cross-account by design"),
    VERIFIED_ID("keyed by an id the same method already verified to belong to the caller's account (I10 check first, "
        + "then the write by primary/foreign key)"),
    GLOBAL_CATALOG("SYSTEM roles and the permission registry are global (account_id IS NULL)"),
    SECURITY_PRIMITIVE("security building block keyed by user, role or tenant ids its caller already resolved in the "
        + "caller's account (PermissionResolver, LastAdminService, RevocationService)"),
    FRAGMENT("WHERE-clause fragment appended to a statement whose fixed base already has the account predicate"),
    KERNEL("assignment-kernel lookup keyed by user or role id; no production caller (repository slice tests only), "
        + "not reachable from an admin API");

    final String why;

    Reason(String why) {
      this.why = why;
    }
  }

  /**
   * {@code "<source file>|<distinctive fragment of the statement>"} → reason. The fragment is matched against the
   * statement with whitespace collapsed.
   */
  static final Map<String, Reason> ALLOWLIST = new TreeMap<>(Map.ofEntries(
      Map.entry("RoleAssignmentRepository.findAllByUser|", Reason.KERNEL),
      Map.entry("RoleAssignmentRepository.findAllByRole|", Reason.KERNEL),
      Map.entry("RoleRepository.findSystemRole|", Reason.GLOBAL_CATALOG),
      Map.entry("RoleRepository.findSystemRoleNames|", Reason.GLOBAL_CATALOG),
      Map.entry("UserSessionRepository.findByRefreshHash|", Reason.AUTH),
      Map.entry("UserSessionRepository.findByPrevRefreshHash|", Reason.AUTH),
      Map.entry("UserSessionRepository.lockByRefreshHash|", Reason.AUTH),
      Map.entry("UserSessionRepository.lockByPrevRefreshHash|", Reason.AUTH),
      Map.entry("UserSessionRepository.findUnrevokedByUser|", Reason.AUTH),
      Map.entry("UserSessionRepository.lockOwned|", Reason.AUTH),
      Map.entry("UserSessionRepository.rotate|", Reason.AUTH),
      Map.entry("UserSessionRepository.rotateAndSwitch|", Reason.AUTH),
      Map.entry("UserSessionRepository.revoke|", Reason.AUTH),
      Map.entry("UserSessionRepository.revokeAllOfUser|", Reason.AUTH),
      Map.entry("UserSessionRepository.revokeOthersOfUser|", Reason.AUTH),
      Map.entry("UserTokenRepository.findByTokenHash|", Reason.AUTH),
      Map.entry("UserTokenRepository.markUsed|", Reason.AUTH),
      Map.entry("UserTokenRepository.invalidateOutstanding|", Reason.VERIFIED_ID),
      Map.entry("AccessStateQuery.java|SELECT session_version FROM app_user WHERE id = :id", Reason.AUTH),
      Map.entry("UserCredentialService.java|FROM app_user u JOIN account a ON a.id = u.account_id", Reason.AUTH),
      Map.entry("UserCredentialService.java|UPDATE app_user SET failed_logins = CASE", Reason.AUTH),
      Map.entry("UserCredentialService.java|UPDATE app_user SET failed_logins = 0, locked_until = NULL, last_login_at", Reason.AUTH),
      Map.entry("UserCredentialService.java|UPDATE app_user SET password_hash = :hash", Reason.AUTH),
      Map.entry("UserCredentialService.java|SELECT user_id FROM user_token WHERE token_hash = :hash", Reason.AUTH),
      Map.entry("UserCredentialService.java|UPDATE app_user SET status = 'ACTIVE', password_hash = :hash", Reason.AUTH),
      Map.entry("UserCredentialService.java|SELECT password_hash FROM app_user WHERE id = :id", Reason.AUTH),
      Map.entry("RevocationService.java|WITH locked AS (SELECT u.id FROM app_user u WHERE u.id IN (:ids)", Reason.SECURITY_PRIMITIVE),
      Map.entry("RevocationService.java|SELECT DISTINCT app_user AS user_id FROM user_tenant_membership WHERE tenant_id = :scope", Reason.SECURITY_PRIMITIVE),
      Map.entry("RevocationService.java|SELECT DISTINCT user_id FROM role_assignment WHERE role_id = :scope", Reason.SECURITY_PRIMITIVE),
      Map.entry("PermissionResolver.java|SELECT DISTINCT p.code FROM role_assignment ra", Reason.SECURITY_PRIMITIVE),
      Map.entry("LastAdminService.java|SELECT account_id FROM app_user WHERE id = :id", Reason.SECURITY_PRIMITIVE),
      Map.entry("LastAdminService.java|FROM role_assignment ra WHERE ra.id = :id", Reason.SECURITY_PRIMITIVE),
      Map.entry("LastAdminService.java|SELECT u.account_id FROM role_assignment ra JOIN app_user u ON u.id = ra.user_id WHERE ra.id = :id", Reason.SECURITY_PRIMITIVE),
      Map.entry("UserService.java|SELECT status FROM app_user WHERE id = :id FOR SHARE", Reason.VERIFIED_ID),
      Map.entry("UserService.java|SELECT 1 FROM user_tenant_membership WHERE app_user = :userId AND tenant_id = :tenantId AND status = 'ACTIVE' FOR SHARE", Reason.VERIFIED_ID),
      Map.entry("AssignmentQueryService.java|AND EXISTS (SELECT 1 FROM user_tenant_membership m WHERE m.app_user = ra.user_id", Reason.FRAGMENT),
      Map.entry("AssignmentQueryService.java|SELECT DISTINCT user_id FROM role_assignment WHERE role_id IN (:ids)", Reason.JOB),
      Map.entry("AssignmentExpiryService.java|SELECT id FROM role_assignment WHERE expires_at IS NOT NULL", Reason.JOB),
      Map.entry("UserQueryService.java|AND EXISTS (SELECT 1 FROM user_tenant_membership m WHERE m.app_user = u.id", Reason.FRAGMENT),
      Map.entry("UserQueryService.java|AND EXISTS (SELECT 1 FROM role_assignment ra WHERE ra.user_id = u.id", Reason.FRAGMENT),
      Map.entry("RoleAdminService.java|UPDATE role SET name = COALESCE", Reason.VERIFIED_ID),
      Map.entry("RoleAdminService.java|UPDATE role SET updated_at = now(), version = version + 1 WHERE id = :id", Reason.VERIFIED_ID),
      Map.entry("RoleAdminService.java|SELECT count(*) FROM role_assignment WHERE role_id = :id", Reason.VERIFIED_ID),
      Map.entry("RoleAdminService.java|DELETE FROM role WHERE id = :id", Reason.VERIFIED_ID),
      Map.entry("RoleAdminService.java|SELECT id FROM role WHERE id = :id FOR UPDATE", Reason.VERIFIED_ID),
      Map.entry("MembershipService.java|SELECT status FROM user_tenant_membership WHERE app_user = :u AND tenant_id = :t", Reason.VERIFIED_ID),
      Map.entry("MembershipService.java|DELETE FROM user_tenant_membership WHERE app_user = :u AND tenant_id = :t", Reason.VERIFIED_ID),
      Map.entry("MembershipService.java|DELETE FROM role_assignment WHERE user_id = :u AND scope_type = 'TENANT' AND scope_id = :t", Reason.VERIFIED_ID),
      Map.entry("MembershipService.java|SELECT 1 FROM user_tenant_membership WHERE app_user = :u AND tenant_id = :t AND status = 'ACTIVE' FOR SHARE", Reason.VERIFIED_ID),
      Map.entry("UserAdminService.java|SELECT EXISTS (SELECT 1 FROM role_assignment WHERE user_id = :id AND scope_type = 'ACCOUNT'", Reason.VERIFIED_ID),
      Map.entry("UserAdminService.java|UPDATE user_tenant_membership m SET status = 'SUSPENDED' FROM app_user u", Reason.VERIFIED_ID),
      Map.entry("UserAdminService.java|DELETE FROM user_tenant_membership m USING app_user u", Reason.VERIFIED_ID),
      Map.entry("UserAdminService.java|DELETE FROM role_assignment WHERE user_id = :id", Reason.VERIFIED_ID),
      Map.entry("BulkInviteService.java|UPDATE bulk_invite_job SET status = 'RUNNING'", Reason.JOB),
      Map.entry("BulkInviteService.java|UPDATE bulk_invite_job SET status = 'FAILED', created_count = 0", Reason.JOB),
      Map.entry("BulkInviteService.java|UPDATE bulk_invite_job SET status = :status", Reason.JOB),
      Map.entry("CredentialPurgeJob.java|DELETE FROM user_token WHERE id IN", Reason.JOB),
      Map.entry("CredentialPurgeJob.java|DELETE FROM user_session WHERE id IN", Reason.JOB),
      Map.entry("MembershipService.java|SELECT EXISTS (SELECT 1 FROM tenant t JOIN user_tenant_membership m", Reason.VERIFIED_ID),
      Map.entry("PlatformBootstrapService.java|SELECT DISTINCT u.id, u.email::text AS email, u.status, u.primary_tenant_id FROM role_assignment ra", Reason.PLATFORM)));

  // ----------------------------------------------------------------------------------------- repositories

  @Test
  void repositoryQueriesOnAccountOwnedTablesFilterByAccount() {
    List<String> problems = new ArrayList<>();
    for (Class<?> repository : repositories()) {
      for (Method method : repository.getDeclaredMethods()) {
        Query query = method.getAnnotation(Query.class);
        String where = repository.getSimpleName() + "." + method.getName();
        if (query != null) {
          String sql = collapse(query.value());
          if (touchesAccountOwnedRows(sql) && !ACCOUNT_PREDICATE.matcher(sql).find() && !allowed(where, sql)) {
            problems.add(where + ": " + sql);
          }
        } else if (!method.isDefault() && !method.isSynthetic() && ownsAccountRows(repository)
            && Arrays.stream(method.getParameters()).map(Parameter::getName).noneMatch(n -> n.startsWith("account"))
            && !allowed(where, method.getName())) {
          problems.add(where + ": derived query without an accountId parameter");
        }
      }
    }
    assertThat(problems).as("repository methods without an account filter (I10)").isEmpty();
  }

  // ------------------------------------------------------------------------------------- hand-written SQL

  @Test
  void handWrittenSqlOnAccountOwnedTablesFiltersByAccount() throws IOException {
    List<String> problems = new ArrayList<>();
    for (Statement statement : statements()) {
      if (touchesAccountOwnedRows(statement.sql()) && !ACCOUNT_PREDICATE.matcher(statement.sql()).find()
          && !allowed(statement.file(), statement.sql())) {
        problems.add(statement.file() + ":" + statement.line() + ": " + abbreviate(statement.sql()));
      }
    }
    assertThat(problems).as("SQL without an account filter (I10); fix it or allowlist it with a reason").isEmpty();
  }

  @Test
  void everyAllowlistEntryStillMatchesAStatement() throws IOException {
    Set<String> used = new TreeSet<>();
    List<Statement> all = statements();
    for (String key : ALLOWLIST.keySet()) {
      String file = key.substring(0, key.indexOf('|'));
      String fragment = collapse(key.substring(key.indexOf('|') + 1));
      boolean matches = all.stream().anyMatch(s -> s.file().equals(file) && s.sql().contains(fragment))
          || repositories().stream().anyMatch(r -> file.equals(r.getSimpleName() + "." + fragment)
              || Arrays.stream(r.getDeclaredMethods()).anyMatch(m -> file.equals(r.getSimpleName() + "." + m.getName())));
      if (matches) {
        used.add(key);
      }
    }
    assertThat(ALLOWLIST.keySet()).as("stale allowlist entries").isSubsetOf(used);
  }

  /** The scan itself: what counts as touching account rows and as an account predicate. */
  @Test
  void theScanRecognisesMissingAndPresentFilters() {
    assertThat(touchesAccountOwnedRows("SELECT * FROM app_user WHERE id = :id")).isTrue();
    assertThat(ACCOUNT_PREDICATE.matcher("SELECT * FROM app_user WHERE id = :id").find()).isFalse();
    assertThat(ACCOUNT_PREDICATE.matcher("SELECT * FROM app_user u WHERE u.account_id = :a AND u.id = :id").find())
        .isTrue();
    assertThat(touchesAccountOwnedRows("DELETE FROM role_assignment WHERE user_id = :id")).isTrue();
    assertThat(touchesAccountOwnedRows("INSERT INTO audit_event (event_id) VALUES (:id)")).isFalse();
    assertThat(touchesAccountOwnedRows("INSERT INTO role_assignment (id) SELECT id FROM app_user")).isTrue();
    assertThat(touchesAccountOwnedRows("SELECT * FROM role_permission WHERE role = :r")).isFalse();
    assertThat(touchesAccountOwnedRows("SELECT * FROM permission")).isFalse();
    assertThat(allowed("Nowhere.java", "SELECT * FROM app_user WHERE id = :id")).isFalse();
  }

  // -------------------------------------------------------------------------------------------- helpers

  record Statement(String file, int line, String sql) {}

  private static boolean touchesAccountOwnedRows(String sql) {
    if (!STATEMENT.matcher(sql).find() || !TABLE_USE.matcher(sql).find()) {
      return false;
    }
    String lower = sql.toLowerCase(Locale.ROOT).trim();
    // a plain INSERT ... VALUES writes the account it is given; only INSERT ... SELECT reads rows
    return !(lower.startsWith("insert") && !lower.contains("select"));
  }

  private static boolean allowed(String where, String sql) {
    for (String key : ALLOWLIST.keySet()) {
      String file = key.substring(0, key.indexOf('|'));
      String fragment = collapse(key.substring(key.indexOf('|') + 1));
      if (file.equals(where) && (sql.contains(fragment) || where.endsWith("." + fragment))) {
        return true;
      }
    }
    return false;
  }

  private static List<Class<?>> repositories() {
    ClassPathScanningCandidateComponentProvider scanner = new ClassPathScanningCandidateComponentProvider(false) {
      @Override
      protected boolean isCandidateComponent(org.springframework.beans.factory.annotation.AnnotatedBeanDefinition d) {
        return d.getMetadata().isInterface();
      }
    };
    scanner.addIncludeFilter(new AssignableTypeFilter(Repository.class));
    List<Class<?>> result = new ArrayList<>();
    for (BeanDefinition candidate : scanner.findCandidateComponents("com.acme.iam")) {
      try {
        result.add(Class.forName(candidate.getBeanClassName()));
      } catch (ClassNotFoundException e) {
        throw new IllegalStateException(e);
      }
    }
    assertThat(result).as("repositories found").hasSizeGreaterThan(5);
    return result;
  }

  /** Repositories of aggregates stored in an account-owned table ({@code @Table} name of the domain type). */
  private static boolean ownsAccountRows(Class<?> repository) {
    for (var type : repository.getGenericInterfaces()) {
      if (type instanceof java.lang.reflect.ParameterizedType p && p.getActualTypeArguments()[0] instanceof Class<?> c) {
        var table = c.getAnnotation(org.springframework.data.relational.core.mapping.Table.class);
        String name = table != null && !table.value().isEmpty() ? table.value() : snake(c.getSimpleName());
        return ACCOUNT_OWNED.contains(name);
      }
    }
    return false;
  }

  private static String snake(String camel) {
    return camel.replaceAll("([a-z0-9])([A-Z])", "$1_$2").toLowerCase(Locale.ROOT);
  }

  private static final Pattern TEXT_BLOCK = Pattern.compile("\"\"\"\\s*\\n(.*?)\"\"\"", Pattern.DOTALL);
  private static final Pattern STRING = Pattern.compile("\"((?:[^\"\\\\\\n]|\\\\.)*)\"");
  private static final Pattern JOIN = Pattern.compile("^\\s*\\+\\s*$");

  /** SQL candidates of every main source file: text blocks and string literals, adjacent literals merged. */
  static List<Statement> statements() throws IOException {
    Path root = Path.of("src/main/java");
    List<Statement> result = new ArrayList<>();
    try (Stream<Path> files = Files.walk(root)) {
      for (Path file : files.filter(f -> f.toString().endsWith(".java"))
          .filter(f -> !f.getFileName().toString().endsWith("Repository.java")).toList()) {
        String source = Files.readString(file);
        String name = file.getFileName().toString();
        List<int[]> spans = new ArrayList<>();
        List<String> texts = new ArrayList<>();
        Matcher blocks = TEXT_BLOCK.matcher(source);
        StringBuilder masked = new StringBuilder(source);
        while (blocks.find()) {
          spans.add(new int[] {blocks.start(), blocks.end()});
          texts.add(blocks.group(1));
          for (int i = blocks.start(); i < blocks.end(); i++) {
            if (masked.charAt(i) != '\n') {
              masked.setCharAt(i, ' ');
            }
          }
        }
        Matcher strings = STRING.matcher(masked);
        while (strings.find()) {
          if (isComment(masked, strings.start())) {
            continue;
          }
          spans.add(new int[] {strings.start(), strings.end()});
          texts.add(strings.group(1));
        }
        // order by position and merge "a" + "b"
        List<Integer> order = new ArrayList<>();
        for (int i = 0; i < spans.size(); i++) {
          order.add(i);
        }
        order.sort((a, b) -> Integer.compare(spans.get(a)[0], spans.get(b)[0]));
        StringBuilder current = null;
        int currentStart = 0;
        int previousEnd = -1;
        for (int index : order) {
          int[] span = spans.get(index);
          String between = previousEnd < 0 ? "" : source.substring(previousEnd, span[0]);
          if (current != null && JOIN.matcher(between).matches()) {
            current.append(' ').append(texts.get(index));
          } else {
            if (current != null) {
              result.add(new Statement(name, line(source, currentStart), collapse(current.toString())));
            }
            current = new StringBuilder(texts.get(index));
            currentStart = span[0];
          }
          previousEnd = span[1];
        }
        if (current != null) {
          result.add(new Statement(name, line(source, currentStart), collapse(current.toString())));
        }
      }
    }
    return result;
  }

  private static boolean isComment(CharSequence source, int position) {
    int lineStart = position;
    while (lineStart > 0 && source.charAt(lineStart - 1) != '\n') {
      lineStart--;
    }
    String prefix = source.subSequence(lineStart, position).toString().trim();
    return prefix.startsWith("//") || prefix.startsWith("*") || prefix.startsWith("/*");
  }

  private static int line(String source, int offset) {
    int line = 1;
    for (int i = 0; i < offset; i++) {
      if (source.charAt(i) == '\n') {
        line++;
      }
    }
    return line;
  }

  static String collapse(String sql) {
    return sql.replace("\\n", " ").replaceAll("\\s+", " ").trim();
  }

  private static String abbreviate(String sql) {
    return sql.length() <= 160 ? sql : sql.substring(0, 160) + "...";
  }
}
