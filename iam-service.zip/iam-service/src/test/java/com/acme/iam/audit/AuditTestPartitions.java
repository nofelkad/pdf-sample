package com.acme.iam.audit;

import com.acme.iam.common.test.PostgresTestBase;
import java.time.YearMonth;
import org.springframework.jdbc.core.simple.JdbcClient;

/**
 * Test-only DDL on {@code audit_event} partitions, as the owner role (the application role has no DDL rights). Created
 * partitions get the same append-only grants as {@code audit_ensure_partitions} would give them.
 */
final class AuditTestPartitions {

  private final JdbcClient migrator = JdbcClient.create(PostgresTestBase.migratorDataSource());

  /** Creates the partition of {@code month} if missing; returns its name. */
  String create(YearMonth month) {
    String name = AuditPartitions.nameOf(month);
    migrator.sql("CREATE TABLE IF NOT EXISTS %s PARTITION OF audit_event FOR VALUES FROM ('%s-01 00:00:00+00') TO ('%s-01 00:00:00+00')"
        .formatted(name, month, month.plusMonths(1))).update();
    migrator.sql("REVOKE UPDATE, DELETE, TRUNCATE ON %s FROM iam_app".formatted(name)).update();
    return name;
  }

  boolean exists(YearMonth month) {
    return exists(AuditPartitions.nameOf(month));
  }

  boolean exists(String name) {
    return migrator.sql("SELECT to_regclass('public.' || quote_ident(:n)) IS NOT NULL").param("n", name)
        .query(Boolean.class).single();
  }

  /** Drops a partition (attached or standalone table) if it exists. */
  void drop(YearMonth month) {
    migrator.sql("DROP TABLE IF EXISTS " + AuditPartitions.nameOf(month)).update();
  }

  JdbcClient migrator() {
    return migrator;
  }
}
