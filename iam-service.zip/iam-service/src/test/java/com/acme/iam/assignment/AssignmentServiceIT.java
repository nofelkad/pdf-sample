package com.acme.iam.assignment;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

import com.acme.iam.account.AccountKind;
import com.acme.iam.common.error.ApiException;
import com.acme.iam.common.error.BadRequestException;
import com.acme.iam.common.error.ConflictException;
import com.acme.iam.common.error.ForbiddenException;
import com.acme.iam.common.error.NotFoundException;
import com.acme.iam.common.test.Fixtures;
import com.acme.iam.common.test.IntegrationTest;
import com.acme.iam.common.test.PostgresTestBase;
import com.acme.iam.product.Product;
import com.acme.iam.role.Role;
import com.acme.iam.user.MembershipStatus;
import com.acme.iam.user.UserStatus;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.List;
import java.util.UUID;
import org.assertj.core.api.ThrowableAssert.ThrowingCallable;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.simple.JdbcClient;
import org.springframework.transaction.annotation.Transactional;

/**
 * Write-time invariants of {@link AssignmentService} (spec section 5): I1, I3, I6, I8, plus duplicate and expiry
 * handling. Each failing path asserts the exception type and machine code. Runs in a rolled-back transaction.
 *
 * <p>Baseline: customer account A with tenant T and an "entitled" product P. The grantor G is a member of T and holds
 * {@code grantorRole} (one IAM + one P permission) at ACCOUNT scope, so G holds both permissions at T and at A. The
 * target user U is a member of T. {@code role} contains exactly those two permissions.
 */
@IntegrationTest
@Transactional
class AssignmentServiceIT extends PostgresTestBase {

  @Autowired AssignmentService service;
  @Autowired PermissionResolver resolver;
  @Autowired JdbcClient jdbc;

  Fixtures fx;
  UUID account;
  UUID tenant;
  UUID product;
  UUID iamPerm;
  UUID productPerm;
  UUID role;
  UUID grantorRole;
  UUID grantor;
  UUID user;

  @BeforeEach
  void baseline() {
    fx = new Fixtures(jdbc);
    Fixtures.Scenario s = fx.scenario();
    account = s.accountId();
    tenant = s.tenantId();
    user = s.userId();
    product = fx.entitledProduct(account, tenant);
    iamPerm = fx.permission(Product.IAM_ID);
    productPerm = fx.permission(product);
    // a CUSTOM role keeps full I6 (R40 exempts only SYSTEM roles of non-IAM products, see ProductSystemRoles)
    role = fx.customRole(product, account, iamPerm, productPerm);
    // Task 9: assigning on someone's behalf needs iam.role.assign at the target scope too
    grantorRole = fx.systemRole(product, iamPerm, productPerm, fx.permission(Product.IAM_ID, "iam.role.assign"));
    grantor = fx.user(account, tenant);
    fx.assign(grantor, grantorRole, ScopeType.ACCOUNT, account);
    Fixtures.actAs(grantor, account, tenant);
  }

  @AfterEach
  void clearActor() {
    Fixtures.clearActor();
  }

  @Nested
  class HappyPath {

    @Test
    void assignsAtTenantScopeAndRecordsTheGrantor() {
      RoleAssignment saved = service.assign(new AssignCommand(user, role, ScopeType.TENANT, tenant));

      assertThat(saved.id()).isNotNull();
      assertThat(saved.grantor()).isEqualTo(grantor);
      assertThat(saved.grantedAt()).isNotNull();
      assertThat(resolver.resolve(user, tenant)).containsExactlyInAnyOrder(fx.code(iamPerm), fx.code(productPerm));
    }

    @Test
    void assignsAtAccountScopeWithAnExpiry() {
      Instant expires = Instant.now().plus(1, ChronoUnit.DAYS).truncatedTo(ChronoUnit.MICROS);
      RoleAssignment saved = service.assign(new AssignCommand(user, role, ScopeType.ACCOUNT, account, expires));
      assertThat(saved.expiresAt()).isEqualTo(expires);
      assertThat(saved.scopeType()).isEqualTo(ScopeType.ACCOUNT);
    }

    @Test
    void ownAccountCustomRoleIsAssignable() {
      UUID custom = fx.customRole(product, account, productPerm);
      assertThat(service.assign(new AssignCommand(user, custom, ScopeType.TENANT, tenant)).role()).isEqualTo(custom);
    }

    @Test
    void grantAsSystemNeedsNoActorAndSkipsI6() {
      Fixtures.clearActor();
      UUID unheld = fx.systemRole(product, fx.permission(product));
      RoleAssignment saved = service.grantAsSystem(user, unheld, ScopeType.TENANT, tenant, null, null);
      assertThat(saved.grantor()).isNull();
      assertThat(saved.role()).isEqualTo(unheld);
    }

    @Test
    void platformAdminIsAssignableInsideThePlatformAccount() {
      Fixtures.Scenario platform = fx.scenario(AccountKind.PLATFORM);
      UUID platformAdmin = fx.systemRole(Product.IAM_ID, Role.PLATFORM_ADMIN);
      RoleAssignment saved = service.grantAsSystem(platform.userId(), platformAdmin, ScopeType.ACCOUNT,
          platform.accountId(), null, null);
      assertThat(saved.role()).isEqualTo(platformAdmin);
    }
  }

  @Nested
  class Actor {

    @Test
    void systemActorMayNotUseAssign() {
      Fixtures.clearActor();
      expect(() -> service.assign(new AssignCommand(user, role, ScopeType.TENANT, tenant)),
          ForbiddenException.class, "grantor_required");
    }

    @Test
    void userActorWithoutAccountClaimIsForbidden() {
      Fixtures.actAs(grantor, null, tenant);
      expect(() -> service.assign(new AssignCommand(user, role, ScopeType.TENANT, tenant)),
          ForbiddenException.class, "forbidden");
    }

    @Test
    void userOfAnotherAccountIsNotFound() {
      Fixtures.Scenario other = fx.scenario();
      expect(() -> service.assign(new AssignCommand(other.userId(), role, ScopeType.TENANT, other.tenantId())),
          NotFoundException.class, "user_not_found");
    }
  }

  @Nested
  class I1Membership {

    @Test
    void tenantScopeWithoutMembershipIsRejected() {
      UUID other = fx.tenant(account);
      expect(() -> service.assign(new AssignCommand(user, role, ScopeType.TENANT, other)),
          ConflictException.class, "membership_required");
      expect(() -> service.grantAsSystem(user, role, ScopeType.TENANT, other, null, null),
          ConflictException.class, "membership_required");
    }

    @Test
    void tenantScopeWithSuspendedMembershipIsRejected() {
      fx.membership(user, tenant, MembershipStatus.SUSPENDED);
      expect(() -> service.assign(new AssignCommand(user, role, ScopeType.TENANT, tenant)),
          ConflictException.class, "membership_required");
      expect(() -> service.grantAsSystem(user, role, ScopeType.TENANT, tenant, null, null),
          ConflictException.class, "membership_required");
    }

    @Test
    void tenantOfAnotherAccountIsRejected() {
      UUID foreignTenant = fx.tenant(fx.account());
      fx.membership(user, foreignTenant, MembershipStatus.ACTIVE); // corrupt data must not help
      expect(() -> service.assign(new AssignCommand(user, role, ScopeType.TENANT, foreignTenant)),
          BadRequestException.class, "scope_not_in_account");
      expect(() -> service.grantAsSystem(user, role, ScopeType.TENANT, foreignTenant, null, null),
          BadRequestException.class, "scope_not_in_account");
    }

    @Test
    void unknownTenantIsRejected() {
      expect(() -> service.grantAsSystem(user, role, ScopeType.TENANT, UUID.randomUUID(), null, null),
          BadRequestException.class, "scope_not_in_account");
    }

    @Test
    void accountScopeMustBeTheUsersAccount() {
      UUID otherAccount = fx.account();
      expect(() -> service.assign(new AssignCommand(user, role, ScopeType.ACCOUNT, otherAccount)),
          BadRequestException.class, "scope_not_in_account");
      expect(() -> service.grantAsSystem(user, role, ScopeType.ACCOUNT, otherAccount, null, null),
          BadRequestException.class, "scope_not_in_account");
    }
  }

  @Nested
  class I3CustomRoleAccount {

    @Test
    void customRoleOfAnotherAccountIsRejected() {
      UUID foreign = fx.customRole(product, fx.account(), productPerm);
      // assign: indistinguishable from an unknown role id (no cross-account enumeration)
      expect(() -> service.assign(new AssignCommand(user, foreign, ScopeType.TENANT, tenant)),
          NotFoundException.class, "role_not_found");
      expect(() -> service.assign(new AssignCommand(user, UUID.randomUUID(), ScopeType.TENANT, tenant)),
          NotFoundException.class, "role_not_found");
      // grantAsSystem: explicit invariant code
      expect(() -> service.grantAsSystem(user, foreign, ScopeType.ACCOUNT, account, null, null),
          BadRequestException.class, "role_not_in_account");
    }
  }

  @Nested
  class TenantMustBeActive {

    @Test
    void suspendedTenantIsRejectedInBothPaths() {
      fx.tenantStatus(tenant, com.acme.iam.tenant.TenantStatus.SUSPENDED);
      expect(() -> service.assign(new AssignCommand(user, role, ScopeType.TENANT, tenant)),
          ConflictException.class, "tenant_not_active");
      expect(() -> service.grantAsSystem(user, role, ScopeType.TENANT, tenant, null, null),
          ConflictException.class, "tenant_not_active");
    }

    @Test
    void archivedTenantIsRejectedInBothPaths() {
      fx.tenantStatus(tenant, com.acme.iam.tenant.TenantStatus.ARCHIVED);
      expect(() -> service.assign(new AssignCommand(user, role, ScopeType.TENANT, tenant)),
          ConflictException.class, "tenant_not_active");
      expect(() -> service.grantAsSystem(user, role, ScopeType.TENANT, tenant, null, null),
          ConflictException.class, "tenant_not_active");
    }
  }

  @Nested
  class I6GrantorHoldsPermissions {

    @Test
    void grantorMissingOnePermissionAtTheTenantIsRejected() {
      UUID extra = fx.permission(product);
      UUID bigger = fx.customRole(product, account, iamPerm, productPerm, extra);

      assertThatThrownBy(() -> service.assign(new AssignCommand(user, bigger, ScopeType.TENANT, tenant)))
          .isInstanceOfSatisfying(ForbiddenException.class, e -> {
            assertThat(e.code()).isEqualTo("grantor_lacks_permissions");
            assertThat(e.properties()).containsEntry("missingPermissions", List.of(fx.code(extra)));
          });
    }

    @Test
    void permissionsHeldInAnotherTenantDoNotCount() {
      UUID other = fx.tenant(account);
      fx.enableProduct(other, product, true);
      UUID tenantGrantor = fx.user(account, other);
      fx.assign(tenantGrantor, grantorRole, ScopeType.TENANT, other);
      Fixtures.actAs(tenantGrantor, account, other);

      // final review M4: the TenantGuard scope rule (iam.role.assign in the active tenant or at ACCOUNT scope) now
      // runs first on every path, so the grant is refused before I6 is even evaluated
      assertThatThrownBy(() -> service.assign(new AssignCommand(user, role, ScopeType.TENANT, tenant)))
          .isInstanceOfSatisfying(com.acme.iam.common.security.CodedAccessDeniedException.class,
              e -> assertThat(e.code()).isEqualTo("scope_exceeded"));
    }

    @Test
    void tenantScopeHoldingIsNotEnoughForAccountScope() {
      UUID tenantGrantor = fx.user(account, tenant);
      fx.assign(tenantGrantor, grantorRole, ScopeType.TENANT, tenant);
      Fixtures.actAs(tenantGrantor, account, tenant);

      assertThat(service.assign(new AssignCommand(user, role, ScopeType.TENANT, tenant))).isNotNull();
      expect(() -> service.assign(new AssignCommand(user, role, ScopeType.ACCOUNT, account)),
          ForbiddenException.class, "grantor_lacks_permissions");
    }

    @Test
    void expiredGrantorAssignmentDoesNotCount() {
      UUID lapsed = fx.user(account, tenant);
      fx.assign(lapsed, grantorRole, ScopeType.ACCOUNT, account, Instant.now().minusSeconds(60));
      Fixtures.actAs(lapsed, account, tenant);

      expect(() -> service.assign(new AssignCommand(user, role, ScopeType.TENANT, tenant)),
          ForbiddenException.class, "grantor_lacks_permissions");
      expect(() -> service.assign(new AssignCommand(user, role, ScopeType.ACCOUNT, account)),
          ForbiddenException.class, "grantor_lacks_permissions");
    }

    @Test
    void productNotEntitledInTheTenantCannotBeDelegated() {
      fx.enableProduct(tenant, product, false);
      expect(() -> service.assign(new AssignCommand(user, role, ScopeType.TENANT, tenant)),
          ForbiddenException.class, "grantor_lacks_permissions");
    }

    /** R11: an ACCOUNT-scope grantor needs no membership in the target tenant. */
    @Test
    void accountScopeGrantorWithoutMembershipCanAssignInTheTenant() {
      UUID other = fx.tenant(account);
      fx.enableProduct(other, product, true);
      fx.membership(user, other, MembershipStatus.ACTIVE); // the target user is a member, the grantor is not

      RoleAssignment saved = service.assign(new AssignCommand(user, role, ScopeType.TENANT, other));
      assertThat(saved.scopeId()).isEqualTo(other);
      assertThat(saved.grantor()).isEqualTo(grantor);
    }

    /** R11: the ACCOUNT-scope part is still filtered by the tenant's entitlement. */
    @Test
    void accountScopeGrantorWithoutMembershipCannotDelegateAProductDisabledInTheTenant() {
      UUID other = fx.tenant(account);
      fx.enableProduct(other, product, false);
      fx.membership(user, other, MembershipStatus.ACTIVE);

      assertThatThrownBy(() -> service.assign(new AssignCommand(user, role, ScopeType.TENANT, other)))
          .isInstanceOfSatisfying(ForbiddenException.class, e -> {
            assertThat(e.code()).isEqualTo("grantor_lacks_permissions");
            assertThat(e.properties()).containsEntry("missingPermissions", List.of(fx.code(productPerm)));
          });
    }

    @Test
    void tenantScopeGrantWithoutActiveMembershipDoesNotCount() {
      UUID memberGrantor = fx.user(account, tenant);
      fx.assign(memberGrantor, grantorRole, ScopeType.TENANT, tenant);
      fx.membership(memberGrantor, tenant, MembershipStatus.SUSPENDED);
      Fixtures.actAs(memberGrantor, account, tenant);

      expect(() -> service.assign(new AssignCommand(user, role, ScopeType.TENANT, tenant)),
          ForbiddenException.class, "grantor_lacks_permissions");
    }

    @Test
    void deprecatedPermissionsAreNotRequired() {
      UUID retired = fx.permission(product);
      fx.deprecate(retired);
      UUID withRetired = fx.systemRole(product, iamPerm, productPerm, retired);
      assertThat(service.assign(new AssignCommand(user, withRetired, ScopeType.TENANT, tenant))).isNotNull();
    }
  }

  @Nested
  class I8PlatformAdmin {

    @Test
    void platformAdminIsRejectedForCustomerUsers() {
      UUID platformAdmin = fx.systemRole(Product.IAM_ID, Role.PLATFORM_ADMIN);
      expect(() -> service.assign(new AssignCommand(user, platformAdmin, ScopeType.ACCOUNT, account)),
          ForbiddenException.class, "platform_role_restricted");
      expect(() -> service.grantAsSystem(user, platformAdmin, ScopeType.ACCOUNT, account, null, null),
          ForbiddenException.class, "platform_role_restricted");
    }
  }

  @Nested
  class Validation {

    @Test
    void duplicateAssignmentIsAConflict() {
      service.assign(new AssignCommand(user, role, ScopeType.TENANT, tenant));
      expect(() -> service.assign(new AssignCommand(user, role, ScopeType.TENANT, tenant)),
          ConflictException.class, "assignment_exists");
    }

    @Test
    void expiryInThePastIsRejected() {
      expect(() -> service.assign(new AssignCommand(user, role, ScopeType.TENANT, tenant,
              Instant.now().minusSeconds(1))),
          BadRequestException.class, "invalid_expiry");
    }

    @Test
    void unknownUserAndRoleAreNotFound() {
      expect(() -> service.assign(new AssignCommand(UUID.randomUUID(), role, ScopeType.TENANT, tenant)),
          NotFoundException.class, "user_not_found");
      expect(() -> service.assign(new AssignCommand(user, UUID.randomUUID(), ScopeType.TENANT, tenant)),
          NotFoundException.class, "role_not_found");
    }
  }

  /**
   * Task 9 (security review): every path that assigns on a user's behalf (the assignment API, invite-with-roles) needs
   * {@code iam.role.assign} held at the target scope, not only the role's permissions (I6).
   */
  @Nested
  class RoleAssignPermission {

    @Test
    void holdingTheRolesPermissionsIsNotEnough() {
      UUID holder = fx.user(account, tenant);
      fx.assign(holder, fx.systemRole(product, iamPerm, productPerm), ScopeType.ACCOUNT, account);
      Fixtures.actAs(holder, account, tenant);

      assertThatThrownBy(() -> service.assign(new AssignCommand(user, role, ScopeType.TENANT, tenant)))
          .isInstanceOfSatisfying(ForbiddenException.class, e -> {
            assertThat(e.code()).isEqualTo("grantor_lacks_permissions");
            assertThat(e.properties().get("missingPermissions")).isEqualTo(List.of("iam.role.assign"));
          });
    }

    @Test
    void anEmptyRoleStillNeedsRoleAssignAtTheScope() {
      UUID holder = fx.user(account, tenant);
      fx.assign(holder, fx.systemRole(Product.IAM_ID, fx.permission(Product.IAM_ID, "iam.role.assign")),
          ScopeType.TENANT, tenant);
      Fixtures.actAs(holder, account, tenant);
      UUID empty = fx.customRole(product, account);

      assertThat(service.assign(new AssignCommand(user, empty, ScopeType.TENANT, tenant)).role()).isEqualTo(empty);
      expect(() -> service.assign(new AssignCommand(user, empty, ScopeType.ACCOUNT, account)),
          ForbiddenException.class, "grantor_lacks_permissions");
    }
  }

  /**
   * Ruling R40: a grantor holding {@code iam.role.assign} at the target scope may assign SYSTEM roles of non-IAM products
   * without holding their permissions, if the product is entitled for the account (and enabled in the tenant for TENANT
   * scope). IAM SYSTEM roles and CUSTOM roles keep full I6.
   */
  @Nested
  class ProductSystemRoles {

    UUID assigner;
    UUID productRole;

    @BeforeEach
    void assignerWithOnlyRoleAssign() {
      assigner = fx.user(account, tenant);
      productRole = fx.systemRole(product, fx.permission(product), fx.permission(product));
    }

    private void holdRoleAssign(ScopeType scope) {
      fx.assign(assigner, fx.customRole(Product.IAM_ID, account, fx.permission(Product.IAM_ID, "iam.role.assign")),
          scope, scope == ScopeType.ACCOUNT ? account : tenant);
      Fixtures.actAs(assigner, account, tenant);
    }

    @Test
    void atAccountScopeWithRoleAssignAtAccountScope() {
      holdRoleAssign(ScopeType.ACCOUNT);
      assertThat(service.assign(new AssignCommand(user, productRole, ScopeType.ACCOUNT, account)).role())
          .isEqualTo(productRole);
    }

    @Test
    void atTenantScopeWithRoleAssignInThatTenant() {
      holdRoleAssign(ScopeType.TENANT);
      assertThat(service.assign(new AssignCommand(user, productRole, ScopeType.TENANT, tenant)).role())
          .isEqualTo(productRole);
      expect(() -> service.assign(new AssignCommand(user, fx.systemRole(product, fx.permission(product)),
          ScopeType.ACCOUNT, account)), ForbiddenException.class, "grantor_lacks_permissions");
    }

    @Test
    void aProductTheAccountIsNotEntitledToIsRefused() {
      holdRoleAssign(ScopeType.ACCOUNT);
      UUID unsubscribed = fx.product();
      UUID role = fx.systemRole(unsubscribed, fx.permission(unsubscribed));
      expect(() -> service.assign(new AssignCommand(user, role, ScopeType.ACCOUNT, account)),
          ForbiddenException.class, "product_not_entitled");
    }

    @Test
    void aProductDisabledInTheTenantIsRefusedAtTenantScope() {
      holdRoleAssign(ScopeType.ACCOUNT);
      fx.enableProduct(tenant, product, false);
      expect(() -> service.assign(new AssignCommand(user, productRole, ScopeType.TENANT, tenant)),
          ForbiddenException.class, "product_not_entitled");
      assertThat(service.assign(new AssignCommand(user, productRole, ScopeType.ACCOUNT, account)).role())
          .as("account scope only needs the subscription").isEqualTo(productRole);
    }

    @Test
    void iamSystemRolesStillNeedI6() {
      holdRoleAssign(ScopeType.ACCOUNT);
      UUID iamRole = fx.systemRole(Product.IAM_ID, fx.permission(Product.IAM_ID));
      expect(() -> service.assign(new AssignCommand(user, iamRole, ScopeType.ACCOUNT, account)),
          ForbiddenException.class, "grantor_lacks_permissions");
    }

    @Test
    void customRolesWithProductPermissionsStillNeedI6() {
      holdRoleAssign(ScopeType.ACCOUNT);
      UUID custom = fx.customRole(product, account, fx.permission(product));
      expect(() -> service.assign(new AssignCommand(user, custom, ScopeType.ACCOUNT, account)),
          ForbiddenException.class, "grantor_lacks_permissions");
    }

    @Test
    void permissionsOfAnotherProductInAProductSystemRoleStillNeedI6() {
      holdRoleAssign(ScopeType.ACCOUNT);
      UUID mixed = fx.systemRole(product, fx.permission(product), fx.permission(Product.IAM_ID));
      expect(() -> service.assign(new AssignCommand(user, mixed, ScopeType.ACCOUNT, account)),
          ForbiddenException.class, "grantor_lacks_permissions");
    }

    @Test
    void withoutRoleAssignAtTheScopeNothingIsExempt() {
      fx.assign(assigner, fx.customRole(Product.IAM_ID, account, fx.permission(Product.IAM_ID, "iam.role.assign")),
          ScopeType.TENANT, tenant);
      Fixtures.actAs(assigner, account, tenant);
      expect(() -> service.assign(new AssignCommand(user, productRole, ScopeType.ACCOUNT, account)),
          ForbiddenException.class, "grantor_lacks_permissions");
    }
  }

  /** Task 9 (deferred fix E4): only ACTIVE and INVITED users can receive roles. */
  @Nested
  class TargetStatus {

    @Test
    void disabledUserIsRejected() {
      UUID disabled = fx.user(account, tenant, UserStatus.DISABLED);
      expect(() -> service.assign(new AssignCommand(disabled, role, ScopeType.TENANT, tenant)),
          ConflictException.class, "user_not_active");
      expect(() -> service.grantAsSystem(disabled, role, ScopeType.ACCOUNT, account, null, null),
          ConflictException.class, "user_not_active");
    }

    @Test
    void deprovisionedUserIsRejected() {
      UUID gone = fx.user(account, tenant, UserStatus.DEPROVISIONED);
      expect(() -> service.assign(new AssignCommand(gone, role, ScopeType.ACCOUNT, account)),
          ConflictException.class, "user_not_active");
      expect(() -> service.grantAsSystem(gone, role, ScopeType.TENANT, tenant, null, null),
          ConflictException.class, "user_not_active");
    }

    @Test
    void invitedUserStaysAssignable() {
      UUID invited = fx.user(account, tenant, UserStatus.INVITED);
      assertThat(service.assign(new AssignCommand(invited, role, ScopeType.TENANT, tenant)).user()).isEqualTo(invited);
      assertThat(service.grantAsSystem(invited, role, ScopeType.ACCOUNT, account, null, null).user())
          .isEqualTo(invited);
    }
  }

  private static void expect(ThrowingCallable call, Class<? extends ApiException> type, String code) {
    assertThatThrownBy(call).isInstanceOfSatisfying(type, e -> assertThat(e.code()).isEqualTo(code));
  }
}
