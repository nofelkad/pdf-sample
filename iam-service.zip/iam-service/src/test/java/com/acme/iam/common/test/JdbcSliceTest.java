package com.acme.iam.common.test;

import com.acme.iam.common.jdbc.JdbcConfig;
import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Inherited;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import org.springframework.boot.autoconfigure.ImportAutoConfiguration;
import org.springframework.boot.autoconfigure.jackson.JacksonAutoConfiguration;
import org.springframework.boot.test.autoconfigure.data.jdbc.DataJdbcTest;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.context.annotation.Import;
import org.springframework.test.context.ActiveProfiles;

/**
 * Spring Data JDBC slice ({@code @DataJdbcTest}: repositories, Flyway, JdbcClient/JdbcTemplate, transactional and
 * rolled back per test) against the shared Testcontainers database, with the project's {@link JdbcConfig} (converters,
 * auditing, {@code AuditContextTransactionManager}). Use on classes extending {@link PostgresTestBase}:
 *
 * <pre>{@code
 * @JdbcSliceTest
 * class RoleRepositoryTest extends PostgresTestBase { ... }
 * }</pre>
 */
@Target(ElementType.TYPE)
@Retention(RetentionPolicy.RUNTIME)
@Documented
@Inherited
@DataJdbcTest
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.NONE)
@ImportAutoConfiguration(JacksonAutoConfiguration.class)
@Import(JdbcConfig.class)
@ActiveProfiles("test")
public @interface JdbcSliceTest {}
