package com.acme.iam.auth;

/**
 * Breached-password lookup used by {@link PasswordService} only when the account's policy enables
 * {@code breachedCheck}. The production implementation is {@link HibpBreachedPasswordChecker} (k-anonymity range API);
 * tests replace the bean with a stub.
 */
@FunctionalInterface
public interface BreachedPasswordChecker {

  /** {@code true} when the password appears in a known breach corpus. Implementations must never send it in full. */
  boolean isBreached(String rawPassword);
}
