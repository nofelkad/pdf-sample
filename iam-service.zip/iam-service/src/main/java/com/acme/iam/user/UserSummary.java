package com.acme.iam.user;

import java.time.Instant;
import java.util.UUID;
import org.springframework.lang.Nullable;

/** Row of the user list read model ({@link UserQueryService}). */
public record UserSummary(
    UUID id,
    String email,
    @Nullable String displayName,
    UserStatus status,
    UUID primaryTenantId,
    @Nullable Instant lastLoginAt,
    Instant createdAt) {}
