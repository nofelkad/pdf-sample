package com.acme.iam.common.security;

import net.javacrumbs.shedlock.spring.annotation.SchedulerLock;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

/**
 * P1-4.2: runs {@link SigningKeyService#runLifecycle()} on one instance at a time (ShedLock
 * {@value #LOCK_NAME}) every {@code iam.security.key-rotation-check-interval} (default 1 h). For a manual rotation
 * call {@link SigningKeyService#rotateNow()} (runbook).
 */
@Component
public class KeyRotationJob {

  public static final String LOCK_NAME = "signing-key-rotation";
  private static final Logger log = LoggerFactory.getLogger(KeyRotationJob.class);

  private final SigningKeyService keys;

  public KeyRotationJob(SigningKeyService keys) {
    this.keys = keys;
  }

  @Scheduled(fixedDelayString = "${iam.security.key-rotation-check-interval:PT1H}",
      initialDelayString = "${iam.security.key-rotation-check-interval:PT1H}")
  @SchedulerLock(name = LOCK_NAME, lockAtMostFor = "PT10M")
  public void run() {
    try {
      keys.runLifecycle();
    } catch (RuntimeException e) {
      log.error("Signing key lifecycle step failed", e);
    }
  }
}
