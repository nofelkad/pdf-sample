package com.acme.iam.observability;

import com.acme.iam.auth.RevocationPoller;
import java.time.Clock;
import java.time.Duration;
import java.time.Instant;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.actuate.health.Health;
import org.springframework.boot.actuate.health.HealthIndicator;
import org.springframework.stereotype.Component;

/**
 * Contributor {@code revocationFreshness} of the {@code readiness} health group: UP while the revocation poller has
 * read the feed successfully within {@code iam.observability.revocation-stale-after} (default 30 s, fifteen poll
 * intervals), otherwise {@link ReadinessStatus#NOT_READY} (also before the first poll). An instance that cannot see
 * revocations must not take traffic.
 *
 * <p>The status is the custom {@code NOT_READY}, which Spring Boot's default status order does not rank, so it never
 * changes the aggregate {@code /actuator/health} nor {@code liveness}; only the {@code readiness} group maps it to
 * 503 (see {@code management.endpoint.health.group.readiness} in application.yml).
 */
@Component
public class RevocationFreshnessHealthIndicator implements HealthIndicator {

  private final RevocationPoller revocation;
  private final Clock clock;
  private final Duration staleAfter;

  /**
   * Task 9 fix round 1: the state comes from {@link RevocationPoller#lastSuccessfulPoll()} (a <em>complete</em> poll:
   * startup cursor and every page), so a failed startup poll keeps the instance NOT_READY instead of failing open.
   */
  public RevocationFreshnessHealthIndicator(RevocationPoller revocation, Clock clock,
      @Value("${iam.observability.revocation-stale-after:PT30S}") Duration staleAfter) {
    this.revocation = revocation;
    this.clock = clock;
    this.staleAfter = staleAfter;
  }

  @Override
  public Health health() {
    Instant last = revocation.lastSuccessfulPoll();
    if (last == null) {
      return Health.status(ReadinessStatus.NOT_READY).withDetail("reason", "no successful poll yet").build();
    }
    Duration age = Duration.between(last, clock.instant());
    boolean stale = age.compareTo(staleAfter) >= 0;
    return Health.status(stale ? ReadinessStatus.NOT_READY : org.springframework.boot.actuate.health.Status.UP)
        .withDetail("lastSuccessfulPollSecondsAgo", age.toSeconds())
        .withDetail("staleAfterSeconds", staleAfter.toSeconds())
        .build();
  }
}
