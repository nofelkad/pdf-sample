package com.acme.iam.tenant;

import com.acme.iam.common.paging.KeysetPage;
import com.acme.iam.common.security.CodedAccessDeniedException;
import com.acme.iam.common.security.CurrentUser;
import com.acme.iam.common.security.TenantGuard;
import com.acme.iam.tenant.TenantAdminService.ProductSwitch;
import com.acme.iam.tenant.TenantAdminService.TenantSummary;
import com.acme.iam.tenant.TenantAdminService.TenantView;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import org.springframework.lang.Nullable;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/**
 * Tenant API (P1-6.3). Tenants are created by platform operators ({@code POST /api/platform/accounts/{id}/tenants},
 * ruling R46); here an account manages its existing tenants. Tenants are account-level objects: every endpoint needs {@code iam.tenant.manage} held through an
 * unexpired ACCOUNT-scope assignment ({@link TenantGuard#hasAccountScope}; otherwise 403
 * {@code account_scope_required}) and works on the caller's account ({@code acc}) only. Endpoints naming a tenant also
 * call {@link TenantGuard#requireActive} (unknown or foreign tenants: 404 {@code tenant_not_found}).
 */
@RestController
@RequestMapping(TenantController.PATH)
public class TenantController {

  public static final String PATH = "/api/tenants";
  private static final String PERMISSION = "iam.tenant.manage";

  public record ProductSwitchRequest(@NotBlank String code, boolean enabled) {
    ProductSwitch toSwitch() {
      return new ProductSwitch(code, enabled);
    }
  }

  public record UpdateTenantRequest(@Nullable @Size(min = 1, max = 200) String name,
                                    @Nullable Map<String, Object> settings) {}

  public record SetProductsRequest(@NotNull List<@Valid ProductSwitchRequest> products) {}

  private final TenantAdminService service;
  private final TenantGuard tenantGuard;
  private final CurrentUser currentUser;

  public TenantController(TenantAdminService service, TenantGuard tenantGuard, CurrentUser currentUser) {
    this.service = service;
    this.tenantGuard = tenantGuard;
    this.currentUser = currentUser;
  }

  @GetMapping
  @PreAuthorize("hasAuthority('iam.tenant.manage')")
  public KeysetPage<TenantSummary> list(@RequestParam(required = false) TenantStatus status,
                                        @RequestParam(required = false) String cursor,
                                        @RequestParam(required = false) Integer limit) {
    requireAccountScope();
    return service.list(currentUser.accountId(), status, cursor, limit);
  }

  @GetMapping("/{id}")
  @PreAuthorize("hasAuthority('iam.tenant.manage')")
  public TenantView get(@PathVariable UUID id) {
    requireAccountScope();
    tenantGuard.requireActive(id, PERMISSION);
    return service.get(currentUser.accountId(), id);
  }

  @PatchMapping("/{id}")
  @PreAuthorize("hasAuthority('iam.tenant.manage')")
  public TenantView update(@PathVariable UUID id, @Valid @RequestBody UpdateTenantRequest request) {
    requireAccountScope();
    tenantGuard.requireActive(id, PERMISSION);
    return service.update(currentUser.accountId(), id, request.name(), request.settings());
  }

  @PostMapping("/{id}/suspend")
  @PreAuthorize("hasAuthority('iam.tenant.manage')")
  public TenantView suspend(@PathVariable UUID id) {
    requireAccountScope();
    tenantGuard.requireActive(id, PERMISSION);
    return service.suspend(currentUser.accountId(), id);
  }

  @PostMapping("/{id}/reactivate")
  @PreAuthorize("hasAuthority('iam.tenant.manage')")
  public TenantView reactivate(@PathVariable UUID id) {
    requireAccountScope();
    tenantGuard.requireActive(id, PERMISSION);
    return service.reactivate(currentUser.accountId(), id);
  }

  @PostMapping("/{id}/archive")
  @PreAuthorize("hasAuthority('iam.tenant.manage')")
  public TenantView archive(@PathVariable UUID id) {
    requireAccountScope();
    tenantGuard.requireActive(id, PERMISSION);
    return service.archive(currentUser.accountId(), id);
  }

  /** Replaces the tenant's product switches (I5). */
  @PutMapping("/{id}/products")
  @PreAuthorize("hasAuthority('iam.tenant.manage')")
  public TenantView setProducts(@PathVariable UUID id, @Valid @RequestBody SetProductsRequest request) {
    requireAccountScope();
    tenantGuard.requireActive(id, PERMISSION);
    return service.setProducts(currentUser.accountId(), id,
        request.products().stream().map(ProductSwitchRequest::toSwitch).toList());
  }

  private void requireAccountScope() {
    if (!tenantGuard.hasAccountScope(PERMISSION)) {
      throw new CodedAccessDeniedException(TenantGuard.ACCOUNT_SCOPE_REQUIRED,
          "Managing tenants requires " + PERMISSION + " at account scope", Map.of("requiredAuthority", PERMISSION));
    }
  }
}
