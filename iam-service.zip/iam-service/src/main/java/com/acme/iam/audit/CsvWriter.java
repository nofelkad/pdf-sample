package com.acme.iam.audit;

import java.io.IOException;
import java.io.Writer;
import org.springframework.lang.Nullable;

/**
 * RFC 4180 CSV cells with CSV-injection protection (OWASP): a cell that starts with {@code = + - @} (or a tab or
 * carriage return, which spreadsheets also treat as formula starters) is prefixed with {@code '} so that Excel, Sheets
 * and LibreOffice show it as text instead of evaluating it. The prefix changes the value the recipient sees; that is
 * the accepted trade-off. Cells containing a comma, double quote, CR or LF are quoted, with embedded quotes doubled;
 * lines end with CRLF.
 */
final class CsvWriter {

  private CsvWriter() {}

  /** Writes one record. {@code null} cells are written empty. */
  static void writeRecord(Writer out, @Nullable String... cells) throws IOException {
    for (int i = 0; i < cells.length; i++) {
      if (i > 0) {
        out.write(',');
      }
      writeCell(out, cells[i]);
    }
    out.write("\r\n");
  }

  static void writeCell(Writer out, @Nullable String value) throws IOException {
    if (value == null || value.isEmpty()) {
      return;
    }
    String cell = isFormulaStarter(value.charAt(0)) ? "'" + value : value;
    if (needsQuotes(cell)) {
      out.write('"');
      out.write(cell.replace("\"", "\"\""));
      out.write('"');
    } else {
      out.write(cell);
    }
  }

  static boolean isFormulaStarter(char c) {
    return c == '=' || c == '+' || c == '-' || c == '@' || c == '\t' || c == '\r';
  }

  private static boolean needsQuotes(String cell) {
    for (int i = 0; i < cell.length(); i++) {
      char c = cell.charAt(i);
      if (c == ',' || c == '"' || c == '\n' || c == '\r') {
        return true;
      }
    }
    return false;
  }
}
