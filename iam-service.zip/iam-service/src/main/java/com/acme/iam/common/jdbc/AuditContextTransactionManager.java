package com.acme.iam.common.jdbc;

import com.acme.iam.common.RequestActor;
import com.acme.iam.common.security.AppCaller;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Objects;
import javax.sql.DataSource;
import org.springframework.jdbc.support.JdbcTransactionManager;
import org.springframework.transaction.TransactionDefinition;

/**
 * Primary transaction manager. At the start of every transaction it copies {@link RequestActor#current()} into
 * transaction-local Postgres settings {@code app.user_id/account_id/tenant_id/request_id/session_id}, which the
 * {@code iam_audit()} trigger reads. {@code set_config(..., true)} scopes them to the transaction, so they reset at
 * commit/rollback and never leak between pooled connections. Absent values are written as {@code ''}.
 *
 * <p>Ruling R9: when the caller is an application token ({@code typ=app}), {@code app.source} is set to
 * {@code app:<clientId>} and {@code app.client_id} to the client id (both {@code ''} otherwise); the trigger (V6) uses
 * them for {@code audit_event.source} and {@code metadata.client_id}.
 */
public class AuditContextTransactionManager extends JdbcTransactionManager {

  private static final String SET_CONTEXT_SQL =
      "SELECT set_config('app.user_id', ?, true), set_config('app.account_id', ?, true), "
          + "set_config('app.tenant_id', ?, true), set_config('app.request_id', ?, true), "
          + "set_config('app.session_id', ?, true), set_config('app.source', ?, true), "
          + "set_config('app.client_id', ?, true)";

  public AuditContextTransactionManager(DataSource dataSource) {
    super(dataSource);
  }

  @Override
  protected void prepareTransactionalConnection(Connection con, TransactionDefinition definition)
      throws SQLException {
    super.prepareTransactionalConnection(con, definition);
    RequestActor actor = RequestActor.current();
    String clientId = AppCaller.currentClientId().orElse("");
    try (PreparedStatement ps = con.prepareStatement(SET_CONTEXT_SQL)) {
      ps.setString(1, Objects.toString(actor.userId(), ""));
      ps.setString(2, Objects.toString(actor.accountId(), ""));
      ps.setString(3, Objects.toString(actor.tenantId(), ""));
      ps.setString(4, Objects.toString(actor.requestId(), ""));
      ps.setString(5, Objects.toString(actor.sessionId(), ""));
      ps.setString(6, clientId.isEmpty() ? "" : AppCaller.source(clientId));
      ps.setString(7, clientId);
      ps.execute();
    }
  }
}
