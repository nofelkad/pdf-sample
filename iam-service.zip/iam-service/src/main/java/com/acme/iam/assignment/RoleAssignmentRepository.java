package com.acme.iam.assignment;

import java.util.List;
import java.util.UUID;
import org.springframework.data.jdbc.repository.query.Query;
import org.springframework.data.repository.ListCrudRepository;

/** Persistence of {@link RoleAssignment}. Private to the {@code assignment} feature; use {@link AssignmentService}. */
public interface RoleAssignmentRepository extends ListCrudRepository<RoleAssignment, UUID> {

  @Query("SELECT * FROM role_assignment WHERE user_id = :userId ORDER BY granted_at, id")
  List<RoleAssignment> findAllByUser(UUID userId);

  @Query("SELECT * FROM role_assignment WHERE role_id = :roleId ORDER BY granted_at, id")
  List<RoleAssignment> findAllByRole(UUID roleId);

  /** The user's unexpired assignments, only when the user belongs to {@code accountId} (I10). */
  @Query("""
      SELECT ra.* FROM role_assignment ra JOIN app_user u ON u.id = ra.user_id
      WHERE ra.user_id = :userId AND u.account_id = :accountId
        AND (ra.expires_at IS NULL OR ra.expires_at > now())
      ORDER BY ra.granted_at, ra.id""")
  List<RoleAssignment> findUnexpiredByUserInAccount(UUID userId, UUID accountId);
}
