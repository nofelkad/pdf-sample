package com.acme.iam.product;

import com.fasterxml.jackson.core.JsonLocation;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.exc.UnrecognizedPropertyException;
import com.fasterxml.jackson.dataformat.yaml.YAMLFactory;
import java.io.IOException;
import java.io.InputStream;

/**
 * Reads a {@link Manifest} from YAML ({@code iam-manifest.yaml}) or JSON (the HTTP upload). Both use the same strict
 * binding: unknown fields and malformed documents raise {@link InvalidManifestException}. Semantic checks are
 * {@link ManifestValidator}'s job.
 */
public final class ManifestParser {

  private static final ObjectMapper JSON = new ObjectMapper()
      .enable(DeserializationFeature.FAIL_ON_TRAILING_TOKENS);
  private static final ObjectMapper YAML = new ObjectMapper(new YAMLFactory());

  private ManifestParser() {}

  public static Manifest parseYaml(InputStream in) {
    try {
      return require(YAML.readValue(in, Manifest.class));
    } catch (JsonProcessingException e) {
      throw malformed(e);
    } catch (IOException e) {
      throw new InvalidManifestException("The manifest cannot be read: " + e.getClass().getSimpleName());
    }
  }

  public static Manifest parseJson(String json) {
    try {
      return require(JSON.readValue(json, Manifest.class));
    } catch (JsonProcessingException e) {
      throw malformed(e);
    }
  }

  private static Manifest require(Manifest manifest) {
    if (manifest == null) {
      throw new InvalidManifestException("The manifest is empty");
    }
    return manifest;
  }

  private static InvalidManifestException malformed(JsonProcessingException e) {
    JsonLocation location = e.getLocation();
    String where = location == null ? "" : " (line " + location.getLineNr() + ", column " + location.getColumnNr() + ")";
    String problem = e instanceof UnrecognizedPropertyException unknown
        ? "unknown field '" + unknown.getPropertyName() + "'"
        : e.getOriginalMessage();
    return new InvalidManifestException("The manifest is not well-formed: " + problem + where);
  }
}
