package com.acme.iam.auth;

import io.github.bucket4j.distributed.ExpirationAfterWriteStrategy;
import io.github.bucket4j.distributed.jdbc.PrimaryKeyMapper;
import io.github.bucket4j.postgresql.Bucket4jPostgreSQL;
import io.github.bucket4j.postgresql.PostgreSQLSelectForUpdateBasedProxyManager;
import java.time.Duration;
import javax.sql.DataSource;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * Wiring of the authentication feature: {@link AuthProperties}, the Bucket4j PostgreSQL proxy manager over the
 * {@code bucket} table (V1; {@code id VARCHAR} key, {@code state BYTEA}, {@code expires_at BIGINT} for
 * expire-after-write) and the HIBP breached-password checker.
 */
@Configuration(proxyBeanMethods = false)
@EnableConfigurationProperties(AuthProperties.class)
public class AuthConfig {

  @Bean
  PostgreSQLSelectForUpdateBasedProxyManager<String> authRateLimitBuckets(DataSource dataSource,
                                                                          AuthProperties properties) {
    Duration keepAfterRefill = properties.rateLimit().window();
    return Bucket4jPostgreSQL.selectForUpdateBasedBuilder(dataSource)
        .primaryKeyMapper(PrimaryKeyMapper.STRING)
        .table("bucket")
        .idColumn("id")
        .stateColumn("state")
        .expiresAtColumn("expires_at")
        .expirationAfterWrite(ExpirationAfterWriteStrategy.basedOnTimeForRefillingBucketUpToMax(keepAfterRefill))
        .build();
  }

  @Bean
  BreachedPasswordChecker hibpBreachedPasswordChecker(AuthProperties properties) {
    return new HibpBreachedPasswordChecker(properties.breachedPassword().rangeUrl(),
        properties.breachedPassword().timeout());
  }
}
