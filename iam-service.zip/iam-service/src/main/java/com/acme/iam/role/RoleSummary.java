package com.acme.iam.role;

import java.time.Instant;
import java.util.UUID;
import org.springframework.lang.Nullable;

/**
 * Row of the role list read model ({@link RoleQueryService}).
 *
 * @param accountId {@code null} for SYSTEM roles
 * @param permissionCount number of permissions in the role
 * @param assignmentCount unexpired assignments of the role inside the caller's account (ACCOUNT scope = the account,
 *     TENANT scope = one of its tenants)
 */
public record RoleSummary(
    UUID id,
    UUID productId,
    String productCode,
    String name,
    @Nullable String description,
    RoleType type,
    @Nullable UUID accountId,
    int permissionCount,
    long assignmentCount,
    Instant createdAt) {}
