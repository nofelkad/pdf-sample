package com.acme.iam.auth;

import org.springframework.lang.Nullable;

/**
 * Who is calling, as far as the network tells: the client IP (already resolved through trusted proxies and normalised
 * with {@code AuditWriter.normalizeIp}) and the {@code User-Agent} (truncated). Used for rate-limit keys, sessions and
 * {@code auth.*} audit events.
 */
public record ClientInfo(@Nullable String ip, @Nullable String userAgent) {

  public static final int MAX_USER_AGENT = 512;
  public static final ClientInfo UNKNOWN = new ClientInfo(null, null);

  public ClientInfo {
    if (userAgent != null && userAgent.length() > MAX_USER_AGENT) {
      userAgent = userAgent.substring(0, MAX_USER_AGENT);
    }
  }
}
