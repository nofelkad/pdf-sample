package com.acme.iam.observability;

import io.micrometer.core.instrument.MeterRegistry;
import io.micrometer.core.instrument.Tag;
import java.util.List;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

/**
 * Latency of {@code PermissionResolver.resolve} and {@code explain} (P1-11.5; target p95 under 15 ms for a user with
 * 20 assignments), one timer per operation under {@value MetricNames#PERMISSION_RESOLVE_DURATION}.
 */
@Aspect
@Component
@Order(Ordered.HIGHEST_PRECEDENCE + 10)
public class ResolverMetrics {

  private final OutcomeTimer resolve;
  private final OutcomeTimer explain;

  public ResolverMetrics(MeterRegistry registry) {
    this.resolve = new OutcomeTimer(registry, MetricNames.PERMISSION_RESOLVE_DURATION,
        "PermissionResolver latency", List.of(Tag.of("op", "resolve")));
    this.explain = new OutcomeTimer(registry, MetricNames.PERMISSION_RESOLVE_DURATION,
        "PermissionResolver latency", List.of(Tag.of("op", "explain")));
  }

  @Around("execution(* com.acme.iam.assignment.PermissionResolver.resolve(..))")
  public Object timeResolve(ProceedingJoinPoint joinPoint) throws Throwable {
    return resolve.time(joinPoint);
  }

  @Around("execution(* com.acme.iam.assignment.PermissionResolver.explain(..))")
  public Object timeExplain(ProceedingJoinPoint joinPoint) throws Throwable {
    return explain.time(joinPoint);
  }
}
