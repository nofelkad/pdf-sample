package com.acme.iam.user;

import java.time.Instant;
import java.util.Objects;
import java.util.UUID;
import org.springframework.data.relational.core.mapping.Table;

/**
 * A user's membership in a tenant ({@code user_tenant_membership}), owned by {@link AppUser}. The back-reference column
 * {@code app_user} is managed by Spring Data JDBC. {@code addedAt} must be set by the caller because Spring Data JDBC
 * writes every column (the SQL default never applies).
 */
@Table("user_tenant_membership")
public record Membership(UUID tenantId, MembershipStatus status, Instant addedAt) {

  public Membership {
    Objects.requireNonNull(tenantId, "tenantId");
    Objects.requireNonNull(status, "status");
    Objects.requireNonNull(addedAt, "addedAt");
  }

  public static Membership active(UUID tenantId, Instant addedAt) {
    return new Membership(tenantId, MembershipStatus.ACTIVE, addedAt);
  }

  public boolean isActive() {
    return status == MembershipStatus.ACTIVE;
  }
}
