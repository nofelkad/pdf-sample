package com.acme.iam.tenant;

import java.util.List;
import java.util.Optional;
import java.util.UUID;
import org.springframework.data.jdbc.repository.query.Query;
import org.springframework.data.repository.ListCrudRepository;

/** Persistence of the {@link Tenant} aggregate. Private to the {@code tenant} feature; use {@link TenantService}. */
public interface TenantRepository extends ListCrudRepository<Tenant, UUID> {

  @Query("SELECT * FROM tenant WHERE account_id = :accountId ORDER BY created_at, id")
  List<Tenant> findAllByAccount(UUID accountId);

  @Query("SELECT * FROM tenant WHERE id = :id AND account_id = :accountId")
  Optional<Tenant> findByIdInAccount(UUID id, UUID accountId);
}
