package com.acme.iam.product;

import com.acme.iam.assignment.AssignmentQueryService;
import com.acme.iam.audit.AuditEvent;
import com.acme.iam.audit.AuditWriter;
import com.acme.iam.auth.RevocationService;
import com.acme.iam.common.jdbc.RetryOnDeadlock;
import com.acme.iam.common.security.AppCaller;
import com.acme.iam.product.Manifest.ManifestPermission;
import com.acme.iam.product.Manifest.ManifestRole;
import com.acme.iam.role.Role;
import com.acme.iam.role.RoleService;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import java.util.function.Function;
import java.util.stream.Collectors;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.core.simple.JdbcClient;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * The permission registry (P1-7.2): applies a product {@link Manifest} idempotently, in one transaction.
 *
 * <p><b>What apply does</b>
 * <ol>
 *   <li>Validates the manifest ({@link ManifestValidator}) and takes a transaction-scoped advisory lock per product
 *       ({@code pg_advisory_xact_lock(hashtext('iam:manifest'), hashtext(code))}), so concurrent applies of the same
 *       product (two instances starting together, an upload racing a startup load) serialise: the second one waits,
 *       then finds nothing left to change.
 *   <li>Upserts the product (a new product is named after its code unless the manifest has a name).
 *   <li>Upserts the permissions, writing only rows that differ; a permission missing from the manifest becomes
 *       {@code deprecated}, one that reappears is un-deprecated.
 *   <li>Rebuilds the product's SYSTEM roles: missing roles are created, an existing role's {@code role_permission}
 *       rows are diffed to exactly the expanded set (targeted INSERT/DELETE). Wildcards expand across <em>all</em>
 *       products' current, non-deprecated permissions; because the validator confines every entry to the product's own
 *       code prefix this still yields only the product's own permissions.
 *   <li>Revokes holders (see below), writes one summary audit event {@code iam.manifest.apply} when something changed.
 * </ol>
 * Nothing is written when nothing differs, so a second apply of the same manifest leaves no audit rows (the audit
 * triggers fire per written row).
 *
 * <p><b>Revocation (one {@code revoke*} per transaction):</b> the holders of every SYSTEM role whose permission set
 * changed (grown or shrunk), and of every role, SYSTEM or CUSTOM, that contains a permission deprecated by this
 * apply, are collected into <em>one</em> {@link RevocationService#revokeUsers} call as the transaction's last write,
 * instead of one {@code revokeRoleHolders} per role (a second {@code revoke*} would fail the deadlock guard). Holders
 * are read into memory (user ids only), which is fine for the 50k-user case. Newly created roles have no holders.
 *
 * <p><b>Removed system roles</b> (in the database, not in the manifest) are left in place and a warning is logged:
 * the spec only deprecates permissions, and deleting a role would orphan its assignments.
 */
@Service
public class RegistryService {

  public static final String AUDIT_ACTION = "iam.manifest.apply";
  public static final String REVOKE_REASON = "manifest.applied";

  private static final Logger log = LoggerFactory.getLogger(RegistryService.class);

  private final ProductRepository products;
  private final PermissionRepository permissions;
  private final RoleService roles;
  private final AssignmentQueryService assignments;
  private final RevocationService revocations;
  private final AuditWriter audit;
  private final JdbcClient jdbc;

  public RegistryService(ProductRepository products, PermissionRepository permissions, RoleService roles,
      AssignmentQueryService assignments, RevocationService revocations, AuditWriter audit, JdbcClient jdbc) {
    this.products = products;
    this.permissions = permissions;
    this.roles = roles;
    this.assignments = assignments;
    this.revocations = revocations;
    this.audit = audit;
    this.jdbc = jdbc;
  }

  /**
   * Applies {@code manifest}; see the class description.
   *
   * @throws InvalidManifestException {@code invalid_manifest} (400) when the manifest breaks a rule, or a permission
   *     code is already registered by another product
   */
  @RetryOnDeadlock
  @Transactional
  public ApplyResult apply(Manifest manifest) {
    ManifestValidator.requireValid(manifest);
    String code = manifest.product();
    jdbc.sql("SELECT 1 FROM (SELECT pg_advisory_xact_lock(hashtext('iam:manifest'), hashtext(CAST(:code AS text)))) l")
        .param("code", code).query(Integer.class).single();

    boolean productChanged = false;
    Optional<Product> existing = products.findByCode(code);
    Product product;
    if (existing.isEmpty()) {
      product = products.save(Product.create(code, manifest.name() != null ? manifest.name() : code));
      productChanged = true;
    } else {
      product = existing.get();
      if (manifest.name() != null && !manifest.name().equals(product.name())) {
        product = products.save(product.withName(manifest.name()));
        productChanged = true;
      }
    }

    requireNoForeignCodes(product, manifest);
    PermissionChanges permissionChanges = upsertPermissions(product, manifest);

    Map<String, UUID> ownIds = permissions.findAllByProduct(product.id()).stream()
        .filter(p -> !p.deprecated()).collect(Collectors.toMap(Permission::code, Permission::id));
    Set<UUID> changedRoles = new HashSet<>();
    int rolesChanged = rebuildSystemRoles(product, manifest, ownIds, changedRoles);

    boolean changed = productChanged || permissionChanges.added() + permissionChanges.updated()
        + permissionChanges.deprecated().size() + rolesChanged > 0;
    ApplyResult result = new ApplyResult(code, changed, permissionChanges.added(), permissionChanges.updated(),
        permissionChanges.deprecated().size(), rolesChanged);
    if (changed) {
      Set<UUID> affectedRoles = new HashSet<>(changedRoles);
      affectedRoles.addAll(roles.rolesContainingAny(permissionChanges.deprecated()));
      Set<UUID> holders = assignments.holdersOfRoles(affectedRoles);
      writeAudit(product, result, holders.size());
      if (!holders.isEmpty()) {
        revocations.revokeUsers(holders, REVOKE_REASON); // the single revoke*, last write
      }
      log.info("Manifest for {} applied: {}", code, result);
    }
    return result;
  }

  // ---------------------------------------------------------------------------------------------------------------

  private record PermissionChanges(int added, int updated, Set<UUID> deprecated) {}

  /** A permission code is globally unique; a manifest may not take one that another product registered. */
  private void requireNoForeignCodes(Product product, Manifest manifest) {
    List<String> codes = manifest.permissions().stream().map(ManifestPermission::code).toList();
    if (codes.isEmpty()) {
      return;
    }
    List<String> clashes = jdbc.sql("""
            SELECT p.code || ' (product ' || pr.code || ')' FROM permission p JOIN product pr ON pr.id = p.product_id
            WHERE p.code IN (:codes) AND p.product_id <> :product ORDER BY p.code""")
        .param("codes", codes).param("product", product.id()).query(String.class).list();
    if (!clashes.isEmpty()) {
      throw new InvalidManifestException(clashes.stream()
          .map(c -> "permission code " + c + " is already registered by another product").toList());
    }
  }

  private PermissionChanges upsertPermissions(Product product, Manifest manifest) {
    Map<String, Permission> current = permissions.findAllByProduct(product.id()).stream()
        .collect(Collectors.toMap(Permission::code, Function.identity()));
    List<Permission> toInsert = new ArrayList<>();
    List<Permission> toUpdate = new ArrayList<>();
    Set<String> declared = new HashSet<>();
    int updated = 0;
    for (ManifestPermission wanted : manifest.permissions()) {
      declared.add(wanted.code());
      PermissionKind kind = PermissionKind.valueOf(wanted.kind());
      Permission existing = current.get(wanted.code());
      if (existing == null) {
        toInsert.add(Permission.create(product.id(), wanted.code(), kind, wanted.description())
            .withFlags(wanted.sensitive(), wanted.auditRead(), false));
      } else if (existing.kind() != kind || !existing.description().equals(wanted.description())
          || existing.sensitive() != wanted.sensitive() || existing.auditRead() != wanted.auditRead()
          || existing.deprecated()) {
        toUpdate.add(existing.withDefinition(kind, wanted.description(), wanted.sensitive(), wanted.auditRead(), false));
        updated++;
      }
    }
    Set<UUID> deprecated = new LinkedHashSet<>();
    for (Permission existing : current.values()) {
      if (!declared.contains(existing.code()) && !existing.deprecated()) {
        toUpdate.add(existing.withFlags(existing.sensitive(), existing.auditRead(), true));
        deprecated.add(existing.id());
      }
    }
    if (!toInsert.isEmpty()) {
      permissions.saveAll(toInsert);
    }
    if (!toUpdate.isEmpty()) {
      permissions.saveAll(toUpdate);
    }
    return new PermissionChanges(toInsert.size(), updated, deprecated);
  }

  private int rebuildSystemRoles(Product product, Manifest manifest, Map<String, UUID> ownIds, Set<UUID> changedRoles) {
    int changed = 0;
    Set<String> declaredNames = new HashSet<>();
    for (ManifestRole wanted : manifest.systemRoles()) {
      declaredNames.add(wanted.name().toLowerCase(Locale.ROOT));
      Set<UUID> desired = expand(wanted, ownIds);
      Optional<Role> existing = roles.findSystemRole(product.id(), wanted.name());
      if (existing.isEmpty()) {
        roles.createSystemRole(product.id(), wanted.name(), null, desired);
        changed++;
      } else if (!roles.replacePermissions(existing.get().id(), desired).isEmpty()) {
        changedRoles.add(existing.get().id());
        changed++;
      }
    }
    for (String name : roles.systemRoleNames(product.id())) {
      if (!declaredNames.contains(name.toLowerCase(Locale.ROOT))) {
        log.warn("System role '{}' of product {} is no longer in its manifest; it is left in place", name,
            product.code());
      }
    }
    return changed;
  }

  /**
   * The permission ids of a role: exact codes plus wildcard matches (across all products' non-deprecated permissions),
   * minus the {@code exclude} entries.
   */
  private Set<UUID> expand(ManifestRole role, Map<String, UUID> ownIds) {
    Map<String, UUID> included = new LinkedHashMap<>();
    for (String entry : role.permissions()) {
      if (ManifestValidator.isWildcard(entry)) {
        jdbc.sql("SELECT id, code FROM permission WHERE NOT deprecated AND starts_with(code, CAST(:prefix AS text))")
            .param("prefix", ManifestValidator.wildcardPrefix(entry))
            .query((rs, i) -> Map.entry(rs.getString("code"), rs.getObject("id", UUID.class)))
            .list().forEach(e -> included.put(e.getKey(), e.getValue()));
      } else if (ownIds.containsKey(entry)) {
        included.put(entry, ownIds.get(entry));
      }
    }
    for (String entry : role.exclude()) {
      if (ManifestValidator.isWildcard(entry)) {
        String prefix = ManifestValidator.wildcardPrefix(entry);
        included.keySet().removeIf(c -> c.startsWith(prefix));
      } else {
        included.remove(entry);
      }
    }
    return new HashSet<>(included.values());
  }

  private void writeAudit(Product product, ApplyResult result, int holdersRevoked) {
    Map<String, Object> metadata = new HashMap<>();
    metadata.put("product", result.product());
    metadata.put("permissions_added", result.permissionsAdded());
    metadata.put("permissions_updated", result.permissionsUpdated());
    metadata.put("permissions_deprecated", result.permissionsDeprecated());
    metadata.put("roles_changed", result.rolesChanged());
    metadata.put("holders_revoked", holdersRevoked);
    AuditEvent.Builder event = AuditEvent.forCurrentActor(AUDIT_ACTION).target("product", product.id().toString());
    AppCaller.currentClientId().ifPresent(clientId -> {
      event.source(AppCaller.source(clientId));
      metadata.put("client_id", clientId);
    });
    audit.write(event.metadata(metadata).build());
  }
}
