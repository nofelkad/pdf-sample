package com.acme.iam.auth;

import com.acme.iam.user.IssuedToken;
import com.acme.iam.user.NotificationPort;
import com.acme.iam.user.TokenPurpose;
import com.acme.iam.user.UserTokenService;
import io.micrometer.core.instrument.Counter;
import io.micrometer.core.instrument.MeterRegistry;
import io.micrometer.core.instrument.simple.SimpleMeterRegistry;
import java.time.Duration;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.Future;
import java.util.concurrent.RejectedExecutionException;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import java.util.concurrent.atomic.AtomicInteger;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.support.TransactionSynchronization;
import org.springframework.transaction.support.TransactionSynchronizationManager;

/**
 * Issues and mails password-reset links off the request thread (Ruling R31), so a {@code forgot} request for a known
 * email does the same work on the request path as one for an unknown email (no timing oracle).
 *
 * <p>Work is queued after the caller's transaction commits (immediately when there is none) on a private, bounded
 * executor ({@code iam.auth.mail-executor.threads}, default 1, so tasks run in submission order and a later reset
 * request always invalidates an earlier one; queue {@code iam.auth.mail-executor.queue-capacity}, default 1000). A
 * full queue drops the task — counted in {@value #DROPPED_METRIC} and logged at WARN (the user can ask again) — rather
 * than running it on the request thread. Each task, in its own transaction, invalidates the user's outstanding reset
 * tokens and issues a new one ({@code iam.auth.password-reset-ttl}), then sends the mail.
 *
 * <p>Every send runs on a separate small pool and is bounded by {@code iam.auth.mail-executor.send-timeout}
 * (default 30 s): a hung mail server cannot pin the worker; the send is cancelled (interrupted) and the worker moves
 * on. Failures and timeouts are logged without any token.
 *
 * <p>The executors are deliberately not Spring {@code Executor} beans, so Boot's {@code applicationTaskExecutor}
 * stays in place for everything else.
 */
@Component
public class PasswordResetMailer implements DisposableBean {

  /** Counter of reset requests dropped because the queue was full. */
  public static final String DROPPED_METRIC = "iam.auth.password_reset.dropped";
  /** Counter of sends cancelled because they hit {@code send-timeout} (P1-11.5). */
  public static final String SEND_TIMEOUTS_METRIC = "iam.auth.password_reset.send_timeouts";

  private static final Logger log = LoggerFactory.getLogger(PasswordResetMailer.class);

  /** One reset to send. */
  public record Target(UUID userId, String email) {}

  private final UserTokenService userTokens;
  private final NotificationPort notifications;
  private final AuthTransactions tx;
  private final Duration resetTtl;
  private final Duration sendTimeout;
  private final Counter dropped;
  private final Counter sendTimeouts;
  private final ThreadPoolExecutor worker;
  private final ThreadPoolExecutor sender;

  @Autowired
  public PasswordResetMailer(UserTokenService userTokens, NotificationPort notifications, AuthTransactions tx,
                             AuthProperties properties, ObjectProvider<MeterRegistry> meterRegistry) {
    this(userTokens, notifications, tx, properties.passwordResetTtl(), properties.mailExecutor(),
        meterRegistry.getIfAvailable(SimpleMeterRegistry::new));
  }

  PasswordResetMailer(UserTokenService userTokens, NotificationPort notifications, AuthTransactions tx,
                      Duration resetTtl, AuthProperties.MailExecutor config, MeterRegistry meterRegistry) {
    this.userTokens = userTokens;
    this.notifications = notifications;
    this.tx = tx;
    this.resetTtl = resetTtl;
    this.sendTimeout = config.sendTimeout();
    this.dropped = Counter.builder(DROPPED_METRIC)
        .description("Password reset requests dropped because the mail queue was full")
        .register(meterRegistry);
    this.sendTimeouts = Counter.builder(SEND_TIMEOUTS_METRIC)
        .description("Password reset mails whose send hit the send timeout").register(meterRegistry);
    this.worker = pool("auth-mail-", config.threads(), config.queueCapacity(), (runnable, pool) -> {
      dropped.increment();
      log.warn("Password reset mail queue is full; dropping a reset request");
    });
    // a timed-out send keeps its thread until the interrupt is honoured; twice the workers leaves headroom
    this.sender = pool("auth-mail-send-", config.threads() * 2, config.queueCapacity(),
        new ThreadPoolExecutor.AbortPolicy());
  }

  /** Queues the resets; after commit when called inside a transaction. Returns immediately. */
  public void dispatch(List<Target> targets) {
    if (targets.isEmpty()) {
      return;
    }
    List<Target> copy = List.copyOf(targets);
    if (TransactionSynchronizationManager.isSynchronizationActive()) {
      TransactionSynchronizationManager.registerSynchronization(new TransactionSynchronization() {
        @Override
        public void afterCommit() {
          submit(copy);
        }
      });
    } else {
      submit(copy);
    }
  }

  private void submit(List<Target> targets) {
    worker.execute(() -> targets.forEach(this::send));
  }

  private void send(Target target) {
    Future<?> sending = null;
    try {
      IssuedToken token = tx.write(() -> {
        userTokens.invalidateOutstanding(target.userId(), TokenPurpose.PASSWORD_RESET);
        return userTokens.issue(target.userId(), TokenPurpose.PASSWORD_RESET, resetTtl, null);
      });
      sending = sender.submit(() -> notifications.sendPasswordReset(target.email(), token.rawToken()));
      sending.get(sendTimeout.toMillis(), TimeUnit.MILLISECONDS);
    } catch (TimeoutException e) {
      sending.cancel(true);
      sendTimeouts.increment();
      log.warn("Sending a password reset mail timed out after {}", sendTimeout);
    } catch (InterruptedException e) {
      Thread.currentThread().interrupt();
    } catch (RejectedExecutionException e) {
      dropped.increment();
      log.warn("Password reset mail sender is saturated; dropping a reset request");
    } catch (Exception e) {
      Throwable cause = e.getCause() == null ? e : e.getCause();
      log.warn("Sending a password reset mail failed ({})", cause.getClass().getSimpleName());
    }
  }

  private static ThreadPoolExecutor pool(String prefix, int threads, int queueCapacity,
                                         java.util.concurrent.RejectedExecutionHandler onFull) {
    AtomicInteger count = new AtomicInteger();
    return new ThreadPoolExecutor(threads, threads, 60, TimeUnit.SECONDS, new ArrayBlockingQueue<>(queueCapacity),
        runnable -> {
          Thread thread = new Thread(runnable, prefix + count.incrementAndGet());
          thread.setDaemon(true);
          return thread;
        },
        onFull);
  }

  @Override
  public void destroy() throws InterruptedException {
    worker.shutdown();
    worker.awaitTermination(10, TimeUnit.SECONDS);
    sender.shutdownNow();
  }
}
