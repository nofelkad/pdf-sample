package com.acme.iam.appclient;

import com.acme.iam.appclient.AppClient.AppClientStatus;
import com.acme.iam.audit.AuditEvent;
import com.acme.iam.audit.AuditWriter;
import com.acme.iam.common.error.ConflictException;
import com.acme.iam.common.error.NotFoundException;
import com.acme.iam.common.security.AppCaller;
import com.acme.iam.common.security.IssuedJwt;
import com.acme.iam.common.security.JwtIssuer;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.time.Instant;
import java.util.Base64;
import java.util.List;
import java.util.Locale;
import java.util.Optional;
import java.util.UUID;
import java.util.regex.Pattern;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.lang.Nullable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * Application clients (P1-12.1): registration by platform operators and the client-credentials exchange behind
 * {@code POST /internal/token}.
 *
 * <p><b>Secret storage:</b> the secret is 32 bytes from {@link SecureRandom}, base64url without padding, returned once
 * at registration. Only {@code SHA-256(secret)} is stored. A slow password hash (Argon2) protects low-entropy,
 * human-chosen secrets against offline guessing; a 256-bit random secret cannot be guessed whatever the hash, so a
 * fast hash loses nothing and keeps the token endpoint cheap (it is called by every application every few minutes).
 * Hashes are compared in constant time, and an unknown client id still costs one hash + comparison.
 */
@Service
public class AppClientService {

  public static final String ACTION_TOKEN = "auth.app_client.token";
  public static final String ACTION_FAILED = "auth.app_client.failed";
  public static final String ACTION_SECRET_ROTATED = "iam.app_client.secret_rotated";
  static final String TARGET_TYPE = "app_client";
  private static final int SECRET_BYTES = 32;
  private static final byte[] DUMMY_HASH = new byte[32];
  /** Same rule as {@code app_client.client_id} (V5) and the registration API. */
  static final Pattern CLIENT_ID = Pattern.compile("[a-z0-9][a-z0-9._-]{2,63}");
  private static final int MAX_INVALID_ID_LENGTH = 64;

  /** View of a client without its secret hash. */
  public record AppClientView(UUID id, String clientId, String productCode, AppClientStatus status, Instant createdAt) {
    static AppClientView of(AppClient c) {
      return new AppClientView(c.id(), c.clientId(), c.productCode(), c.status(), c.createdAt());
    }
  }

  /** Registration result: the only time {@code clientSecret} is ever returned. */
  public record RegisteredAppClient(UUID id, String clientId, String productCode, AppClientStatus status,
                                    Instant createdAt, String clientSecret) {
    @Override
    public String toString() {
      return "RegisteredAppClient[id=" + id + ", clientId=" + clientId + "]";
    }
  }

  /** Keyset page; {@code next} is the {@code after} value for the following page, {@code null} on the last one. */
  public record AppClientPage(List<AppClientView> items, @Nullable UUID next) {}

  private final AppClientRepository repository;
  private final JwtIssuer jwtIssuer;
  private final AuditWriter auditWriter;
  private final SecureRandom random = new SecureRandom();

  public AppClientService(AppClientRepository repository, JwtIssuer jwtIssuer, AuditWriter auditWriter) {
    this.repository = repository;
    this.jwtIssuer = jwtIssuer;
    this.auditWriter = auditWriter;
  }

  @Transactional
  public RegisteredAppClient register(String clientId, String productCode) {
    if (repository.existsByClientId(clientId)) {
      throw exists(clientId);
    }
    String secret = newSecret();
    AppClient saved;
    try {
      saved = repository.save(AppClient.register(clientId, productCode, sha256(secret)));
    } catch (DuplicateKeyException e) {
      throw exists(clientId);
    }
    return new RegisteredAppClient(saved.id(), saved.clientId(), saved.productCode(), saved.status(),
        saved.createdAt(), secret);
  }

  @Transactional(readOnly = true)
  public AppClientPage list(@Nullable UUID after, int limit) {
    List<AppClient> rows = repository.findPage(after == null ? new UUID(0, 0) : after, limit + 1);
    List<AppClientView> items = rows.stream().limit(limit).map(AppClientView::of).toList();
    return new AppClientPage(items, rows.size() > limit ? items.get(items.size() - 1).id() : null);
  }

  /** Removes the client; tokens it already holds stay valid until they expire ({@code app-token-ttl}, 10 min). */
  @Transactional
  public void delete(UUID id) {
    if (!repository.existsById(id)) {
      throw new NotFoundException("app_client_not_found", "Application client not found");
    }
    repository.deleteById(id);
  }

  /**
   * Ruling R39: a new secret replaces the stored hash in one update, so the old secret stops working immediately (app
   * tokens already issued stay valid until they expire). The new secret is returned once; the rotation is audited as
   * {@value #ACTION_SECRET_ROTATED} (never with the secret) besides the row trigger's {@code iam.app_client.update}.
   */
  @Transactional
  public RegisteredAppClient rotateSecret(UUID id) {
    AppClient client = repository.findById(id)
        .orElseThrow(() -> new NotFoundException("app_client_not_found", "Application client not found"));
    String secret = newSecret();
    AppClient saved = repository.save(client.withSecretHash(sha256(secret)));
    auditWriter.write(AuditEvent.forCurrentActor(ACTION_SECRET_ROTATED).target(TARGET_TYPE, saved.clientId())
        .metadata("client_id", saved.clientId()).metadata("product_code", saved.productCode()).build());
    return new RegisteredAppClient(saved.id(), saved.clientId(), saved.productCode(), saved.status(),
        saved.createdAt(), secret);
  }

  /** ACTIVE → DISABLED; a no-op (no row change, no audit) when already disabled. */
  @Transactional
  public AppClientView disable(UUID id) {
    AppClient client = repository.findById(id)
        .orElseThrow(() -> new NotFoundException("app_client_not_found", "Application client not found"));
    if (client.status() == AppClientStatus.DISABLED) {
      return AppClientView.of(client);
    }
    return AppClientView.of(repository.save(client.withStatus(AppClientStatus.DISABLED)));
  }

  /**
   * Client-credentials exchange: authenticates {@code Authorization: Basic base64(clientId:secret)} and issues an
   * application token. Every outcome is audited ({@value #ACTION_TOKEN} / {@value #ACTION_FAILED}).
   *
   * @throws InvalidClientException missing/malformed credentials, unknown or disabled client, wrong secret
   */
  public IssuedJwt issueToken(@Nullable String authorization, @Nullable String ip, @Nullable String userAgent) {
    Optional<String[]> credentials = parseBasic(authorization);
    if (credentials.isEmpty()) {
      fail(null, authorization == null ? "missing_credentials" : "malformed_credentials", ip, userAgent);
    }
    String clientId = credentials.get()[0];
    byte[] presented = sha256(credentials.get()[1]);
    Optional<AppClient> client = repository.findByClientId(clientId);
    boolean secretMatches = MessageDigest.isEqual(presented, client.map(AppClient::secretHash).orElse(DUMMY_HASH));
    if (client.isEmpty()) {
      fail(clientId, "unknown_client", ip, userAgent);
    }
    if (!secretMatches) {
      fail(clientId, "bad_secret", ip, userAgent);
    }
    if (client.get().status() != AppClientStatus.ACTIVE) {
      fail(clientId, "disabled", ip, userAgent);
    }
    IssuedJwt token = jwtIssuer.issueAppToken(clientId, client.get().productCode());
    auditWriter.write(AuditEvent.builder(ACTION_TOKEN)
        .actorType(AuditEvent.ActorType.SYSTEM)
        .source(AppCaller.source(clientId))
        .actorIp(ip)
        .userAgent(userAgent)
        .target(TARGET_TYPE, clientId)
        .metadata("client_id", clientId)
        .metadata("product_code", client.get().productCode())
        .metadata("jti", token.jti())
        .build());
    return token;
  }

  // ---------------------------------------------------------------------------------------------------------------

  private void fail(@Nullable String clientId, String reason, @Nullable String ip, @Nullable String userAgent) {
    AuditEvent.Builder event = AuditEvent.builder(ACTION_FAILED)
        .anonymous()
        .outcome(AuditEvent.Outcome.FAILURE)
        .actorIp(ip)
        .userAgent(userAgent)
        .metadata("reason", reason);
    if (clientId != null && CLIENT_ID.matcher(clientId).matches()) {
      event.target(TARGET_TYPE, clientId).metadata("client_id", clientId);
    } else if (clientId != null) {
      // attacker-controlled: never a target, only a sanitised, truncated and clearly marked value
      event.metadata("client_id_invalid", sanitizeInvalidClientId(clientId));
    }
    auditWriter.write(event.build());
    throw new InvalidClientException();
  }

  /**
   * An attacker-supplied client id made safe to store: control characters ({@code \p{Cntrl}}) and Unicode format
   * characters ({@code \p{Cf}}: bidi overrides, zero-width characters, BOM) removed, at most 64 chars.
   */
  static String sanitizeInvalidClientId(String clientId) {
    String printable = clientId.replaceAll("[\\p{Cntrl}\\p{Cf}]", "");
    return printable.length() > MAX_INVALID_ID_LENGTH ? printable.substring(0, MAX_INVALID_ID_LENGTH) : printable;
  }

  /** {@code [clientId, secret]} from an RFC 6749 section 2.3.1 Basic header (form-urlencoded parts). */
  static Optional<String[]> parseBasic(@Nullable String authorization) {
    if (authorization == null || !authorization.regionMatches(true, 0, "Basic ", 0, 6)) {
      return Optional.empty();
    }
    try {
      String decoded = new String(Base64.getDecoder().decode(authorization.substring(6).trim()), StandardCharsets.UTF_8);
      int colon = decoded.indexOf(':');
      if (colon <= 0 || colon == decoded.length() - 1) {
        return Optional.empty();
      }
      String clientId = URLDecoder.decode(decoded.substring(0, colon), StandardCharsets.UTF_8);
      String secret = URLDecoder.decode(decoded.substring(colon + 1), StandardCharsets.UTF_8);
      return Optional.of(new String[] {clientId.toLowerCase(Locale.ROOT), secret});
    } catch (IllegalArgumentException e) {
      return Optional.empty();
    }
  }

  private String newSecret() {
    byte[] raw = new byte[SECRET_BYTES];
    random.nextBytes(raw);
    return Base64.getUrlEncoder().withoutPadding().encodeToString(raw);
  }

  private static byte[] sha256(String secret) {
    try {
      return MessageDigest.getInstance("SHA-256").digest(secret.getBytes(StandardCharsets.UTF_8));
    } catch (NoSuchAlgorithmException e) {
      throw new IllegalStateException(e);
    }
  }

  private static ConflictException exists(String clientId) {
    return new ConflictException("app_client_exists", "Application client '" + clientId + "' already exists");
  }
}
