package com.acme.iam.assignment;

import java.time.OffsetDateTime;
import java.util.List;
import java.util.Set;
import java.util.UUID;
import org.springframework.jdbc.core.simple.JdbcClient;
import org.springframework.stereotype.Service;

/**
 * Effective permissions (spec section 5, P1-7.4).
 *
 * <p>{@link #resolve} and {@link #explain} share one {@code FROM ... WHERE} fragment ({@link #TENANT_GRANTS}, the spec
 * query verbatim), so the permissions put into a JWT always equal the set of permissions {@code explain} reports.
 * {@link #resolveGrantorAtTenant} reuses the same fragments ({@link #TENANT_JOINS}, {@link #TENANT_PREDICATE}).
 *
 * <p>Rules encoded by the predicate: the tenant and its account are ACTIVE; the user has an ACTIVE membership in the
 * tenant; the assignment is unexpired and scoped to this tenant or to its account; the permission is not deprecated;
 * its product is IAM (always entitled) or is subscribed ACTIVE/TRIAL, not past {@code ends_at}, and enabled in the
 * tenant; and a {@code *.account} DATA permission comes from an ACCOUNT-scope assignment (ruling R42).
 *
 * <p>Runs on login, refresh and tenant switch only; no cache. Not transactional by itself: it joins the caller's
 * transaction if there is one.
 */
@Service
public class PermissionResolver {

  /**
   * Ruling R42 (final review I4): a DATA permission whose code ends in {@code .account} ("every record of the
   * account", iam-client {@code DataScope.ACCOUNT}) is granted only through an ACCOUNT-scope assignment. A TENANT-scope
   * assignment of a role containing it grants the role's other permissions but not this one, so the JWT {@code perms}
   * are truthful for {@code DataScope}: holding {@code x.read.account} in a token always means account-wide. Shared by
   * {@link #resolve}, {@link #explain} (JWT perms == explain) and {@link #resolveGrantorAtTenant}.
   */
  static final String ACCOUNT_DATA_RULE =
      "NOT (p.kind = 'DATA' AND p.code LIKE '%.account' AND ra.scope_type <> 'ACCOUNT')";

  /**
   * Spec section 5 joins, minus the membership join: assignment → permission (not deprecated) → ACTIVE tenant
   * {@code :tenantId} → ACTIVE account → product, subscription and tenant switch.
   */
  static final String TENANT_JOINS = """
      FROM role_assignment ra
      JOIN role_permission rp ON rp.role = ra.role_id
      JOIN permission p       ON p.id = rp.permission_id AND NOT p.deprecated
      JOIN tenant t           ON t.id = :tenantId AND t.status = 'ACTIVE'
      JOIN account a          ON a.id = t.account_id AND a.status = 'ACTIVE'
      JOIN product pr         ON pr.id = p.product_id
      LEFT JOIN account_product ap ON ap.account = a.id AND ap.product_id = p.product_id
      LEFT JOIN tenant_product tp  ON tp.tenant = t.id AND tp.product_id = p.product_id
      """;

  /** Spec section 5: the user must hold an ACTIVE membership in the tenant. */
  static final String MEMBERSHIP_JOIN = """
      JOIN user_tenant_membership m ON m.app_user = ra.user_id AND m.tenant_id = t.id AND m.status = 'ACTIVE'
      """;

  /**
   * Spec section 5 WHERE: user, unexpired, scoped to this tenant or its account, product entitled in the tenant; plus
   * ruling R42 ({@link #ACCOUNT_DATA_RULE}).
   */
  static final String TENANT_PREDICATE = """
      WHERE ra.user_id = :userId
        AND (ra.expires_at IS NULL OR ra.expires_at > now())
        AND ((ra.scope_type = 'TENANT' AND ra.scope_id = t.id) OR (ra.scope_type = 'ACCOUNT' AND ra.scope_id = a.id))
        AND ( pr.code = 'IAM'
           OR (ap.status IN ('ACTIVE','TRIAL') AND (ap.ends_at IS NULL OR ap.ends_at >= current_date) AND tp.enabled) )
      """ + "  AND " + PermissionResolver.ACCOUNT_DATA_RULE + "\n";

  /** Spec section 5, verbatim (same joins in the same order). Parameters: {@code :userId}, {@code :tenantId}. */
  static final String TENANT_GRANTS = TENANT_JOINS + MEMBERSHIP_JOIN + TENANT_PREDICATE;

  static final String RESOLVE_SQL = "SELECT DISTINCT p.code\n" + TENANT_GRANTS;

  /**
   * I6 at TENANT scope (ruling R11): {@link #TENANT_GRANTS} plus the user's ACCOUNT-scope grants in the tenant's
   * account under the same tenant entitlement rules, without the membership join. Parameters: {@code :userId},
   * {@code :tenantId}.
   */
  static final String GRANTOR_AT_TENANT_SQL = "SELECT p.code\n" + TENANT_GRANTS
      + "UNION\nSELECT p.code\n" + TENANT_JOINS + TENANT_PREDICATE + "  AND ra.scope_type = 'ACCOUNT'\n";

  static final String EXPLAIN_SQL = """
      SELECT g.code, g.role_id, r.name AS role_name, g.scope_type, g.scope_id, g.expires_at
      FROM (SELECT p.code, ra.role_id, ra.scope_type, ra.scope_id, ra.expires_at
      """ + TENANT_GRANTS + """
           ) g
      JOIN role r ON r.id = g.role_id
      ORDER BY g.code, r.name, g.scope_type
      """;

  /**
   * The account-level counterpart used for I6 at ACCOUNT scope: only unexpired ACCOUNT-scope assignments in the
   * (ACTIVE) account, same deprecation and subscription rules, no membership and no {@code tenant_product} (there is
   * no tenant). Parameters: {@code :userId}, {@code :accountId}.
   */
  static final String ACCOUNT_SCOPE_SQL = """
      SELECT DISTINCT p.code
      FROM role_assignment ra
      JOIN role_permission rp ON rp.role = ra.role_id
      JOIN permission p       ON p.id = rp.permission_id AND NOT p.deprecated
      JOIN account a          ON a.id = :accountId AND a.status = 'ACTIVE'
      JOIN product pr         ON pr.id = p.product_id
      LEFT JOIN account_product ap ON ap.account = a.id AND ap.product_id = p.product_id
      WHERE ra.user_id = :userId
        AND (ra.expires_at IS NULL OR ra.expires_at > now())
        AND ra.scope_type = 'ACCOUNT' AND ra.scope_id = a.id
        AND ( pr.code = 'IAM'
           OR (ap.status IN ('ACTIVE','TRIAL') AND (ap.ends_at IS NULL OR ap.ends_at >= current_date)) )
      """;

  private final JdbcClient jdbc;

  public PermissionResolver(JdbcClient jdbc) {
    this.jdbc = jdbc;
  }

  /** Permission codes user {@code userId} holds in tenant {@code tenantId} (empty if none or not applicable). */
  public Set<String> resolve(UUID userId, UUID tenantId) {
    return Set.copyOf(jdbc.sql(RESOLVE_SQL)
        .param("userId", userId)
        .param("tenantId", tenantId)
        .query(String.class)
        .list());
  }

  /** Why {@link #resolve} returns what it returns: one row per (permission, role, scope) grant. Same predicate. */
  public List<PermissionGrant> explain(UUID userId, UUID tenantId) {
    return jdbc.sql(EXPLAIN_SQL)
        .param("userId", userId)
        .param("tenantId", tenantId)
        .query((rs, i) -> {
          OffsetDateTime expires = rs.getObject("expires_at", OffsetDateTime.class);
          return new PermissionGrant(
              rs.getString("code"),
              rs.getObject("role_id", UUID.class),
              rs.getString("role_name"),
              ScopeType.valueOf(rs.getString("scope_type")),
              rs.getObject("scope_id", UUID.class),
              expires == null ? null : expires.toInstant());
        })
        .list();
  }

  /**
   * What a grantor holds at tenant {@code tenantId} for I6 (ruling R11): {@link #resolve} ∪ the permissions of the
   * grantor's unexpired ACCOUNT-scope assignments in the tenant's account, filtered by the tenant's entitlement
   * exactly like {@link #resolve} (tenant and account ACTIVE, {@code tenant_product} enabled, subscription
   * ACTIVE/TRIAL and not ended, IAM always entitled, not deprecated) but without requiring a membership in the tenant.
   */
  public Set<String> resolveGrantorAtTenant(UUID grantorId, UUID tenantId) {
    return Set.copyOf(jdbc.sql(GRANTOR_AT_TENANT_SQL)
        .param("userId", grantorId)
        .param("tenantId", tenantId)
        .query(String.class)
        .list());
  }

  /**
   * Permission codes user {@code userId} holds through unexpired ACCOUNT-scope assignments in account
   * {@code accountId}, filtered by product entitlement (IAM always entitled). Used by I6 for ACCOUNT-scope grants.
   */
  public Set<String> resolveAccountScope(UUID userId, UUID accountId) {
    return Set.copyOf(jdbc.sql(ACCOUNT_SCOPE_SQL)
        .param("userId", userId)
        .param("accountId", accountId)
        .query(String.class)
        .list());
  }
}
