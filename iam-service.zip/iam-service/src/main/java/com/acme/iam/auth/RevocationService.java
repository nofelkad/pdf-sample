package com.acme.iam.auth;

import com.acme.iam.audit.AuditEvent;
import com.acme.iam.audit.AuditWriter;
import com.acme.iam.common.security.AppCaller;
import com.acme.iam.core.revocation.RevocationEntry;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.UUID;
import java.util.stream.Collectors;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.simple.JdbcClient;
import org.springframework.lang.Nullable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.support.TransactionSynchronization;
import org.springframework.transaction.support.TransactionSynchronizationManager;

/**
 * Revokes users' outstanding access tokens (spec section 5, Revocation; P1-10.1): bumps
 * {@code app_user.session_version} and appends one {@code revocation} row per user with {@code min_sv} = the new
 * version, and writes one {@value #AUDIT_ACTION} audit event per call (Ruling R15).
 *
 * <p><b>Transactions:</b> every {@code revoke*} method has {@code Propagation.MANDATORY}: it must run inside the
 * caller's transaction (the change that shrinks access), so the bumps, the feed rows and the audit event commit or
 * roll back with it. Calling it without a transaction throws {@code IllegalTransactionStateException}.
 *
 * <p><b>Order of work (Ruling R13):</b>
 * <ol>
 *   <li>all {@code session_version} bumps, in batches of {@value #DEFAULT_BATCH_SIZE}: each batch selects its target
 *       user ids, then locks those {@code app_user} rows in id order ({@code SELECT … ORDER BY id FOR NO KEY UPDATE},
 *       which does not block FK inserts such as sessions or grants referencing the users) and updates them;
 *   <li>then the feed advisory lock {@value #FEED_LOCK_KEY} ({@code pg_advisory_xact_lock}, <b>held until the
 *       caller's transaction commits or rolls back</b>);
 *   <li>then one {@code INSERT} of every feed row, and the audit event.
 * </ol>
 * The feed lock makes feed ids follow commit order (a poller that has seen id {@code n} never misses a smaller id
 * committed later). Because no row is locked while waiting for or holding the feed lock, two revocations cannot
 * <b>deadlock</b> on it, provided every transaction follows these rules:
 * <ul>
 *   <li><b>At most one {@code revoke*} call per transaction, as the caller's last write.</b> A second call in the same
 *       transaction fails fast with {@link IllegalStateException}: it would lock rows while holding the feed lock and
 *       can deadlock with another revocation. Row locks taken after the call cannot be detected but carry the same
 *       deadlock risk, so take none. Collect every affected user first ({@link #revokeUsers} takes any number).
 *       The guard is bound to the thread for the lifetime of the publishing transaction, so a {@code revoke*} in a
 *       {@code REQUIRES_NEW} transaction opened inside it also fails fast: that inner transaction would otherwise wait
 *       forever on the feed lock held by its own suspended outer transaction (a self-deadlock PostgreSQL cannot
 *       detect). {@code NESTED} (savepoint) transactions are not supported: rolling back to a savepoint after a
 *       {@code revoke*} leaves the guard set for the rest of the outer transaction.
 *   <li>Ordinary row-order cycles between writers (two transactions touching the same users in different orders before
 *       revoking) can still deadlock like any PostgreSQL workload: expect SQLSTATE {@code 40P01}
 *       ({@code deadlock_detected}, surfaced as Spring's {@code CannotAcquireLockException}) and retry the whole
 *       transaction.
 * </ul>
 */
@Service
public class RevocationService {

  public static final int DEFAULT_BATCH_SIZE = 5000;
  /** {@code pg_advisory_xact_lock} key serialising revocation feed writers. */
  public static final long FEED_LOCK_KEY = 0x1A4D_0001L;
  /** One summary event per {@code revoke*} call. */
  public static final String AUDIT_ACTION = "auth.sessions.revoked";
  /** At most this many user ids are listed in the audit event's {@code user_ids}. */
  public static final int AUDIT_MAX_USER_IDS = 1000;

  private static final UUID MIN_UUID = new UUID(0, 0);

  /** One batch of bumps: the target rows are locked in id order, then updated. */
  private static final String BUMP_SQL = """
      WITH locked AS (SELECT u.id FROM app_user u WHERE u.id IN (:ids) ORDER BY u.id FOR NO KEY UPDATE)
      UPDATE app_user u SET session_version = u.session_version + 1
      FROM locked l WHERE u.id = l.id
      RETURNING u.id, u.session_version, u.account_id, u.primary_tenant_id
      """;

  /** Transaction-bound resource key: set once this transaction holds the feed lock. */
  private static final String PUBLISHED_IN_TX = RevocationService.class.getName() + ".publishedInTransaction";

  private static final String INSERT_FEED_SQL = """
      INSERT INTO revocation (user_id, min_sv, reason)
      SELECT b.user_id, b.min_sv, :reason
      FROM unnest(CAST(:userIds AS uuid[]), CAST(:minSvs AS int[])) AS b(user_id, min_sv)
      ORDER BY b.user_id
      """;

  private record Bumped(UUID userId, int minSv, UUID accountId, UUID primaryTenantId) {}

  private final JdbcClient jdbc;
  private final AuditWriter auditWriter;
  private final int batchSize;

  @Autowired
  public RevocationService(JdbcClient jdbc, AuditWriter auditWriter,
                           @Value("${iam.revocation.batch-size:5000}") int batchSize) {
    if (batchSize < 1) {
      throw new IllegalArgumentException("batch size must be positive");
    }
    this.jdbc = jdbc;
    this.auditWriter = auditWriter;
    this.batchSize = batchSize;
  }

  /** Revokes the given users (duplicates ignored). @return number of users revoked */
  @Transactional(propagation = Propagation.MANDATORY)
  public int revokeUsers(Collection<UUID> userIds, String reason) {
    requireReason(reason);
    List<UUID> ids = userIds.stream().filter(Objects::nonNull).distinct()
        .sorted(Comparator.comparing(UUID::toString)).toList();
    List<Bumped> bumped = new ArrayList<>();
    for (int from = 0; from < ids.size(); from += batchSize) {
      bumped.addAll(bump(ids.subList(from, Math.min(from + batchSize, ids.size()))));
    }
    return publish(bumped, reason, null, null);
  }

  /** Every user of the account (account suspended/closed). @return number of users revoked */
  @Transactional(propagation = Propagation.MANDATORY)
  public int revokeAccountUsers(UUID accountId, String reason) {
    return revokeScope("SELECT id AS user_id FROM app_user WHERE account_id = :scope AND id > :after",
        "account", accountId, reason);
  }

  /** Every member of the tenant, whatever the membership status (tenant suspended/archived). */
  @Transactional(propagation = Propagation.MANDATORY)
  public int revokeTenantMembers(UUID tenantId, String reason) {
    return revokeScope("""
        SELECT DISTINCT app_user AS user_id FROM user_tenant_membership
        WHERE tenant_id = :scope AND app_user > :after""", "tenant", tenantId, reason);
  }

  /** Every user holding the role at any scope, expired assignments included (role permissions edited). */
  @Transactional(propagation = Propagation.MANDATORY)
  public int revokeRoleHolders(UUID roleId, String reason) {
    return revokeScope("""
        SELECT DISTINCT user_id FROM role_assignment
        WHERE role_id = :scope AND user_id > :after""", "role", roleId, reason);
  }

  /** Feed rows with {@code id > cursor}, oldest first, at most {@code limit}. */
  public List<RevocationEntry> since(long cursor, int limit) {
    return jdbc.sql("SELECT id, user_id, min_sv FROM revocation WHERE id > :cursor ORDER BY id LIMIT :limit")
        .param("cursor", cursor)
        .param("limit", limit)
        .query((rs, n) -> new RevocationEntry(rs.getLong("id"), rs.getObject("user_id", UUID.class), rs.getInt("min_sv")))
        .list();
  }

  /**
   * Cursor from which a poller that starts now must read to see every row of the last {@code lookback}: the id just
   * before the oldest such row, or the newest id when there is none.
   */
  public long startCursor(Duration lookback) {
    return jdbc.sql("""
            SELECT COALESCE(
                (SELECT min(id) - 1 FROM revocation WHERE created_at >= now() - make_interval(secs => :secs)),
                (SELECT COALESCE(max(id), 0) FROM revocation))""")
        .param("secs", (double) lookback.toMillis() / 1000)
        .query(Long.class).single();
  }

  /** Deletes feed rows older than {@code retention}. @return rows deleted */
  @Transactional
  public int purge(Duration retention) {
    return jdbc.sql("DELETE FROM revocation WHERE created_at < now() - make_interval(secs => :secs)")
        .param("secs", (double) retention.toMillis() / 1000)
        .update();
  }

  // ---------------------------------------------------------------------------------------------------------------

  private int revokeScope(String targetSql, String scopeType, UUID scopeId, String reason) {
    requireReason(reason);
    Objects.requireNonNull(scopeId, "scopeId");
    String query = targetSql + " ORDER BY 1 LIMIT :batch";
    UUID after = MIN_UUID;
    List<Bumped> bumped = new ArrayList<>();
    while (true) {
      // Driven by the targets, not by the rows bumped: a target deleted concurrently is skipped by the row lock but
      // must not end the scan early.
      List<UUID> targets = jdbc.sql(query)
          .params(Map.of("scope", scopeId, "after", after, "batch", batchSize))
          .query(UUID.class).list();
      if (targets.isEmpty()) {
        break;
      }
      bumped.addAll(bump(targets));
      if (targets.size() < batchSize) {
        break;
      }
      after = targets.get(targets.size() - 1); // ORDER BY 1: the largest id in PostgreSQL order
    }
    return publish(bumped, reason, scopeType, scopeId);
  }

  /**
   * Bumps one batch of users (users that no longer exist are skipped); returns the new versions ordered by user id.
   *
   * @throws IllegalStateException when this transaction already published a revocation (deadlock guard)
   */
  private List<Bumped> bump(List<UUID> userIds) {
    if (TransactionSynchronizationManager.hasResource(PUBLISHED_IN_TX)) {
      throw new IllegalStateException("at most one revoke* per transaction: this transaction already holds the "
          + "revocation feed lock, and locking more app_user rows now can deadlock with another revocation; collect "
          + "all affected users and make a single revoke* call as the transaction's last write");
    }
    List<Bumped> rows = new ArrayList<>(jdbc.sql(BUMP_SQL)
        .param("ids", userIds)
        .query((rs, n) -> new Bumped(rs.getObject("id", UUID.class), rs.getInt("session_version"),
            rs.getObject("account_id", UUID.class), rs.getObject("primary_tenant_id", UUID.class)))
        .list());
    rows.sort(Comparator.comparing(b -> b.userId().toString())); // PostgreSQL uuid order = lower-case hex order
    return rows;
  }

  /** Feed lock (held to commit), one INSERT of every feed row, one audit event. */
  private int publish(List<Bumped> bumped, String reason, @Nullable String scopeType, @Nullable UUID scopeId) {
    if (bumped.isEmpty()) {
      return 0;
    }
    // Remember (for this transaction only) that the feed lock is held. The flag is bound only when it can be cleared
    // at commit/rollback: register the clean-up first, then bind, so a failure can never leave it on a pooled thread.
    // Without active synchronization (a transaction manager configured SYNCHRONIZATION_NEVER) the guard is skipped.
    if (TransactionSynchronizationManager.isSynchronizationActive()) {
      TransactionSynchronizationManager.registerSynchronization(new TransactionSynchronization() {
        @Override
        public void afterCompletion(int status) {
          TransactionSynchronizationManager.unbindResourceIfPossible(PUBLISHED_IN_TX);
        }
      });
      TransactionSynchronizationManager.bindResource(PUBLISHED_IN_TX, Boolean.TRUE);
    }
    jdbc.sql("SELECT 1 FROM (SELECT pg_advisory_xact_lock(:key)) l").param("key", FEED_LOCK_KEY)
        .query(Integer.class).single();
    jdbc.sql(INSERT_FEED_SQL)
        .param("userIds", arrayLiteral(bumped.stream().map(b -> b.userId().toString()).toList()))
        .param("minSvs", arrayLiteral(bumped.stream().map(b -> Integer.toString(b.minSv())).toList()))
        .param("reason", reason)
        .update();
    audit(bumped, reason, scopeType, scopeId);
    return bumped.size();
  }

  private void audit(List<Bumped> bumped, String reason, @Nullable String scopeType, @Nullable UUID scopeId) {
    List<UUID> userIds = bumped.stream().map(Bumped::userId).toList();
    Map<String, Object> metadata = new LinkedHashMap<>();
    metadata.put("reason", reason);
    metadata.put("count", userIds.size());
    metadata.put("user_ids", cappedIds(userIds).stream().map(UUID::toString).toList());
    if (scopeType != null) {
      metadata.put("scope_type", scopeType);
      metadata.put("scope_id", scopeId.toString());
    }
    AuditEvent.Builder event = AuditEvent.forCurrentActor(AUDIT_ACTION);
    attribute(event, bumped, scopeType, scopeId);
    if (userIds.size() == 1) {
      event.target("app_user", userIds.get(0).toString());
    } else if (scopeType != null) {
      event.target(scopeType, scopeId.toString());
    }
    AppCaller.currentClientId().ifPresent(clientId -> {
      event.source(AppCaller.source(clientId));
      metadata.put("client_id", clientId);
    });
    auditWriter.write(event.metadata(metadata).build());
  }

  /**
   * Final review C1: the summary belongs to the revoked users' account (not the actor's): with one user, to that user's
   * account and primary tenant; for a tenant-wide revocation, to that tenant; otherwise account-level. Users of several
   * accounts at once (a SYSTEM role edited by its product's manifest) keep the actor's attribution.
   */
  private static void attribute(AuditEvent.Builder event, List<Bumped> bumped, @Nullable String scopeType,
      @Nullable UUID scopeId) {
    List<UUID> accounts = bumped.stream().map(Bumped::accountId).distinct().toList();
    if (accounts.size() != 1) {
      return;
    }
    UUID tenant = bumped.size() == 1 ? bumped.get(0).primaryTenantId()
        : "tenant".equals(scopeType) ? scopeId : null;
    event.affecting(accounts.get(0), tenant);
  }

  /** The first {@value #AUDIT_MAX_USER_IDS} ids (ordered as given). */
  static List<UUID> cappedIds(List<UUID> userIds) {
    return userIds.size() <= AUDIT_MAX_USER_IDS ? userIds : userIds.subList(0, AUDIT_MAX_USER_IDS);
  }

  /** Postgres array literal of values that need no quoting (UUIDs, integers). */
  private static String arrayLiteral(List<String> values) {
    return values.stream().collect(Collectors.joining(",", "{", "}"));
  }

  private static void requireReason(String reason) {
    if (reason == null || reason.isBlank()) {
      throw new IllegalArgumentException("reason is required");
    }
  }
}
