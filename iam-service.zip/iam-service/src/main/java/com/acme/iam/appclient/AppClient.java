package com.acme.iam.appclient;

import java.time.Instant;
import java.util.UUID;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.Id;
import org.springframework.data.annotation.Version;
import org.springframework.data.relational.core.mapping.Table;

/**
 * A registered application client (P1-12.1, table {@code app_client}, V5). Authenticates at
 * {@code POST /internal/token} with {@code clientId} and a secret whose SHA-256 is {@code secretHash}.
 */
@Table("app_client")
public record AppClient(
    @Id UUID id,
    String clientId,
    String productCode,
    byte[] secretHash,
    AppClientStatus status,
    @CreatedDate Instant createdAt,
    @Version Long version) {

  public enum AppClientStatus { ACTIVE, DISABLED }

  static AppClient register(String clientId, String productCode, byte[] secretHash) {
    return new AppClient(null, clientId, productCode, secretHash, AppClientStatus.ACTIVE, null, null);
  }

  AppClient withSecretHash(byte[] newSecretHash) {
    return new AppClient(id, clientId, productCode, newSecretHash, status, createdAt, version);
  }

  AppClient withStatus(AppClientStatus newStatus) {
    return new AppClient(id, clientId, productCode, secretHash, newStatus, createdAt, version);
  }

  /** Never print the secret hash. */
  @Override
  public String toString() {
    return "AppClient[id=" + id + ", clientId=" + clientId + ", productCode=" + productCode + ", status=" + status
        + "]";
  }
}
