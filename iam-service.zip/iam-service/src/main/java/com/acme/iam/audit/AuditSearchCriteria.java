package com.acme.iam.audit;

import com.acme.iam.common.paging.KeysetCursor;
import java.time.Instant;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.UUID;
import org.springframework.lang.Nullable;

/**
 * Validated filters with the account already resolved: {@code accountId} is the caller's own account unless a
 * platform caller named another one (I10). Every query built from this carries {@code account_id = :accountId}.
 *
 * @param actionPrefix the raw prefix (wildcards are escaped when the query is built)
 * @param from         inclusive, {@code null} only for a target history
 * @param to           exclusive, {@code null} only for a target history
 * @param cursor       last row of the previous page, {@code null} for the first page
 * @param limit        page size, only used by {@link AuditSearchSql#page}
 */
public record AuditSearchCriteria(
    UUID accountId,
    @Nullable UUID tenantId,
    @Nullable UUID actorUserId,
    @Nullable String actionPrefix,
    @Nullable String targetType,
    @Nullable String targetId,
    @Nullable String outcome,
    @Nullable Instant from,
    @Nullable Instant to,
    @Nullable KeysetCursor cursor,
    int limit) {

  /** The filters that were applied, as recorded in the export audit event. */
  public Map<String, Object> describe() {
    Map<String, Object> m = new LinkedHashMap<>();
    m.put("accountId", accountId.toString());
    put(m, "tenantId", tenantId);
    put(m, "actorUserId", actorUserId);
    put(m, "action", actionPrefix);
    put(m, "targetType", targetType);
    put(m, "targetId", targetId);
    put(m, "outcome", outcome);
    put(m, "from", from);
    put(m, "to", to);
    return m;
  }

  private static void put(Map<String, Object> m, String key, @Nullable Object value) {
    if (value != null) {
      m.put(key, value.toString());
    }
  }
}
