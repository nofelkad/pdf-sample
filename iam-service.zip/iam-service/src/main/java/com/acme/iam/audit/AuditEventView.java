package com.acme.iam.audit;

import com.fasterxml.jackson.databind.JsonNode;
import java.time.Instant;
import java.util.UUID;
import org.springframework.lang.Nullable;

/** One audit row as returned by search and target history. Absent (null) fields are omitted from the JSON. */
public record AuditEventView(
    UUID eventId,
    Instant occurredAt,
    Instant receivedAt,
    @Nullable UUID accountId,
    @Nullable UUID tenantId,
    String source,
    @Nullable UUID actorUserId,
    String actorType,
    @Nullable String actorIp,
    @Nullable String userAgent,
    @Nullable UUID sessionId,
    @Nullable String requestId,
    String action,
    @Nullable String targetType,
    @Nullable String targetId,
    String outcome,
    @Nullable JsonNode before,
    @Nullable JsonNode after,
    @Nullable JsonNode metadata) {}
