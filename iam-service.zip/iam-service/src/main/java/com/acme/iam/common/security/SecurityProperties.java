package com.acme.iam.common.security;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import java.time.Duration;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.bind.DefaultValue;
import org.springframework.validation.annotation.Validated;

/**
 * {@code iam.security.*}. {@code issuer} and {@code master-key} have no default outside the {@code dev}/{@code test}
 * profiles, so a production start without them fails fast.
 *
 * @param issuer {@code iss} claim and accepted issuer ({@code IAM_ISSUER})
 * @param masterKey base64 of 32 random bytes; AES-256-GCM key for signing-key private parts ({@code IAM_MASTER_KEY})
 * @param accessTokenTtl user access token lifetime (spec: 15 min)
 * @param appTokenTtl application client token lifetime ({@code expires_in}: 600 s)
 * @param clockSkew tolerance on {@code exp}/{@code nbf}
 * @param keyPublishLead how long a new key is published before it signs (JWKS caches catch up)
 * @param keyRotationInterval age of the ACTIVE key after which the rotation job publishes a successor
 * @param keyRetireMargin extra time after the longest token lifetime before a demoted key is retired
 * @param jwkRefreshInterval how often each instance reloads keys from the database
 */
@Validated
@ConfigurationProperties("iam.security")
public record SecurityProperties(
    @NotBlank String issuer,
    @NotBlank String masterKey,
    @NotNull @DefaultValue("PT15M") Duration accessTokenTtl,
    @NotNull @DefaultValue("PT10M") Duration appTokenTtl,
    @NotNull @DefaultValue("PT60S") Duration clockSkew,
    @NotNull @DefaultValue("PT24H") Duration keyPublishLead,
    @NotNull @DefaultValue("P90D") Duration keyRotationInterval,
    @NotNull @DefaultValue("PT5M") Duration keyRetireMargin,
    @NotNull @DefaultValue("PT60S") Duration jwkRefreshInterval) {

  /** Longest lifetime of any token IAM signs. */
  public Duration maxTokenTtl() {
    return accessTokenTtl.compareTo(appTokenTtl) >= 0 ? accessTokenTtl : appTokenTtl;
  }

  /** Never print the master key. */
  @Override
  public String toString() {
    return "SecurityProperties[issuer=" + issuer + ", masterKey=[REDACTED], accessTokenTtl=" + accessTokenTtl
        + ", appTokenTtl=" + appTokenTtl + ", clockSkew=" + clockSkew + ", keyPublishLead=" + keyPublishLead
        + ", keyRotationInterval=" + keyRotationInterval + ", keyRetireMargin=" + keyRetireMargin
        + ", jwkRefreshInterval=" + jwkRefreshInterval + "]";
  }
}
