package com.acme.iam.observability;

/**
 * Names of the meters iam-service publishes through Micrometer (P1-11.5), all under {@code iam.*}. They are listed,
 * with their Prometheus series and tags, in {@code docs/observability.md}; keep the two in step.
 *
 * <p>Meters that were already published before this class existed keep their definitions in their owners:
 * {@code iam.audit.partitions.months_ahead} (AuditPartitionService) and {@code iam.auth.password_reset.dropped}
 * (PasswordResetMailer).
 */
public final class MetricNames {

  /** Counter, tags {@code outcome} (success|failure) and {@code reason}. */
  public static final String AUTH_LOGINS = "iam.auth.logins";
  /** Counter: a failed login that applied the lock (the {@code max-attempts}-th failure). */
  public static final String AUTH_LOCKOUTS = "iam.auth.lockouts";
  /** Counter: a rotated-out refresh token was presented again (the session is revoked). */
  public static final String AUTH_REFRESH_REUSE_DETECTED = "iam.auth.refresh.reuse_detected";
  /** Timer, tag {@code outcome} (success|error). */
  public static final String AUTH_LOGIN_DURATION = "iam.auth.login.duration";
  /** Timer, tag {@code outcome}. */
  public static final String AUTH_REFRESH_DURATION = "iam.auth.refresh.duration";
  /** Timer, tag {@code outcome}. */
  public static final String AUTH_TENANT_SWITCH_DURATION = "iam.auth.tenant_switch.duration";
  /** Timer, tags {@code op} (resolve|explain) and {@code outcome}. */
  public static final String PERMISSION_RESOLVE_DURATION = "iam.permission.resolve.duration";
  /** Gauge (seconds): age, when the poller applied it, of the newest revocation entry applied. */
  public static final String REVOCATION_LAG = "iam.revocation.lag";
  /** Gauge (seconds): time since the revocation poller last read the feed successfully. */
  public static final String REVOCATION_POLL_AGE = "iam.revocation.poll.age";
  /** Counter: revocation feed reads of the poller that failed. */
  public static final String REVOCATION_POLL_FAILURES = "iam.revocation.poll.failures";
  /** Distribution summary (seconds): {@code received_at - occurred_at} of accepted ingested audit events. */
  public static final String AUDIT_INGEST_LAG = "iam.audit.ingest.lag";
  /** Counter: password reset mails whose send hit {@code iam.auth.mail-executor.send-timeout}. */
  public static final String PASSWORD_RESET_SEND_TIMEOUTS = "iam.auth.password_reset.send_timeouts";

  /** Percentiles published (client side) by every timer and summary above. */
  public static final double[] PERCENTILES = {0.5, 0.95, 0.99};

  private MetricNames() {}
}
