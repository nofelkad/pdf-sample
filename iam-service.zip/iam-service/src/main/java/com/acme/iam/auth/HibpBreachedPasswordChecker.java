package com.acme.iam.auth;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.time.Duration;
import java.util.HashMap;
import java.util.HexFormat;
import java.util.Locale;
import java.util.Map;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Have I Been Pwned "range" API with k-anonymity: only the first 5 hex characters of the password's SHA-1 are sent
 * ({@code GET <rangeUrl><PREFIX>} with {@code Add-Padding: true}); the returned suffixes are compared locally.
 * Fails open (returns {@code false} and logs a warning without any password data) when the service is unreachable or
 * answers with an error, so an outage never blocks password changes.
 */
public class HibpBreachedPasswordChecker implements BreachedPasswordChecker {

  static final int PREFIX_LENGTH = 5;
  private static final Logger log = LoggerFactory.getLogger(HibpBreachedPasswordChecker.class);

  private final URI rangeUrl;
  private final Duration timeout;
  private final HttpClient http;

  public HibpBreachedPasswordChecker(URI rangeUrl, Duration timeout) {
    String base = rangeUrl.toString();
    this.rangeUrl = URI.create(base.endsWith("/") ? base : base + "/");
    this.timeout = timeout;
    this.http = HttpClient.newBuilder().connectTimeout(timeout).followRedirects(HttpClient.Redirect.NEVER).build();
  }

  @Override
  public boolean isBreached(String rawPassword) {
    String sha1 = sha1Hex(rawPassword);
    String prefix = sha1.substring(0, PREFIX_LENGTH);
    String suffix = sha1.substring(PREFIX_LENGTH);
    try {
      HttpRequest request = HttpRequest.newBuilder(rangeUrl.resolve(prefix))
          .timeout(timeout)
          .header("Add-Padding", "true")
          .header("User-Agent", "acme-iam")
          .GET()
          .build();
      HttpResponse<String> response = http.send(request, HttpResponse.BodyHandlers.ofString(StandardCharsets.UTF_8));
      if (response.statusCode() != 200) {
        log.warn("Breached-password check unavailable (HTTP {}); accepting the password", response.statusCode());
        return false;
      }
      return Range.parse(response.body()).count(suffix) > 0;
    } catch (InterruptedException e) {
      Thread.currentThread().interrupt();
      log.warn("Breached-password check interrupted; accepting the password");
      return false;
    } catch (Exception e) {
      log.warn("Breached-password check failed ({}); accepting the password", e.getClass().getSimpleName());
      return false;
    }
  }

  static String sha1Hex(String raw) {
    try {
      byte[] digest = MessageDigest.getInstance("SHA-1").digest(raw.getBytes(StandardCharsets.UTF_8));
      return HexFormat.of().withUpperCase().formatHex(digest);
    } catch (NoSuchAlgorithmException e) {
      throw new IllegalStateException("SHA-1 unavailable", e);
    }
  }

  /** One range response: upper-case 35-char suffix → breach count (padding entries have count 0). */
  record Range(Map<String, Integer> counts) {

    static Range parse(String body) {
      Map<String, Integer> counts = new HashMap<>();
      for (String line : body.split("\r?\n")) {
        int colon = line.indexOf(':');
        if (colon <= 0) {
          continue;
        }
        try {
          counts.put(line.substring(0, colon).trim().toUpperCase(Locale.ROOT),
              Integer.parseInt(line.substring(colon + 1).trim()));
        } catch (NumberFormatException ignored) {
          // malformed line: skip
        }
      }
      return new Range(counts);
    }

    int count(String suffix) {
      return counts.getOrDefault(suffix.toUpperCase(Locale.ROOT), 0);
    }
  }
}
