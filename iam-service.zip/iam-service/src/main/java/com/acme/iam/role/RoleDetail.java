package com.acme.iam.role;

import com.acme.iam.product.PermissionKind;
import java.time.Instant;
import java.util.List;
import java.util.UUID;
import org.springframework.lang.Nullable;

/**
 * A role with its permissions, as returned by the role API.
 *
 * @param accountId {@code null} for SYSTEM roles
 */
public record RoleDetail(
    UUID id,
    UUID productId,
    String productCode,
    String name,
    @Nullable String description,
    RoleType type,
    @Nullable UUID accountId,
    List<RolePermissionView> permissions,
    Instant createdAt,
    Instant updatedAt) {

  /** One permission of a role. A deprecated permission is listed but never granted. */
  public record RolePermissionView(UUID id, String code, PermissionKind kind, String description,
      boolean deprecated) {}
}
