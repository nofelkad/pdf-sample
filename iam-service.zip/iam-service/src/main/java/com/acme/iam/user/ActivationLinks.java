package com.acme.iam.user;

import com.acme.iam.audit.AuditEvent;
import com.acme.iam.audit.AuditWriter;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import org.springframework.lang.Nullable;
import org.springframework.stereotype.Component;

/**
 * Ruling R46: the only place that turns an issued INVITE token into an {@link Activation} for an API response. The link
 * is built from {@code iam.notification.invitation-url}, so it is the same link the invitation email carries. Every
 * link handed out is audited as {@value #AUDIT_ACTION} in the caller's transaction (without the token or the link).
 * With {@code iam.notification.expose-activation-link=false} nothing is returned and nothing is audited.
 */
@Component
public class ActivationLinks {

  public static final String AUDIT_ACTION = "iam.invitation.link_issued";

  /** Which flow handed the link out ({@code via} in the audit metadata). */
  public enum Via {
    ACCOUNT_CREATE, INVITE, RESEND, ADMIN_RECOVERY;

    public String code() {
      return name().toLowerCase(Locale.ROOT);
    }
  }

  private final NotificationProperties properties;
  private final AuditWriter audit;

  public ActivationLinks(NotificationProperties properties, AuditWriter audit) {
    this.properties = properties;
    this.audit = audit;
  }

  /** The activation for {@code token}, or {@code null} when links are not exposed. */
  @Nullable
  public Activation issue(IssuedToken token, UUID accountId, UUID tenantId, UUID userId, Via via) {
    if (!properties.exposeActivationLink()) {
      return null;
    }
    Map<String, Object> metadata = new LinkedHashMap<>();
    metadata.put("expires_at", token.expiresAt().toString());
    metadata.put("via", via.code());
    audit.write(AuditEvent.forCurrentActor(AUDIT_ACTION).affecting(accountId, tenantId)
        .target("app_user", userId.toString()).metadata(metadata).build());
    return new Activation(properties.invitationLink(token.rawToken()), token.expiresAt());
  }
}
