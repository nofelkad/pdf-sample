package com.acme.iam.user;

import java.util.UUID;
import org.springframework.lang.Nullable;

/**
 * Optional filters of the user list; {@code null} means "any".
 *
 * @param tenantId users with a membership (any status) in this tenant
 * @param status users in this status
 * @param roleId users holding an unexpired assignment of this role; combined with {@code tenantId}, only assignments
 *     at that tenant's scope or at the account scope count
 */
public record UserListFilter(@Nullable UUID tenantId, @Nullable UserStatus status, @Nullable UUID roleId) {

  public static final UserListFilter NONE = new UserListFilter(null, null, null);
}
