package com.acme.iam.common.paging;

import com.acme.iam.common.error.BadRequestException;
import java.nio.charset.StandardCharsets;
import java.time.Instant;
import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.time.format.DateTimeParseException;
import java.util.Base64;
import java.util.Objects;
import java.util.Optional;
import java.util.UUID;
import org.springframework.lang.Nullable;

/**
 * Position in a list ordered by {@code (created_at DESC, id DESC)}: the last row of the previous page. Serialized as an
 * opaque string, base64url (no padding) of {@code <created_at ISO-8601>|<id>}.
 *
 * <p>Use as {@code WHERE (x.created_at, x.id) < (:cursorAt, :cursorId)} with {@link #createdAtParam()} and
 * {@link #id()}.
 */
public record KeysetCursor(Instant createdAt, UUID id) {

  /** Machine code of the 400 raised for a malformed cursor. */
  public static final String INVALID_CURSOR = "invalid_cursor";

  public KeysetCursor {
    Objects.requireNonNull(createdAt, "createdAt");
    Objects.requireNonNull(id, "id");
  }

  public String encode() {
    String raw = createdAt + "|" + id;
    return Base64.getUrlEncoder().withoutPadding().encodeToString(raw.getBytes(StandardCharsets.UTF_8));
  }

  /** {@code createdAt} as a JDBC-bindable {@code timestamptz} value. */
  public OffsetDateTime createdAtParam() {
    return OffsetDateTime.ofInstant(createdAt, ZoneOffset.UTC);
  }

  /**
   * Decodes a cursor produced by {@link #encode()}; {@code null} or blank means "first page".
   *
   * @throws BadRequestException {@value #INVALID_CURSOR} when the value is not a cursor
   */
  public static Optional<KeysetCursor> decode(@Nullable String cursor) {
    if (cursor == null || cursor.isBlank()) {
      return Optional.empty();
    }
    try {
      String raw = new String(Base64.getUrlDecoder().decode(cursor), StandardCharsets.UTF_8);
      int bar = raw.indexOf('|');
      if (bar < 0) {
        throw new IllegalArgumentException("no separator");
      }
      return Optional.of(new KeysetCursor(Instant.parse(raw.substring(0, bar)), UUID.fromString(raw.substring(bar + 1))));
    } catch (IllegalArgumentException | DateTimeParseException e) {
      throw new BadRequestException(INVALID_CURSOR, "Malformed pagination cursor");
    }
  }
}
