package com.acme.iam.audit;

import com.acme.iam.common.error.BadRequestException;
import com.acme.iam.common.paging.KeysetCursor;
import com.acme.iam.common.paging.KeysetPage;
import com.acme.iam.common.security.CodedAccessDeniedException;
import com.acme.iam.common.security.CurrentUser;
import com.acme.iam.common.security.PlatformGuard;
import com.acme.iam.common.security.TenantGuard;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.Duration;
import java.time.Instant;
import java.time.OffsetDateTime;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.regex.Pattern;
import org.springframework.jdbc.core.simple.JdbcClient;
import org.springframework.lang.Nullable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * P1-9.5 / P1-9.6: audit search and target history, and the shared filter validation used by the CSV export.
 *
 * <p>Tenant scope (Ruling R25): within the account, see {@link #resolveTenant}.
 *
 * <p>Account scope (I10): every query filters {@code account_id = <caller's acc>}. A caller may name another
 * {@code accountId} only as a platform operator ({@link PlatformGuard#isOperator()}: PLATFORM account and
 * {@value #PERM_PLATFORM} at ACCOUNT scope); anyone else naming a different account gets 403
 * {@value #ACCOUNT_FILTER_FORBIDDEN} (audited as {@code authz.denied}). Rows without an account (for example anonymous
 * login failures) are therefore never returned. Search and export require {@code from} and {@code to} (at most
 * {@value #MAX_WINDOW_DAYS} days apart, else 400 {@value #WINDOW_TOO_LARGE}); a target history needs neither.
 */
@Service
public class AuditQueryService {

  public static final String PERM_READ = "iam.audit.read";
  public static final String PERM_EXPORT = "iam.audit.export";
  public static final String PERM_PLATFORM = "platform.account.manage";
  public static final int MAX_WINDOW_DAYS = 92;
  public static final String WINDOW_REQUIRED = "window_required";
  public static final String WINDOW_TOO_LARGE = "window_too_large";
  public static final String INVALID_WINDOW = "invalid_window";
  public static final String ACCOUNT_FILTER_FORBIDDEN = "account_filter_forbidden";
  public static final String SCOPE_EXCEEDED = TenantGuard.SCOPE_EXCEEDED;
  public static final String TENANT_REQUIRED = "tenant_required";
  private static final Instant MIN_INSTANT = Instant.parse("0001-01-01T00:00:00Z");
  private static final Instant MAX_INSTANT = Instant.parse("9999-12-31T23:59:59Z");

  private static final Pattern ACTION_PREFIX = Pattern.compile("[a-z0-9_.]{1,128}");
  private static final int MAX_TARGET_TYPE = 128;
  private static final int MAX_TARGET_ID = 256;

  private final JdbcClient jdbc;
  private final CurrentUser currentUser;
  private final ObjectMapper objectMapper;
  private final TenantGuard tenantGuard;
  private final PlatformGuard platformGuard;

  public AuditQueryService(JdbcClient jdbc, CurrentUser currentUser, ObjectMapper objectMapper,
                           TenantGuard tenantGuard, PlatformGuard platformGuard) {
    this.jdbc = jdbc;
    this.currentUser = currentUser;
    this.objectMapper = objectMapper;
    this.tenantGuard = tenantGuard;
    this.platformGuard = platformGuard;
  }

  /**
   * Validates {@code filter} and resolves the account. Call it on the request thread (it reads the caller).
   *
   * @param windowRequired {@code true} for search and export, {@code false} for a target history
   * @param permission     the permission of the calling endpoint ({@link #PERM_READ} or {@link #PERM_EXPORT}); its
   *                       scope decides the tenants the caller may see (Ruling R25)
   */
  public AuditSearchCriteria criteria(AuditFilter filter, boolean windowRequired, String permission) {
    UUID callerAccount = currentUser.accountId();
    UUID account = resolveAccount(callerAccount, filter.accountId());
    UUID tenant = account.equals(callerAccount) ? resolveTenant(filter.tenantId(), permission) : filter.tenantId();
    validateInstant(filter.from(), "from");
    validateInstant(filter.to(), "to");
    validateWindow(filter.from(), filter.to(), windowRequired);
    if (filter.action() != null && !ACTION_PREFIX.matcher(filter.action()).matches()) {
      throw new BadRequestException("invalid_action_prefix", "action must match [a-z0-9_.]{1,128}");
    }
    require(filter.targetType() == null || filter.targetType().length() <= MAX_TARGET_TYPE, "targetType too long");
    require(filter.targetId() == null || filter.targetId().length() <= MAX_TARGET_ID, "targetId too long");
    return new AuditSearchCriteria(
        account,
        tenant,
        filter.actorUserId(),
        filter.action(),
        filter.targetType(),
        filter.targetId(),
        filter.outcome() == null ? null : filter.outcome().name(),
        filter.from(),
        filter.to(),
        cursor(filter.cursor()),
        KeysetPage.limit(filter.limit()));
  }

  /** One page of matching events, newest first. */
  @Transactional(readOnly = true)
  public KeysetPage<AuditEventView> search(AuditSearchCriteria criteria) {
    AuditSearchSql.Query q = AuditSearchSql.page(criteria);
    List<AuditEventView> rows = jdbc.sql(q.sql()).params(q.params()).query(this::view).list();
    return KeysetPage.of(rows, criteria.limit(), AuditEventView::occurredAt, AuditEventView::eventId);
  }

  /**
   * Ruling R25. A caller holding {@code permission} through an ACCOUNT-scope assignment sees every tenant of the
   * account and the account-level rows (null tenant); a {@code tenantId} filter must name a tenant of the account
   * ({@link TenantGuard#requireActive}). Everyone else is pinned to the token's tenant: {@code tenant_id = tid} is
   * forced (null-tenant rows drop out) and naming another tenant is 403 {@value #SCOPE_EXCEEDED}. A caller without an
   * active tenant ({@code tid} absent) and without account scope fails closed: 403 {@value #TENANT_REQUIRED} (it never
   * falls back to the whole account).
   */
  @Nullable
  private UUID resolveTenant(@Nullable UUID requested, String permission) {
    UUID active = currentUser.tenantIdOrNull();
    boolean other = requested != null && !requested.equals(active);
    if (tenantGuard.hasAccountScope(permission)) {
      if (other) {
        tenantGuard.requireActive(requested, permission);
      }
      return requested;
    }
    if (other) {
      throw new CodedAccessDeniedException(SCOPE_EXCEEDED,
          "Your " + permission + " grant covers only the active tenant",
          Map.of("requestedTenantId", requested.toString(), "requiredAuthority", permission));
    }
    if (active == null) {
      throw new CodedAccessDeniedException(TENANT_REQUIRED,
          "Without an active tenant, " + permission + " is needed at account scope",
          Map.of("requiredAuthority", permission));
    }
    return active;
  }

  /** The decoded cursor; one whose time cannot be stored as a timestamptz is as malformed as garbage. */
  @Nullable
  private static KeysetCursor cursor(@Nullable String raw) {
    KeysetCursor cursor = KeysetCursor.decode(raw).orElse(null);
    if (cursor != null && !inRange(cursor.createdAt())) {
      throw new BadRequestException(KeysetCursor.INVALID_CURSOR, "Malformed pagination cursor");
    }
    return cursor;
  }

  private static void validateInstant(@Nullable Instant value, String name) {
    if (value != null && !inRange(value)) {
      throw new BadRequestException("invalid_parameter", name + " must be between the years 0001 and 9999");
    }
  }

  /** Years 0001-9999: inside PostgreSQL's timestamptz range and what any real caller sends. */
  private static boolean inRange(Instant instant) {
    return !instant.isBefore(MIN_INSTANT) && instant.isBefore(MAX_INSTANT);
  }

  private UUID resolveAccount(UUID callerAccount, @Nullable UUID requested) {
    if (requested == null || requested.equals(callerAccount)) {
      return callerAccount;
    }
    if (!platformGuard.isOperator()) {
      throw new CodedAccessDeniedException(ACCOUNT_FILTER_FORBIDDEN,
          "Only platform administrators may query another account's audit log",
          Map.of("requestedAccountId", requested.toString()));
    }
    return requested;
  }

  private static void validateWindow(@Nullable Instant from, @Nullable Instant to, boolean required) {
    if (from == null || to == null) {
      if (required) {
        throw new BadRequestException(WINDOW_REQUIRED, "from and to are required");
      }
      return;
    }
    if (!to.isAfter(from)) {
      throw new BadRequestException(INVALID_WINDOW, "to must be after from");
    }
    if (required && Duration.between(from, to).compareTo(Duration.ofDays(MAX_WINDOW_DAYS)) > 0) {
      throw new BadRequestException(WINDOW_TOO_LARGE, "The window between from and to is at most "
          + MAX_WINDOW_DAYS + " days", Map.of("maxDays", MAX_WINDOW_DAYS));
    }
  }

  private static void require(boolean ok, String detail) {
    if (!ok) {
      throw new BadRequestException("validation_failed", detail);
    }
  }

  private AuditEventView view(ResultSet rs, int rowNum) throws SQLException {
    return new AuditEventView(
        rs.getObject("event_id", UUID.class),
        rs.getObject("occurred_at", OffsetDateTime.class).toInstant(),
        rs.getObject("received_at", OffsetDateTime.class).toInstant(),
        rs.getObject("account_id", UUID.class),
        rs.getObject("tenant_id", UUID.class),
        rs.getString("source"),
        rs.getObject("actor_user_id", UUID.class),
        rs.getString("actor_type"),
        rs.getString("actor_ip"),
        rs.getString("user_agent"),
        rs.getObject("session_id", UUID.class),
        rs.getString("request_id"),
        rs.getString("action"),
        rs.getString("target_type"),
        rs.getString("target_id"),
        rs.getString("outcome"),
        json(rs.getString("before_state")),
        json(rs.getString("after_state")),
        json(rs.getString("metadata")));
  }

  @Nullable
  private JsonNode json(@Nullable String text) throws SQLException {
    if (text == null) {
      return null;
    }
    try {
      return objectMapper.readTree(text);
    } catch (JsonProcessingException e) {
      throw new SQLException("Stored audit payload is not valid JSON", e);
    }
  }
}
