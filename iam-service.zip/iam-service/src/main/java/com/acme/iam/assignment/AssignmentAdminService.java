package com.acme.iam.assignment;

import com.acme.iam.auth.RevocationService;
import com.acme.iam.common.error.NotFoundException;
import com.acme.iam.common.jdbc.RetryOnDeadlock;
import com.acme.iam.common.security.CodedAccessDeniedException;
import com.acme.iam.common.security.TenantGuard;
import java.time.Instant;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import org.springframework.lang.Nullable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * Assigning and revoking roles through the API (P1-10.4). Both operations need {@code iam.role.assign} and are
 * authorised at the scope they act on:
 *
 * <ul>
 *   <li><b>TENANT scope</b>: the tenant must be the caller's active tenant, or the caller must hold
 *       {@code iam.role.assign} through an ACCOUNT-scope assignment ({@link TenantGuard}; unknown or foreign tenants
 *       are {@code 404 tenant_not_found}).
 *   <li><b>ACCOUNT scope</b>: the caller must hold {@code iam.role.assign} at ACCOUNT scope
 *       ({@link TenantGuard#hasAccountScope}, the same predicate every other account-wide check uses; final review M3)
 *       ({@code 403 account_scope_required}), so a Tenant Admin cannot hand out or take away account-wide roles.
 * </ul>
 *
 * Assigning delegates to {@link AssignmentService#assign} (I1, I3, I6, I8). Revoking runs
 * {@link LastAdminService#requireNotLastAdminAssignment} first (I7), then deletes the row, then revokes the user's
 * tokens as the transaction's last write (one {@code revoke*}). Revoking an assignment of a user of another account is
 * {@code 404 assignment_not_found} (I10).
 */
@Service
public class AssignmentAdminService {

  public static final String PERMISSION = "iam.role.assign";
  public static final String ACCOUNT_SCOPE_REQUIRED = TenantGuard.ACCOUNT_SCOPE_REQUIRED;
  public static final String REVOKE_REASON = "assignment.revoked";

  private final AssignmentService assignments;
  private final AssignmentQueryService query;
  private final RoleAssignmentRepository repository;
  private final LastAdminService lastAdmin;
  private final TenantGuard tenantGuard;
  private final RevocationService revocations;

  public AssignmentAdminService(AssignmentService assignments, AssignmentQueryService query,
      RoleAssignmentRepository repository, LastAdminService lastAdmin, TenantGuard tenantGuard,
      RevocationService revocations) {
    this.assignments = assignments;
    this.query = query;
    this.repository = repository;
    this.lastAdmin = lastAdmin;
    this.tenantGuard = tenantGuard;
    this.revocations = revocations;
  }

  /** Assigns the role to {@code userId} on behalf of the caller (the grantor taken from the security context). */
  @RetryOnDeadlock
  @Transactional
  public AssignmentView assign(UUID callerId, UUID callerAccountId, UUID userId, UUID roleId, ScopeType scopeType,
      UUID scopeId, @Nullable Instant expiresAt) {
    requireScope(scopeType, scopeId);
    RoleAssignment saved = assignments.assign(new AssignCommand(userId, roleId, scopeType, scopeId, expiresAt));
    return query.find(callerAccountId, saved.id()).orElseThrow();
  }

  /** Revokes (deletes) one assignment. */
  @RetryOnDeadlock
  @Transactional
  public void revoke(UUID callerId, UUID callerAccountId, UUID assignmentId) {
    AssignmentView target = query.find(callerAccountId, assignmentId)
        .orElseThrow(() -> new NotFoundException("assignment_not_found", "Assignment not found"));
    requireScope(target.scopeType(), target.scopeId());
    lastAdmin.requireNotLastAdminAssignment(assignmentId);          // 1. lock + check (I7)
    repository.deleteById(assignmentId);                             // 2. the delete
    revocations.revokeUsers(List.of(target.userId()), REVOKE_REASON); // 3. last write
  }

  private void requireScope(ScopeType scopeType, UUID scopeId) {
    switch (scopeType) {
      case TENANT -> tenantGuard.requireActive(scopeId, PERMISSION);
      case ACCOUNT -> {
        if (!tenantGuard.hasAccountScope(PERMISSION)) { // M3: the one ACCOUNT-scope predicate
          throw new CodedAccessDeniedException(ACCOUNT_SCOPE_REQUIRED,
              "Assigning or revoking account-wide roles requires " + PERMISSION + " at account scope",
              Map.of("requiredAuthority", PERMISSION));
        }
      }
    }
  }
}
