package com.acme.iam.audit;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * {@link AuditArchiveHook} for {@code iam.audit.archive.mode=none-acknowledged}: the operator has acknowledged that
 * expired audit data needs no archive (dev/test), so every partition may be dropped. Never use in production.
 */
public final class AcknowledgedNoArchiveHook implements AuditArchiveHook {

  private static final Logger log = LoggerFactory.getLogger(AcknowledgedNoArchiveHook.class);

  @Override
  public boolean archive(String partitionName) {
    log.warn("Audit partition {} will be dropped WITHOUT archive (iam.audit.archive.mode=none-acknowledged)",
        partitionName);
    return true;
  }
}
