package com.acme.iam.user;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.mail.MailException;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;

/**
 * SMTP {@link NotificationPort} ({@code iam.notification.mode=smtp}), sending plain-text mail through Boot's
 * {@link JavaMailSender} ({@code spring.mail.*}). Links come from {@link NotificationProperties}.
 *
 * <p>Delivery failures are logged (without the token) and rethrown; callers decide whether the business action
 * should fail (an invitation) or stay silent (forgot-password always answers 202).
 */
public class SmtpNotificationAdapter implements NotificationPort {

  private static final Logger log = LoggerFactory.getLogger(SmtpNotificationAdapter.class);

  private final JavaMailSender mail;
  private final NotificationProperties properties;

  public SmtpNotificationAdapter(JavaMailSender mail, NotificationProperties properties) {
    this.mail = mail;
    this.properties = properties;
  }

  @Override
  public void sendInvitation(String email, String accountName, String rawToken) {
    send(email, "You have been invited to " + accountName, """
        You have been invited to join %s.

        Accept the invitation and choose a password:
        %s

        The link expires in 7 days and can be used once.
        """.formatted(accountName, properties.invitationLink(rawToken)), "invitation");
  }

  @Override
  public void sendPasswordReset(String email, String rawToken) {
    send(email, "Reset your password", """
        Someone asked to reset the password of this account.

        Choose a new password:
        %s

        The link expires in 30 minutes and can be used once. If you did not ask for this, ignore this e-mail.
        """.formatted(properties.passwordResetLink(rawToken)), "password_reset");
  }

  private void send(String to, String subject, String text, String kind) {
    SimpleMailMessage message = new SimpleMailMessage();
    message.setFrom(properties.from());
    message.setTo(to);
    message.setSubject(subject);
    message.setText(text);
    try {
      mail.send(message);
      log.info("notification.{} sent to={}", kind, LoggingNotificationAdapter.mask(to));
    } catch (MailException e) {
      log.warn("notification.{} failed to={} error={}", kind, LoggingNotificationAdapter.mask(to),
          e.getClass().getSimpleName());
      throw e;
    }
  }
}
