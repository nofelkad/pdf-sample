package com.acme.iam.auth;

import com.acme.iam.account.AccountStatus;
import com.acme.iam.tenant.TenantStatus;
import com.acme.iam.user.MembershipStatus;
import com.acme.iam.user.UserStatus;
import java.time.Instant;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import org.springframework.lang.Nullable;

/**
 * Everything login, refresh, tenant switch and the password flows check about a user in one tenant, read in one
 * query by {@link AccessStateQuery}: user status, account status and settings, the tenant (only if it belongs to the
 * user's account) and the user's membership in it, and the current {@code session_version}.
 */
record AccessState(
    UUID userId,
    UUID accountId,
    String email,
    UserStatus userStatus,
    UUID primaryTenantId,
    int sessionVersion,
    @Nullable String passwordHash,
    @Nullable Instant lockedUntil,
    AccountStatus accountStatus,
    Map<String, Object> accountSettings,
    UUID requestedTenantId,
    @Nullable TenantStatus tenantStatus,
    @Nullable MembershipStatus membershipStatus) {

  static final String USER_INACTIVE = "user_inactive";
  static final String ACCOUNT_INACTIVE = "account_inactive";
  static final String TENANT_INACTIVE = "tenant_inactive";
  static final String MEMBERSHIP_INACTIVE = "membership_inactive";

  /** {@code true} while a failed-login lockout is in force. */
  boolean isLocked(Instant now) {
    return lockedUntil != null && lockedUntil.isAfter(now);
  }

  /** Why the user (or its account) may not hold a session: {@code user_inactive} or {@code account_inactive}. */
  Optional<String> userDenial() {
    if (userStatus != UserStatus.ACTIVE) {
      return Optional.of(USER_INACTIVE);
    }
    if (accountStatus != AccountStatus.ACTIVE) {
      return Optional.of(ACCOUNT_INACTIVE);
    }
    return Optional.empty();
  }

  /**
   * Why the requested tenant cannot be the active tenant: {@code tenant_inactive} (unknown, other account, not
   * ACTIVE) or {@code membership_inactive} (no membership or not ACTIVE).
   */
  Optional<String> tenantDenial() {
    if (tenantStatus != TenantStatus.ACTIVE) {
      return Optional.of(TENANT_INACTIVE);
    }
    if (membershipStatus != MembershipStatus.ACTIVE) {
      return Optional.of(MEMBERSHIP_INACTIVE);
    }
    return Optional.empty();
  }

  /** The first failing check of user, account, tenant, membership (R17), if any. */
  Optional<String> denial() {
    return userDenial().or(this::tenantDenial);
  }

  @Override
  public String toString() {
    return "AccessState[userId=" + userId + ", accountId=" + accountId + ", userStatus=" + userStatus
        + ", accountStatus=" + accountStatus + ", tenant=" + requestedTenantId + ", tenantStatus=" + tenantStatus
        + ", membershipStatus=" + membershipStatus + ", sessionVersion=" + sessionVersion + "]";
  }
}
