package com.acme.iam.account;

import com.acme.iam.account.PlatformBootstrapService.AlreadyBootstrappedException;
import com.acme.iam.account.PlatformBootstrapService.Result;
import com.acme.iam.user.NotificationPort;
import com.acme.iam.user.NotificationProperties;
import java.io.PrintStream;
import java.util.List;
import java.util.Optional;
import java.util.function.IntConsumer;
import java.util.stream.Stream;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.stereotype.Component;

/**
 * Operator entry point for P1-6.4: start the application with
 * {@code --bootstrap-platform-admin email=<email>} (or {@code --bootstrap-platform-admin=email=<email>}) to create the
 * platform tenant and invite the first Platform Admin ({@link PlatformBootstrapService}), then exit.
 *
 * <pre>{@code
 * java -jar iam-service.jar --spring.main.web-application-type=none --bootstrap-platform-admin email=ops@acme.com
 * }</pre>
 *
 * <ul>
 *   <li>Exit 0: done. With {@code iam.notification.mode=log} (a fresh install without SMTP) the accept link is
 *       printed to stdout, once (Ruling R23); otherwise it is emailed and never printed. Also exit 0 when the platform
 *       exists but its only Platform Admin is still INVITED with this email: a new invitation is issued and delivered
 *       the same way (recovery from a lost or failed email).
 *   <li>Exit 2: already bootstrapped (the {@code platform} tenant or a Platform Admin assignment exists).
 *   <li>Exit 1: missing/invalid email, a failed invitation email (the data is committed; run the same command again
 *       to reissue and re-send) or any other failure (e.g. system roles not loaded).
 * </ul>
 * Without the option this runner does nothing.
 */
@Component
public class PlatformBootstrapCommand implements ApplicationRunner {

  public static final String OPTION = "bootstrap-platform-admin";
  public static final int EXIT_OK = 0;
  public static final int EXIT_FAILED = 1;
  public static final int EXIT_ALREADY_BOOTSTRAPPED = 2;

  private final PlatformBootstrapService service;
  private final NotificationProperties notificationProperties;
  private final NotificationPort notifications;
  private final PrintStream out;
  private final PrintStream err;
  private final IntConsumer exit;

  @Autowired
  public PlatformBootstrapCommand(PlatformBootstrapService service, NotificationProperties notificationProperties,
      NotificationPort notifications, ConfigurableApplicationContext context) {
    this(service, notificationProperties, notifications, System.out, System.err,
        code -> System.exit(SpringApplication.exit(context, () -> code)));
  }

  /** For tests: output streams and the exit hook are injected. */
  PlatformBootstrapCommand(PlatformBootstrapService service, NotificationProperties notificationProperties,
      NotificationPort notifications, PrintStream out, PrintStream err, IntConsumer exit) {
    this.service = service;
    this.notificationProperties = notificationProperties;
    this.notifications = notifications;
    this.out = out;
    this.err = err;
    this.exit = exit;
  }

  @Override
  public void run(ApplicationArguments args) {
    if (!args.containsOption(OPTION)) {
      return;
    }
    Optional<String> email = email(args);
    if (email.isEmpty()) {
      err.println("Usage: --" + OPTION + " email=<email>");
      exit.accept(EXIT_FAILED);
      return;
    }
    int code;
    try {
      Result result = service.bootstrap(email.get()); // committed when it returns
      code = deliver(result);
    } catch (AlreadyBootstrappedException e) {
      err.println(e.getMessage());
      code = EXIT_ALREADY_BOOTSTRAPPED;
    } catch (RuntimeException e) {
      err.println("Platform bootstrap failed: " + e.getMessage());
      code = EXIT_FAILED;
    }
    exit.accept(code);
  }

  private int deliver(Result result) {
    if (result.reissued()) {
      out.println("Platform already bootstrapped and its Platform Admin " + result.email() + " has not accepted yet: "
          + "a new invitation was issued (earlier links no longer work), valid until " + result.token().expiresAt());
    } else {
      out.println("Platform bootstrapped: tenant " + result.tenantId() + ", Platform Admin " + result.email()
          + " invited (user " + result.userId() + ", invitation valid until " + result.token().expiresAt() + ")");
    }
    if (notificationProperties.mode() == NotificationProperties.Mode.LOG) {
      out.println("Accept the invitation: " + notificationProperties.invitationLink(result.token().rawToken()));
      return EXIT_OK;
    }
    try {
      notifications.sendInvitation(result.email(), result.accountName(), result.token().rawToken());
    } catch (RuntimeException e) {
      err.println("The invitation email could not be sent (" + e.getClass().getSimpleName() + "). The platform data "
          + "is saved; run the same command again to issue and send a new invitation.");
      return EXIT_FAILED;
    }
    out.println("The invitation was emailed to " + result.email());
    return EXIT_OK;
  }

  /** {@code email=<x>} as the option's value or as a separate argument. */
  private static Optional<String> email(ApplicationArguments args) {
    List<String> values = args.getOptionValues(OPTION);
    return Stream.concat(values == null ? Stream.empty() : values.stream(), args.getNonOptionArgs().stream())
        .filter(v -> v != null && v.startsWith("email="))
        .map(v -> v.substring("email=".length()).trim())
        .filter(v -> !v.isEmpty())
        .findFirst();
  }
}
