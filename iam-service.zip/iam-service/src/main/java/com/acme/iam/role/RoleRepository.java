package com.acme.iam.role;

import java.util.List;
import java.util.Optional;
import java.util.UUID;
import org.springframework.data.jdbc.repository.query.Query;
import org.springframework.data.repository.ListCrudRepository;

/** Persistence of the {@link Role} aggregate. Private to the {@code role} feature; use {@link RoleService}. */
public interface RoleRepository extends ListCrudRepository<Role, UUID> {

  /** SYSTEM roles of the product plus the account's CUSTOM roles (spec section 3). */
  @Query("SELECT * FROM role WHERE product_id = :productId AND (account_id IS NULL OR account_id = :accountId) ORDER BY type, name")
  List<Role> findVisible(UUID productId, UUID accountId);

  /** The SYSTEM role of a product with this (case-insensitive) name. */
  @Query("SELECT * FROM role WHERE product_id = :productId AND type = 'SYSTEM' AND lower(name) = lower(CAST(:name AS text))")
  Optional<Role> findSystemRole(UUID productId, String name);

  /** Names of the SYSTEM roles of a product. */
  @Query("SELECT name FROM role WHERE product_id = :productId AND type = 'SYSTEM' ORDER BY name")
  List<String> findSystemRoleNames(UUID productId);
}
