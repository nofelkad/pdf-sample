package com.acme.iam.product;

import java.util.Collection;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import org.springframework.data.jdbc.repository.query.Query;
import org.springframework.data.repository.ListCrudRepository;

/** Persistence of {@link Permission}. Private to the {@code product} feature; use {@link ProductService}. */
public interface PermissionRepository extends ListCrudRepository<Permission, UUID> {

  Optional<Permission> findByCode(String code);

  @Query("SELECT * FROM permission WHERE code IN (:codes)")
  List<Permission> findAllByCodes(Collection<String> codes);

  @Query("SELECT * FROM permission WHERE product_id = :productId ORDER BY code")
  List<Permission> findAllByProduct(UUID productId);
}
