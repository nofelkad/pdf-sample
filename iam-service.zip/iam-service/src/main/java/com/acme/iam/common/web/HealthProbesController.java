package com.acme.iam.common.web;

import java.util.Map;
import org.springframework.boot.actuate.autoconfigure.web.server.ConditionalOnManagementPort;
import org.springframework.boot.actuate.autoconfigure.web.server.ManagementPortType;
import org.springframework.boot.actuate.health.HealthComponent;
import org.springframework.boot.actuate.health.HealthEndpoint;
import org.springframework.boot.actuate.health.HealthEndpointGroup;
import org.springframework.boot.actuate.health.HealthEndpointGroups;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * Ruling R36 (Task 9): actuator runs on the separate management port ({@code management.server.port}, default 8081,
 * unauthenticated, network-restricted). The application port keeps only the two Kubernetes probes, served here from
 * the same health groups ({@code liveness}, {@code readiness}) with each group's HTTP status mapping (readiness: 503
 * when not ready). The body is the status only, never component details.
 *
 * <p>Active only when the management port differs from the server port; with the same port (tests) the actuator's own
 * endpoints answer these paths.
 */
@RestController
@ConditionalOnManagementPort(ManagementPortType.DIFFERENT)
public class HealthProbesController {

  private final HealthEndpoint health;
  private final HealthEndpointGroups groups;

  public HealthProbesController(HealthEndpoint health, HealthEndpointGroups groups) {
    this.health = health;
    this.groups = groups;
  }

  @GetMapping("/actuator/health/liveness")
  public ResponseEntity<Map<String, String>> liveness() {
    return probe("liveness");
  }

  @GetMapping("/actuator/health/readiness")
  public ResponseEntity<Map<String, String>> readiness() {
    return probe("readiness");
  }

  private ResponseEntity<Map<String, String>> probe(String group) {
    HealthEndpointGroup endpointGroup = groups.get(group);
    HealthComponent component = health.healthForPath(group);
    if (endpointGroup == null || component == null) {
      return ResponseEntity.status(503).body(Map.of("status", "UNKNOWN"));
    }
    int status = endpointGroup.getHttpCodeStatusMapper().getStatusCode(component.getStatus());
    return ResponseEntity.status(status).body(Map.of("status", component.getStatus().getCode()));
  }
}
