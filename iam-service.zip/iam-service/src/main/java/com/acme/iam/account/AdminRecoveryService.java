package com.acme.iam.account;

import com.acme.iam.assignment.AssignmentService;
import com.acme.iam.assignment.LastAdminService;
import com.acme.iam.assignment.ScopeType;
import com.acme.iam.audit.AuditEvent;
import com.acme.iam.audit.AuditWriter;
import com.acme.iam.common.RequestActor;
import com.acme.iam.common.error.ApiException;
import com.acme.iam.common.error.ConflictException;
import com.acme.iam.common.error.NotFoundException;
import com.acme.iam.common.jdbc.RetryOnDeadlock;
import com.acme.iam.product.Product;
import com.acme.iam.role.Role;
import com.acme.iam.role.RoleService;
import com.acme.iam.tenant.Tenant;
import com.acme.iam.tenant.TenantAdminService;
import com.acme.iam.tenant.TenantService;
import com.acme.iam.tenant.TenantStatus;
import com.acme.iam.user.AppUser;
import com.acme.iam.user.Activation;
import com.acme.iam.user.ActivationLinks;
import com.acme.iam.user.InvitationService;
import com.acme.iam.user.InvitationService.InvitationResult;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.acme.iam.user.InvitationService.InvitedUser;
import com.acme.iam.user.InvitationService.PendingInvitation;
import com.acme.iam.user.MembershipService;
import com.acme.iam.user.UserAdminService;
import com.acme.iam.user.UserService;
import com.acme.iam.user.UserStatus;
import java.time.Clock;
import java.time.Instant;
import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import org.springframework.http.HttpStatus;
import org.springframework.jdbc.core.simple.JdbcClient;
import org.springframework.lang.Nullable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * Ruling R43 (final review I5): platform recovery of an account that has no usable admin,
 * {@code POST /api/platform/accounts/{id}/admins {email, tenantId}} (platform operators only, {@code PlatformGuard} in
 * the controller). One transaction, in this order (lock order: I7 advisory lock, then rows):
 *
 * <ol>
 *   <li>the account must exist (404 {@code account_not_found}), not be CLOSED (409 {@code account_closed}) and not be
 *       the PLATFORM account (409 {@code platform_account_protected}: recover platform operators with the bootstrap
 *       CLI, runbook {@code bootstrap-platform-admin.md});
 *   <li>the account's I7 lock ({@link LastAdminService#lockAccount}), so the recovery serialises with admin removals;
 *   <li>the tenant must belong to the account (404 {@code tenant_not_found}); ARCHIVED is 409 {@code tenant_not_active};
 *       SUSPENDED is reactivated;
 *   <li>the user: an unknown email is invited into the tenant (INVITED, primary membership there, invitation mailed
 *       after commit); an existing user of the account is reused: DEPROVISIONED is 409 {@code user_deprovisioned},
 *       otherwise it gets an ACTIVE membership in the tenant (which also becomes its primary tenant when the current
 *       primary cannot be used to log in), a DISABLED user is re-enabled (ACTIVE, or INVITED when it never set a
 *       password) and an INVITED user is sent a fresh invitation;
 *   <li>{@value Role#ACCOUNT_ADMIN} at ACCOUNT scope through {@link AssignmentService#grantAsSystem} (granted by the
 *       operator, no expiry); an existing expiring grant is made permanent, so it counts for I7;
 *   <li>one {@value #AUDIT_ACTION} event filed under the recovered account (the trigger records every row change too).
 * </ol>
 * Nothing is revoked: access only grows.
 */
@Service
public class AdminRecoveryService {

  public static final String AUDIT_ACTION = "iam.account.admin_recovered";

  /**
   * What the recovery did. {@code invitationExpiresAt} is set when an invitation was (re)sent; {@code activation} then
   * carries the link (R46), unless {@code iam.notification.expose-activation-link=false}.
   */
  @JsonInclude(JsonInclude.Include.NON_NULL)
  public record RecoveredAdmin(UUID accountId, UUID tenantId, UUID userId, String email, boolean invited,
      @Nullable Instant invitationExpiresAt, boolean tenantReactivated, boolean userReactivated,
      boolean primaryTenantChanged, String grant, @Nullable Activation activation) {}

  private final AccountService accounts;
  private final TenantService tenants;
  private final TenantAdminService tenantAdmin;
  private final UserService users;
  private final InvitationService invitations;
  private final MembershipService memberships;
  private final UserAdminService userAdmin;
  private final AssignmentService assignments;
  private final RoleService roles;
  private final LastAdminService lastAdmin;
  private final AuditWriter audit;
  private final JdbcClient jdbc;
  private final Clock clock;
  private final ActivationLinks activationLinks;

  public AdminRecoveryService(AccountService accounts, TenantService tenants, TenantAdminService tenantAdmin,
      UserService users, InvitationService invitations, MembershipService memberships,
      UserAdminService userAdmin, AssignmentService assignments, RoleService roles, LastAdminService lastAdmin,
      AuditWriter audit, JdbcClient jdbc, Clock clock, ActivationLinks activationLinks) {
    this.accounts = accounts;
    this.tenants = tenants;
    this.tenantAdmin = tenantAdmin;
    this.users = users;
    this.invitations = invitations;
    this.memberships = memberships;
    this.userAdmin = userAdmin;
    this.assignments = assignments;
    this.roles = roles;
    this.lastAdmin = lastAdmin;
    this.audit = audit;
    this.jdbc = jdbc;
    this.clock = clock;
    this.activationLinks = activationLinks;
  }

  @RetryOnDeadlock
  @Transactional
  public RecoveredAdmin recover(UUID accountId, String rawEmail, UUID tenantId) {
    String email = rawEmail.trim();
    UUID operator = RequestActor.current().userUuid();
    Account account = accounts.findById(accountId)
        .orElseThrow(() -> new NotFoundException("account_not_found", "Account not found"));
    if (account.status() == AccountStatus.CLOSED) {
      throw new ConflictException("account_closed", "The account is closed");
    }
    if (account.isPlatform()) {
      throw new ConflictException("platform_account_protected",
          "Platform operators are recovered with the bootstrap command, not through the platform API");
    }
    Role adminRole = roles.findSystemRole(Product.IAM_ID, Role.ACCOUNT_ADMIN)
        .orElseThrow(() -> new ApiException(HttpStatus.INTERNAL_SERVER_ERROR, "system_role_missing",
            "The " + Role.ACCOUNT_ADMIN + " system role is not loaded"));

    lastAdmin.lockAccount(accountId); // 1. I7 lock

    Tenant tenant = tenants.findByIdInAccount(tenantId, accountId)
        .orElseThrow(() -> new NotFoundException("tenant_not_found", "Tenant not found"));
    if (tenant.status() == TenantStatus.ARCHIVED) {
      throw new ConflictException("tenant_not_active", "The tenant is archived; choose another tenant");
    }
    boolean tenantReactivated = tenant.status() == TenantStatus.SUSPENDED;
    if (tenantReactivated) {
      tenantAdmin.reactivate(accountId, tenantId);
    }

    Optional<AppUser> existing = users.findByAccountAndEmail(accountId, email);
    UUID userId;
    String userEmail;
    boolean invited = false;
    boolean userReactivated = false;
    boolean primaryChanged = false;
    Instant invitationExpiresAt = null;
    Activation activation = null;
    if (existing.isEmpty()) {
      InvitedUser created = invitations.createInvitedUser(accountId, tenantId, email, null, operator);
      userId = created.user().id();
      userEmail = created.user().email();
      invitations.notifyAfterCommit(List.of(new PendingInvitation(userEmail, account.name(),
          created.token().rawToken())));
      invited = true;
      invitationExpiresAt = created.token().expiresAt();
      activation = activationLinks.issue(created.token(), accountId, tenantId, userId,
          ActivationLinks.Via.ADMIN_RECOVERY);
    } else {
      userId = existing.get().id();
      userEmail = existing.get().email();
      primaryChanged = memberships.ensureUsableMembership(accountId, userId, tenantId); // user row, then membership
      if (existing.get().status() == UserStatus.DISABLED) {
        userAdmin.enable(accountId, userId);
        userReactivated = true;
      }
      UserStatus now = users.findByIdInAccount(userId, accountId).orElseThrow().status();
      if (now == UserStatus.INVITED) {
        InvitationResult resent = invitations.resend(accountId, userId, ActivationLinks.Via.ADMIN_RECOVERY);
        invitationExpiresAt = resent.invitationExpiresAt();
        activation = resent.activation();
        invited = true;
      }
    }

    String grant = grantPermanentAdmin(userId, adminRole.id(), accountId, operator);

    Map<String, Object> metadata = new java.util.LinkedHashMap<>();
    metadata.put("user_id", userId.toString());
    metadata.put("tenant_id", tenantId.toString());
    metadata.put("invited", invited);
    metadata.put("tenant_reactivated", tenantReactivated);
    metadata.put("user_reactivated", userReactivated);
    metadata.put("primary_tenant_changed", primaryChanged);
    metadata.put("grant", grant);
    audit.write(AuditEvent.forCurrentActor(AUDIT_ACTION).affecting(accountId, tenantId)
        .target("app_user", userId.toString()).metadata(metadata).build());
    return new RecoveredAdmin(accountId, tenantId, userId, userEmail, invited, invitationExpiresAt,
        tenantReactivated, userReactivated, primaryChanged, grant, activation);
  }

  /** {@code created}, {@code made_permanent} or {@code existing}. */
  private String grantPermanentAdmin(UUID userId, UUID roleId, UUID accountId, @Nullable UUID operator) {
    Optional<Boolean> expiring = jdbc.sql("""
            SELECT expires_at IS NOT NULL FROM role_assignment
            WHERE user_id = :u AND role_id = :r AND scope_type = 'ACCOUNT' AND scope_id = :account FOR UPDATE""")
        .param("u", userId).param("r", roleId).param("account", accountId).query(Boolean.class).optional();
    if (expiring.isEmpty()) {
      assignments.grantAsSystem(userId, roleId, ScopeType.ACCOUNT, accountId, operator, null);
      return "created";
    }
    if (!expiring.get()) {
      return "existing";
    }
    jdbc.sql("""
            UPDATE role_assignment SET expires_at = NULL, granted_by = :g, granted_at = :now, version = version + 1
            WHERE user_id = :u AND role_id = :r AND scope_type = 'ACCOUNT' AND scope_id = :account""")
        .param("g", operator).param("now", OffsetDateTime.ofInstant(clock.instant(), ZoneOffset.UTC))
        .param("u", userId).param("r", roleId).param("account", accountId)
        .update();
    return "made_permanent";
  }
}
