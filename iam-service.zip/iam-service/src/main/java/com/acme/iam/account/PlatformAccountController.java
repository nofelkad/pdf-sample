package com.acme.iam.account;

import com.acme.iam.account.AccountAdminService.AccountSummary;
import com.acme.iam.account.AccountAdminService.AccountView;
import com.acme.iam.account.AccountAdminService.CreatedAccount;
import com.acme.iam.account.AccountAdminService.DefaultTenant;
import com.acme.iam.account.AccountAdminService.DefaultUser;
import com.acme.iam.account.AccountAdminService.SubscriptionRequest;
import com.acme.iam.common.paging.KeysetPage;
import com.acme.iam.common.security.PlatformGuard;
import com.acme.iam.tenant.TenantAdminService.ProductSwitch;
import com.acme.iam.tenant.TenantAdminService.TenantView;
import jakarta.validation.Valid;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import java.net.URI;
import java.time.LocalDate;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import org.springframework.http.CacheControl;
import org.springframework.http.ResponseEntity;
import org.springframework.lang.Nullable;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/**
 * Platform account API (P1-6.1, P1-6.2). Every endpoint needs {@code platform.account.manage} <b>and</b> a token of the
 * PLATFORM account ({@code acc}) whose user holds that permission at ACCOUNT scope ({@link PlatformGuard}); anything
 * else is 403 ({@code platform_account_required} / {@code account_scope_required}, audited as {@code authz.denied}). These are the only admin endpoints not filtered by the caller's account (I10 exception).
 */
@RestController
@RequestMapping(PlatformAccountController.PATH)
public class PlatformAccountController {

  public static final String PATH = "/api/platform/accounts";

  public record SubscriptionBody(@NotBlank String code, @NotNull SubscriptionStatus status,
                                 @NotNull LocalDate startsAt, @Nullable LocalDate endsAt) {
    SubscriptionRequest toRequest() {
      return new SubscriptionRequest(code, status, startsAt, endsAt);
    }
  }

  public record DefaultTenantBody(@NotBlank @Size(max = 200) String name,
                                  @NotBlank @Pattern(regexp = "[a-zA-Z0-9][a-zA-Z0-9-]{0,62}") String slug) {}

  public record DefaultUserBody(@NotBlank @Email @Size(max = 254) String email,
                                @Nullable @Size(max = 200) String displayName) {}

  /** R46: every name of the new account, its default tenant and its default user comes from the request. */
  public record CreateAccountRequest(
      @NotBlank @Size(max = 200) String name,
      @NotBlank @Pattern(regexp = "[a-zA-Z0-9][a-zA-Z0-9-]{1,62}") String slug,
      @NotNull @Valid DefaultTenantBody defaultTenant,
      @NotNull @Valid DefaultUserBody defaultUser,
      @Nullable List<@Valid SubscriptionBody> products) {}

  public record UpdateAccountRequest(@Nullable @Size(min = 1, max = 200) String name,
                                     @Nullable Map<String, Object> settings) {}

  public record SetProductsRequest(@NotNull List<@Valid SubscriptionBody> products) {}

  public record TenantProductBody(@NotBlank String code, boolean enabled) {
    ProductSwitch toSwitch() {
      return new ProductSwitch(code, enabled);
    }
  }

  /** R46: a tenant created by the platform in an existing account. */
  public record CreateTenantRequest(
      @NotBlank @Size(max = 200) String name,
      @NotBlank @Pattern(regexp = "[a-zA-Z0-9][a-zA-Z0-9-]{0,62}") String slug,
      @Nullable List<@Valid TenantProductBody> products) {}

  /** Ruling R43: who becomes the account's admin, and the tenant they log in through. */
  public record RecoverAdminRequest(@NotBlank @Email @Size(max = 254) String email, @NotNull UUID tenantId) {}

  private final AccountAdminService service;
  private final AdminRecoveryService recovery;
  private final PlatformGuard platformGuard;

  public PlatformAccountController(AccountAdminService service, AdminRecoveryService recovery,
      PlatformGuard platformGuard) {
    this.service = service;
    this.recovery = recovery;
    this.platformGuard = platformGuard;
  }

  /**
   * P1-6.2 / R46: account + requested default tenant + invited default user (Account Admin), in one call. The response
   * carries the activation link, so it is never cached.
   */
  @PostMapping
  @PreAuthorize("hasAuthority('platform.account.manage')")
  public ResponseEntity<CreatedAccount> create(@Valid @RequestBody CreateAccountRequest request) {
    requirePlatformCaller();
    CreatedAccount created = service.create(request.name(), request.slug(),
        new DefaultTenant(request.defaultTenant().name(), request.defaultTenant().slug()),
        new DefaultUser(request.defaultUser().email(), request.defaultUser().displayName()),
        toRequests(request.products()));
    return ResponseEntity.created(URI.create(PATH + "/" + created.account().id()))
        .cacheControl(CacheControl.noStore())
        .body(created);
  }

  @GetMapping
  @PreAuthorize("hasAuthority('platform.account.manage')")
  public KeysetPage<AccountSummary> list(@RequestParam(required = false) AccountStatus status,
                                         @RequestParam(required = false) String cursor,
                                         @RequestParam(required = false) Integer limit) {
    requirePlatformCaller();
    return service.list(status, cursor, limit);
  }

  @GetMapping("/{id}")
  @PreAuthorize("hasAuthority('platform.account.manage')")
  public AccountView get(@PathVariable UUID id) {
    requirePlatformCaller();
    return service.get(id);
  }

  @PatchMapping("/{id}")
  @PreAuthorize("hasAuthority('platform.account.manage')")
  public AccountView update(@PathVariable UUID id, @Valid @RequestBody UpdateAccountRequest request) {
    requirePlatformCaller();
    return service.update(id, request.name(), request.settings());
  }

  @PostMapping("/{id}/suspend")
  @PreAuthorize("hasAuthority('platform.account.manage')")
  public AccountView suspend(@PathVariable UUID id) {
    requirePlatformCaller();
    return service.suspend(id);
  }

  @PostMapping("/{id}/reactivate")
  @PreAuthorize("hasAuthority('platform.account.manage')")
  public AccountView reactivate(@PathVariable UUID id) {
    requirePlatformCaller();
    return service.reactivate(id);
  }

  @PostMapping("/{id}/close")
  @PreAuthorize("hasAuthority('platform.account.manage')")
  public AccountView close(@PathVariable UUID id) {
    requirePlatformCaller();
    return service.close(id);
  }

  /** Replaces the account's subscriptions ({@code account_product}). */
  @PutMapping("/{id}/products")
  @PreAuthorize("hasAuthority('platform.account.manage')")
  public AccountView setProducts(@PathVariable UUID id, @Valid @RequestBody SetProductsRequest request) {
    requirePlatformCaller();
    return service.setProducts(id, toRequests(request.products()));
  }

  /** R46: tenant creation is a platform operation; customer Account Admins manage, but no longer create, tenants. */
  @PostMapping("/{id}/tenants")
  @PreAuthorize("hasAuthority('platform.account.manage')")
  public ResponseEntity<TenantView> createTenant(@PathVariable UUID id,
                                                 @Valid @RequestBody CreateTenantRequest request) {
    requirePlatformCaller();
    List<ProductSwitch> switches = request.products() == null ? List.of()
        : request.products().stream().map(TenantProductBody::toSwitch).toList();
    TenantView created = service.createTenant(id, request.name(), request.slug(), switches);
    return ResponseEntity.created(URI.create(PATH + "/" + id + "/tenants/" + created.id())).body(created);
  }

  /**
   * Ruling R43 (final review I5): recovers an account that has no usable admin. Reactivates a SUSPENDED tenant
   * (ARCHIVED: 409 {@code tenant_not_active}), invites a new user or reuses and reactivates an existing one, and grants
   * Account Admin at ACCOUNT scope without expiry. When it invites, the response carries the activation link (R46) and
   * is not cached. Runbook: {@code docs/runbooks/recover-account-admin.md}.
   */
  @PostMapping("/{id}/admins")
  @PreAuthorize("hasAuthority('platform.account.manage')")
  public ResponseEntity<AdminRecoveryService.RecoveredAdmin> recoverAdmin(@PathVariable UUID id,
      @Valid @RequestBody RecoverAdminRequest request) {
    requirePlatformCaller();
    return ResponseEntity.ok().cacheControl(CacheControl.noStore())
        .body(recovery.recover(id, request.email(), request.tenantId()));
  }

  private void requirePlatformCaller() {
    platformGuard.requireOperator();
  }

  private static List<SubscriptionRequest> toRequests(@Nullable List<SubscriptionBody> bodies) {
    return bodies == null ? List.of() : bodies.stream().map(SubscriptionBody::toRequest).toList();
  }
}
