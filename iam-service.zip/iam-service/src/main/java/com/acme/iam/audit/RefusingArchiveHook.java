package com.acme.iam.audit;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Default {@link AuditArchiveHook}: logs and returns {@code false}, so no audit partition is ever dropped unless an
 * operator configures {@code iam.audit.archive.mode=none-acknowledged} or provides a real hook.
 */
public final class RefusingArchiveHook implements AuditArchiveHook {

  private static final Logger log = LoggerFactory.getLogger(RefusingArchiveHook.class);

  @Override
  public boolean archive(String partitionName) {
    log.warn("Audit partition {} is past retention but no archive hook is configured; keeping it. Provide an "
        + "AuditArchiveHook bean, or set iam.audit.archive.mode=none-acknowledged if no archive is needed.",
        partitionName);
    return false;
  }
}
