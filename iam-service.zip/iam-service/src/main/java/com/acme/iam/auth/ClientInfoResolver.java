package com.acme.iam.auth;

import com.acme.iam.audit.AuditWriter;
import jakarta.servlet.http.HttpServletRequest;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.regex.Pattern;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.properties.bind.Bindable;
import org.springframework.boot.context.properties.bind.Binder;
import org.springframework.core.env.Environment;
import org.springframework.core.env.Profiles;
import org.springframework.http.HttpHeaders;
import org.springframework.lang.Nullable;
import org.springframework.stereotype.Component;

/**
 * Resolves the {@link ClientInfo} of a request. The client IP is {@code request.getRemoteAddr()}, unless that address
 * is a trusted proxy ({@code iam.security.trusted-proxies}: comma-separated or YAML list of IP literals and CIDR
 * ranges, e.g. {@code 10.0.0.0/8, 192.168.1.10, fd00::/8}); then it is the right-most {@code X-Forwarded-For} entry
 * that is not itself a trusted proxy (R35), provided it is an IP literal. All {@code X-Forwarded-For} header lines are
 * read and joined in order before the scan.
 *
 * <p>Final review I3: the client IP keys the per-IP rate limits (login/forgot/reset 10/min, refresh 60/min) and the
 * audit {@code actor_ip}. Behind a load balancer with no trusted proxy configured every request seems to come from the
 * load balancer, so all users share one bucket; a WARN is logged at startup when the list is empty outside the
 * {@code dev}, {@code local} and {@code test} profiles (see {@code docs/deployment.md}). A malformed entry (a host
 * name, a prefix out of range) fails startup. Addresses are compared as bytes, so equivalent IPv6 spellings match and
 * an IPv4 address never matches an IPv6 range.
 */
@Component
public class ClientInfoResolver {

  public static final String TRUSTED_PROXIES_PROPERTY = "iam.security.trusted-proxies";
  static final String FORWARDED_FOR = "X-Forwarded-For";

  private static final Logger log = LoggerFactory.getLogger(ClientInfoResolver.class);
  private static final Pattern PREFIX = Pattern.compile("\\d{1,3}");

  /** One trusted network: {@code address} with the first {@code prefix} bits significant. */
  record IpRange(byte[] address, int prefix) {

    static IpRange parse(String entry) {
      int slash = entry.indexOf('/');
      String host = slash < 0 ? entry : entry.substring(0, slash);
      byte[] address = literal(host);
      if (address == null) {
        throw invalid(entry, "not an IP literal");
      }
      int bits = address.length * 8;
      int prefix = bits;
      if (slash >= 0) {
        String digits = entry.substring(slash + 1);
        if (!PREFIX.matcher(digits).matches() || Integer.parseInt(digits) > bits) {
          throw invalid(entry, "prefix length must be 0.." + bits);
        }
        prefix = Integer.parseInt(digits);
      }
      return new IpRange(address, prefix);
    }

    boolean contains(byte[] candidate) {
      if (candidate.length != address.length) {
        return false;
      }
      int full = prefix / 8;
      for (int i = 0; i < full; i++) {
        if (candidate[i] != address[i]) {
          return false;
        }
      }
      int rest = prefix % 8;
      if (rest == 0) {
        return true;
      }
      int mask = 0xFF << (8 - rest) & 0xFF;
      return (candidate[full] & mask) == (address[full] & mask);
    }

    private static IllegalArgumentException invalid(String entry, String why) {
      return new IllegalArgumentException(TRUSTED_PROXIES_PROPERTY + ": '" + entry + "' is invalid (" + why
          + "); use IP literals or CIDR ranges such as 10.0.0.0/8");
    }
  }

  private final List<IpRange> trustedProxies;

  @Autowired
  public ClientInfoResolver(Environment environment) {
    this(Binder.get(environment).bind(TRUSTED_PROXIES_PROPERTY, Bindable.listOf(String.class)).orElse(List.of()));
    missingProxiesWarning(environment, trustedProxiesConfig(environment)).ifPresent(log::warn);
  }

  public ClientInfoResolver(List<String> trustedProxies) {
    this.trustedProxies = trustedProxies.stream()
        .map(String::trim).filter(s -> !s.isEmpty()).map(IpRange::parse).toList();
  }

  /**
   * The startup warning for an empty {@value #TRUSTED_PROXIES_PROPERTY} outside the {@code dev}, {@code local} and
   * {@code test} profiles; empty otherwise.
   */
  static Optional<String> missingProxiesWarning(Environment environment, List<String> configured) {
    boolean none = configured.stream().allMatch(String::isBlank);
    if (!none || environment.acceptsProfiles(Profiles.of("dev | local | test"))) {
      return Optional.empty();
    }
    return Optional.of(TRUSTED_PROXIES_PROPERTY + " is empty: the client IP is the TCP peer. Behind a load balancer or "
        + "ingress every request then shares the per-IP rate limits (login 10/min, refresh 60/min) and audit rows show "
        + "the proxy's address; list the proxies' addresses or CIDR ranges (docs/deployment.md)");
  }

  private static List<String> trustedProxiesConfig(Environment environment) {
    return Binder.get(environment).bind(TRUSTED_PROXIES_PROPERTY, Bindable.listOf(String.class)).orElse(List.of());
  }

  public ClientInfo resolve(HttpServletRequest request) {
    String peer = AuditWriter.normalizeIp(request.getRemoteAddr());
    String ip = peer;
    if (peer != null && isTrusted(peer)) {
      // all header lines, in order: a proxy may add its own line instead of appending to the client's
      String forwarded = forwardedClient(String.join(",", Collections.list(request.getHeaders(FORWARDED_FOR))));
      if (forwarded != null) {
        ip = forwarded;
      }
    }
    return new ClientInfo(ip, request.getHeader(HttpHeaders.USER_AGENT));
  }

  /**
   * The right-most {@code X-Forwarded-For} entry that is not a trusted proxy (R35): each proxy appends the address it
   * received the request from, so everything left of that entry is client-controlled. {@code null} when that entry
   * is not an IP literal (the caller then uses the peer address); the left-most entry when every entry is trusted.
   */
  @Nullable
  private String forwardedClient(@Nullable String header) {
    if (header == null || header.isBlank()) {
      return null;
    }
    String[] entries = header.split(",");
    for (int i = entries.length - 1; i >= 0; i--) {
      String entry = entries[i].trim();
      if (!isTrusted(entry)) {
        return AuditWriter.normalizeIp(entry);
      }
    }
    return AuditWriter.normalizeIp(entries[0].trim());
  }

  private boolean isTrusted(String raw) {
    if (trustedProxies.isEmpty()) {
      return false;
    }
    byte[] address = literal(raw);
    return address != null && trustedProxies.stream().anyMatch(range -> range.contains(address));
  }

  /** The bytes of an IPv4/IPv6 literal; {@code null} for anything else. Never performs DNS lookups. */
  @Nullable
  private static byte[] literal(String raw) {
    String ip = AuditWriter.normalizeIp(raw);
    if (ip == null || ip.contains(",")) {
      return null;
    }
    try {
      return InetAddress.getByName(ip).getAddress(); // a validated literal: parsed, not resolved
    } catch (UnknownHostException e) {
      return null;
    }
  }
}
