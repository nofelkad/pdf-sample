package com.acme.iam.audit;

import com.acme.iam.common.Ids;
import com.acme.iam.common.RequestActor;
import java.time.Instant;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Objects;
import java.util.UUID;
import org.slf4j.MDC;
import org.springframework.lang.Nullable;

/**
 * One row of {@code audit_event}. Build with {@link #builder(String)} or {@link #forCurrentActor(String)}.
 *
 * <p>Defaults applied by {@link Builder#build()}: {@code eventId} = UUIDv7, {@code occurredAt} = now,
 * {@code source} = {@value #SOURCE_IAM}, {@code outcome} = SUCCESS, {@code requestId} = MDC {@code requestId},
 * {@code actorType} = USER when {@code actorUserId} is set, otherwise SYSTEM.
 *
 * @param action {@code noun.verb}, e.g. {@code auth.login.failed}, {@code iam.audit.exported}
 */
public record AuditEvent(
    UUID eventId,
    Instant occurredAt,
    @Nullable UUID accountId,
    @Nullable UUID tenantId,
    String source,
    @Nullable UUID actorUserId,
    ActorType actorType,
    @Nullable String actorIp,
    @Nullable String userAgent,
    @Nullable UUID sessionId,
    @Nullable String requestId,
    String action,
    @Nullable String targetType,
    @Nullable String targetId,
    Outcome outcome,
    @Nullable Map<String, Object> before,
    @Nullable Map<String, Object> after,
    @Nullable Map<String, Object> metadata) {

  public static final String SOURCE_IAM = "IAM";

  public enum ActorType { USER, SYSTEM, ANONYMOUS }

  public enum Outcome { SUCCESS, DENIED, FAILURE }

  public AuditEvent {
    Objects.requireNonNull(eventId, "eventId");
    Objects.requireNonNull(occurredAt, "occurredAt");
    Objects.requireNonNull(source, "source");
    Objects.requireNonNull(actorType, "actorType");
    Objects.requireNonNull(action, "action");
    Objects.requireNonNull(outcome, "outcome");
    before = frozen(before);
    after = frozen(after);
    metadata = frozen(metadata);
  }

  /** An unmodifiable copy (insertion order and {@code null} values kept), so an event cannot change once built. */
  @Nullable
  private static Map<String, Object> frozen(@Nullable Map<String, Object> map) {
    return map == null ? null : Collections.unmodifiableMap(new LinkedHashMap<>(map));
  }

  public static Builder builder(String action) {
    return new Builder(action);
  }

  /** A builder pre-filled with {@link RequestActor#current()} (user, account, tenant, session, request id). */
  public static Builder forCurrentActor(String action) {
    return new Builder(action).actor(RequestActor.current());
  }

  public static final class Builder {
    private UUID eventId;
    private Instant occurredAt;
    private UUID accountId;
    private UUID tenantId;
    private String source = SOURCE_IAM;
    private UUID actorUserId;
    private ActorType actorType;
    private String actorIp;
    private String userAgent;
    private UUID sessionId;
    private String requestId;
    private final String action;
    private String targetType;
    private String targetId;
    private Outcome outcome = Outcome.SUCCESS;
    private Map<String, Object> before;
    private Map<String, Object> after;
    private Map<String, Object> metadata;

    private Builder(String action) {
      this.action = Objects.requireNonNull(action, "action");
    }

    /** Copies user, account, tenant, session and request id; actor type becomes USER or SYSTEM accordingly. */
    public Builder actor(RequestActor actor) {
      this.actorUserId = actor.userUuid();
      this.accountId = actor.accountUuid();
      this.tenantId = actor.tenantUuid();
      this.sessionId = actor.sessionUuid();
      this.requestId = actor.requestId();
      this.actorType = actor.isSystem() ? ActorType.SYSTEM : ActorType.USER;
      return this;
    }

    /** No authenticated actor (for example a failed login); clears the actor user. */
    public Builder anonymous() {
      this.actorUserId = null;
      this.actorType = ActorType.ANONYMOUS;
      return this;
    }

    public Builder eventId(UUID eventId) {
      this.eventId = eventId;
      return this;
    }

    public Builder occurredAt(Instant occurredAt) {
      this.occurredAt = occurredAt;
      return this;
    }

    public Builder accountId(@Nullable UUID accountId) {
      this.accountId = accountId;
      return this;
    }

    public Builder tenantId(@Nullable UUID tenantId) {
      this.tenantId = tenantId;
      return this;
    }

    /**
     * Final review C1: files the event under the <b>affected resource</b>'s account and tenant instead of the actor's
     * token (call it after {@link #actor}). When the resource has no tenant of its own ({@code tenantId == null}) the
     * actor's tenant is kept only if the resource lies in the actor's own account; otherwise the event is
     * account-level ({@code tenant_id} NULL). Same rule as the {@code iam_audit()} trigger (V60).
     */
    public Builder affecting(UUID accountId, @Nullable UUID tenantId) {
      Objects.requireNonNull(accountId, "accountId");
      UUID actorAccount = this.accountId;
      UUID actorTenant = this.tenantId;
      this.accountId = accountId;
      this.tenantId = tenantId != null ? tenantId : accountId.equals(actorAccount) ? actorTenant : null;
      return this;
    }

    public Builder source(String source) {
      this.source = source;
      return this;
    }

    public Builder actorUserId(@Nullable UUID actorUserId) {
      this.actorUserId = actorUserId;
      return this;
    }

    public Builder actorType(ActorType actorType) {
      this.actorType = actorType;
      return this;
    }

    public Builder actorIp(@Nullable String actorIp) {
      this.actorIp = actorIp;
      return this;
    }

    public Builder userAgent(@Nullable String userAgent) {
      this.userAgent = userAgent;
      return this;
    }

    public Builder sessionId(@Nullable UUID sessionId) {
      this.sessionId = sessionId;
      return this;
    }

    public Builder requestId(@Nullable String requestId) {
      this.requestId = requestId;
      return this;
    }

    public Builder target(@Nullable String targetType, @Nullable String targetId) {
      this.targetType = targetType;
      this.targetId = targetId;
      return this;
    }

    public Builder outcome(Outcome outcome) {
      this.outcome = outcome;
      return this;
    }

    public Builder before(@Nullable Map<String, ?> before) {
      this.before = copy(before);
      return this;
    }

    public Builder after(@Nullable Map<String, ?> after) {
      this.after = copy(after);
      return this;
    }

    public Builder metadata(@Nullable Map<String, ?> metadata) {
      this.metadata = copy(metadata);
      return this;
    }

    /** Adds one metadata entry ({@code null} values allowed). */
    public Builder metadata(String key, @Nullable Object value) {
      if (this.metadata == null) {
        this.metadata = new LinkedHashMap<>();
      }
      this.metadata.put(key, value);
      return this;
    }

    public AuditEvent build() {
      return new AuditEvent(
          eventId != null ? eventId : Ids.newId(),
          occurredAt != null ? occurredAt : Instant.now(),
          accountId,
          tenantId,
          source,
          actorUserId,
          actorType != null ? actorType : (actorUserId != null ? ActorType.USER : ActorType.SYSTEM),
          actorIp,
          userAgent,
          sessionId,
          requestId != null ? requestId : MDC.get(RequestActor.MDC_REQUEST_ID),
          action,
          targetType,
          targetId,
          outcome,
          before,
          after,
          metadata);
    }

    @Nullable
    private static Map<String, Object> copy(@Nullable Map<String, ?> map) {
      return map == null ? null : new LinkedHashMap<>(map);
    }
  }
}
