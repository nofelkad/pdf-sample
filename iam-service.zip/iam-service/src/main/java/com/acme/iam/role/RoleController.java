package com.acme.iam.role;

import com.acme.iam.common.error.NotFoundException;
import com.acme.iam.common.paging.KeysetPage;
import com.acme.iam.common.security.CodedAccessDeniedException;
import com.acme.iam.common.security.CurrentUser;
import com.acme.iam.common.security.TenantGuard;
import com.acme.iam.product.Product;
import com.acme.iam.product.ProductService;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import java.net.URI;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import org.springframework.http.ResponseEntity;
import org.springframework.lang.Nullable;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/**
 * Role API (P1-10.3). Reads need {@code iam.role.manage} or {@code iam.role.assign} (whoever may assign a role must be
 * able to see the roles to choose from); every write needs {@code iam.role.manage} held at ACCOUNT scope (403
 * {@code account_scope_required} otherwise). All of it is scoped to the caller's
 * account ({@code acc} claim, I10); SYSTEM roles are read-only (I8). See {@link RoleAdminService} for the rules.
 */
@RestController
@RequestMapping(RoleController.PATH)
public class RoleController {

  public static final String PATH = "/api/roles";
  public static final String MANAGE = "iam.role.manage";
  public static final String ACCOUNT_SCOPE_REQUIRED = TenantGuard.ACCOUNT_SCOPE_REQUIRED;

  public record CreateRoleRequest(
      @NotBlank @Pattern(regexp = "[A-Z][A-Z0-9_]{1,31}") String productCode,
      @NotBlank @Size(max = 100) String name,
      @Nullable @Size(max = 500) String description,
      @NotNull List<@NotBlank String> permissionCodes) {}

  /** Both fields optional; an absent one is left unchanged. */
  public record UpdateRoleRequest(
      @Nullable @Size(min = 1, max = 100) @Pattern(regexp = ".*\\S.*") String name,
      @Nullable @Size(max = 500) String description) {}

  public record SetPermissionsRequest(@NotNull List<@NotBlank String> permissionCodes) {}

  private final CurrentUser currentUser;
  private final RoleQueryService query;
  private final RoleAdminService admin;
  private final ProductService products;
  private final TenantGuard tenantGuard;

  public RoleController(CurrentUser currentUser, RoleQueryService query, RoleAdminService admin,
      ProductService products, TenantGuard tenantGuard) {
    this.currentUser = currentUser;
    this.query = query;
    this.admin = admin;
    this.products = products;
    this.tenantGuard = tenantGuard;
  }

  /** Roles visible to the account (SYSTEM + own CUSTOM), newest first, with permission and assignment counts. */
  @GetMapping
  @PreAuthorize("hasAnyAuthority('iam.role.manage','iam.role.assign')")
  public KeysetPage<RoleSummary> list(@RequestParam(required = false) @Nullable String productCode,
      @RequestParam(required = false) @Nullable RoleType type,
      @RequestParam(required = false) @Nullable String cursor,
      @RequestParam(required = false) @Nullable Integer limit) {
    UUID productId = null;
    if (productCode != null) {
      productId = products.findByCode(productCode).map(Product::id)
          .orElseThrow(() -> new NotFoundException("product_not_found", "Product not found"));
    }
    return query.list(currentUser.accountId(), new RoleListFilter(productId, type), cursor, limit);
  }

  @GetMapping("/{id}")
  @PreAuthorize("hasAnyAuthority('iam.role.manage','iam.role.assign')")
  public RoleDetail get(@PathVariable UUID id) {
    return admin.get(currentUser.accountId(), id);
  }

  @PostMapping
  @PreAuthorize("hasAuthority('iam.role.manage')")
  public ResponseEntity<RoleDetail> create(@Valid @RequestBody CreateRoleRequest request) {
    requireAccountScope();
    RoleDetail created = admin.create(currentUser.accountId(), currentUser.userId(), request.productCode(),
        request.name(), request.description(), request.permissionCodes());
    return ResponseEntity.created(URI.create(PATH + "/" + created.id())).body(created);
  }

  @PatchMapping("/{id}")
  @PreAuthorize("hasAuthority('iam.role.manage')")
  public RoleDetail update(@PathVariable UUID id, @Valid @RequestBody UpdateRoleRequest request) {
    requireAccountScope();
    return admin.update(currentUser.accountId(), id, request.name(), request.description());
  }

  /** Replaces the permission set. Any change revokes all holders of the role. */
  @PutMapping("/{id}/permissions")
  @PreAuthorize("hasAuthority('iam.role.manage')")
  public RoleDetail setPermissions(@PathVariable UUID id, @Valid @RequestBody SetPermissionsRequest request) {
    requireAccountScope();
    return admin.setPermissions(currentUser.accountId(), currentUser.userId(), id, request.permissionCodes());
  }

  /** 204, or 409 {@code role_in_use} (with {@code count}) while the role is assigned. */
  @DeleteMapping("/{id}")
  @PreAuthorize("hasAuthority('iam.role.manage')")
  public ResponseEntity<Void> delete(@PathVariable UUID id) {
    requireAccountScope();
    admin.delete(currentUser.accountId(), id);
    return ResponseEntity.noContent().build();
  }

  /**
   * CUSTOM roles are account-wide objects (assignable in every tenant), so every write needs {@value #MANAGE} through an
   * unexpired ACCOUNT-scope assignment (Task 9); a TENANT-scope grant only reads.
   */
  private void requireAccountScope() {
    if (!tenantGuard.hasAccountScope(MANAGE)) {
      throw new CodedAccessDeniedException(ACCOUNT_SCOPE_REQUIRED,
          "Creating and editing roles requires " + MANAGE + " at account scope", Map.of("requiredAuthority", MANAGE));
    }
  }
}
