package com.acme.iam.user;

import com.acme.iam.common.paging.KeysetPage;
import com.acme.iam.common.security.CurrentUser;
import com.acme.iam.common.security.TenantGuard;
import com.acme.iam.user.InvitationService.InvitationResult;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import java.util.UUID;
import org.springframework.http.CacheControl;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.lang.Nullable;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/**
 * User API (P1-8.1, P1-8.2 resend, P1-8.3 memberships), always inside the caller's account (I10).
 *
 * <ul>
 *   <li>Reads need {@code iam.user.read.account} (whole account) or {@code iam.user.read.tenant} (active tenant only).
 *   <li>Writes on a user need {@code iam.user.manage} and pass {@link UserAdminService#requireManageable} (Ruling R28):
 *       the permission at ACCOUNT scope, or a tenant-local target (status changes: not oneself).
 *   <li>Sharing needs {@code iam.user.share}, {@code requireManageable} on the shared user and
 *       {@link TenantGuard#requireActive} on the target tenant; removal needs {@code iam.user.share} and the guard on the
 *       tenant (its effect is local to that tenant); the primary-tenant change needs {@code iam.user.manage} on the user
 *       and on the target tenant.
 * </ul>
 */
@RestController
@RequestMapping(UserController.PATH)
public class UserController {

  public static final String PATH = "/api/users";
  private static final String MANAGE = UserAdminService.MANAGE;
  private static final String SHARE = "iam.user.share";

  public record UpdateUserRequest(@Nullable @Size(max = 200) String displayName) {}

  public record TenantRequest(@NotNull UUID tenantId) {}

  private final UserAdminService users;
  private final InvitationService invitations;
  private final MembershipService memberships;
  private final TenantGuard tenantGuard;
  private final CurrentUser currentUser;

  public UserController(UserAdminService users, InvitationService invitations, MembershipService memberships,
      TenantGuard tenantGuard, CurrentUser currentUser) {
    this.users = users;
    this.invitations = invitations;
    this.memberships = memberships;
    this.tenantGuard = tenantGuard;
    this.currentUser = currentUser;
  }

  @GetMapping
  @PreAuthorize("hasAnyAuthority('iam.user.read.account', 'iam.user.read.tenant')")
  public KeysetPage<UserSummary> list(@RequestParam(required = false) UUID tenantId,
                                      @RequestParam(required = false) UserStatus status,
                                      @RequestParam(required = false) UUID roleId,
                                      @RequestParam(required = false) String cursor,
                                      @RequestParam(required = false) Integer limit) {
    return users.list(new UserListFilter(tenantId, status, roleId), cursor, limit);
  }

  @GetMapping("/{id}")
  @PreAuthorize("hasAnyAuthority('iam.user.read.account', 'iam.user.read.tenant')")
  public UserView get(@PathVariable UUID id) {
    return users.get(id);
  }

  @PatchMapping("/{id}")
  @PreAuthorize("hasAuthority('iam.user.manage')")
  public UserView update(@PathVariable UUID id, @Valid @RequestBody UpdateUserRequest request) {
    users.requireManageable(id, MANAGE, false);
    return users.updateProfile(currentUser.accountId(), id, request.displayName());
  }

  @PostMapping("/{id}/disable")
  @PreAuthorize("hasAuthority('iam.user.manage')")
  public UserView disable(@PathVariable UUID id) {
    users.requireManageable(id, MANAGE, true);
    return users.disable(currentUser.accountId(), id);
  }

  @PostMapping("/{id}/enable")
  @PreAuthorize("hasAuthority('iam.user.manage')")
  public UserView enable(@PathVariable UUID id) {
    users.requireManageable(id, MANAGE, true);
    return users.enable(currentUser.accountId(), id);
  }

  @PostMapping("/{id}/deprovision")
  @PreAuthorize("hasAuthority('iam.user.manage')")
  public UserView deprovision(@PathVariable UUID id) {
    users.requireManageable(id, MANAGE, true);
    return users.deprovision(currentUser.accountId(), id);
  }

  /** Ruling R38: clears a lockout (failed logins, locked until); audited as {@code auth.unlocked}. */
  @PostMapping("/{id}/unlock")
  @PreAuthorize("hasAuthority('iam.user.manage')")
  public UserView unlock(@PathVariable UUID id) {
    users.requireManageable(id, MANAGE, false);
    return users.unlock(currentUser.accountId(), id);
  }

  /** New INVITE token (old ones invalidated), emailed after commit; the response carries the new activation link. */
  @PostMapping("/{id}/invitation/resend")
  @PreAuthorize("hasAuthority('iam.user.manage')")
  public ResponseEntity<InvitationResult> resendInvitation(@PathVariable UUID id) {
    users.requireManageable(id, MANAGE, false);
    return ResponseEntity.ok().cacheControl(CacheControl.noStore())
        .body(invitations.resend(currentUser.accountId(), id));
  }

  @PostMapping("/{id}/memberships")
  @PreAuthorize("hasAuthority('iam.user.share')")
  public ResponseEntity<UserView> addMembership(@PathVariable UUID id, @Valid @RequestBody TenantRequest request) {
    tenantGuard.requireActive(request.tenantId(), SHARE);
    users.requireManageable(id, SHARE, false); // only users you already control can be shared (R28)
    return ResponseEntity.status(HttpStatus.CREATED)
        .body(memberships.add(currentUser.accountId(), id, request.tenantId()));
  }

  @DeleteMapping("/{id}/memberships/{tenantId}")
  @PreAuthorize("hasAuthority('iam.user.share')")
  public ResponseEntity<Void> removeMembership(@PathVariable UUID id, @PathVariable UUID tenantId) {
    tenantGuard.requireActive(tenantId, SHARE);
    memberships.remove(currentUser.accountId(), id, tenantId);
    return ResponseEntity.noContent().build();
  }

  @PutMapping("/{id}/primary-tenant")
  @PreAuthorize("hasAuthority('iam.user.manage')")
  public UserView changePrimaryTenant(@PathVariable UUID id, @Valid @RequestBody TenantRequest request) {
    tenantGuard.requireActive(request.tenantId(), MANAGE);
    users.requireManageable(id, MANAGE, false);
    return memberships.changePrimary(currentUser.accountId(), id, request.tenantId());
  }
}
