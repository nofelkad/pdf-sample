package com.acme.iam.common.error;

import com.acme.iam.common.security.AuditingAccessDeniedHandler;
import com.acme.iam.common.web.RequestIdFilter;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.ConstraintViolationException;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessResourceFailureException;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.dao.OptimisticLockingFailureException;
import org.springframework.dao.QueryTimeoutException;
import org.springframework.data.relational.core.conversion.DbActionExecutionException;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ProblemDetail;
import org.springframework.http.ResponseEntity;
import org.springframework.lang.Nullable;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.core.AuthenticationException;
import org.springframework.transaction.CannotCreateTransactionException;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.context.request.NativeWebRequest;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.method.annotation.HandlerMethodValidationException;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

/**
 * Renders every error as RFC 7807 {@code application/problem+json}. Every body carries {@code code} (machine
 * readable) and {@code requestId}; {@link ApiException} properties are copied as extra members, validation failures
 * add {@code errors: [{field, message}]}.
 *
 * <p>A 403 {@link ApiException} (a service-level authorization denial such as I6 {@code grantor_lacks_permissions})
 * is also audited as {@code authz.denied} through {@link AuditingAccessDeniedHandler#auditApiDenial} (final review I1).
 *
 * <p>Spring Security exceptions are re-thrown so that the security filter chain's entry point / access-denied
 * handler (which audits {@code authz.denied}) stay in charge.
 */
@RestControllerAdvice
public class GlobalExceptionHandler extends ResponseEntityExceptionHandler {

  private static final Logger log = LoggerFactory.getLogger(GlobalExceptionHandler.class);

  public static final String CODE = "code";
  public static final String REQUEST_ID = "requestId";
  public static final String ERRORS = "errors";
  static final int RETRY_AFTER_SECONDS = 5;

  @Nullable private AuditingAccessDeniedHandler denials;

  /** Final review I1: audits 403 {@link ApiException}s as {@code authz.denied} (absent in plain unit tests). */
  @Autowired(required = false)
  void setDenials(AuditingAccessDeniedHandler denials) {
    this.denials = denials;
  }

  @ExceptionHandler(ApiException.class)
  ResponseEntity<Object> handleApi(ApiException ex, HttpServletRequest request) {
    if (denials != null) {
      denials.auditApiDenial(request, ex);
    }
    return ResponseEntity.status(ex.status()).body(problemOf(ex, request));
  }

  /**
   * The RFC 7807 body of an {@link ApiException}: its properties, {@code code} and {@code requestId}. For handlers that
   * must add headers of their own (for example {@code WWW-Authenticate} on {@code invalid_client}).
   */
  public static ProblemDetail problemOf(ApiException ex, @Nullable HttpServletRequest request) {
    ProblemDetail body = ProblemDetail.forStatusAndDetail(ex.status(), ex.detail());
    ex.properties().forEach(body::setProperty);
    body.setProperty(CODE, ex.code());
    decorate(body, request);
    return body;
  }

  @ExceptionHandler(ConstraintViolationException.class)
  ResponseEntity<Object> handleConstraintViolation(ConstraintViolationException ex, HttpServletRequest request) {
    ProblemDetail body = ProblemDetail.forStatusAndDetail(HttpStatus.BAD_REQUEST, "Request validation failed");
    body.setProperty(CODE, "validation_failed");
    body.setProperty(ERRORS, ex.getConstraintViolations().stream()
        .map(v -> Map.of("field", String.valueOf(v.getPropertyPath()), "message", v.getMessage()))
        .toList());
    return problem(body, request);
  }

  @ExceptionHandler(OptimisticLockingFailureException.class)
  ResponseEntity<Object> handleOptimisticLock(OptimisticLockingFailureException ex, HttpServletRequest request) {
    ProblemDetail body = ProblemDetail.forStatusAndDetail(HttpStatus.CONFLICT,
        "The resource was modified concurrently; reload and retry");
    body.setProperty(CODE, "concurrent_modification");
    return problem(body, request);
  }

  @ExceptionHandler(DuplicateKeyException.class)
  ResponseEntity<Object> handleDuplicateKey(DuplicateKeyException ex, HttpServletRequest request) {
    ProblemDetail body = ProblemDetail.forStatusAndDetail(HttpStatus.CONFLICT, "The resource already exists");
    body.setProperty(CODE, "duplicate");
    return problem(body, request);
  }

  /**
   * Spring Data JDBC repositories wrap driver/translation errors in {@link DbActionExecutionException} (ruling R12):
   * a {@link DuplicateKeyException} cause renders as 409 {@code duplicate}, any other
   * {@link DataIntegrityViolationException} (FK, NOT NULL, CHECK) as 409 {@code conflict}; anything else is a 500.
   * The database message is never exposed.
   */
  @ExceptionHandler(DbActionExecutionException.class)
  ResponseEntity<Object> handleDbAction(DbActionExecutionException ex, HttpServletRequest request) {
    Throwable cause = ex.getCause();
    if (cause instanceof DuplicateKeyException duplicate) {
      return handleDuplicateKey(duplicate, request);
    }
    if (cause instanceof OptimisticLockingFailureException optimistic) {
      return handleOptimisticLock(optimistic, request);
    }
    if (cause instanceof DataAccessResourceFailureException || cause instanceof QueryTimeoutException) {
      return handleDatabaseUnavailable((Exception) cause, request);
    }
    if (cause instanceof DataIntegrityViolationException) {
      log.debug("Data integrity violation on {} {}", request.getMethod(), request.getRequestURI(), ex);
      ProblemDetail body = ProblemDetail.forStatusAndDetail(HttpStatus.CONFLICT,
          "The change conflicts with existing data");
      body.setProperty(CODE, "conflict");
      return problem(body, request);
    }
    return handleUnexpected(ex, request);
  }

  /**
   * Task 9 (failure modes): the database is unreachable or too slow (pool timeout, connect/socket timeout, I/O error).
   * 503 {@code database_unavailable} with {@code Retry-After: 5}; the driver message is never exposed. Requests fail
   * within {@code spring.datasource.hikari.connection-timeout} instead of hanging.
   */
  @ExceptionHandler({CannotCreateTransactionException.class, DataAccessResourceFailureException.class,
      QueryTimeoutException.class})
  ResponseEntity<Object> handleDatabaseUnavailable(Exception ex, HttpServletRequest request) {
    log.warn("Database unavailable on {} {}: {}", request.getMethod(), request.getRequestURI(), ex.getMessage());
    ProblemDetail body = ProblemDetail.forStatusAndDetail(HttpStatus.SERVICE_UNAVAILABLE,
        "The service is temporarily unavailable; retry later");
    body.setProperty(CODE, "database_unavailable");
    decorate(body, request);
    return ResponseEntity.status(HttpStatus.SERVICE_UNAVAILABLE)
        .header(HttpHeaders.RETRY_AFTER, String.valueOf(RETRY_AFTER_SECONDS))
        .body(body);
  }

  /** Let Spring Security's ExceptionTranslationFilter handle these (401 entry point, audited 403 handler). */
  @ExceptionHandler({AccessDeniedException.class, AuthenticationException.class})
  void rethrowSecurity(RuntimeException ex) {
    throw ex;
  }

  @ExceptionHandler(Exception.class)
  ResponseEntity<Object> handleUnexpected(Exception ex, HttpServletRequest request) {
    log.error("Unhandled exception on {} {}", request.getMethod(), request.getRequestURI(), ex);
    ProblemDetail body = ProblemDetail.forStatusAndDetail(HttpStatus.INTERNAL_SERVER_ERROR, "Internal error");
    body.setProperty(CODE, "internal_error");
    return problem(body, request);
  }

  @Override
  protected ResponseEntity<Object> handleMethodArgumentNotValid(
      MethodArgumentNotValidException ex, HttpHeaders headers, HttpStatusCode status, WebRequest request) {
    ProblemDetail body = ex.getBody();
    body.setDetail("Request validation failed");
    body.setProperty(CODE, "validation_failed");
    List<Map<String, String>> errors = new ArrayList<>();
    for (FieldError fe : ex.getBindingResult().getFieldErrors()) {
      errors.add(Map.of("field", fe.getField(), "message", String.valueOf(fe.getDefaultMessage())));
    }
    ex.getBindingResult().getGlobalErrors().forEach(ge ->
        errors.add(Map.of("field", ge.getObjectName(), "message", String.valueOf(ge.getDefaultMessage()))));
    body.setProperty(ERRORS, errors);
    return handleExceptionInternal(ex, body, headers, status, request);
  }

  @Override
  protected ResponseEntity<Object> handleHandlerMethodValidationException(
      HandlerMethodValidationException ex, HttpHeaders headers, HttpStatusCode status, WebRequest request) {
    ProblemDetail body = ex.getBody();
    body.setDetail("Request validation failed");
    body.setProperty(CODE, "validation_failed");
    List<Map<String, String>> errors = ex.getParameterValidationResults().stream()
        .flatMap(r -> r.getResolvableErrors().stream().map(e -> Map.of(
            "field", r.getMethodParameter().getParameterName() == null
                ? "arg" + r.getMethodParameter().getParameterIndex()
                : r.getMethodParameter().getParameterName(),
            "message", String.valueOf(e.getDefaultMessage()))))
        .toList();
    body.setProperty(ERRORS, errors);
    return handleExceptionInternal(ex, body, headers, status, request);
  }

  /** Adds {@code code} (derived from the status when absent) and {@code requestId} to every Spring MVC error. */
  @Override
  protected ResponseEntity<Object> handleExceptionInternal(
      Exception ex, @Nullable Object body, HttpHeaders headers, HttpStatusCode statusCode, WebRequest request) {
    ResponseEntity<Object> response = super.handleExceptionInternal(ex, body, headers, statusCode, request);
    if (response != null && response.getBody() instanceof ProblemDetail problem) {
      decorate(problem, request instanceof NativeWebRequest nwr ? nwr.getNativeRequest(HttpServletRequest.class) : null);
    }
    return response;
  }

  private ResponseEntity<Object> problem(ProblemDetail body, HttpServletRequest request) {
    decorate(body, request);
    return ResponseEntity.status(body.getStatus()).body(body);
  }

  private static void decorate(ProblemDetail problem, @Nullable HttpServletRequest request) {
    Map<String, Object> props = problem.getProperties();
    if (props == null || !props.containsKey(CODE)) {
      problem.setProperty(CODE, defaultCode(problem.getStatus()));
    }
    String requestId = RequestIdFilter.currentRequestId(request);
    if (requestId != null) {
      problem.setProperty(REQUEST_ID, requestId);
    }
  }

  private static String defaultCode(int status) {
    HttpStatus resolved = HttpStatus.resolve(status);
    return resolved == null ? "error" : resolved.name().toLowerCase(Locale.ROOT);
  }
}
