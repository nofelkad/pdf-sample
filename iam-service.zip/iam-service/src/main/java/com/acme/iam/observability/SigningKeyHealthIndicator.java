package com.acme.iam.observability;

import com.acme.iam.common.security.SigningKeyService;
import org.springframework.boot.actuate.health.Health;
import org.springframework.boot.actuate.health.HealthIndicator;
import org.springframework.boot.actuate.health.Status;
import org.springframework.stereotype.Component;

/**
 * Contributor {@code signingKey} of the {@code readiness} health group: UP while an ACTIVE signing key is loaded
 * (without it no token can be issued). {@link ReadinessStatus#NOT_READY} otherwise, never DOWN, so the aggregate
 * health is unaffected (see {@link RevocationFreshnessHealthIndicator}).
 */
@Component
public class SigningKeyHealthIndicator implements HealthIndicator {

  private final SigningKeyService keys;

  public SigningKeyHealthIndicator(SigningKeyService keys) {
    this.keys = keys;
  }

  @Override
  public Health health() {
    try {
      return Health.status(Status.UP).withDetail("kid", keys.activeKeyId()).build();
    } catch (RuntimeException e) {
      return Health.status(ReadinessStatus.NOT_READY).withDetail("reason", "no ACTIVE signing key loaded").build();
    }
  }
}
