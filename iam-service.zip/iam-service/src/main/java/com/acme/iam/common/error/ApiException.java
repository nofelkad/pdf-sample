package com.acme.iam.common.error;

import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Objects;
import org.springframework.http.HttpStatus;

/**
 * Base class for errors that map to a specific HTTP response. Rendered by {@link GlobalExceptionHandler} as an
 * RFC 7807 {@code ProblemDetail} carrying {@code code}, {@code requestId} and every entry of {@link #properties()}.
 *
 * <p>{@code code} is a stable, machine-readable snake_case identifier (for example {@code last_admin}); {@code detail}
 * is human readable and must not contain secrets.
 */
public class ApiException extends RuntimeException {

  private final HttpStatus status;
  private final String code;
  private final String detail;
  private final Map<String, Object> properties;

  public ApiException(HttpStatus status, String code, String detail) {
    this(status, code, detail, Map.of());
  }

  public ApiException(HttpStatus status, String code, String detail, Map<String, Object> properties) {
    super(detail);
    this.status = Objects.requireNonNull(status, "status");
    this.code = Objects.requireNonNull(code, "code");
    this.detail = Objects.requireNonNull(detail, "detail");
    this.properties = Collections.unmodifiableMap(new LinkedHashMap<>(Objects.requireNonNull(properties, "properties")));
  }

  public HttpStatus status() {
    return status;
  }

  public String code() {
    return code;
  }

  public String detail() {
    return detail;
  }

  /** Extra ProblemDetail members (for example {@code tenantId}); never {@code null}. */
  public Map<String, Object> properties() {
    return properties;
  }
}
