package com.acme.iam.user;

import com.acme.iam.account.Account;
import com.acme.iam.account.AccountService;
import com.acme.iam.assignment.AssignmentService;
import com.acme.iam.assignment.PermissionResolver;
import com.acme.iam.audit.AuditEvent;
import com.acme.iam.audit.AuditWriter;
import com.acme.iam.common.Ids;
import com.acme.iam.common.RequestActor;
import com.acme.iam.common.error.ApiException;
import com.acme.iam.common.error.ConflictException;
import com.acme.iam.common.error.NotFoundException;
import com.acme.iam.common.security.TenantGuard;
import com.acme.iam.product.Product;
import com.acme.iam.role.Role;
import com.acme.iam.role.RoleService;
import com.acme.iam.tenant.Tenant;
import com.acme.iam.tenant.TenantService;
import com.acme.iam.user.BulkInviteCsv.Row;
import com.acme.iam.user.InvitationService.PendingInvitation;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.InputStream;
import java.security.SecureRandom;
import java.time.Clock;
import java.time.Duration;
import java.time.Instant;
import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.util.ArrayList;
import java.util.Base64;
import java.util.HashMap;
import java.util.HashSet;
import java.util.HexFormat;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.task.TaskRejectedException;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.http.HttpStatus;
import org.springframework.jdbc.core.simple.JdbcClient;
import org.springframework.lang.Nullable;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.support.TransactionTemplate;

/**
 * Bulk invite from CSV (P1-8.4): {@link #submit} parses the file (≤ {@value #MAX_ROWS} rows), records a
 * {@code bulk_invite_job} and runs it asynchronously on a small bounded executor; {@link #get} reports status, counts
 * and per-row errors.
 *
 * <p><b>Validate everything first.</b> Every row is checked before anything is written: email format, duplicates in
 * the file, existing users of the account, role names resolvable to a role visible to the account (SYSTEM roles and
 * the account's CUSTOM roles, case-insensitive; ambiguous names are rejected), I8 (Platform Admin only in the PLATFORM
 * account) and I6 (the submitter holds every grantable permission of the role in the tenant, checked once per distinct
 * role). Any invalid row ends the job FAILED with all errors and nothing inserted.
 *
 * <p><b>Parity with the Java rules (final review M4).</b> The role checks here and the set-based insert below
 * re-implement, for speed, what {@code AssignmentService.assign} enforces for {@code POST /api/users/{id}/assignments}
 * and invite-with-roles: the {@code TenantGuard} scope rule for {@code iam.role.assign} (checked on the request thread
 * in {@link #submit} when any row names a role: 403 {@code scope_exceeded}), I6 with {@code iam.role.assign}
 * ({@link #checkRoles}), the R40 exemption for SYSTEM roles of non-IAM products ({@code product_not_entitled}), I8,
 * and I1/I3 in the insert statement. A change to one must be made to the other; {@code AssignmentPathParityIT} runs
 * the same grantor/role/tenant through all three paths and expects the same outcome.
 *
 * <p><b>Then insert</b> in one transaction, in batches of {@value #BATCH_SIZE} set-based statements
 * ({@code INSERT … SELECT FROM unnest(…)}): users (INVITED), primary memberships, TENANT-scope assignments (the
 * statement re-checks I1: user in the account, tenant ACTIVE in the account, ACTIVE membership; I3: SYSTEM or own
 * CUSTOM role; I8; a shortfall aborts the job) and INVITE tokens (7 days). The emails are sent after commit.
 *
 * <p>The executor ({@code iam.bulk-invite.threads}, {@code iam.bulk-invite.queue-capacity}) is owned by this service
 * rather than exposed as an {@code Executor} bean, so Boot's {@code applicationTaskExecutor} stays in place. A full
 * queue is a 503 {@code bulk_invite_busy}. A job whose instance stops is marked FAILED ({@code job_interrupted}) by
 * {@link #failStaleJobs} (Ruling R29). A user created concurrently with the same email fails the job as
 * {@code user_exists}. Rows with control characters (including NUL) are rejected ({@code invalid_characters}).
 * Failures are logged with the exception class and SQLSTATE only, never the database message (it carries emails).
 */
@Service
public class BulkInviteService implements DisposableBean {

  public static final int MAX_ROWS = 5000;
  public static final int BATCH_SIZE = 500;
  public static final String AUDIT_COMPLETED = "iam.bulk_invite.completed";
  public static final String AUDIT_FAILED = "iam.bulk_invite.failed";

  private static final Logger log = LoggerFactory.getLogger(BulkInviteService.class);
  private static final Pattern EMAIL = Pattern.compile("^[^@\\s,;]{1,64}@[^@\\s,;]+\\.[^@\\s,;]+$");
  private static final int MAX_EMAIL = 254;
  private static final int MAX_DISPLAY_NAME = 200;
  private static final SecureRandom RANDOM = new SecureRandom();
  private static final TypeReference<List<RowError>> ERRORS = new TypeReference<>() {};

  public enum JobStatus { PENDING, RUNNING, COMPLETED, FAILED }

  /** A rejected row: {@code row} is the line in the file (0 for job-level errors). */
  public record RowError(int row, @Nullable String email, String code, String message) {}

  public record JobView(UUID id, UUID tenantId, JobStatus status, int totalRows, int createdCount, int errorCount,
      List<RowError> errors, Instant createdAt, @Nullable Instant startedAt, @Nullable Instant finishedAt) {}

  /** A submitted job (package-private for tests). */
  record Job(UUID id, UUID accountId, UUID tenantId, @Nullable UUID grantor, int totalRows) {}

  /** The job is no longer in the state this worker expects (the R29 sweep failed it); its transaction rolls back. */
  private static final class JobInterruptedException extends RuntimeException {
    JobInterruptedException() {
      super(null, null, false, false);
    }
  }

  private record ValidRow(String email, @Nullable String displayName, @Nullable UUID roleId) {}

  private final JdbcClient jdbc;
  private final TenantService tenants;
  private final AccountService accounts;
  private final RoleService roles;
  private final PermissionResolver resolver;
  private final InvitationService invitations;
  private final AuditWriter auditWriter;
  private final ObjectMapper json;
  private final TenantGuard tenantGuard;
  private final Clock clock;
  private final TransactionTemplate tx;
  private final ThreadPoolTaskExecutor executor;
  @Nullable private volatile Runnable afterValidation;

  public BulkInviteService(JdbcClient jdbc, TenantService tenants, AccountService accounts, RoleService roles,
      PermissionResolver resolver, InvitationService invitations, AuditWriter auditWriter, ObjectMapper json,
      TenantGuard tenantGuard, Clock clock, PlatformTransactionManager transactionManager,
      @Value("${iam.bulk-invite.threads:2}") int threads,
      @Value("${iam.bulk-invite.queue-capacity:20}") int queueCapacity) {
    this.jdbc = jdbc;
    this.tenants = tenants;
    this.accounts = accounts;
    this.roles = roles;
    this.resolver = resolver;
    this.invitations = invitations;
    this.auditWriter = auditWriter;
    this.json = json;
    this.tenantGuard = tenantGuard;
    this.clock = clock;
    this.tx = new TransactionTemplate(transactionManager);
    this.executor = new ThreadPoolTaskExecutor();
    executor.setCorePoolSize(threads);
    executor.setMaxPoolSize(threads);
    executor.setQueueCapacity(queueCapacity);
    executor.setThreadNamePrefix("bulk-invite-");
    executor.setWaitForTasksToCompleteOnShutdown(true);
    executor.setAwaitTerminationSeconds(30);
    executor.initialize();
  }

  /**
   * Parses the CSV, records a PENDING job and starts it in the background.
   *
   * @return the job id (poll {@link #get})
   * @throws com.acme.iam.common.error.BadRequestException {@code invalid_csv}, {@code empty_file},
   *     {@code too_many_rows}
   * @throws NotFoundException {@code tenant_not_found}
   * @throws ConflictException {@code tenant_not_active}
   * @throws ApiException 503 {@code bulk_invite_busy} when the job queue is full
   */
  public UUID submit(UUID accountId, UUID tenantId, InputStream csv) {
    List<Row> rows = BulkInviteCsv.parse(csv, MAX_ROWS);
    requireActiveTenant(accountId, tenantId);
    if (rows.stream().anyMatch(r -> r.roleName() != null)) {
      // M4: the scope rule of AssignmentService.assign, on the request thread (403 scope_exceeded, audited)
      tenantGuard.requireActive(tenantId, AssignmentService.ROLE_ASSIGN);
    }
    Authentication caller = SecurityContextHolder.getContext().getAuthentication();
    String requestId = MDC.get(RequestActor.MDC_REQUEST_ID);
    Job job = new Job(Ids.newId(), accountId, tenantId, RequestActor.current().userUuid(), rows.size());
    tx.executeWithoutResult(s -> jdbc.sql("""
            INSERT INTO bulk_invite_job (id, account_id, tenant_id, created_by, status, total_rows, created_at)
            VALUES (:id, :account, :tenant, :createdBy, 'PENDING', :total, :now)""")
        .param("id", job.id()).param("account", accountId).param("tenant", tenantId)
        .param("createdBy", job.grantor()).param("total", rows.size()).param("now", now())
        .update());
    try {
      executor.execute(() -> runAs(caller, requestId, () -> run(job, rows)));
    } catch (TaskRejectedException e) {
      finish(job, JobStatus.FAILED, 0, List.of(new RowError(0, null, "bulk_invite_busy", "Too many bulk invites")),
          JobStatus.PENDING);
      throw new ApiException(HttpStatus.SERVICE_UNAVAILABLE, "bulk_invite_busy",
          "Too many bulk invites are running; try again later");
    }
    return job.id();
  }

  /**
   * The job, if it belongs to the account (I10).
   *
   * @throws NotFoundException {@code bulk_invite_not_found}
   */
  public JobView get(UUID accountId, UUID jobId) {
    return jdbc.sql("""
            SELECT id, tenant_id, status, total_rows, created_count, error_count, errors::text AS errors,
                   created_at, started_at, finished_at
            FROM bulk_invite_job WHERE id = :id AND account_id = :account""")
        .param("id", jobId).param("account", accountId)
        .query((rs, i) -> new JobView(
            rs.getObject("id", UUID.class), rs.getObject("tenant_id", UUID.class),
            JobStatus.valueOf(rs.getString("status")), rs.getInt("total_rows"), rs.getInt("created_count"),
            rs.getInt("error_count"), readErrors(rs.getString("errors")),
            instant(rs.getObject("created_at", OffsetDateTime.class)),
            instant(rs.getObject("started_at", OffsetDateTime.class)),
            instant(rs.getObject("finished_at", OffsetDateTime.class))))
        .optional()
        .orElseThrow(() -> new NotFoundException("bulk_invite_not_found", "Bulk invite job not found"));
  }

  @Override
  public void destroy() {
    executor.shutdown();
  }

  // --------------------------------------------------------------------------------------------- the job

  /**
   * Runs one job. Every state change is a compare-and-set on {@code status}: PENDING → RUNNING at the start (a job the
   * R29 sweep already failed is skipped) and RUNNING → COMPLETED/FAILED at the end (if the sweep failed it meanwhile,
   * the insert transaction rolls back and nothing is emailed). Package-private for tests.
   */
  void run(Job job, List<Row> rows) {
    try {
      Integer started = tx.execute(s -> jdbc.sql("""
              UPDATE bulk_invite_job SET status = 'RUNNING', started_at = :now
              WHERE id = :id AND status = 'PENDING'""")
          .param("now", now()).param("id", job.id()).update());
      if (started == null || started == 0) {
        log.warn("bulk_invite.not_pending job={} (already failed by the sweep); skipped", job.id());
        return;
      }
      List<RowError> errors = new ArrayList<>();
      List<ValidRow> valid = validate(job, rows, errors);
      if (!errors.isEmpty()) {
        finish(job, JobStatus.FAILED, 0, errors, JobStatus.RUNNING);
        return;
      }
      Runnable hook = afterValidation;
      if (hook != null) {
        hook.run();
      }
      tx.executeWithoutResult(s -> insertAll(job, valid));
    } catch (JobInterruptedException e) {
      log.warn("bulk_invite.interrupted job={} (failed by the sweep while running); rolled back", job.id());
    } catch (DuplicateKeyException e) {
      // a user with one of the emails was created between validation and insert; the transaction rolled back
      log.warn("bulk_invite.duplicate job={} sqlState={}", job.id(), sqlState(e));
      finishQuietly(job, List.of(new RowError(0, null, "user_exists",
          "A user with one of these emails was created while the job ran; nothing was inserted")));
    } catch (RuntimeException e) {
      // never log the exception itself: PostgreSQL messages carry row values (emails)
      log.error("bulk_invite.failed job={} error={} sqlState={}", job.id(), e.getClass().getSimpleName(),
          sqlState(e));
      finishQuietly(job, List.of(new RowError(0, null, "internal_error", "The job failed; nothing was inserted")));
    }
  }

  /**
   * Ruling R29: marks jobs that can no longer finish as FAILED with {@code job_interrupted}: RUNNING jobs started, and
   * PENDING jobs created, more than {@code staleAfter} ago (their instance stopped or crashed). Called by
   * {@link BulkInviteSweepJob} at startup and periodically.
   *
   * @return number of jobs marked
   */
  public int failStaleJobs(Duration staleAfter) {
    OffsetDateTime cutoff = OffsetDateTime.ofInstant(clock.instant().minus(staleAfter), ZoneOffset.UTC);
    String errors = writeErrors(List.of(new RowError(0, null, "job_interrupted",
        "The job was interrupted (the service stopped); nothing was inserted. Submit the file again.")));
    Integer marked = tx.execute(s -> {
      List<Map<String, Object>> rows = jdbc.sql("""
              UPDATE bulk_invite_job
              SET status = 'FAILED', created_count = 0, error_count = 1, errors = CAST(:errors AS jsonb),
                  finished_at = :now
              WHERE (status = 'RUNNING' AND started_at < :cutoff) OR (status = 'PENDING' AND created_at < :cutoff)
              RETURNING id, account_id, tenant_id, total_rows""")
          .param("errors", errors).param("now", now()).param("cutoff", cutoff)
          .query().listOfRows();
      for (Map<String, Object> row : rows) {
        auditWriter.write(AuditEvent.forCurrentActor(AUDIT_FAILED)
            .accountId((UUID) row.get("account_id"))
            .tenantId((UUID) row.get("tenant_id"))
            .target("bulk_invite_job", row.get("id").toString())
            .outcome(AuditEvent.Outcome.FAILURE)
            .metadata(Map.of("reason", "job_interrupted", "total_rows", row.get("total_rows")))
            .build());
      }
      return rows.size();
    });
    return marked == null ? 0 : marked;
  }

  /** Test hook: runs between validation and the insert transaction ({@code null} to clear). */
  void afterValidationForTests(@Nullable Runnable hook) {
    this.afterValidation = hook;
  }

  private void finishQuietly(Job job, List<RowError> errors) {
    try {
      finish(job, JobStatus.FAILED, 0, errors, JobStatus.RUNNING);
    } catch (RuntimeException e) {
      log.error("bulk_invite.finish_failed job={} error={} sqlState={}", job.id(), e.getClass().getSimpleName(),
          sqlState(e));
    }
  }

  @Nullable
  private static String sqlState(Throwable e) {
    for (Throwable t = e; t != null; t = t.getCause()) {
      if (t instanceof java.sql.SQLException sql) {
        return sql.getSQLState();
      }
    }
    return null;
  }

  /** Every check, no writes. Errors are collected per row in file order. */
  private List<ValidRow> validate(Job job, List<Row> rows, List<RowError> errors) {
    Map<String, Integer> firstLine = new HashMap<>();
    Set<String> emailsToCheck = new HashSet<>();
    for (Row row : rows) {
      if (isEmail(row.email())) {
        emailsToCheck.add(row.email().toLowerCase(Locale.ROOT));
      }
    }
    Set<String> existing = existingEmails(job.accountId(), emailsToCheck);
    Map<String, RoleCheck> roleChecks = checkRoles(job, rows);

    List<ValidRow> valid = new ArrayList<>();
    for (Row row : rows) {
      String email = row.email();
      String key = email.toLowerCase(Locale.ROOT);
      if (row.columns() > 3) {
        errors.add(error(row, "invalid_columns", "Expected at most 3 columns: email,displayName,roleName"));
      } else if (hasControlCharacters(email) || hasControlCharacters(row.displayName())
          || hasControlCharacters(row.roleName())) {
        errors.add(error(row, "invalid_characters", "The row contains control characters"));
      } else if (!isEmail(email)) {
        errors.add(error(row, "invalid_email", "Not a valid email address"));
      } else if (firstLine.containsKey(key)) {
        errors.add(error(row, "duplicate_in_file", "Same email as row " + firstLine.get(key)));
      } else if (existing.contains(key)) {
        errors.add(error(row, "user_exists", "A user with this email already exists in the account"));
      } else if (row.displayName() != null && row.displayName().length() > MAX_DISPLAY_NAME) {
        errors.add(error(row, "invalid_display_name", "displayName is longer than " + MAX_DISPLAY_NAME));
      } else if (row.roleName() != null && roleChecks.get(row.roleName().toLowerCase(Locale.ROOT)).error() != null) {
        RoleCheck check = roleChecks.get(row.roleName().toLowerCase(Locale.ROOT));
        errors.add(error(row, check.error(), check.message()));
      } else {
        UUID roleId = row.roleName() == null ? null : roleChecks.get(row.roleName().toLowerCase(Locale.ROOT)).roleId();
        valid.add(new ValidRow(email, row.displayName(), roleId));
      }
      firstLine.putIfAbsent(key, row.line());
    }
    return valid;
  }

  private record RoleCheck(@Nullable UUID roleId, @Nullable String error, @Nullable String message) {}

  /** Resolves each distinct role name once and checks I8 and I6 for it. */
  private Map<String, RoleCheck> checkRoles(Job job, List<Row> rows) {
    Set<String> names = rows.stream().map(Row::roleName).filter(n -> n != null)
        .map(n -> n.toLowerCase(Locale.ROOT)).collect(Collectors.toCollection(HashSet::new));
    Map<String, RoleCheck> result = new HashMap<>();
    if (names.isEmpty()) {
      return result;
    }
    Map<String, List<UUID>> byName = new HashMap<>();
    jdbc.sql("""
            SELECT id, lower(name) AS name FROM role
            WHERE lower(name) = ANY (CAST(:names AS text[])) AND (account_id IS NULL OR account_id = :account)""")
        .param("names", PgArrays.text(names)).param("account", job.accountId())
        .query((rs, i) -> Map.entry(rs.getString("name"), rs.getObject("id", UUID.class)))
        .list()
        .forEach(e -> byName.computeIfAbsent(e.getKey(), k -> new ArrayList<>()).add(e.getValue()));

    Account account = accounts.getById(job.accountId());
    Set<String> held = null;
    for (String name : names) {
      List<UUID> ids = byName.getOrDefault(name, List.of());
      if (ids.isEmpty()) {
        result.put(name, new RoleCheck(null, "unknown_role", "No role with this name is visible to the account"));
        continue;
      }
      if (ids.size() > 1) {
        result.put(name, new RoleCheck(null, "ambiguous_role", "Several roles have this name"));
        continue;
      }
      Role role = roles.getById(ids.get(0));
      if (role.isPlatformAdmin() && !account.isPlatform()) {
        result.put(name, new RoleCheck(null, "platform_role_restricted",
            "Platform Admin is assignable only inside the platform account"));
        continue;
      }
      if (job.grantor() == null) {
        result.put(name, new RoleCheck(null, "grantor_required", "Role assignment requires an authenticated user"));
        continue;
      }
      if (held == null) {
        held = resolver.resolveGrantorAtTenant(job.grantor(), job.tenantId());
      }
      boolean productSystemRole = role.isSystem() && !Product.IAM_ID.equals(role.product());
      if (productSystemRole && !enabledInTenant(job, role.product())) {
        result.put(name, new RoleCheck(null, AssignmentService.PRODUCT_NOT_ENTITLED,
            "The role's product is not enabled in this tenant"));
        continue;
      }
      // R40: a SYSTEM role of a non-IAM product needs only iam.role.assign (and permissions of other products)
      Set<String> missing = new HashSet<>(productSystemRole ? roles.grantablePermissionCodesOfOtherProducts(role)
          : roles.grantablePermissionCodes(role));
      missing.add(AssignmentService.ROLE_ASSIGN); // Task 9: like AssignmentService.assign, the grantor needs it too
      missing.removeAll(held);
      if (!missing.isEmpty()) {
        result.put(name, new RoleCheck(null, "grantor_lacks_permissions",
            "You do not hold " + missing.stream().sorted().collect(Collectors.joining(", "))));
        continue;
      }
      result.put(name, new RoleCheck(role.id(), null, null));
    }
    return result;
  }

  /** The product is subscribed by the job's account (ACTIVE/TRIAL, not ended) and enabled in its tenant (R40). */
  private boolean enabledInTenant(Job job, UUID productId) {
    return jdbc.sql("""
            SELECT EXISTS (
              SELECT 1 FROM tenant_product tp
              JOIN tenant t ON t.id = tp.tenant
              JOIN account_product ap ON ap.account = t.account_id AND ap.product_id = tp.product_id
              WHERE tp.tenant = :tenant AND t.account_id = :account AND tp.product_id = :product AND tp.enabled
                AND ap.status IN ('ACTIVE', 'TRIAL') AND (ap.ends_at IS NULL OR ap.ends_at >= CURRENT_DATE))""")
        .param("tenant", job.tenantId()).param("account", job.accountId()).param("product", productId)
        .query(Boolean.class).single();
  }

  private Set<String> existingEmails(UUID accountId, Set<String> emails) {
    Set<String> existing = new HashSet<>();
    List<String> all = List.copyOf(emails);
    for (int from = 0; from < all.size(); from += BATCH_SIZE) {
      List<String> batch = all.subList(from, Math.min(from + BATCH_SIZE, all.size()));
      existing.addAll(jdbc.sql("""
              SELECT lower(email::text) FROM app_user
              WHERE account_id = :account AND email = ANY (CAST(:emails AS citext[]))""")
          .param("account", accountId).param("emails", PgArrays.text(batch))
          .query(String.class).list());
    }
    return existing;
  }

  /** One transaction: every batch, the job's COMPLETED update, the audit event; emails after commit. */
  private void insertAll(Job job, List<ValidRow> rows) {
    OffsetDateTime now = now();
    OffsetDateTime expires = OffsetDateTime.ofInstant(clock.instant().plus(InvitationService.INVITE_TTL),
        ZoneOffset.UTC);
    String accountName = accounts.getById(job.accountId()).name();
    List<PendingInvitation> mails = new ArrayList<>(rows.size());
    for (int from = 0; from < rows.size(); from += BATCH_SIZE) {
      List<ValidRow> batch = rows.subList(from, Math.min(from + BATCH_SIZE, rows.size()));
      List<UUID> userIds = batch.stream().map(r -> Ids.newId()).toList();

      jdbc.sql("""
              INSERT INTO app_user (id, account_id, email, display_name, status, primary_tenant_id, version,
                                    created_at, updated_at)
              SELECT u.id, :account, u.email, u.name, 'INVITED', :tenant, 0, :now, :now
              FROM unnest(CAST(:ids AS uuid[]), CAST(:emails AS text[]), CAST(:names AS text[])) AS u(id, email, name)""")
          .param("account", job.accountId()).param("tenant", job.tenantId()).param("now", now)
          .param("ids", PgArrays.uuids(userIds))
          .param("emails", PgArrays.text(batch.stream().map(ValidRow::email).toList()))
          .param("names", PgArrays.text(batch.stream().map(ValidRow::displayName).toList()))
          .update();

      jdbc.sql("""
              INSERT INTO user_tenant_membership (app_user, tenant_id, status, added_at)
              SELECT u.id, :tenant, 'ACTIVE', :now FROM unnest(CAST(:ids AS uuid[])) AS u(id)""")
          .param("tenant", job.tenantId()).param("now", now).param("ids", PgArrays.uuids(userIds))
          .update();

      insertAssignments(job, batch, userIds, now);

      List<UUID> tokenIds = new ArrayList<>(batch.size());
      List<String> hashes = new ArrayList<>(batch.size());
      for (int i = 0; i < batch.size(); i++) {
        String raw = newRawToken();
        tokenIds.add(Ids.newId());
        hashes.add(HexFormat.of().formatHex(UserTokenService.hash(raw)));
        mails.add(new PendingInvitation(batch.get(i).email(), accountName, raw));
      }
      jdbc.sql("""
              INSERT INTO user_token (id, user_id, purpose, token_hash, expires_at, created_by, created_at)
              SELECT t.id, t.user_id, 'INVITE', decode(t.hash, 'hex'), :expires, :createdBy, :now
              FROM unnest(CAST(:ids AS uuid[]), CAST(:userIds AS uuid[]), CAST(:hashes AS text[]))
                AS t(id, user_id, hash)""")
          .param("expires", expires).param("createdBy", job.grantor()).param("now", now)
          .param("ids", PgArrays.uuids(tokenIds)).param("userIds", PgArrays.uuids(userIds))
          .param("hashes", PgArrays.text(hashes))
          .update();
    }
    if (!finish(job, JobStatus.COMPLETED, rows.size(), List.of(), JobStatus.RUNNING)) {
      throw new JobInterruptedException(); // swept meanwhile: roll the inserts back, send nothing
    }
    invitations.notifyAfterCommit(mails);
  }

  /** TENANT-scope assignments, re-checking I1, I3 and I8 in SQL; a shortfall aborts the whole job. */
  private void insertAssignments(Job job, List<ValidRow> batch, List<UUID> userIds, OffsetDateTime now) {
    List<UUID> ids = new ArrayList<>();
    List<UUID> users = new ArrayList<>();
    List<UUID> roleIds = new ArrayList<>();
    for (int i = 0; i < batch.size(); i++) {
      if (batch.get(i).roleId() != null) {
        ids.add(Ids.newId());
        users.add(userIds.get(i));
        roleIds.add(batch.get(i).roleId());
      }
    }
    if (ids.isEmpty()) {
      return;
    }
    int inserted = jdbc.sql("""
            INSERT INTO role_assignment (id, user_id, role_id, scope_type, scope_id, granted_by, granted_at, version)
            SELECT a.id, a.user_id, r.id, 'TENANT', t.id, :grantor, :now, 0
            FROM unnest(CAST(:ids AS uuid[]), CAST(:userIds AS uuid[]), CAST(:roleIds AS uuid[]))
              AS a(id, user_id, role_id)
            JOIN app_user u ON u.id = a.user_id AND u.account_id = :account
            JOIN tenant t ON t.id = :tenant AND t.account_id = :account AND t.status = 'ACTIVE'
            JOIN user_tenant_membership m ON m.app_user = a.user_id AND m.tenant_id = t.id AND m.status = 'ACTIVE'
            JOIN account ac ON ac.id = :account
            JOIN role r ON r.id = a.role_id
            WHERE (r.type = 'SYSTEM' OR r.account_id = :account)
              AND NOT (r.type = 'SYSTEM' AND r.product_id = :iam AND lower(r.name) = lower(CAST(:platformAdmin AS text))
                       AND ac.kind <> 'PLATFORM')""")
        .param("grantor", job.grantor()).param("now", now).param("account", job.accountId())
        .param("tenant", job.tenantId()).param("iam", Product.IAM_ID).param("platformAdmin", Role.PLATFORM_ADMIN)
        .param("ids", PgArrays.uuids(ids)).param("userIds", PgArrays.uuids(users))
        .param("roleIds", PgArrays.uuids(roleIds))
        .update();
    if (inserted != ids.size()) {
      throw new IllegalStateException("role assignment invariants failed for " + (ids.size() - inserted)
          + " rows (tenant no longer active?)");
    }
  }

  // ---------------------------------------------------------------------------------------------- helpers

  /**
   * Compare-and-set {@code expected → status}; writes the audit event only when it applied.
   *
   * @return {@code false} when the job was no longer in {@code expected} (nothing written)
   */
  private boolean finish(Job job, JobStatus status, int created, List<RowError> errors, JobStatus expected) {
    Boolean applied = tx.execute(s -> {
      int updated = jdbc.sql("""
              UPDATE bulk_invite_job
              SET status = :status, created_count = :created, error_count = :errorCount,
                  errors = CAST(:errors AS jsonb), finished_at = :now
              WHERE id = :id AND status = :expected""")
          .param("status", status.name()).param("created", created).param("errorCount", errors.size())
          .param("errors", writeErrors(errors)).param("now", now()).param("id", job.id())
          .param("expected", expected.name())
          .update();
      if (updated == 0) {
        return false;
      }
      Map<String, Object> metadata = new LinkedHashMap<>();
      metadata.put("tenant_id", job.tenantId().toString());
      metadata.put("total_rows", job.totalRows());
      metadata.put("created_count", created);
      metadata.put("error_count", errors.size());
      auditWriter.write(AuditEvent.forCurrentActor(status == JobStatus.COMPLETED ? AUDIT_COMPLETED : AUDIT_FAILED)
          .accountId(job.accountId())
          .tenantId(job.tenantId())
          .target("bulk_invite_job", job.id().toString())
          .outcome(status == JobStatus.COMPLETED ? AuditEvent.Outcome.SUCCESS : AuditEvent.Outcome.FAILURE)
          .metadata(metadata)
          .build());
      return true;
    });
    return Boolean.TRUE.equals(applied);
  }

  private void requireActiveTenant(UUID accountId, UUID tenantId) {
    Tenant tenant = tenants.findByIdInAccount(tenantId, accountId)
        .orElseThrow(() -> new NotFoundException("tenant_not_found", "Tenant not found"));
    if (!tenant.isActive()) {
      throw new ConflictException("tenant_not_active", "The tenant is " + tenant.status());
    }
  }

  /** Runs {@code task} on this thread as the submitting caller (audit context, I6 grantor) with its request id. */
  private static void runAs(@Nullable Authentication caller, @Nullable String requestId, Runnable task) {
    SecurityContext context = SecurityContextHolder.createEmptyContext();
    context.setAuthentication(caller);
    SecurityContextHolder.setContext(context);
    if (requestId != null) {
      MDC.put(RequestActor.MDC_REQUEST_ID, requestId);
    }
    try {
      task.run();
    } finally {
      SecurityContextHolder.clearContext();
      MDC.remove(RequestActor.MDC_REQUEST_ID);
    }
  }

  /** The row's email (control characters replaced: PostgreSQL JSONB cannot store NUL) or {@code null}. */
  private static RowError error(Row row, String code, String message) {
    String email = row.email().codePoints()
        .map(c -> Character.isISOControl(c) ? '?' : c)
        .collect(StringBuilder::new, StringBuilder::appendCodePoint, StringBuilder::append).toString();
    return new RowError(row.line(), email.isEmpty() ? null : email, code, message);
  }

  private static boolean hasControlCharacters(@Nullable String value) {
    return value != null && value.codePoints().anyMatch(Character::isISOControl);
  }

  private static boolean isEmail(String email) {
    return email.length() <= MAX_EMAIL && EMAIL.matcher(email).matches();
  }

  private static String newRawToken() {
    byte[] random = new byte[32];
    RANDOM.nextBytes(random);
    return Base64.getUrlEncoder().withoutPadding().encodeToString(random);
  }

  private String writeErrors(List<RowError> errors) {
    try {
      return json.writeValueAsString(errors);
    } catch (JsonProcessingException e) {
      throw new IllegalStateException(e);
    }
  }

  private List<RowError> readErrors(String errors) {
    try {
      return json.readValue(errors, ERRORS);
    } catch (JsonProcessingException e) {
      throw new IllegalStateException(e);
    }
  }

  private OffsetDateTime now() {
    return OffsetDateTime.ofInstant(clock.instant(), ZoneOffset.UTC);
  }

  @Nullable
  private static Instant instant(@Nullable OffsetDateTime value) {
    return value == null ? null : value.toInstant();
  }

  /** PostgreSQL array literals for binding lists as one parameter ({@code CAST(:p AS text[])}). */
  static final class PgArrays {
    private PgArrays() {}

    static String uuids(List<UUID> ids) {
      return ids.stream().map(UUID::toString).collect(Collectors.joining(",", "{", "}"));
    }

    /** Every element quoted (backslash and double quote escaped); {@code null} becomes SQL NULL. */
    static String text(java.util.Collection<String> values) {
      return values.stream()
          .map(v -> v == null ? "NULL" : "\"" + v.replace("\\", "\\\\").replace("\"", "\\\"") + "\"")
          .collect(Collectors.joining(",", "{", "}"));
    }
  }
}
