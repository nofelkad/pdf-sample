package com.acme.iam.assignment;

import java.time.Instant;
import java.util.UUID;
import org.springframework.lang.Nullable;

/** A role assignment as listed by the assignment API. */
public record AssignmentView(
    UUID id,
    UUID userId,
    UUID roleId,
    String roleName,
    ScopeType scopeType,
    UUID scopeId,
    @Nullable UUID grantedBy,
    Instant grantedAt,
    @Nullable Instant expiresAt) {}
