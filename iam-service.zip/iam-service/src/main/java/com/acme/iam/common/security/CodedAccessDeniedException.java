package com.acme.iam.common.security;

import java.util.Map;
import java.util.Objects;
import org.springframework.security.access.AccessDeniedException;

/**
 * An authorization denial with a machine-readable {@code code} (Ruling R14). Thrown from controllers or services, it
 * reaches {@link AuditingAccessDeniedHandler}, which writes {@code authz.denied} (metadata {@code reason = code} plus
 * {@link #auditMetadata()}) and renders 403 RFC 7807 with this {@code code} and the exception message as
 * {@code detail}. Example: {@link TenantGuard}'s {@code scope_exceeded}.
 */
public class CodedAccessDeniedException extends AccessDeniedException {

  private final String code;
  private final transient Map<String, Object> auditMetadata;

  public CodedAccessDeniedException(String code, String detail, Map<String, Object> auditMetadata) {
    super(detail);
    this.code = Objects.requireNonNull(code, "code");
    this.auditMetadata = Map.copyOf(auditMetadata);
  }

  public String code() {
    return code;
  }

  /** Extra audit metadata (never secrets). */
  public Map<String, Object> auditMetadata() {
    return auditMetadata;
  }
}
