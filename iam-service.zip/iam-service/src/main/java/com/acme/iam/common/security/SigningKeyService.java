package com.acme.iam.common.security;

import com.acme.iam.common.Ids;
import com.acme.iam.core.Claims;
import com.nimbusds.jose.JOSEException;
import com.nimbusds.jose.JWSAlgorithm;
import com.nimbusds.jose.jwk.JWK;
import com.nimbusds.jose.jwk.JWKMatcher;
import com.nimbusds.jose.jwk.JWKSet;
import com.nimbusds.jose.jwk.KeyUse;
import com.nimbusds.jose.jwk.RSAKey;
import com.nimbusds.jose.jwk.gen.RSAKeyGenerator;
import com.nimbusds.jose.jwk.source.JWKSource;
import com.nimbusds.jose.proc.SecurityContext;
import com.nimbusds.jose.util.JSONObjectUtils;
import java.nio.charset.StandardCharsets;
import java.security.KeyFactory;
import java.security.interfaces.RSAPrivateKey;
import java.security.spec.PKCS8EncodedKeySpec;
import java.sql.Timestamp;
import java.text.ParseException;
import java.time.Clock;
import java.time.Duration;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.atomic.AtomicLong;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.SmartInitializingSingleton;
import org.springframework.jdbc.core.simple.JdbcClient;
import org.springframework.lang.Nullable;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.transaction.support.TransactionTemplate;

/**
 * JWT signing keys (P1-4.1, P1-4.2): RSA-2048 key pairs in {@code signing_key}, private part encrypted with the master
 * key ({@link MasterKeyCipher}, AES-256-GCM, kid as associated data), kid = UUIDv7.
 *
 * <p>Each instance keeps an in-memory copy: the ACTIVE private key for signing and the public keys of every ACTIVE and
 * PUBLISHED key for verification / JWKS. The copy is reloaded every {@code iam.security.jwk-refresh-interval} (60 s),
 * immediately after a lifecycle change made by this instance, and at most once per 5 s when a token names an unknown
 * kid.
 *
 * <p>Lifecycle: a new key is created PUBLISHED ({@link #rotateNow()}, or by {@link #runLifecycle()} once the ACTIVE key
 * is older than {@code key-rotation-interval}); after {@code key-publish-lead} (24 h, so every JWKS cache has it) it
 * becomes ACTIVE and the previous ACTIVE key is demoted to PUBLISHED; once the longest token lifetime plus clock skew
 * plus {@code key-retire-margin} ({@link #retireAfter()}) has passed since the demotion, it becomes RETIRED. A
 * never-activated key is retired only when a newer successor supersedes it (the newest one is kept). All
 * lifecycle writes take a transaction-scoped advisory lock, so the startup bootstrap, the ShedLock job and a runbook
 * call never race; at most one ACTIVE key is also enforced by a unique index (V7).
 */
@Service
public class SigningKeyService implements SmartInitializingSingleton {

  private static final Logger log = LoggerFactory.getLogger(SigningKeyService.class);
  private static final String LOCK_SQL = "SELECT 1 FROM (SELECT pg_advisory_xact_lock(hashtext('iam.signing_key'))) l";
  private static final Duration UNKNOWN_KID_REFRESH_MIN_INTERVAL = Duration.ofSeconds(5);

  public enum Status { ACTIVE, PUBLISHED, RETIRED }

  /** One row of {@code signing_key} without the private part. */
  record KeyRow(String kid, String publicJwk, Status status, Instant createdAt,
                @Nullable Instant activatedAt, @Nullable Instant demotedAt) {}

  private record KeyCache(@Nullable RSAKey active, List<JWK> verification) {
    static final KeyCache EMPTY = new KeyCache(null, List.of());
  }

  private final JdbcClient jdbc;
  private final TransactionTemplate tx;
  private final MasterKeyCipher cipher;
  private final SecurityProperties properties;
  private final Clock clock;
  private final AtomicLong lastUnknownKidRefresh = new AtomicLong();
  private volatile KeyCache cache = KeyCache.EMPTY;

  public SigningKeyService(JdbcClient jdbc, TransactionTemplate tx, SecurityProperties properties, Clock clock) {
    this.jdbc = jdbc;
    this.tx = tx;
    this.properties = properties;
    this.clock = clock;
    this.cipher = MasterKeyCipher.fromBase64(properties.masterKey());
  }

  /** Startup: create the first key when none is ACTIVE (other instances wait on the advisory lock), then load. */
  @Override
  public void afterSingletonsInstantiated() {
    ensureActiveKey();
  }

  // ------------------------------------------------------------------------------------------------ read side

  /** The private ACTIVE key used to sign. */
  public RSAKey activeSigningKey() {
    RSAKey active = cache.active;
    if (active == null) {
      refresh();
      active = cache.active;
    }
    if (active == null) {
      throw new IllegalStateException("No ACTIVE signing key");
    }
    return active;
  }

  public String activeKeyId() {
    return activeSigningKey().getKeyID();
  }

  /** Signing source for {@code NimbusJwtEncoder}: exactly the ACTIVE private key. */
  public JWKSource<SecurityContext> signingJwkSource() {
    return (selector, context) -> selector.select(new JWKSet(activeSigningKey()));
  }

  /** Verification source for the JWT decoder: public keys of ACTIVE + PUBLISHED; reloads once on an unknown kid. */
  public JWKSource<SecurityContext> verificationJwkSource() {
    return (selector, context) -> {
      List<JWK> found = selector.select(new JWKSet(cache.verification));
      if (found.isEmpty() && namesUnknownKid(selector.getMatcher()) && mayRefreshForUnknownKid()) {
        refresh();
        found = selector.select(new JWKSet(cache.verification));
      }
      return found;
    };
  }

  /** The JWKS document ({@code {"keys": [...]}}): public parameters only. */
  public Map<String, Object> jwks() {
    return new JWKSet(cache.verification).toJSONObject(true);
  }

  /** Time after demotion at which a key is retired: longest token lifetime + {@code key-retire-margin}. */
  public Duration retireAfter() {
    return properties.maxTokenTtl().plus(properties.clockSkew()).plus(properties.keyRetireMargin());
  }

  /** Scheduled reload every {@code jwk-refresh-interval} on every instance; a failure keeps the previous keys. */
  @Scheduled(fixedDelayString = "${iam.security.jwk-refresh-interval:PT60S}",
      initialDelayString = "${iam.security.jwk-refresh-interval:PT60S}")
  void scheduledRefresh() {
    try {
      refresh();
    } catch (RuntimeException e) {
      log.error("Signing key refresh failed; keeping the previously loaded keys", e);
    }
  }

  /**
   * Reloads keys from the database. A PUBLISHED key whose public JWK cannot be parsed is skipped (logged); an
   * ACTIVE key that cannot be loaded or decrypted fails the refresh.
   */
  public void refresh() {
    List<KeyRow> rows = jdbc.sql("""
            SELECT kid, public_jwk::text AS public_jwk, status, created_at, activated_at, demoted_at
            FROM signing_key WHERE status IN ('ACTIVE', 'PUBLISHED') ORDER BY created_at DESC""")
        .query(SigningKeyService::mapRow).list();
    RSAKey active = null;
    List<JWK> verification = new ArrayList<>();
    for (KeyRow row : rows) {
      RSAKey publicKey;
      try {
        publicKey = parsePublic(row.publicJwk());
      } catch (IllegalStateException e) {
        if (row.status() == Status.ACTIVE) {
          throw e;
        }
        log.error("Skipping signing key {}: invalid public JWK", row.kid());
        continue;
      }
      verification.add(publicKey);
      if (row.status() == Status.ACTIVE) {
        active = loadPrivate(row.kid(), publicKey);
      }
    }
    cache = new KeyCache(active, List.copyOf(verification));
  }

  // ------------------------------------------------------------------------------------------------ lifecycle

  /** Creates the first key directly as ACTIVE when there is none (fresh database). */
  public void ensureActiveKey() {
    tx.executeWithoutResult(status -> {
      lock();
      if (findActive().isEmpty()) {
        String kid = insertKey(Status.ACTIVE, clock.instant());
        log.info("Created initial ACTIVE signing key {}", kid);
      }
    });
    refresh();
  }

  /**
   * Runbook / CLI rotation: publishes a new key now. It starts signing after {@code key-publish-lead} via
   * {@link #runLifecycle()}.
   *
   * @return the new key id
   */
  public String rotateNow() {
    String kid = tx.execute(status -> {
      lock();
      return insertKey(Status.PUBLISHED, clock.instant());
    });
    log.info("Published new signing key {} (becomes ACTIVE after {})", kid, properties.keyPublishLead());
    refresh();
    return kid;
  }

  /**
   * One lifecycle step (ShedLock job {@code KeyRotationJob}, also callable from a runbook): publish a successor when the
   * ACTIVE key is due, promote a successor whose publish lead has elapsed, retire demoted keys whose tokens have all
   * expired. Idempotent.
   */
  public void runLifecycle() {
    tx.executeWithoutResult(status -> {
      lock();
      Instant now = clock.instant();
      List<KeyRow> keys = jdbc.sql("""
              SELECT kid, public_jwk::text AS public_jwk, status, created_at, activated_at, demoted_at
              FROM signing_key WHERE status IN ('ACTIVE', 'PUBLISHED') ORDER BY created_at DESC, kid DESC""")
          .query(SigningKeyService::mapRow).list();
      KeyRow active = keys.stream().filter(k -> k.status() == Status.ACTIVE).findFirst().orElse(null);
      if (active == null) {
        insertKey(Status.ACTIVE, now);
        return;
      }
      // Successors: published keys that have never been ACTIVE (never activated nor demoted), newest first.
      // demoted_at also covers keys that were ACTIVE before V7 and therefore have no activated_at.
      List<KeyRow> successors = keys.stream()
          .filter(k -> k.status() == Status.PUBLISHED && k.activatedAt() == null && k.demotedAt() == null)
          .toList();

      // 1. publish a successor when the active key is due
      Instant activeSince = active.activatedAt() != null ? active.activatedAt() : active.createdAt();
      if (successors.isEmpty() && !activeSince.plus(properties.keyRotationInterval()).isAfter(now)) {
        String kid = insertKey(Status.PUBLISHED, now);
        log.info("Signing key {} is due for rotation; published successor {}", active.kid(), kid);
      }

      // 2. promote the newest successor whose publish lead has elapsed
      Optional<KeyRow> ready = successors.stream()
          .filter(k -> !k.createdAt().plus(properties.keyPublishLead()).isAfter(now))
          .findFirst();
      ready.ifPresent(next -> {
        jdbc.sql("""
                UPDATE signing_key SET status = 'PUBLISHED', demoted_at = :now,
                                       activated_at = COALESCE(activated_at, created_at)
                WHERE kid = :kid""")
            .param("now", Timestamp.from(now)).param("kid", active.kid()).update();
        jdbc.sql("UPDATE signing_key SET status = 'ACTIVE', activated_at = :now WHERE kid = :kid")
            .param("now", Timestamp.from(now)).param("kid", next.kid()).update();
        log.info("Signing key {} is now ACTIVE; {} demoted to PUBLISHED", next.kid(), active.kid());
      });

      // 3. retire PUBLISHED keys whose tokens have all expired: demoted keys once retire-after has passed since the
      //    demotion; never-active keys (no activated_at, no demoted_at) only when superseded by a newer successor
      //    (the newest one is kept). A demoted key is only ever retired through the demoted_at branch.
      Instant retireBefore = now.minus(retireAfter());
      int retired = jdbc.sql("""
              UPDATE signing_key SET status = 'RETIRED', retired_at = :now
              WHERE status = 'PUBLISHED'
                AND ((demoted_at IS NOT NULL AND demoted_at <= :retireBefore)
                  OR (activated_at IS NULL AND demoted_at IS NULL AND created_at <= :retireBefore
                      AND kid <> (SELECT kid FROM signing_key
                                  WHERE status = 'PUBLISHED' AND activated_at IS NULL AND demoted_at IS NULL
                                  ORDER BY created_at DESC, kid DESC LIMIT 1)))""")
          .param("now", Timestamp.from(now)).param("retireBefore", Timestamp.from(retireBefore)).update();
      if (retired > 0) {
        log.info("Retired {} signing key(s)", retired);
      }
    });
    refresh();
  }

  // ------------------------------------------------------------------------------------------------ internals

  private void lock() {
    jdbc.sql(LOCK_SQL).query(Integer.class).single();
  }

  private Optional<String> findActive() {
    return jdbc.sql("SELECT kid FROM signing_key WHERE status = 'ACTIVE'").query(String.class).optional();
  }

  private String insertKey(Status status, Instant now) {
    String kid = Ids.newId().toString();
    RSAKey key;
    try {
      key = new RSAKeyGenerator(2048)
          .keyID(kid)
          .keyUse(KeyUse.SIGNATURE)
          .algorithm(JWSAlgorithm.parse(Claims.ALGORITHM))
          .generate();
    } catch (JOSEException e) {
      throw new IllegalStateException("RSA key generation failed", e);
    }
    byte[] pkcs8;
    try {
      pkcs8 = key.toRSAPrivateKey().getEncoded();
    } catch (JOSEException e) {
      throw new IllegalStateException("Cannot export private key", e);
    }
    byte[] sealed;
    try {
      sealed = cipher.encrypt(pkcs8, kid.getBytes(StandardCharsets.UTF_8));
    } finally {
      Arrays.fill(pkcs8, (byte) 0);
    }
    jdbc.sql("""
            INSERT INTO signing_key (kid, public_jwk, private_enc, status, created_at, activated_at)
            VALUES (:kid, CAST(:jwk AS jsonb), :sealed, :status, :now, :activatedAt)""")
        .param("kid", kid)
        .param("jwk", JSONObjectUtils.toJSONString(key.toPublicJWK().toJSONObject()))
        .param("sealed", sealed)
        .param("status", status.name())
        .param("now", Timestamp.from(now))
        .param("activatedAt", status == Status.ACTIVE ? Timestamp.from(now) : null, java.sql.Types.TIMESTAMP)
        .update();
    return kid;
  }

  private RSAKey loadPrivate(String kid, RSAKey publicKey) {
    byte[] sealed = jdbc.sql("SELECT private_enc FROM signing_key WHERE kid = :kid")
        .param("kid", kid).query(byte[].class).single();
    byte[] pkcs8 = cipher.decrypt(sealed, kid.getBytes(StandardCharsets.UTF_8));
    try {
      RSAPrivateKey privateKey = (RSAPrivateKey) KeyFactory.getInstance("RSA")
          .generatePrivate(new PKCS8EncodedKeySpec(pkcs8));
      return new RSAKey.Builder(publicKey).privateKey(privateKey).build();
    } catch (java.security.GeneralSecurityException e) {
      throw new IllegalStateException("Cannot load private key " + kid, e);
    } finally {
      Arrays.fill(pkcs8, (byte) 0);
    }
  }

  private static RSAKey parsePublic(String json) {
    try {
      return RSAKey.parse(json);
    } catch (ParseException e) {
      throw new IllegalStateException("Invalid public JWK in signing_key", e);
    }
  }

  private boolean namesUnknownKid(JWKMatcher matcher) {
    if (matcher.getKeyIDs() == null || matcher.getKeyIDs().isEmpty()) {
      return false;
    }
    return cache.verification.stream().noneMatch(k -> matcher.getKeyIDs().contains(k.getKeyID()));
  }

  private boolean mayRefreshForUnknownKid() {
    long now = clock.millis();
    long last = lastUnknownKidRefresh.get();
    return now - last >= UNKNOWN_KID_REFRESH_MIN_INTERVAL.toMillis() && lastUnknownKidRefresh.compareAndSet(last, now);
  }

  private static KeyRow mapRow(java.sql.ResultSet rs, int rowNum) throws java.sql.SQLException {
    return new KeyRow(
        rs.getString("kid"),
        rs.getString("public_jwk"),
        Status.valueOf(rs.getString("status")),
        rs.getTimestamp("created_at").toInstant(),
        instantOrNull(rs.getTimestamp("activated_at")),
        instantOrNull(rs.getTimestamp("demoted_at")));
  }

  @Nullable
  private static Instant instantOrNull(@Nullable Timestamp timestamp) {
    return timestamp == null ? null : timestamp.toInstant();
  }
}
