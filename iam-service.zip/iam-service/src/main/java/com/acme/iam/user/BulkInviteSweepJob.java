package com.acme.iam.user;

import java.time.Duration;
import net.javacrumbs.shedlock.spring.annotation.SchedulerLock;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

/**
 * Ruling R29: a bulk invite job lives in memory on the instance that accepted it, so a stop or crash leaves it RUNNING
 * (or PENDING) forever. This cluster-wide job (ShedLock {@value #LOCK_NAME}) runs at startup and then every
 * {@code iam.bulk-invite.sweep-interval} (default 5 min) and marks jobs older than {@code iam.bulk-invite.stale-after}
 * (default 30 min) FAILED with {@code job_interrupted}. Jobs of 5,000 rows finish in seconds, so 30 minutes only
 * catches dead ones.
 */
@Component
public class BulkInviteSweepJob {

  public static final String LOCK_NAME = "bulk-invite-sweep";

  private static final Logger log = LoggerFactory.getLogger(BulkInviteSweepJob.class);

  private final BulkInviteService service;
  private final Duration staleAfter;

  public BulkInviteSweepJob(BulkInviteService service,
      @Value("${iam.bulk-invite.stale-after:PT30M}") Duration staleAfter) {
    this.service = service;
    this.staleAfter = staleAfter;
  }

  @Scheduled(initialDelayString = "${iam.bulk-invite.sweep-initial-delay:PT0S}",
      fixedDelayString = "${iam.bulk-invite.sweep-interval:PT5M}")
  @SchedulerLock(name = LOCK_NAME, lockAtMostFor = "PT5M")
  public void run() {
    int marked = service.failStaleJobs(staleAfter);
    if (marked > 0) {
      log.warn("bulk_invite.interrupted_jobs_failed count={}", marked);
    }
  }
}
