package com.acme.iam.auth;

import jakarta.validation.Valid;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;
import java.net.URI;
import java.time.Duration;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.bind.DefaultValue;
import org.springframework.validation.annotation.Validated;

/**
 * {@code iam.auth.*}: session lifetimes, lockout, password reset, password policy defaults, rate limits and the
 * breached-password check. Session lifetimes and the password policy can be overridden per account in
 * {@code account.settings} (see {@link SessionTtl} and {@link PasswordPolicy}).
 *
 * @param session default refresh-token lifetimes
 * @param lockout failed-login lockout
 * @param passwordResetTtl lifetime of a {@code PASSWORD_RESET} token (spec: 30 min)
 * @param passwordPolicy defaults for {@code account.settings.passwordPolicy}
 * @param rateLimit Bucket4j limits for the public {@code /auth} endpoints (P1-5.7)
 * @param breachedPassword HIBP range API used when a policy enables {@code breachedCheck}
 * @param mailExecutor background executor issuing and mailing password-reset links ({@link PasswordResetMailer})
 */
@Validated
@ConfigurationProperties("iam.auth")
public record AuthProperties(
    @Valid @NotNull @DefaultValue Session session,
    @Valid @NotNull @DefaultValue Lockout lockout,
    @NotNull @DefaultValue("PT30M") Duration passwordResetTtl,
    @Valid @NotNull @DefaultValue Policy passwordPolicy,
    @Valid @NotNull @DefaultValue RateLimit rateLimit,
    @Valid @NotNull @DefaultValue Breached breachedPassword,
    @Valid @NotNull @DefaultValue MailExecutor mailExecutor) {

  /** @param absoluteTtl session lifetime from login (12 h) @param idleTtl max time between refreshes (30 min) */
  public record Session(@NotNull @DefaultValue("PT12H") Duration absoluteTtl,
                        @NotNull @DefaultValue("PT30M") Duration idleTtl) {}

  /** @param maxAttempts consecutive failures that lock the user @param duration how long the lock lasts */
  public record Lockout(@Min(1) @DefaultValue("5") int maxAttempts,
                        @NotNull @DefaultValue("PT15M") Duration duration) {}

  public record Policy(@Min(8) @Max(1024) @DefaultValue("12") int minLength,
                       @Min(8) @Max(1024) @DefaultValue("128") int maxLength,
                       @Min(0) @Max(24) @DefaultValue("5") int historySize,
                       @DefaultValue("false") boolean breachedCheck) {
    /** The defaults, cross-checked like account settings (e.g. {@code min-length > max-length} is clamped). */
    PasswordPolicy toPolicy() {
      return PasswordPolicy.clamped(minLength, maxLength, historySize, breachedCheck);
    }
  }

  /**
   * @param enabled switch for all limits
   * @param perIp requests per {@code window} per client IP on login, forgot and reset (10)
   * @param perEmail requests per {@code window} per normalised email on login and forgot (5)
   * @param refreshPerIp requests per {@code window} per client IP on refresh
   * @param changePerUser password-change requests per {@code window} per user
   * @param window refill period of every bucket
   * @param purgeInterval how often expired buckets are deleted
   */
  public record RateLimit(@DefaultValue("true") boolean enabled,
                          @Min(1) @DefaultValue("10") int perIp,
                          @Min(1) @DefaultValue("5") int perEmail,
                          @Min(1) @DefaultValue("60") int refreshPerIp,
                          @Min(1) @DefaultValue("10") int changePerUser,
                          @NotNull @DefaultValue("PT1M") Duration window,
                          @NotNull @DefaultValue("PT10M") Duration purgeInterval) {}

  /** @param rangeUrl HIBP range endpoint; the 5-char SHA-1 prefix is appended */
  public record Breached(@NotNull @DefaultValue("https://api.pwnedpasswords.com/range/") URI rangeUrl,
                         @NotNull @DefaultValue("PT3S") Duration timeout) {}

  /**
   * @param threads worker threads (1 keeps resets in request order)
   * @param queueCapacity queued tasks before new ones are dropped ({@code iam.auth.password_reset.dropped})
   * @param sendTimeout upper bound of one {@code NotificationPort} call; a hung send is cancelled
   */
  public record MailExecutor(@Min(1) @DefaultValue("1") int threads,
                             @Min(1) @DefaultValue("1000") int queueCapacity,
                             @NotNull @DefaultValue("PT30S") Duration sendTimeout) {}
}
