package com.acme.iam.assignment;

import com.acme.iam.account.Account;
import com.acme.iam.account.AccountService;
import com.acme.iam.common.RequestActor;
import com.acme.iam.common.error.BadRequestException;
import com.acme.iam.common.error.ConflictException;
import com.acme.iam.common.error.ForbiddenException;
import com.acme.iam.common.error.NotFoundException;
import com.acme.iam.common.security.TenantGuard;
import com.acme.iam.product.Product;
import com.acme.iam.role.Role;
import com.acme.iam.role.RoleService;
import com.acme.iam.tenant.Tenant;
import com.acme.iam.tenant.TenantService;
import com.acme.iam.user.AppUser;
import com.acme.iam.user.UserService;
import com.acme.iam.user.UserStatus;
import java.time.Clock;
import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneOffset;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;
import java.util.UUID;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.data.relational.core.conversion.DbActionExecutionException;
import org.springframework.lang.Nullable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * Creates role assignments, enforcing the write-time invariants of spec section 5. The audit trigger records each
 * insert ({@code iam.role_assignment.insert}) in the same transaction.
 *
 * <table>
 *   <caption>Checks, in order</caption>
 *   <tr><th>Rule</th><th>{@link #assign}</th><th>{@link #grantAsSystem}</th><th>Failure</th></tr>
 *   <tr><td>actor is a user</td><td>yes</td><td>-</td><td>403 {@code grantor_required}</td></tr>
 *   <tr><td>I10 actor has an account claim (fails closed)</td><td>yes</td><td>-</td><td>403 {@code forbidden}</td></tr>
 *   <tr><td>I10 user in the actor's account</td><td>yes</td><td>-</td><td>404 {@code user_not_found}</td></tr>
 *   <tr><td>I10 CUSTOM role of the actor's account (else indistinguishable from unknown)</td><td>yes</td><td>-</td>
 *       <td>404 {@code role_not_found}</td></tr>
 *   <tr><td>expiry in the future</td><td>yes</td><td>yes</td><td>400 {@code invalid_expiry}</td></tr>
 *   <tr><td>I8 Platform Admin only in the PLATFORM account</td><td>yes</td><td>yes</td>
 *       <td>403 {@code platform_role_restricted}</td></tr>
 *   <tr><td>I3 CUSTOM role only in its own account</td><td>(404 above)</td><td>yes</td>
 *       <td>400 {@code role_not_in_account}</td></tr>
 *   <tr><td>I1 scope inside the user's account</td><td>yes</td><td>yes</td>
 *       <td>400 {@code scope_not_in_account}</td></tr>
 *   <tr><td>TENANT scope: tenant ACTIVE</td><td>yes</td><td>yes</td><td>409 {@code tenant_not_active}</td></tr>
 *   <tr><td>I1 ACTIVE membership for TENANT scope (row locked FOR SHARE)</td><td>yes</td><td>yes</td>
 *       <td>409 {@code membership_required}</td></tr>
 *   <tr><td>TENANT scope: {@code iam.role.assign} in the token's active tenant or at ACCOUNT scope
 *       ({@link TenantGuard#requireActive}, final review M4: the same rule on every path)</td><td>yes</td><td>-</td>
 *       <td>403 {@code scope_exceeded}</td></tr>
 *   <tr><td>I6 grantor holds every grantable permission of the role, and {@code iam.role.assign}, at the scope; for a
 *       SYSTEM role of a non-IAM product only {@code iam.role.assign} (+ its own scope rule) and the product entitled
 *       (R40, 403 {@code product_not_entitled})</td>
 *       <td>yes</td><td>-</td>
 *       <td>403 {@code grantor_lacks_permissions} (+ {@code missingPermissions})</td></tr>
 *   <tr><td>not already assigned</td><td>yes</td><td>yes</td><td>409 {@code assignment_exists}</td></tr>
 * </table>
 *
 * <p>I6 semantics: at TENANT scope the grantor's permissions are {@link PermissionResolver#resolveGrantorAtTenant}
 * (ruling R11: what {@code resolve} gives plus the grantor's ACCOUNT-scope grants entitled in that tenant, no
 * membership needed); at ACCOUNT scope they are
 * {@link PermissionResolver#resolveAccountScope} (only the grantor's ACCOUNT-scope assignments count). Deprecated
 * permissions of the role are not required, since they are never granted.
 */
@Service
public class AssignmentService {

  /** 409: the target user is DISABLED or DEPROVISIONED. */
  public static final String USER_NOT_ACTIVE = "user_not_active";
  /** The permission every grantor needs at the target scope (in addition to the role's permissions, I6). */
  public static final String ROLE_ASSIGN = "iam.role.assign";
  /** 403: R40 exemption refused, the product is not entitled for the account (or not enabled in the tenant). */
  public static final String PRODUCT_NOT_ENTITLED = "product_not_entitled";

  private final RoleAssignmentRepository assignments;
  private final PermissionResolver resolver;
  private final UserService users;
  private final RoleService roles;
  private final TenantService tenants;
  private final AccountService accounts;
  private final Clock clock;
  private final TenantGuard tenantGuard;

  public AssignmentService(RoleAssignmentRepository assignments, PermissionResolver resolver, UserService users,
      RoleService roles, TenantService tenants, AccountService accounts, Clock clock, TenantGuard tenantGuard) {
    this.tenantGuard = tenantGuard;
    this.assignments = assignments;
    this.resolver = resolver;
    this.users = users;
    this.roles = roles;
    this.tenants = tenants;
    this.accounts = accounts;
    this.clock = clock;
  }

  /**
   * Assigns a role on behalf of the current actor (the grantor), enforcing I1, I3, I6 and I8.
   *
   * @throws ForbiddenException {@code grantor_required} when there is no acting user (use {@link #grantAsSystem})
   */
  @Transactional
  public RoleAssignment assign(AssignCommand cmd) {
    RequestActor actor = RequestActor.current();
    UUID grantor = actor.userUuid();
    if (grantor == null) {
      throw new ForbiddenException("grantor_required", "Role assignment requires an authenticated user");
    }
    UUID actorAccount = actor.accountUuid();
    if (actorAccount == null) {
      // I10 fails closed: a user actor without an account claim may not assign anything
      throw new ForbiddenException("Role assignment requires an account context");
    }
    AppUser user = users.getById(cmd.userId());
    if (!actorAccount.equals(user.account())) {
      throw new NotFoundException("user_not_found", "User not found");
    }
    Role role = roles.getById(cmd.roleId());
    if (role.isCustom() && !actorAccount.equals(role.account())) {
      // another account's CUSTOM role is indistinguishable from an unknown id (no enumeration)
      throw new NotFoundException("role_not_found", "Role not found");
    }

    checkInvariants(user, role, cmd.scopeType(), cmd.scopeId(), cmd.expiresAt());
    requireGrantorHolds(grantor, user.account(), role, cmd.scopeType(), cmd.scopeId());
    return insert(RoleAssignment.create(user.id(), role.id(), cmd.scopeType(), cmd.scopeId(), grantor,
        cmd.expiresAt()));
  }

  /**
   * Assigns a role without a grantor check (I6), for bootstrap and system flows only: the first operator, the first
   * Account Admin of a new account, manifest-driven grants. I1, I3 and I8 still apply.
   *
   * @param grantedBy recorded as {@code granted_by}; may be {@code null}
   */
  @Transactional
  public RoleAssignment grantAsSystem(UUID userId, UUID roleId, ScopeType scopeType, UUID scopeId,
      @Nullable UUID grantedBy, @Nullable Instant expiresAt) {
    AppUser user = users.getById(userId);
    Role role = roles.getById(roleId);
    checkInvariants(user, role, scopeType, scopeId, expiresAt);
    return insert(RoleAssignment.create(user.id(), role.id(), scopeType, scopeId, grantedBy, expiresAt));
  }

  private void checkInvariants(AppUser user, Role role, ScopeType scopeType, UUID scopeId,
      @Nullable Instant expiresAt) {
    // Task 5 / R28: serialise with user administration writes on this user. Task 9: the status read under the lock
    // must allow grants; INVITED stays assignable (invite-with-roles), DISABLED and DEPROVISIONED users are not.
    UserStatus status = users.lockForGrant(user.id()).orElse(user.status());
    if (status != UserStatus.ACTIVE && status != UserStatus.INVITED) {
      throw new ConflictException(USER_NOT_ACTIVE, "The user is " + status + " and cannot receive roles");
    }
    if (expiresAt != null && !expiresAt.isAfter(clock.instant())) {
      throw new BadRequestException("invalid_expiry", "expiresAt must be in the future");
    }

    // I8: Platform Admin only for users of the PLATFORM account
    if (role.isPlatformAdmin()) {
      Account account = accounts.getById(user.account());
      if (!account.isPlatform()) {
        throw new ForbiddenException("platform_role_restricted",
            "Platform Admin is assignable only inside the platform account");
      }
    }

    // I3: a CUSTOM role is assignable only inside its own account
    if (role.isCustom() && !user.account().equals(role.account())) {
      throw new BadRequestException("role_not_in_account", "The role belongs to another account");
    }

    // I1: the scope lies in the user's account; TENANT scope needs an ACTIVE membership
    switch (scopeType) {
      case ACCOUNT -> {
        if (!scopeId.equals(user.account())) {
          throw scopeNotInAccount();
        }
      }
      case TENANT -> {
        Tenant tenant = tenants.findByIdInAccount(scopeId, user.account()).orElseThrow(
            AssignmentService::scopeNotInAccount);
        if (!tenant.isActive()) {
          throw new ConflictException("tenant_not_active", "The tenant is " + tenant.status());
        }
        if (!users.lockActiveMembership(user.id(), scopeId)) {
          throw new ConflictException("membership_required",
              "A tenant-scope assignment requires an active membership in that tenant");
        }
      }
    }
  }

  /**
   * Ruling R46 (final review): whether {@code callerId} holds, at the same scope, every grantable permission of every
   * unexpired role {@code userId} holds in {@code accountId}, i.e. could have granted all of them (I6, without the R40
   * product-system-role exemption). Gates the activation link of a re-sent invitation, so a user manager cannot take
   * over a more privileged invitee. A user without roles is dominated by anyone.
   */
  public boolean holdsEveryRoleOf(UUID callerId, UUID accountId, UUID userId) {
    for (RoleAssignment assignment : assignments.findUnexpiredByUserInAccount(userId, accountId)) {
      Set<String> held = assignment.scopeType() == ScopeType.TENANT
          ? resolver.resolveGrantorAtTenant(callerId, assignment.scopeId())
          : resolver.resolveAccountScope(callerId, accountId);
      if (!held.containsAll(roles.grantablePermissionCodes(roles.getById(assignment.roleId().getId())))) {
        return false;
      }
    }
    return true;
  }

  /**
   * I6: the grantor must hold every grantable permission of the role at the target scope, and (Task 9) {@value
   * #ROLE_ASSIGN} itself at that scope, so no path (invite-with-roles, bulk invite) assigns roles without it.
   */
  private void requireGrantorHolds(UUID grantor, UUID accountId, Role role, ScopeType scopeType, UUID scopeId) {
    if (scopeType == ScopeType.TENANT) {
      // Final review M4: the scope rule of POST /api/users/{id}/assignments (AssignmentAdminService) for every path,
      // invite-with-roles included: iam.role.assign in the active tenant, or at ACCOUNT scope for another tenant
      tenantGuard.requireActive(scopeId, ROLE_ASSIGN);
    }
    boolean productSystemRole = role.isSystem() && !Product.IAM_ID.equals(role.product());
    Set<String> required = new TreeSet<>(productSystemRole
        ? roles.grantablePermissionCodesOfOtherProducts(role) // R40: the role's own product's permissions are exempt
        : roles.grantablePermissionCodes(role));
    required.add(ROLE_ASSIGN);
    if (productSystemRole) {
      requireProductSystemRoleScope(accountId, role, scopeType, scopeId);
    }
    Set<String> held = switch (scopeType) {
      case TENANT -> resolver.resolveGrantorAtTenant(grantor, scopeId);
      case ACCOUNT -> resolver.resolveAccountScope(grantor, scopeId);
    };
    if (!held.containsAll(required)) {
      throw new ForbiddenException("grantor_lacks_permissions",
          "You can only assign roles whose permissions you hold at that scope",
          Map.of("missingPermissions", required.stream().filter(p -> !held.contains(p)).sorted().toList()));
    }
  }

  /**
   * Ruling R40 (Task 9), the conditions of the I6 exemption for SYSTEM roles of non-IAM products: {@value #ROLE_ASSIGN}
   * at the target scope (ACCOUNT: through an ACCOUNT-scope assignment; TENANT: {@link TenantGuard#requireActive}, so the
   * active tenant or an ACCOUNT-scope grant), and the product entitled for the account (ACTIVE/TRIAL subscription not
   * ended) and, at TENANT scope, enabled in the tenant (403 {@value #PRODUCT_NOT_ENTITLED}). Separation of duties is
   * relaxed on purpose here: product system roles are defined by the product's manifest, not by the account.
   */
  private void requireProductSystemRoleScope(UUID accountId, Role role, ScopeType scopeType, UUID scopeId) {
    // the TENANT-scope TenantGuard check ran first, in requireGrantorHolds (M4)
    LocalDate today = LocalDate.now(clock.withZone(ZoneOffset.UTC));
    boolean entitled = accounts.getById(accountId).entitledProductIds(today).contains(role.product());
    if (entitled && scopeType == ScopeType.TENANT) {
      entitled = tenants.findByIdInAccount(scopeId, accountId)
          .map(t -> t.products().stream().anyMatch(p -> p.productId().equals(role.product()) && p.enabled()))
          .orElse(false);
    }
    if (!entitled) {
      throw new ForbiddenException(PRODUCT_NOT_ENTITLED,
          "The role's product is not " + (scopeType == ScopeType.TENANT ? "enabled in this tenant" : "subscribed"),
          Map.of("productId", role.product().toString()));
    }
  }

  private RoleAssignment insert(RoleAssignment assignment) {
    try {
      return assignments.save(assignment);
    } catch (DbActionExecutionException e) {
      if (e.getCause() instanceof DuplicateKeyException) {
        throw new ConflictException("assignment_exists", "The user already holds this role at this scope");
      }
      throw e;
    }
  }

  private static BadRequestException scopeNotInAccount() {
    return new BadRequestException("scope_not_in_account", "The scope is not part of the user's account");
  }
}
