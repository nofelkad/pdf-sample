package com.acme.iam.common.security;

import java.util.Collection;
import java.util.List;
import java.util.Objects;
import java.util.TreeSet;
import java.util.UUID;

/**
 * Input of {@link JwtIssuer#issueAccessToken(AccessTokenClaims)}: the user-specific claims of a spec section 4 access
 * token ({@code iss, iat, exp, jti} are added by the issuer).
 *
 * @param userId {@code sub}
 * @param accountId {@code acc}
 * @param tenantId {@code tid}, the active tenant
 * @param sessionId {@code sid}, {@code user_session.id}
 * @param sessionVersion {@code sv}, {@code app_user.session_version} read in the same transaction as the permissions
 * @param permissions {@code perms}, e.g. from {@code PermissionResolver.resolve(userId, tenantId)}; de-duplicated and
 *     sorted
 */
public record AccessTokenClaims(
    UUID userId,
    UUID accountId,
    UUID tenantId,
    UUID sessionId,
    int sessionVersion,
    List<String> permissions) {

  public AccessTokenClaims(UUID userId, UUID accountId, UUID tenantId, UUID sessionId, int sessionVersion,
                           Collection<String> permissions) {
    this(userId, accountId, tenantId, sessionId, sessionVersion, List.copyOf(new TreeSet<>(permissions)));
  }

  public AccessTokenClaims {
    Objects.requireNonNull(userId, "userId");
    Objects.requireNonNull(accountId, "accountId");
    Objects.requireNonNull(tenantId, "tenantId");
    Objects.requireNonNull(sessionId, "sessionId");
    permissions = List.copyOf(new TreeSet<>(Objects.requireNonNull(permissions, "permissions")));
  }
}
