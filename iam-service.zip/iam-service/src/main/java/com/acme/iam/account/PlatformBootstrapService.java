package com.acme.iam.account;

import com.acme.iam.assignment.AssignmentService;
import com.acme.iam.assignment.ScopeType;
import com.acme.iam.product.Product;
import com.acme.iam.role.Role;
import com.acme.iam.role.RoleService;
import com.acme.iam.tenant.Tenant;
import com.acme.iam.tenant.TenantAdminService;
import com.acme.iam.user.InvitationService;
import com.acme.iam.user.InvitationService.InvitedUser;
import com.acme.iam.user.IssuedToken;
import com.acme.iam.user.TokenPurpose;
import com.acme.iam.user.UserStatus;
import com.acme.iam.user.UserTokenService;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import java.util.regex.Pattern;
import org.springframework.jdbc.core.simple.JdbcClient;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * P1-6.4: makes a fresh install usable. In one transaction it creates the PLATFORM account's tenant (slug
 * {@value #PLATFORM_TENANT_SLUG}), an INVITED user with a primary membership there, the {@value Role#PLATFORM_ADMIN}
 * assignment at ACCOUNT scope ({@link AssignmentService#grantAsSystem}, no grantor) and a 7-day INVITE token.
 *
 * <p>Runs once: when the {@code platform} tenant or any Platform Admin assignment already exists it throws
 * {@link AlreadyBootstrappedException}, with one recovery exception: when the only Platform Admin is still INVITED and
 * the run names the same email (case-insensitive), the invitation is reissued (outstanding INVITE tokens invalidated,
 * a new 7-day token issued; {@link Result#reissued()}), so a lost or failed invitation email can be re-sent by running
 * the command again. Concurrent runs serialise on a transaction-scoped advisory lock. Delivery of the invitation is
 * the caller's job ({@link PlatformBootstrapCommand}), after this method has committed.
 */
@Service
public class PlatformBootstrapService {

  public static final String PLATFORM_TENANT_SLUG = "platform";

  private static final Pattern EMAIL = Pattern.compile("^[^@\\s]{1,64}@[^@\\s]+\\.[^@\\s]+$");

  /** The platform is already bootstrapped. */
  public static class AlreadyBootstrappedException extends RuntimeException {
    public AlreadyBootstrappedException(String message) {
      super(message);
    }
  }

  /**
   * The invited Platform Admin. {@code token.rawToken()} is the secret for the accept link.
   *
   * @param reissued {@code true} when the platform already existed and only the invitation was issued again
   */
  public record Result(UUID userId, UUID tenantId, String email, String accountName, IssuedToken token,
                       boolean reissued) {}

  private record PlatformAdmin(UUID userId, String email, UserStatus status, UUID primaryTenantId) {}

  private final TenantAdminService tenantAdmin;
  private final InvitationService invitations;
  private final AssignmentService assignments;
  private final RoleService roles;
  private final AccountService accounts;
  private final UserTokenService userTokens;
  private final JdbcClient jdbc;

  public PlatformBootstrapService(TenantAdminService tenantAdmin, InvitationService invitations,
      AssignmentService assignments, RoleService roles, AccountService accounts, UserTokenService userTokens,
      JdbcClient jdbc) {
    this.tenantAdmin = tenantAdmin;
    this.invitations = invitations;
    this.assignments = assignments;
    this.roles = roles;
    this.accounts = accounts;
    this.userTokens = userTokens;
    this.jdbc = jdbc;
  }

  /**
   * @throws IllegalArgumentException for an invalid email
   * @throws IllegalStateException when the {@value Role#PLATFORM_ADMIN} system role is not loaded
   * @throws AlreadyBootstrappedException when the platform tenant or a Platform Admin assignment exists
   */
  @Transactional
  public Result bootstrap(String email) {
    if (email == null || !EMAIL.matcher(email.trim()).matches()) {
      throw new IllegalArgumentException("Not a valid email address: " + email);
    }
    jdbc.sql("SELECT 1 FROM (SELECT pg_advisory_xact_lock(hashtext('iam:platform_bootstrap'))) l")
        .query(Integer.class).single();
    Role platformAdmin = roles.findSystemRole(Product.IAM_ID, Role.PLATFORM_ADMIN)
        .orElseThrow(() -> new IllegalStateException(
            "The " + Role.PLATFORM_ADMIN + " system role does not exist; the IAM manifest was not loaded"));
    boolean done = jdbc.sql("""
            SELECT EXISTS (SELECT 1 FROM tenant WHERE account_id = :platform AND slug = :slug)
                OR EXISTS (SELECT 1 FROM role_assignment WHERE role_id = :role)""")
        .param("platform", Account.PLATFORM_ID).param("slug", PLATFORM_TENANT_SLUG).param("role", platformAdmin.id())
        .query(Boolean.class).single();
    if (done) {
      Optional<Result> reissued = reissuePendingInvitation(email.trim(), platformAdmin);
      if (reissued.isPresent()) {
        return reissued.get();
      }
      throw new AlreadyBootstrappedException(
          "The platform is already bootstrapped (a '" + PLATFORM_TENANT_SLUG + "' tenant or a "
              + Role.PLATFORM_ADMIN + " assignment exists); refusing to run again");
    }
    Tenant tenant = tenantAdmin.createWithProducts(Account.PLATFORM_ID, "Platform", PLATFORM_TENANT_SLUG, Set.of());
    InvitedUser admin = invitations.createInvitedUser(Account.PLATFORM_ID, tenant.id(), email, null, null);
    assignments.grantAsSystem(admin.user().id(), platformAdmin.id(), ScopeType.ACCOUNT, Account.PLATFORM_ID, null,
        null);
    return new Result(admin.user().id(), tenant.id(), admin.user().email(),
        accounts.getById(Account.PLATFORM_ID).name(), admin.token(), false);
  }

  /** The single, still INVITED Platform Admin with this email gets a fresh INVITE token; otherwise empty. */
  private Optional<Result> reissuePendingInvitation(String email, Role platformAdmin) {
    List<PlatformAdmin> admins = jdbc.sql("""
            SELECT DISTINCT u.id, u.email::text AS email, u.status, u.primary_tenant_id
            FROM role_assignment ra JOIN app_user u ON u.id = ra.user_id
            WHERE ra.role_id = :role""")
        .param("role", platformAdmin.id())
        .query((rs, i) -> new PlatformAdmin(rs.getObject("id", UUID.class), rs.getString("email"),
            UserStatus.valueOf(rs.getString("status")), rs.getObject("primary_tenant_id", UUID.class)))
        .list();
    if (admins.size() != 1) {
      return Optional.empty();
    }
    PlatformAdmin admin = admins.get(0);
    if (admin.status() != UserStatus.INVITED || !admin.email().equalsIgnoreCase(email)) {
      return Optional.empty();
    }
    userTokens.invalidateOutstanding(admin.userId(), TokenPurpose.INVITE);
    IssuedToken token = userTokens.issue(admin.userId(), TokenPurpose.INVITE, InvitationService.INVITE_TTL, null);
    return Optional.of(new Result(admin.userId(), admin.primaryTenantId(), admin.email(),
        accounts.getById(Account.PLATFORM_ID).name(), token, true));
  }
}
