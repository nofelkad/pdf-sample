package com.acme.iam.audit;

import io.micrometer.core.instrument.Gauge;
import io.micrometer.core.instrument.MeterRegistry;
import java.time.Clock;
import java.time.YearMonth;
import java.time.ZoneOffset;
import java.util.concurrent.atomic.AtomicInteger;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.event.EventListener;
import org.springframework.jdbc.core.simple.JdbcClient;
import org.springframework.stereotype.Service;

/**
 * P1-9.2: keeps {@value #MONTHS_AHEAD} future monthly partitions of {@code audit_event} in place by calling the
 * SECURITY DEFINER function {@code audit_ensure_partitions} (Ruling R3, serialised by an advisory lock inside the
 * function, so concurrent callers are safe). Runs once at startup ({@link #onStartup()}) and daily
 * ({@link AuditPartitionJob}).
 *
 * <p>The "alert" is the gauge {@value #GAUGE} (number of existing partitions after the current month, expected
 * {@value #MONTHS_AHEAD}) plus an ERROR log line when fewer than {@value #MIN_MONTHS_AHEAD} exist. A failing
 * {@code ensure} also logs at ERROR; it is never thrown into the scheduler or the startup sequence, because ingest
 * keeps working while the current partition exists.
 */
@Service
public class AuditPartitionService {

  public static final String GAUGE = "iam.audit.partitions.months_ahead";
  public static final int MONTHS_AHEAD = 3;
  public static final int MIN_MONTHS_AHEAD = 2;

  private static final Logger log = LoggerFactory.getLogger(AuditPartitionService.class);

  private final JdbcClient jdbc;
  private final AuditPartitions partitions;
  private final Clock clock;
  private final AtomicInteger monthsAhead = new AtomicInteger(-1);

  public AuditPartitionService(JdbcClient jdbc, AuditPartitions partitions, Clock clock, MeterRegistry meters) {
    this.jdbc = jdbc;
    this.partitions = partitions;
    this.clock = clock;
    Gauge.builder(GAUGE, monthsAhead, AtomicInteger::get)
        .description("Existing audit_event partitions after the current month (alert when below 2)")
        .register(meters);
  }

  /** Creates missing partitions for the current month plus {@value #MONTHS_AHEAD}, then refreshes the gauge. */
  public int ensurePartitions() {
    int created = 0;
    try {
      created = jdbc.sql("SELECT audit_ensure_partitions(:months)").param("months", MONTHS_AHEAD)
          .query(Integer.class).single();
      if (created > 0) {
        log.info("Created {} audit_event partition(s)", created);
      }
    } catch (RuntimeException e) {
      log.error("audit_ensure_partitions failed; audit partitions may run out", e);
    }
    refreshGauge();
    return created;
  }

  /** Number of existing partitions after the current month (UTC); also published as {@value #GAUGE}. */
  public int refreshGauge() {
    try {
      YearMonth current = YearMonth.now(clock.withZone(ZoneOffset.UTC));
      int ahead = (int) partitions.existing().stream().filter(m -> m.isAfter(current)).count();
      monthsAhead.set(ahead);
      if (ahead < MIN_MONTHS_AHEAD) {
        log.error("Only {} future audit_event partition(s) exist (expected {}); ingest of events beyond the last "
            + "partition will be rejected. Run SELECT audit_ensure_partitions({}) or check the partition job.",
            ahead, MONTHS_AHEAD, MONTHS_AHEAD);
      }
      return ahead;
    } catch (RuntimeException e) {
      log.error("Could not determine the audit_event partition horizon", e);
      return monthsAhead.get();
    }
  }

  @EventListener(ApplicationReadyEvent.class)
  void onStartup() {
    ensurePartitions();
  }
}
