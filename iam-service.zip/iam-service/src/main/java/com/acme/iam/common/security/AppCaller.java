package com.acme.iam.common.security;

import com.acme.iam.core.Claims;
import java.util.Optional;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.security.oauth2.server.resource.authentication.JwtAuthenticationToken;

/**
 * Static view of an application-client caller ({@code typ=app} token) in the current SecurityContext. Used where a
 * bean cannot be injected (transaction manager, audit attribution, Ruling R9).
 */
public final class AppCaller {

  private AppCaller() {}

  /** {@code true} for an application token ({@code typ = "app"}). */
  public static boolean isApp(Jwt jwt) {
    return Claims.TYPE_APP.equals(jwt.getClaimAsString(Claims.TYPE));
  }

  /** The client id of an application token ({@code sub = "app:<clientId>"}), else empty. */
  public static Optional<String> clientId(Jwt jwt) {
    String subject = jwt.getSubject();
    if (!isApp(jwt) || subject == null || !subject.startsWith(Claims.APP_SUBJECT_PREFIX)) {
      return Optional.empty();
    }
    return Optional.of(subject.substring(Claims.APP_SUBJECT_PREFIX.length()));
  }

  /** Client id of the application calling in this thread, if the caller is an application. */
  public static Optional<String> currentClientId() {
    Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
    if (authentication instanceof JwtAuthenticationToken token) {
      return clientId(token.getToken());
    }
    return Optional.empty();
  }

  /** Audit {@code source} value for an application: {@code app:<clientId>}. */
  public static String source(String clientId) {
    return Claims.APP_SUBJECT_PREFIX + clientId;
  }
}
