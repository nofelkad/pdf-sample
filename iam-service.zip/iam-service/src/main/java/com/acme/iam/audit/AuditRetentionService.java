package com.acme.iam.audit;

import java.time.Clock;
import java.time.Instant;
import java.time.LocalDate;
import java.time.Period;
import java.time.YearMonth;
import java.time.ZoneOffset;
import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.simple.JdbcClient;
import org.springframework.stereotype.Service;

/**
 * P1-9.3: drops audit partitions that lie entirely past the retention period ({@code iam.audit.retention},
 * ISO-8601 period, default {@code P7Y}), but only after {@link AuditArchiveHook#archive(String)} returned
 * {@code true} for that partition.
 *
 * <p>Order of events per partition (oldest first): archive hook (partition still attached and readable) ->
 * {@code SELECT audit_detach_partition(name)} (SECURITY DEFINER; detach + drop in one transaction, refuses a name that
 * is not an audit partition and any partition that ended less than 90 days ago) -> audit event
 * {@value #ACTION_DROPPED}. A failure on one partition is logged and does not stop the others; the partition is
 * simply offered again on the next run. With the default {@link RefusingArchiveHook} nothing is ever dropped.
 *
 * <p>Runbook: to keep data, make sure the hook really archived (for example {@code pg_dump -t audit_event_y2019m03})
 * before it returns true; to drop one partition by hand, run the same function as the application role:
 * {@code SELECT audit_detach_partition('audit_event_y2019m03')}.
 */
@Service
public class AuditRetentionService {

  public static final String ACTION_DROPPED = "iam.audit.partition.dropped";
  /** Same floor as {@code audit_detach_partition}: retention below this is rejected at startup. */
  public static final int MIN_RETENTION_DAYS = 90;

  private static final Logger log = LoggerFactory.getLogger(AuditRetentionService.class);

  private final JdbcClient jdbc;
  private final AuditPartitions partitions;
  private final AuditArchiveHook archiveHook;
  private final AuditWriter auditWriter;
  private final Clock clock;
  private final Period retention;

  public AuditRetentionService(JdbcClient jdbc, AuditPartitions partitions, AuditArchiveHook archiveHook,
                               AuditWriter auditWriter, Clock clock,
                               @Value("${iam.audit.retention:P7Y}") String retention) {
    this.jdbc = jdbc;
    this.partitions = partitions;
    this.archiveHook = archiveHook;
    this.auditWriter = auditWriter;
    this.clock = clock;
    this.retention = Period.parse(retention);
    LocalDate today = LocalDate.now(clock.withZone(ZoneOffset.UTC));
    if (this.retention.isNegative() || today.minus(this.retention).isAfter(today.minusDays(MIN_RETENTION_DAYS))) {
      throw new IllegalArgumentException("iam.audit.retention must be at least " + MIN_RETENTION_DAYS + " days, got "
          + retention);
    }
  }

  /**
   * Events older than this are no longer accepted by ingest: a partition becomes archivable once everything in it is
   * older than the retention period, and a row landing in it after the archive but before the drop would be lost.
   */
  Instant cutoff() {
    return clock.instant().atOffset(ZoneOffset.UTC).minus(retention).toInstant();
  }

  /** Partitions whose whole range ended at or before {@code today - retention}, oldest first. */
  List<YearMonth> expired() {
    LocalDate cutoff = LocalDate.now(clock.withZone(ZoneOffset.UTC)).minus(retention);
    return partitions.existing().stream()
        .filter(month -> !month.plusMonths(1).atDay(1).isAfter(cutoff))
        .toList();
  }

  /** Archives and drops every expired partition; returns the names that were dropped. */
  public List<String> enforce() {
    return expired().stream().map(AuditPartitions::nameOf).filter(this::archiveAndDrop).toList();
  }

  private boolean archiveAndDrop(String partition) {
    boolean archived;
    try {
      archived = archiveHook.archive(partition);
    } catch (RuntimeException e) {
      log.error("Archiving audit partition {} failed; keeping it", partition, e);
      return false;
    }
    if (!archived) {
      log.info("Audit partition {} is past retention but was not archived; keeping it", partition);
      return false;
    }
    boolean dropped;
    try {
      dropped = Boolean.TRUE.equals(jdbc.sql("SELECT audit_detach_partition(:name)").param("name", partition)
          .query(Boolean.class).single());
    } catch (RuntimeException e) {
      log.error("Detaching audit partition {} failed; it stays attached and is retried on the next run", partition, e);
      return false;
    }
    if (dropped) {
      log.warn("Dropped audit partition {} (past retention {}, archived)", partition, retention);
      try {
        auditWriter.write(AuditEvent.builder(ACTION_DROPPED)
            .target("audit_partition", partition)
            .metadata("retention", retention.toString())
            .metadata("archiveHook", archiveHook.getClass().getSimpleName())
            .build());
      } catch (RuntimeException e) {
        log.error("Could not record {} for {}", ACTION_DROPPED, partition, e);
      }
    }
    return dropped;
  }
}
