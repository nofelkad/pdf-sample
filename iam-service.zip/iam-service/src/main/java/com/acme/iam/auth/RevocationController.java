package com.acme.iam.auth;

import com.acme.iam.core.Claims;
import com.acme.iam.core.revocation.RevocationEntry;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.PositiveOrZero;
import java.time.Duration;
import java.util.List;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/**
 * {@code GET /internal/revocations?since={cursor}&limit={n}} for iam-client pollers (application token with
 * {@value Claims#PERM_INTERNAL_REVOCATIONS_READ}). Without {@code since} it returns the rows of the last
 * {@code iam.revocation.startup-lookback} (20 min), which is what a poller loads at startup. Keep calling with the
 * returned {@code cursor}; a page shorter than {@code limit} means the poller is up to date.
 */
@RestController
public class RevocationController {

  public static final String PATH = "/internal/revocations";

  /** Response body: {@code {entries: [{id, userId, minSv}], cursor}}. */
  public record RevocationFeed(List<RevocationEntry> entries, long cursor) {}

  private final RevocationService revocations;
  private final Duration startupLookback;

  public RevocationController(RevocationService revocations,
                              @Value("${iam.revocation.startup-lookback:PT20M}") Duration startupLookback) {
    this.revocations = revocations;
    this.startupLookback = startupLookback;
  }

  @GetMapping(PATH)
  @PreAuthorize("hasAuthority('" + Claims.PERM_INTERNAL_REVOCATIONS_READ + "')")
  public RevocationFeed feed(@RequestParam(required = false) @PositiveOrZero Long since,
                             @RequestParam(defaultValue = "1000") @Min(1) @Max(5000) int limit) {
    long cursor = since != null ? since : revocations.startCursor(startupLookback);
    List<RevocationEntry> entries = revocations.since(cursor, limit);
    long next = entries.isEmpty() ? cursor : entries.get(entries.size() - 1).id();
    return new RevocationFeed(entries, next);
  }
}
