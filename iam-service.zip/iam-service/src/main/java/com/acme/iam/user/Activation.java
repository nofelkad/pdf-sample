package com.acme.iam.user;

import java.time.Instant;

/**
 * An activation (accept-invitation) link returned by the API (ruling R46). The link embeds a raw INVITE token: it is a
 * 7-day bearer secret, so {@link #toString()} hides it and responses carrying it are {@code Cache-Control: no-store}.
 */
public record Activation(String link, Instant expiresAt) {

  @Override
  public String toString() {
    return "Activation[expiresAt=" + expiresAt + "]";
  }
}
