package com.acme.iam.role;

import java.util.Objects;
import java.util.UUID;
import org.springframework.data.relational.core.mapping.Table;

/** A permission granted by a role ({@code role_permission}), owned by {@link Role}. */
@Table("role_permission")
public record RolePermission(UUID permissionId) {

  public RolePermission {
    Objects.requireNonNull(permissionId, "permissionId");
  }
}
