package com.acme.iam.user;

import java.time.Clock;
import java.time.Duration;
import java.time.Instant;
import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import org.springframework.lang.Nullable;
import org.springframework.jdbc.core.simple.JdbcClient;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * Credential and login-bookkeeping writes on {@code app_user} (Ruling R19, owned by the authentication task):
 * login candidates, failed-login counting and lockout, last login, password set/change with
 * {@code password_history}, and invitation activation.
 *
 * <p>Every write is a targeted {@code UPDATE}/{@code INSERT}, never {@code AppUser} {@code save()} (which would rewrite
 * and audit every membership row). Login bookkeeping ({@code failed_logins}, {@code locked_until},
 * {@code last_login_at}) does not bump {@code version} and is ignored by the {@code app_user} audit trigger; password
 * and status changes bump {@code version}, so a concurrent aggregate {@code save()} with a stale copy fails with an
 * optimistic-locking conflict instead of silently restoring the old password hash or status.
 */
@Service
public class UserCredentialService {

  /** Upper bound of accounts one email can match in a login; bounds the Argon2 work per attempt. */
  public static final int MAX_CANDIDATES = 20;

  private final JdbcClient jdbc;
  private final Clock clock;

  public UserCredentialService(JdbcClient jdbc, Clock clock) {
    this.jdbc = jdbc;
    this.clock = clock;
  }

  /**
   * ACTIVE users with this email (case-insensitive), optionally only in the account with this slug
   * (case-insensitive), ordered by account slug.
   */
  public List<LoginCandidate> findLoginCandidates(String email, @Nullable String accountSlug) {
    return jdbc.sql("""
            SELECT u.id, u.account_id, u.email, a.slug, a.name, u.primary_tenant_id, u.password_hash, u.locked_until
            FROM app_user u JOIN account a ON a.id = u.account_id
            WHERE u.email = CAST(:email AS citext) AND u.status = 'ACTIVE'
              AND (CAST(:slug AS text) IS NULL OR a.slug = CAST(:slug AS citext))
            ORDER BY a.slug
            LIMIT :max""")
        .param("email", email)
        .param("slug", accountSlug)
        .param("max", MAX_CANDIDATES)
        .query((rs, n) -> new LoginCandidate(
            rs.getObject("id", UUID.class),
            rs.getObject("account_id", UUID.class),
            rs.getString("email"),
            rs.getString("slug"),
            rs.getString("name"),
            rs.getObject("primary_tenant_id", UUID.class),
            rs.getString("password_hash"),
            instant(rs.getObject("locked_until", OffsetDateTime.class))))
        .list();
  }

  /**
   * Counts one failed login of a user that is not currently locked. The {@code maxAttempts}-th consecutive failure
   * locks the user for {@code lockDuration} and resets the counter. A locked user is left unchanged.
   *
   * @return {@code true} when this call applied the lock (audit {@code auth.locked})
   */
  @Transactional
  public boolean recordFailedLogin(UUID userId, int maxAttempts, Duration lockDuration) {
    Instant now = clock.instant();
    return jdbc.sql("""
            UPDATE app_user SET
              failed_logins = CASE WHEN failed_logins + 1 >= :max THEN 0 ELSE failed_logins + 1 END,
              locked_until  = CASE WHEN failed_logins + 1 >= :max THEN :lockedUntil ELSE locked_until END
            WHERE id = :id AND (locked_until IS NULL OR locked_until <= :now)
            RETURNING locked_until IS NOT NULL AND locked_until > :now AS locked""")
        .param("id", userId)
        .param("max", maxAttempts)
        .param("lockedUntil", utc(now.plus(lockDuration)))
        .param("now", utc(now))
        .query(Boolean.class)
        .optional()
        .orElse(false);
  }

  /**
   * Resets the failure counter and stamps {@code last_login_at}, but only while the user is not locked. The lock
   * condition is part of the {@code UPDATE}, so PostgreSQL re-evaluates it after waiting for a concurrent (not yet
   * committed) lock-applying update of the row: a correct guess can never clear a lock applied concurrently.
   *
   * @return {@code false} when the user is (now) locked; nothing is written then and the login must fail
   */
  @Transactional
  public boolean recordSuccessfulLogin(UUID userId) {
    Instant now = clock.instant();
    return jdbc.sql("""
            UPDATE app_user SET failed_logins = 0, locked_until = NULL, last_login_at = :now
            WHERE id = :id AND (locked_until IS NULL OR locked_until <= :now)""")
        .param("id", userId)
        .param("now", utc(now))
        .update() == 1;
  }

  /**
   * Administrative unlock (Task 9, ruling R38): clears {@code failed_logins} and {@code locked_until} of a user of the
   * account. Joins the caller's transaction.
   *
   * @return {@code true} when the user was locked ({@code locked_until} in the future) before the call
   */
  @Transactional
  public boolean unlock(UUID accountId, UUID userId) {
    Instant now = clock.instant();
    Boolean wasLocked = jdbc.sql("""
            UPDATE app_user u SET failed_logins = 0, locked_until = NULL
            FROM (SELECT id, locked_until FROM app_user WHERE id = :id AND account_id = :account FOR UPDATE) before
            WHERE u.id = before.id
            RETURNING before.locked_until IS NOT NULL AND before.locked_until > :now""")
        .param("id", userId).param("account", accountId).param("now", utc(now))
        .query(Boolean.class).optional().orElse(false);
    return Boolean.TRUE.equals(wasLocked);
  }

  /**
   * Sets a new (already hashed and policy-checked) password: {@code password_hash}, {@code password_changed_at},
   * clears any lockout, appends the hash to {@code password_history} and keeps only the newest {@code keepHistory}
   * entries (at least one).
   */
  @Transactional
  public void setPassword(UUID userId, String passwordHash, int keepHistory) {
    Instant now = clock.instant();
    jdbc.sql("""
            UPDATE app_user SET password_hash = :hash, password_changed_at = :now, failed_logins = 0,
                                locked_until = NULL, version = version + 1, updated_at = :now
            WHERE id = :id""")
        .param("id", userId)
        .param("hash", passwordHash)
        .param("now", utc(now))
        .update();
    recordHistory(userId, passwordHash, now, keepHistory);
  }

  /**
   * Like {@link #setPassword(UUID, String, int)}, but only if the stored hash is still {@code expectedCurrentHash}
   * (compare-and-set: the caller verified the current password against that hash outside the transaction).
   *
   * @return {@code false} when the password changed in the meantime; nothing is written then
   */
  @Transactional
  public boolean setPassword(UUID userId, String passwordHash, int keepHistory, String expectedCurrentHash) {
    Instant now = clock.instant();
    int updated = jdbc.sql("""
            UPDATE app_user SET password_hash = :hash, password_changed_at = :now, failed_logins = 0,
                                locked_until = NULL, version = version + 1, updated_at = :now
            WHERE id = :id AND password_hash = :expected""")
        .param("id", userId)
        .param("hash", passwordHash)
        .param("expected", expectedCurrentHash)
        .param("now", utc(now))
        .update();
    if (updated == 0) {
      return false;
    }
    recordHistory(userId, passwordHash, now, keepHistory);
    return true;
  }

  /**
   * The user a still-usable (unused, unexpired) token of this purpose belongs to, <em>without</em> consuming it. Lets
   * the reset and invitation flows run Argon2 and the breached-password check before their transaction; the token is
   * then consumed atomically inside it ({@link UserTokenService#consume}).
   */
  public Optional<UUID> usableTokenOwner(String rawToken, TokenPurpose purpose) {
    if (rawToken == null || rawToken.isBlank()) {
      return Optional.empty();
    }
    return jdbc.sql("""
            SELECT user_id FROM user_token
            WHERE token_hash = :hash AND purpose = :purpose AND used_at IS NULL AND expires_at > :now""")
        .param("hash", UserTokenService.hash(rawToken))
        .param("purpose", purpose.name())
        .param("now", utc(clock.instant()))
        .query(UUID.class)
        .optional();
  }

  /**
   * Activates an INVITED user on invitation accept: status ACTIVE, password, optional display name, history entry.
   *
   * @param displayName new display name, or {@code null} to keep the current one
   * @return {@code false} when the user is not (or no longer) INVITED; nothing is written then
   */
  @Transactional
  public boolean activateInvited(UUID userId, String passwordHash, @Nullable String displayName, int keepHistory) {
    Instant now = clock.instant();
    int updated = jdbc.sql("""
            UPDATE app_user SET status = 'ACTIVE', password_hash = :hash, password_changed_at = :now,
                                display_name = COALESCE(CAST(:displayName AS text), display_name),
                                failed_logins = 0, locked_until = NULL, version = version + 1, updated_at = :now
            WHERE id = :id AND status = 'INVITED'""")
        .param("id", userId)
        .param("hash", passwordHash)
        .param("displayName", displayName)
        .param("now", utc(now))
        .update();
    if (updated == 0) {
      return false;
    }
    recordHistory(userId, passwordHash, now, keepHistory);
    return true;
  }

  /**
   * Hashes a new password must not match: the current hash first, then {@code password_history} newest first, at
   * most {@code limit} distinct hashes in total.
   */
  public List<String> passwordHashesToAvoid(UUID userId, int limit) {
    List<String> hashes = new ArrayList<>();
    jdbc.sql("SELECT password_hash FROM app_user WHERE id = :id AND password_hash IS NOT NULL")
        .param("id", userId).query(String.class).optional().ifPresent(hashes::add);
    jdbc.sql("""
            SELECT password_hash FROM password_history WHERE user_id = :id
            ORDER BY changed_at DESC LIMIT :limit""")
        .param("id", userId).param("limit", Math.max(limit, 1))
        .query(String.class).list().stream()
        .filter(h -> !hashes.contains(h))
        .forEach(hashes::add);
    return List.copyOf(hashes.subList(0, Math.min(hashes.size(), Math.max(limit, 1))));
  }

  private void recordHistory(UUID userId, String passwordHash, Instant now, int keepHistory) {
    jdbc.sql("INSERT INTO password_history (user_id, password_hash, changed_at) VALUES (:id, :hash, :now)")
        .param("id", userId).param("hash", passwordHash).param("now", utc(now)).update();
    jdbc.sql("""
            DELETE FROM password_history ph
            WHERE ph.user_id = :id
              AND ph.ctid NOT IN (SELECT ctid FROM password_history WHERE user_id = :id
                                  ORDER BY changed_at DESC LIMIT :keep)""")
        .param("id", userId).param("keep", Math.max(keepHistory, 1)).update();
  }

  private static OffsetDateTime utc(Instant instant) {
    return OffsetDateTime.ofInstant(instant, ZoneOffset.UTC);
  }

  @Nullable
  private static Instant instant(@Nullable OffsetDateTime value) {
    return value == null ? null : value.toInstant();
  }
}
