package com.acme.iam.common;

import com.github.f4b6a3.uuid.UuidCreator;
import java.util.UUID;

/** Application-assigned identifiers. All aggregate ids are UUIDv7 (time-ordered, index friendly). */
public final class Ids {

  private Ids() {}

  /** A new UUIDv7 ({@code UuidCreator.getTimeOrderedEpoch()}). */
  public static UUID newId() {
    return UuidCreator.getTimeOrderedEpoch();
  }
}
