package com.acme.iam.tenant;

import com.acme.iam.common.error.NotFoundException;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import org.springframework.stereotype.Service;

/**
 * Tenant lookups used by other features. Task 2 provides only the reads the authorization kernel needs; the tenant
 * administration API (Wave 2) extends this class.
 */
@Service
public class TenantService {

  private final TenantRepository tenants;

  public TenantService(TenantRepository tenants) {
    this.tenants = tenants;
  }

  public Optional<Tenant> findById(UUID tenantId) {
    return tenants.findById(tenantId);
  }

  /** @throws NotFoundException {@code tenant_not_found} */
  public Tenant getById(UUID tenantId) {
    return tenants.findById(tenantId)
        .orElseThrow(() -> new NotFoundException("tenant_not_found", "Tenant not found"));
  }

  /** The tenant if it belongs to {@code accountId} (I10-safe lookup); empty otherwise. */
  public Optional<Tenant> findByIdInAccount(UUID tenantId, UUID accountId) {
    return tenants.findByIdInAccount(tenantId, accountId);
  }

  public List<Tenant> findAllByAccount(UUID accountId) {
    return tenants.findAllByAccount(accountId);
  }
}
