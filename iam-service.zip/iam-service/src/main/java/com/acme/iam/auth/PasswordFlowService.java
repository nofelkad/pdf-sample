package com.acme.iam.auth;

import com.acme.iam.audit.AuditEvent.Outcome;
import com.acme.iam.common.error.ApiException;
import com.acme.iam.common.error.BadRequestException;
import com.acme.iam.user.LoginCandidate;
import com.acme.iam.user.TokenPurpose;
import com.acme.iam.user.UserCredentialService;
import com.acme.iam.user.UserStatus;
import com.acme.iam.user.UserToken;
import com.acme.iam.user.UserTokenService;
import java.time.Clock;
import java.time.Instant;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import org.springframework.lang.Nullable;
import org.springframework.stereotype.Service;

/**
 * Forgot / reset / change password (P1-5.6).
 *
 * <ul>
 *   <li><b>Forgot</b> always succeeds (202). The request path only looks up the ACTIVE users with the email
 *       (optionally in one account) and writes the {@value AuthAuditService#PASSWORD_FORGOT} audit event; token issue
 *       and mail run off the request thread in {@link PasswordResetMailer} (R31), so known and unknown emails cost the
 *       same.
 *   <li><b>Reset</b> peeks the token's owner, runs the policy check (Argon2 history verifications, breached check)
 *       and hashing <em>before</em> its transaction; the transaction consumes the token, sets the password (clearing
 *       any lockout), revokes every session and calls {@code revokeUsers([user], "password_reset")} last. A rejected
 *       password never consumes the token. Audited {@value AuthAuditService#PASSWORD_RESET}.
 *   <li><b>Change</b> needs the current password and is refused (403 {@code account_locked}) while a lockout is in
 *       force. A wrong current password counts as a failed login (same lockout as login); the attempt that applies
 *       the lock also ends the caller's session and revokes the user's access tokens ({@code revokeUsers([user],
 *       "password_change_lockout")}) and answers 401 {@code session_invalid}. On success it keeps the caller's
 *       session (rotating its refresh token), revokes the user's other sessions, calls
 *       {@code revokeUsers([user], "password_change")} last and returns fresh tokens carrying the new {@code sv}. The
 *       new hash is stored only if the stored hash is still the one the current password was verified against
 *       (409 {@code concurrent_modification} otherwise, audited
 *       {@value AuthAuditService#PASSWORD_CHANGE_FAILED}). Audited {@value AuthAuditService#PASSWORD_CHANGED}; the
 *       controller also applies a per-user rate limit.
 * </ul>
 */
@Service
public class PasswordFlowService {

  public static final String REASON_RESET = "password_reset";
  public static final String REASON_CHANGE = "password_change";
  public static final String REASON_CHANGE_LOCKOUT = "password_change_lockout";

  private final UserCredentialService credentials;
  private final UserTokenService userTokens;
  private final PasswordResetMailer resetMailer;
  private final PasswordService passwords;
  private final AccessStateQuery access;
  private final UserSessionRepository sessionRepository;
  private final SessionService sessions;
  private final RevocationService revocations;
  private final AuthAuditService audit;
  private final AuthTransactions tx;
  private final AuthProperties properties;
  private final Clock clock;

  public PasswordFlowService(UserCredentialService credentials, UserTokenService userTokens,
                             PasswordResetMailer resetMailer, PasswordService passwords, AccessStateQuery access,
                             UserSessionRepository sessionRepository, SessionService sessions,
                             RevocationService revocations, AuthAuditService audit, AuthTransactions tx,
                             AuthProperties properties, Clock clock) {
    this.credentials = credentials;
    this.userTokens = userTokens;
    this.resetMailer = resetMailer;
    this.passwords = passwords;
    this.access = access;
    this.sessionRepository = sessionRepository;
    this.sessions = sessions;
    this.revocations = revocations;
    this.audit = audit;
    this.tx = tx;
    this.properties = properties;
    this.clock = clock;
  }

  // ------------------------------------------------------------------------------------------------- forgot

  /** Audits the request and queues reset mails; never reveals (not even by timing) whether the email exists. */
  public void forgot(String email, @Nullable String accountSlug, ClientInfo client) {
    String normalized = email.trim();
    String slug = accountSlug == null || accountSlug.isBlank() ? null : accountSlug.trim();
    List<LoginCandidate> users = credentials.findLoginCandidates(normalized, slug);
    tx.write(() -> {
      for (LoginCandidate user : users) {
        audit.event(AuthAuditService.PASSWORD_FORGOT, client).subject(user.userId(), user.accountId())
            .meta("email", normalized).write();
      }
      if (users.isEmpty()) {
        audit.event(AuthAuditService.PASSWORD_FORGOT, client).meta("email", normalized)
            .meta("account", slug).meta("reason", "unknown_user").write();
      }
      return null;
    });
    resetMailer.dispatch(users.stream().map(u -> new PasswordResetMailer.Target(u.userId(), u.email())).toList());
  }

  // -------------------------------------------------------------------------------------------------- reset

  /**
   * @throws ApiException 400 {@code invalid_token} or {@code password_policy}
   */
  public void reset(String rawToken, String newPassword, ClientInfo client) {
    try {
      // Argon2 (history), breached check and hashing happen before the transaction
      UUID userId = credentials.usableTokenOwner(rawToken, TokenPurpose.PASSWORD_RESET)
          .orElseThrow(PasswordFlowService::invalidToken);
      AccessState before = access.load(userId, null)
          .filter(s -> s.userStatus() == UserStatus.ACTIVE)
          .orElseThrow(PasswordFlowService::invalidToken);
      PasswordPolicy policy = passwords.policy(before.accountSettings());
      passwords.validate(policy, newPassword, credentials.passwordHashesToAvoid(userId, policy.historySize()));
      String newHash = passwords.hash(newPassword);

      tx.write(() -> {
        UserToken token = userTokens.consume(rawToken, TokenPurpose.PASSWORD_RESET);
        AccessState state = access.load(token.user(), null)
            .filter(s -> s.userId().equals(userId) && s.userStatus() == UserStatus.ACTIVE)
            .orElseThrow(PasswordFlowService::invalidToken);
        credentials.setPassword(userId, newHash, policy.historySize());
        userTokens.invalidateOutstanding(userId, TokenPurpose.PASSWORD_RESET);
        int revoked = sessionRepository.revokeAllOfUser(userId, clock.instant());
        audit.event(AuthAuditService.PASSWORD_RESET, client)
            .user(userId, state.accountId(), null, null)
            .meta("sessions_revoked", revoked)
            .write();
        revocations.revokeUsers(List.of(userId), REASON_RESET); // last write
        return null;
      });
    } catch (ApiException e) {
      audit.event(AuthAuditService.PASSWORD_RESET, client).outcome(Outcome.FAILURE).meta("reason", e.code()).write();
      throw e;
    }
  }

  // ------------------------------------------------------------------------------------------------- change

  /**
   * @throws ApiException 400 {@code invalid_current_password} or {@code password_policy}; 401 {@code session_invalid}
   *     (session gone, or this attempt locked the user); 403 {@code account_locked}; 409
   *     {@code concurrent_modification}
   */
  public AuthTokens change(Caller caller, String currentPassword, String newPassword, ClientInfo client) {
    AccessState before = access.load(caller.userId(), caller.tenantId()).orElseThrow(AuthErrors::sessionInvalid);
    if (before.isLocked(clock.instant())) {
      audit.event(AuthAuditService.PASSWORD_CHANGED, client).user(caller).outcome(Outcome.DENIED)
          .meta("reason", AuthErrors.ACCOUNT_LOCKED).write();
      throw AuthErrors.accountLocked();
    }
    String expectedHash = before.passwordHash();
    if (expectedHash == null || !passwords.matches(currentPassword, expectedHash)) {
      return wrongCurrentPassword(caller, client);
    }
    PasswordPolicy policy = passwords.policy(before.accountSettings());
    try {
      passwords.validate(policy, newPassword, credentials.passwordHashesToAvoid(caller.userId(), policy.historySize()));
    } catch (ApiException e) {
      audit.event(AuthAuditService.PASSWORD_CHANGED, client).user(caller).outcome(Outcome.FAILURE)
          .meta("reason", e.code()).write();
      throw e;
    }
    String newHash = passwords.hash(newPassword);

    return tx.<AuthTransactions.Outcome<AuthTokens>>write(() -> {
      Instant now = clock.instant();
      Optional<UserSession> session = sessionRepository.lockOwned(caller.sessionId(), caller.userId());
      // the session's active tenant (it may differ from the presented token's tid after a switch-tenant)
      UUID tenantId = session.map(UserSession::activeTenant).orElse(caller.tenantId());
      AccessState state = access.load(caller.userId(), tenantId).orElse(null);
      if (session.isEmpty() || !session.get().isActive(now) || state == null || state.denial().isPresent()) {
        session.filter(s -> s.revokedAt() == null).ifPresent(s -> sessionRepository.revoke(s.id(), now));
        audit.event(AuthAuditService.SESSION_INVALIDATED, client).user(caller).outcome(Outcome.DENIED)
            .meta("reason", state == null ? "user_not_found" : state.denial().orElse("session_ended")).write();
        return AuthTransactions.Outcome.fail(AuthErrors.sessionInvalid());
      }
      if (!credentials.setPassword(caller.userId(), newHash, policy.historySize(), expectedHash)) {
        audit.event(AuthAuditService.PASSWORD_CHANGE_FAILED, client).user(caller).outcome(Outcome.FAILURE)
            .meta("reason", AuthErrors.CONCURRENT_MODIFICATION).write();
        return AuthTransactions.Outcome.fail(AuthErrors.concurrentModification()); // only the audit row written
      }
      int others = sessionRepository.revokeOthersOfUser(caller.userId(), caller.sessionId(), now);
      String refreshToken = SessionService.newRefreshToken();
      sessionRepository.rotate(caller.sessionId(), SessionService.hash(refreshToken), now);
      audit.event(AuthAuditService.PASSWORD_CHANGED, client).user(caller).meta("sessions_revoked", others).write();
      revocations.revokeUsers(List.of(caller.userId()), REASON_CHANGE); // last write
      int sessionVersion = access.sessionVersion(caller.userId());
      SessionTtl ttl = sessions.ttl(state);
      return AuthTransactions.Outcome.ok(sessions.issue(caller.userId(), state.accountId(), tenantId,
          caller.sessionId(), sessionVersion, refreshToken, ttl.refreshExpiresAt(session.get().expiresAt(), now)));
    }).get();
  }

  /** Counts the failure like a failed login; the attempt that locks the user also ends the session. */
  private AuthTokens wrongCurrentPassword(Caller caller, ClientInfo client) {
    AuthProperties.Lockout lockout = properties.lockout();
    return tx.<AuthTransactions.Outcome<AuthTokens>>write(() -> {
      boolean lockedNow = credentials.recordFailedLogin(caller.userId(), lockout.maxAttempts(), lockout.duration());
      audit.event(AuthAuditService.PASSWORD_CHANGED, client).user(caller).outcome(Outcome.FAILURE)
          .meta("reason", AuthErrors.INVALID_CURRENT_PASSWORD).write();
      if (!lockedNow) {
        return AuthTransactions.Outcome.fail(AuthErrors.invalidCurrentPassword());
      }
      audit.event(AuthAuditService.LOCKED, client).user(caller).outcome(Outcome.DENIED)
          .meta("trigger", "password_change").meta("max_attempts", lockout.maxAttempts())
          .meta("lock_duration", lockout.duration().toString()).write();
      sessionRepository.revoke(caller.sessionId(), clock.instant());
      revocations.revokeUsers(List.of(caller.userId()), REASON_CHANGE_LOCKOUT); // last write
      return AuthTransactions.Outcome.fail(AuthErrors.sessionInvalid());
    }).get();
  }

  private static BadRequestException invalidToken() {
    return new BadRequestException(UserTokenService.INVALID_TOKEN, "The link is invalid or has expired");
  }
}
