package com.acme.iam.appclient;

import com.acme.iam.common.error.ApiException;
import org.springframework.http.HttpStatus;

/** 401 {@code invalid_client} (RFC 6749 section 5.2): client authentication at {@code POST /internal/token} failed. */
public class InvalidClientException extends ApiException {

  public static final String CODE = "invalid_client";

  public InvalidClientException() {
    super(HttpStatus.UNAUTHORIZED, CODE, "Client authentication failed");
  }
}
