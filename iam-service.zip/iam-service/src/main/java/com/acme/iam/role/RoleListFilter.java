package com.acme.iam.role;

import java.util.UUID;
import org.springframework.lang.Nullable;

/** Optional filters of the role list; {@code null} means "any". */
public record RoleListFilter(@Nullable UUID productId, @Nullable RoleType type) {

  public static final RoleListFilter NONE = new RoleListFilter(null, null);
}
