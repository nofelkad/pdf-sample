package com.acme.iam.assignment;

import net.javacrumbs.shedlock.spring.annotation.SchedulerLock;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

/**
 * Every {@code iam.assignment.expiry.interval} (5 min) one instance (ShedLock {@value #LOCK_NAME}) deletes expired
 * assignments and revokes their holders ({@link AssignmentExpiryService}). The method is not transactional: each batch
 * is its own transaction, and a failure is logged and retried on the next run.
 */
@Component
// disabled in application-test.yml: test contexts share one database, a background job would delete other tests' fixtures
@ConditionalOnProperty(name = "iam.assignment.expiry.enabled", havingValue = "true", matchIfMissing = true)
public class AssignmentExpiryJob {

  public static final String LOCK_NAME = "assignment-expiry";
  private static final Logger log = LoggerFactory.getLogger(AssignmentExpiryJob.class);

  private final AssignmentExpiryService expiry;

  public AssignmentExpiryJob(AssignmentExpiryService expiry) {
    this.expiry = expiry;
  }

  @Scheduled(fixedDelayString = "${iam.assignment.expiry.interval:PT5M}")
  @SchedulerLock(name = LOCK_NAME, lockAtMostFor = "PT10M")
  public void run() {
    try {
      int deleted = runOnce();
      if (deleted > 0) {
        log.info("Deleted {} expired role assignments", deleted);
      }
    } catch (RuntimeException e) {
      log.error("Assignment expiry failed", e);
    }
  }

  /** Batches until one comes back short (each batch is its own transaction). @return total rows deleted */
  public int runOnce() {
    int total = 0;
    int deleted;
    do {
      deleted = expiry.deleteExpiredBatch();
      total += deleted;
    } while (deleted >= expiry.batchSize());
    return total;
  }
}
