package com.acme.iam.product;

import java.util.UUID;
import org.springframework.data.annotation.Id;
import org.springframework.data.annotation.Version;
import org.springframework.data.relational.core.mapping.Table;

/** Product aggregate root (IAM, BILLING, CRM, ...). Permissions and system roles come from the product manifest. */
@Table("product")
public record Product(@Id UUID id, String code, String name, @Version Long version) {

  /** Code of IAM's own product; IAM permissions are always entitled. */
  public static final String IAM_CODE = "IAM";

  /** Id of the IAM product (V3__seed.sql). */
  public static final UUID IAM_ID = UUID.fromString("00000000-0000-7000-8000-000000000001");

  public static Product create(String code, String name) {
    return new Product(null, code, name, null);
  }

  public boolean isIam() {
    return IAM_CODE.equals(code);
  }

  public Product withName(String newName) {
    return new Product(id, code, newName, version);
  }
}
