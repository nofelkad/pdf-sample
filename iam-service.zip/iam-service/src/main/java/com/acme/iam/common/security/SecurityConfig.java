package com.acme.iam.common.security;

import com.acme.iam.core.Claims;
import com.acme.iam.core.revocation.RevocationRegistry;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Stream;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.core.convert.converter.Converter;
import org.springframework.security.authentication.AbstractAuthenticationToken;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configurers.AbstractHttpConfigurer;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.security.oauth2.jwt.JwtDecoder;
import org.springframework.security.oauth2.server.resource.authentication.JwtAuthenticationToken;
import org.springframework.security.oauth2.server.resource.web.BearerTokenResolver;
import org.springframework.security.oauth2.server.resource.web.DefaultBearerTokenResolver;
import org.springframework.security.oauth2.server.resource.web.authentication.BearerTokenAuthenticationFilter;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.header.writers.ReferrerPolicyHeaderWriter;
import org.springframework.security.web.servlet.util.matcher.PathPatternRequestMatcher;
import org.springframework.security.web.util.matcher.AnyRequestMatcher;
import org.springframework.security.web.util.matcher.OrRequestMatcher;
import org.springframework.security.web.util.matcher.RequestMatcher;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.CorsConfigurationSource;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;

/**
 * Spring Security setup (spec section 4). Three stateless chains, all rendering RFC 7807 errors:
 *
 * <ol>
 *   <li>{@code @Order(1)} {@code /auth/**}, {@code /.well-known/**}: public except
 *       {@link #AUTH_AUTHENTICATED_PATHS}; bearer tokens are only read on those paths.
 *   <li>{@code @Order(2)} {@code /api/**}, {@code /internal/**}: authenticated; public only {@code POST /internal/token}
 *       and {@link PermitAllPaths} beans.
 *   <li>{@code @Order(LOWEST_PRECEDENCE - 10)} everything else: health/info/error public, rest 401.
 * </ol>
 *
 * JWT chains: RS256 only, keys from {@link SigningKeyService}, {@code iss} + {@code exp/nbf} with
 * {@code iam.security.clock-skew} (60 s), {@code perms} → authorities ({@link #permsConverter()}),
 * {@link RevocationFilter} after {@link BearerTokenAuthenticationFilter}, {@link ProblemAuthenticationEntryPoint}
 * (401, not audited) and {@link AuditingAccessDeniedHandler} (403 + {@code authz.denied}).
 *
 * <p>A feature that needs its own chain declares a {@code SecurityFilterChain} bean with an {@code @Order} between 3
 * and {@code LOWEST_PRECEDENCE - 11} and calls {@link #jwtResourceServer(HttpSecurity, RequestMatcher)} on it.
 */
@Configuration(proxyBeanMethods = false)
@EnableWebSecurity
@EnableMethodSecurity
@EnableConfigurationProperties(CorsProperties.class)
public class SecurityConfig {

  /** {@code /auth/**} endpoints that need a valid (non-revoked) access token. */
  public static final String[] AUTH_AUTHENTICATED_PATHS =
      {"/auth/logout", "/auth/logout-all", "/auth/switch-tenant", "/auth/password/change"};
  public static final String INTERNAL_TOKEN_PATH = "/internal/token";
  public static final String JWKS_PATH = "/.well-known/jwks.json";
  static final long HSTS_MAX_AGE_SECONDS = 31_536_000L;
  static final String JSON_CSP = "default-src 'none'; frame-ancestors 'none'";
  /** Public outside the JWT chains. */
  public static final String[] PUBLIC_MISC_PATHS = {"/actuator/health", "/actuator/health/**", "/actuator/info", "/error"};

  private final JwtDecoder jwtDecoder;
  private final RevocationRegistry revocationRegistry;
  private final SecurityProblemWriter problems;
  private final ProblemAuthenticationEntryPoint entryPoint;
  private final AuditingAccessDeniedHandler accessDeniedHandler;
  private final CorsConfigurationSource corsSource;

  public SecurityConfig(JwtDecoder jwtDecoder, RevocationRegistry revocationRegistry, SecurityProblemWriter problems,
                        ProblemAuthenticationEntryPoint entryPoint, AuditingAccessDeniedHandler accessDeniedHandler,
                        CorsProperties cors) {
    this.jwtDecoder = jwtDecoder;
    this.revocationRegistry = revocationRegistry;
    this.problems = problems;
    this.entryPoint = entryPoint;
    this.accessDeniedHandler = accessDeniedHandler;
    this.corsSource = corsSource(cors);
  }

  @Bean
  @Order(1)
  SecurityFilterChain authEndpoints(HttpSecurity http) throws Exception {
    RequestMatcher authenticated = matchers(AUTH_AUTHENTICATED_PATHS);
    return jwtResourceServer(http.securityMatcher(matchers("/auth/**", "/.well-known/**")), authenticated)
        .authorizeHttpRequests(a -> a
            .requestMatchers(authenticated).authenticated()
            .anyRequest().permitAll())
        .build();
  }

  @Bean
  @Order(2)
  SecurityFilterChain api(HttpSecurity http, ObjectProvider<PermitAllPaths> extraPublicPaths) throws Exception {
    List<String> publicPaths = new ArrayList<>(List.of(INTERNAL_TOKEN_PATH));
    extraPublicPaths.orderedStream().forEach(p -> publicPaths.addAll(p.patterns()));
    RequestMatcher open = matchers(publicPaths.toArray(String[]::new));
    return jwtResourceServer(http.securityMatcher(matchers("/api/**", "/internal/**")), request -> !open.matches(request))
        .authorizeHttpRequests(a -> a
            .requestMatchers(open).permitAll()
            .anyRequest().authenticated())
        .build();
  }

  @Bean
  @Order(Ordered.LOWEST_PRECEDENCE - 10)
  SecurityFilterChain fallback(HttpSecurity http) throws Exception {
    return stateless(http, false)
        .authorizeHttpRequests(a -> a
            .requestMatchers(matchers(PUBLIC_MISC_PATHS)).permitAll()
            .anyRequest().authenticated())
        .exceptionHandling(e -> e.authenticationEntryPoint(entryPoint).accessDeniedHandler(accessDeniedHandler))
        .build();
  }

  /**
   * Applies the common JWT resource-server setup to {@code http}: stateless, no CSRF/basic/form/logout, IAM JWT
   * decoder + {@link #permsConverter()}, bearer tokens read only where {@code bearerPaths} matches,
   * {@link RevocationFilter} after {@link BearerTokenAuthenticationFilter}, RFC 7807 entry point and auditing
   * access-denied handler. Callers add {@code securityMatcher} before and {@code authorizeHttpRequests} after.
   */
  public HttpSecurity jwtResourceServer(HttpSecurity http, RequestMatcher bearerPaths) throws Exception {
    DefaultBearerTokenResolver standard = new DefaultBearerTokenResolver();
    BearerTokenResolver resolver = request -> bearerPaths.matches(request) ? standard.resolve(request) : null;
    return stateless(http, true)
        .oauth2ResourceServer(o -> o
            .bearerTokenResolver(resolver)
            .jwt(j -> j.decoder(jwtDecoder).jwtAuthenticationConverter(permsConverter()))
            .authenticationEntryPoint(entryPoint)
            .accessDeniedHandler(accessDeniedHandler))
        .addFilterAfter(new RevocationFilter(revocationRegistry, problems), BearerTokenAuthenticationFilter.class)
        .exceptionHandling(e -> e.authenticationEntryPoint(entryPoint).accessDeniedHandler(accessDeniedHandler));
  }

  /**
   * Stateless, no CSRF/basic/form/logout, CORS from {@link CorsProperties} (denied by default) and the security headers
   * (Task 9): HSTS on every response (1 year, sub-domains; browsers ignore it on plain HTTP, and TLS usually ends at a
   * proxy, so it is not limited to secure requests), {@code X-Content-Type-Options: nosniff}, {@code X-Frame-Options:
   * DENY}, {@code Referrer-Policy: no-referrer}, Spring Security's {@code Cache-Control: no-cache, no-store} (unless a
   * handler sets its own) and, on the JSON chains ({@code jsonApi}), {@code Content-Security-Policy: default-src
   * 'none'; frame-ancestors 'none'}.
   */
  private HttpSecurity stateless(HttpSecurity http, boolean jsonApi) throws Exception {
    return http
        .csrf(AbstractHttpConfigurer::disable)
        .httpBasic(AbstractHttpConfigurer::disable)
        .formLogin(AbstractHttpConfigurer::disable)
        .logout(AbstractHttpConfigurer::disable)
        .requestCache(AbstractHttpConfigurer::disable)
        .sessionManagement(s -> s.sessionCreationPolicy(SessionCreationPolicy.STATELESS))
        .cors(c -> c.configurationSource(corsSource))
        .headers(h -> {
          h.httpStrictTransportSecurity(hsts -> hsts.includeSubDomains(true).maxAgeInSeconds(HSTS_MAX_AGE_SECONDS)
              .requestMatcher(AnyRequestMatcher.INSTANCE));
          h.frameOptions(f -> f.deny());
          h.referrerPolicy(r -> r.policy(ReferrerPolicyHeaderWriter.ReferrerPolicy.NO_REFERRER));
          if (jsonApi) {
            h.contentSecurityPolicy(csp -> csp.policyDirectives(JSON_CSP));
          }
        });
  }

  /**
   * CORS for {@code iam.security.cors.allowed-origins}: exact origins, the API methods, the headers a browser client
   * sends, {@code X-Request-Id}/{@code Retry-After} exposed, no credentials, preflight cached 1 h. With no origins the
   * source has no configuration at all (deny by default).
   */
  public static CorsConfigurationSource corsSource(CorsProperties properties) {
    if (properties.allowedOrigins().isEmpty()) {
      return request -> null;
    }
    CorsConfiguration config = new CorsConfiguration();
    config.setAllowedOrigins(properties.allowedOrigins());
    config.setAllowedMethods(List.of("GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS"));
    config.setAllowedHeaders(List.of("Authorization", "Content-Type", "X-Request-Id"));
    config.setExposedHeaders(List.of("X-Request-Id", "Retry-After", "Location", "Content-Disposition"));
    config.setAllowCredentials(false);
    config.setMaxAge(Duration.ofHours(1));
    UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
    source.registerCorsConfiguration("/**", config);
    return source;
  }

  private static RequestMatcher matchers(String... patterns) {
    PathPatternRequestMatcher.Builder builder = PathPatternRequestMatcher.withDefaults();
    return new OrRequestMatcher(Arrays.stream(patterns).<RequestMatcher>map(builder::matcher).toList());
  }

  /**
   * {@code perms} → authorities, principal name = {@code sub}. User tokens never get {@code internal.*} authorities;
   * application tokens only get {@code internal.*} ones.
   */
  public static Converter<Jwt, AbstractAuthenticationToken> permsConverter() {
    return jwt -> {
      boolean app = AppCaller.isApp(jwt);
      List<String> perms = jwt.getClaimAsStringList(Claims.PERMISSIONS);
      List<SimpleGrantedAuthority> authorities = (perms == null ? Stream.<String>empty() : perms.stream())
          .filter(p -> p.startsWith(Claims.INTERNAL_PERMISSION_PREFIX) == app)
          .map(SimpleGrantedAuthority::new)
          .toList();
      return new JwtAuthenticationToken(jwt, authorities, jwt.getSubject());
    };
  }

}
