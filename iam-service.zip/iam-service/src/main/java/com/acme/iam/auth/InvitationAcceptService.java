package com.acme.iam.auth;

import com.acme.iam.account.AccountStatus;
import com.acme.iam.audit.AuditEvent.Outcome;
import com.acme.iam.common.error.ApiException;
import com.acme.iam.common.error.BadRequestException;
import com.acme.iam.user.TokenPurpose;
import com.acme.iam.user.UserCredentialService;
import com.acme.iam.user.UserStatus;
import com.acme.iam.user.UserToken;
import com.acme.iam.user.UserTokenService;
import java.util.List;
import java.util.UUID;
import org.springframework.lang.Nullable;
import org.springframework.stereotype.Service;

/**
 * {@code POST /auth/invitations/accept}: consumes the {@code INVITE} token (issued by the user administration, 7 days),
 * sets the password under the account's policy, moves the user INVITED → ACTIVE (optionally setting the display name)
 * and logs the user in (session in the primary tenant). The policy check (breached check included) and Argon2
 * hashing run before the transaction against the token's owner (peeked, not consumed); the transaction then consumes
 * the token and activates the user. Any rejection leaves the token usable. Audited {@value AuthAuditService#INVITATION_ACCEPTED}.
 */
@Service
public class InvitationAcceptService {

  private final UserTokenService userTokens;
  private final UserCredentialService credentials;
  private final PasswordService passwords;
  private final AccessStateQuery access;
  private final SessionService sessions;
  private final AuthAuditService audit;
  private final AuthTransactions tx;

  public InvitationAcceptService(UserTokenService userTokens, UserCredentialService credentials,
                                 PasswordService passwords, AccessStateQuery access, SessionService sessions,
                                 AuthAuditService audit, AuthTransactions tx) {
    this.userTokens = userTokens;
    this.credentials = credentials;
    this.passwords = passwords;
    this.access = access;
    this.sessions = sessions;
    this.audit = audit;
    this.tx = tx;
  }

  /**
   * @throws ApiException 400 {@code invalid_token} (unknown, used, expired, other purpose, user not INVITED) or
   *     {@code password_policy}; 403 {@code access_inactive} (account, primary tenant or membership not ACTIVE)
   */
  public AuthTokens accept(String rawToken, String password, @Nullable String displayName, ClientInfo client) {
    try {
      // the policy check (incl. the breached check) and Argon2 hashing happen before the transaction
      UUID userId = credentials.usableTokenOwner(rawToken, TokenPurpose.INVITE)
          .orElseThrow(InvitationAcceptService::invalidToken);
      AccessState before = invitedState(userId);
      PasswordPolicy policy = passwords.policy(before.accountSettings());
      passwords.validate(policy, password, List.of());
      String hash = passwords.hash(password);
      String name = displayName == null || displayName.isBlank() ? null : displayName.trim();

      return tx.write(() -> {
        UserToken token = userTokens.consume(rawToken, TokenPurpose.INVITE);
        if (!token.user().equals(userId)) {
          throw invalidToken();
        }
        AccessState state = invitedState(userId);
        if (!credentials.activateInvited(userId, hash, name, policy.historySize())) {
          throw invalidToken();
        }
        credentials.recordSuccessfulLogin(userId);
        SessionService.OpenedSession session = sessions.open(userId, state.primaryTenantId(), sessions.ttl(state),
            client);
        audit.event(AuthAuditService.INVITATION_ACCEPTED, client)
            .user(userId, state.accountId(), state.primaryTenantId(), session.sessionId())
            .meta("email", state.email())
            .write();
        return sessions.issue(userId, state.accountId(), state.primaryTenantId(), session.sessionId(),
            state.sessionVersion(), session.refreshToken(), session.refreshExpiresAt());
      });
    } catch (ApiException e) {
      audit.event(AuthAuditService.INVITATION_ACCEPTED, client).outcome(Outcome.FAILURE)
          .meta("reason", e.code()).write();
      throw e;
    }
  }

  /** The INVITED user's state; account, primary tenant and membership must be ACTIVE. */
  private AccessState invitedState(UUID userId) {
    AccessState state = access.load(userId, null)
        .filter(s -> s.userStatus() == UserStatus.INVITED)
        .orElseThrow(InvitationAcceptService::invalidToken);
    if (state.accountStatus() != AccountStatus.ACTIVE || state.tenantDenial().isPresent()) {
      throw AuthErrors.accessInactive();
    }
    return state;
  }

  private static BadRequestException invalidToken() {
    return new BadRequestException(UserTokenService.INVALID_TOKEN, "The link is invalid or has expired");
  }
}
