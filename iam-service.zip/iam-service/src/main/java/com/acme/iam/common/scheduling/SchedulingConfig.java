package com.acme.iam.common.scheduling;

import javax.sql.DataSource;
import net.javacrumbs.shedlock.core.LockProvider;
import net.javacrumbs.shedlock.provider.jdbctemplate.JdbcTemplateLockProvider;
import net.javacrumbs.shedlock.spring.annotation.EnableSchedulerLock;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.scheduling.annotation.EnableScheduling;

/**
 * {@code @Scheduled} + ShedLock (spec section 1). Cluster-wide jobs add
 * {@code @SchedulerLock(name = "<unique-job-name>", lockAtMostFor = "...")} next to {@code @Scheduled}; jobs every
 * instance must run (pollers, caches) omit it. Locks live in the {@code shedlock} table (V1) and use database time,
 * so instance clock drift does not matter.
 *
 * <p>Keep the scheduled method itself non-transactional and call a {@code @Transactional} service from it, so the
 * lock is held around the whole transaction.
 */
@Configuration(proxyBeanMethods = false)
@EnableScheduling
@EnableSchedulerLock(defaultLockAtMostFor = SchedulingConfig.DEFAULT_LOCK_AT_MOST_FOR)
public class SchedulingConfig {

  public static final String DEFAULT_LOCK_AT_MOST_FOR = "PT10M";

  @Bean
  public LockProvider lockProvider(DataSource dataSource) {
    return new JdbcTemplateLockProvider(JdbcTemplateLockProvider.Configuration.builder()
        .withJdbcTemplate(new JdbcTemplate(dataSource))
        .usingDbTime()
        .build());
  }
}
