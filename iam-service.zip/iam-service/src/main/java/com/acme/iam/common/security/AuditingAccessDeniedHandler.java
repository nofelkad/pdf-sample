package com.acme.iam.common.security;

import com.acme.iam.audit.AuditEvent;
import com.acme.iam.audit.AuditWriter;
import com.acme.iam.common.error.ApiException;
import com.acme.iam.common.error.ForbiddenException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.lang.Nullable;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.authorization.AuthorityAuthorizationDecision;
import org.springframework.security.authorization.AuthorizationDeniedException;
import org.springframework.security.authorization.AuthorizationResult;
import org.springframework.security.authorization.ExpressionAuthorizationDecision;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.web.access.AccessDeniedHandler;
import org.springframework.stereotype.Component;

/**
 * 403 for authenticated callers that lack a permission ({@code @PreAuthorize} or URL rule): writes one
 * {@code authz.denied} audit event (outcome DENIED; metadata {@code method}, {@code path} and
 * {@code requiredAuthority} when it can be read from the failed expression, otherwise {@code reason}) and answers an
 * RFC 7807 body with {@code code = "forbidden"}. Application callers are attributed with {@code source = app:<id>}
 * and {@code metadata.client_id}. A {@link CodedAccessDeniedException} (e.g. {@code scope_exceeded}) is audited with
 * {@code reason = code} plus its own metadata and rendered with its {@code code} and message.
 *
 * <p>The audit insert runs in its own transaction ({@link AuditWriter#writeIndependently}): the request's transaction,
 * if any, rolls back. An audit failure is logged and does not change the 403. 403 {@code ApiException}s thrown by
 * services are audited through {@link #auditApiDenial} (final review I1).
 */
@Component
public class AuditingAccessDeniedHandler implements AccessDeniedHandler {

  public static final String ACTION = "authz.denied";

  private static final Logger log = LoggerFactory.getLogger(AuditingAccessDeniedHandler.class);
  private static final Pattern AUTHORITY_EXPRESSION =
      Pattern.compile("has(?:Any)?Authority\\(([^)]*)\\)");
  private static final Pattern QUOTED = Pattern.compile("'([^']*)'");

  private final AuditWriter auditWriter;
  private final SecurityProblemWriter problems;

  public AuditingAccessDeniedHandler(AuditWriter auditWriter, SecurityProblemWriter problems) {
    this.auditWriter = auditWriter;
    this.problems = problems;
  }

  @Override
  public void handle(HttpServletRequest request, HttpServletResponse response, AccessDeniedException ex)
      throws IOException {
    audit(request, ex);
    if (ex instanceof CodedAccessDeniedException coded) {
      problems.write(request, response, HttpStatus.FORBIDDEN, coded.code(), coded.getMessage());
    } else {
      problems.write(request, response, HttpStatus.FORBIDDEN, "forbidden", "Access denied");
    }
  }

  /**
   * Final review I1: a 403 {@link ApiException} raised by a service (for example I6 {@code grantor_lacks_permissions},
   * I8 {@code platform_role_restricted}, {@code system_role_read_only}) is rendered by {@code GlobalExceptionHandler},
   * never reaching this handler; that handler calls this method so the denial is audited the same way
   * ({@code authz.denied}, {@code reason = code}, the exception's properties as metadata). Flows that audit their own
   * denials throw {@link ForbiddenException#alreadyAudited} and are skipped.
   */
  public void auditApiDenial(HttpServletRequest request, ApiException ex) {
    if (ex.status() != HttpStatus.FORBIDDEN
        || ex instanceof ForbiddenException forbidden && forbidden.isAlreadyAudited()) {
      return;
    }
    Map<String, Object> metadata = new LinkedHashMap<>(ex.properties());
    metadata.put("reason", ex.code());
    audit(request, metadata);
  }

  private void audit(HttpServletRequest request, AccessDeniedException ex) {
    Map<String, Object> metadata = new LinkedHashMap<>();
    if (ex instanceof CodedAccessDeniedException coded) {
      metadata.putAll(coded.auditMetadata());
      metadata.put("reason", coded.code()); // reserved keys (reason, method, path, client_id) always win
    } else {
      requiredAuthority(ex).ifPresentOrElse(
          required -> metadata.put("requiredAuthority", required),
          () -> metadata.put("reason", ex.getMessage()));
    }
    audit(request, metadata);
  }

  private void audit(HttpServletRequest request, Map<String, Object> metadata) {
    try {
      metadata.put("method", request.getMethod());
      metadata.put("path", request.getRequestURI());
      AuditEvent.Builder event = AuditEvent.forCurrentActor(ACTION)
          .outcome(AuditEvent.Outcome.DENIED)
          .actorIp(request.getRemoteAddr())
          .userAgent(request.getHeader(HttpHeaders.USER_AGENT));
      AppCaller.currentClientId().ifPresent(clientId -> {
        event.source(AppCaller.source(clientId));
        metadata.put("client_id", clientId);
      });
      auditWriter.writeIndependently(event.metadata(metadata).build()); // survives the request's rollback
    } catch (RuntimeException e) {
      log.error("Could not audit {} for {} {}", ACTION, request.getMethod(), request.getRequestURI(), e);
    }
  }

  /** Authorities named by the failed decision, comma separated; empty when not determinable. */
  static Optional<String> requiredAuthority(AccessDeniedException ex) {
    if (!(ex instanceof AuthorizationDeniedException denied)) {
      return Optional.empty();
    }
    AuthorizationResult result = denied.getAuthorizationResult();
    if (result instanceof AuthorityAuthorizationDecision decision) {
      return join(decision.getAuthorities().stream().map(GrantedAuthority::getAuthority).toList());
    }
    if (result instanceof ExpressionAuthorizationDecision decision) {
      return fromExpression(decision.getExpression().getExpressionString());
    }
    return Optional.empty();
  }

  static Optional<String> fromExpression(@Nullable String expression) {
    if (expression == null) {
      return Optional.empty();
    }
    List<String> authorities = new ArrayList<>();
    Matcher call = AUTHORITY_EXPRESSION.matcher(expression);
    while (call.find()) {
      Matcher quoted = QUOTED.matcher(call.group(1));
      while (quoted.find()) {
        authorities.add(quoted.group(1));
      }
    }
    return join(authorities);
  }

  private static Optional<String> join(List<String> authorities) {
    return authorities.isEmpty() ? Optional.empty() : Optional.of(String.join(",", authorities));
  }
}
