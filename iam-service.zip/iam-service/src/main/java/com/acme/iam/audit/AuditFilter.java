package com.acme.iam.audit;

import com.acme.iam.audit.AuditEvent.Outcome;
import java.time.Instant;
import java.util.UUID;
import org.springframework.lang.Nullable;

/**
 * Raw filters of an audit search, history or export request, exactly as the caller sent them. Turned into an
 * {@link AuditSearchCriteria} (validated, account resolved) by {@link AuditQueryService#criteria}.
 *
 * @param accountId only honoured for callers holding {@code platform.account.manage}
 * @param action    prefix of the action, e.g. {@code iam.role.}
 * @param cursor    opaque cursor of the previous page
 */
public record AuditFilter(
    @Nullable UUID accountId,
    @Nullable UUID tenantId,
    @Nullable UUID actorUserId,
    @Nullable String action,
    @Nullable String targetType,
    @Nullable String targetId,
    @Nullable Outcome outcome,
    @Nullable Instant from,
    @Nullable Instant to,
    @Nullable String cursor,
    @Nullable Integer limit) {}
