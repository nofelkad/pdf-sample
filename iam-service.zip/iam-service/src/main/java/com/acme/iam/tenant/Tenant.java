package com.acme.iam.tenant;

import com.acme.iam.account.Account;
import java.time.Instant;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.Id;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.annotation.Version;
import org.springframework.data.jdbc.core.mapping.AggregateReference;
import org.springframework.data.relational.core.mapping.MappedCollection;
import org.springframework.data.relational.core.mapping.Table;

/** Tenant aggregate root. Owns its {@link TenantProduct} switches; references its account by id. */
@Table("tenant")
public record Tenant(
    @Id UUID id,
    AggregateReference<Account, UUID> accountId,
    String name,
    String slug,
    TenantStatus status,
    Map<String, Object> settings,
    @MappedCollection(idColumn = "tenant") Set<TenantProduct> products,
    @Version Long version,
    @CreatedDate Instant createdAt,
    @LastModifiedDate Instant updatedAt) {

  public Tenant {
    settings = settings == null ? Map.of() : settings;
    products = products == null ? Set.of() : Set.copyOf(products);
  }

  /** A new ACTIVE tenant of {@code accountId} with empty settings and no products. */
  public static Tenant create(UUID accountId, String name, String slug) {
    return new Tenant(null, AggregateReference.to(accountId), name, slug, TenantStatus.ACTIVE, Map.of(), Set.of(),
        null, null, null);
  }

  /** The owning account id (never {@code null}). */
  public UUID account() {
    return accountId.getId();
  }

  public boolean isActive() {
    return status == TenantStatus.ACTIVE;
  }

  public Tenant withName(String newName) {
    return new Tenant(id, accountId, newName, slug, status, settings, products, version, createdAt, updatedAt);
  }

  public Tenant withStatus(TenantStatus newStatus) {
    return new Tenant(id, accountId, name, slug, newStatus, settings, products, version, createdAt, updatedAt);
  }

  public Tenant withSettings(Map<String, Object> newSettings) {
    return new Tenant(id, accountId, name, slug, status, newSettings, products, version, createdAt, updatedAt);
  }

  public Tenant withProducts(Set<TenantProduct> newProducts) {
    return new Tenant(id, accountId, name, slug, status, settings, newProducts, version, createdAt, updatedAt);
  }
}
