package com.acme.iam.product;

import java.util.Optional;
import java.util.UUID;
import org.springframework.data.repository.ListCrudRepository;

/** Persistence of {@link Product}. Private to the {@code product} feature; use {@link ProductService}. */
public interface ProductRepository extends ListCrudRepository<Product, UUID> {

  Optional<Product> findByCode(String code);
}
