package com.acme.iam.product;

import com.acme.iam.common.error.NotFoundException;
import java.util.Collection;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import org.springframework.stereotype.Service;

/**
 * Product and permission lookups used by other features. Task 2 provides only the reads the authorization kernel
 * needs; the manifest registry (Task 6) extends this feature.
 */
@Service
public class ProductService {

  private final ProductRepository products;
  private final PermissionRepository permissions;

  public ProductService(ProductRepository products, PermissionRepository permissions) {
    this.products = products;
    this.permissions = permissions;
  }

  public Optional<Product> findById(UUID productId) {
    return products.findById(productId);
  }

  /** @throws NotFoundException {@code product_not_found} */
  public Product getById(UUID productId) {
    return products.findById(productId)
        .orElseThrow(() -> new NotFoundException("product_not_found", "Product not found"));
  }

  public Optional<Product> findByCode(String code) {
    return products.findByCode(code);
  }

  /** The permissions with the given ids that exist (unknown ids are silently absent from the result). */
  public List<Permission> findPermissions(Collection<UUID> permissionIds) {
    if (permissionIds.isEmpty()) {
      return List.of();
    }
    return permissions.findAllById(permissionIds);
  }

  /** The permissions with these codes that exist (unknown codes are silently absent from the result). */
  public List<Permission> findPermissionsByCodes(Collection<String> codes) {
    if (codes.isEmpty()) {
      return List.of();
    }
    return permissions.findAllByCodes(codes);
  }

  public Optional<Permission> findPermissionByCode(String code) {
    return permissions.findByCode(code);
  }

  public List<Permission> findPermissionsOfProduct(UUID productId) {
    return permissions.findAllByProduct(productId);
  }
}
