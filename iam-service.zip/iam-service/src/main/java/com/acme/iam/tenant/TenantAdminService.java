package com.acme.iam.tenant;

import com.acme.iam.account.Account;
import com.acme.iam.account.AccountService;
import com.acme.iam.account.AccountStatus;
import com.acme.iam.assignment.LastAdminService;
import com.acme.iam.auth.RevocationService;
import com.acme.iam.common.error.BadRequestException;
import com.acme.iam.common.error.ConflictException;
import com.acme.iam.common.error.NotFoundException;
import com.acme.iam.common.paging.KeysetCursor;
import com.acme.iam.common.paging.KeysetPage;
import com.acme.iam.product.Product;
import com.acme.iam.product.ProductService;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.time.Clock;
import java.time.Instant;
import java.time.LocalDate;
import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.util.Collection;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import java.util.stream.Collectors;
import org.springframework.jdbc.core.simple.JdbcClient;
import org.springframework.lang.Nullable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

/**
 * Tenant administration (P1-6.3): create, update, suspend, reactivate, archive and the product switches, always inside
 * the caller's account (I10).
 *
 * <ul>
 *   <li><b>I5:</b> an <em>enabled</em> {@code tenant_product} must be a product the account is entitled to (ACTIVE or
 *       TRIAL subscription that has not ended; IAM is always entitled). A disabled switch grants nothing and is
 *       allowed. When an account's entitlements shrink, {@link #disableProductsNotEntitled} switches the affected
 *       tenant products off. Every tenant write first locks the account row {@code FOR SHARE}, so it serialises with a
 *       concurrent change of the account's subscriptions or status.
 *   <li><b>Revocation:</b> suspend, archive and switching a product off call
 *       {@link RevocationService#revokeTenantMembers} once, as the transaction's last write.
 *   <li><b>Status:</b> ACTIVE ⇄ SUSPENDED; ARCHIVED is terminal (any write to it is {@code tenant_not_active});
 *       writes in a CLOSED account are {@code account_closed}.
 *   <li><b>Last admin (ruling R43):</b> suspending or archiving a tenant that is the primary tenant of every remaining
 *       effective admin of the account is 409 {@code last_admin} ({@link LastAdminService#requireAdminOutsideTenant}):
 *       login, refresh and switch deny when the primary tenant is not ACTIVE, so the account would be locked out.
 * </ul>
 */
@Service
public class TenantAdminService {

  /** A product switch in a request: product code and whether it is enabled. */
  public record ProductSwitch(String code, boolean enabled) {}

  public record TenantProductView(UUID productId, String productCode, boolean enabled) {}

  public record TenantView(UUID id, UUID accountId, String name, String slug, TenantStatus status,
      Map<String, Object> settings, List<TenantProductView> products, Instant createdAt, Instant updatedAt) {}

  public record TenantSummary(UUID id, String name, String slug, TenantStatus status, Instant createdAt) {}

  private final TenantRepository tenants;
  private final AccountService accounts;
  private final ProductService products;
  private final RevocationService revocations;
  private final LastAdminService lastAdmin;
  private final JdbcClient jdbc;
  private final ObjectMapper objectMapper;
  private final Clock clock;

  public TenantAdminService(TenantRepository tenants, AccountService accounts, ProductService products,
      RevocationService revocations, LastAdminService lastAdmin, JdbcClient jdbc,
      ObjectMapper objectMapper, Clock clock) {
    this.tenants = tenants;
    this.accounts = accounts;
    this.products = products;
    this.revocations = revocations;
    this.lastAdmin = lastAdmin;
    this.jdbc = jdbc;
    this.objectMapper = objectMapper;
    this.clock = clock;
  }

  // ------------------------------------------------------------------------------------------------- reads

  /** Keyset page of the account's tenants, newest first. */
  public KeysetPage<TenantSummary> list(UUID accountId, @Nullable TenantStatus status, @Nullable String cursor,
      @Nullable Integer limit) {
    int size = KeysetPage.limit(limit);
    Optional<KeysetCursor> after = KeysetCursor.decode(cursor);
    StringBuilder sql = new StringBuilder(
        "SELECT id, name, slug, status, created_at FROM tenant WHERE account_id = :accountId\n");
    if (status != null) {
      sql.append("  AND status = :status\n");
    }
    if (after.isPresent()) {
      sql.append("  AND (created_at, id) < (:cursorAt, :cursorId)\n");
    }
    sql.append("ORDER BY created_at DESC, id DESC LIMIT :limit");
    JdbcClient.StatementSpec spec = jdbc.sql(sql.toString()).param("accountId", accountId).param("limit", size + 1);
    if (status != null) {
      spec = spec.param("status", status.name());
    }
    if (after.isPresent()) {
      spec = spec.param("cursorAt", after.get().createdAtParam()).param("cursorId", after.get().id());
    }
    List<TenantSummary> rows = spec.query((rs, i) -> new TenantSummary(
        rs.getObject("id", UUID.class), rs.getString("name"), rs.getString("slug"),
        TenantStatus.valueOf(rs.getString("status")),
        rs.getObject("created_at", OffsetDateTime.class).toInstant())).list();
    return KeysetPage.of(rows, size, TenantSummary::createdAt, TenantSummary::id);
  }

  public TenantView get(UUID accountId, UUID tenantId) {
    return view(load(accountId, tenantId));
  }

  /**
   * The tenant if it belongs to the account.
   *
   * @throws NotFoundException {@code tenant_not_found} for an unknown tenant or one of another account (I10)
   */
  public Tenant load(UUID accountId, UUID tenantId) {
    return tenants.findByIdInAccount(tenantId, accountId)
        .orElseThrow(() -> new NotFoundException("tenant_not_found", "Tenant not found"));
  }

  // ------------------------------------------------------------------------------------------------ writes

  /**
   * Creates an ACTIVE tenant with the given product switches (I5).
   *
   * @throws ConflictException {@code slug_taken} when the account already has a tenant with this slug
   * @throws BadRequestException {@code unknown_product}, {@code product_not_subscribed}
   */
  @Transactional
  public TenantView create(UUID accountId, String name, String slug, List<ProductSwitch> switches) {
    Map<UUID, Boolean> resolved = resolve(switches);
    return view(createInternal(accountId, name, slug, resolved));
  }

  /**
   * Creates an ACTIVE tenant with exactly {@code enabledProducts} switched on. Used by account bootstrap (default
   * tenant) and the platform bootstrap CLI. Joins the caller's transaction.
   */
  @Transactional
  public Tenant createWithProducts(UUID accountId, String name, String slug, Collection<UUID> enabledProducts) {
    Map<UUID, Boolean> switches = new LinkedHashMap<>();
    enabledProducts.forEach(p -> switches.put(p, true));
    return createInternal(accountId, name, slug, switches);
  }

  @Transactional
  public TenantView update(UUID accountId, UUID tenantId, @Nullable String name,
      @Nullable Map<String, Object> settings) {
    Tenant tenant = loadForWrite(accountId, tenantId);
    requireNotArchived(tenant);
    if (name == null && settings == null) {
      return view(tenant);
    }
    jdbc.sql("""
            UPDATE tenant SET name = COALESCE(CAST(:name AS text), name),
                              settings = COALESCE(CAST(:settings AS jsonb), settings),
                              version = version + 1, updated_at = :now
            WHERE id = :id AND account_id = :account""")
        .param("name", name).param("settings", settings == null ? null : json(settings))
        .param("now", now()).param("id", tenantId).param("account", accountId)
        .update();
    return view(load(accountId, tenantId));
  }

  /** ACTIVE → SUSPENDED and revokes every member's tokens; no-op when already suspended. */
  @Transactional
  public TenantView suspend(UUID accountId, UUID tenantId) {
    Tenant tenant = loadForWrite(accountId, tenantId);
    requireNotArchived(tenant);
    if (tenant.status() == TenantStatus.SUSPENDED) {
      return view(tenant);
    }
    lastAdmin.requireAdminOutsideTenant(accountId, tenantId); // R43
    setStatus(accountId, tenantId, TenantStatus.SUSPENDED);
    revocations.revokeTenantMembers(tenantId, "tenant.suspended");
    return view(load(accountId, tenantId));
  }

  /** SUSPENDED → ACTIVE; no-op when already active. */
  @Transactional
  public TenantView reactivate(UUID accountId, UUID tenantId) {
    Tenant tenant = loadForWrite(accountId, tenantId);
    requireNotArchived(tenant);
    if (tenant.isActive()) {
      return view(tenant);
    }
    setStatus(accountId, tenantId, TenantStatus.ACTIVE);
    return view(load(accountId, tenantId));
  }

  /** → ARCHIVED (terminal) and revokes every member's tokens; no-op when already archived. */
  @Transactional
  public TenantView archive(UUID accountId, UUID tenantId) {
    Tenant tenant = loadForWrite(accountId, tenantId);
    if (tenant.status() == TenantStatus.ARCHIVED) {
      return view(tenant);
    }
    lastAdmin.requireAdminOutsideTenant(accountId, tenantId); // R43
    setStatus(accountId, tenantId, TenantStatus.ARCHIVED);
    revocations.revokeTenantMembers(tenantId, "tenant.archived");
    return view(load(accountId, tenantId));
  }

  /**
   * Replaces the tenant's product switches (I5). Products not listed are removed. When a previously enabled product
   * is no longer enabled, every member's tokens are revoked.
   */
  @Transactional
  public TenantView setProducts(UUID accountId, UUID tenantId, List<ProductSwitch> switches) {
    Tenant tenant = loadForWrite(accountId, tenantId);
    requireNotArchived(tenant);
    Map<UUID, Boolean> resolved = resolve(switches);
    requireEntitled(accountId, resolved);
    Set<UUID> enabledBefore = enabled(tenant.products());
    Tenant saved = tenants.save(tenant.withProducts(toProducts(resolved)));
    Set<UUID> lost = new HashSet<>(enabledBefore);
    lost.removeAll(enabled(saved.products()));
    if (!lost.isEmpty()) {
      revocations.revokeTenantMembers(tenantId, "tenant.products.disabled");
    }
    return view(saved);
  }

  /**
   * I5 after an account's entitlements shrink: switches off, in every tenant of the account, each enabled product not
   * in {@code entitledProducts} (IAM is never touched). Joins the caller's transaction; the caller revokes.
   *
   * @return number of switches turned off
   */
  @Transactional(propagation = Propagation.MANDATORY)
  public int disableProductsNotEntitled(UUID accountId, Set<UUID> entitledProducts) {
    String entitled = entitledProducts.stream().map(UUID::toString).sorted()
        .collect(Collectors.joining(",", "{", "}"));
    return jdbc.sql("""
            UPDATE tenant_product tp SET enabled = false
            FROM tenant t
            WHERE tp.tenant = t.id AND t.account_id = :accountId AND tp.enabled
              AND tp.product_id <> :iam
              AND NOT (tp.product_id = ANY (CAST(:entitled AS uuid[])))""")
        .param("accountId", accountId)
        .param("iam", Product.IAM_ID)
        .param("entitled", entitled)
        .update();
  }

  // ---------------------------------------------------------------------------------------------- internals

  /**
   * Final review M6: status, name and settings changes are targeted UPDATEs of the tenant row. Saving the aggregate
   * rewrote (delete + insert) every {@code tenant_product} row, and the trigger audited each as a change.
   */
  private void setStatus(UUID accountId, UUID tenantId, TenantStatus status) {
    jdbc.sql("""
            UPDATE tenant SET status = :status, version = version + 1, updated_at = :now
            WHERE id = :id AND account_id = :account""")
        .param("status", status.name()).param("now", now()).param("id", tenantId).param("account", accountId)
        .update();
  }

  private String json(Map<String, Object> settings) {
    try {
      return objectMapper.writeValueAsString(settings);
    } catch (JsonProcessingException e) {
      throw new BadRequestException("invalid_settings", "settings must be a JSON object");
    }
  }

  private OffsetDateTime now() {
    return OffsetDateTime.ofInstant(clock.instant(), ZoneOffset.UTC);
  }

  private Tenant createInternal(UUID accountId, String name, String rawSlug, Map<UUID, Boolean> switches) {
    String slug = rawSlug.toLowerCase(Locale.ROOT);
    lockOpenAccount(accountId);
    requireEntitled(accountId, switches);
    if (jdbc.sql("SELECT EXISTS (SELECT 1 FROM tenant WHERE account_id = :a AND slug = :s)")
        .param("a", accountId).param("s", slug).query(Boolean.class).single()) {
      throw new ConflictException("slug_taken", "The account already has a tenant with this slug");
    }
    return tenants.save(Tenant.create(accountId, name, slug).withProducts(toProducts(switches)));
  }

  /** Product codes → ids; unknown or repeated codes are rejected. */
  private Map<UUID, Boolean> resolve(@Nullable List<ProductSwitch> switches) {
    Map<UUID, Boolean> resolved = new LinkedHashMap<>();
    if (switches == null) {
      return resolved;
    }
    for (ProductSwitch s : switches) {
      Product product = products.findByCode(s.code()).orElseThrow(() -> new BadRequestException("unknown_product",
          "Unknown product " + s.code(), Map.of("products", List.of(s.code()))));
      if (resolved.put(product.id(), s.enabled()) != null) {
        throw new BadRequestException("duplicate_product", "Product listed twice: " + s.code(),
            Map.of("products", List.of(s.code())));
      }
    }
    return resolved;
  }

  /** Locks the account row (then the tenant is read) for a tenant write. */
  private Tenant loadForWrite(UUID accountId, UUID tenantId) {
    lockOpenAccount(accountId);
    return load(accountId, tenantId);
  }

  /**
   * Takes the account row {@code FOR SHARE} for the rest of the transaction, so the entitlement check (I5) and the
   * write serialise with a concurrent subscription shrink or account close (both update that row).
   *
   * @throws ConflictException {@code account_closed}
   */
  private void lockOpenAccount(UUID accountId) {
    String status = jdbc.sql("SELECT status FROM account WHERE id = :a FOR SHARE").param("a", accountId)
        .query(String.class).optional()
        .orElseThrow(() -> new NotFoundException("account_not_found", "Account not found"));
    if (AccountStatus.CLOSED.name().equals(status)) {
      throw new ConflictException("account_closed", "The account is closed");
    }
  }

  /** I5: every enabled product is IAM or entitled for the account today (call after {@link #lockOpenAccount}). */
  private void requireEntitled(UUID accountId, Map<UUID, Boolean> switches) {
    Account account = accounts.getById(accountId);
    Set<UUID> entitled = account.entitledProductIds(LocalDate.now(clock));
    List<String> missing = switches.entrySet().stream()
        .filter(e -> e.getValue() && !Product.IAM_ID.equals(e.getKey()) && !entitled.contains(e.getKey()))
        .map(e -> products.getById(e.getKey()).code())
        .sorted()
        .toList();
    if (!missing.isEmpty()) {
      throw new BadRequestException("product_not_subscribed",
          "The account has no active subscription for these products", Map.of("products", missing));
    }
  }

  private void requireNotArchived(Tenant tenant) {
    if (tenant.status() == TenantStatus.ARCHIVED) {
      throw new ConflictException("tenant_not_active", "The tenant is archived");
    }
  }

  private static Set<TenantProduct> toProducts(Map<UUID, Boolean> switches) {
    return switches.entrySet().stream().map(e -> new TenantProduct(e.getKey(), e.getValue()))
        .collect(Collectors.toSet());
  }

  private static Set<UUID> enabled(Set<TenantProduct> products) {
    return products.stream().filter(TenantProduct::enabled).map(TenantProduct::productId).collect(Collectors.toSet());
  }

  private TenantView view(Tenant t) {
    Map<UUID, String> codes = new HashMap<>();
    List<TenantProductView> productViews = t.products().stream()
        .map(p -> new TenantProductView(p.productId(),
            codes.computeIfAbsent(p.productId(), id -> products.getById(id).code()), p.enabled()))
        .sorted(Comparator.comparing(TenantProductView::productCode))
        .toList();
    return new TenantView(t.id(), t.account(), t.name(), t.slug(), t.status(), t.settings(), productViews,
        t.createdAt(), t.updatedAt());
  }
}
