package com.acme.iam.audit;

import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.util.HashMap;
import java.util.Map;

/**
 * Builds the audit search SQL from fixed fragments. Nothing a caller sends is ever concatenated into the statement:
 * the only variable parts are which of the fixed {@code AND ...} fragments are present, and every value is a bound
 * named parameter. The account predicate is unconditional (I10).
 *
 * <p>Ordering is {@code occurred_at DESC, event_id DESC}; the keyset condition repeats {@code occurred_at <= :curAt}
 * next to the row comparison so that partitions and index ranges newer than the cursor are excluded.
 */
final class AuditSearchSql {

  /** Columns of {@code audit_event} as read by search and export; jsonb as text, {@code actor_ip} without netmask. */
  static final String COLUMNS = """
      event_id, occurred_at, received_at, account_id, tenant_id, source, actor_user_id, actor_type,
      host(actor_ip) AS actor_ip, user_agent, session_id, request_id, action, target_type, target_id, outcome,
      before_state::text AS before_state, after_state::text AS after_state, metadata::text AS metadata""";

  private static final String BASE = "SELECT " + COLUMNS + "\nFROM audit_event\nWHERE account_id = :accountId";

  /** {@code ESCAPE '\'}: the backslash is the LIKE escape character (standard_conforming_strings is on). */
  private static final String ACTION_PREFIX = " AND action LIKE :actionPrefix ESCAPE '\\'";

  private static final String ORDER = "\nORDER BY occurred_at DESC, event_id DESC";

  record Query(String sql, Map<String, Object> params) {}

  private AuditSearchSql() {}

  /** One page: up to {@code limit + 1} rows (the extra row tells whether there is a next page). */
  static Query page(AuditSearchCriteria c) {
    Query q = filtered(c, true);
    q.params().put("limit", c.limit() + 1);
    return new Query(q.sql() + "\nLIMIT :limit", q.params());
  }

  /** Every matching row, no cursor and no limit (CSV export). */
  static Query all(AuditSearchCriteria c) {
    return filtered(c, false);
  }

  private static Query filtered(AuditSearchCriteria c, boolean withCursor) {
    StringBuilder sql = new StringBuilder(BASE);
    Map<String, Object> params = new HashMap<>();
    params.put("accountId", c.accountId());
    if (c.from() != null) {
      sql.append(" AND occurred_at >= :from");
      params.put("from", utc(c.from()));
    }
    if (c.to() != null) {
      sql.append(" AND occurred_at < :to");
      params.put("to", utc(c.to()));
    }
    if (c.tenantId() != null) {
      sql.append(" AND tenant_id = :tenantId");
      params.put("tenantId", c.tenantId());
    }
    if (c.actorUserId() != null) {
      sql.append(" AND actor_user_id = :actorUserId");
      params.put("actorUserId", c.actorUserId());
    }
    if (c.actionPrefix() != null) {
      sql.append(ACTION_PREFIX);
      params.put("actionPrefix", escapeLike(c.actionPrefix()) + "%");
    }
    if (c.targetType() != null) {
      sql.append(" AND target_type = :targetType");
      params.put("targetType", c.targetType());
    }
    if (c.targetId() != null) {
      sql.append(" AND target_id = :targetId");
      params.put("targetId", c.targetId());
    }
    if (c.outcome() != null) {
      sql.append(" AND outcome = :outcome");
      params.put("outcome", c.outcome());
    }
    if (withCursor && c.cursor() != null) {
      sql.append(" AND occurred_at <= :curAt AND (occurred_at, event_id) < (:curAt, :curId)");
      params.put("curAt", c.cursor().createdAtParam());
      params.put("curId", c.cursor().id());
    }
    sql.append(ORDER);
    return new Query(sql.toString(), params);
  }

  /** Escapes {@code \}, {@code %} and {@code _} so that a prefix is matched literally. */
  static String escapeLike(String prefix) {
    return prefix.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_");
  }

  private static OffsetDateTime utc(java.time.Instant instant) {
    return OffsetDateTime.ofInstant(instant, ZoneOffset.UTC);
  }
}
