package com.acme.iam;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.security.servlet.UserDetailsServiceAutoConfiguration;

/**
 * IAM service entry point.
 *
 * <p>{@link UserDetailsServiceAutoConfiguration} is excluded: IAM authenticates users itself and must never log
 * Boot's generated default password.
 */
@SpringBootApplication(exclude = UserDetailsServiceAutoConfiguration.class)
public class IamApplication {

  public static void main(String[] args) {
    SpringApplication.run(IamApplication.class, args);
  }
}
