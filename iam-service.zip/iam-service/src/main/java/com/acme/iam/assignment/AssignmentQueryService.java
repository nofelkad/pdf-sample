package com.acme.iam.assignment;

import com.acme.iam.common.error.NotFoundException;
import com.acme.iam.common.paging.KeysetCursor;
import com.acme.iam.common.paging.KeysetPage;
import com.acme.iam.role.Role;
import com.acme.iam.role.RoleService;
import com.acme.iam.tenant.TenantService;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.OffsetDateTime;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import org.springframework.jdbc.core.simple.JdbcClient;
import org.springframework.lang.Nullable;
import org.springframework.stereotype.Service;

/**
 * Read side of role assignments (P1-10.4): keyset-paginated lists by user, by role and by tenant, newest grant first
 * ({@code granted_at DESC, id DESC}). Every list is filtered to the caller's account (I10) through the assigned user's
 * {@code account_id}, and the user, role or tenant in the path is checked against the account first (404 otherwise, so
 * other accounts' ids are not confirmed). Expired rows that the expiry job has not yet deleted are listed with their
 * {@code expiresAt}.
 */
@Service
public class AssignmentQueryService {

  private static final String BASE = """
      SELECT ra.id, ra.user_id, ra.role_id, r.name AS role_name, ra.scope_type, ra.scope_id, ra.granted_by,
             ra.granted_at, ra.expires_at
      FROM role_assignment ra
      JOIN role r ON r.id = ra.role_id
      JOIN app_user u ON u.id = ra.user_id
      WHERE u.account_id = :accountId
      """;

  private final JdbcClient jdbc;
  private final RoleService roles;
  private final TenantService tenants;

  public AssignmentQueryService(JdbcClient jdbc, RoleService roles, TenantService tenants) {
    this.jdbc = jdbc;
    this.roles = roles;
    this.tenants = tenants;
  }

  /** Assignments of a user of the account. @throws NotFoundException {@code user_not_found} */
  public KeysetPage<AssignmentView> listByUser(UUID accountId, UUID userId, @Nullable String cursor,
      @Nullable Integer limit) {
    return listByUser(accountId, userId, null, cursor, limit);
  }

  /**
   * Assignments of a user of the account; with {@code tenantId} only for a member of that tenant (404 otherwise) and
   * only the assignments that apply in it (ACCOUNT scope, or TENANT scope in that tenant).
   *
   * @throws NotFoundException {@code user_not_found}
   */
  public KeysetPage<AssignmentView> listByUser(UUID accountId, UUID userId, @Nullable UUID tenantId,
      @Nullable String cursor, @Nullable Integer limit) {
    boolean visible = jdbc.sql("""
            SELECT EXISTS (SELECT 1 FROM app_user u WHERE u.id = :id AND u.account_id = :acc
                             AND (CAST(:tenant AS uuid) IS NULL OR EXISTS (SELECT 1 FROM user_tenant_membership m
                                  WHERE m.app_user = u.id AND m.tenant_id = CAST(:tenant AS uuid))))""")
        .param("id", userId).param("acc", accountId).param("tenant", tenantId).query(Boolean.class).single();
    if (!visible) {
      throw new NotFoundException("user_not_found", "User not found");
    }
    return page(accountId, "AND ra.user_id = :target\n" + inTenant(tenantId), userId, tenantId, cursor, limit);
  }

  /** Assignments of a role visible to the account (SYSTEM or its own CUSTOM role). @throws NotFoundException {@code role_not_found} */
  public KeysetPage<AssignmentView> listByRole(UUID accountId, UUID roleId, @Nullable String cursor,
      @Nullable Integer limit) {
    return listByRole(accountId, roleId, null, cursor, limit);
  }

  /**
   * Assignments of a role visible to the account; with {@code tenantId} only those of members of that tenant that apply
   * in it (ACCOUNT scope, or TENANT scope in that tenant).
   *
   * @throws NotFoundException {@code role_not_found}
   */
  public KeysetPage<AssignmentView> listByRole(UUID accountId, UUID roleId, @Nullable UUID tenantId,
      @Nullable String cursor, @Nullable Integer limit) {
    Role role = roles.findById(roleId).orElseThrow(() -> new NotFoundException("role_not_found", "Role not found"));
    if (role.isCustom() && !accountId.equals(role.account())) {
      throw new NotFoundException("role_not_found", "Role not found");
    }
    String filter = "AND ra.role_id = :target\n" + (tenantId == null ? "" : """
        AND EXISTS (SELECT 1 FROM user_tenant_membership m WHERE m.app_user = ra.user_id AND m.tenant_id = :tenant)
        """) + inTenant(tenantId);
    return page(accountId, filter, roleId, tenantId, cursor, limit);
  }

  /** Rows that apply in {@code tenantId}: ACCOUNT scope, or TENANT scope in that tenant; nothing when {@code null}. */
  private static String inTenant(@Nullable UUID tenantId) {
    return tenantId == null ? "" : "AND (ra.scope_type = 'ACCOUNT' OR ra.scope_id = :tenant)\n";
  }

  /** TENANT-scope assignments in a tenant of the account. @throws NotFoundException {@code tenant_not_found} */
  public KeysetPage<AssignmentView> listByTenant(UUID accountId, UUID tenantId, @Nullable String cursor,
      @Nullable Integer limit) {
    tenants.findByIdInAccount(tenantId, accountId)
        .orElseThrow(() -> new NotFoundException("tenant_not_found", "Tenant not found"));
    return page(accountId, "AND ra.scope_type = 'TENANT' AND ra.scope_id = :target\n", tenantId, null, cursor, limit);
  }

  /** One assignment of a user of the account (I10), if it exists. */
  public Optional<AssignmentView> find(UUID accountId, UUID assignmentId) {
    return jdbc.sql(BASE + "AND ra.id = :target")
        .param("accountId", accountId).param("target", assignmentId)
        .query((rs, i) -> map(rs)).optional();
  }

  /** Every user holding any of the roles at any scope, expired assignments included (as {@code revokeRoleHolders}). */
  public Set<UUID> holdersOfRoles(Collection<UUID> roleIds) {
    if (roleIds.isEmpty()) {
      return Set.of();
    }
    return new HashSet<>(jdbc.sql("SELECT DISTINCT user_id FROM role_assignment WHERE role_id IN (:ids)")
        .param("ids", roleIds).query(UUID.class).list());
  }

  private KeysetPage<AssignmentView> page(UUID accountId, String filter, UUID target, @Nullable UUID tenant,
      @Nullable String cursor, @Nullable Integer limit) {
    int size = KeysetPage.limit(limit);
    Optional<KeysetCursor> after = KeysetCursor.decode(cursor);
    String sql = BASE + filter
        + (after.isPresent() ? "AND (ra.granted_at, ra.id) < (:cursorAt, :cursorId)\n" : "")
        + "ORDER BY ra.granted_at DESC, ra.id DESC\nLIMIT :limit";
    JdbcClient.StatementSpec spec = jdbc.sql(sql)
        .param("accountId", accountId).param("target", target).param("limit", size + 1);
    if (tenant != null) {
      spec = spec.param("tenant", tenant);
    }
    if (after.isPresent()) {
      spec = spec.param("cursorAt", after.get().createdAtParam()).param("cursorId", after.get().id());
    }
    List<AssignmentView> rows = spec.query((rs, i) -> map(rs)).list();
    return KeysetPage.of(rows, size, AssignmentView::grantedAt, AssignmentView::id);
  }

  private static AssignmentView map(ResultSet rs) throws SQLException {
    OffsetDateTime expires = rs.getObject("expires_at", OffsetDateTime.class);
    return new AssignmentView(
        rs.getObject("id", UUID.class),
        rs.getObject("user_id", UUID.class),
        rs.getObject("role_id", UUID.class),
        rs.getString("role_name"),
        ScopeType.valueOf(rs.getString("scope_type")),
        rs.getObject("scope_id", UUID.class),
        rs.getObject("granted_by", UUID.class),
        rs.getObject("granted_at", OffsetDateTime.class).toInstant(),
        expires == null ? null : expires.toInstant());
  }
}
