package com.acme.iam.user;

import java.time.Instant;
import java.util.Comparator;
import java.util.List;
import java.util.UUID;
import org.springframework.lang.Nullable;

/** A user as returned by the user administration API (never carries the password hash or login counters). */
public record UserView(
    UUID id,
    UUID accountId,
    String email,
    @Nullable String displayName,
    UserStatus status,
    UUID primaryTenantId,
    List<MembershipView> memberships,
    @Nullable Instant lastLoginAt,
    Instant createdAt,
    Instant updatedAt) {

  public record MembershipView(UUID tenantId, MembershipStatus status, boolean primary, Instant addedAt) {}

  public static UserView of(AppUser u) {
    List<MembershipView> memberships = u.memberships().stream()
        .map(m -> new MembershipView(m.tenantId(), m.status(), m.tenantId().equals(u.primaryTenant()), m.addedAt()))
        .sorted(Comparator.comparing(MembershipView::addedAt).thenComparing(MembershipView::tenantId))
        .toList();
    return new UserView(u.id(), u.account(), u.email(), u.displayName(), u.status(), u.primaryTenant(), memberships,
        u.lastLoginAt(), u.createdAt(), u.updatedAt());
  }
}
