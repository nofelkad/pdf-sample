package com.acme.iam.common.security;

import com.acme.iam.core.Claims;
import java.util.Set;
import java.util.UUID;
import java.util.stream.Collectors;
import org.springframework.lang.Nullable;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.authentication.AuthenticationCredentialsNotFoundException;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.security.oauth2.server.resource.authentication.JwtAuthenticationToken;
import org.springframework.stereotype.Component;

/**
 * The authenticated caller of the current request, read from the validated JWT in the SecurityContext.
 *
 * <p>Every accessor throws {@link AuthenticationCredentialsNotFoundException} (401) when there is no JWT
 * authentication. User-only accessors ({@link #userId()}, {@link #accountId()}, {@link #tenantId()},
 * {@link #sessionId()}, {@link #sessionVersion()}) throw {@link AccessDeniedException} (403) for application tokens;
 * check {@link #isApp()} first where both kinds of caller are accepted.
 */
@Component
public class CurrentUser {

  /** The validated token. */
  public Jwt jwt() {
    Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
    if (authentication instanceof JwtAuthenticationToken token) {
      return token.getToken();
    }
    throw new AuthenticationCredentialsNotFoundException("No authenticated caller");
  }

  public boolean isAuthenticated() {
    return SecurityContextHolder.getContext().getAuthentication() instanceof JwtAuthenticationToken;
  }

  /** {@code true} for an application client token ({@code typ = "app"}). */
  public boolean isApp() {
    return AppCaller.isApp(jwt());
  }

  /** {@code sub} of a user token. */
  public UUID userId() {
    return uuidClaim(Claims.SUBJECT);
  }

  /** {@code acc}. */
  public UUID accountId() {
    return uuidClaim(Claims.ACCOUNT);
  }

  /** {@code tid}: the active tenant. */
  public UUID tenantId() {
    return uuidClaim(Claims.TENANT);
  }

  /**
   * {@code tid}, or {@code null} when the user token has no active tenant. Use where a missing tenant must fail
   * closed with a specific error instead of a 401 ({@link #tenantId()} throws).
   */
  @Nullable
  public UUID tenantIdOrNull() {
    String value = userJwt().getClaimAsString(Claims.TENANT);
    return value == null ? null : UUID.fromString(value);
  }

  /** {@code sid}. */
  public UUID sessionId() {
    return uuidClaim(Claims.SESSION);
  }

  /** {@code sv}. */
  public int sessionVersion() {
    Jwt jwt = userJwt();
    Object sv = jwt.getClaim(Claims.SESSION_VERSION);
    if (sv instanceof Number number) {
      return number.intValue();
    }
    throw new AuthenticationCredentialsNotFoundException("Token has no session version");
  }

  /** Granted permissions (the {@code perms} claim after filtering, see {@code SecurityConfig.permsConverter()}). */
  public Set<String> permissions() {
    jwt();
    return SecurityContextHolder.getContext().getAuthentication().getAuthorities().stream()
        .map(GrantedAuthority::getAuthority)
        .collect(Collectors.toUnmodifiableSet());
  }

  public boolean hasPermission(String permission) {
    return permissions().contains(permission);
  }

  /** Client id of an application token. */
  public String clientId() {
    return AppCaller.clientId(jwt()).orElseThrow(() -> new AccessDeniedException("Not an application token"));
  }

  /** {@code prd} of an application token. */
  public String productCode() {
    Jwt jwt = jwt();
    if (!AppCaller.isApp(jwt)) {
      throw new AccessDeniedException("Not an application token");
    }
    return jwt.getClaimAsString(Claims.PRODUCT);
  }

  private Jwt userJwt() {
    Jwt jwt = jwt();
    if (AppCaller.isApp(jwt)) {
      throw new AccessDeniedException("Not a user token");
    }
    return jwt;
  }

  private UUID uuidClaim(String claim) {
    String value = userJwt().getClaimAsString(claim);
    if (value == null) {
      throw new AuthenticationCredentialsNotFoundException("Token has no " + claim + " claim");
    }
    return UUID.fromString(value);
  }
}
