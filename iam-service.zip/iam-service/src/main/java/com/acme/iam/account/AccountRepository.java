package com.acme.iam.account;

import java.util.Optional;
import java.util.UUID;
import org.springframework.data.repository.ListCrudRepository;

/** Persistence of the {@link Account} aggregate. Private to the {@code account} feature; use {@link AccountService}. */
public interface AccountRepository extends ListCrudRepository<Account, UUID> {

  /** Case-insensitive (CITEXT) lookup by slug. */
  Optional<Account> findBySlug(String slug);
}
