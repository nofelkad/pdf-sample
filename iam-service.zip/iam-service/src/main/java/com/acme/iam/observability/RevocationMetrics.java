package com.acme.iam.observability;

import com.acme.iam.core.revocation.RevocationEntry;
import io.micrometer.core.instrument.Counter;
import io.micrometer.core.instrument.Gauge;
import io.micrometer.core.instrument.MeterRegistry;
import java.time.Clock;
import java.time.Instant;
import java.time.OffsetDateTime;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.atomic.AtomicLong;
import java.util.function.BooleanSupplier;
import java.util.function.LongFunction;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.simple.JdbcClient;
import org.springframework.lang.Nullable;
import org.springframework.stereotype.Component;

/**
 * Revocation lag, poll age and poll failures of IAM's own {@code RevocationPoller} (P1-11.5), observed through the
 * poller's two reads of the feed ({@code RevocationService.since} and {@code startCursor}) so the poller itself is
 * unchanged. A read counts only when it comes from {@code RevocationPoller.poll} (found on the call stack):
 * {@code GET /internal/revocations} calls the same service method on behalf of iam-client instances.
 *
 * <ul>
 *   <li>{@value MetricNames#REVOCATION_POLL_AGE} (seconds): time since the last successful read; before the first
 *       one, time since startup, so a poller that never works also crosses an alert threshold.
 *   <li>{@value MetricNames#REVOCATION_LAG} (seconds): when a read returns entries, {@code now - created_at} of the
 *       newest one, fixed at that moment (one primary-key lookup per non-empty read). It is the time a revocation
 *       needed to reach this instance, not an age that grows while nothing is revoked. {@code created_at} is the
 *       start of the revoking transaction, so a long revoking transaction adds its own duration. Entries created
 *       before this instance started (the startup replay of {@code iam.revocation.startup-lookback}) are ignored: their
 *       age is history, not propagation delay. 0 until the first entry created after startup is applied.
 *   <li>{@value MetricNames#REVOCATION_POLL_FAILURES}: reads that threw (the poller logs and retries on its tick).
 * </ul>
 */
@Aspect
@Component
public class RevocationMetrics {

  private static final Logger log = LoggerFactory.getLogger(RevocationMetrics.class);
  private static final String POLLER = "com.acme.iam.auth.RevocationPoller";

  private final Clock clock;
  private final LongFunction<Optional<Instant>> createdAt;
  private final BooleanSupplier fromPoller;
  private final Counter failures;
  private final Instant startedAt;
  private final AtomicLong lagMillis = new AtomicLong();
  private volatile Instant lastSuccess;

  @Autowired
  public RevocationMetrics(MeterRegistry registry, Clock clock, JdbcClient jdbc) {
    this(registry, clock, jdbc, RevocationMetrics::calledByPoller);
  }

  /** For tests: {@code fromPoller} decides whether a read belongs to the poller. */
  RevocationMetrics(MeterRegistry registry, Clock clock, JdbcClient jdbc, BooleanSupplier fromPoller) {
    this(registry, clock, fromPoller, id -> createdAt(jdbc, id));
  }

  /** For tests: {@code createdAt} replaces the {@code revocation.created_at} lookup. */
  RevocationMetrics(MeterRegistry registry, Clock clock, BooleanSupplier fromPoller,
                    LongFunction<Optional<Instant>> createdAt) {
    this.clock = clock;
    this.createdAt = createdAt;
    this.fromPoller = fromPoller;
    this.startedAt = clock.instant();
    Gauge.builder(MetricNames.REVOCATION_LAG, lagMillis, millis -> millis.get() / 1000.0)
        .description("Age of the newest revocation entry when this instance applied it")
        .baseUnit("seconds").register(registry);
    Gauge.builder(MetricNames.REVOCATION_POLL_AGE, this, RevocationMetrics::pollAgeSeconds)
        .description("Time since the revocation poller last read the feed successfully")
        .baseUnit("seconds").register(registry);
    this.failures = Counter.builder(MetricNames.REVOCATION_POLL_FAILURES)
        .description("Revocation feed reads of the poller that failed").register(registry);
  }

  @Around("execution(* com.acme.iam.auth.RevocationService.since(..))"
      + " || execution(* com.acme.iam.auth.RevocationService.startCursor(..))")
  public Object aroundFeedRead(ProceedingJoinPoint joinPoint) throws Throwable {
    if (!fromPoller.getAsBoolean()) {
      return joinPoint.proceed();
    }
    Object result;
    try {
      result = joinPoint.proceed();
    } catch (Throwable e) {
      failures.increment();
      throw e;
    }
    lastSuccess = clock.instant();
    if (result instanceof List<?> page && !page.isEmpty() && page.get(page.size() - 1) instanceof RevocationEntry last) {
      recordLag(last.id());
    }
    return result;
  }

  /** When the poller last read the feed successfully; {@code null} before the first read. */
  @Nullable
  public Instant lastSuccess() {
    return lastSuccess;
  }

  /** Seconds since the last successful read, or since startup when there has been none. */
  double pollAgeSeconds() {
    Instant reference = lastSuccess != null ? lastSuccess : startedAt;
    return Math.max(0, (clock.millis() - reference.toEpochMilli()) / 1000.0);
  }

  private void recordLag(long entryId) {
    try {
      createdAt.apply(entryId)
          .filter(created -> !created.isBefore(startedAt)) // startup replay is history, not lag
          .ifPresent(created -> lagMillis.set(Math.max(0, clock.millis() - created.toEpochMilli())));
    } catch (RuntimeException e) {
      log.debug("Could not read created_at of revocation entry {}", entryId, e);
    }
  }

  private static Optional<Instant> createdAt(JdbcClient jdbc, long entryId) {
    return jdbc.sql("SELECT created_at FROM revocation WHERE id = :id").param("id", entryId)
        .query(OffsetDateTime.class).optional().map(OffsetDateTime::toInstant);
  }

  private static boolean calledByPoller() {
    return StackWalker.getInstance().walk(frames -> frames.anyMatch(f -> f.getClassName().equals(POLLER)));
  }
}
