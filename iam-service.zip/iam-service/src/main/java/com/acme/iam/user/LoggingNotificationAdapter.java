package com.acme.iam.user;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Default {@link NotificationPort} ({@code iam.notification.mode=log} or unset): logs that a notification would be sent,
 * with a masked address and <b>without</b> the token. Useful for local runs; nothing is delivered.
 */
public class LoggingNotificationAdapter implements NotificationPort {

  private static final Logger log = LoggerFactory.getLogger(LoggingNotificationAdapter.class);

  @Override
  public void sendInvitation(String email, String accountName, String rawToken) {
    log.info("notification.invitation to={} account={} (log mode: not delivered)", mask(email), accountName);
  }

  @Override
  public void sendPasswordReset(String email, String rawToken) {
    log.info("notification.password_reset to={} (log mode: not delivered)", mask(email));
  }

  /** {@code jane.doe@example.com -> j***@example.com}. */
  static String mask(String email) {
    if (email == null) {
      return null;
    }
    int at = email.indexOf('@');
    if (at <= 0) {
      return "***";
    }
    return email.charAt(0) + "***" + email.substring(at);
  }
}
