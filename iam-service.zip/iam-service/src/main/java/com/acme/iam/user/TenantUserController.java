package com.acme.iam.user;

import com.acme.iam.assignment.ScopeType;
import com.acme.iam.common.security.CurrentUser;
import com.acme.iam.common.security.TenantGuard;
import com.acme.iam.user.InvitationService.InvitationResult;
import com.acme.iam.user.InvitationService.RoleGrant;
import jakarta.validation.Valid;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import java.net.URI;
import java.time.Instant;
import java.util.List;
import java.util.UUID;
import org.springframework.http.CacheControl;
import org.springframework.http.ResponseEntity;
import org.springframework.lang.Nullable;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

/**
 * Invitations into a tenant (P1-8.2), spec section 4's {@code TenantGuard} example: {@code iam.user.manage} plus
 * {@link TenantGuard#requireActive} on the path tenant.
 */
@RestController
public class TenantUserController {

  private static final String MANAGE = "iam.user.manage";

  public record RoleRequest(@NotNull UUID roleId, @NotNull ScopeType scopeType, @Nullable UUID scopeId,
                            @Nullable Instant expiresAt) {
    RoleGrant toGrant() {
      return new RoleGrant(roleId, scopeType, scopeId, expiresAt);
    }
  }

  public record InviteRequest(
      @NotBlank @Email @Size(max = 254) String email,
      @Nullable @Size(max = 200) String displayName,
      @Nullable @Size(max = 50) List<@Valid RoleRequest> roles) {}

  private final InvitationService invitations;
  private final TenantGuard tenantGuard;
  private final CurrentUser currentUser;

  public TenantUserController(InvitationService invitations, TenantGuard tenantGuard, CurrentUser currentUser) {
    this.invitations = invitations;
    this.tenantGuard = tenantGuard;
    this.currentUser = currentUser;
  }

  /** 201: the INVITED user, the invitation's expiry and the created assignment ids. */
  @PostMapping("/api/tenants/{tenantId}/users")
  @PreAuthorize("hasAuthority('iam.user.manage')")
  public ResponseEntity<InvitationResult> invite(@PathVariable UUID tenantId,
                                                 @Valid @RequestBody InviteRequest request) {
    tenantGuard.requireActive(tenantId, MANAGE);
    List<RoleGrant> roles = request.roles() == null ? List.of()
        : request.roles().stream().map(RoleRequest::toGrant).toList();
    InvitationResult result = invitations.invite(currentUser.accountId(), tenantId, request.email(),
        request.displayName(), roles);
    return ResponseEntity.created(URI.create(UserController.PATH + "/" + result.user().id()))
        .cacheControl(CacheControl.noStore())
        .body(result);
  }
}
