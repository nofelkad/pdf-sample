package com.acme.iam.appclient;

import com.acme.iam.common.error.ApiException;
import com.acme.iam.common.error.BadRequestException;
import com.acme.iam.common.error.GlobalExceptionHandler;
import com.acme.iam.common.security.IssuedJwt;
import com.acme.iam.common.security.SecurityConfig;
import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.http.CacheControl;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ProblemDetail;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/**
 * {@code POST /internal/token} (client-credentials style, P1-12.1): public in the security chain, the client
 * authenticates itself with {@code Authorization: Basic base64(clientId:secret)} and form
 * {@code grant_type=client_credentials}. Response {@code {access_token, token_type: "Bearer", expires_in: 600}}.
 * Errors: 400 {@code invalid_request} / {@code unsupported_grant_type}, 401 {@code invalid_client} with
 * {@code WWW-Authenticate: Basic realm="iam"}.
 */
@RestController
public class AppTokenController {

  public static final String GRANT_TYPE = "client_credentials";

  public record TokenResponse(
      @JsonProperty("access_token") String accessToken,
      @JsonProperty("token_type") String tokenType,
      @JsonProperty("expires_in") long expiresIn) {
    @Override
    public String toString() {
      return "TokenResponse[token_type=" + tokenType + ", expires_in=" + expiresIn + "]";
    }
  }

  private final AppClientService service;

  public AppTokenController(AppClientService service) {
    this.service = service;
  }

  @PostMapping(path = SecurityConfig.INTERNAL_TOKEN_PATH, consumes = MediaType.APPLICATION_FORM_URLENCODED_VALUE)
  public ResponseEntity<TokenResponse> token(
      @RequestHeader(value = HttpHeaders.AUTHORIZATION, required = false) String authorization,
      @RequestParam(name = "grant_type", required = false) String grantType,
      HttpServletRequest request) {
    if (grantType == null || grantType.isBlank()) {
      throw new BadRequestException("invalid_request", "grant_type is required");
    }
    if (!GRANT_TYPE.equals(grantType)) {
      throw new BadRequestException("unsupported_grant_type", "Only grant_type=client_credentials is supported");
    }
    IssuedJwt token = service.issueToken(authorization, request.getRemoteAddr(),
        request.getHeader(HttpHeaders.USER_AGENT));
    return ResponseEntity.ok()
        .cacheControl(CacheControl.noStore())
        .header(HttpHeaders.PRAGMA, "no-cache")
        .body(new TokenResponse(token.tokenValue(), "Bearer", token.expiresInSeconds()));
  }

  /** RFC 6749: {@code invalid_client} after Basic authentication carries a {@code WWW-Authenticate} challenge. */
  @ExceptionHandler(InvalidClientException.class)
  ResponseEntity<ProblemDetail> invalidClient(ApiException ex, HttpServletRequest request) {
    return ResponseEntity.status(ex.status())
        .header(HttpHeaders.WWW_AUTHENTICATE, "Basic realm=\"iam\"")
        .cacheControl(CacheControl.noStore())
        .body(GlobalExceptionHandler.problemOf(ex, request));
  }
}
