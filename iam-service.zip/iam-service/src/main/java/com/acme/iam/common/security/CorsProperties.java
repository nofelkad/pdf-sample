package com.acme.iam.common.security;

import java.util.List;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.bind.DefaultValue;

/**
 * {@code iam.security.cors.*} (Task 9). CORS is <b>denied by default</b>: with no {@code allowed-origins} no CORS
 * configuration exists, so browsers refuse cross-origin calls. List the exact origins of the admin UI (scheme, host and
 * port, comma separated in {@code IAM_CORS_ALLOWED_ORIGINS}); wildcards are not supported. Credentials (cookies) are
 * never allowed: IAM uses bearer tokens.
 *
 * @param allowedOrigins exact origins such as {@code https://admin.example.com}
 */
@ConfigurationProperties("iam.security.cors")
public record CorsProperties(@DefaultValue List<String> allowedOrigins) {

  public CorsProperties {
    allowedOrigins = allowedOrigins == null ? List.of()
        : allowedOrigins.stream().map(String::trim).filter(o -> !o.isEmpty()).toList();
    if (allowedOrigins.stream().anyMatch(o -> o.contains("*"))) {
      throw new IllegalArgumentException("iam.security.cors.allowed-origins must list exact origins, not wildcards");
    }
  }
}
