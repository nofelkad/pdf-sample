package com.acme.iam.audit;

import com.acme.iam.common.error.ApiException;
import com.acme.iam.common.error.BadRequestException;
import com.acme.iam.common.security.CurrentUser;
import com.acme.iam.core.Claims;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import jakarta.servlet.http.HttpServletRequest;
import java.io.IOException;
import java.io.InputStream;
import java.util.Map;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * {@code POST /internal/audit/events} (P1-9.4): batch ingest for iam-client outbox relays; application token with
 * {@value Claims#PERM_INTERNAL_AUDIT_WRITE}. The contract (body, {@code accepted/duplicates/rejected}, limits) is
 * described on {@link AuditIngestService}.
 *
 * <p>The body is read here, bounded to {@value #MAX_BODY_BYTES} bytes (413 {@code payload_too_large}, also when the
 * client sends no Content-Length), and parsed as a tree so that one malformed event is rejected individually instead
 * of failing the whole request.
 */
@RestController
public class AuditIngestController {

  public static final String PATH = "/internal/audit/events";
  public static final int MAX_BODY_BYTES = 1024 * 1024;

  private final AuditIngestService ingest;
  private final CurrentUser currentUser;
  private final ObjectMapper objectMapper;

  public AuditIngestController(AuditIngestService ingest, CurrentUser currentUser, ObjectMapper objectMapper) {
    this.ingest = ingest;
    this.currentUser = currentUser;
    this.objectMapper = objectMapper;
  }

  @PostMapping(path = PATH, consumes = MediaType.APPLICATION_JSON_VALUE)
  @PreAuthorize("hasAuthority('" + Claims.PERM_INTERNAL_AUDIT_WRITE + "')")
  public IngestResult ingest(HttpServletRequest request) throws IOException {
    if (request.getContentLengthLong() > MAX_BODY_BYTES) {
      throw tooLarge();
    }
    byte[] body = readBounded(request.getInputStream());
    JsonNode tree;
    try {
      tree = objectMapper.readTree(body);
    } catch (JsonProcessingException e) {
      throw new BadRequestException("invalid_body", "Body is not valid JSON");
    }
    return ingest.ingest(currentUser.productCode(), tree);
  }

  private static byte[] readBounded(InputStream in) throws IOException {
    byte[] body = in.readNBytes(MAX_BODY_BYTES + 1);
    if (body.length > MAX_BODY_BYTES) {
      throw tooLarge();
    }
    return body;
  }

  private static ApiException tooLarge() {
    return new ApiException(HttpStatus.PAYLOAD_TOO_LARGE, "payload_too_large",
        "Request body exceeds " + MAX_BODY_BYTES + " bytes", Map.of("maxBytes", MAX_BODY_BYTES));
  }
}
