package com.acme.iam.audit;

import java.util.List;
import org.springframework.lang.Nullable;

/**
 * Response of {@code POST /internal/audit/events}.
 *
 * @param accepted   events stored by this request
 * @param duplicates events whose {@code eventId} was already stored (a retried batch): submitted - accepted - rejected
 * @param rejected   events that failed validation; the client must not retry them
 */
public record IngestResult(int accepted, int duplicates, List<Rejected> rejected) {

  /**
   * @param eventId the id as sent, when it is a valid UUID; absent otherwise
   * @param index   position of the event in the request's {@code events} array
   * @param reason  snake_case code, for example {@code invalid_action}, {@code occurred_at_out_of_range}
   */
  public record Rejected(@Nullable String eventId, int index, String reason) {}
}
