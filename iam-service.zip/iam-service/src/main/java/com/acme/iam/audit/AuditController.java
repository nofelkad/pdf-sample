package com.acme.iam.audit;

import com.acme.iam.audit.AuditEvent.Outcome;
import com.acme.iam.common.paging.KeysetPage;
import java.time.Instant;
import java.util.UUID;
import org.springframework.lang.Nullable;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/**
 * Audit log reads (permission {@code iam.audit.read}), always scoped to the caller's account (I10):
 *
 * <ul>
 *   <li>{@code GET /api/audit/events?from&to[&tenantId&actorUserId&action&targetType&targetId&outcome&accountId&limit
 *       &cursor]}: {@code from} (inclusive) and {@code to} (exclusive) are ISO-8601 instants and at most 92 days
 *       apart; {@code action} is a prefix; {@code limit} defaults to 50, at most 200. Response
 *       {@code {items: [...], nextCursor}}, newest first, keyset-paginated ({@code nextCursor} absent on the last
 *       page).
 *   <li>{@code GET /api/audit/targets/{type}/{id}[?from&to&limit&cursor]}: the history of one record, same item shape;
 *       the time window is optional.
 * </ul>
 *
 * Tenant scope (Ruling R25): a caller holding {@code iam.audit.read} through an ACCOUNT-scope assignment sees all tenants
 * and account-level rows; any other caller sees only the token's tenant, and a {@code tenantId} filter naming another
 * tenant is 403 {@code scope_exceeded}.
 *
 * {@code accountId} is honoured only for callers holding {@code platform.account.manage}; for everyone else naming
 * another account is 403 {@code account_filter_forbidden}.
 */
@RestController
public class AuditController {

  public static final String EVENTS_PATH = "/api/audit/events";
  public static final String TARGETS_PATH = "/api/audit/targets/{type}/{id}";

  private final AuditQueryService queries;

  public AuditController(AuditQueryService queries) {
    this.queries = queries;
  }

  @GetMapping(EVENTS_PATH)
  @PreAuthorize("hasAuthority('iam.audit.read')")
  public KeysetPage<AuditEventView> search(
      @RequestParam(required = false) @Nullable UUID accountId,
      @RequestParam(required = false) @Nullable UUID tenantId,
      @RequestParam(required = false) @Nullable UUID actorUserId,
      @RequestParam(required = false) @Nullable String action,
      @RequestParam(required = false) @Nullable String targetType,
      @RequestParam(required = false) @Nullable String targetId,
      @RequestParam(required = false) @Nullable Outcome outcome,
      @RequestParam(required = false) @Nullable Instant from,
      @RequestParam(required = false) @Nullable Instant to,
      @RequestParam(required = false) @Nullable String cursor,
      @RequestParam(required = false) @Nullable Integer limit) {
    AuditFilter filter = new AuditFilter(accountId, tenantId, actorUserId, action, targetType, targetId, outcome, from,
        to, cursor, limit);
    return queries.search(queries.criteria(filter, true, AuditQueryService.PERM_READ));
  }

  @GetMapping(TARGETS_PATH)
  @PreAuthorize("hasAuthority('iam.audit.read')")
  public KeysetPage<AuditEventView> targetHistory(
      @PathVariable String type,
      @PathVariable String id,
      @RequestParam(required = false) @Nullable UUID accountId,
      @RequestParam(required = false) @Nullable Instant from,
      @RequestParam(required = false) @Nullable Instant to,
      @RequestParam(required = false) @Nullable String cursor,
      @RequestParam(required = false) @Nullable Integer limit) {
    AuditFilter filter = new AuditFilter(accountId, null, null, null, type, id, null, from, to, cursor, limit);
    return queries.search(queries.criteria(filter, false, AuditQueryService.PERM_READ));
  }
}
