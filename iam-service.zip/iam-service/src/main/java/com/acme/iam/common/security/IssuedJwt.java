package com.acme.iam.common.security;

import java.time.Duration;
import java.time.Instant;

/**
 * A signed JWT returned by {@link JwtIssuer}.
 *
 * @param tokenValue compact serialization; never log it
 * @param jti {@code jti} claim
 * @param issuedAt {@code iat}
 * @param expiresAt {@code exp}
 */
public record IssuedJwt(String tokenValue, String jti, Instant issuedAt, Instant expiresAt) {

  /** Seconds until expiry, for {@code expires_in}. */
  public long expiresInSeconds() {
    return Duration.between(issuedAt, expiresAt).toSeconds();
  }

  @Override
  public String toString() {
    return "IssuedJwt[jti=" + jti + ", issuedAt=" + issuedAt + ", expiresAt=" + expiresAt + "]";
  }
}
