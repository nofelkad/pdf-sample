package com.acme.iam.user;

import com.acme.iam.common.error.BadRequestException;
import com.acme.iam.common.error.NotFoundException;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.time.Clock;
import java.time.Duration;
import java.time.Instant;
import java.util.Base64;
import java.util.Objects;
import java.util.UUID;
import org.springframework.lang.Nullable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * Single-use invitation and password-reset tokens ({@code user_token}).
 *
 * <ul>
 *   <li><b>Raw token:</b> 32 bytes from {@link SecureRandom} (256 bits), encoded base64url without padding (43
 *       characters). Returned once by {@link #issue}; never stored or logged.
 *   <li><b>Stored hash:</b> {@code SHA-256} over the US-ASCII bytes of that base64url <em>string</em> (not of the
 *       decoded bytes), so any input can be hashed and looked up without decoding.
 *   <li><b>Consumption</b> is one atomic {@code UPDATE ... WHERE used_at IS NULL AND expires_at > now}: of two
 *       concurrent consumers exactly one wins.
 * </ul>
 */
@Service
public class UserTokenService {

  /** Machine code of every rejection by {@link #consume}; deliberately the same for unknown, used and expired. */
  public static final String INVALID_TOKEN = "invalid_token";

  private static final int TOKEN_BYTES = 32;
  private static final SecureRandom RANDOM = new SecureRandom();

  private final UserTokenRepository tokens;
  private final AppUserRepository users;
  private final Clock clock;

  public UserTokenService(UserTokenRepository tokens, AppUserRepository users, Clock clock) {
    this.tokens = tokens;
    this.users = users;
    this.clock = clock;
  }

  /**
   * Issues a new token. Outstanding tokens of the same purpose stay valid; call {@link #invalidateOutstanding} first
   * when re-sending (e.g. a new invitation).
   *
   * @param ttl lifetime, e.g. 7 days for INVITE, 30 minutes for PASSWORD_RESET
   * @param createdBy the admin who triggered it, or {@code null} (self-service, system)
   * @throws NotFoundException {@code user_not_found} if the user does not exist
   */
  @Transactional
  public IssuedToken issue(UUID userId, TokenPurpose purpose, Duration ttl, @Nullable UUID createdBy) {
    Objects.requireNonNull(userId, "userId");
    Objects.requireNonNull(purpose, "purpose");
    if (ttl == null || ttl.isNegative() || ttl.isZero()) {
      throw new IllegalArgumentException("ttl must be positive");
    }
    if (!users.existsById(userId)) {
      throw new NotFoundException("user_not_found", "User not found");
    }
    byte[] random = new byte[TOKEN_BYTES];
    RANDOM.nextBytes(random);
    String raw = Base64.getUrlEncoder().withoutPadding().encodeToString(random);
    Instant expiresAt = clock.instant().plus(ttl);
    UserToken saved = tokens.save(UserToken.create(userId, purpose, hash(raw), expiresAt, createdBy));
    return new IssuedToken(saved.id(), raw, saved.expiresAt());
  }

  /**
   * Consumes a token: marks it used and returns it (with {@code usedAt} set). Runs in the caller's transaction, so if
   * the caller's later steps fail the token stays usable.
   *
   * @throws BadRequestException {@value #INVALID_TOKEN} if the token is unknown, of another purpose, already used or
   *     expired
   */
  @Transactional
  public UserToken consume(String rawToken, TokenPurpose purpose) {
    if (rawToken == null || rawToken.isBlank()) {
      throw invalid();
    }
    byte[] hash = hash(rawToken);
    if (tokens.markUsed(hash, purpose.name(), clock.instant()) != 1) {
      throw invalid();
    }
    return tokens.findByTokenHash(hash).orElseThrow(UserTokenService::invalid);
  }

  /** Marks every unused token of the user and purpose as used; returns how many. */
  @Transactional
  public int invalidateOutstanding(UUID userId, TokenPurpose purpose) {
    return tokens.invalidateOutstanding(userId, purpose.name(), clock.instant());
  }

  /** {@code SHA-256(rawToken as US-ASCII)}. Package-private for tests. */
  static byte[] hash(String rawToken) {
    try {
      return MessageDigest.getInstance("SHA-256").digest(rawToken.getBytes(StandardCharsets.US_ASCII));
    } catch (NoSuchAlgorithmException e) {
      throw new IllegalStateException("SHA-256 unavailable", e);
    }
  }

  private static BadRequestException invalid() {
    return new BadRequestException(INVALID_TOKEN, "The link is invalid or has expired");
  }
}
