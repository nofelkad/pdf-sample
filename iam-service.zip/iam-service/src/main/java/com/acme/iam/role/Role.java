package com.acme.iam.role;

import static java.util.stream.Collectors.toUnmodifiableSet;

import com.acme.iam.account.Account;
import com.acme.iam.product.Product;
import java.time.Instant;
import java.util.Collection;
import java.util.Set;
import java.util.UUID;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.Id;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.annotation.Version;
import org.springframework.data.jdbc.core.mapping.AggregateReference;
import org.springframework.data.relational.core.mapping.MappedCollection;
import org.springframework.data.relational.core.mapping.Table;
import org.springframework.lang.Nullable;

/** Role aggregate root (spec section 3). Owns its {@link RolePermission}s. */
@Table("role")
public record Role(
    @Id UUID id,
    AggregateReference<Product, UUID> productId,
    String name,
    @Nullable String description,
    RoleType type,
    @Nullable AggregateReference<Account, UUID> accountId,
    @MappedCollection(idColumn = "role") Set<RolePermission> permissions,
    @Version Long version,
    @CreatedDate Instant createdAt,
    @LastModifiedDate Instant updatedAt) {

  /** Name of the IAM system role that is assignable only inside the PLATFORM account (I8). */
  public static final String PLATFORM_ADMIN = "Platform Admin";

  /** Name of the IAM system role guarded by I7 (last active Account Admin). */
  public static final String ACCOUNT_ADMIN = "Account Admin";

  public Role {
    permissions = permissions == null ? Set.of() : Set.copyOf(permissions);
  }

  public static Role system(UUID productId, String name, @Nullable String description, Collection<UUID> permissionIds) {
    return new Role(null, AggregateReference.to(productId), name, description, RoleType.SYSTEM, null,
        toPermissions(permissionIds), null, null, null);
  }

  public static Role custom(UUID productId, UUID accountId, String name, @Nullable String description,
      Collection<UUID> permissionIds) {
    return new Role(null, AggregateReference.to(productId), name, description, RoleType.CUSTOM,
        AggregateReference.to(accountId), toPermissions(permissionIds), null, null, null);
  }

  /** The owning product id (never {@code null}). */
  public UUID product() {
    return productId.getId();
  }

  /** The owning account id; {@code null} for SYSTEM roles. */
  @Nullable
  public UUID account() {
    return accountId == null ? null : accountId.getId();
  }

  public boolean isSystem() {
    return type == RoleType.SYSTEM;
  }

  public boolean isCustom() {
    return type == RoleType.CUSTOM;
  }

  /** {@code true} for the IAM system role "Platform Admin" (I8). */
  public boolean isPlatformAdmin() {
    return isSystem() && Product.IAM_ID.equals(product()) && PLATFORM_ADMIN.equals(name);
  }

  public Set<UUID> permissionIds() {
    return permissions.stream().map(RolePermission::permissionId).collect(toUnmodifiableSet());
  }

  public Role withPermissions(Collection<UUID> permissionIds) {
    return new Role(id, productId, name, description, type, accountId, toPermissions(permissionIds), version,
        createdAt, updatedAt);
  }

  public Role withName(String newName, @Nullable String newDescription) {
    return new Role(id, productId, newName, newDescription, type, accountId, permissions, version, createdAt,
        updatedAt);
  }

  private static Set<RolePermission> toPermissions(Collection<UUID> permissionIds) {
    return permissionIds.stream().map(RolePermission::new).collect(toUnmodifiableSet());
  }
}
