package com.acme.iam.auth;

import org.springframework.http.CacheControl;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * {@code GET /api/me} (P1-5.9). <b>Intentionally authenticated-only, without {@code @PreAuthorize}</b>: every user may
 * read their own profile, and the {@code /api/**} security chain already requires a valid, non-revoked access token
 * (401 otherwise). Application tokens get 403 (they have no user).
 */
@RestController
public class MeController {

  private final MeService meService;

  public MeController(MeService meService) {
    this.meService = meService;
  }

  @GetMapping("/api/me")
  public ResponseEntity<MeService.Me> me() {
    return ResponseEntity.ok().cacheControl(CacheControl.noStore()).body(meService.me());
  }
}
