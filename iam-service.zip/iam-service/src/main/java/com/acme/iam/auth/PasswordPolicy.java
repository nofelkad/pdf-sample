package com.acme.iam.auth;

import java.util.Map;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Password policy of one account (P1-5.1). Read from {@code account.settings.passwordPolicy}
 * ({@code {minLength, maxLength, historySize, breachedCheck}}). Missing or non-numeric/non-boolean keys take the
 * defaults; numeric values outside {@code 8 ≤ minLength ≤ maxLength ≤ 1024} and {@code 0 ≤ historySize ≤ 24} are
 * clamped into range (with a WARN log), so an account cannot weaken the policy below the floor or make every change
 * cost dozens of Argon2 verifications.
 *
 * @param historySize how many previous passwords (the current one included) may not be reused
 */
public record PasswordPolicy(int minLength, int maxLength, int historySize, boolean breachedCheck) {

  public static final String SETTINGS_KEY = "passwordPolicy";
  public static final PasswordPolicy DEFAULTS = new PasswordPolicy(12, 128, 5, false);
  public static final int MIN_LENGTH_FLOOR = 8;
  public static final int MAX_LENGTH_CEILING = 1024;
  public static final int MAX_HISTORY = 24;

  private static final Logger log = LoggerFactory.getLogger(PasswordPolicy.class);

  /** The policy in {@code accountSettings}, key by key over {@code defaults}, clamped into range. */
  public static PasswordPolicy from(Map<String, Object> accountSettings, PasswordPolicy defaults) {
    if (accountSettings == null || !(accountSettings.get(SETTINGS_KEY) instanceof Map<?, ?> raw)) {
      return defaults;
    }
    return clamped(number(raw.get("minLength"), defaults.minLength()),
        number(raw.get("maxLength"), defaults.maxLength()),
        number(raw.get("historySize"), defaults.historySize()),
        raw.get("breachedCheck") instanceof Boolean b ? b : defaults.breachedCheck());
  }

  /**
   * A policy with every value clamped into range ({@code 8 ≤ minLength ≤ maxLength ≤ 1024},
   * {@code 0 ≤ historySize ≤ 24}), logging a WARN per clamped value. Used for account settings and for the
   * configured defaults ({@code iam.auth.password-policy.*}).
   */
  public static PasswordPolicy clamped(int minLength, int maxLength, int historySize, boolean breachedCheck) {
    int min = clamp("minLength", minLength, MIN_LENGTH_FLOOR, MAX_LENGTH_CEILING);
    int max = clamp("maxLength", maxLength, min, MAX_LENGTH_CEILING);
    int history = clamp("historySize", historySize, 0, MAX_HISTORY);
    return new PasswordPolicy(min, max, history, breachedCheck);
  }

  private static int number(Object value, int fallback) {
    return value instanceof Number n ? n.intValue() : fallback;
  }

  private static int clamp(String key, int value, int lower, int upper) {
    int clamped = Math.max(lower, Math.min(upper, value));
    if (clamped != value) {
      log.warn("Password policy {}={} is out of range [{}, {}]; using {}", key, value, lower, upper, clamped);
    }
    return clamped;
  }
}
