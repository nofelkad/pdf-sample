package com.acme.iam.auth;

import com.acme.iam.account.AccountStatus;
import com.acme.iam.tenant.TenantStatus;
import com.acme.iam.user.MembershipStatus;
import com.acme.iam.user.UserStatus;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.time.OffsetDateTime;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import org.springframework.lang.Nullable;
import org.springframework.jdbc.core.simple.JdbcClient;
import org.springframework.stereotype.Component;

/**
 * Reads the {@link AccessState} of a user in a tenant with one query over {@code app_user}, {@code account},
 * {@code tenant} and {@code user_tenant_membership}. Read-only; runs in the caller's transaction when there is one.
 */
@Component
class AccessStateQuery {

  private static final TypeReference<Map<String, Object>> MAP = new TypeReference<>() {};

  private final JdbcClient jdbc;
  private final ObjectMapper objectMapper;

  AccessStateQuery(JdbcClient jdbc, ObjectMapper objectMapper) {
    this.jdbc = jdbc;
    this.objectMapper = objectMapper;
  }

  /**
   * @param tenantId the tenant to check, or {@code null} for the user's primary tenant
   * @return empty when the user does not exist
   */
  Optional<AccessState> load(UUID userId, @Nullable UUID tenantId) {
    return jdbc.sql("""
            SELECT u.id, u.account_id, u.email, u.status AS user_status, u.primary_tenant_id, u.session_version,
                   u.password_hash, u.locked_until, a.status AS account_status, a.settings::text AS account_settings,
                   COALESCE(CAST(:tenantId AS uuid), u.primary_tenant_id) AS requested_tenant_id,
                   t.status AS tenant_status, m.status AS membership_status
            FROM app_user u
            JOIN account a ON a.id = u.account_id
            LEFT JOIN tenant t ON t.id = COALESCE(CAST(:tenantId AS uuid), u.primary_tenant_id)
                              AND t.account_id = u.account_id
            LEFT JOIN user_tenant_membership m ON m.app_user = u.id AND m.tenant_id = t.id
            WHERE u.id = :userId""")
        .param("userId", userId)
        .param("tenantId", tenantId == null ? null : tenantId.toString())
        .query((rs, n) -> new AccessState(
            rs.getObject("id", UUID.class),
            rs.getObject("account_id", UUID.class),
            rs.getString("email"),
            UserStatus.valueOf(rs.getString("user_status")),
            rs.getObject("primary_tenant_id", UUID.class),
            rs.getInt("session_version"),
            rs.getString("password_hash"),
            Optional.ofNullable(rs.getObject("locked_until", OffsetDateTime.class)).map(OffsetDateTime::toInstant)
                .orElse(null),
            AccountStatus.valueOf(rs.getString("account_status")),
            settings(rs.getString("account_settings")),
            rs.getObject("requested_tenant_id", UUID.class),
            enumOrNull(TenantStatus.class, rs.getString("tenant_status")),
            enumOrNull(MembershipStatus.class, rs.getString("membership_status"))))
        .optional();
  }

  /** The user's current {@code session_version} (e.g. right after a revocation bumped it). */
  int sessionVersion(UUID userId) {
    return jdbc.sql("SELECT session_version FROM app_user WHERE id = :id").param("id", userId)
        .query(Integer.class).single();
  }

  private Map<String, Object> settings(@Nullable String json) {
    if (json == null) {
      return Map.of();
    }
    try {
      return objectMapper.readValue(json, MAP);
    } catch (Exception e) {
      return Map.of();
    }
  }

  @Nullable
  private static <E extends Enum<E>> E enumOrNull(Class<E> type, @Nullable String value) {
    return value == null ? null : Enum.valueOf(type, value);
  }
}
