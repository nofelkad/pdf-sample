package com.acme.iam.observability;

import com.acme.iam.audit.AuditEvent;
import com.acme.iam.auth.AuthAuditService;
import io.micrometer.core.instrument.Counter;
import io.micrometer.core.instrument.MeterRegistry;
import java.util.List;
import java.util.Map;
import java.util.HashMap;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;
import org.springframework.transaction.support.TransactionSynchronization;
import org.springframework.transaction.support.TransactionSynchronizationManager;

/**
 * Login, lockout, refresh-reuse, login/refresh/tenant-switch latency meters (P1-11.5), added without touching the
 * auth code:
 *
 * <ul>
 *   <li><b>Counters</b> listen to {@code AuditWriter.write}. {@code AuthAuditService} writes one explicit
 *       {@code auth.*} event per outcome, and the {@code reason} of a failed login is in its metadata, so the audit
 *       trail and the meters can never disagree. A counter is incremented only once the event is committed (after
 *       the surrounding transaction commits, or at once when there is none), so a rolled-back event is not counted.
 *   <li><b>Timers</b> wrap {@code LoginService.login}, {@code SessionService.refresh} and
 *       {@code SessionService.switchTenant}. They measure the service call, not the HTTP layer.
 * </ul>
 *
 * The pointcuts are strings on purpose (no compile-time dependency on the services); {@code AuthMetricsIT} fails when
 * a rename or move breaks one.
 */
@Aspect
@Component
@Order(Ordered.HIGHEST_PRECEDENCE + 10)
public class AuthMetrics {

  /** {@code reason} values the auth code uses; anything else is counted as {@code other} (bounded cardinality). */
  private static final List<String> KNOWN_FAILURE_REASONS = List.of(
      "unknown_user", "invalid_password", "locked", "account_selection_required",
      "user_inactive", "account_inactive", "tenant_inactive", "membership_inactive");
  private static final String OTHER = "other";

  private final MeterRegistry registry;
  private final Map<String, Counter> failures = new HashMap<>(); // filled once in the constructor, then read only
  private final Counter successes;
  private final Counter lockouts;
  private final Counter refreshReuse;
  private final OutcomeTimer login;
  private final OutcomeTimer refresh;
  private final OutcomeTimer tenantSwitch;

  public AuthMetrics(MeterRegistry registry) {
    this.registry = registry;
    this.successes = loginCounter("success", "ok");
    KNOWN_FAILURE_REASONS.forEach(reason -> failures.put(reason, loginCounter("failure", reason)));
    failures.put(OTHER, loginCounter("failure", OTHER));
    this.lockouts = Counter.builder(MetricNames.AUTH_LOCKOUTS)
        .description("Failed logins that applied the account lock").register(registry);
    this.refreshReuse = Counter.builder(MetricNames.AUTH_REFRESH_REUSE_DETECTED)
        .description("Rotated-out refresh tokens presented again (session revoked)").register(registry);
    this.login = new OutcomeTimer(registry, MetricNames.AUTH_LOGIN_DURATION,
        "LoginService.login latency (Argon2 dominates)", List.of());
    this.refresh = new OutcomeTimer(registry, MetricNames.AUTH_REFRESH_DURATION,
        "SessionService.refresh latency", List.of());
    this.tenantSwitch = new OutcomeTimer(registry, MetricNames.AUTH_TENANT_SWITCH_DURATION,
        "SessionService.switchTenant latency", List.of());
  }

  // ----------------------------------------------------------------------------------------------- counters

  @AfterReturning("execution(* com.acme.iam.audit.AuditWriter.write(..)) && args(event)")
  public void onAuditEvent(AuditEvent event) {
    switch (event.action()) {
      case AuthAuditService.LOGIN_SUCCESS -> afterCommit(successes::increment);
      case AuthAuditService.LOGIN_FAILED -> {
        Counter counter = failureCounter(event);
        afterCommit(counter::increment);
      }
      case AuthAuditService.LOCKED -> afterCommit(lockouts::increment);
      case AuthAuditService.REFRESH_REUSE_DETECTED -> afterCommit(refreshReuse::increment);
      default -> { }
    }
  }

  private Counter failureCounter(AuditEvent event) {
    Object reason = event.metadata() == null ? null : event.metadata().get("reason");
    Counter known = reason instanceof String text ? failures.get(text) : null;
    return known != null ? known : failures.get(OTHER);
  }

  private Counter loginCounter(String outcome, String reason) {
    return Counter.builder(MetricNames.AUTH_LOGINS)
        .description("Login attempts by outcome and reason")
        .tag("outcome", outcome).tag("reason", reason)
        .register(registry);
  }

  private static void afterCommit(Runnable action) {
    if (TransactionSynchronizationManager.isSynchronizationActive()) {
      TransactionSynchronizationManager.registerSynchronization(new TransactionSynchronization() {
        @Override
        public void afterCommit() {
          action.run();
        }
      });
    } else {
      action.run();
    }
  }

  // ------------------------------------------------------------------------------------------------- timers

  @Around("execution(* com.acme.iam.auth.LoginService.login(..))")
  public Object timeLogin(ProceedingJoinPoint joinPoint) throws Throwable {
    return login.time(joinPoint);
  }

  @Around("execution(* com.acme.iam.auth.SessionService.refresh(..))")
  public Object timeRefresh(ProceedingJoinPoint joinPoint) throws Throwable {
    return refresh.time(joinPoint);
  }

  @Around("execution(* com.acme.iam.auth.SessionService.switchTenant(..))")
  public Object timeTenantSwitch(ProceedingJoinPoint joinPoint) throws Throwable {
    return tenantSwitch.time(joinPoint);
  }
}
