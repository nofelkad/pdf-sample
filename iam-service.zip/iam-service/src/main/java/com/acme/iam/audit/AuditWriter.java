package com.acme.iam.audit;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.json.JsonMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.fasterxml.jackson.databind.node.TextNode;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.util.Collection;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.regex.Pattern;
import org.springframework.jdbc.core.simple.JdbcClient;
import org.springframework.lang.Nullable;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

/**
 * Writes explicit audit events (auth, authorization denials, sensitive reads, ingested application events) directly
 * into {@code audit_event}, inside the caller's transaction (REQUIRED propagation): if the caller rolls back, so does
 * the event. Data changes of IAM tables are audited by the {@code iam_audit()} trigger instead.
 *
 * <p>{@code before}, {@code after} and {@code metadata} are first normalised to a JSON tree (so records/POJOs,
 * {@code JsonNode}s and arrays become plain objects/arrays) and then redacted ({@link #DENY_LIST}). {@code actorIp}
 * is validated as an IP literal ({@link #normalizeIp(String)}); anything else is stored as {@code null} so a bad
 * header never aborts the caller's transaction. Inserts are idempotent on {@code (occurred_at, event_id)}.
 */
@Component
public class AuditWriter {

  public static final String REDACTED = "[REDACTED]";

  /** Keys containing any of these (case-insensitive) have their value replaced by {@value #REDACTED}. */
  public static final List<String> DENY_LIST =
      List.of("password", "secret", "token", "hash", "private", "authorization");

  private static final TypeReference<Map<String, Object>> MAP = new TypeReference<>() {};
  private static final ObjectMapper DEFAULT_MAPPER = JsonMapper.builder().findAndAddModules().build();
  private static final Pattern IPV4 = Pattern.compile(
      "((25[0-5]|2[0-4]\\d|1\\d\\d|[1-9]?\\d)\\.){3}(25[0-5]|2[0-4]\\d|1\\d\\d|[1-9]?\\d)");
  private static final Pattern IPV6_CHARS = Pattern.compile("[0-9A-Fa-f:][0-9A-Fa-f:.]{1,44}");

  private static final String INSERT_SQL = """
      INSERT INTO audit_event (event_id, occurred_at, account_id, tenant_id, source, actor_user_id, actor_type,
                               actor_ip, user_agent, session_id, request_id, action, target_type, target_id, outcome,
                               before_state, after_state, metadata)
      VALUES (:eventId, :occurredAt, :accountId, :tenantId, :source, :actorUserId, :actorType,
              CAST(:actorIp AS inet), :userAgent, :sessionId, :requestId, :action, :targetType, :targetId, :outcome,
              CAST(:before AS jsonb), CAST(:after AS jsonb), CAST(:metadata AS jsonb))
      ON CONFLICT DO NOTHING
      """;

  private final JdbcClient jdbc;
  private final ObjectMapper objectMapper;

  public AuditWriter(JdbcClient jdbc, ObjectMapper objectMapper) {
    this.jdbc = jdbc;
    this.objectMapper = objectMapper;
  }

  /** Inserts one event in the current transaction (or a new one if none is active). */
  @Transactional(propagation = Propagation.REQUIRED)
  public void write(AuditEvent event) {
    insert(event);
  }

  /**
   * Inserts one event in a transaction of its own ({@code REQUIRES_NEW}): it commits even when the caller's transaction
   * rolls back. For denials (final review I1), whose request transaction is rolled back by the very exception being
   * audited. Without an active transaction it behaves like {@link #write}.
   */
  @Transactional(propagation = Propagation.REQUIRES_NEW)
  public void writeIndependently(AuditEvent event) {
    insert(event);
  }

  /**
   * Records a sensitive read (spec section 6, permissions with {@code audit_read}), e.g. {@code iam.audit.exported}:
   * a SUCCESS event for {@link com.acme.iam.common.RequestActor#current()}.
   */
  @Transactional(propagation = Propagation.REQUIRED)
  public void read(String action, @Nullable String targetType, @Nullable String targetId,
      @Nullable Map<String, ?> metadata) {
    insert(AuditEvent.forCurrentActor(action)
        .target(targetType, targetId)
        .metadata(metadata)
        .outcome(AuditEvent.Outcome.SUCCESS)
        .build());
  }

  /** Inserts several events in one transaction; returns how many were new (duplicates are skipped). */
  @Transactional(propagation = Propagation.REQUIRED)
  public int writeAll(Collection<AuditEvent> events) {
    int inserted = 0;
    for (AuditEvent event : events) {
      inserted += insert(event);
    }
    return inserted;
  }

  private int insert(AuditEvent e) {
    return jdbc.sql(INSERT_SQL)
        .param("eventId", e.eventId())
        .param("occurredAt", OffsetDateTime.ofInstant(e.occurredAt(), ZoneOffset.UTC))
        .param("accountId", e.accountId())
        .param("tenantId", e.tenantId())
        .param("source", e.source())
        .param("actorUserId", e.actorUserId())
        .param("actorType", e.actorType().name())
        .param("actorIp", normalizeIp(e.actorIp()))
        .param("userAgent", e.userAgent())
        .param("sessionId", e.sessionId())
        .param("requestId", e.requestId())
        .param("action", e.action())
        .param("targetType", e.targetType())
        .param("targetId", e.targetId())
        .param("outcome", e.outcome().name())
        .param("before", json(e.before()))
        .param("after", json(e.after()))
        .param("metadata", json(e.metadata()))
        .update();
  }

  @Nullable
  private String json(@Nullable Map<String, Object> map) {
    if (map == null) {
      return null;
    }
    try {
      return objectMapper.writeValueAsString(redactTree(objectMapper.valueToTree(map)));
    } catch (JsonProcessingException | IllegalArgumentException ex) {
      throw new IllegalArgumentException("Audit payload is not serializable to JSON", ex);
    }
  }

  /**
   * Returns a redacted copy of {@code map}: values are first normalised to plain maps, lists and scalars (records,
   * POJOs, {@code JsonNode}s and arrays included), then the value of every key matching {@link #DENY_LIST} is
   * replaced by {@value #REDACTED}, at any depth.
   */
  public static Map<String, Object> redact(Map<String, ?> map) {
    JsonNode redacted = redactTree(DEFAULT_MAPPER.valueToTree(map));
    return DEFAULT_MAPPER.convertValue(redacted, MAP);
  }

  /** Redacts a JSON tree in place and returns it. */
  private static JsonNode redactTree(JsonNode node) {
    if (node instanceof ObjectNode object) {
      object.properties().forEach(entry -> {
        if (isDenied(entry.getKey())) {
          entry.setValue(TextNode.valueOf(REDACTED));
        } else {
          redactTree(entry.getValue());
        }
      });
    } else if (node instanceof ArrayNode array) {
      array.forEach(AuditWriter::redactTree);
    }
    return node;
  }

  private static boolean isDenied(String key) {
    String lower = key.toLowerCase(Locale.ROOT);
    return DENY_LIST.stream().anyMatch(lower::contains);
  }

  /**
   * The client IP to store: the first element of a comma-separated list (X-Forwarded-For style), if it is an IPv4 or
   * IPv6 literal; otherwise {@code null}. Never performs DNS lookups.
   */
  @Nullable
  public static String normalizeIp(@Nullable String raw) {
    if (raw == null) {
      return null;
    }
    int comma = raw.indexOf(',');
    String first = (comma < 0 ? raw : raw.substring(0, comma)).trim();
    if (IPV4.matcher(first).matches()) {
      return first;
    }
    // Only strings that start with a hex digit or ':', consist of hex digits, ':' and '.', and contain ':' reach
    // InetAddress. It parses those as numeric literals and throws instead of resolving, so no DNS lookup happens.
    if (first.indexOf(':') >= 0 && IPV6_CHARS.matcher(first).matches()) {
      try {
        InetAddress.getByName(first);
        return first;
      } catch (UnknownHostException e) {
        return null;
      }
    }
    return null;
  }
}
