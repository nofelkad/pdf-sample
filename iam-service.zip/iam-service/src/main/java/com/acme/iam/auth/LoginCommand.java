package com.acme.iam.auth;

import org.springframework.lang.Nullable;

/**
 * {@code POST /auth/login} input.
 *
 * @param account optional account slug, required when the email exists in more than one account
 */
public record LoginCommand(String email, String password, @Nullable String account) {

  /** Never print the password. */
  @Override
  public String toString() {
    return "LoginCommand[email=" + email + ", account=" + account + "]";
  }
}
