package com.acme.iam.product;

import java.io.IOException;
import java.io.InputStream;
import java.io.UncheckedIOException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.SmartInitializingSingleton;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.Resource;
import org.springframework.core.io.ResourceLoader;
import org.springframework.stereotype.Component;

/**
 * Loads IAM's own manifest ({@code classpath:iam-manifest.yaml}) at startup, through the same {@link RegistryService}
 * that every product uses (Ruling R20, P1-7.3).
 *
 * <p>It runs from {@link SmartInitializingSingleton}: after Flyway and every singleton exist, but before the web
 * server starts, before any {@code ApplicationRunner} and before the revocation poller. Instances starting together
 * serialise on the registry's per-product advisory lock (they wait, unlike a ShedLock job that would skip), and the
 * later ones find nothing to change. A failure aborts startup: running with an unknown permission catalogue would make
 * every authorization decision suspect.
 *
 * <p>{@code iam.registry.load-on-startup=false} disables it (tests that need a bare registry);
 * {@code iam.registry.manifest} overrides the location.
 */
@Component
public class ManifestLoader implements SmartInitializingSingleton {

  public static final String DEFAULT_LOCATION = "classpath:iam-manifest.yaml";

  private static final Logger log = LoggerFactory.getLogger(ManifestLoader.class);

  private final RegistryService registry;
  private final ResourceLoader resources;
  private final boolean enabled;
  private final String location;

  public ManifestLoader(RegistryService registry, ResourceLoader resources,
      @Value("${iam.registry.load-on-startup:true}") boolean enabled,
      @Value("${iam.registry.manifest:" + DEFAULT_LOCATION + "}") String location) {
    this.registry = registry;
    this.resources = resources;
    this.enabled = enabled;
    this.location = location;
  }

  @Override
  public void afterSingletonsInstantiated() {
    if (!enabled) {
      log.info("IAM manifest load disabled (iam.registry.load-on-startup=false)");
      return;
    }
    ApplyResult result = registry.apply(load());
    log.info("IAM manifest loaded from {}: {}", location, result);
  }

  /** Parses the configured manifest. */
  Manifest load() {
    Resource resource = resources.getResource(location);
    try (InputStream in = resource.getInputStream()) {
      return ManifestParser.parseYaml(in);
    } catch (IOException e) {
      throw new UncheckedIOException("Cannot read the IAM manifest " + location, e);
    }
  }
}
