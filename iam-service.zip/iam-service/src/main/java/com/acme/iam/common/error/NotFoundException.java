package com.acme.iam.common.error;

import java.util.Map;
import org.springframework.http.HttpStatus;

/** 404 Not Found. Default code {@value #DEFAULT_CODE}. */
public class NotFoundException extends ApiException {

  public static final String DEFAULT_CODE = "not_found";

  public NotFoundException(String detail) {
    this(DEFAULT_CODE, detail);
  }

  public NotFoundException(String code, String detail) {
    super(HttpStatus.NOT_FOUND, code, detail);
  }

  public NotFoundException(String code, String detail, Map<String, Object> properties) {
    super(HttpStatus.NOT_FOUND, code, detail, properties);
  }
}
