package com.acme.iam.common.security;

import com.acme.iam.core.Claims;
import java.util.List;
import java.util.UUID;
import org.springframework.security.oauth2.core.OAuth2Error;
import org.springframework.security.oauth2.core.OAuth2ErrorCodes;
import org.springframework.security.oauth2.core.OAuth2TokenValidator;
import org.springframework.security.oauth2.core.OAuth2TokenValidatorResult;
import org.springframework.security.oauth2.jwt.Jwt;

/**
 * Structural check of IAM tokens after signature, issuer and time validation: {@code exp} present; user tokens carry
 * UUID {@code sub/acc/tid/sid} and an integer {@code sv}; application tokens carry {@code sub = "app:<clientId>"}.
 * Anything else is {@code invalid_token}, so downstream code can rely on the claims.
 */
final class IamTokenValidator implements OAuth2TokenValidator<Jwt> {

  private static final OAuth2Error MALFORMED =
      new OAuth2Error(OAuth2ErrorCodes.INVALID_TOKEN, "The token is missing required IAM claims", null);

  @Override
  public OAuth2TokenValidatorResult validate(Jwt jwt) {
    if (jwt.getExpiresAt() == null) {
      return OAuth2TokenValidatorResult.failure(MALFORMED);
    }
    boolean valid = AppCaller.isApp(jwt)
        ? AppCaller.clientId(jwt).filter(id -> !id.isBlank()).isPresent()
        : isUuid(jwt.getSubject())
            && List.of(Claims.ACCOUNT, Claims.TENANT, Claims.SESSION).stream()
                .allMatch(c -> isUuid(jwt.getClaimAsString(c)))
            && jwt.getClaim(Claims.SESSION_VERSION) instanceof Number;
    return valid ? OAuth2TokenValidatorResult.success() : OAuth2TokenValidatorResult.failure(MALFORMED);
  }

  private static boolean isUuid(String value) {
    if (value == null) {
      return false;
    }
    try {
      UUID.fromString(value);
      return true;
    } catch (IllegalArgumentException e) {
      return false;
    }
  }
}
