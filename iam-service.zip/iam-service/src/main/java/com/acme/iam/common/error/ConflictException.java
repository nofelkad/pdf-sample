package com.acme.iam.common.error;

import java.util.Map;
import org.springframework.http.HttpStatus;

/** 409 Conflict. Default code {@value #DEFAULT_CODE}. */
public class ConflictException extends ApiException {

  public static final String DEFAULT_CODE = "conflict";

  public ConflictException(String detail) {
    this(DEFAULT_CODE, detail);
  }

  public ConflictException(String code, String detail) {
    super(HttpStatus.CONFLICT, code, detail);
  }

  public ConflictException(String code, String detail, Map<String, Object> properties) {
    super(HttpStatus.CONFLICT, code, detail, properties);
  }
}
