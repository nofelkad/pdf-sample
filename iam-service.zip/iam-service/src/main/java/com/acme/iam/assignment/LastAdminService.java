package com.acme.iam.assignment;

import com.acme.iam.account.Account;
import com.acme.iam.account.AccountService;
import com.acme.iam.common.error.ConflictException;
import com.acme.iam.product.Product;
import com.acme.iam.role.Role;
import com.acme.iam.role.RoleService;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import org.springframework.jdbc.core.simple.JdbcClient;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

/**
 * Invariant I7 (spec section 5): the last active Account Admin of an account cannot be revoked or disabled.
 *
 * <p>An <b>effective admin</b> of account A is a user of A with status {@code ACTIVE} holding a <b>non-expiring</b>
 * ({@code expires_at IS NULL}, ruling R43) ACCOUNT-scope assignment (scope A) of the IAM SYSTEM role
 * {@value Role#ACCOUNT_ADMIN}, or of {@value Role#PLATFORM_ADMIN} when A is the PLATFORM account. A grant that expires
 * does not keep the account administrable, so it neither counts as "another admin" nor is protected itself.
 *
 * <p>Ruling R43 also guards tenant status: {@link #requireAdminOutsideTenant} refuses to suspend or archive a tenant
 * that is the primary tenant of every remaining effective admin (login, refresh and switch deny when the primary tenant
 * is not ACTIVE). The platform recovery endpoint ({@code POST /api/platform/accounts/{id}/admins}) is the way back if an
 * account still ends up without a usable admin.
 *
 * <p><b>Usage:</b> call inside the caller's transaction ({@code Propagation.MANDATORY}) <b>before the caller's own
 * writes</b> and before any {@code RevocationService.revoke*} call:
 * <pre>{@code
 * @Transactional void disable(UUID userId) {
 *   lastAdminService.requireNotLastAdmin(accountId, userId);   // 1. lock + check
 *   users.save(user.withStatus(DISABLED));                      // 2. own writes
 *   revocationService.revokeUsers(List.of(userId), "user.disabled"); // 3. last write
 * }
 * }</pre>
 *
 * <p><b>Concurrency:</b> each check first takes a transaction-scoped advisory lock on the account
 * ({@code pg_advisory_xact_lock(hashtext('iam:last_admin'), hashtext(accountId))}, the two-int key space, so it
 * cannot collide with the single-bigint revocation feed lock). The lock is held until the caller commits, so two
 * concurrent removals of the last two admins serialise and the second one sees the first one's committed change.
 * Bulk operations spanning several accounts must take these per-account locks (call the checks) in ascending
 * account-id order, so two such operations cannot deadlock on each other.
 */
@Service
public class LastAdminService {

  public static final String CODE = "last_admin";

  private static final String LOCK_SQL =
      "SELECT 1 FROM (SELECT pg_advisory_xact_lock(hashtext('iam:last_admin'), hashtext(CAST(:account AS text)))) l";

  /** Effective admins of {@code :account} through {@code :role}, minus an excluded user or assignment. */
  private static final String OTHER_ADMINS_SQL = """
      SELECT count(DISTINCT ra.user_id)
      FROM role_assignment ra
      JOIN app_user u ON u.id = ra.user_id
      WHERE ra.role_id = :role
        AND ra.scope_type = 'ACCOUNT' AND ra.scope_id = :account
        AND ra.expires_at IS NULL
        AND u.account_id = :account AND u.status = 'ACTIVE'
        AND ra.user_id <> :excludedUser
        AND ra.id <> :excludedAssignment
      """;

  private static final String IS_ADMIN_SQL = """
      SELECT EXISTS (
        SELECT 1 FROM role_assignment ra JOIN app_user u ON u.id = ra.user_id
        WHERE ra.user_id = :user AND ra.role_id = :role
          AND ra.scope_type = 'ACCOUNT' AND ra.scope_id = :account
          AND ra.expires_at IS NULL
          AND u.account_id = :account AND u.status = 'ACTIVE')
      """;

  /**
   * R43: effective admins of {@code :account} whose primary tenant is {@code :tenant} ({@code in_tenant}), and those
   * who can still log in elsewhere: primary tenant ACTIVE and not {@code :tenant}, primary membership ACTIVE.
   */
  private static final String ADMINS_BY_PRIMARY_SQL = """
      SELECT count(DISTINCT u.id) FILTER (WHERE u.primary_tenant_id = :tenant) AS in_tenant,
             count(DISTINCT u.id) FILTER (WHERE u.primary_tenant_id <> :tenant AND t.status = 'ACTIVE'
                                            AND m.status = 'ACTIVE') AS elsewhere
      FROM role_assignment ra
      JOIN app_user u ON u.id = ra.user_id
      JOIN tenant t ON t.id = u.primary_tenant_id
      LEFT JOIN user_tenant_membership m ON m.app_user = u.id AND m.tenant_id = u.primary_tenant_id
      WHERE ra.role_id = :role
        AND ra.scope_type = 'ACCOUNT' AND ra.scope_id = :account
        AND ra.expires_at IS NULL
        AND u.account_id = :account AND u.status = 'ACTIVE'
      """;

  private static final UUID NONE = new UUID(0, 0);

  private final JdbcClient jdbc;
  private final RoleService roles;
  private final AccountService accounts;

  public LastAdminService(JdbcClient jdbc, RoleService roles, AccountService accounts) {
    this.jdbc = jdbc;
    this.roles = roles;
    this.accounts = accounts;
  }

  /**
   * Before disabling or deprovisioning {@code userId}: fails when the user is an effective admin of the account and no
   * other ACTIVE user of the account is one.
   *
   * @throws ConflictException {@value #CODE}
   * @throws IllegalArgumentException when the user exists but belongs to another account (a caller bug; a mismatched
   *     account would otherwise silently bypass I7). An unknown user passes (nothing to protect).
   */
  @Transactional(propagation = Propagation.MANDATORY)
  public void requireNotLastAdmin(UUID accountId, UUID userId) {
    Optional<UUID> usersAccount = jdbc.sql("SELECT account_id FROM app_user WHERE id = :id")
        .param("id", userId).query(UUID.class).optional();
    if (usersAccount.isEmpty()) {
      return;
    }
    if (!usersAccount.get().equals(accountId)) {
      throw new IllegalArgumentException("User " + userId + " does not belong to account " + accountId);
    }
    lock(accountId);
    Optional<UUID> role = adminRole(accountId);
    if (role.isEmpty() || !isEffectiveAdmin(accountId, userId, role.get())) {
      return;
    }
    if (otherAdmins(accountId, role.get(), userId, NONE) == 0) {
      throw lastAdmin();
    }
  }

  /**
   * Before revoking or deleting assignment {@code assignmentId}: fails when it is an effective admin grant and removing
   * it would leave the account without any effective admin. An unknown assignment passes (nothing to protect).
   *
   * @throws ConflictException {@value #CODE}
   */
  @Transactional(propagation = Propagation.MANDATORY)
  public void requireNotLastAdminAssignment(UUID assignmentId) {
    Optional<UUID> accountOfUser = accountOfAssignment(assignmentId);
    if (accountOfUser.isEmpty()) {
      return;
    }
    UUID accountId = accountOfUser.get();
    lock(accountId);
    Optional<Map<String, Object>> grant = jdbc.sql("""
            SELECT ra.user_id, ra.role_id, ra.scope_type, ra.scope_id
            FROM role_assignment ra WHERE ra.id = :id""")
        .param("id", assignmentId).query().listOfRows().stream().findFirst(); // re-read under the lock
    Optional<UUID> role = adminRole(accountId);
    if (grant.isEmpty() || role.isEmpty()) {
      return;
    }
    Map<String, Object> g = grant.get();
    boolean adminGrant = role.get().equals(g.get("role_id"))
        && "ACCOUNT".equals(g.get("scope_type"))
        && accountId.equals(g.get("scope_id"));
    UUID userId = (UUID) g.get("user_id");
    if (!adminGrant || !isEffectiveAdmin(accountId, userId, role.get())) {
      return;
    }
    // (user, role, ACCOUNT, account) is unique, so other admins = users other than this one
    if (otherAdmins(accountId, role.get(), userId, assignmentId) == 0) {
      throw lastAdmin();
    }
  }

  /**
   * Ruling R43: before suspending or archiving {@code tenantId}: fails when at least one effective admin has it as
   * primary tenant and no effective admin could still log in through another ACTIVE primary tenant. Takes the
   * account's I7 lock first (lock order: I7 advisory lock, then rows).
   *
   * @throws ConflictException {@value #CODE}
   */
  @Transactional(propagation = Propagation.MANDATORY)
  public void requireAdminOutsideTenant(UUID accountId, UUID tenantId) {
    lock(accountId);
    Optional<UUID> role = adminRole(accountId);
    if (role.isEmpty()) {
      return;
    }
    Map<String, Object> counts = jdbc.sql(ADMINS_BY_PRIMARY_SQL)
        .param("role", role.get()).param("account", accountId).param("tenant", tenantId)
        .query().singleRow();
    if (((Number) counts.get("in_tenant")).longValue() > 0 && ((Number) counts.get("elsewhere")).longValue() == 0) {
      throw new ConflictException(CODE, "Every remaining admin of the account has this tenant as primary tenant; "
          + "suspending or archiving it would lock them all out. Make another user an admin first, or move an "
          + "admin's primary tenant.");
    }
  }

  /**
   * Takes the account's I7 advisory lock (held to commit) without checking anything: for writers that add admins
   * (the R43 recovery endpoint) and must serialise with the checks above.
   */
  @Transactional(propagation = Propagation.MANDATORY)
  public void lockAccount(UUID accountId) {
    lock(accountId);
  }

  // ---------------------------------------------------------------------------------------------------------------

  private void lock(UUID accountId) {
    jdbc.sql(LOCK_SQL).param("account", accountId).query(Integer.class).single();
  }

  /** Account Admin, or Platform Admin for the PLATFORM account; empty when the role does not exist (yet). */
  private Optional<UUID> adminRole(UUID accountId) {
    Account account = accounts.getById(accountId);
    String name = account.isPlatform() ? Role.PLATFORM_ADMIN : Role.ACCOUNT_ADMIN;
    return roles.findSystemRole(Product.IAM_ID, name).map(Role::id);
  }

  private boolean isEffectiveAdmin(UUID accountId, UUID userId, UUID roleId) {
    return Boolean.TRUE.equals(jdbc.sql(IS_ADMIN_SQL)
        .param("user", userId).param("role", roleId).param("account", accountId)
        .query(Boolean.class).single());
  }

  private long otherAdmins(UUID accountId, UUID roleId, UUID excludedUser, UUID excludedAssignment) {
    return jdbc.sql(OTHER_ADMINS_SQL)
        .param("role", roleId).param("account", accountId)
        .param("excludedUser", excludedUser).param("excludedAssignment", excludedAssignment)
        .query(Long.class).single();
  }

  private Optional<UUID> accountOfAssignment(UUID assignmentId) {
    return jdbc.sql("SELECT u.account_id FROM role_assignment ra JOIN app_user u ON u.id = ra.user_id WHERE ra.id = :id")
        .param("id", assignmentId).query(UUID.class).optional();
  }

  private static ConflictException lastAdmin() {
    return new ConflictException(CODE, "The last active admin of the account cannot be removed or disabled");
  }
}
