package com.acme.iam.observability;

import io.micrometer.core.instrument.MeterRegistry;
import io.micrometer.core.instrument.Tag;
import io.micrometer.core.instrument.Timer;
import java.util.List;
import org.aspectj.lang.ProceedingJoinPoint;

/**
 * A pair of timers {@code outcome=success|error} of one meter name, both registered up front so the series exist (at
 * zero) from the first scrape. Every timer publishes the client-side percentiles of {@link MetricNames#PERCENTILES}
 * ({@code quantile="0.5|0.95|0.99"} series, per instance and over a sliding window; they cannot be averaged across
 * instances, so dashboards plot one line per instance).
 */
final class OutcomeTimer {

  private final Timer success;
  private final Timer error;

  OutcomeTimer(MeterRegistry registry, String name, String description, List<Tag> tags) {
    this.success = build(registry, name, description, tags, "success");
    this.error = build(registry, name, description, tags, "error");
  }

  /** Runs the join point and records its duration; an exception is recorded as {@code error} and rethrown. */
  Object time(ProceedingJoinPoint joinPoint) throws Throwable {
    long start = System.nanoTime();
    boolean ok = false;
    try {
      Object result = joinPoint.proceed();
      ok = true;
      return result;
    } finally {
      (ok ? success : error).record(System.nanoTime() - start, java.util.concurrent.TimeUnit.NANOSECONDS);
    }
  }

  private static Timer build(MeterRegistry registry, String name, String description, List<Tag> tags,
                             String outcome) {
    return Timer.builder(name)
        .description(description)
        .tags(tags)
        .tag("outcome", outcome)
        .publishPercentiles(MetricNames.PERCENTILES)
        .register(registry);
  }
}
