package com.acme.iam.auth;

import com.acme.iam.common.error.ApiException;
import com.acme.iam.common.error.BadRequestException;
import com.acme.iam.common.error.ConflictException;
import com.acme.iam.common.error.ForbiddenException;
import java.util.List;
import java.util.Map;
import org.springframework.http.HttpStatus;

/** Error codes and exceptions of the {@code /auth} endpoints (RFC 7807 {@code code} member). */
public final class AuthErrors {

  /** 401: unknown email, wrong password, locked user, inactive account/tenant/membership (never distinguished). */
  public static final String INVALID_CREDENTIALS = "invalid_credentials";
  public static final String INVALID_CREDENTIALS_DETAIL = "Invalid email or password";
  /** 409: the email and password match users in several accounts; property {@code accounts: [{slug, name}]}. */
  public static final String ACCOUNT_SELECTION_REQUIRED = "account_selection_required";
  /** 401: unknown, rotated (reuse), revoked, expired or idle refresh token. */
  public static final String INVALID_REFRESH_TOKEN = "invalid_refresh_token";
  /** 401: the session ended because the user, account, tenant or membership is no longer active (R17). */
  public static final String SESSION_INVALID = "session_invalid";
  /** 403: switch-tenant target without an ACTIVE membership in an ACTIVE tenant of the caller's account. */
  public static final String TENANT_NOT_ACCESSIBLE = "tenant_not_accessible";
  /** 400: password change with a wrong current password. */
  public static final String INVALID_CURRENT_PASSWORD = "invalid_current_password";
  /** 403: password change while a failed-login lockout is in force. */
  public static final String ACCOUNT_LOCKED = "account_locked";
  /** 409: the password changed between verifying the current one and storing the new one. */
  public static final String CONCURRENT_MODIFICATION = "concurrent_modification";
  /** 403: invitation accept while the account, primary tenant or membership is not active. */
  public static final String ACCESS_INACTIVE = "access_inactive";
  /** 429 with {@code Retry-After}; property {@code retryAfter} (seconds). */
  public static final String RATE_LIMITED = "rate_limited";

  private AuthErrors() {}

  static ApiException invalidCredentials() {
    return new ApiException(HttpStatus.UNAUTHORIZED, INVALID_CREDENTIALS, INVALID_CREDENTIALS_DETAIL);
  }

  static ApiException accountSelectionRequired(List<Map<String, String>> accounts) {
    return new ApiException(HttpStatus.CONFLICT, ACCOUNT_SELECTION_REQUIRED,
        "The email exists in several accounts; repeat the login with one of the account slugs",
        Map.of("accounts", accounts));
  }

  static ApiException invalidRefreshToken() {
    return new ApiException(HttpStatus.UNAUTHORIZED, INVALID_REFRESH_TOKEN, "The refresh token is invalid or expired");
  }

  static ApiException sessionInvalid() {
    return new ApiException(HttpStatus.UNAUTHORIZED, SESSION_INVALID, "The session is no longer valid; log in again");
  }

  static ApiException tenantNotAccessible() {
    return ForbiddenException.alreadyAudited(TENANT_NOT_ACCESSIBLE,
        "No active membership in an active tenant with this id");
  }

  static ApiException invalidCurrentPassword() {
    return new BadRequestException(INVALID_CURRENT_PASSWORD, "The current password is not correct");
  }

  static ApiException accountLocked() {
    return ForbiddenException.alreadyAudited(ACCOUNT_LOCKED, "Too many failed attempts; try again later");
  }

  static ApiException concurrentModification() {
    return new ConflictException(CONCURRENT_MODIFICATION, "The password was changed concurrently; try again");
  }

  static ApiException accessInactive() {
    return ForbiddenException.alreadyAudited(ACCESS_INACTIVE, "The account, tenant or membership is not active");
  }
}
