package com.acme.iam.appclient;

import java.util.List;
import java.util.Optional;
import java.util.UUID;
import org.springframework.data.jdbc.repository.query.Query;
import org.springframework.data.repository.ListCrudRepository;

interface AppClientRepository extends ListCrudRepository<AppClient, UUID> {

  Optional<AppClient> findByClientId(String clientId);

  boolean existsByClientId(String clientId);

  /** Keyset page ordered by id (UUIDv7, i.e. registration order). */
  @Query("SELECT * FROM app_client WHERE id > :after ORDER BY id LIMIT :limit")
  List<AppClient> findPage(UUID after, int limit);
}
