package com.acme.iam.user;

import java.time.Instant;
import java.util.UUID;

/**
 * Result of {@link UserTokenService#issue}: the raw token is available exactly once, here. Hand it to the
 * {@link NotificationPort}; never log or persist it. {@link #toString()} omits it.
 */
public record IssuedToken(UUID tokenId, String rawToken, Instant expiresAt) {

  @Override
  public String toString() {
    return "IssuedToken[tokenId=" + tokenId + ", expiresAt=" + expiresAt + "]";
  }
}
