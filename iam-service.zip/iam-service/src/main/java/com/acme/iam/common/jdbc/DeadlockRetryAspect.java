package com.acme.iam.common.jdbc;

import java.sql.SQLException;
import java.time.Duration;
import java.util.Set;
import java.util.concurrent.ThreadLocalRandom;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;
import org.springframework.transaction.support.TransactionSynchronizationManager;

/**
 * Implements {@link RetryOnDeadlock} (Task 9, deferred fix E2). Ordered before the transaction interceptor
 * ({@code @EnableTransactionManagement} uses {@code LOWEST_PRECEDENCE}), so it wraps the whole transaction: every attempt
 * begins, runs and rolls back (or commits) a transaction of its own.
 *
 * <p>Retries only when no transaction is active on entry and the failure's cause chain contains a
 * {@link SQLException} with SQLSTATE {@value #DEADLOCK} or {@value #SERIALIZATION_FAILURE}; everything else
 * (including {@code ApiException}s) propagates unchanged. At most {@value #MAX_ATTEMPTS} attempts; the wait before
 * attempt {@code n+1} is {@code BASE_BACKOFF * 2^(n-1)} plus a random jitter of up to the same amount. The last
 * failure propagates as is (500 {@code internal_error}).
 */
@Aspect
@Component
@Order(Ordered.HIGHEST_PRECEDENCE + 100)
public class DeadlockRetryAspect {

  public static final int MAX_ATTEMPTS = 3;
  public static final String DEADLOCK = "40P01";
  public static final String SERIALIZATION_FAILURE = "40001";
  static final Duration BASE_BACKOFF = Duration.ofMillis(25);
  private static final Set<String> RETRYABLE = Set.of(DEADLOCK, SERIALIZATION_FAILURE);
  private static final Logger log = LoggerFactory.getLogger(DeadlockRetryAspect.class);

  @Around("@annotation(com.acme.iam.common.jdbc.RetryOnDeadlock)")
  public Object retry(ProceedingJoinPoint call) throws Throwable {
    if (TransactionSynchronizationManager.isActualTransactionActive()) {
      return call.proceed(); // not the outermost transaction: the caller's entry point decides
    }
    for (int attempt = 1; ; attempt++) {
      try {
        return call.proceed();
      } catch (RuntimeException e) {
        String state = retryableSqlState(e);
        if (state == null || attempt >= MAX_ATTEMPTS) {
          if (state != null) {
            log.warn("{} failed with SQLSTATE {} after {} attempts; giving up", call.getSignature().toShortString(),
                state, attempt);
          }
          throw e;
        }
        log.info("{} hit SQLSTATE {} (attempt {} of {}); retrying the transaction",
            call.getSignature().toShortString(), state, attempt, MAX_ATTEMPTS);
        sleep(backoff(attempt));
      }
    }
  }

  /** The retryable SQLSTATE in {@code failure}'s cause chain, or {@code null}. */
  static String retryableSqlState(Throwable failure) {
    for (Throwable t = failure; t != null; t = t.getCause() == t ? null : t.getCause()) {
      if (t instanceof SQLException sql) {
        for (SQLException e = sql; e != null; e = e.getNextException()) {
          if (e.getSQLState() != null && RETRYABLE.contains(e.getSQLState())) {
            return e.getSQLState();
          }
        }
      }
    }
    return null;
  }

  static Duration backoff(int failedAttempt) {
    long base = BASE_BACKOFF.toMillis() << Math.max(0, failedAttempt - 1);
    return Duration.ofMillis(base + ThreadLocalRandom.current().nextLong(base + 1));
  }

  private static void sleep(Duration duration) {
    try {
      Thread.sleep(duration.toMillis());
    } catch (InterruptedException e) {
      Thread.currentThread().interrupt();
      throw new IllegalStateException("Interrupted while waiting to retry a deadlocked transaction", e);
    }
  }
}
