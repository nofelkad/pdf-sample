package com.acme.iam.account;

import java.time.Instant;
import java.time.LocalDate;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.stream.Collectors;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.Id;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.annotation.Version;
import org.springframework.data.relational.core.mapping.MappedCollection;
import org.springframework.data.relational.core.mapping.Table;

/**
 * Account aggregate root: the commercial and isolation boundary. Owns its product subscriptions
 * ({@link AccountProduct}); they are rewritten (delete + insert) on every save, which is fine for a handful of rows.
 *
 * <p>{@code id == null} and {@code version == null} mean "new": the id is assigned (UUIDv7) on insert.
 */
@Table("account")
public record Account(
    @Id UUID id,
    String name,
    String slug,
    AccountKind kind,
    AccountStatus status,
    Map<String, Object> settings,
    @MappedCollection(idColumn = "account") Set<AccountProduct> products,
    @Version Long version,
    @CreatedDate Instant createdAt,
    @LastModifiedDate Instant updatedAt) {

  /** The seeded operator account (V3__seed.sql). */
  public static final UUID PLATFORM_ID = UUID.fromString("00000000-0000-7000-8000-0000000000a1");

  public Account {
    settings = settings == null ? Map.of() : settings;
    products = products == null ? Set.of() : Set.copyOf(products);
  }

  /** A new ACTIVE account with empty settings and no subscriptions. */
  public static Account create(String name, String slug, AccountKind kind) {
    return new Account(null, name, slug, kind, AccountStatus.ACTIVE, Map.of(), Set.of(), null, null, null);
  }

  public boolean isActive() {
    return status == AccountStatus.ACTIVE;
  }

  public boolean isPlatform() {
    return kind == AccountKind.PLATFORM;
  }

  /**
   * Products this account is entitled to on {@code today}: subscriptions in an entitling status (ACTIVE, TRIAL) that
   * have not ended, exactly the {@code account_product} half of the permission resolver's predicate. IAM is always
   * entitled and is not implied here.
   */
  public Set<UUID> entitledProductIds(LocalDate today) {
    return products.stream()
        .filter(p -> p.status().entitles() && (p.endsAt() == null || !p.endsAt().isBefore(today)))
        .map(AccountProduct::productId)
        .collect(Collectors.toUnmodifiableSet());
  }

  public Account withName(String newName) {
    return new Account(id, newName, slug, kind, status, settings, products, version, createdAt, updatedAt);
  }

  public Account withStatus(AccountStatus newStatus) {
    return new Account(id, name, slug, kind, newStatus, settings, products, version, createdAt, updatedAt);
  }

  public Account withSettings(Map<String, Object> newSettings) {
    return new Account(id, name, slug, kind, status, newSettings, products, version, createdAt, updatedAt);
  }

  public Account withProducts(Set<AccountProduct> newProducts) {
    return new Account(id, name, slug, kind, status, settings, newProducts, version, createdAt, updatedAt);
  }
}
