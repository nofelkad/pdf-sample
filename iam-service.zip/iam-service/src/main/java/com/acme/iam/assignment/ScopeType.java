package com.acme.iam.assignment;

/** {@code role_assignment.scope_type}: an ACCOUNT-scope grant applies in every tenant of the account. */
public enum ScopeType {
  ACCOUNT,
  TENANT
}
