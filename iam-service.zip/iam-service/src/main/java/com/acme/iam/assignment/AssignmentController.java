package com.acme.iam.assignment;

import com.acme.iam.common.paging.KeysetPage;
import com.acme.iam.common.security.CurrentUser;
import com.acme.iam.common.security.TenantGuard;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import java.time.Instant;
import java.util.UUID;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.lang.Nullable;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/**
 * Assignment API (P1-10.4), all of it {@code iam.role.assign} and scoped to the caller's account (I10). Reading
 * assignments by user or by role is account-wide for holders of the permission at ACCOUNT scope; a TENANT-scope holder
 * sees only members of the active tenant and the assignments that apply there (ACCOUNT scope, or TENANT scope in the
 * active tenant). The tenant list needs the active tenant or an account-scope grant ({@link TenantGuard}). See {@link AssignmentAdminService} for the write rules.
 */
@RestController
public class AssignmentController {

  /** {@code expiresAt} must lie in the future when present. */
  public record AssignRequest(@NotNull UUID roleId, @NotNull ScopeType scopeType, @NotNull UUID scopeId,
      @Nullable Instant expiresAt) {}

  private final CurrentUser currentUser;
  private final AssignmentAdminService admin;
  private final AssignmentQueryService query;
  private final TenantGuard tenantGuard;

  public AssignmentController(CurrentUser currentUser, AssignmentAdminService admin, AssignmentQueryService query,
      TenantGuard tenantGuard) {
    this.currentUser = currentUser;
    this.admin = admin;
    this.query = query;
    this.tenantGuard = tenantGuard;
  }

  @PostMapping("/api/users/{userId}/assignments")
  @PreAuthorize("hasAuthority('iam.role.assign')")
  public ResponseEntity<AssignmentView> assign(@PathVariable UUID userId, @Valid @RequestBody AssignRequest request) {
    AssignmentView created = admin.assign(currentUser.userId(), currentUser.accountId(), userId, request.roleId(),
        request.scopeType(), request.scopeId(), request.expiresAt());
    return ResponseEntity.status(HttpStatus.CREATED).body(created);
  }

  @DeleteMapping("/api/assignments/{id}")
  @PreAuthorize("hasAuthority('iam.role.assign')")
  public ResponseEntity<Void> revoke(@PathVariable UUID id) {
    admin.revoke(currentUser.userId(), currentUser.accountId(), id);
    return ResponseEntity.noContent().build();
  }

  @GetMapping("/api/users/{userId}/assignments")
  @PreAuthorize("hasAuthority('iam.role.assign')")
  public KeysetPage<AssignmentView> byUser(@PathVariable UUID userId,
      @RequestParam(required = false) @Nullable String cursor,
      @RequestParam(required = false) @Nullable Integer limit) {
    return query.listByUser(currentUser.accountId(), userId, tenantFilter(), cursor, limit);
  }

  @GetMapping("/api/roles/{roleId}/assignments")
  @PreAuthorize("hasAuthority('iam.role.assign')")
  public KeysetPage<AssignmentView> byRole(@PathVariable UUID roleId,
      @RequestParam(required = false) @Nullable String cursor,
      @RequestParam(required = false) @Nullable Integer limit) {
    return query.listByRole(currentUser.accountId(), roleId, tenantFilter(), cursor, limit);
  }

  /**
   * {@code null} (account-wide) for holders of {@code iam.role.assign} at ACCOUNT scope; otherwise the active tenant:
   * a TENANT-scope holder sees only members of that tenant and only assignments that apply there (Task 9).
   */
  @Nullable
  private UUID tenantFilter() {
    return tenantGuard.hasAccountScope(AssignmentAdminService.PERMISSION) ? null : currentUser.tenantId();
  }

  @GetMapping("/api/tenants/{tenantId}/assignments")
  @PreAuthorize("hasAuthority('iam.role.assign')")
  public KeysetPage<AssignmentView> byTenant(@PathVariable UUID tenantId,
      @RequestParam(required = false) @Nullable String cursor,
      @RequestParam(required = false) @Nullable Integer limit) {
    tenantGuard.requireActive(tenantId, AssignmentAdminService.PERMISSION);
    return query.listByTenant(currentUser.accountId(), tenantId, cursor, limit);
  }
}
