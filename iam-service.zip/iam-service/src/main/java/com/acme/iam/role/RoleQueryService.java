package com.acme.iam.role;

import com.acme.iam.common.paging.KeysetCursor;
import com.acme.iam.common.paging.KeysetPage;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.OffsetDateTime;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import org.springframework.jdbc.core.simple.JdbcClient;
import org.springframework.lang.Nullable;
import org.springframework.stereotype.Service;

/**
 * Role list read model (P1-3.4): the roles visible to an account (SYSTEM roles plus its own CUSTOM roles) with
 * permission and assignment counts, keyset-paginated newest first.
 *
 * <p>Assignment counts only include assignments inside the caller's account (I10): SYSTEM roles are shared by every
 * account, so counting by role alone would leak other accounts' numbers. The count is driven per scope (the account
 * plus each of its tenants) through a {@code LATERAL} aggregate with equality on all three columns of
 * {@code ra_role_scope_idx (role_id, scope_type, scope_id) INCLUDE (expires_at)} (V10): an index-only probe per
 * (role, scope), so a SYSTEM role held in many other accounts costs nothing extra. (An {@code OR}/{@code = ANY}
 * formulation lets the PG 16 planner demote the scope match to a filter and scan the role's assignments in every
 * account.) Cost grows with roles-on-page x tenants-of-account.
 */
@Service
public class RoleQueryService {

  private final JdbcClient jdbc;

  public RoleQueryService(JdbcClient jdbc) {
    this.jdbc = jdbc;
  }

  /**
   * One page of roles visible to the account.
   *
   * @param accountId the caller's account ({@code acc}); never taken from the request
   * @param cursor {@code nextCursor} of the previous page, or {@code null} for the first page
   * @param limit page size, default 50, capped at 200
   */
  public KeysetPage<RoleSummary> list(UUID accountId, RoleListFilter filter, @Nullable String cursor,
      @Nullable Integer limit) {
    int size = KeysetPage.limit(limit);
    Optional<KeysetCursor> after = KeysetCursor.decode(cursor);

    JdbcClient.StatementSpec spec = jdbc.sql(sql(filter, after.isPresent()))
        .param("accountId", accountId)
        .param("limit", size + 1);
    if (filter.productId() != null) {
      spec = spec.param("productId", filter.productId());
    }
    if (filter.type() != null) {
      spec = spec.param("type", filter.type().name());
    }
    if (after.isPresent()) {
      spec = spec.param("cursorAt", after.get().createdAtParam()).param("cursorId", after.get().id());
    }
    List<RoleSummary> rows = spec.query((rs, i) -> map(rs)).list();
    return KeysetPage.of(rows, size, RoleSummary::createdAt, RoleSummary::id);
  }

  /**
   * The list SQL for exactly the given filters. Parameters: {@code :accountId}, {@code :limit} and, when used,
   * {@code :productId}, {@code :type}, {@code :cursorAt}, {@code :cursorId}.
   */
  static String sql(RoleListFilter filter, boolean withCursor) {
    StringBuilder sql = new StringBuilder("""
        SELECT r.id, r.product_id, pr.code AS product_code, r.name, r.description, r.type, r.account_id, r.created_at,
               (SELECT count(*) FROM role_permission rp WHERE rp.role = r.id) AS permission_count,
               (SELECT coalesce(sum(c.n), 0)
                FROM (SELECT CAST('ACCOUNT' AS text) AS scope_type, CAST(:accountId AS uuid) AS scope_id
                      UNION ALL
                      SELECT 'TENANT', t.id FROM tenant t WHERE t.account_id = :accountId) s
                CROSS JOIN LATERAL (
                      SELECT count(*) AS n FROM role_assignment ra
                      WHERE ra.role_id = r.id AND ra.scope_type = s.scope_type AND ra.scope_id = s.scope_id
                        AND (ra.expires_at IS NULL OR ra.expires_at > now())) c
               ) AS assignment_count
        FROM role r
        JOIN product pr ON pr.id = r.product_id
        WHERE (r.account_id IS NULL OR r.account_id = :accountId)
        """);
    if (filter.productId() != null) {
      sql.append("  AND r.product_id = :productId\n");
    }
    if (filter.type() != null) {
      sql.append("  AND r.type = :type\n");
    }
    if (withCursor) {
      sql.append("  AND (r.created_at, r.id) < (:cursorAt, :cursorId)\n");
    }
    sql.append("ORDER BY r.created_at DESC, r.id DESC\nLIMIT :limit");
    return sql.toString();
  }

  private static RoleSummary map(ResultSet rs) throws SQLException {
    return new RoleSummary(
        rs.getObject("id", UUID.class),
        rs.getObject("product_id", UUID.class),
        rs.getString("product_code"),
        rs.getString("name"),
        rs.getString("description"),
        RoleType.valueOf(rs.getString("type")),
        rs.getObject("account_id", UUID.class),
        rs.getInt("permission_count"),
        rs.getLong("assignment_count"),
        rs.getObject("created_at", OffsetDateTime.class).toInstant());
  }
}
