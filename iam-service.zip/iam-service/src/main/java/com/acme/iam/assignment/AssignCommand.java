package com.acme.iam.assignment;

import java.time.Instant;
import java.util.Objects;
import java.util.UUID;
import org.springframework.lang.Nullable;

/**
 * Request to assign role {@code roleId} to user {@code userId} at {@code scopeType/scopeId}, optionally until
 * {@code expiresAt}. The grantor is the current actor ({@code RequestActor.current()}), never part of the command.
 */
public record AssignCommand(
    UUID userId,
    UUID roleId,
    ScopeType scopeType,
    UUID scopeId,
    @Nullable Instant expiresAt) {

  public AssignCommand {
    Objects.requireNonNull(userId, "userId");
    Objects.requireNonNull(roleId, "roleId");
    Objects.requireNonNull(scopeType, "scopeType");
    Objects.requireNonNull(scopeId, "scopeId");
  }

  public AssignCommand(UUID userId, UUID roleId, ScopeType scopeType, UUID scopeId) {
    this(userId, roleId, scopeType, scopeId, null);
  }
}
