package com.acme.iam.product;

import com.acme.iam.common.error.BadRequestException;
import java.util.List;
import java.util.Map;

/** 400 {@code invalid_manifest} with the full list of {@code violations} (human readable, no secrets). */
public class InvalidManifestException extends BadRequestException {

  public static final String CODE = "invalid_manifest";

  private final List<String> violations;

  public InvalidManifestException(List<String> violations) {
    super(CODE, "The manifest is invalid (" + violations.size() + " violation" + (violations.size() == 1 ? "" : "s")
        + ")", Map.of("violations", List.copyOf(violations)));
    this.violations = List.copyOf(violations);
  }

  public InvalidManifestException(String violation) {
    this(List.of(violation));
  }

  public List<String> violations() {
    return violations;
  }
}
