package com.acme.iam.product;

import com.acme.iam.product.Manifest.ManifestPermission;
import com.acme.iam.product.Manifest.ManifestRole;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.regex.Pattern;

/**
 * Static checks of a {@link Manifest} (P1-7.1, spec section 5 data scope). Nothing here touches the database; the
 * registry adds the checks that need it (a code already owned by another product).
 *
 * <ul>
 *   <li>the product code matches {@code [A-Z][A-Z0-9_]{1,31}} and is not the reserved {@code PLATFORM};
 *   <li>every permission has a well-formed lower-case dotted {@code code} that starts with the product's lower-case
 *       code plus {@code "."} (IAM may also use {@code "platform."}), is unique, has a {@code kind} of FEATURE or DATA
 *       and a description; a DATA permission ends with {@code .own}, {@code .tenant} or {@code .account};
 *   <li>every system role has a unique (case-insensitive) name; its {@code permissions} and {@code exclude} entries are
 *       exact codes or prefix wildcards ending in {@code .*} inside the product's namespace, and an exact code in
 *       {@code permissions} must be declared by the manifest.
 * </ul>
 */
public final class ManifestValidator {

  static final Pattern PRODUCT = Pattern.compile("[A-Z][A-Z0-9_]{1,31}");
  static final Pattern CODE = Pattern.compile("[a-z][a-z0-9_]*(\\.[a-z][a-z0-9_]*)+");
  static final Set<String> DATA_SUFFIXES = Set.of(".own", ".tenant", ".account");
  static final String WILDCARD = ".*";
  /** Size limits (an upload comes from an application, not from a trusted operator). */
  public static final int MAX_PERMISSIONS = 2000;
  public static final int MAX_SYSTEM_ROLES = 200;
  /** Largest accepted manifest body over HTTP, in bytes. */
  public static final int MAX_BODY_BYTES = 1024 * 1024;
  /** Product codes nobody but IAM itself may use: their namespace belongs to IAM. */
  static final Set<String> RESERVED_PRODUCTS = Set.of("PLATFORM");

  private ManifestValidator() {}

  /** The code prefixes a product may use: its own lower-case code plus {@code "."}; IAM also owns {@code "platform."}. */
  public static List<String> allowedPrefixes(String productCode) {
    String own = productCode.toLowerCase(Locale.ROOT) + ".";
    return Product.IAM_CODE.equals(productCode) ? List.of(own, "platform.") : List.of(own);
  }

  /** All violations, in document order; empty when the manifest is valid. */
  public static List<String> validate(Manifest manifest) {
    List<String> violations = new ArrayList<>();
    String product = manifest.product();
    List<String> prefixes = List.of();
    if (product == null || !PRODUCT.matcher(product).matches()) {
      violations.add("product must match " + PRODUCT.pattern() + (product == null ? "" : ", got '" + product + "'"));
    } else {
      prefixes = allowedPrefixes(product);
      if (RESERVED_PRODUCTS.contains(product)) {
        violations.add("product code '" + product + "' is reserved");
      }
    }

    boolean tooBig = false;
    if (manifest.permissions().size() > MAX_PERMISSIONS) {
      violations.add("a manifest may declare at most " + MAX_PERMISSIONS + " permissions, got "
          + manifest.permissions().size());
      tooBig = true;
    }
    if (manifest.systemRoles().size() > MAX_SYSTEM_ROLES) {
      violations.add("a manifest may declare at most " + MAX_SYSTEM_ROLES + " system roles, got "
          + manifest.systemRoles().size());
      tooBig = true;
    }
    if (tooBig) {
      return violations;   // do not spend time checking an oversized document item by item
    }

    Set<String> declared = new HashSet<>();
    Set<String> reportedDuplicates = new HashSet<>();
    for (ManifestPermission permission : manifest.permissions()) {
      checkPermission(permission, prefixes, declared, reportedDuplicates, violations);
    }

    Set<String> roleNames = new HashSet<>();
    for (ManifestRole role : manifest.systemRoles()) {
      checkRole(role, prefixes, declared, roleNames, violations);
    }
    return violations;
  }

  /** @throws InvalidManifestException with every violation when the manifest is not valid */
  public static void requireValid(Manifest manifest) {
    List<String> violations = validate(manifest);
    if (!violations.isEmpty()) {
      throw new InvalidManifestException(violations);
    }
  }

  /** {@code true} when {@code entry} is a prefix wildcard such as {@code iam.*} (the prefix keeps its trailing dot). */
  static boolean isWildcard(String entry) {
    return entry.endsWith(WILDCARD);
  }

  /** The prefix a wildcard stands for, e.g. {@code "iam."} for {@code "iam.*"}. */
  static String wildcardPrefix(String wildcard) {
    return wildcard.substring(0, wildcard.length() - 1);
  }

  private static void checkPermission(ManifestPermission permission, List<String> prefixes, Set<String> declared,
      Set<String> reportedDuplicates, List<String> violations) {
    String code = permission.code();
    if (code == null || code.isBlank()) {
      violations.add("a permission has no code");
      return;
    }
    if (!CODE.matcher(code).matches()) {
      violations.add("permission code '" + code + "' must be lower-case dotted segments such as billing.invoice.approve");
    } else if (prefixes.stream().noneMatch(code::startsWith)) {
      violations.add("permission code '" + code + "' must start with " + String.join(" or ", prefixes));
    }
    if (!declared.add(code) && reportedDuplicates.add(code)) {
      violations.add("duplicate permission code '" + code + "'");
    }
    String kind = permission.kind();
    if (kind == null || !isKind(kind)) {
      violations.add("permission '" + code + "' has an unknown kind " + (kind == null ? "(missing)" : "'" + kind + "'")
          + "; expected FEATURE or DATA");
    } else if (PermissionKind.DATA.name().equals(kind) && DATA_SUFFIXES.stream().noneMatch(code::endsWith)) {
      violations.add("DATA permission '" + code + "' must end with .own, .tenant or .account");
    }
    if (permission.description() == null || permission.description().isBlank()) {
      violations.add("permission '" + code + "' has no description");
    }
  }

  private static boolean isKind(String kind) {
    for (PermissionKind k : PermissionKind.values()) {
      if (k.name().equals(kind)) {
        return true;
      }
    }
    return false;
  }

  private static void checkRole(ManifestRole role, List<String> prefixes, Set<String> declared, Set<String> roleNames,
      List<String> violations) {
    String name = role.name();
    if (name == null || name.isBlank()) {
      violations.add("a system role has no name");
      name = "(unnamed)";
    } else if (!roleNames.add(name.toLowerCase(Locale.ROOT))) {
      violations.add("duplicate system role name '" + name + "'");
    }
    for (String entry : role.permissions()) {
      if (checkEntry(name, entry, prefixes, violations) && !isWildcard(entry) && !declared.contains(entry)) {
        violations.add("role '" + name + "': permission '" + entry + "' is not declared in this manifest");
      }
    }
    for (String entry : role.exclude()) {
      checkEntry(name, entry, prefixes, violations);
    }
  }

  /** Syntax and namespace of one role entry; {@code false} (with a violation added) when unusable. */
  private static boolean checkEntry(String role, String entry, List<String> prefixes, List<String> violations) {
    if (entry == null || entry.isBlank()) {
      violations.add("role '" + role + "': an entry is blank");
      return false;
    }
    if (isWildcard(entry)) {
      String prefix = wildcardPrefix(entry);
      if (prefix.length() < 2 || prefix.contains("*") || prefix.contains("..") || prefix.startsWith(".")) {
        violations.add("role '" + role + "': malformed wildcard '" + entry + "'");
        return false;
      }
    } else if (entry.contains("*") || !CODE.matcher(entry).matches()) {
      violations.add("role '" + role + "': malformed permission entry '" + entry + "'");
      return false;
    }
    String probe = isWildcard(entry) ? wildcardPrefix(entry) : entry;
    if (prefixes.stream().noneMatch(probe::startsWith)) {
      violations.add("role '" + role + "': '" + entry + "' is outside the product namespace ("
          + String.join(", ", prefixes) + ")");
      return false;
    }
    return true;
  }
}
