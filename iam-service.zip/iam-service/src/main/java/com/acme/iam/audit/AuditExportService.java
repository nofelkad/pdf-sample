package com.acme.iam.audit;

import com.acme.iam.common.Ids;
import com.acme.iam.common.RequestActor;
import com.acme.iam.common.error.ApiException;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.UncheckedIOException;
import java.nio.charset.StandardCharsets;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.Clock;
import java.time.Duration;
import java.time.Instant;
import java.time.OffsetDateTime;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.concurrent.Callable;
import java.util.concurrent.Semaphore;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;
import javax.sql.DataSource;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowCallbackHandler;
import org.springframework.jdbc.core.simple.JdbcClient;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.support.TransactionTemplate;
import org.springframework.web.context.request.NativeWebRequest;
import org.springframework.web.context.request.RequestAttributes;
import org.springframework.web.context.request.async.CallableProcessingInterceptor;

/**
 * P1-9.7 (Ruling R21): streamed synchronous CSV export of the audit log.
 *
 * <p>Memory: the query runs in one read-only transaction (autocommit off) through a {@link JdbcClient} over a
 * {@link JdbcTemplate} whose {@code fetchSize} is {@value #FETCH_SIZE}, so the PostgreSQL driver pulls the result with
 * a server-side cursor in pages of that size; each row is mapped straight into a buffered writer on the response
 * stream, which is flushed every {@value #FETCH_SIZE} rows. Nothing proportional to the row count is held.
 *
 * <p>Audit trail (the export is a sensitive read, spec section 6), written with
 * {@link AuditWriter#read(String, String, String, Map)} in its own write-capable transaction, never inside the
 * read-only one:
 * <ol>
 *   <li>{@value #ACTION_STARTED} when the export is accepted, before any data leaves (so a crash mid-stream still
 *       leaves a trail); metadata {@code filters};
 *   <li>{@value #ACTION_EXPORTED} when streaming ends, whatever the outcome; metadata {@code filters},
 *       {@code rowCount} (rows actually written), {@code status} ({@code completed}, {@code aborted} when the client
 *       went away, {@code failed}) and {@code durationMs}. Both events share {@code target_type = audit_export} and
 *       {@code target_id = <export id>}.
 * </ol>
 *
 * <p>At most {@code iam.audit.export.max-concurrent} (default 2) exports run per instance, because each holds a
 * database connection and a request thread for its whole duration; further requests get 429 {@code export_busy}.
 *
 * <p><b>Permit lifecycle (final review M8).</b> {@link #begin} takes the permit on the request thread; normally
 * {@link Export#stream} releases it when it ends. The body may never run, though: the MVC task executor can reject it,
 * or the async request can time out or fail before it starts. The controller therefore stores the export in the request
 * ({@value #EXPORT_ATTRIBUTE}) and {@link PermitReleasingInterceptor} (registered for MVC async requests by
 * {@code AuditWebConfig}) calls {@link Export#abandonIfNotStarted} when the async request completes. An export moves
 * once from PENDING to either STREAMING (the body runs and releases at its end) or ABANDONED (the callback releases,
 * {@value #ACTION_EXPORTED} with {@code status = abandoned}, and a late body writes nothing), so the permit is released
 * exactly once.
 */
@Service
public class AuditExportService {

  public static final String ACTION_STARTED = "iam.audit.export.started";
  public static final String ACTION_EXPORTED = "iam.audit.exported";
  public static final String TARGET_TYPE = "audit_export";
  public static final String BUSY = "export_busy";
  public static final int FETCH_SIZE = 1000;
  /** Request attribute holding the {@link Export} of an export request (for {@link PermitReleasingInterceptor}). */
  public static final String EXPORT_ATTRIBUTE = AuditExportService.class.getName() + ".export";

  private static final int PENDING = 0;
  private static final int STREAMING = 1;
  private static final int ABANDONED = 2;

  static final String[] HEADER = {"event_id", "occurred_at", "received_at", "account_id", "tenant_id", "source",
      "actor_user_id", "actor_type", "actor_ip", "user_agent", "session_id", "request_id", "action", "target_type",
      "target_id", "outcome", "before", "after", "metadata"};

  private static final Logger log = LoggerFactory.getLogger(AuditExportService.class);

  private final JdbcClient streamingJdbc;
  private final TransactionTemplate readOnlyTx;
  private final AuditWriter auditWriter;
  private final Clock clock;
  private final Semaphore permits;

  public AuditExportService(DataSource dataSource, PlatformTransactionManager transactionManager,
                            AuditWriter auditWriter, Clock clock,
                            @Value("${iam.audit.export.max-concurrent:2}") int maxConcurrent) {
    JdbcTemplate template = new JdbcTemplate(dataSource);
    template.setFetchSize(FETCH_SIZE);
    this.streamingJdbc = JdbcClient.create(template);
    this.readOnlyTx = new TransactionTemplate(transactionManager);
    this.readOnlyTx.setReadOnly(true);
    this.auditWriter = auditWriter;
    this.clock = clock;
    this.permits = new Semaphore(maxConcurrent, true);
  }

  /**
   * Accepts an export: takes a concurrency permit and records {@value #ACTION_STARTED}. Call on the request thread
   * (it captures the caller), then hand {@link Export#stream(OutputStream)} to the response. The permit is released
   * when {@code stream} ends, so {@code stream} must always be called.
   *
   * @throws ApiException 429 {@value #BUSY} when the instance already runs its maximum number of exports
   */
  public Export begin(AuditSearchCriteria criteria) {
    if (!permits.tryAcquire()) {
      throw new ApiException(HttpStatus.TOO_MANY_REQUESTS, BUSY, "Too many exports are running; retry shortly");
    }
    try {
      return new Export(criteria);
    } catch (RuntimeException e) {
      permits.release();
      throw e;
    }
  }

  /** One accepted export; {@link #stream} runs it (typically on an MVC async thread). */
  public final class Export {
    private final AuditSearchCriteria criteria;
    private final String exportId = Ids.newId().toString();
    private final SecurityContext securityContext = SecurityContextHolder.getContext();
    private final String requestId = RequestActor.current().requestId();
    private final Instant startedAt = clock.instant();
    private final AtomicLong rows = new AtomicLong();
    private final AtomicInteger state = new AtomicInteger(PENDING);

    private Export(AuditSearchCriteria criteria) {
      this.criteria = criteria;
      auditWriter.read(ACTION_STARTED, TARGET_TYPE, exportId, Map.of("filters", criteria.describe()));
    }

    /**
     * Writes the CSV (UTF-8, header first, CRLF) to {@code out} and records {@value #ACTION_EXPORTED}.
     *
     * @throws IOException when the client went away (status {@code aborted})
     */
    public void stream(OutputStream out) throws IOException {
      if (!state.compareAndSet(PENDING, STREAMING)) {
        return; // abandoned before it started: the permit is already back, write nothing
      }
      SecurityContext previous = SecurityContextHolder.getContext();
      SecurityContextHolder.setContext(securityContext);
      if (requestId != null) {
        MDC.put(RequestActor.MDC_REQUEST_ID, requestId);
      }
      String status = "failed";
      try {
        BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(out, StandardCharsets.UTF_8), 64 * 1024);
        CsvWriter.writeRecord(writer, HEADER);
        AuditSearchSql.Query q = AuditSearchSql.all(criteria);
        try {
          readOnlyTx.executeWithoutResult(tx -> streamingJdbc.sql(q.sql()).params(q.params())
              .query((RowCallbackHandler) rs -> writeRow(rs, writer)));
        } catch (UncheckedIOException e) {
          status = "aborted";
          throw e.getCause();
        }
        writer.flush();
        status = "completed";
      } catch (IOException e) {
        status = "aborted";
        throw e;
      } finally {
        finish(status);
        SecurityContextHolder.setContext(previous);
        MDC.remove(RequestActor.MDC_REQUEST_ID);
        permits.release();
      }
    }

    /**
     * Releases the permit of an export whose body never started (and records {@value #ACTION_EXPORTED} with status
     * {@code abandoned}); a no-op once {@link #stream} has started or after a first call.
     *
     * @return {@code true} when this call released the permit
     */
    public boolean abandonIfNotStarted() {
      if (!state.compareAndSet(PENDING, ABANDONED)) {
        return false;
      }
      try {
        finish("abandoned");
      } finally {
        permits.release();
      }
      return true;
    }

    private void writeRow(ResultSet rs, BufferedWriter writer) throws SQLException {
      try {
        CsvWriter.writeRecord(writer,
            rs.getString("event_id"),
            instant(rs, "occurred_at"),
            instant(rs, "received_at"),
            rs.getString("account_id"),
            rs.getString("tenant_id"),
            rs.getString("source"),
            rs.getString("actor_user_id"),
            rs.getString("actor_type"),
            rs.getString("actor_ip"),
            rs.getString("user_agent"),
            rs.getString("session_id"),
            rs.getString("request_id"),
            rs.getString("action"),
            rs.getString("target_type"),
            rs.getString("target_id"),
            rs.getString("outcome"),
            rs.getString("before_state"),
            rs.getString("after_state"),
            rs.getString("metadata"));
        if (rows.incrementAndGet() % FETCH_SIZE == 0) {
          writer.flush();
        }
      } catch (IOException e) {
        throw new UncheckedIOException(e);
      }
    }

    /** Runs after the read-only transaction has ended, so this insert gets its own write transaction. */
    private void finish(String status) {
      Map<String, Object> metadata = new LinkedHashMap<>();
      metadata.put("filters", criteria.describe());
      metadata.put("rowCount", rows.get());
      metadata.put("status", status);
      metadata.put("durationMs", Duration.between(startedAt, clock.instant()).toMillis());
      try {
        auditWriter.read(ACTION_EXPORTED, TARGET_TYPE, exportId, metadata);
      } catch (RuntimeException e) {
        log.error("Could not record {} for export {} ({} rows, {})", ACTION_EXPORTED, exportId, rows.get(), status, e);
      }
    }
  }

  /**
   * Final review M8: when an MVC async request completes (normally, by timeout or by error, including a body the task
   * executor rejected), gives back the permit of an export whose body never started.
   */
  public static final class PermitReleasingInterceptor implements CallableProcessingInterceptor {
    @Override
    public <T> void afterCompletion(NativeWebRequest request, Callable<T> task) {
      Object export = request.getAttribute(EXPORT_ATTRIBUTE, RequestAttributes.SCOPE_REQUEST);
      if (export instanceof Export e && e.abandonIfNotStarted()) {
        log.warn("Audit export {} ended before it started streaming; its permit was released", e.exportId);
      }
    }
  }

  private static String instant(ResultSet rs, String column) throws SQLException {
    return rs.getObject(column, OffsetDateTime.class).toInstant().toString();
  }
}
