package com.acme.iam.account;

/** {@code account.kind}: the single PLATFORM account is the operator; every other account is a CUSTOMER. */
public enum AccountKind {
  CUSTOMER,
  PLATFORM
}
