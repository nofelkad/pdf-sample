package com.acme.iam.common.security;

import com.acme.iam.common.error.NotFoundException;
import java.util.Map;
import java.util.Objects;
import java.util.UUID;
import org.springframework.jdbc.core.simple.JdbcClient;
import org.springframework.stereotype.Component;

/**
 * Checks a tenant named in the request path against the caller's token (P1-4.4, Ruling R2 as amended). The active
 * tenant always comes from the token; a different tenant is allowed only through an account-scope grant of the same
 * permission the endpoint requires:
 *
 * <ol>
 *   <li>path tenant = token {@code tid}: allowed (no database access);
 *   <li>path tenant not in the token's account (or unknown): {@link NotFoundException} {@code tenant_not_found}
 *       (404, not audited), so other accounts' tenant ids are not confirmed;
 *   <li>otherwise allowed only when the caller holds an unexpired ACCOUNT-scope role assignment in the token's account
 *       whose role contains {@code permission} (not deprecated); else {@link CodedAccessDeniedException}
 *       {@value #SCOPE_EXCEEDED} (403, audited as {@code authz.denied} by {@link AuditingAccessDeniedHandler}).
 * </ol>
 *
 * Pass the same permission as the endpoint's {@code @PreAuthorize}: a TENANT-scope grant in the active tenant never
 * unlocks another tenant. Tenant status is not checked (an account admin must be able to manage a suspended tenant).
 * Application tokens have no tenant and always get {@value #SCOPE_EXCEEDED}.
 *
 * <p>Final review M3: the error codes of the scope checks are defined here once and used everywhere. "The path or filter
 * names a tenant other than the token's, and the caller has no ACCOUNT-scope grant" is always {@value #SCOPE_EXCEEDED}
 * (it was {@code tenant_mismatch} here and in the explain endpoint); "this account-wide action needs the permission at
 * ACCOUNT scope" is always {@value #ACCOUNT_SCOPE_REQUIRED}.
 */
@Component
public class TenantGuard {

  /** 403: another tenant than the token's active tenant, without an ACCOUNT-scope grant of the permission. */
  public static final String SCOPE_EXCEEDED = "scope_exceeded";
  /** 403: an account-wide action or resource whose permission the caller holds only at TENANT scope. */
  public static final String ACCOUNT_SCOPE_REQUIRED = "account_scope_required";
  public static final String TENANT_NOT_FOUND = "tenant_not_found";

  /** Unexpired ACCOUNT-scope assignment in the token's account whose role contains the (non-deprecated) permission. */
  private static final String ACCOUNT_SCOPE_EXISTS = """
      EXISTS (SELECT 1 FROM role_assignment ra
              WHERE ra.user_id = :userId
                AND ra.scope_type = 'ACCOUNT' AND ra.scope_id = :accountId
                AND (ra.expires_at IS NULL OR ra.expires_at > now())
                AND EXISTS (SELECT 1 FROM role_permission rp JOIN permission p ON p.id = rp.permission_id
                            WHERE rp.role = ra.role_id AND p.code = :permission AND NOT p.deprecated))""";

  private static final String CHECK_SQL = "SELECT EXISTS (SELECT 1 FROM tenant t WHERE t.id = :tenantId "
      + "AND t.account_id = :accountId) AS in_account, " + ACCOUNT_SCOPE_EXISTS + " AS account_scope";

  private static final String ACCOUNT_SCOPE_SQL = "SELECT " + ACCOUNT_SCOPE_EXISTS;

  private final CurrentUser currentUser;
  private final JdbcClient jdbc;

  public TenantGuard(CurrentUser currentUser, JdbcClient jdbc) {
    this.currentUser = currentUser;
    this.jdbc = jdbc;
  }

  /**
   * The path tenant must be the token's active tenant, or the caller must hold {@code permission} through an
   * ACCOUNT-scope assignment in the token's account.
   *
   * @param permission the permission the endpoint requires (the same as its {@code @PreAuthorize})
   * @throws NotFoundException {@code tenant_not_found} for an unknown tenant or one of another account
   * @throws CodedAccessDeniedException {@value #SCOPE_EXCEEDED} otherwise (audited)
   */
  public void requireActive(UUID tenantId, String permission) {
    Objects.requireNonNull(tenantId, "tenantId");
    Objects.requireNonNull(permission, "permission");
    if (currentUser.isApp()) {
      throw mismatch(tenantId, permission);
    }
    if (tenantId.equals(currentUser.tenantIdOrNull())) {
      return;
    }
    Map<String, Object> result = jdbc.sql(CHECK_SQL)
        .param("tenantId", tenantId)
        .param("accountId", currentUser.accountId())
        .param("userId", currentUser.userId())
        .param("permission", permission)
        .query().singleRow();
    if (!Boolean.TRUE.equals(result.get("in_account"))) {
      throw new NotFoundException(TENANT_NOT_FOUND, "Tenant not found");
    }
    if (!Boolean.TRUE.equals(result.get("account_scope"))) {
      throw mismatch(tenantId, permission);
    }
  }

  /**
   * Whether the caller holds {@code permission} through an unexpired ACCOUNT-scope assignment in the token's account
   * (the same predicate {@link #requireActive} uses), as opposed to a tenant-scope grant. {@code false} for
   * application tokens.
   */
  public boolean hasAccountScope(String permission) {
    Objects.requireNonNull(permission, "permission");
    if (currentUser.isApp()) {
      return false;
    }
    return Boolean.TRUE.equals(jdbc.sql(ACCOUNT_SCOPE_SQL)
        .param("userId", currentUser.userId())
        .param("accountId", currentUser.accountId())
        .param("permission", permission)
        .query(Boolean.class).single());
  }

  private static CodedAccessDeniedException mismatch(UUID tenantId, String permission) {
    return new CodedAccessDeniedException(SCOPE_EXCEEDED, "The tenant is not the active tenant of this session",
        Map.of("tenantId", tenantId.toString(), "requiredAuthority", permission));
  }
}
