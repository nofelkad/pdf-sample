package com.acme.iam.product;

import java.util.UUID;
import org.springframework.data.annotation.Id;
import org.springframework.data.annotation.Version;
import org.springframework.data.jdbc.core.mapping.AggregateReference;
import org.springframework.data.relational.core.mapping.Table;

/**
 * Permission aggregate root, registered by a product manifest. A deprecated permission is never granted (the resolver
 * skips it) but stays referenced by roles until the manifest owner removes it.
 */
@Table("permission")
public record Permission(
    @Id UUID id,
    AggregateReference<Product, UUID> productId,
    String code,
    PermissionKind kind,
    String description,
    boolean sensitive,
    boolean auditRead,
    boolean deprecated,
    @Version Long version) {

  public static Permission create(UUID productId, String code, PermissionKind kind, String description) {
    return new Permission(null, AggregateReference.to(productId), code, kind, description, false, false, false, null);
  }

  /** The owning product id (never {@code null}). */
  public UUID product() {
    return productId.getId();
  }

  public Permission withFlags(boolean newSensitive, boolean newAuditRead, boolean newDeprecated) {
    return new Permission(id, productId, code, kind, description, newSensitive, newAuditRead, newDeprecated, version);
  }

  /** All manifest-controlled attributes at once (the registry's upsert). */
  public Permission withDefinition(PermissionKind newKind, String newDescription, boolean newSensitive,
      boolean newAuditRead, boolean newDeprecated) {
    return new Permission(id, productId, code, newKind, newDescription, newSensitive, newAuditRead, newDeprecated,
        version);
  }

  public Permission withDescription(String newDescription) {
    return new Permission(id, productId, code, kind, newDescription, sensitive, auditRead, deprecated, version);
  }
}
