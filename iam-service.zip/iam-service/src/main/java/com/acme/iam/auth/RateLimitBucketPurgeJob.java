package com.acme.iam.auth;

import io.github.bucket4j.postgresql.PostgreSQLSelectForUpdateBasedProxyManager;
import net.javacrumbs.shedlock.spring.annotation.SchedulerLock;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

/**
 * Deletes expired rate-limit buckets ({@code bucket.expires_at} in the past, i.e. fully refilled) on one instance
 * (ShedLock), in batches, every {@code iam.auth.rate-limit.purge-interval}.
 */
@Component
public class RateLimitBucketPurgeJob {

  public static final String LOCK_NAME = "rate-limit-bucket-purge";
  static final int BATCH_SIZE = 1000;
  static final int MAX_BATCHES = 100;
  private static final Logger log = LoggerFactory.getLogger(RateLimitBucketPurgeJob.class);

  private final PostgreSQLSelectForUpdateBasedProxyManager<String> buckets;

  public RateLimitBucketPurgeJob(PostgreSQLSelectForUpdateBasedProxyManager<String> authRateLimitBuckets) {
    this.buckets = authRateLimitBuckets;
  }

  @Scheduled(fixedDelayString = "${iam.auth.rate-limit.purge-interval:PT10M}")
  @SchedulerLock(name = LOCK_NAME, lockAtMostFor = "PT5M")
  public void run() {
    try {
      int total = purge();
      if (total > 0) {
        log.info("Purged {} expired rate-limit buckets", total);
      }
    } catch (RuntimeException e) {
      log.error("Rate-limit bucket purge failed", e);
    }
  }

  /** @return number of buckets deleted */
  public int purge() {
    int total = 0;
    for (int i = 0; i < MAX_BATCHES; i++) {
      int removed = buckets.removeExpired(BATCH_SIZE);
      total += removed;
      if (removed < BATCH_SIZE) {
        break;
      }
    }
    return total;
  }
}
