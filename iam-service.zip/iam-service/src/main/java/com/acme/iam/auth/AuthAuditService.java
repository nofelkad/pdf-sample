package com.acme.iam.auth;

import com.acme.iam.audit.AuditEvent;
import com.acme.iam.audit.AuditEvent.ActorType;
import com.acme.iam.audit.AuditEvent.Outcome;
import com.acme.iam.audit.AuditWriter;
import java.time.Clock;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.UUID;
import org.springframework.lang.Nullable;
import org.springframework.stereotype.Service;

/**
 * Explicit {@code auth.*} audit events (spec section 6, P1-5.8). Every event carries the client IP
 * ({@link ClientInfo}, normalised), the user agent and the request id; user events also carry account, tenant and
 * session. {@code user_session}, {@code user_token} and {@code password_history} have no audit trigger, so these
 * events are their audit trail.
 *
 * <p>Failed logins and other pre-authentication events are {@code ANONYMOUS}; when the user they concern is known
 * it is the target ({@code app_user}) and its account is set, so account admins find the event. The email is kept in
 * {@code metadata.email} (not a secret). Passwords, tokens and hashes are never passed in; {@link AuditWriter} also
 * redacts any metadata key containing password/secret/token/hash/private/authorization.
 *
 * <p>Writes join the caller's transaction (or open their own when there is none).
 */
@Service
public class AuthAuditService {

  public static final String LOGIN_SUCCESS = "auth.login.success";
  public static final String LOGIN_FAILED = "auth.login.failed";
  public static final String LOCKED = "auth.locked";
  public static final String REFRESH = "auth.refresh";
  public static final String REFRESH_FAILED = "auth.refresh.failed";
  public static final String REFRESH_REUSE_DETECTED = "auth.refresh.reuse_detected";
  public static final String SESSION_INVALIDATED = "auth.session.invalidated";
  public static final String TENANT_SWITCHED = "auth.tenant.switched";
  public static final String LOGOUT = "auth.logout";
  public static final String LOGOUT_ALL = "auth.logout_all";
  public static final String PASSWORD_FORGOT = "auth.password.forgot";
  public static final String PASSWORD_RESET = "auth.password.reset";
  public static final String PASSWORD_CHANGED = "auth.password.changed";
  /** Password change rejected after verification because the password changed concurrently (409). */
  public static final String PASSWORD_CHANGE_FAILED = "auth.password.change_failed";
  public static final String INVITATION_ACCEPTED = "auth.invitation.accepted";
  public static final String RATE_LIMITED = "auth.rate_limited";

  private final AuditWriter writer;
  private final Clock clock;

  public AuthAuditService(AuditWriter writer, Clock clock) {
    this.writer = writer;
    this.clock = clock;
  }

  /** A new event: ANONYMOUS, outcome SUCCESS, client IP and user agent set. Finish with {@link Entry#write()}. */
  public Entry event(String action, ClientInfo client) {
    return new Entry(action, client);
  }

  /** Fluent builder of one {@code auth.*} event. */
  public final class Entry {
    private final AuditEvent.Builder builder;
    private final Map<String, Object> metadata = new LinkedHashMap<>();

    private Entry(String action, ClientInfo client) {
      this.builder = AuditEvent.builder(action)
          .occurredAt(clock.instant())
          .anonymous()
          .actorIp(AuditWriter.normalizeIp(client.ip()))
          .userAgent(client.userAgent());
    }

    /** The authenticated (or just authenticated) user is the actor and the target. */
    public Entry user(UUID userId, @Nullable UUID accountId, @Nullable UUID tenantId, @Nullable UUID sessionId) {
      builder.actorUserId(userId).actorType(ActorType.USER).accountId(accountId).tenantId(tenantId)
          .sessionId(sessionId).target("app_user", userId.toString());
      return this;
    }

    public Entry user(Caller caller) {
      return user(caller.userId(), caller.accountId(), caller.tenantId(), caller.sessionId());
    }

    /** The event concerns this user, but the actor stays anonymous (e.g. a failed login). */
    public Entry subject(UUID userId, @Nullable UUID accountId) {
      builder.accountId(accountId).target("app_user", userId.toString());
      return this;
    }

    public Entry session(@Nullable UUID sessionId) {
      builder.sessionId(sessionId);
      return this;
    }

    public Entry tenant(@Nullable UUID tenantId) {
      builder.tenantId(tenantId);
      return this;
    }

    public Entry outcome(Outcome outcome) {
      builder.outcome(outcome);
      return this;
    }

    public Entry meta(String key, @Nullable Object value) {
      if (value != null) {
        metadata.put(key, value instanceof UUID ? value.toString() : value);
      }
      return this;
    }

    public void write() {
      writer.write(builder.metadata(metadata.isEmpty() ? null : Map.copyOf(metadata)).build());
    }
  }
}
