package com.acme.iam.user;

import com.acme.iam.assignment.LastAdminService;
import com.acme.iam.audit.AuditEvent;
import com.acme.iam.audit.AuditWriter;
import com.acme.iam.auth.RevocationService;
import com.acme.iam.common.error.ConflictException;
import com.acme.iam.common.error.NotFoundException;
import com.acme.iam.common.jdbc.RetryOnDeadlock;
import com.acme.iam.common.paging.KeysetPage;
import com.acme.iam.common.security.CodedAccessDeniedException;
import com.acme.iam.common.security.CurrentUser;
import com.acme.iam.common.security.TenantGuard;
import java.time.Clock;
import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import org.springframework.jdbc.core.simple.JdbcClient;
import org.springframework.lang.Nullable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * User administration (P1-8.1) for the calling user's account (I10): list and get with data scope, profile update,
 * disable, enable and deprovision.
 *
 * <ul>
 *   <li><b>Data scope (reads):</b> {@value #READ_ACCOUNT} held at ACCOUNT scope sees the whole account; otherwise
 *       ({@value #READ_TENANT}, or {@value #READ_ACCOUNT} through a TENANT-scope assignment) the list is forced to the token's active tenant (another {@code tenantId} filter is 403 {@code scope_exceeded}) and
 *       a user without a membership there is 404.
 *   <li><b>Scope (writes, Ruling R28):</b> {@link #requireManageable}: the caller holds the permission through an
 *       unexpired ACCOUNT-scope assignment ({@link TenantGuard#hasAccountScope}), or the target is <em>tenant-local</em>
 *       (a member of the caller's active tenant with no ACTIVE membership elsewhere and no ACCOUNT-scope assignment;
 *       for status changes, not the caller). Otherwise 403 {@value #ACCOUNT_SCOPE_REQUIRED}. Controllers call it
 *       before the write; disable, enable and deprovision <b>re-check it inside their transaction after locking the
 *       user row</b> ({@code FOR NO KEY UPDATE}), so a concurrent ACCOUNT-scope grant or share into another tenant
 *       (both lock the same row: {@code AssignmentService} via {@link UserService#lockForGrant},
 *       {@link MembershipService#add} via its own row lock) cannot slip between check and write. Without an
 *       authenticated user the re-check fails closed.
 *   <li><b>I7:</b> disable and deprovision first call {@link LastAdminService#requireNotLastAdmin} (its advisory lock
 *       comes before the user row lock).
 *   <li><b>I9:</b> users are never deleted. Deprovision sets DEPROVISIONED, deletes every role assignment and every
 *       membership except the primary one (which becomes SUSPENDED), invalidates outstanding tokens and keeps the
 *       email.
 *   <li><b>Revocation:</b> disable and deprovision end with one {@link RevocationService#revokeUsers} (last write);
 *       sessions are closed by Task 4's refresh re-check (Ruling R17).
 * </ul>
 * Status changes are targeted {@code UPDATE}s ({@link AppUser} save would rewrite the memberships).
 */
@Service
public class UserAdminService {

  public static final String READ_ACCOUNT = "iam.user.read.account";
  public static final String READ_TENANT = "iam.user.read.tenant";
  public static final String ACCOUNT_SCOPE_REQUIRED = TenantGuard.ACCOUNT_SCOPE_REQUIRED;
  /** The permission of the status-change endpoints (disable, enable, deprovision). */
  public static final String MANAGE = "iam.user.manage";
  /** Audit action of {@link #unlock}. */
  public static final String ACTION_UNLOCKED = "auth.unlocked";

  private final AppUserRepository users;
  private final UserQueryService queries;
  private final UserTokenService tokens;
  private final LastAdminService lastAdmin;
  private final RevocationService revocations;
  private final TenantGuard tenantGuard;
  private final CurrentUser currentUser;
  private final JdbcClient jdbc;
  private final Clock clock;
  private final UserCredentialService credentials;
  private final AuditWriter audit;

  public UserAdminService(AppUserRepository users, UserQueryService queries, UserTokenService tokens,
      LastAdminService lastAdmin, RevocationService revocations, TenantGuard tenantGuard, CurrentUser currentUser,
      JdbcClient jdbc, Clock clock, UserCredentialService credentials, AuditWriter audit) {
    this.credentials = credentials;
    this.audit = audit;
    this.users = users;
    this.queries = queries;
    this.tokens = tokens;
    this.lastAdmin = lastAdmin;
    this.revocations = revocations;
    this.tenantGuard = tenantGuard;
    this.currentUser = currentUser;
    this.jdbc = jdbc;
    this.clock = clock;
  }

  // ------------------------------------------------------------------------------------------------- reads

  /**
   * The caller's users, newest first, limited by the caller's data scope.
   *
   * @throws NotFoundException {@code tenant_not_found} when the tenant filter is not a tenant of the caller's account
   * @throws CodedAccessDeniedException {@code scope_exceeded} when a tenant-scoped reader filters by another tenant
   */
  public KeysetPage<UserSummary> list(UserListFilter requested, @Nullable String cursor, @Nullable Integer limit) {
    UserListFilter filter = requested;
    if (requested.tenantId() != null && !jdbc.sql(
            "SELECT EXISTS (SELECT 1 FROM tenant WHERE id = :t AND account_id = :a)")
        .param("t", requested.tenantId()).param("a", currentUser.accountId()).query(Boolean.class).single()) {
      // fix round 1: like TenantGuard, a tenant of another account (or an unknown id) is not confirmed
      throw new NotFoundException("tenant_not_found", "Tenant not found");
    }
    if (!accountWideReader()) {
      UUID activeTenant = currentUser.tenantId();
      if (requested.tenantId() != null && !requested.tenantId().equals(activeTenant)) {
        throw new CodedAccessDeniedException(TenantGuard.SCOPE_EXCEEDED,
            "Listing users of another tenant requires " + READ_ACCOUNT + " at account scope",
            Map.of("tenantId", requested.tenantId().toString(), "requiredAuthority", READ_ACCOUNT));
      }
      filter = new UserListFilter(activeTenant, requested.status(), requested.roleId());
    }
    return queries.list(currentUser.accountId(), filter, cursor, limit);
  }

  /** One user of the caller's account, within the caller's data scope (otherwise 404). */
  public UserView get(UUID userId) {
    AppUser user = load(currentUser.accountId(), userId);
    if (!accountWideReader() && user.membership(currentUser.tenantId()).isEmpty()) {
      throw notFound();
    }
    return UserView.of(user);
  }

  /**
   * {@value #READ_ACCOUNT} in the token <b>and</b> through an unexpired ACCOUNT-scope assignment (Task 9: the JWT
   * {@code perms} carry no scope, so a TENANT-scope grant of the account-wide read permission only reads the active
   * tenant, like {@value #READ_TENANT}).
   */
  private boolean accountWideReader() {
    return currentUser.hasPermission(READ_ACCOUNT) && tenantGuard.hasAccountScope(READ_ACCOUNT);
  }

  /**
   * Write scope check (Ruling R28). Account-wide user actions (status changes, profile, primary tenant, sharing the
   * user) need {@code permission} through an unexpired ACCOUNT-scope assignment ({@link TenantGuard#hasAccountScope}).
   * A tenant-scope holder may act only on a <b>tenant-local</b> target:
   * <ul>
   *   <li>the target has a membership in the caller's active tenant and every ACTIVE membership is there;
   *   <li>the target holds no unexpired ACCOUNT-scope assignment;
   *   <li>for status changes ({@code statusChange}), the target is not the caller.
   * </ul>
   *
   * @throws NotFoundException {@code user_not_found} (checked first, so other accounts' ids are not confirmed)
   * @throws CodedAccessDeniedException {@value #ACCOUNT_SCOPE_REQUIRED} (403, audited)
   */
  public void requireManageable(UUID userId, String permission, boolean statusChange) {
    requireInScope(load(currentUser.accountId(), userId), permission, statusChange);
  }

  /** The R28 decision for an already loaded user. */
  private void requireInScope(AppUser user, String permission, boolean statusChange) {
    if (tenantGuard.hasAccountScope(permission)) {
      return;
    }
    boolean self = user.id().equals(currentUser.userId());
    if (isTenantLocal(user, currentUser.tenantId()) && !(statusChange && self)) {
      return;
    }
    throw new CodedAccessDeniedException(ACCOUNT_SCOPE_REQUIRED,
        "This user can only be managed with an account-wide grant of " + permission,
        Map.of("userId", user.id().toString(), "requiredAuthority", permission));
  }

  /**
   * Locks the user row ({@code FOR NO KEY UPDATE}, until commit) and re-runs the R28 decision for a status change
   * against the committed state seen after the lock. Returns the freshly read user.
   */
  private AppUser lockAndRecheck(UUID accountId, UUID userId) {
    jdbc.sql("SELECT 1 FROM app_user WHERE id = :id AND account_id = :a FOR NO KEY UPDATE")
        .param("id", userId).param("a", accountId).query(Integer.class).optional();
    AppUser fresh = load(accountId, userId);
    requireInScope(fresh, MANAGE, true);
    return fresh;
  }

  private boolean isTenantLocal(AppUser user, UUID activeTenant) {
    if (user.membership(activeTenant).isEmpty()) {
      return false;
    }
    if (user.memberships().stream().anyMatch(m -> m.isActive() && !m.tenantId().equals(activeTenant))) {
      return false;
    }
    return !jdbc.sql("""
            SELECT EXISTS (SELECT 1 FROM role_assignment
                           WHERE user_id = :id AND scope_type = 'ACCOUNT'
                             AND (expires_at IS NULL OR expires_at > now()))""")
        .param("id", user.id()).query(Boolean.class).single();
  }

  // ------------------------------------------------------------------------------------------------ writes

  @Transactional
  public UserView updateProfile(UUID accountId, UUID userId, @Nullable String displayName) {
    load(accountId, userId);
    jdbc.sql("""
            UPDATE app_user SET display_name = :name, version = version + 1, updated_at = :now
            WHERE id = :id AND account_id = :account""")
        .param("name", displayName == null || displayName.isBlank() ? null : displayName.trim())
        .param("now", now()).param("id", userId).param("account", accountId)
        .update();
    return UserView.of(load(accountId, userId));
  }

  /** ACTIVE/INVITED → DISABLED (I7 checked first), outstanding tokens invalidated, tokens revoked. */
  @RetryOnDeadlock
  @Transactional
  public UserView disable(UUID accountId, UUID userId) {
    load(accountId, userId); // 404 first: LastAdminService rejects users of other accounts
    lastAdmin.requireNotLastAdmin(accountId, userId);
    AppUser user = lockAndRecheck(accountId, userId);
    requireNotDeprovisioned(user);
    if (user.status() == UserStatus.DISABLED) {
      return UserView.of(user);
    }
    setStatus(accountId, userId, UserStatus.DISABLED);
    invalidateTokens(userId);
    revocations.revokeUsers(List.of(userId), "user.disabled");
    return UserView.of(load(accountId, userId));
  }

  /** DISABLED → ACTIVE, or INVITED when the user never set a password; no-op for ACTIVE/INVITED users. */
  @RetryOnDeadlock
  @Transactional
  public UserView enable(UUID accountId, UUID userId) {
    load(accountId, userId);
    AppUser user = lockAndRecheck(accountId, userId);
    requireNotDeprovisioned(user);
    if (user.status() != UserStatus.DISABLED) {
      return UserView.of(user);
    }
    setStatus(accountId, userId, user.passwordHash() == null ? UserStatus.INVITED : UserStatus.ACTIVE);
    return UserView.of(load(accountId, userId));
  }

  /**
   * I9: → DEPROVISIONED (I7 checked first). Deletes all role assignments and every membership except the primary,
   * invalidates outstanding tokens, keeps the row and email, and revokes. No-op when already deprovisioned.
   */
  @RetryOnDeadlock
  @Transactional
  public UserView deprovision(UUID accountId, UUID userId) {
    AppUser user = load(accountId, userId);
    if (user.status() == UserStatus.DEPROVISIONED) {
      return UserView.of(user);
    }
    lastAdmin.requireNotLastAdmin(accountId, userId); // advisory lock first (LastAdminService contract)
    if (lockAndRecheck(accountId, userId).status() == UserStatus.DEPROVISIONED) {
      return UserView.of(load(accountId, userId));
    }
    setStatus(accountId, userId, UserStatus.DEPROVISIONED);
    // Memberships before assignments: an in-flight TENANT-scope assign holds its membership FOR SHARE, so these
    // statements wait for it to commit and the assignment delete below then removes what it inserted. Afterwards the
    // only membership left (the primary) is SUSPENDED, so later TENANT-scope assigns fail on I1.
    jdbc.sql("""
            UPDATE user_tenant_membership m SET status = 'SUSPENDED' FROM app_user u
            WHERE m.app_user = u.id AND u.id = :id AND m.tenant_id = u.primary_tenant_id AND m.status <> 'SUSPENDED'""")
        .param("id", userId).update();
    jdbc.sql("""
            DELETE FROM user_tenant_membership m USING app_user u
            WHERE m.app_user = u.id AND u.id = :id AND m.tenant_id <> u.primary_tenant_id""")
        .param("id", userId).update();
    jdbc.sql("DELETE FROM role_assignment WHERE user_id = :id").param("id", userId).update();
    invalidateTokens(userId);
    revocations.revokeUsers(List.of(userId), "user.deprovisioned");
    return UserView.of(load(accountId, userId));
  }

  /**
   * Ruling R38: clears the user's lockout ({@code failed_logins}, {@code locked_until}) through
   * {@link UserCredentialService#unlock} and writes {@value #ACTION_UNLOCKED} (metadata {@code was_locked}). Callers
   * check R28 first ({@link #requireManageable}).
   */
  @RetryOnDeadlock
  @Transactional
  public UserView unlock(UUID accountId, UUID userId) {
    AppUser user = load(accountId, userId);
    boolean wasLocked = credentials.unlock(accountId, userId);
    audit.write(AuditEvent.forCurrentActor(ACTION_UNLOCKED).affecting(accountId, user.primaryTenant()) // C1
        .target("app_user", userId.toString())
        .metadata("was_locked", wasLocked).build());
    return UserView.of(load(accountId, userId));
  }

  // ---------------------------------------------------------------------------------------------- internals

  private AppUser load(UUID accountId, UUID userId) {
    return users.findByIdInAccount(userId, accountId).orElseThrow(UserAdminService::notFound);
  }

  private void setStatus(UUID accountId, UUID userId, UserStatus status) {
    jdbc.sql("""
            UPDATE app_user SET status = :status, version = version + 1, updated_at = :now
            WHERE id = :id AND account_id = :account""")
        .param("status", status.name()).param("now", now()).param("id", userId).param("account", accountId)
        .update();
  }

  private void invalidateTokens(UUID userId) {
    for (TokenPurpose purpose : TokenPurpose.values()) {
      tokens.invalidateOutstanding(userId, purpose);
    }
  }

  private static void requireNotDeprovisioned(AppUser user) {
    if (user.status() == UserStatus.DEPROVISIONED) {
      throw new ConflictException("user_deprovisioned", "The user is deprovisioned");
    }
  }

  private OffsetDateTime now() {
    return OffsetDateTime.ofInstant(clock.instant(), ZoneOffset.UTC);
  }

  private static NotFoundException notFound() {
    return new NotFoundException("user_not_found", "User not found");
  }
}
