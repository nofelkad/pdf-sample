package com.acme.iam.user;

import com.acme.iam.account.AccountService;
import com.acme.iam.assignment.AssignCommand;
import com.acme.iam.assignment.AssignmentService;
import com.acme.iam.assignment.ScopeType;
import com.acme.iam.common.RequestActor;
import com.acme.iam.common.error.ConflictException;
import com.acme.iam.common.error.NotFoundException;
import com.acme.iam.tenant.Tenant;
import com.acme.iam.tenant.TenantService;
import com.fasterxml.jackson.annotation.JsonInclude;
import java.time.Clock;
import java.time.Duration;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import org.springframework.jdbc.core.simple.JdbcClient;
import org.springframework.lang.Nullable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.support.TransactionSynchronization;
import org.springframework.transaction.support.TransactionSynchronizationManager;

/**
 * Invitations (P1-8.2): an INVITED user with an ACTIVE membership in the inviting tenant (its primary tenant), the
 * optional role assignments and a single-use INVITE token valid {@link #INVITE_TTL}, all in one transaction. The
 * invitation email is handed to {@link InvitationMailer} only <b>after commit</b>, so a rollback never emails, and is
 * sent off the request thread (final review I2: a slow mail server never holds the request or its DB connection).
 *
 * <p>Invitations "expire" with their token: Task 4's {@code /auth/invitations/accept} consumes it through
 * {@link UserTokenService#consume}. {@link #resend} invalidates every outstanding INVITE token and issues a new one.
 */
@Service
public class InvitationService {

  public static final Duration INVITE_TTL = Duration.ofDays(7);

  /**
   * A role to assign with the invitation.
   *
   * @param scopeId {@code null} means the inviting tenant (TENANT scope) or the account (ACCOUNT scope)
   */
  public record RoleGrant(UUID roleId, ScopeType scopeType, @Nullable UUID scopeId, @Nullable Instant expiresAt) {}

  /** A freshly created INVITED user and its INVITE token (raw value: send it, never store or log it). */
  public record InvitedUser(AppUser user, IssuedToken token) {}

  /** {@code activation} is absent when {@code iam.notification.expose-activation-link=false} (R46). */
  @JsonInclude(JsonInclude.Include.NON_NULL)
  public record InvitationResult(UserView user, Instant invitationExpiresAt, List<UUID> assignmentIds,
                                 @Nullable Activation activation) {}

  /** An invitation email to send after commit. {@link #toString()} hides the token. */
  public record PendingInvitation(String email, String accountName, String rawToken) {
    @Override
    public String toString() {
      return "PendingInvitation[email=" + email + ", accountName=" + accountName + "]";
    }
  }

  private final AppUserRepository users;
  private final TenantService tenants;
  private final AccountService accounts;
  private final AssignmentService assignments;
  private final UserTokenService tokens;
  private final InvitationMailer mailer;
  private final JdbcClient jdbc;
  private final Clock clock;
  private final ActivationLinks activationLinks;

  public InvitationService(AppUserRepository users, TenantService tenants, AccountService accounts,
      AssignmentService assignments, UserTokenService tokens, InvitationMailer mailer, JdbcClient jdbc,
      Clock clock, ActivationLinks activationLinks) {
    this.users = users;
    this.tenants = tenants;
    this.accounts = accounts;
    this.assignments = assignments;
    this.tokens = tokens;
    this.mailer = mailer;
    this.jdbc = jdbc;
    this.clock = clock;
    this.activationLinks = activationLinks;
  }

  /**
   * Invites a user into {@code tenantId} on behalf of the current actor. Each role goes through
   * {@link AssignmentService#assign} (I1, I3, I6, I8); any failure rolls the whole invitation back.
   *
   * @throws NotFoundException {@code tenant_not_found}
   * @throws ConflictException {@code tenant_not_active}, {@code user_exists}
   */
  @Transactional
  public InvitationResult invite(UUID accountId, UUID tenantId, String email, @Nullable String displayName,
      List<RoleGrant> roles) {
    InvitedUser invited = createInvitedUser(accountId, tenantId, email, displayName,
        RequestActor.current().userUuid());
    List<UUID> assignmentIds = new ArrayList<>();
    for (RoleGrant grant : roles) {
      UUID scopeId = grant.scopeId() != null ? grant.scopeId()
          : grant.scopeType() == ScopeType.TENANT ? tenantId : accountId;
      assignmentIds.add(assignments.assign(
          new AssignCommand(invited.user().id(), grant.roleId(), grant.scopeType(), scopeId, grant.expiresAt())).id());
    }
    notifyAfterCommit(List.of(new PendingInvitation(invited.user().email(), accounts.getById(accountId).name(),
        invited.token().rawToken())));
    Activation activation = activationLinks.issue(invited.token(), accountId, tenantId, invited.user().id(),
        ActivationLinks.Via.INVITE);
    return new InvitationResult(UserView.of(invited.user()), invited.token().expiresAt(), assignmentIds, activation);
  }

  /**
   * Re-sends the invitation of an INVITED user: every outstanding INVITE token is invalidated and a new one (valid
   * {@link #INVITE_TTL}) is emailed after commit.
   *
   * @throws NotFoundException {@code user_not_found} (also for users of another account, I10)
   * @throws ConflictException {@code not_invited} when the user is not INVITED
   */
  @Transactional
  public InvitationResult resend(UUID accountId, UUID userId) {
    return resend(accountId, userId, ActivationLinks.Via.RESEND);
  }

  /**
   * As {@link #resend(UUID, UUID)}, recording {@code via} on the activation-link audit event (admin recovery re-sends
   * through here, R46). A customer re-send ({@link ActivationLinks.Via#RESEND}) returns the link only when the caller
   * holds every role of the invitee ({@link AssignmentService#holdsEveryRoleOf}); otherwise only the email goes out.
   */
  @Transactional
  public InvitationResult resend(UUID accountId, UUID userId, ActivationLinks.Via via) {
    // serialise concurrent re-sends of the same user, so exactly one token stays usable
    jdbc.sql("SELECT 1 FROM app_user WHERE id = :id AND account_id = :a FOR NO KEY UPDATE")
        .param("id", userId).param("a", accountId).query(Integer.class).optional();
    AppUser user = users.findByIdInAccount(userId, accountId)
        .orElseThrow(() -> new NotFoundException("user_not_found", "User not found"));
    if (user.status() != UserStatus.INVITED) {
      throw new ConflictException("not_invited", "Only invited users can be sent a new invitation");
    }
    tokens.invalidateOutstanding(userId, TokenPurpose.INVITE);
    IssuedToken token = tokens.issue(userId, TokenPurpose.INVITE, INVITE_TTL, RequestActor.current().userUuid());
    notifyAfterCommit(List.of(new PendingInvitation(user.email(), accounts.getById(accountId).name(),
        token.rawToken())));
    UUID caller = RequestActor.current().userUuid();
    boolean callerMayActivate = via != ActivationLinks.Via.RESEND
        || (caller != null && assignments.holdsEveryRoleOf(caller, accountId, userId));
    Activation activation = callerMayActivate
        ? activationLinks.issue(token, accountId, user.primaryTenant(), userId, via) : null;
    return new InvitationResult(UserView.of(user), token.expiresAt(), List.of(), activation);
  }

  /**
   * Creates an INVITED user with an ACTIVE primary membership in {@code tenantId} and issues its INVITE token. Sends
   * nothing: the caller schedules the email ({@link #notifyAfterCommit}) or, for the bootstrap CLI, prints the link.
   *
   * @param createdBy recorded as the token's {@code created_by}; {@code null} for system flows
   * @throws NotFoundException {@code tenant_not_found} when the tenant is unknown or of another account
   * @throws ConflictException {@code tenant_not_active}; {@code user_exists} when the email is taken in the account
   */
  @Transactional
  public InvitedUser createInvitedUser(UUID accountId, UUID tenantId, String email, @Nullable String displayName,
      @Nullable UUID createdBy) {
    String normalized = email.trim();
    Tenant tenant = tenants.findByIdInAccount(tenantId, accountId)
        .orElseThrow(() -> new NotFoundException("tenant_not_found", "Tenant not found"));
    if (!tenant.isActive()) {
      throw new ConflictException("tenant_not_active", "The tenant is " + tenant.status());
    }
    if (users.findByAccountAndEmail(accountId, normalized).isPresent()) {
      throw new ConflictException("user_exists", "A user with this email already exists in the account");
    }
    AppUser saved = users.save(AppUser.invite(accountId, tenantId, normalized, blankToNull(displayName),
        clock.instant()));
    IssuedToken token = tokens.issue(saved.id(), TokenPurpose.INVITE, INVITE_TTL, createdBy);
    return new InvitedUser(saved, token);
  }

  /**
   * Queues the invitations on {@link InvitationMailer} once the current transaction commits (immediately when no
   * transaction is active) and returns at once. Delivery happens on the mailer's own threads; failures, timeouts and
   * drops are counted and logged (without the token) and never affect the committed data.
   */
  public void notifyAfterCommit(List<PendingInvitation> invitations) {
    if (invitations.isEmpty()) {
      return;
    }
    List<PendingInvitation> batch = List.copyOf(invitations);
    if (TransactionSynchronizationManager.isSynchronizationActive()) {
      TransactionSynchronizationManager.registerSynchronization(new TransactionSynchronization() {
        @Override
        public void afterCommit() {
          mailer.submit(batch);
        }
      });
    } else {
      mailer.submit(batch);
    }
  }

  @Nullable
  private static String blankToNull(@Nullable String value) {
    return value == null || value.isBlank() ? null : value.trim();
  }
}
