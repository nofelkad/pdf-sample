package com.acme.iam.user;

import java.time.Instant;
import java.util.UUID;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.Id;
import org.springframework.data.jdbc.core.mapping.AggregateReference;
import org.springframework.data.relational.core.mapping.Table;
import org.springframework.lang.Nullable;

/**
 * Single-use invitation / password-reset token ({@code user_token}). Only the SHA-256 of the raw token is stored; see
 * {@link UserTokenService} for the hashing rule. The table has no {@code version} column, so "new" means
 * {@code id == null}.
 */
@Table("user_token")
public record UserToken(
    @Id UUID id,
    AggregateReference<AppUser, UUID> userId,
    TokenPurpose purpose,
    byte[] tokenHash,
    Instant expiresAt,
    @Nullable Instant usedAt,
    @Nullable AggregateReference<AppUser, UUID> createdBy,
    @CreatedDate Instant createdAt) {

  public static UserToken create(UUID userId, TokenPurpose purpose, byte[] tokenHash, Instant expiresAt,
      @Nullable UUID createdBy) {
    return new UserToken(null, AggregateReference.to(userId), purpose, tokenHash.clone(), expiresAt, null,
        createdBy == null ? null : AggregateReference.to(createdBy), null);
  }

  /** The user the token belongs to (never {@code null}). */
  public UUID user() {
    return userId.getId();
  }

  public boolean isUsable(Instant now) {
    return usedAt == null && expiresAt.isAfter(now);
  }
}
