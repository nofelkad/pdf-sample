package com.acme.iam.common;

import java.util.UUID;
import org.slf4j.MDC;
import org.springframework.lang.Nullable;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.security.oauth2.server.resource.authentication.JwtAuthenticationToken;

/**
 * Who is acting in the current request or job, as seen by the audit trigger and {@code AuditWriter}.
 *
 * <p>Ids are UUID strings or {@code null}. A JWT claim that is not a UUID (for example an application client's
 * {@code sub = "app:<clientId>"}) is treated as absent, because the audit trigger casts these values to {@code uuid}.
 * When no user is known the actor is SYSTEM ({@link #isSystem()}).
 *
 * @param userId JWT {@code sub}
 * @param accountId JWT {@code acc}
 * @param tenantId JWT {@code tid}
 * @param requestId MDC {@code requestId} set by {@code RequestIdFilter}
 * @param sessionId JWT {@code sid}
 */
public record RequestActor(
    @Nullable String userId,
    @Nullable String accountId,
    @Nullable String tenantId,
    @Nullable String requestId,
    @Nullable String sessionId) {

  /** MDC key holding the current request id. */
  public static final String MDC_REQUEST_ID = "requestId";

  public static final String CLAIM_SUBJECT = "sub";
  public static final String CLAIM_ACCOUNT = "acc";
  public static final String CLAIM_TENANT = "tid";
  public static final String CLAIM_SESSION = "sid";

  /** The actor of the current thread: JWT claims from the SecurityContext (if any) plus the MDC request id. */
  public static RequestActor current() {
    String requestId = MDC.get(MDC_REQUEST_ID);
    Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
    if (authentication instanceof JwtAuthenticationToken token) {
      Jwt jwt = token.getToken();
      return new RequestActor(
          uuidOrNull(jwt.getSubject()),
          uuidOrNull(jwt.getClaimAsString(CLAIM_ACCOUNT)),
          uuidOrNull(jwt.getClaimAsString(CLAIM_TENANT)),
          requestId,
          uuidOrNull(jwt.getClaimAsString(CLAIM_SESSION)));
    }
    return new RequestActor(null, null, null, requestId, null);
  }

  /** {@code true} when no user is acting (scheduled jobs, bootstrap, application clients, anonymous calls). */
  public boolean isSystem() {
    return userId == null;
  }

  @Nullable
  public UUID userUuid() {
    return userId == null ? null : UUID.fromString(userId);
  }

  @Nullable
  public UUID accountUuid() {
    return accountId == null ? null : UUID.fromString(accountId);
  }

  @Nullable
  public UUID tenantUuid() {
    return tenantId == null ? null : UUID.fromString(tenantId);
  }

  @Nullable
  public UUID sessionUuid() {
    return sessionId == null ? null : UUID.fromString(sessionId);
  }

  @Nullable
  private static String uuidOrNull(@Nullable String value) {
    if (value == null || value.isBlank()) {
      return null;
    }
    try {
      return UUID.fromString(value).toString();
    } catch (IllegalArgumentException e) {
      return null;
    }
  }
}
