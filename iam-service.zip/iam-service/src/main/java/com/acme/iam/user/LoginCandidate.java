package com.acme.iam.user;

import java.time.Instant;
import java.util.UUID;
import org.springframework.lang.Nullable;

/**
 * An ACTIVE user a login attempt may refer to (spec section 4 step 2), with what the login flow needs to verify the
 * password and to offer an account choice. {@link #toString()} omits the password hash.
 */
public record LoginCandidate(
    UUID userId,
    UUID accountId,
    String email,
    String accountSlug,
    String accountName,
    UUID primaryTenantId,
    @Nullable String passwordHash,
    @Nullable Instant lockedUntil) {

  public boolean isLocked(Instant now) {
    return lockedUntil != null && lockedUntil.isAfter(now);
  }

  @Override
  public String toString() {
    return "LoginCandidate[userId=" + userId + ", accountId=" + accountId + ", accountSlug=" + accountSlug
        + ", lockedUntil=" + lockedUntil + "]";
  }
}
