package com.acme.iam.product;

/**
 * Outcome of {@link RegistryService#apply}; also the JSON body of {@code PUT /internal/products/{code}/manifest}.
 *
 * @param changed {@code false} when the manifest was already applied and nothing was written
 * @param permissionsAdded new permissions
 * @param permissionsUpdated existing permissions whose kind, description or flags changed, or that were un-deprecated
 * @param permissionsDeprecated permissions that are no longer in the manifest
 * @param rolesChanged SYSTEM roles created or whose permission set changed
 */
public record ApplyResult(
    String product,
    boolean changed,
    int permissionsAdded,
    int permissionsUpdated,
    int permissionsDeprecated,
    int rolesChanged) {}
