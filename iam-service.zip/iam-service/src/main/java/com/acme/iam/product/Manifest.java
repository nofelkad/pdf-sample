package com.acme.iam.product;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.List;
import org.springframework.lang.Nullable;

/**
 * A product manifest (P1-7.1): the permissions a product defines and its SYSTEM roles. The same field names are used
 * by {@code iam-manifest.yaml}, by the {@code PUT /internal/products/{code}/manifest} JSON body and by
 * {@code docs/manifest-format.md}. Unknown fields are rejected, so a typo fails loudly instead of silently dropping a
 * section. Parse with {@link ManifestParser}; check with {@link ManifestValidator}.
 *
 * @param product product code, e.g. {@code BILLING}
 * @param name display name; optional. A new product defaults to its code, an existing one keeps its name when absent.
 * @param permissions the product's complete permission catalogue; a permission missing here is deprecated
 * @param systemRoles the product's SYSTEM roles; each is rebuilt to exactly its expanded permission set
 */
@JsonIgnoreProperties(ignoreUnknown = false)
public record Manifest(
    @Nullable String product,
    @Nullable String name,
    List<ManifestPermission> permissions,
    @JsonProperty("system_roles") List<ManifestRole> systemRoles) {

  public Manifest {
    permissions = permissions == null ? List.of() : List.copyOf(permissions);
    systemRoles = systemRoles == null ? List.of() : List.copyOf(systemRoles);
  }

  /**
   * One permission.
   *
   * @param kind {@code FEATURE} or {@code DATA}; kept as text so an unknown kind is reported as a violation
   * @param sensitive Phase 2 approval workflow marker (default {@code false})
   * @param auditRead reads of this permission must be audited (default {@code false})
   */
  @JsonIgnoreProperties(ignoreUnknown = false)
  public record ManifestPermission(
      @Nullable String code,
      @Nullable String kind,
      @Nullable String description,
      boolean sensitive,
      @JsonProperty("audit_read") boolean auditRead) {}

  /**
   * One SYSTEM role.
   *
   * @param permissions exact permission codes or prefix wildcards ending in {@code .*}
   * @param exclude removed from the expansion; same syntax
   */
  @JsonIgnoreProperties(ignoreUnknown = false)
  public record ManifestRole(@Nullable String name, List<String> permissions, List<String> exclude) {

    public ManifestRole {
      permissions = permissions == null ? List.of() : List.copyOf(permissions);
      exclude = exclude == null ? List.of() : List.copyOf(exclude);
    }
  }
}
