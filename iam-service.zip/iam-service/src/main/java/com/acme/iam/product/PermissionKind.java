package com.acme.iam.product;

/** {@code permission.kind}: FEATURE gates an action, DATA scopes a read ({@code .own/.tenant/.account}). */
public enum PermissionKind {
  FEATURE,
  DATA
}
