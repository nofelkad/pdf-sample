package com.acme.iam.auth;

import com.acme.iam.common.error.GlobalExceptionHandler;
import com.acme.iam.common.security.CurrentUser;
import com.acme.iam.common.web.RequestIdFilter;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import java.util.UUID;
import org.springframework.http.CacheControl;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ProblemDetail;
import org.springframework.http.ResponseEntity;
import org.springframework.lang.Nullable;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

/**
 * The {@code /auth} endpoints of spec section 4 (P1-5.2 – P1-5.8). Public except logout, logout-all, switch-tenant
 * and password change, which need a valid access token ({@code SecurityConfig.AUTH_AUTHENTICATED_PATHS}). Token
 * responses carry {@code Cache-Control: no-store}. Rate-limited endpoints answer 429 {@code rate_limited} with
 * {@code Retry-After} (seconds). All errors are RFC 7807 with a {@code code}; see {@link AuthErrors}.
 */
@RestController
public class AuthController {

  static final int MAX_PASSWORD = 1024;
  static final int MAX_TOKEN = 512;

  public record LoginRequest(@NotBlank @Size(max = 320) String email,
                             @NotBlank @Size(max = MAX_PASSWORD) String password,
                             @Nullable @Size(max = 255) String account) {
    @Override
    public String toString() {
      return "LoginRequest[email=" + email + ", account=" + account + "]";
    }
  }

  public record RefreshRequest(@NotBlank @Size(max = MAX_TOKEN) String refreshToken) {
    @Override
    public String toString() {
      return "RefreshRequest[]";
    }
  }

  public record SwitchTenantRequest(@NotNull UUID tenantId) {}

  public record ForgotPasswordRequest(@NotBlank @Size(max = 320) String email,
                                      @Nullable @Size(max = 255) String account) {}

  public record ResetPasswordRequest(@NotBlank @Size(max = MAX_TOKEN) String token,
                                     @NotBlank @Size(max = MAX_PASSWORD) String password) {
    @Override
    public String toString() {
      return "ResetPasswordRequest[]";
    }
  }

  public record ChangePasswordRequest(@NotBlank @Size(max = MAX_PASSWORD) String currentPassword,
                                      @NotBlank @Size(max = MAX_PASSWORD) String newPassword) {
    @Override
    public String toString() {
      return "ChangePasswordRequest[]";
    }
  }

  public record AcceptInvitationRequest(@NotBlank @Size(max = MAX_TOKEN) String token,
                                        @NotBlank @Size(max = MAX_PASSWORD) String password,
                                        @Nullable @Size(max = 200) String displayName) {
    @Override
    public String toString() {
      return "AcceptInvitationRequest[displayName=" + displayName + "]";
    }
  }

  private final LoginService loginService;
  private final SessionService sessionService;
  private final PasswordFlowService passwordFlows;
  private final InvitationAcceptService invitations;
  private final AuthRateLimiter rateLimiter;
  private final ClientInfoResolver clientInfo;
  private final CurrentUser currentUser;

  public AuthController(LoginService loginService, SessionService sessionService, PasswordFlowService passwordFlows,
                        InvitationAcceptService invitations, AuthRateLimiter rateLimiter,
                        ClientInfoResolver clientInfo, CurrentUser currentUser) {
    this.loginService = loginService;
    this.sessionService = sessionService;
    this.passwordFlows = passwordFlows;
    this.invitations = invitations;
    this.rateLimiter = rateLimiter;
    this.clientInfo = clientInfo;
    this.currentUser = currentUser;
  }

  /** 200 tokens; 401 {@code invalid_credentials}; 409 {@code account_selection_required}; 429. */
  @PostMapping("/auth/login")
  public ResponseEntity<AuthTokens> login(@Valid @RequestBody LoginRequest body, HttpServletRequest request) {
    ClientInfo client = clientInfo.resolve(request);
    rateLimiter.check(AuthRateLimiter.Scope.LOGIN, client, body.email());
    return tokens(loginService.login(new LoginCommand(body.email(), body.password(), body.account()), client));
  }

  /** 200 tokens; 401 {@code invalid_refresh_token} / {@code session_invalid}; 429. */
  @PostMapping("/auth/refresh")
  public ResponseEntity<AuthTokens> refresh(@Valid @RequestBody RefreshRequest body, HttpServletRequest request) {
    ClientInfo client = clientInfo.resolve(request);
    rateLimiter.check(AuthRateLimiter.Scope.REFRESH, client, null);
    return tokens(sessionService.refresh(body.refreshToken(), client));
  }

  /** 200 tokens; 401 {@code session_invalid}; 403 {@code tenant_not_accessible}. */
  @PostMapping("/auth/switch-tenant")
  public ResponseEntity<AuthTokens> switchTenant(@Valid @RequestBody SwitchTenantRequest body,
                                                 HttpServletRequest request) {
    return tokens(sessionService.switchTenant(Caller.of(currentUser), body.tenantId(), clientInfo.resolve(request)));
  }

  /** 204. */
  @PostMapping("/auth/logout")
  public ResponseEntity<Void> logout(HttpServletRequest request) {
    sessionService.logout(Caller.of(currentUser), clientInfo.resolve(request));
    return ResponseEntity.noContent().build();
  }

  /** 204. */
  @PostMapping("/auth/logout-all")
  public ResponseEntity<Void> logoutAll(HttpServletRequest request) {
    sessionService.logoutAll(Caller.of(currentUser), clientInfo.resolve(request));
    return ResponseEntity.noContent().build();
  }

  /** Always 202 (unless rate-limited: 429). */
  @PostMapping("/auth/password/forgot")
  public ResponseEntity<Void> forgot(@Valid @RequestBody ForgotPasswordRequest body, HttpServletRequest request) {
    ClientInfo client = clientInfo.resolve(request);
    rateLimiter.check(AuthRateLimiter.Scope.FORGOT, client, body.email());
    passwordFlows.forgot(body.email(), body.account(), client);
    return ResponseEntity.accepted().build();
  }

  /** 204; 400 {@code invalid_token} / {@code password_policy}; 429. */
  @PostMapping("/auth/password/reset")
  public ResponseEntity<Void> reset(@Valid @RequestBody ResetPasswordRequest body, HttpServletRequest request) {
    ClientInfo client = clientInfo.resolve(request);
    rateLimiter.check(AuthRateLimiter.Scope.RESET, client, null);
    passwordFlows.reset(body.token(), body.password(), client);
    return ResponseEntity.noContent().build();
  }

  /**
   * 200 fresh tokens; 400 {@code invalid_current_password} / {@code password_policy}; 401 {@code session_invalid}
   * (also when this attempt locked the user); 403 {@code account_locked}; 409 {@code concurrent_modification}; 429
   * (per user).
   */
  @PostMapping("/auth/password/change")
  public ResponseEntity<AuthTokens> change(@Valid @RequestBody ChangePasswordRequest body,
                                           HttpServletRequest request) {
    Caller caller = Caller.of(currentUser);
    ClientInfo client = clientInfo.resolve(request);
    rateLimiter.checkUser(AuthRateLimiter.Scope.PASSWORD_CHANGE, client, caller.userId());
    return tokens(passwordFlows.change(caller, body.currentPassword(), body.newPassword(), client));
  }

  /** 200 tokens; 400 {@code invalid_token} / {@code password_policy}; 403 {@code access_inactive}. */
  @PostMapping("/auth/invitations/accept")
  public ResponseEntity<AuthTokens> acceptInvitation(@Valid @RequestBody AcceptInvitationRequest body,
                                                     HttpServletRequest request) {
    return tokens(invitations.accept(body.token(), body.password(), body.displayName(), clientInfo.resolve(request)));
  }

  /** 429 with {@code Retry-After}; otherwise the same RFC 7807 body as {@code GlobalExceptionHandler}. */
  @ExceptionHandler(RateLimitedException.class)
  ResponseEntity<ProblemDetail> rateLimited(RateLimitedException ex, HttpServletRequest request) {
    ProblemDetail body = ProblemDetail.forStatusAndDetail(ex.status(), ex.detail());
    body.setProperty(GlobalExceptionHandler.CODE, ex.code());
    ex.properties().forEach(body::setProperty);
    String requestId = RequestIdFilter.currentRequestId(request);
    if (requestId != null) {
      body.setProperty(GlobalExceptionHandler.REQUEST_ID, requestId);
    }
    return ResponseEntity.status(ex.status())
        .header(HttpHeaders.RETRY_AFTER, Long.toString(ex.retryAfterSeconds()))
        .body(body);
  }

  private static ResponseEntity<AuthTokens> tokens(AuthTokens tokens) {
    return ResponseEntity.ok().cacheControl(CacheControl.noStore()).header(HttpHeaders.PRAGMA, "no-cache").body(tokens);
  }
}
