package com.acme.iam.auth;

import com.acme.iam.core.revocation.RevocationEntry;
import com.acme.iam.core.revocation.RevocationRegistry;
import java.time.Clock;
import java.time.Duration;
import java.time.Instant;
import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.SmartLifecycle;
import org.springframework.lang.Nullable;
import org.springframework.scheduling.concurrent.ThreadPoolTaskScheduler;
import org.springframework.stereotype.Component;

/**
 * IAM's own revocation poller (P1-10.2): every {@code iam.revocation.poll-interval} (2 s, ruling R41) on every instance (no
 * ShedLock) it reads new feed rows straight from the database through {@link RevocationService#since} and applies
 * them to the shared {@link RevocationRegistry} that {@code RevocationFilter} consults. The first poll starts from
 * {@code iam.revocation.startup-lookback} (20 min) ago. Registry entries older than {@code iam.revocation.retention}
 * (1 h, well beyond the 15 min token lifetime) are evicted.
 *
 * <p>Runs on its own single-thread scheduler ({@value #THREAD_NAME_PREFIX}*), not the shared {@code @Scheduled}
 * pool, so no other job (key rotation, purges, Wave 2 jobs) can delay revocation; started and stopped with the
 * application context ({@link SmartLifecycle}).
 */
@Component
public class RevocationPoller implements SmartLifecycle {

  public static final String THREAD_NAME_PREFIX = "revocation-poller-";
  static final int PAGE_SIZE = 1000;
  private static final Logger log = LoggerFactory.getLogger(RevocationPoller.class);

  private final RevocationService revocations;
  private final RevocationRegistry registry;
  private final Clock clock;
  private final Duration pollInterval;
  private final Duration startupLookback;
  private final Duration retention;
  private boolean started;
  private volatile ThreadPoolTaskScheduler scheduler;
  private volatile String lastScheduledThreadName = "";
  private volatile Instant lastSuccessfulPoll;

  public RevocationPoller(RevocationService revocations, RevocationRegistry registry, Clock clock,
                          @Value("${iam.revocation.poll-interval:PT2S}") Duration pollInterval,
                          @Value("${iam.revocation.startup-lookback:PT20M}") Duration startupLookback,
                          @Value("${iam.revocation.retention:PT1H}") Duration retention) {
    this.revocations = revocations;
    this.registry = registry;
    this.clock = clock;
    this.pollInterval = pollInterval;
    this.startupLookback = startupLookback;
    this.retention = retention;
  }

  /**
   * Reads every feed row after the registry's cursor and applies it. Tests call this directly instead of waiting.
   *
   * @return number of rows applied
   */
  public synchronized int poll() {
    if (!started) {
      registry.advanceCursor(revocations.startCursor(startupLookback));
      started = true;
    }
    int applied = 0;
    List<RevocationEntry> page;
    do {
      page = revocations.since(registry.lastCursor(), PAGE_SIZE);
      registry.apply(page);
      applied += page.size();
    } while (page.size() == PAGE_SIZE);
    registry.evictOlderThan(clock.instant().minus(retention));
    lastSuccessfulPoll = clock.instant();
    return applied;
  }

  /**
   * When a poll last completed (startup window or cursor and every page applied); {@code null} before the first.
   * Readiness ({@code RevocationFreshnessHealthIndicator}) is NOT_READY until then: a failed startup poll is logged and
   * retried, and the instance takes no traffic in the meantime.
   */
  @Nullable
  public Instant lastSuccessfulPoll() {
    return lastSuccessfulPoll;
  }

  /** Name of the thread that ran the last scheduled poll (diagnostics/tests). */
  String lastScheduledThreadName() {
    return lastScheduledThreadName;
  }

  void scheduledPoll() {
    lastScheduledThreadName = Thread.currentThread().getName();
    try {
      poll();
    } catch (RuntimeException e) {
      log.warn("Revocation poll failed; retrying on the next tick", e);
    }
  }

  @Override
  public synchronized void start() {
    if (scheduler != null) {
      return;
    }
    ThreadPoolTaskScheduler own = new ThreadPoolTaskScheduler();
    own.setPoolSize(1);
    own.setThreadNamePrefix(THREAD_NAME_PREFIX);
    own.setDaemon(true);
    own.setWaitForTasksToCompleteOnShutdown(false);
    own.initialize();
    // Task 9: load the startup window before the web server accepts requests (see getPhase), so a restarted instance
    // rejects tokens revoked before it started from its first request; a failure here is retried by the schedule
    scheduledPoll();
    own.scheduleWithFixedDelay(this::scheduledPoll, clock.instant().plus(pollInterval), pollInterval);
    scheduler = own;
  }

  /** Starts before the web server ({@code Integer.MAX_VALUE - 1}) like the iam-client poller. */
  @Override
  public int getPhase() {
    return Integer.MAX_VALUE - 1000;
  }

  @Override
  public synchronized void stop() {
    if (scheduler != null) {
      scheduler.shutdown();
      scheduler = null;
    }
  }

  @Override
  public boolean isRunning() {
    return scheduler != null;
  }
}
