package com.acme.iam.common.jdbc;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * Re-runs the whole annotated transactional service method when PostgreSQL aborts its transaction with a deadlock
 * ({@code 40P01}) or a serialization failure ({@code 40001}): at most {@link DeadlockRetryAspect#MAX_ATTEMPTS}
 * attempts with jittered exponential backoff ({@link DeadlockRetryAspect}).
 *
 * <p>Put it next to {@code @Transactional} on <b>service entry points</b> only (methods called from controllers or
 * jobs). The aspect runs outside the transaction interceptor, so each attempt is a fresh transaction. When a
 * transaction is already active on entry (the method was called from another transactional method), the aspect does
 * nothing: a deadlock aborts the outer transaction too, so only the outermost entry point may retry.
 *
 * <p>The method must not have side effects outside the database that a retry would repeat (mail is sent after commit,
 * revocation is part of the transaction).
 */
@Target(ElementType.METHOD)
@Retention(RetentionPolicy.RUNTIME)
@Documented
public @interface RetryOnDeadlock {
}
