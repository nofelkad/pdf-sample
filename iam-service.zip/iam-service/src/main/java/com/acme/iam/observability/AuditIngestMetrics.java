package com.acme.iam.observability;

import com.acme.iam.audit.IngestResult;
import com.fasterxml.jackson.databind.JsonNode;
import io.micrometer.core.instrument.DistributionSummary;
import io.micrometer.core.instrument.MeterRegistry;
import java.time.Clock;
import java.time.DateTimeException;
import java.time.Instant;
import java.time.format.DateTimeFormatter;
import java.util.HashSet;
import java.util.Set;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.stereotype.Component;

/**
 * Audit ingest lag (P1-11.5): for every event of a {@code POST /internal/audit/events} batch that was not rejected,
 * {@code received - occurredAt} in seconds, as the distribution summary {@value MetricNames#AUDIT_INGEST_LAG}.
 * "received" is the time the batch reached {@code AuditIngestService.ingest}, within milliseconds of the
 * {@code received_at} column. Duplicates (a retried batch) count too: the lag is how late the event arrived.
 *
 * <p>A growing p95 means iam-client relays are backing up (IAM outage, or an outbox that cannot drain); see the
 * {@code iam.client.audit.outbox.*} gauges on the application side.
 */
@Aspect
@Component
public class AuditIngestMetrics {

  private final Clock clock;
  private final DistributionSummary lag;

  public AuditIngestMetrics(MeterRegistry registry, Clock clock) {
    this.clock = clock;
    this.lag = DistributionSummary.builder(MetricNames.AUDIT_INGEST_LAG)
        .description("Ingested audit events: received_at minus occurred_at")
        .baseUnit("seconds")
        .publishPercentiles(MetricNames.PERCENTILES)
        .register(registry);
  }

  @Around("execution(* com.acme.iam.audit.AuditIngestService.ingest(..)) && args(source, body)")
  public Object recordLag(ProceedingJoinPoint joinPoint, String source, JsonNode body) throws Throwable {
    Instant received = clock.instant();
    Object result = joinPoint.proceed();
    try {
      if (result instanceof IngestResult ingested && body != null && body.get("events") != null) {
        Set<Integer> rejected = new HashSet<>();
        ingested.rejected().forEach(r -> rejected.add(r.index()));
        int index = 0;
        for (JsonNode event : body.get("events")) {
          Instant occurredAt = rejected.contains(index++) ? null : occurredAt(event);
          if (occurredAt != null) {
            lag.record(Math.max(0, (received.toEpochMilli() - occurredAt.toEpochMilli()) / 1000.0));
          }
        }
      }
    } catch (RuntimeException e) {
      // metrics must never fail an ingest
    }
    return result;
  }

  private static Instant occurredAt(JsonNode event) {
    JsonNode value = event.get("occurredAt");
    if (value == null || !value.isTextual()) {
      return null;
    }
    try {
      return DateTimeFormatter.ISO_OFFSET_DATE_TIME.parse(value.asText(), Instant::from);
    } catch (DateTimeException e) {
      return null;
    }
  }
}
