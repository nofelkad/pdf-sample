package com.acme.iam.common.security;

import com.acme.iam.common.error.GlobalExceptionHandler;
import com.acme.iam.common.web.RequestIdFilter;
import com.fasterxml.jackson.databind.ObjectMapper;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.LinkedHashMap;
import java.util.Map;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;

/**
 * Writes RFC 7807 bodies from the security filter chain (entry point, access-denied handler, revocation filter), with
 * the same members as {@link GlobalExceptionHandler}: {@code type, title, status, detail, instance, code, requestId}.
 */
@Component
public class SecurityProblemWriter {

  private final ObjectMapper objectMapper;

  public SecurityProblemWriter(ObjectMapper objectMapper) {
    this.objectMapper = objectMapper;
  }

  public void write(HttpServletRequest request, HttpServletResponse response, HttpStatus status, String code,
                    String detail) throws IOException {
    Map<String, Object> body = new LinkedHashMap<>();
    body.put("type", "about:blank");
    body.put("title", status.getReasonPhrase());
    body.put("status", status.value());
    body.put("detail", detail);
    body.put("instance", request.getRequestURI());
    body.put(GlobalExceptionHandler.CODE, code);
    String requestId = RequestIdFilter.currentRequestId(request);
    if (requestId != null) {
      body.put(GlobalExceptionHandler.REQUEST_ID, requestId);
    }
    response.setStatus(status.value());
    response.setContentType(MediaType.APPLICATION_PROBLEM_JSON_VALUE);
    response.setCharacterEncoding("UTF-8");
    objectMapper.writeValue(response.getOutputStream(), body);
  }
}
