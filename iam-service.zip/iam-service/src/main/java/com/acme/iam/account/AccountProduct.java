package com.acme.iam.account;

import java.time.LocalDate;
import java.util.Objects;
import java.util.UUID;
import org.springframework.data.relational.core.mapping.Table;
import org.springframework.lang.Nullable;

/**
 * A product subscription of an account ({@code account_product}), owned by {@link Account}. The back-reference column
 * {@code account} is managed by Spring Data JDBC.
 *
 * @param productId the subscribed product
 * @param status subscription status
 * @param startsAt first day of the subscription
 * @param endsAt last day (inclusive) or {@code null} for open-ended
 */
@Table("account_product")
public record AccountProduct(UUID productId, SubscriptionStatus status, LocalDate startsAt, @Nullable LocalDate endsAt) {

  public AccountProduct {
    Objects.requireNonNull(productId, "productId");
    Objects.requireNonNull(status, "status");
    Objects.requireNonNull(startsAt, "startsAt");
  }
}
