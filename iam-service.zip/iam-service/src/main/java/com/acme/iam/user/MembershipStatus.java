package com.acme.iam.user;

/** {@code user_tenant_membership.status}. */
public enum MembershipStatus {
  ACTIVE,
  SUSPENDED
}
