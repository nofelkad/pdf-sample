package com.acme.iam.auth;

import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.util.List;
import java.util.UUID;
import org.springframework.jdbc.core.simple.JdbcClient;
import org.springframework.stereotype.Repository;

/** {@code password_history} access (no primary key, so plain SQL instead of a Spring Data repository). */
@Repository
public class PasswordHistoryRepository {

  private final JdbcClient jdbc;

  public PasswordHistoryRepository(JdbcClient jdbc) {
    this.jdbc = jdbc;
  }

  public void insert(PasswordHistory entry) {
    jdbc.sql("INSERT INTO password_history (user_id, password_hash, changed_at) VALUES (:userId, :hash, :changedAt)")
        .param("userId", entry.userId())
        .param("hash", entry.passwordHash())
        .param("changedAt", OffsetDateTime.ofInstant(entry.changedAt(), ZoneOffset.UTC))
        .update();
  }

  /** The user's most recent {@code limit} entries, newest first. */
  public List<PasswordHistory> findRecent(UUID userId, int limit) {
    return jdbc.sql("""
            SELECT user_id, password_hash, changed_at FROM password_history
            WHERE user_id = :userId ORDER BY changed_at DESC LIMIT :limit""")
        .param("userId", userId)
        .param("limit", limit)
        .query((rs, i) -> new PasswordHistory(
            rs.getObject("user_id", UUID.class),
            rs.getString("password_hash"),
            rs.getObject("changed_at", OffsetDateTime.class).toInstant()))
        .list();
  }

  /** Deletes all but the newest {@code keep} entries of the user; returns how many were deleted. */
  public int trim(UUID userId, int keep) {
    return jdbc.sql("""
            DELETE FROM password_history ph
            WHERE ph.user_id = :userId
              AND ph.ctid NOT IN (SELECT ctid FROM password_history
                                  WHERE user_id = :userId ORDER BY changed_at DESC LIMIT :keep)""")
        .param("userId", userId)
        .param("keep", keep)
        .update();
  }
}
