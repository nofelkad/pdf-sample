package com.acme.iam.auth;

import com.acme.iam.audit.AuditEvent.Outcome;
import io.github.bucket4j.Bandwidth;
import io.github.bucket4j.BucketConfiguration;
import io.github.bucket4j.ConsumptionProbe;
import io.github.bucket4j.distributed.proxy.ProxyManager;
import java.net.Inet6Address;
import java.net.InetAddress;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Arrays;
import java.util.HexFormat;
import java.util.Locale;
import java.util.UUID;
import java.util.regex.Pattern;
import org.springframework.lang.Nullable;
import org.springframework.stereotype.Component;

/**
 * Rate limits of the {@code /auth} endpoints (P1-5.7), shared by all instances through Bucket4j's PostgreSQL proxy
 * manager ({@code bucket} table, {@code SELECT … FOR UPDATE}). Limits ({@code iam.auth.rate-limit.*}) are
 * greedy-refill buckets per {@code window} (1 min):
 *
 * <ul>
 *   <li>login, forgot: {@code per-ip} (10) per client IP and {@code per-email} (5) per normalised (trimmed, lower-case)
 *       email;
 *   <li>reset: {@code per-ip} (the request carries no email);
 *   <li>refresh: {@code refresh-per-ip} (60);
 *   <li>password change: {@code change-per-user} (10) per user ({@link #checkUser}).
 * </ul>
 *
 * <p><b>Keys:</b> {@code <scope>:ip:<ip>}, {@code <scope>:email:<sha256-hex>} (no email is stored in the bucket
 * table) and {@code <scope>:user:<uuid>}. IPs are canonicalised (parsed, re-printed); IPv6 clients are bucketed per
 * {@code /64} ({@code <scope>:ip:<first 64 bits hex>/64}), since one host typically owns a whole /64. A request
 * without a usable client IP shares no IP bucket (the IP limit is skipped; the email limit still applies).
 *
 * <p>The IP bucket is consumed first; a request rejected by it does not consume the email bucket. A rejection raises
 * {@link RateLimitedException} with the seconds until a token is available and is audited
 * {@value AuthAuditService#RATE_LIMITED} (DENIED, email hint, never the password) only for the <em>first</em>
 * rejection of that bucket per window (a capacity-1 {@code audit:<key>} bucket), so a flood writes one row per window.
 *
 * <p>Call it outside any transaction: Bucket4j takes its own connection and commits.
 */
@Component
public class AuthRateLimiter {

  /** Which endpoint a request counts against. */
  public enum Scope {
    LOGIN("login", true), FORGOT("forgot", true), RESET("reset", false), REFRESH("refresh", false),
    PASSWORD_CHANGE("change", false);

    private final String key;
    private final boolean perEmail;

    Scope(String key, boolean perEmail) {
      this.key = key;
      this.perEmail = perEmail;
    }

    public String key() {
      return key;
    }
  }

  private static final Pattern IPV4 = Pattern.compile("\\d{1,3}(\\.\\d{1,3}){3}");
  /** Hex digits, ':' and '.' with at least one ':' — InetAddress parses such strings as IPv6 literals, never DNS. */
  private static final Pattern IPV6 = Pattern.compile("[0-9A-Fa-f:.]*:[0-9A-Fa-f:.]*");

  private final ProxyManager<String> buckets;
  private final AuthProperties.RateLimit limits;
  private final AuthAuditService audit;
  private final BucketConfiguration ipConfig;
  private final BucketConfiguration emailConfig;
  private final BucketConfiguration refreshConfig;
  private final BucketConfiguration userConfig;
  private final BucketConfiguration auditConfig;

  public AuthRateLimiter(ProxyManager<String> authRateLimitBuckets, AuthProperties properties,
                         AuthAuditService audit) {
    this.buckets = authRateLimitBuckets;
    this.limits = properties.rateLimit();
    this.audit = audit;
    this.ipConfig = config(limits.perIp());
    this.emailConfig = config(limits.perEmail());
    this.refreshConfig = config(limits.refreshPerIp());
    this.userConfig = config(limits.changePerUser());
    this.auditConfig = BucketConfiguration.builder()
        .addLimit(Bandwidth.builder().capacity(1).refillIntervally(1, limits.window()).build())
        .build();
  }

  /**
   * Counts one request against the scope's IP (and, for login/forgot, email) buckets.
   *
   * @param email the request's email (login, forgot), or {@code null}
   * @throws RateLimitedException when a limit is exhausted
   */
  public void check(Scope scope, ClientInfo client, @Nullable String email) {
    if (!limits.enabled()) {
      return;
    }
    String ipKey = ipKey(client.ip());
    if (ipKey != null) {
      consume(scope, "ip", scope.key + ":ip:" + ipKey, scope == Scope.REFRESH ? refreshConfig : ipConfig, client,
          null);
    }
    if (scope.perEmail && email != null && !email.isBlank()) {
      String normalized = email.trim().toLowerCase(Locale.ROOT);
      consume(scope, "email", scope.key + ":email:" + sha256Hex(normalized), emailConfig, client, normalized);
    }
  }

  /** Counts one request against the user's bucket of the scope ({@code change-per-user}). */
  public void checkUser(Scope scope, ClientInfo client, UUID userId) {
    if (!limits.enabled()) {
      return;
    }
    consume(scope, "user", scope.key + ":user:" + userId, userConfig, client, null);
  }

  private void consume(Scope scope, String limit, String key, BucketConfiguration config, ClientInfo client,
                       @Nullable String email) {
    ConsumptionProbe probe = buckets.builder().build(key, () -> config).tryConsumeAndReturnRemaining(1);
    if (probe.isConsumed()) {
      return;
    }
    long retryAfter = Math.max(1, (probe.getNanosToWaitForRefill() + 999_999_999L) / 1_000_000_000L);
    if (buckets.builder().build("audit:" + key, () -> auditConfig).tryConsume(1)) {
      audit.event(AuthAuditService.RATE_LIMITED, client)
          .outcome(Outcome.DENIED)
          .meta("scope", scope.key)
          .meta("limit", limit)
          .meta("email", email)
          .meta("retry_after_seconds", retryAfter)
          .write();
    }
    throw new RateLimitedException(retryAfter);
  }

  /**
   * Canonical bucket key of a client IP: IPv4 dotted quad, IPv6 {@code /64} prefix; {@code null} when there is no
   * usable IP literal (no shared "unknown" bucket).
   */
  @Nullable
  static String ipKey(@Nullable String ip) {
    if (ip == null || ip.length() > 45 || !(IPV4.matcher(ip).matches() || IPV6.matcher(ip).matches())) {
      return null;
    }
    try {
      // only IPv4/IPv6 literal syntax reaches this point; InetAddress parses it without any DNS lookup
      InetAddress address = InetAddress.getByName(ip);
      if (address instanceof Inet6Address) {
        return HexFormat.of().formatHex(Arrays.copyOf(address.getAddress(), 8)) + "/64";
      }
      return address.getHostAddress();
    } catch (Exception e) {
      return null;
    }
  }

  private BucketConfiguration config(int perWindow) {
    return BucketConfiguration.builder()
        .addLimit(Bandwidth.builder().capacity(perWindow).refillGreedy(perWindow, limits.window()).build())
        .build();
  }

  private static String sha256Hex(String value) {
    try {
      return HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256")
          .digest(value.getBytes(StandardCharsets.UTF_8)));
    } catch (NoSuchAlgorithmException e) {
      throw new IllegalStateException("SHA-256 unavailable", e);
    }
  }
}
