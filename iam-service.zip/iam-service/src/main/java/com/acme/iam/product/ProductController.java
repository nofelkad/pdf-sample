package com.acme.iam.product;

import com.acme.iam.common.error.BadRequestException;
import com.acme.iam.common.error.NotFoundException;
import com.acme.iam.common.security.CodedAccessDeniedException;
import com.acme.iam.common.security.CurrentUser;
import com.acme.iam.core.Claims;
import jakarta.servlet.http.HttpServletRequest;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.Map;
import org.springframework.http.MediaType;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * Product registry endpoints (P1-7.3).
 *
 * <ul>
 *   <li>{@code PUT /internal/products/{code}/manifest}: applications upload their manifest with an application token
 *       holding {@code internal.manifest.write}. The token's {@code prd} claim must equal {@code {code}} (an app manages
 *       only its own product; otherwise 403 {@code product_mismatch}, audited as {@code authz.denied}), the body's
 *       {@code product} must equal it too (400 {@code product_mismatch}), and IAM's own manifest is never accepted over
 *       HTTP (403 {@code iam_manifest_not_uploadable}); it is loaded from the classpath at startup.
 *   <li>{@code GET /api/products/{code}/permissions}: the permission catalogue of a product. <b>Authenticated-only by
 *       design</b>: any signed-in caller may read any product's catalogue (codes, kinds, descriptions, flags; no
 *       tenant data), because the role editor and client applications need it to pick permissions.
 * </ul>
 */
@RestController
public class ProductController {

  public static final String MANIFEST_PATH = "/internal/products/{code}/manifest";
  public static final String PERMISSIONS_PATH = "/api/products/{code}/permissions";

  /** One entry of the catalogue. */
  public record PermissionView(String code, PermissionKind kind, String description, boolean sensitive,
      boolean auditRead, boolean deprecated) {}

  /** The catalogue of one product, deprecated permissions included (flagged). */
  public record PermissionCatalogue(String product, String name, List<PermissionView> permissions) {}

  private final RegistryService registry;
  private final ProductService products;
  private final CurrentUser currentUser;

  public ProductController(RegistryService registry, ProductService products, CurrentUser currentUser) {
    this.registry = registry;
    this.products = products;
    this.currentUser = currentUser;
  }

  @PutMapping(value = MANIFEST_PATH, consumes = MediaType.APPLICATION_JSON_VALUE)
  @PreAuthorize("hasAuthority('" + Claims.PERM_INTERNAL_MANIFEST_WRITE + "')")
  public ApplyResult uploadManifest(@PathVariable String code, HttpServletRequest request) throws IOException {
    if (Product.IAM_CODE.equals(code)) {
      throw new CodedAccessDeniedException("iam_manifest_not_uploadable",
          "IAM's own manifest is loaded from the classpath, never over HTTP", Map.of("product", code));
    }
    String tokenProduct = currentUser.productCode();
    if (!code.equals(tokenProduct)) {
      throw new CodedAccessDeniedException("product_mismatch",
          "An application may only upload the manifest of its own product",
          Map.of("product", code, "tokenProduct", String.valueOf(tokenProduct)));
    }
    // read at most 1 MB + 1 byte: an oversized body is refused without being buffered in full
    byte[] raw = request.getInputStream().readNBytes(ManifestValidator.MAX_BODY_BYTES + 1);
    if (raw.length > ManifestValidator.MAX_BODY_BYTES) {
      throw new InvalidManifestException("The manifest body is larger than " + ManifestValidator.MAX_BODY_BYTES
          + " bytes");
    }
    Manifest manifest = ManifestParser.parseJson(new String(raw, StandardCharsets.UTF_8));
    if (!code.equals(manifest.product())) {
      throw new BadRequestException("product_mismatch", "The manifest's product must equal the path's product");
    }
    return registry.apply(manifest);
  }

  @GetMapping(PERMISSIONS_PATH)
  @PreAuthorize("isAuthenticated()")
  public PermissionCatalogue permissions(@PathVariable String code) {
    Product product = products.findByCode(code)
        .orElseThrow(() -> new NotFoundException("product_not_found", "Product not found"));
    List<PermissionView> permissions = products.findPermissionsOfProduct(product.id()).stream()
        .map(p -> new PermissionView(p.code(), p.kind(), p.description(), p.sensitive(), p.auditRead(), p.deprecated()))
        .toList();
    return new PermissionCatalogue(product.code(), product.name(), permissions);
  }
}
