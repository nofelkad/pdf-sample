package com.acme.iam.auth;

import java.time.Duration;
import net.javacrumbs.shedlock.spring.annotation.SchedulerLock;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

/** Deletes revocation feed rows older than {@code iam.revocation.retention} (1 h) on one instance (ShedLock). */
@Component
public class RevocationPurgeJob {

  public static final String LOCK_NAME = "revocation-purge";
  private static final Logger log = LoggerFactory.getLogger(RevocationPurgeJob.class);

  private final RevocationService revocations;
  private final Duration retention;

  public RevocationPurgeJob(RevocationService revocations, @Value("${iam.revocation.retention:PT1H}") Duration retention) {
    this.revocations = revocations;
    this.retention = retention;
  }

  @Scheduled(fixedDelayString = "${iam.revocation.purge-interval:PT5M}")
  @SchedulerLock(name = LOCK_NAME, lockAtMostFor = "PT5M")
  public void run() {
    try {
      int purged = revocations.purge(retention);
      if (purged > 0) {
        log.info("Purged {} revocation rows older than {}", purged, retention);
      }
    } catch (RuntimeException e) {
      log.error("Revocation purge failed", e);
    }
  }
}
