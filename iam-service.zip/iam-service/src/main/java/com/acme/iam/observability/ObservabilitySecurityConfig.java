package com.acme.iam.observability;

import java.util.Arrays;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.autoconfigure.condition.ConditionalOnWebApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.annotation.Order;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configurers.AbstractHttpConfigurer;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.servlet.util.matcher.PathPatternRequestMatcher;
import org.springframework.security.web.util.matcher.OrRequestMatcher;
import org.springframework.security.web.util.matcher.RequestMatcher;

/**
 * Filter chains for the operational endpoints that {@code SecurityConfig}'s fallback chain would answer with 401
 * (it only lets {@code /actuator/health/**}, {@code /actuator/info} and {@code /error} through). Both use the
 * extension point documented there: their own {@code SecurityFilterChain} with an order between 3 and
 * {@code LOWEST_PRECEDENCE - 11}.
 *
 * <ul>
 *   <li>{@code /actuator/prometheus} is open by default ({@code iam.observability.metrics-public=true}), as a
 *       Prometheus scrape normally carries no credentials. Since ruling R36 (Task 9) actuator is served only on the
 *       management port ({@code management.server.port}, default 8081; the security filter chains apply there too),
 *       so this chain opens the endpoint on that port only; the application port has no actuator mapping besides
 *       the liveness/readiness probes ({@code HealthProbesController}). The management port must be reachable from
 *       the monitoring network only. With {@code metrics-public=false} no chain is registered and the fallback chain
 *       answers 401.
 *   <li>{@code /v3/api-docs} and Swagger UI exist only when springdoc is enabled
 *       ({@code springdoc.api-docs.enabled=true}, set by the {@code dev} profile only); the chain is open then.
 * </ul>
 */
@Configuration(proxyBeanMethods = false)
@ConditionalOnWebApplication(type = ConditionalOnWebApplication.Type.SERVLET)
public class ObservabilitySecurityConfig {

  @Bean
  @Order(3)
  @ConditionalOnProperty(prefix = "iam.observability", name = "metrics-public", havingValue = "true",
      matchIfMissing = true)
  SecurityFilterChain prometheusScrapeChain(HttpSecurity http) throws Exception {
    return open(http, "/actuator/prometheus");
  }

  @Bean
  @Order(4)
  @ConditionalOnProperty(prefix = "springdoc.api-docs", name = "enabled", havingValue = "true")
  SecurityFilterChain apiDocsChain(HttpSecurity http) throws Exception {
    return open(http, "/v3/api-docs", "/v3/api-docs/**", "/v3/api-docs.yaml", "/swagger-ui.html", "/swagger-ui/**");
  }

  private static SecurityFilterChain open(HttpSecurity http, String... patterns) throws Exception {
    PathPatternRequestMatcher.Builder builder = PathPatternRequestMatcher.withDefaults();
    RequestMatcher matcher = new OrRequestMatcher(
        Arrays.stream(patterns).<RequestMatcher>map(builder::matcher).toList());
    return http.securityMatcher(matcher)
        .csrf(AbstractHttpConfigurer::disable)
        .httpBasic(AbstractHttpConfigurer::disable)
        .formLogin(AbstractHttpConfigurer::disable)
        .logout(AbstractHttpConfigurer::disable)
        .requestCache(AbstractHttpConfigurer::disable)
        .sessionManagement(s -> s.sessionCreationPolicy(SessionCreationPolicy.STATELESS))
        .authorizeHttpRequests(a -> a.anyRequest().permitAll())
        .build();
  }
}
