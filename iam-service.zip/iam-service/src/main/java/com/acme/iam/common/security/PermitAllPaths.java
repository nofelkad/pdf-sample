package com.acme.iam.common.security;

import java.util.List;
import java.util.Objects;

/**
 * Extension point for the {@code /api/**} + {@code /internal/**} chain: declare a bean of this type in a feature's
 * configuration to make additional paths (Ant/MVC patterns) public. Bearer tokens on these paths are ignored (not
 * parsed), exactly like {@code POST /internal/token}.
 *
 * <pre>{@code
 * @Bean PermitAllPaths invitationPreview() { return new PermitAllPaths("/api/public/invitations/*"); }
 * }</pre>
 *
 * Use sparingly: every {@code /api/**} endpoint is authenticated by default.
 */
public record PermitAllPaths(List<String> patterns) {

  public PermitAllPaths {
    patterns = List.copyOf(Objects.requireNonNull(patterns, "patterns"));
  }

  public PermitAllPaths(String... patterns) {
    this(List.of(patterns));
  }
}
