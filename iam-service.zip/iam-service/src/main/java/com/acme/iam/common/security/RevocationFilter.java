package com.acme.iam.common.security;

import com.acme.iam.core.Claims;
import com.acme.iam.core.revocation.RevocationRegistry;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.UUID;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.security.oauth2.server.resource.authentication.JwtAuthenticationToken;
import org.springframework.web.filter.OncePerRequestFilter;

/**
 * Rejects user tokens revoked through the revocation feed (spec section 5, P1-10.2): when {@code jwt.sv} is lower
 * than the user's minimum session version in the {@link RevocationRegistry}, the request ends with {@code 401},
 * {@code WWW-Authenticate: Bearer error="token_revoked"} and an RFC 7807 body {@code code = "token_revoked"}. The
 * client then refreshes (refresh re-checks the database).
 *
 * <p>Placed right after {@code BearerTokenAuthenticationFilter} in every JWT chain. Application tokens
 * ({@code typ = "app"}) are not subject to user revocation. Deliberately not a Spring bean (that would also register it
 * as a servlet filter for every request); {@link SecurityConfig} instantiates it per chain.
 */
public class RevocationFilter extends OncePerRequestFilter {

  public static final String ERROR_CODE = "token_revoked";
  static final String WWW_AUTHENTICATE_VALUE =
      "Bearer error=\"token_revoked\", error_description=\"The access token has been revoked\"";

  private final RevocationRegistry registry;
  private final SecurityProblemWriter problems;

  public RevocationFilter(RevocationRegistry registry, SecurityProblemWriter problems) {
    this.registry = registry;
    this.problems = problems;
  }

  @Override
  protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain chain)
      throws ServletException, IOException {
    Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
    if (authentication instanceof JwtAuthenticationToken token && isRevoked(token.getToken())) {
      SecurityContextHolder.clearContext();
      response.setHeader(HttpHeaders.WWW_AUTHENTICATE, WWW_AUTHENTICATE_VALUE);
      problems.write(request, response, HttpStatus.UNAUTHORIZED, ERROR_CODE, "The access token has been revoked");
      return;
    }
    chain.doFilter(request, response);
  }

  private boolean isRevoked(Jwt jwt) {
    if (AppCaller.isApp(jwt)) {
      return false;
    }
    // sub (UUID) and sv (integer) are guaranteed by the decoder's IamTokenValidator
    Object sv = jwt.getClaim(Claims.SESSION_VERSION);
    return registry.isRevoked(UUID.fromString(jwt.getSubject()), ((Number) sv).intValue());
  }
}
