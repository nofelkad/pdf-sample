package com.acme.iam.user;

import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;
import java.time.Duration;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.bind.DefaultValue;
import org.springframework.validation.annotation.Validated;

/**
 * {@code iam.notification.executor.*}: the background executor that sends invitation emails ({@link InvitationMailer},
 * final review I2).
 *
 * @param threads concurrent sends (default 2)
 * @param queueCapacity invitations waiting to be sent before new ones are dropped (default 10000, two full 5,000-row
 *     bulk invites); a dropped invitation is counted in {@code iam.notification.invitations.dropped} and can be
 *     re-sent with {@code POST /api/users/{id}/invitation/resend}
 * @param sendTimeout upper bound of one {@code NotificationPort.sendInvitation} call; a hung send is cancelled
 */
@Validated
@ConfigurationProperties("iam.notification.executor")
public record InvitationMailerProperties(
    @Min(1) @Max(64) @DefaultValue("2") int threads,
    @Min(1) @DefaultValue("10000") int queueCapacity,
    @NotNull @DefaultValue("PT30S") Duration sendTimeout) {}
