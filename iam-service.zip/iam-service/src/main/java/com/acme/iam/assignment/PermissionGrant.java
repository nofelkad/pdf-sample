package com.acme.iam.assignment;

import java.time.Instant;
import java.util.UUID;
import org.springframework.lang.Nullable;

/**
 * One row of {@link PermissionResolver#explain}: {@code permission} is granted through role {@code roleId}
 * ({@code roleName}) assigned at {@code scopeType/scopeId}. A permission granted by several roles or scopes appears once
 * per grant.
 */
public record PermissionGrant(
    String permission,
    UUID roleId,
    String roleName,
    ScopeType scopeType,
    UUID scopeId,
    @Nullable Instant expiresAt) {}
