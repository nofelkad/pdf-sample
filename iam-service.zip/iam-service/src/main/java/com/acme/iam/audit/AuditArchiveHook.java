package com.acme.iam.audit;

/**
 * Archives one audit partition before the retention job drops it (P1-9.3). The partition is still attached to
 * {@code audit_event} (readable through the application role) when this is called; the usual implementation runs
 * {@code pg_dump -t <partitionName>} to cold storage, verifies the dump and returns {@code true}.
 *
 * <p>Contract: return {@code true} only when the partition's rows are safely archived (or the operator has explicitly
 * decided none is needed); the retention job then detaches and drops the table. Return {@code false} (or throw) to
 * keep the partition; it is offered again on the next run. Implementations must be idempotent: the same partition may
 * be archived again after a failed drop, or by two instances.
 *
 * <p>Provide your own bean to replace the default {@link RefusingArchiveHook}. Setting
 * {@code iam.audit.archive.mode=none-acknowledged} selects {@link AcknowledgedNoArchiveHook} instead (dev/test).
 */
public interface AuditArchiveHook {

  /**
   * @param partitionName for example {@code audit_event_y2019m03}
   * @return {@code true} when the partition may be dropped
   */
  boolean archive(String partitionName);
}
