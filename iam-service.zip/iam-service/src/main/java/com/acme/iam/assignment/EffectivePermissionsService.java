package com.acme.iam.assignment;

import com.acme.iam.common.error.NotFoundException;
import com.acme.iam.tenant.TenantService;
import com.acme.iam.user.AppUser;
import com.acme.iam.user.UserService;
import java.time.Instant;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import org.springframework.lang.Nullable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * The explain endpoint's logic (P1-10.6): why does user U hold which permissions in tenant T? Built from
 * {@link PermissionResolver#explain}, which uses the same predicate as {@link PermissionResolver#resolve}, so the set
 * of {@code code}s always equals the permissions that go into the user's token for that tenant.
 */
@Service
public class EffectivePermissionsService {

  /** One role assignment that grants a permission. */
  public record Grant(UUID roleId, String roleName, ScopeType scopeType, UUID scopeId, @Nullable Instant expiresAt) {}

  /** A permission and every grant behind it. */
  public record PermissionEntry(String code, List<Grant> grants) {}

  public record EffectivePermissions(UUID userId, UUID tenantId, List<PermissionEntry> permissions) {}

  private final PermissionResolver resolver;
  private final UserService users;
  private final TenantService tenants;

  public EffectivePermissionsService(PermissionResolver resolver, UserService users, TenantService tenants) {
    this.resolver = resolver;
    this.users = users;
    this.tenants = tenants;
  }

  /**
   * @param accountId the caller's account (I10): the user and the tenant must both belong to it
   * @param tenantLevelOnly the caller only holds the tenant-level read permission: the user must then be a member of
   *     the tenant (any membership status), otherwise it is reported as not found
   * @throws NotFoundException {@code user_not_found} or {@code tenant_not_found}
   */
  @Transactional(readOnly = true)
  public EffectivePermissions explain(UUID accountId, UUID userId, UUID tenantId, boolean tenantLevelOnly) {
    AppUser user = users.findByIdInAccount(userId, accountId)
        .orElseThrow(() -> new NotFoundException("user_not_found", "User not found"));
    tenants.findByIdInAccount(tenantId, accountId)
        .orElseThrow(() -> new NotFoundException("tenant_not_found", "Tenant not found"));
    if (tenantLevelOnly && user.membership(tenantId).isEmpty()) {
      throw new NotFoundException("user_not_found", "User not found");
    }

    Map<String, List<Grant>> byCode = new LinkedHashMap<>();
    for (PermissionGrant g : resolver.explain(userId, tenantId)) {
      byCode.computeIfAbsent(g.permission(), c -> new ArrayList<>())
          .add(new Grant(g.roleId(), g.roleName(), g.scopeType(), g.scopeId(), g.expiresAt()));
    }
    List<PermissionEntry> permissions = byCode.entrySet().stream()
        .map(e -> new PermissionEntry(e.getKey(), List.copyOf(e.getValue()))).toList();
    return new EffectivePermissions(userId, tenantId, permissions);
  }
}
