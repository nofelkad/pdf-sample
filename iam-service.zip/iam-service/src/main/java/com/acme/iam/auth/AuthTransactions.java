package com.acme.iam.auth;

import com.acme.iam.common.error.ApiException;
import java.util.function.Supplier;
import org.springframework.dao.PessimisticLockingFailureException;
import org.springframework.lang.Nullable;
import org.springframework.stereotype.Component;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.support.TransactionTemplate;

/**
 * Transactions of the authentication flows.
 *
 * <ul>
 *   <li>{@link #write(Supplier)} runs the work in a new read-write transaction and retries it (up to
 *       {@value #ATTEMPTS} times) on a deadlock or lock timeout ({@link PessimisticLockingFailureException}, e.g.
 *       SQLSTATE 40P01 around {@code RevocationService.revoke*}, as its contract asks).
 *   <li>{@link Outcome}: several flows must <em>commit</em> their writes (a revoked session, a failure counter, an
 *       audit event) and still answer with an error. The work returns {@code Outcome.fail(error)}; the transaction
 *       commits; {@link Outcome#get()} then throws.
 * </ul>
 */
@Component
class AuthTransactions {

  static final int ATTEMPTS = 3;

  private final TransactionTemplate template;

  AuthTransactions(PlatformTransactionManager transactionManager) {
    this.template = new TransactionTemplate(transactionManager);
  }

  <T> T write(Supplier<T> work) {
    for (int attempt = 1; ; attempt++) {
      try {
        return template.execute(status -> work.get());
      } catch (PessimisticLockingFailureException e) {
        if (attempt >= ATTEMPTS) {
          throw e;
        }
      }
    }
  }

  /** A committed result: a value, or an error to throw after commit. */
  static final class Outcome<T> {
    @Nullable private final T value;
    @Nullable private final ApiException failure;

    private Outcome(@Nullable T value, @Nullable ApiException failure) {
      this.value = value;
      this.failure = failure;
    }

    static <T> Outcome<T> ok(T value) {
      return new Outcome<>(value, null);
    }

    static <T> Outcome<T> fail(ApiException failure) {
      return new Outcome<>(null, failure);
    }

    T get() {
      if (failure != null) {
        throw failure;
      }
      return value;
    }
  }
}
