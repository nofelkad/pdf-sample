package com.acme.iam.auth;

import java.time.Instant;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import org.springframework.data.jdbc.repository.query.Modifying;
import org.springframework.data.jdbc.repository.query.Query;
import org.springframework.data.repository.ListCrudRepository;

/** Persistence of {@link UserSession}. Private to the {@code auth} feature. */
public interface UserSessionRepository extends ListCrudRepository<UserSession, UUID> {

  @Query("SELECT * FROM user_session WHERE refresh_hash = :refreshHash")
  Optional<UserSession> findByRefreshHash(byte[] refreshHash);

  /** Refresh-token reuse detection: the session whose <em>previous</em> refresh token has this hash. */
  @Query("SELECT * FROM user_session WHERE prev_refresh_hash = :refreshHash")
  Optional<UserSession> findByPrevRefreshHash(byte[] refreshHash);

  @Query("SELECT * FROM user_session WHERE user_id = :userId AND revoked_at IS NULL ORDER BY created_at")
  List<UserSession> findUnrevokedByUser(UUID userId);

  // --- Task 4: row-locking reads and targeted updates (the refresh/switch/logout hot paths) ---

  /** The session whose current refresh token has this hash, locked until the end of the transaction. */
  @Query("SELECT * FROM user_session WHERE refresh_hash = :refreshHash FOR UPDATE")
  Optional<UserSession> lockByRefreshHash(byte[] refreshHash);

  /** The session whose previous refresh token has this hash, locked until the end of the transaction. */
  @Query("SELECT * FROM user_session WHERE prev_refresh_hash = :refreshHash FOR UPDATE")
  Optional<UserSession> lockByPrevRefreshHash(byte[] refreshHash);

  @Query("SELECT * FROM user_session WHERE id = :id AND user_id = :userId FOR UPDATE")
  Optional<UserSession> lockOwned(UUID id, UUID userId);

  /** Rotates the refresh token (the current hash becomes the previous one) and records activity. */
  @Modifying
  @Query("""
      UPDATE user_session SET prev_refresh_hash = refresh_hash, refresh_hash = :newHash, last_seen_at = :now,
                              version = version + 1
      WHERE id = :id""")
  int rotate(UUID id, byte[] newHash, Instant now);

  /** Rotates the refresh token and moves the session to another tenant. */
  @Modifying
  @Query("""
      UPDATE user_session SET prev_refresh_hash = refresh_hash, refresh_hash = :newHash, active_tenant_id = :tenantId,
                              last_seen_at = :now, version = version + 1
      WHERE id = :id""")
  int rotateAndSwitch(UUID id, byte[] newHash, UUID tenantId, Instant now);

  @Modifying
  @Query("UPDATE user_session SET revoked_at = :now, version = version + 1 WHERE id = :id AND revoked_at IS NULL")
  int revoke(UUID id, Instant now);

  @Modifying
  @Query("""
      UPDATE user_session SET revoked_at = :now, version = version + 1
      WHERE user_id = :userId AND revoked_at IS NULL""")
  int revokeAllOfUser(UUID userId, Instant now);

  @Modifying
  @Query("""
      UPDATE user_session SET revoked_at = :now, version = version + 1
      WHERE user_id = :userId AND id <> :keep AND revoked_at IS NULL""")
  int revokeOthersOfUser(UUID userId, UUID keep, Instant now);
}
