package com.acme.iam.account;

/** {@code account.status}. */
public enum AccountStatus {
  ACTIVE,
  SUSPENDED,
  CLOSED
}
