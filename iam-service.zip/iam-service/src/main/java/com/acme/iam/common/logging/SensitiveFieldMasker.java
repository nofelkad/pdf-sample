package com.acme.iam.common.logging;

import com.fasterxml.jackson.core.JsonStreamContext;
import java.util.List;
import java.util.Locale;
import net.logstash.logback.mask.FieldMasker;

/**
 * JSON log field masker (Task 9 security review): masks every field whose <b>name contains</b> a sensitive word,
 * case-insensitively, so {@code clientSecret}, {@code newPassword}, {@code refresh_token}, {@code X-Api-Token} or
 * {@code privateKey} are masked as well as the exact names. The same words as the audit deny-list
 * ({@code AuditWriter.DENY_LIST}) plus {@code credential}, {@code cookie} and {@code apikey}. Applies to structured
 * arguments, MDC entries and markers; message text is covered by the bearer/JWT value patterns in
 * {@code logback-spring.xml}.
 */
public class SensitiveFieldMasker implements FieldMasker {

  public static final String MASK = "****";
  static final List<String> WORDS = List.of("password", "passwd", "secret", "token", "hash", "private",
      "authorization", "credential", "cookie", "apikey", "api_key", "api-key");

  @Override
  public Object mask(JsonStreamContext context) {
    if (!context.hasCurrentName()) {
      return null;
    }
    String name = context.getCurrentName().toLowerCase(Locale.ROOT);
    for (String word : WORDS) {
      if (name.contains(word)) {
        return MASK;
      }
    }
    return null;
  }
}
