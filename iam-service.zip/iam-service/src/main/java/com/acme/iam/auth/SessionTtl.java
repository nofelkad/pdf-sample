package com.acme.iam.auth;

import java.time.Duration;
import java.time.Instant;
import java.time.format.DateTimeParseException;
import java.util.Map;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Refresh-token lifetimes of one account: absolute (from login) and idle (between refreshes). Read from
 * {@code account.settings} — either nested {@code {"session": {"absoluteTtl": "PT8H", "idleTtl": "PT15M"}}} or flat
 * keys {@code "session.absoluteTtl"} / {@code "session.idleTtl"} — as ISO-8601 durations; missing, malformed or
 * non-positive values take the configured defaults ({@code iam.auth.session.*}, 12 h / 30 min). The absolute lifetime
 * is capped at {@value #MAX_ABSOLUTE_DAYS} days and the idle timeout at the absolute lifetime (WARN log when clamped).
 */
record SessionTtl(Duration absolute, Duration idle) {

  static final int MAX_ABSOLUTE_DAYS = 7;
  static final Duration MAX_ABSOLUTE = Duration.ofDays(MAX_ABSOLUTE_DAYS);
  private static final Logger log = LoggerFactory.getLogger(SessionTtl.class);

  static SessionTtl from(Map<String, Object> accountSettings, AuthProperties.Session defaults) {
    Duration absolute = duration(accountSettings, "absoluteTtl", defaults.absoluteTtl());
    if (absolute.compareTo(MAX_ABSOLUTE) > 0) {
      log.warn("Session absoluteTtl {} exceeds the maximum {}; using the maximum", absolute, MAX_ABSOLUTE);
      absolute = MAX_ABSOLUTE;
    }
    Duration idle = duration(accountSettings, "idleTtl", defaults.idleTtl());
    if (idle.compareTo(absolute) > 0) {
      log.warn("Session idleTtl {} exceeds absoluteTtl {}; using absoluteTtl", idle, absolute);
      idle = absolute;
    }
    return new SessionTtl(absolute, idle);
  }

  /** When an unused refresh token issued at {@code now} expires: idle timeout, capped by the absolute expiry. */
  Instant refreshExpiresAt(Instant sessionExpiresAt, Instant now) {
    Instant idleExpiry = now.plus(idle);
    return idleExpiry.isBefore(sessionExpiresAt) ? idleExpiry : sessionExpiresAt;
  }

  boolean isIdle(Instant lastSeenAt, Instant now) {
    return !lastSeenAt.plus(idle).isAfter(now);
  }

  private static Duration duration(Map<String, Object> settings, String key, Duration fallback) {
    Object value = null;
    if (settings != null) {
      if (settings.get("session") instanceof Map<?, ?> nested) {
        value = nested.get(key);
      }
      if (value == null) {
        value = settings.get("session." + key);
      }
    }
    if (value instanceof String text) {
      try {
        Duration parsed = Duration.parse(text);
        if (!parsed.isNegative() && !parsed.isZero()) {
          return parsed;
        }
      } catch (DateTimeParseException ignored) {
        // fall back to the default
      }
    }
    return fallback;
  }
}
