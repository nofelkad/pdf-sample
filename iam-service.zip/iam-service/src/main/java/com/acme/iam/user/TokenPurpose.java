package com.acme.iam.user;

/** {@code user_token.purpose}. */
public enum TokenPurpose {
  INVITE,
  PASSWORD_RESET
}
