package com.acme.iam.user;

/**
 * Outbound user notifications. Exactly one adapter is active, chosen by {@code iam.notification.mode}:
 * {@code log} (default, {@link LoggingNotificationAdapter}) or {@code smtp} ({@link SmtpNotificationAdapter}). Tests
 * replace it with {@code CapturingNotificationAdapter} (test sources).
 *
 * <p>Implementations receive raw tokens and must never log them.
 */
public interface NotificationPort {

  /** Invitation e-mail with an accept link carrying {@code rawToken}. */
  void sendInvitation(String email, String accountName, String rawToken);

  /** Password-reset e-mail with a reset link carrying {@code rawToken}. */
  void sendPasswordReset(String email, String rawToken);
}
