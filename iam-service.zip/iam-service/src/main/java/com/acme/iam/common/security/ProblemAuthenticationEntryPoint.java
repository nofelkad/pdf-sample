package com.acme.iam.common.security;

import com.acme.iam.audit.AuditEvent;
import com.acme.iam.audit.AuditWriter;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.LinkedHashMap;
import java.util.Map;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.oauth2.core.OAuth2AuthenticationException;
import org.springframework.security.oauth2.core.OAuth2Error;
import org.springframework.security.oauth2.server.resource.web.BearerTokenAuthenticationEntryPoint;
import org.springframework.security.web.AuthenticationEntryPoint;
import org.springframework.stereotype.Component;

/**
 * 401 for missing or invalid credentials: the standard {@code WWW-Authenticate: Bearer ...} header (RFC 6750) plus an
 * RFC 7807 body with {@code code} = {@code unauthorized} (no token) or the OAuth error code ({@code invalid_token}).
 *
 * <p>Auditing (Ruling R14): a presented but rejected token (bad signature, unknown kid, wrong issuer, expired,
 * malformed) is audited as {@value #ACTION_INVALID_TOKEN} (ANONYMOUS, DENIED; metadata {@code method}, {@code path},
 * {@code error_code}, {@code error} = the validation error description, truncated; never the token). A request without
 * a token is not audited (scanner noise). An audit failure is logged and does not change the 401.
 */
@Component
public class ProblemAuthenticationEntryPoint implements AuthenticationEntryPoint {

  public static final String ACTION_INVALID_TOKEN = "auth.token.invalid";
  private static final int MAX_ERROR_LENGTH = 256;
  private static final Logger log = LoggerFactory.getLogger(ProblemAuthenticationEntryPoint.class);

  private final BearerTokenAuthenticationEntryPoint bearer = new BearerTokenAuthenticationEntryPoint();
  private final SecurityProblemWriter problems;
  private final AuditWriter auditWriter;

  public ProblemAuthenticationEntryPoint(SecurityProblemWriter problems, AuditWriter auditWriter) {
    this.problems = problems;
    this.auditWriter = auditWriter;
  }

  @Override
  public void commence(HttpServletRequest request, HttpServletResponse response, AuthenticationException ex)
      throws IOException {
    bearer.commence(request, response, ex); // status + WWW-Authenticate
    HttpStatus status = HttpStatus.valueOf(response.getStatus());
    if (ex instanceof OAuth2AuthenticationException oauth) {
      auditInvalidToken(request, oauth.getError());
      problems.write(request, response, status, oauth.getError().getErrorCode(),
          "The access token is invalid or expired");
    } else {
      problems.write(request, response, status, "unauthorized", "Authentication is required");
    }
  }

  private void auditInvalidToken(HttpServletRequest request, OAuth2Error error) {
    try {
      Map<String, Object> metadata = new LinkedHashMap<>();
      metadata.put("method", request.getMethod());
      metadata.put("path", request.getRequestURI());
      metadata.put("error_code", error.getErrorCode());
      String description = error.getDescription() == null ? error.getErrorCode() : error.getDescription();
      metadata.put("error", description.length() > MAX_ERROR_LENGTH
          ? description.substring(0, MAX_ERROR_LENGTH) : description);
      auditWriter.write(AuditEvent.builder(ACTION_INVALID_TOKEN)
          .anonymous()
          .outcome(AuditEvent.Outcome.DENIED)
          .actorIp(request.getRemoteAddr())
          .userAgent(request.getHeader(HttpHeaders.USER_AGENT))
          .metadata(metadata)
          .build());
    } catch (RuntimeException e) {
      log.error("Could not audit {} for {} {}", ACTION_INVALID_TOKEN, request.getMethod(), request.getRequestURI(), e);
    }
  }
}
