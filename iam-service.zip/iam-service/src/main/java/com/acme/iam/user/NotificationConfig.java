package com.acme.iam.user;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.Locale;
import java.util.Optional;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;
import org.springframework.core.env.Profiles;
import org.springframework.mail.javamail.JavaMailSender;

/**
 * Selects the {@link NotificationPort} adapter from the bound {@link NotificationProperties#mode()} (an enum, so an
 * unknown value fails at startup instead of silently leaving no adapter).
 *
 * <p>Ruling R44 (final review M5):
 * <ul>
 *   <li>{@code mode=log} outside the {@code dev}, {@code local} and {@code test} profiles logs a startup WARN: no email
 *       ever leaves the service, so invited users and password resets never receive their links.
 *   <li>{@code mode=smtp} fails startup when {@code iam.notification.invitation-url} or
 *       {@code iam.notification.password-reset-url} is missing, not an absolute http(s) URL, lacks the {@code {token}}
 *       placeholder or points at a loopback host ({@code localhost}, {@code *.localhost}, {@code 127.0.0.0/8},
 *       {@code ::1}; the defaults are {@code http://localhost:3000/...}): mailed links would be dead.
 * </ul>
 */
@Configuration(proxyBeanMethods = false)
@EnableConfigurationProperties({NotificationProperties.class, InvitationMailerProperties.class})
public class NotificationConfig {

  private static final Logger log = LoggerFactory.getLogger(NotificationConfig.class);

  /**
   * @throws IllegalStateException in SMTP mode without a {@link JavaMailSender} (set {@code spring.mail.host}) or with
   *     an unusable public link URL
   */
  @Bean
  NotificationPort notificationPort(NotificationProperties properties, ObjectProvider<JavaMailSender> mail,
      Environment environment) {
    return switch (properties.mode()) {
      case LOG -> {
        logModeWarning(environment).ifPresent(log::warn);
        yield new LoggingNotificationAdapter();
      }
      case SMTP -> {
        requirePublicLink("iam.notification.invitation-url", properties.invitationUrl());
        requirePublicLink("iam.notification.password-reset-url", properties.passwordResetUrl());
        yield new SmtpNotificationAdapter(mail.getIfAvailable(() -> {
          throw new IllegalStateException(
              "iam.notification.mode=smtp requires a JavaMailSender; configure spring.mail.host");
        }), properties);
      }
    };
  }

  static Optional<String> logModeWarning(Environment environment) {
    if (environment.acceptsProfiles(Profiles.of("dev | local | test"))) {
      return Optional.empty();
    }
    return Optional.of("iam.notification.mode=log: invitation and password-reset emails are NOT sent (only logged, "
        + "without the link). Set iam.notification.mode=smtp with spring.mail.* and public link URLs "
        + "(docs/deployment.md)");
  }

  /** The link template must be an absolute http(s) URL on a non-loopback host and contain {@code {token}}. */
  static void requirePublicLink(String property, String template) {
    String problem = linkProblem(template);
    if (problem != null) {
      throw new IllegalStateException("iam.notification.mode=smtp: " + property + " " + problem + " (was '" + template
          + "'); set it to the public URL of the page that handles the link, e.g. "
          + "https://app.example.com/invitations/accept?token={token}");
    }
  }

  private static String linkProblem(String template) {
    if (template == null || template.isBlank()) {
      return "is missing";
    }
    if (!template.contains(NotificationProperties.TOKEN_PLACEHOLDER)) {
      return "has no " + NotificationProperties.TOKEN_PLACEHOLDER + " placeholder";
    }
    URI uri;
    try {
      uri = new URI(template.replace(NotificationProperties.TOKEN_PLACEHOLDER, "t"));
    } catch (URISyntaxException e) {
      return "is not a valid URL";
    }
    String scheme = uri.getScheme() == null ? "" : uri.getScheme().toLowerCase(Locale.ROOT);
    if (!scheme.equals("https") && !scheme.equals("http") || uri.getHost() == null) {
      return "is not an absolute http(s) URL";
    }
    String host = uri.getHost().toLowerCase(Locale.ROOT);
    if (host.startsWith("[") && host.endsWith("]")) {
      host = host.substring(1, host.length() - 1);
    }
    if (host.equals("localhost") || host.endsWith(".localhost") || host.startsWith("127.") || host.equals("::1")
        || host.equals("0:0:0:0:0:0:0:1") || host.equals("0.0.0.0")) {
      return "points at a loopback host";
    }
    return null;
  }
}
