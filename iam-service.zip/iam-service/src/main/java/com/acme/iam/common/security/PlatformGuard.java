package com.acme.iam.common.security;

import java.util.Map;
import java.util.UUID;
import org.springframework.stereotype.Component;

/**
 * The single check behind every platform (cross-account) operation (Task 9): the caller is a <em>platform
 * operator</em> when the token's account ({@code acc}) is the PLATFORM account <b>and</b> the caller holds
 * {@value #PERMISSION} through an unexpired ACCOUNT-scope assignment ({@link TenantGuard#hasAccountScope}). The JWT
 * {@code perms} claim carries no scope, so the permission alone is never enough: a TENANT-scope grant in a platform
 * tenant does not reach other accounts.
 *
 * <p>Used by {@code /api/platform/accounts/**}, {@code /api/platform/app-clients/**} and the audit API's
 * {@code accountId} filter. Endpoints still carry {@code @PreAuthorize("hasAuthority('platform.account.manage')")}.
 */
@Component
public class PlatformGuard {

  /** The seeded PLATFORM account (V3); equal to {@code account.Account.PLATFORM_ID}. */
  public static final UUID PLATFORM_ACCOUNT_ID = UUID.fromString("00000000-0000-7000-8000-0000000000a1");
  public static final String PERMISSION = "platform.account.manage";
  public static final String PLATFORM_ACCOUNT_REQUIRED = "platform_account_required";
  public static final String ACCOUNT_SCOPE_REQUIRED = TenantGuard.ACCOUNT_SCOPE_REQUIRED;

  private final CurrentUser currentUser;
  private final TenantGuard tenantGuard;

  public PlatformGuard(CurrentUser currentUser, TenantGuard tenantGuard) {
    this.currentUser = currentUser;
    this.tenantGuard = tenantGuard;
  }

  /**
   * @throws CodedAccessDeniedException {@value #PLATFORM_ACCOUNT_REQUIRED} for a caller outside the PLATFORM account
   *     (or an application token), {@value #ACCOUNT_SCOPE_REQUIRED} without an ACCOUNT-scope grant (both 403, audited)
   */
  public void requireOperator() {
    if (currentUser.isApp() || !PLATFORM_ACCOUNT_ID.equals(currentUser.accountId())) {
      throw new CodedAccessDeniedException(PLATFORM_ACCOUNT_REQUIRED,
          "Only operators of the platform account may use the platform API", Map.of("requiredAuthority", PERMISSION));
    }
    if (!tenantGuard.hasAccountScope(PERMISSION)) {
      throw new CodedAccessDeniedException(ACCOUNT_SCOPE_REQUIRED,
          "The platform API requires " + PERMISSION + " at account scope", Map.of("requiredAuthority", PERMISSION));
    }
  }

  /** Whether {@link #requireOperator()} would pass (no exception, no audit). */
  public boolean isOperator() {
    return !currentUser.isApp() && PLATFORM_ACCOUNT_ID.equals(currentUser.accountId())
        && currentUser.hasPermission(PERMISSION) && tenantGuard.hasAccountScope(PERMISSION);
  }
}
