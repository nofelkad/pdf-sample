package com.acme.iam.auth;

import java.time.Instant;
import java.util.UUID;

/**
 * Response of login, refresh, switch-tenant, password change and invitation accept:
 * {@code {accessToken, tokenType: "Bearer", expiresIn, refreshToken, refreshExpiresAt, activeTenantId}}.
 *
 * @param expiresIn access token lifetime in seconds
 * @param refreshExpiresAt when the refresh token stops working if unused: the earlier of the session's absolute
 *     expiry and the idle timeout from now
 */
public record AuthTokens(
    String accessToken,
    String tokenType,
    long expiresIn,
    String refreshToken,
    Instant refreshExpiresAt,
    UUID activeTenantId) {

  public static final String BEARER = "Bearer";

  /** Never print the tokens. */
  @Override
  public String toString() {
    return "AuthTokens[tokenType=" + tokenType + ", expiresIn=" + expiresIn + ", refreshExpiresAt=" + refreshExpiresAt
        + ", activeTenantId=" + activeTenantId + "]";
  }
}
