package com.acme.iam.appclient;

import com.acme.iam.appclient.AppClientService.AppClientPage;
import com.acme.iam.appclient.AppClientService.AppClientView;
import com.acme.iam.appclient.AppClientService.RegisteredAppClient;
import com.acme.iam.common.security.PlatformGuard;
import jakarta.validation.Valid;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import java.net.URI;
import java.util.UUID;
import org.springframework.http.CacheControl;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/**
 * Platform API for application clients (P1-12.1); platform operators only: {@code platform.account.manage} held at
 * ACCOUNT scope by a user of the PLATFORM account ({@link PlatformGuard}, 403 {@code platform_account_required} /
 * {@code account_scope_required} otherwise).
 */
@RestController
@RequestMapping(AppClientController.PATH)
public class AppClientController {

  public static final String PATH = "/api/platform/app-clients";

  /** {@code clientId}: lower-case, 3-64 chars; {@code productCode}: upper-case product code (IAM, BILLING …). */
  public record RegisterAppClientRequest(
      @NotBlank @Pattern(regexp = "[a-z0-9][a-z0-9._-]{2,63}") String clientId,
      @NotBlank @Pattern(regexp = "[A-Z][A-Z0-9_]{1,31}") String productCode) {}

  private final AppClientService service;
  private final PlatformGuard platformGuard;

  public AppClientController(AppClientService service, PlatformGuard platformGuard) {
    this.service = service;
    this.platformGuard = platformGuard;
  }

  /** 201 with the client and its secret (shown once; {@code Cache-Control: no-store}). */
  @PostMapping
  @PreAuthorize("hasAuthority('platform.account.manage')")
  public ResponseEntity<RegisteredAppClient> register(@Valid @RequestBody RegisterAppClientRequest request) {
    platformGuard.requireOperator();
    RegisteredAppClient created = service.register(request.clientId(), request.productCode());
    return ResponseEntity.created(URI.create(PATH + "/" + created.id()))
        .cacheControl(CacheControl.noStore())
        .body(created);
  }

  @GetMapping
  @PreAuthorize("hasAuthority('platform.account.manage')")
  public AppClientPage list(@RequestParam(required = false) UUID after,
                            @RequestParam(defaultValue = "50") @Min(1) @Max(200) int limit) {
    platformGuard.requireOperator();
    return service.list(after, limit);
  }

  @DeleteMapping("/{id}")
  @PreAuthorize("hasAuthority('platform.account.manage')")
  public ResponseEntity<Void> delete(@PathVariable UUID id) {
    platformGuard.requireOperator();
    service.delete(id);
    return ResponseEntity.noContent().build();
  }

  /** Ruling R39: a new secret, shown once ({@code Cache-Control: no-store}); the old secret stops working at once. */
  @PostMapping("/{id}/rotate-secret")
  @PreAuthorize("hasAuthority('platform.account.manage')")
  public ResponseEntity<RegisteredAppClient> rotateSecret(@PathVariable UUID id) {
    platformGuard.requireOperator();
    return ResponseEntity.ok().cacheControl(CacheControl.noStore()).body(service.rotateSecret(id));
  }

  /**
   * ACTIVE → DISABLED (idempotent): the client can no longer obtain tokens ({@code invalid_client}, audited reason
   * {@code disabled}); app tokens it already holds stay valid until they expire ({@code app-token-ttl}, 10 min).
   */
  @PostMapping("/{id}/disable")
  @PreAuthorize("hasAuthority('platform.account.manage')")
  public AppClientView disable(@PathVariable UUID id) {
    platformGuard.requireOperator();
    return service.disable(id);
  }
}
