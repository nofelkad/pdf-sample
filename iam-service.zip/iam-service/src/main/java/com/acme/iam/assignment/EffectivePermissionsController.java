package com.acme.iam.assignment;

import com.acme.iam.assignment.EffectivePermissionsService.EffectivePermissions;
import com.acme.iam.common.error.BadRequestException;
import com.acme.iam.common.security.CodedAccessDeniedException;
import com.acme.iam.common.security.CurrentUser;
import com.acme.iam.common.security.TenantGuard;
import com.acme.iam.core.Claims;
import java.util.Map;
import java.util.UUID;
import org.springframework.lang.Nullable;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/**
 * {@code GET /api/users/{id}/effective-permissions?tenantId=} (P1-10.6): permission, then the roles and scopes that
 * grant it. {@code tenantId} defaults to the caller's active tenant.
 *
 * <p>Authorisation: {@code iam.user.read.account} held at ACCOUNT scope may explain any user of the account in any
 * tenant of the account (another tenant additionally needs an ACCOUNT-scope grant of it, see {@link TenantGuard});
 * {@code iam.user.read.tenant} only works for the caller's own active tenant and only for members of it (403
 * {@value TenantGuard#SCOPE_EXCEEDED} for another tenant). Since ruling R42 a TENANT-scope grant of
 * {@code iam.user.read.account} never reaches the token; the {@code hasAccountScope} re-check below is kept as a
 * redundant guard.
 */
@RestController
public class EffectivePermissionsController {

  public static final String ACCOUNT_READ = "iam.user.read.account";
  public static final String TENANT_READ = "iam.user.read.tenant";

  private final CurrentUser currentUser;
  private final TenantGuard tenantGuard;
  private final EffectivePermissionsService explainer;

  public EffectivePermissionsController(CurrentUser currentUser, TenantGuard tenantGuard,
      EffectivePermissionsService explainer) {
    this.currentUser = currentUser;
    this.tenantGuard = tenantGuard;
    this.explainer = explainer;
  }

  @GetMapping("/api/users/{id}/effective-permissions")
  @PreAuthorize("hasAnyAuthority('" + ACCOUNT_READ + "','" + TENANT_READ + "')")
  public EffectivePermissions explain(@PathVariable UUID id, @RequestParam(required = false) @Nullable UUID tenantId) {
    String tid = currentUser.jwt().getClaimAsString(Claims.TENANT);   // may be absent: no active tenant
    UUID activeTenant = tid == null ? null : UUID.fromString(tid);
    UUID target = tenantId != null ? tenantId : activeTenant;
    if (target == null) {
      throw new BadRequestException("tenant_required", "The token has no active tenant: pass tenantId");
    }
    // Task 9: the token's perms carry no scope; read.account counts as account level only at ACCOUNT scope
    boolean accountLevel = currentUser.hasPermission(ACCOUNT_READ) && tenantGuard.hasAccountScope(ACCOUNT_READ);
    if (!target.equals(activeTenant)) {
      if (!accountLevel) {
        throw new CodedAccessDeniedException(TenantGuard.SCOPE_EXCEEDED,
            "Reading another tenant requires " + ACCOUNT_READ, Map.of("requiredAuthority", ACCOUNT_READ));
      }
      tenantGuard.requireActive(target, ACCOUNT_READ);
    }
    return explainer.explain(currentUser.accountId(), id, target, !accountLevel);
  }
}
