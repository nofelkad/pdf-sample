package com.acme.iam.audit;

import java.time.YearMonth;
import java.util.Set;
import java.util.TreeSet;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.springframework.jdbc.core.simple.JdbcClient;
import org.springframework.stereotype.Component;

/**
 * Catalog view of the monthly partitions of {@code audit_event} (named {@code audit_event_yYYYYmMM}, covering that
 * month in UTC). Read straight from {@code pg_inherits}, so it always reflects what exists right now; the lookup is a
 * single cheap catalog query, which is why ingest simply asks per batch instead of caching.
 */
@Component
class AuditPartitions {

  static final Pattern NAME = Pattern.compile("audit_event_y(\\d{4})m(0[1-9]|1[0-2])");

  private static final String LIST_SQL = """
      SELECT c.relname
      FROM pg_inherits i JOIN pg_class c ON c.oid = i.inhrelid
      WHERE i.inhparent = 'public.audit_event'::regclass
      """;

  private final JdbcClient jdbc;

  AuditPartitions(JdbcClient jdbc) {
    this.jdbc = jdbc;
  }

  /** Months that currently have a partition, ascending. */
  Set<YearMonth> existing() {
    Set<YearMonth> months = new TreeSet<>();
    for (String name : jdbc.sql(LIST_SQL).query(String.class).list()) {
      Matcher m = NAME.matcher(name);
      if (m.matches()) {
        months.add(YearMonth.of(Integer.parseInt(m.group(1)), Integer.parseInt(m.group(2))));
      }
    }
    return months;
  }

  static String nameOf(YearMonth month) {
    return "audit_event_y%04dm%02d".formatted(month.getYear(), month.getMonthValue());
  }
}
