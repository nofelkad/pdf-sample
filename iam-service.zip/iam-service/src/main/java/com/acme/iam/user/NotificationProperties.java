package com.acme.iam.user;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.bind.DefaultValue;

/**
 * {@code iam.notification.*}.
 *
 * @param mode {@link Mode#LOG} (default) or {@link Mode#SMTP}; relaxed binding ({@code log}, {@code SMTP}, ...). Any
 *     other value fails binding, so the application does not start.
 * @param from sender address for SMTP mail
 * @param invitationUrl accept-invitation link; {@code {token}} is replaced by the raw token
 * @param passwordResetUrl password-reset link; {@code {token}} is replaced by the raw token
 * @param exposeActivationLink when {@code true} (default) API responses that create or re-invite a single user carry
 *     the activation link ({@link ActivationLinks}, ruling R46); {@code false} keeps links email-only
 */
@ConfigurationProperties("iam.notification")
public record NotificationProperties(
    @DefaultValue("log") Mode mode,
    @DefaultValue("no-reply@iam.local") String from,
    @DefaultValue("http://localhost:3000/invitations/accept?token={token}") String invitationUrl,
    @DefaultValue("http://localhost:3000/password/reset?token={token}") String passwordResetUrl,
    @DefaultValue("true") boolean exposeActivationLink) {

  public static final String TOKEN_PLACEHOLDER = "{token}";

  /** Which {@link NotificationPort} adapter is active. */
  public enum Mode {
    LOG,
    SMTP
  }

  public String invitationLink(String rawToken) {
    return invitationUrl.replace(TOKEN_PLACEHOLDER, rawToken);
  }

  public String passwordResetLink(String rawToken) {
    return passwordResetUrl.replace(TOKEN_PLACEHOLDER, rawToken);
  }
}
