package com.acme.iam.role;

import com.acme.iam.account.Account;
import com.acme.iam.account.AccountService;
import com.acme.iam.assignment.PermissionResolver;
import com.acme.iam.auth.RevocationService;
import com.acme.iam.common.error.BadRequestException;
import com.acme.iam.common.error.ConflictException;
import com.acme.iam.common.error.ForbiddenException;
import com.acme.iam.common.error.NotFoundException;
import com.acme.iam.common.jdbc.RetryOnDeadlock;
import com.acme.iam.product.Permission;
import com.acme.iam.product.Product;
import com.acme.iam.product.ProductService;
import java.time.Clock;
import java.time.LocalDate;
import java.time.ZoneOffset;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.stream.Collectors;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.data.relational.core.conversion.DbActionExecutionException;
import org.springframework.jdbc.core.simple.JdbcClient;
import org.springframework.lang.Nullable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * The role administration API's logic (P1-10.3): CUSTOM roles of the caller's account, plus read access to SYSTEM
 * roles. Every method takes the caller's account from the token (I10); another account's CUSTOM role is
 * indistinguishable from an unknown id ({@code 404 role_not_found}).
 *
 * <ul>
 *   <li><b>I8</b>: SYSTEM roles are read-only: a write is {@code 403 system_role_read_only}.
 *   <li><b>I3</b>: a CUSTOM role holds only permissions of its own product ({@link RoleService#validateCustomRolePermissions})
 *       and only deprecated-free ones are accepted; the product must be IAM or one the account is subscribed to
 *       ({@code 400 product_not_subscribed}).
 *   <li><b>I6 for role editing</b> (spec "separation of duties"): a role's permissions can only be added by someone who
 *       holds them at ACCOUNT scope, so a role editor cannot mint a role stronger than themselves and then assign it
 *       ({@code 403 grantor_lacks_permissions}, property {@code missingPermissions}). Removing permissions needs no
 *       such check.
 *   <li><b>Revocation</b>: any change to a role's permission set revokes every holder of the role
 *       ({@link RevocationService#revokeRoleHolders}) as the transaction's last write, not only shrinking edits:
 *       holders refresh and re-resolve, so a grown set is also picked up at once. An unchanged set writes nothing and
 *       revokes nobody.
 *   <li><b>Delete</b> is refused while any assignment row exists ({@code 409 role_in_use}, property {@code count}); the
 *       expiry job removes expired rows within minutes.
 * </ul>
 *
 * Name and description updates and the permission diff are targeted SQL, never {@code Role.save}, which would delete
 * and re-insert (and audit) every {@code role_permission} row.
 */
@Service
public class RoleAdminService {

  private final RoleRepository roles;
  private final RoleService roleService;
  private final ProductService products;
  private final AccountService accounts;
  private final PermissionResolver resolver;
  private final RevocationService revocations;
  private final JdbcClient jdbc;
  private final Clock clock;

  public RoleAdminService(RoleRepository roles, RoleService roleService, ProductService products,
      AccountService accounts, PermissionResolver resolver, RevocationService revocations, JdbcClient jdbc,
      Clock clock) {
    this.roles = roles;
    this.roleService = roleService;
    this.products = products;
    this.accounts = accounts;
    this.resolver = resolver;
    this.revocations = revocations;
    this.jdbc = jdbc;
    this.clock = clock;
  }

  /** A role the account can see (SYSTEM, or its own CUSTOM role) with its permissions. */
  @Transactional(readOnly = true)
  public RoleDetail get(UUID accountId, UUID roleId) {
    return detail(visible(accountId, roleId));
  }

  /**
   * Creates a CUSTOM role in the caller's account.
   *
   * @param grantorId the caller (I6: must hold every permission at ACCOUNT scope)
   */
  @RetryOnDeadlock
  @Transactional
  public RoleDetail create(UUID accountId, UUID grantorId, String productCode, String name,
      @Nullable String description, Collection<String> permissionCodes) {
    Product product = products.findByCode(productCode)
        .orElseThrow(() -> new NotFoundException("product_not_found", "Product not found"));
    requireSubscribed(accountId, product);
    List<Permission> permissions = resolveCodes(permissionCodes);
    roleService.validateCustomRolePermissions(product.id(), ids(permissions));
    requireHeldAtAccountScope(grantorId, accountId, permissions);
    try {
      Role saved = roles.save(Role.custom(product.id(), accountId, name.strip(), description, ids(permissions)));
      return detail(saved);
    } catch (DbActionExecutionException e) {
      throw translateDuplicate(e);
    }
  }

  /** Changes name and/or description ({@code null} keeps the current value). */
  @RetryOnDeadlock
  @Transactional
  public RoleDetail update(UUID accountId, UUID roleId, @Nullable String name, @Nullable String description) {
    if (name == null && description == null) {
      throw new BadRequestException("empty_update", "Provide a name or a description");
    }
    Role role = lockWritable(accountId, roleId);
    try {
      jdbc.sql("""
              UPDATE role SET name = COALESCE(CAST(:name AS text), name),
                              description = COALESCE(CAST(:description AS text), description),
                              updated_at = now(), version = version + 1
              WHERE id = :id""")
          .param("name", name == null ? null : name.strip())
          .param("description", description)
          .param("id", role.id())
          .update();
    } catch (DuplicateKeyException e) {
      throw nameExists();
    }
    return detail(roles.findById(roleId).orElseThrow());
  }

  /**
   * Replaces the role's permissions with exactly {@code permissionCodes}. A change revokes every holder.
   *
   * @param grantorId the caller (I6 applies to the permissions being added)
   */
  @RetryOnDeadlock
  @Transactional
  public RoleDetail setPermissions(UUID accountId, UUID grantorId, UUID roleId, Collection<String> permissionCodes) {
    Role role = lockWritable(accountId, roleId);
    List<Permission> permissions = resolveCodes(permissionCodes);
    roleService.validateCustomRolePermissions(role.product(), ids(permissions));

    Set<UUID> current = role.permissionIds();
    requireHeldAtAccountScope(grantorId, accountId,
        permissions.stream().filter(p -> !current.contains(p.id())).toList());

    RoleService.PermissionDiff diff = roleService.replacePermissions(role.id(), ids(permissions));
    if (diff.isEmpty()) {
      return detail(role);
    }
    jdbc.sql("UPDATE role SET updated_at = now(), version = version + 1 WHERE id = :id")
        .param("id", role.id()).update();
    RoleDetail result = detail(roles.findById(roleId).orElseThrow());
    revocations.revokeRoleHolders(role.id(), "role.permissions_changed"); // last write
    return result;
  }

  /** Deletes a CUSTOM role that nobody holds. */
  @RetryOnDeadlock
  @Transactional
  public void delete(UUID accountId, UUID roleId) {
    Role role = lockWritable(accountId, roleId);
    long count = jdbc.sql("SELECT count(*) FROM role_assignment WHERE role_id = :id")
        .param("id", role.id()).query(Long.class).single();
    if (count > 0) {
      throw new ConflictException("role_in_use", "The role is still assigned (" + count + " assignment"
          + (count == 1 ? "" : "s") + ")", Map.of("count", count));
    }
    jdbc.sql("DELETE FROM role WHERE id = :id").param("id", role.id()).update();
  }

  // ---------------------------------------------------------------------------------------------------------------

  /** The role if the account may see it; otherwise 404. */
  private Role visible(UUID accountId, UUID roleId) {
    Role role = roleService.findById(roleId)
        .orElseThrow(() -> new NotFoundException("role_not_found", "Role not found"));
    if (role.isCustom() && !accountId.equals(role.account())) {
      throw new NotFoundException("role_not_found", "Role not found");
    }
    return role;
  }

  /**
   * Locks the role row ({@code FOR UPDATE}, so concurrent edits, deletes and new assignments of the same role
   * serialise) and returns the freshly read, writable (CUSTOM, own account) role. The visibility and SYSTEM checks
   * run on a plain read first: a SYSTEM role (or another account's role) is refused without ever taking a row lock,
   * which would otherwise block concurrent assignments of, say, Account Admin until this transaction ends.
   */
  private Role lockWritable(UUID accountId, UUID roleId) {
    Role plain = visible(accountId, roleId); // 404 first
    if (plain.isSystem()) {
      throw new ForbiddenException("system_role_read_only", "SYSTEM roles are read-only");
    }
    jdbc.sql("SELECT id FROM role WHERE id = :id FOR UPDATE").param("id", roleId).query(UUID.class).optional()
        .orElseThrow(() -> new NotFoundException("role_not_found", "Role not found"));
    return visible(accountId, roleId); // re-read under the lock (type and account never change)
  }

  private void requireSubscribed(UUID accountId, Product product) {
    if (product.isIam()) {
      return;
    }
    Account account = accounts.getById(accountId);
    LocalDate today = LocalDate.now(clock.withZone(ZoneOffset.UTC));
    boolean subscribed = account.products().stream().anyMatch(ap -> ap.productId().equals(product.id())
        && ap.status().entitles() && (ap.endsAt() == null || !ap.endsAt().isBefore(today)));
    if (!subscribed) {
      throw new BadRequestException("product_not_subscribed",
          "The account is not subscribed to product " + product.code());
    }
  }

  /** The permissions for these codes, in request order; unknown or deprecated codes are rejected. */
  private List<Permission> resolveCodes(Collection<String> codes) {
    Set<String> wanted = new LinkedHashSet<>(codes);
    Map<String, Permission> found = products.findPermissionsByCodes(wanted).stream()
        .collect(Collectors.toMap(Permission::code, p -> p));
    List<String> unknown = wanted.stream().filter(c -> !found.containsKey(c)).sorted().toList();
    if (!unknown.isEmpty()) {
      throw new BadRequestException("unknown_permission", "Unknown permission codes",
          Map.of("permissionCodes", unknown));
    }
    List<String> deprecated = wanted.stream().filter(c -> found.get(c).deprecated()).sorted().toList();
    if (!deprecated.isEmpty()) {
      throw new BadRequestException("permission_deprecated", "Deprecated permissions cannot be added to a role",
          Map.of("permissionCodes", deprecated));
    }
    List<Permission> ordered = new ArrayList<>();
    wanted.forEach(c -> ordered.add(found.get(c)));
    return ordered;
  }

  /** I6: the grantor holds each permission through an ACCOUNT-scope assignment in the account. */
  private void requireHeldAtAccountScope(UUID grantorId, UUID accountId, Collection<Permission> adding) {
    if (adding.isEmpty()) {
      return;
    }
    Set<String> held = resolver.resolveAccountScope(grantorId, accountId);
    List<String> missing = adding.stream().map(Permission::code).filter(c -> !held.contains(c)).sorted().toList();
    if (!missing.isEmpty()) {
      throw new ForbiddenException("grantor_lacks_permissions",
          "You can only add permissions to a role that you hold at account scope",
          Map.of("missingPermissions", missing));
    }
  }

  private RoleDetail detail(Role role) {
    Product product = products.getById(role.product());
    List<RoleDetail.RolePermissionView> permissions = products.findPermissions(role.permissionIds()).stream()
        .sorted(Comparator.comparing(Permission::code))
        .map(p -> new RoleDetail.RolePermissionView(p.id(), p.code(), p.kind(), p.description(), p.deprecated()))
        .toList();
    return new RoleDetail(role.id(), product.id(), product.code(), role.name(), role.description(), role.type(),
        role.account(), permissions, role.createdAt(), role.updatedAt());
  }

  private static List<UUID> ids(Collection<Permission> permissions) {
    return permissions.stream().map(Permission::id).toList();
  }

  private static RuntimeException translateDuplicate(DbActionExecutionException e) {
    if (e.getCause() instanceof DuplicateKeyException) {
      return nameExists();
    }
    return e;
  }

  private static ConflictException nameExists() {
    return new ConflictException("role_name_exists", "A role with this name already exists for the product");
  }
}
