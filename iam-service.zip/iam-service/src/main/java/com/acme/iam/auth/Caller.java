package com.acme.iam.auth;

import com.acme.iam.common.security.CurrentUser;
import java.util.UUID;

/** The authenticated user of an {@code /auth} request, from the access token ({@code sub, acc, tid, sid}). */
public record Caller(UUID userId, UUID accountId, UUID tenantId, UUID sessionId) {

  public static Caller of(CurrentUser currentUser) {
    return new Caller(currentUser.userId(), currentUser.accountId(), currentUser.tenantId(), currentUser.sessionId());
  }
}
