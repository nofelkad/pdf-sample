package com.acme.iam.audit;

import com.acme.iam.audit.AuditEvent.ActorType;
import com.acme.iam.audit.AuditEvent.Outcome;
import com.acme.iam.common.error.BadRequestException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.time.Clock;
import java.time.DateTimeException;
import java.time.Duration;
import java.time.Instant;
import java.time.YearMonth;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.regex.Pattern;
import org.springframework.lang.Nullable;
import org.springframework.stereotype.Service;

/**
 * P1-9.4: validates and stores a batch of application audit events (the iam-client outbox relay's
 * {@code POST /internal/audit/events}).
 *
 * <ul>
 *   <li>At most {@value #MAX_BATCH} events per request, else 400 {@code batch_too_large} for the whole request.
 *   <li>Each event is validated on its own; failures go to {@link IngestResult#rejected()} with a snake_case reason
 *       and never fail the request. Required: {@code eventId} (UUID), {@code occurredAt} (ISO-8601 with offset),
 *       {@code action} ({@code [a-z0-9_.]{1,128}}), {@code outcome}, {@code actorType}. Strings are length-bounded;
 *       {@code before/after/metadata} must be JSON objects of at most {@value #MAX_PAYLOAD_BYTES} bytes each.
 *   <li>{@code occurredAt} must lie in an existing monthly partition (there is no DEFAULT partition) and at most
 *       {@value #MAX_FUTURE_MINUTES} minutes in the future, else {@code occurred_at_out_of_range}; it must also be
 *       newer than the retention cutoff ({@code iam.audit.retention}), so a row cannot land in a partition that the
 *       retention job has archived but not yet dropped.
 *   <li>{@code source} is always the caller's product code (token {@code prd}); a client-supplied value is ignored.
 *   <li>Storage goes through {@link AuditWriter#writeAll}, which applies the redaction deny-list and
 *       {@code ON CONFLICT DO NOTHING}, so a retried batch yields {@code duplicates}, not errors.
 * </ul>
 */
@Service
public class AuditIngestService {

  public static final int MAX_BATCH = 500;
  public static final int MAX_FUTURE_MINUTES = 5;
  public static final int MAX_PAYLOAD_BYTES = 32 * 1024;

  private static final Pattern ACTION = Pattern.compile("[a-z0-9_.]{1,128}");
  private static final Pattern UUID_TEXT =
      Pattern.compile("[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}");
  private static final TypeReference<Map<String, Object>> MAP = new TypeReference<>() {};
  private static final int MAX_IP = 64;
  private static final int MAX_USER_AGENT = 512;
  private static final int MAX_REQUEST_ID = 128;
  private static final int MAX_TARGET_TYPE = 128;
  private static final int MAX_TARGET_ID = 256;

  private final AuditWriter auditWriter;
  private final AuditPartitions partitions;
  private final ObjectMapper objectMapper;
  private final Clock clock;
  private final AuditRetentionService retention;

  public AuditIngestService(AuditWriter auditWriter, AuditPartitions partitions, ObjectMapper objectMapper,
                            Clock clock, AuditRetentionService retention) {
    this.retention = retention;
    this.auditWriter = auditWriter;
    this.partitions = partitions;
    this.objectMapper = objectMapper;
    this.clock = clock;
  }

  /**
   * @param source the calling product code ({@code prd} claim of the application token)
   * @param body   the parsed request body, {@code {"events": [...]}}
   * @throws BadRequestException {@code invalid_body} or {@code batch_too_large}
   */
  public IngestResult ingest(String source, JsonNode body) {
    JsonNode events = body == null ? null : body.get("events");
    if (body == null || !body.isObject() || events == null || !events.isArray()) {
      throw new BadRequestException("invalid_body", "Body must be an object with an \"events\" array");
    }
    if (events.size() > MAX_BATCH) {
      throw new BadRequestException("batch_too_large", "At most " + MAX_BATCH + " events per request",
          Map.of("max", MAX_BATCH, "submitted", events.size()));
    }
    if (events.isEmpty()) {
      return new IngestResult(0, 0, List.of());
    }

    Instant latest = clock.instant().plus(Duration.ofMinutes(MAX_FUTURE_MINUTES));
    Instant earliest = retention.cutoff();
    Set<YearMonth> months = partitions.existing();
    List<AuditEvent> valid = new ArrayList<>(events.size());
    List<IngestResult.Rejected> rejected = new ArrayList<>();
    int index = 0;
    for (JsonNode node : events) {
      try {
        valid.add(parse(node, source, earliest, latest, months));
      } catch (Invalid e) {
        rejected.add(new IngestResult.Rejected(echoId(node), index, e.reason));
      }
      index++;
    }

    int inserted = valid.isEmpty() ? 0 : auditWriter.writeAll(valid);
    int duplicates = events.size() - inserted - rejected.size();
    return new IngestResult(inserted, duplicates, List.copyOf(rejected));
  }

  private AuditEvent parse(JsonNode node, String source, Instant earliest, Instant latest,
                           Set<YearMonth> months) {
    if (!node.isObject()) {
      throw new Invalid("invalid_event");
    }
    UUID eventId = uuid(node, "eventId", "missing_event_id", "invalid_event_id", true);
    Instant occurredAt = occurredAt(node);
    String action = text(node, "action", "missing_action", "invalid_action", 128);
    if (!ACTION.matcher(action).matches()) {
      throw new Invalid("invalid_action");
    }
    Outcome outcome = enumValue(node, "outcome", Outcome.class, "missing_outcome", "invalid_outcome");
    ActorType actorType = enumValue(node, "actorType", ActorType.class, "missing_actor_type", "invalid_actor_type");
    UUID accountId = uuid(node, "accountId", null, "invalid_account_id", false);
    UUID tenantId = uuid(node, "tenantId", null, "invalid_tenant_id", false);
    UUID actorUserId = uuid(node, "actorUserId", null, "invalid_actor_user_id", false);
    UUID sessionId = uuid(node, "sessionId", null, "invalid_session_id", false);
    String actorIp = optionalText(node, "actorIp", MAX_IP);
    String userAgent = optionalText(node, "userAgent", MAX_USER_AGENT);
    String requestId = optionalText(node, "requestId", MAX_REQUEST_ID);
    String targetType = optionalText(node, "targetType", MAX_TARGET_TYPE);
    String targetId = optionalText(node, "targetId", MAX_TARGET_ID);
    Map<String, Object> before = payload(node, "before");
    Map<String, Object> after = payload(node, "after");
    Map<String, Object> metadata = payload(node, "metadata");

    if (occurredAt.isAfter(latest) || occurredAt.isBefore(earliest) || !months.contains(YearMonth.from(occurredAt.atOffset(ZoneOffset.UTC)))) {
      throw new Invalid("occurred_at_out_of_range");
    }
    return AuditEvent.builder(action)
        .eventId(eventId)
        .occurredAt(occurredAt)
        .accountId(accountId)
        .tenantId(tenantId)
        .source(source)
        .actorUserId(actorUserId)
        .actorType(actorType)
        .actorIp(actorIp)
        .userAgent(userAgent)
        .sessionId(sessionId)
        .requestId(requestId)
        .target(targetType, targetId)
        .outcome(outcome)
        .before(before)
        .after(after)
        .metadata(metadata)
        .build();
  }

  // ------------------------------------------------------------------------------------------ field parsing

  private static UUID uuid(JsonNode node, String field, @Nullable String missing, String invalid, boolean required) {
    JsonNode value = node.get(field);
    if (value == null || value.isNull()) {
      if (required) {
        throw new Invalid(missing);
      }
      return null;
    }
    if (!value.isTextual() || !UUID_TEXT.matcher(value.asText()).matches()) {
      throw new Invalid(invalid);
    }
    return UUID.fromString(value.asText());
  }

  private static Instant occurredAt(JsonNode node) {
    JsonNode value = node.get("occurredAt");
    if (value == null || value.isNull()) {
      throw new Invalid("missing_occurred_at");
    }
    if (!value.isTextual()) {
      throw new Invalid("invalid_occurred_at");
    }
    try {
      return DateTimeFormatter.ISO_OFFSET_DATE_TIME.parse(value.asText(), Instant::from);
    } catch (DateTimeException e) {
      throw new Invalid("invalid_occurred_at");
    }
  }

  private static String text(JsonNode node, String field, String missing, String invalid, int max) {
    JsonNode value = node.get(field);
    if (value == null || value.isNull()) {
      throw new Invalid(missing);
    }
    if (!value.isTextual() || value.asText().isEmpty()) {
      throw new Invalid(invalid);
    }
    String s = value.asText();
    if (s.length() > max) {
      throw new Invalid(invalid);
    }
    return s;
  }

  @Nullable
  private static String optionalText(JsonNode node, String field, int max) {
    JsonNode value = node.get(field);
    if (value == null || value.isNull()) {
      return null;
    }
    if (!value.isTextual()) {
      throw new Invalid("invalid_" + snake(field));
    }
    String s = value.asText();
    if (s.length() > max) {
      throw new Invalid("field_too_long");
    }
    if (s.indexOf('\0') >= 0) {
      throw new Invalid("invalid_characters");
    }
    return s;
  }

  private static <E extends Enum<E>> E enumValue(JsonNode node, String field, Class<E> type, String missing,
                                                 String invalid) {
    JsonNode value = node.get(field);
    if (value == null || value.isNull()) {
      throw new Invalid(missing);
    }
    if (value.isTextual()) {
      for (E constant : type.getEnumConstants()) {
        if (constant.name().equals(value.asText())) {
          return constant;
        }
      }
    }
    throw new Invalid(invalid);
  }

  @Nullable
  private Map<String, Object> payload(JsonNode node, String field) {
    JsonNode value = node.get(field);
    if (value == null || value.isNull()) {
      return null;
    }
    if (!value.isObject()) {
      throw new Invalid("invalid_payload");
    }
    String serialized = value.toString();
    if (serialized.getBytes(java.nio.charset.StandardCharsets.UTF_8).length > MAX_PAYLOAD_BYTES) {
      throw new Invalid("payload_too_large");
    }
    if (serialized.contains("\\u0000")) {
      throw new Invalid("invalid_characters");
    }
    return objectMapper.convertValue(value, MAP);
  }

  @Nullable
  private static String echoId(JsonNode node) {
    JsonNode id = node.isObject() ? node.get("eventId") : null;
    return id != null && id.isTextual() && UUID_TEXT.matcher(id.asText()).matches() ? id.asText().toLowerCase() : null;
  }

  private static String snake(String camel) {
    return camel.replaceAll("([A-Z])", "_$1").toLowerCase();
  }

  /** Control flow for a per-event validation failure. */
  private static final class Invalid extends RuntimeException {
    private final String reason;

    Invalid(String reason) {
      super(reason, null, false, false);
      this.reason = reason;
    }
  }
}
