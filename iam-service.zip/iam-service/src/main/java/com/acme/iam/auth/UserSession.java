package com.acme.iam.auth;

import com.acme.iam.tenant.Tenant;
import com.acme.iam.user.AppUser;
import java.time.Instant;
import java.util.UUID;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.Id;
import org.springframework.data.annotation.Version;
import org.springframework.data.jdbc.core.mapping.AggregateReference;
import org.springframework.data.relational.core.mapping.Table;
import org.springframework.lang.Nullable;

/**
 * Login session ({@code user_session}) holding the SHA-256 of the current refresh token and of the previous one (reuse
 * detection). Lives in {@code auth} because only the session/login code uses it.
 *
 * @param ip client address as text; bound untyped ({@code stringtype=unspecified}) so Postgres casts it to INET
 */
@Table("user_session")
public record UserSession(
    @Id UUID id,
    AggregateReference<AppUser, UUID> userId,
    AggregateReference<Tenant, UUID> activeTenantId,
    byte[] refreshHash,
    @Nullable byte[] prevRefreshHash,
    @Nullable String ip,
    @Nullable String userAgent,
    @CreatedDate Instant createdAt,
    Instant lastSeenAt,
    Instant expiresAt,
    @Nullable Instant revokedAt,
    @Version Long version) {

  public static UserSession open(UUID userId, UUID activeTenantId, byte[] refreshHash, @Nullable String ip,
      @Nullable String userAgent, Instant now, Instant expiresAt) {
    return new UserSession(null, AggregateReference.to(userId), AggregateReference.to(activeTenantId),
        refreshHash.clone(), null, ip, userAgent, null, now, expiresAt, null, null);
  }

  public UUID user() {
    return userId.getId();
  }

  public UUID activeTenant() {
    return activeTenantId.getId();
  }

  public boolean isActive(Instant now) {
    return revokedAt == null && expiresAt.isAfter(now);
  }

  /** Rotates the refresh token: the current hash becomes {@code prevRefreshHash}. */
  public UserSession rotate(byte[] newRefreshHash, Instant now) {
    return new UserSession(id, userId, activeTenantId, newRefreshHash.clone(), refreshHash, ip, userAgent, createdAt,
        now, expiresAt, revokedAt, version);
  }

  public UserSession withActiveTenant(UUID tenantId) {
    return new UserSession(id, userId, AggregateReference.to(tenantId), refreshHash, prevRefreshHash, ip, userAgent,
        createdAt, lastSeenAt, expiresAt, revokedAt, version);
  }

  public UserSession revoke(Instant now) {
    return new UserSession(id, userId, activeTenantId, refreshHash, prevRefreshHash, ip, userAgent, createdAt,
        lastSeenAt, expiresAt, now, version);
  }
}
