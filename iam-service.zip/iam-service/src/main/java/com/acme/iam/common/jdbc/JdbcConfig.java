package com.acme.iam.common.jdbc;

import com.acme.iam.common.Ids;
import com.acme.iam.common.RequestActor;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.json.JsonMapper;
import java.sql.SQLException;
import java.time.Clock;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import javax.sql.DataSource;
import org.postgresql.util.PGobject;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.boot.autoconfigure.transaction.TransactionManagerCustomizers;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.core.convert.converter.Converter;
import org.springframework.data.auditing.DateTimeProvider;
import org.springframework.data.convert.ReadingConverter;
import org.springframework.data.convert.WritingConverter;
import org.springframework.data.domain.AuditorAware;
import org.springframework.data.jdbc.core.convert.JdbcConverter;
import org.springframework.data.jdbc.repository.config.AbstractJdbcConfiguration;
import org.springframework.data.jdbc.repository.config.EnableJdbcAuditing;
import org.springframework.data.mapping.PersistentPropertyAccessor;
import org.springframework.data.relational.core.mapping.RelationalPersistentEntity;
import org.springframework.data.relational.core.mapping.RelationalPersistentProperty;
import org.springframework.data.relational.core.mapping.event.BeforeConvertCallback;

/**
 * Spring Data JDBC configuration (spec section 3).
 *
 * <ul>
 *   <li>Converters: {@code JSONB <-> Map<String,Object>}, {@code JSONB <-> JsonNode}, {@code CITEXT -> String}
 *       (Strings are written as untyped parameters, see {@code stringtype=unspecified} in application.yml). Enums are
 *       stored by {@code name()} in TEXT columns (Spring Data JDBC default).
 *   <li>{@code @EnableJdbcAuditing}: {@code @CreatedDate/@LastModifiedDate} from the {@link Clock} bean,
 *       {@code @CreatedBy/@LastModifiedBy} from {@link RequestActor#current()} as {@code UUID}.
 *   <li>UUIDv7 ids: aggregates saved with a {@code null} {@code UUID @Id} get {@link Ids#newId()} before insert.
 *   <li>{@link AuditContextTransactionManager} as the primary transaction manager.
 * </ul>
 */
@Configuration(proxyBeanMethods = false)
@EnableJdbcAuditing(auditorAwareRef = "auditorAware", dateTimeProviderRef = "auditingDateTimeProvider")
public class JdbcConfig extends AbstractJdbcConfiguration {

  private final ObjectMapper objectMapper;

  public JdbcConfig(ObjectProvider<ObjectMapper> objectMapper) {
    this.objectMapper = objectMapper.getIfAvailable(() -> JsonMapper.builder().findAndAddModules().build());
  }

  @Override
  protected List<?> userConverters() {
    return List.of(
        new MapToJsonbConverter(objectMapper),
        new JsonbToMapConverter(objectMapper),
        new JsonNodeToJsonbConverter(objectMapper),
        new JsonbToJsonNodeConverter(objectMapper),
        new PgObjectToStringConverter());
  }

  @Bean
  @Primary
  public AuditContextTransactionManager transactionManager(
      DataSource dataSource, ObjectProvider<TransactionManagerCustomizers> customizers) {
    AuditContextTransactionManager transactionManager = new AuditContextTransactionManager(dataSource);
    customizers.ifAvailable(c -> c.customize(transactionManager));
    return transactionManager;
  }

  /** UTC system clock; inject it (instead of {@code Instant.now()}) wherever time matters so tests can fix it. */
  @Bean
  public Clock clock() {
    return Clock.systemUTC();
  }

  @Bean
  public AuditorAware<UUID> auditorAware() {
    return () -> Optional.ofNullable(RequestActor.current().userUuid());
  }

  @Bean
  public DateTimeProvider auditingDateTimeProvider(Clock clock) {
    return () -> Optional.of(clock.instant());
  }

  @Bean
  public BeforeConvertCallback<Object> uuidV7IdAssigner(ObjectProvider<JdbcConverter> converter) {
    return new UuidV7IdAssigner(converter);
  }

  /** Assigns {@link Ids#newId()} to a {@code null} {@code UUID} id before an aggregate is converted for insert. */
  static final class UuidV7IdAssigner implements BeforeConvertCallback<Object> {

    private final ObjectProvider<JdbcConverter> converter;

    UuidV7IdAssigner(ObjectProvider<JdbcConverter> converter) {
      this.converter = converter;
    }

    @Override
    @SuppressWarnings("unchecked")
    public Object onBeforeConvert(Object aggregate) {
      JdbcConverter jdbcConverter = converter.getObject();
      RelationalPersistentEntity<Object> entity = (RelationalPersistentEntity<Object>)
          jdbcConverter.getMappingContext().getPersistentEntity(aggregate.getClass());
      if (entity == null || !entity.hasIdProperty()) {
        return aggregate;
      }
      RelationalPersistentProperty id = entity.getRequiredIdProperty();
      if (!UUID.class.equals(id.getType())) {
        return aggregate;
      }
      PersistentPropertyAccessor<Object> accessor = jdbcConverter.getPropertyAccessor(entity, aggregate);
      if (accessor.getProperty(id) != null) {
        return aggregate;
      }
      accessor.setProperty(id, Ids.newId());
      return accessor.getBean();
    }
  }

  private static PGobject jsonb(ObjectMapper mapper, Object value) {
    try {
      PGobject object = new PGobject();
      object.setType("jsonb");
      object.setValue(mapper.writeValueAsString(value));
      return object;
    } catch (JsonProcessingException | SQLException e) {
      throw new IllegalArgumentException("Cannot write value as JSONB", e);
    }
  }

  @WritingConverter
  static final class MapToJsonbConverter implements Converter<Map<String, Object>, PGobject> {
    private final ObjectMapper mapper;

    MapToJsonbConverter(ObjectMapper mapper) {
      this.mapper = mapper;
    }

    @Override
    public PGobject convert(Map<String, Object> source) {
      return jsonb(mapper, source);
    }
  }

  @ReadingConverter
  static final class JsonbToMapConverter implements Converter<PGobject, Map<String, Object>> {
    private static final TypeReference<Map<String, Object>> MAP = new TypeReference<>() {};
    private final ObjectMapper mapper;

    JsonbToMapConverter(ObjectMapper mapper) {
      this.mapper = mapper;
    }

    @Override
    public Map<String, Object> convert(PGobject source) {
      try {
        return source.getValue() == null ? null : mapper.readValue(source.getValue(), MAP);
      } catch (JsonProcessingException e) {
        throw new IllegalArgumentException("Cannot read JSONB as Map", e);
      }
    }
  }

  @WritingConverter
  static final class JsonNodeToJsonbConverter implements Converter<JsonNode, PGobject> {
    private final ObjectMapper mapper;

    JsonNodeToJsonbConverter(ObjectMapper mapper) {
      this.mapper = mapper;
    }

    @Override
    public PGobject convert(JsonNode source) {
      return jsonb(mapper, source);
    }
  }

  @ReadingConverter
  static final class JsonbToJsonNodeConverter implements Converter<PGobject, JsonNode> {
    private final ObjectMapper mapper;

    JsonbToJsonNodeConverter(ObjectMapper mapper) {
      this.mapper = mapper;
    }

    @Override
    public JsonNode convert(PGobject source) {
      try {
        return source.getValue() == null ? null : mapper.readTree(source.getValue());
      } catch (JsonProcessingException e) {
        throw new IllegalArgumentException("Cannot read JSONB as JsonNode", e);
      }
    }
  }

  /** CITEXT (and other driver-specific types) arrive as {@link PGobject}; String properties take the raw value. */
  @ReadingConverter
  static final class PgObjectToStringConverter implements Converter<PGobject, String> {
    @Override
    public String convert(PGobject source) {
      return source.getValue();
    }
  }
}
