package com.acme.iam.user;

/** {@code app_user.status}. Users are never hard-deleted (I9): they become DEPROVISIONED. */
public enum UserStatus {
  INVITED,
  ACTIVE,
  DISABLED,
  DEPROVISIONED
}
