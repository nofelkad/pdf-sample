package com.acme.iam.auth;

import com.acme.iam.common.error.BadRequestException;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.lang.Nullable;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

/**
 * Password hashing (Argon2id, the {@code PasswordEncoder} bean from {@code JwtConfig}) and the per-account password
 * policy (P1-5.1).
 *
 * <p>{@link #matches} always runs exactly one Argon2 verification, also when there is no stored hash: it then verifies
 * against a dummy hash computed once at startup, so "no such user" and "wrong password" cost the same (P1-5.2).
 */
@Service
public class PasswordService {

  /** Error code of every policy rejection; the violations are in the {@value #VIOLATIONS} property. */
  public static final String POLICY_CODE = "password_policy";
  public static final String VIOLATIONS = "violations";
  public static final String TOO_SHORT = "too_short";
  public static final String TOO_LONG = "too_long";
  public static final String REUSED = "reused";
  public static final String BREACHED = "breached";

  private final PasswordEncoder encoder;
  private final BreachedPasswordChecker breachedChecker;
  private final PasswordPolicy defaults;
  private final String dummyHash;

  @Autowired
  public PasswordService(PasswordEncoder encoder, BreachedPasswordChecker breachedChecker, AuthProperties properties) {
    this(encoder, breachedChecker, properties.passwordPolicy().toPolicy());
  }

  public PasswordService(PasswordEncoder encoder, BreachedPasswordChecker breachedChecker, PasswordPolicy defaults) {
    this.encoder = encoder;
    this.breachedChecker = breachedChecker;
    this.defaults = defaults;
    byte[] random = new byte[24];
    new SecureRandom().nextBytes(random);
    this.dummyHash = encoder.encode(Base64.getEncoder().encodeToString(random));
  }

  public String hash(String rawPassword) {
    return encoder.encode(rawPassword);
  }

  /** One Argon2 verification; a {@code null} hash verifies against the dummy hash and returns {@code false}. */
  public boolean matches(String rawPassword, @Nullable String hash) {
    if (hash == null) {
      encoder.matches(rawPassword, dummyHash);
      return false;
    }
    return encoder.matches(rawPassword, hash);
  }

  /** The account's policy ({@code settings.passwordPolicy} over the configured defaults). */
  public PasswordPolicy policy(@Nullable Map<String, Object> accountSettings) {
    return PasswordPolicy.from(accountSettings, defaults);
  }

  /**
   * Validates a new password.
   *
   * @param previousHashes the current hash followed by the history, newest first; the first
   *     {@code policy.historySize()} (at least the current one) may not match
   * @throws BadRequestException {@value #POLICY_CODE} with {@code violations} (e.g. {@code ["too_short"]})
   */
  public void validate(PasswordPolicy policy, String rawPassword, Collection<String> previousHashes) {
    List<String> violations = new ArrayList<>();
    int length = rawPassword == null ? 0 : rawPassword.codePointCount(0, rawPassword.length());
    if (length < policy.minLength()) {
      violations.add(TOO_SHORT);
    }
    if (length > policy.maxLength()) {
      violations.add(TOO_LONG);
    }
    if (violations.isEmpty()) {
      int checked = Math.max(policy.historySize(), 1);
      if (previousHashes.stream().limit(checked).anyMatch(h -> h != null && encoder.matches(rawPassword, h))) {
        violations.add(REUSED);
      }
      if (policy.breachedCheck() && breachedChecker.isBreached(rawPassword)) {
        violations.add(BREACHED);
      }
    }
    if (!violations.isEmpty()) {
      throw new BadRequestException(POLICY_CODE, "The password does not meet the password policy",
          Map.of(VIOLATIONS, List.copyOf(violations), "minLength", policy.minLength(),
              "maxLength", policy.maxLength()));
    }
  }
}
