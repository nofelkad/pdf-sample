package com.acme.iam.user;

import java.util.Optional;
import java.util.UUID;
import org.springframework.data.jdbc.repository.query.Query;
import org.springframework.data.repository.ListCrudRepository;

/** Persistence of the {@link AppUser} aggregate. Private to the {@code user} feature; use {@link UserService}. */
public interface AppUserRepository extends ListCrudRepository<AppUser, UUID> {

  /** Case-insensitive (CITEXT) lookup of a user by email inside one account. */
  @Query("SELECT * FROM app_user WHERE account_id = :accountId AND email = :email")
  Optional<AppUser> findByAccountAndEmail(UUID accountId, String email);

  @Query("SELECT * FROM app_user WHERE id = :id AND account_id = :accountId")
  Optional<AppUser> findByIdInAccount(UUID id, UUID accountId);
}
