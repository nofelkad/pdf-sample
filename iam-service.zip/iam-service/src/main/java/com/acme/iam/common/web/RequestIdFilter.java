package com.acme.iam.common.web;

import com.acme.iam.common.Ids;
import com.acme.iam.common.RequestActor;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.regex.Pattern;
import org.slf4j.MDC;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.lang.Nullable;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

/**
 * Assigns every request an id: the caller's {@code X-Request-Id} when it is well formed, otherwise a new UUIDv7.
 * The id is echoed in the {@code X-Request-Id} response header (set before the chain runs, so it is present on every
 * response including security rejections and errors), stored in the MDC under {@value RequestActor#MDC_REQUEST_ID}
 * (JSON logs, audit context) and as request attribute {@link #ATTRIBUTE}.
 *
 * <p>Ordered first, ahead of the Spring Security filter chain.
 */
@Component
@Order(Ordered.HIGHEST_PRECEDENCE)
public class RequestIdFilter extends OncePerRequestFilter {

  public static final String HEADER = "X-Request-Id";
  public static final String ATTRIBUTE = RequestIdFilter.class.getName() + ".requestId";

  /** Accepted inbound ids: 1-64 chars of letters, digits, '.', '_', '-' (keeps logs and audit rows clean). */
  private static final Pattern VALID = Pattern.compile("[A-Za-z0-9._-]{1,64}");

  @Override
  protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain chain)
      throws ServletException, IOException {
    String requestId = resolve(request);
    request.setAttribute(ATTRIBUTE, requestId);
    response.setHeader(HEADER, requestId);
    String previous = MDC.get(RequestActor.MDC_REQUEST_ID);
    MDC.put(RequestActor.MDC_REQUEST_ID, requestId);
    try {
      chain.doFilter(request, response);
    } finally {
      if (previous == null) {
        MDC.remove(RequestActor.MDC_REQUEST_ID);
      } else {
        MDC.put(RequestActor.MDC_REQUEST_ID, previous);
      }
    }
  }

  /** Also run on ERROR dispatches so the MDC holds the same id while the error is rendered. */
  @Override
  protected boolean shouldNotFilterErrorDispatch() {
    return false;
  }

  /** The current request id: MDC first, then the request attribute; {@code null} outside a request. */
  @Nullable
  public static String currentRequestId(@Nullable HttpServletRequest request) {
    String fromMdc = MDC.get(RequestActor.MDC_REQUEST_ID);
    if (fromMdc != null) {
      return fromMdc;
    }
    return request == null ? null : (String) request.getAttribute(ATTRIBUTE);
  }

  private static String resolve(HttpServletRequest request) {
    Object existing = request.getAttribute(ATTRIBUTE); // ERROR dispatch of a request we already tagged
    if (existing instanceof String id) {
      return id;
    }
    String inbound = request.getHeader(HEADER);
    if (inbound != null && VALID.matcher(inbound).matches()) {
      return inbound;
    }
    return Ids.newId().toString();
  }
}
