package com.acme.iam.observability;

import org.springframework.boot.actuate.health.Status;

/**
 * Health status of the readiness-only contributors. Not part of Spring Boot's default status order, so the aggregate
 * health ignores it; the {@code readiness} group ranks it (between {@code OUT_OF_SERVICE} and {@code UNKNOWN}) and
 * maps it to HTTP 503.
 */
public final class ReadinessStatus {

  public static final Status NOT_READY = new Status("NOT_READY", "Not ready to take traffic");

  private ReadinessStatus() {}
}
