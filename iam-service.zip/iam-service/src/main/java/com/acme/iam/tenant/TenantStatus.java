package com.acme.iam.tenant;

/** {@code tenant.status}. */
public enum TenantStatus {
  ACTIVE,
  SUSPENDED,
  ARCHIVED
}
