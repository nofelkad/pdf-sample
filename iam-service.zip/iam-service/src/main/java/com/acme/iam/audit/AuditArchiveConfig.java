package com.acme.iam.audit;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Fallback;

/**
 * The default {@link AuditArchiveHook}. {@link Fallback} makes it lose against any other {@code AuditArchiveHook} bean
 * at injection time, independent of the order in which configuration classes are processed (which
 * {@code @ConditionalOnMissingBean} outside auto-configuration is not).
 */
@Configuration(proxyBeanMethods = false)
class AuditArchiveConfig {

  static final String MODE_NONE_ACKNOWLEDGED = "none-acknowledged";

  @Bean
  @Fallback
  AuditArchiveHook auditArchiveHook(@Value("${iam.audit.archive.mode:}") String mode) {
    return MODE_NONE_ACKNOWLEDGED.equals(mode) ? new AcknowledgedNoArchiveHook() : new RefusingArchiveHook();
  }
}
