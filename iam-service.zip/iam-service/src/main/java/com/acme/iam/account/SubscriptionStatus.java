package com.acme.iam.account;

/** {@code account_product.status}. Only ACTIVE and TRIAL (and not past {@code ends_at}) entitle an account. */
public enum SubscriptionStatus {
  ACTIVE,
  TRIAL,
  SUSPENDED,
  EXPIRED;

  /** {@code true} for the statuses the permission resolver treats as entitled. */
  public boolean entitles() {
    return this == ACTIVE || this == TRIAL;
  }
}
