package com.acme.iam.user;

import com.acme.iam.common.paging.KeysetCursor;
import com.acme.iam.common.paging.KeysetPage;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.OffsetDateTime;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import org.springframework.jdbc.core.simple.JdbcClient;
import org.springframework.lang.Nullable;
import org.springframework.stereotype.Service;

/**
 * User list read model (P1-3.4): keyset-paginated, newest first, always filtered by account (I10).
 *
 * <p>The SQL is assembled from fixed fragments for exactly the filters given (values are always bound), so every
 * filter combination gets its own index-friendly plan instead of one generic {@code (:p IS NULL OR ...)} plan. Indexes:
 * {@code app_user_account_created_idx}, {@code app_user_account_status_created_idx} (V10), membership and assignment
 * primary/unique keys for the {@code EXISTS} probes.
 */
@Service
public class UserQueryService {

  private final JdbcClient jdbc;

  public UserQueryService(JdbcClient jdbc) {
    this.jdbc = jdbc;
  }

  /**
   * One page of the account's users.
   *
   * @param accountId the caller's account ({@code acc}); never taken from the request
   * @param cursor {@code nextCursor} of the previous page, or {@code null} for the first page
   * @param limit page size, default 50, capped at 200
   */
  public KeysetPage<UserSummary> list(UUID accountId, UserListFilter filter, @Nullable String cursor,
      @Nullable Integer limit) {
    int size = KeysetPage.limit(limit);
    Optional<KeysetCursor> after = KeysetCursor.decode(cursor);

    JdbcClient.StatementSpec spec = jdbc.sql(sql(filter, after.isPresent()))
        .param("accountId", accountId)
        .param("limit", size + 1);
    if (filter.status() != null) {
      spec = spec.param("status", filter.status().name());
    }
    if (filter.tenantId() != null) {
      spec = spec.param("tenantId", filter.tenantId());
    }
    if (filter.roleId() != null) {
      spec = spec.param("roleId", filter.roleId());
    }
    if (after.isPresent()) {
      spec = spec.param("cursorAt", after.get().createdAtParam()).param("cursorId", after.get().id());
    }
    List<UserSummary> rows = spec.query((rs, i) -> map(rs)).list();
    return KeysetPage.of(rows, size, UserSummary::createdAt, UserSummary::id);
  }

  /**
   * The list SQL for exactly the given filters. Parameters: {@code :accountId}, {@code :limit} and, when used,
   * {@code :status}, {@code :tenantId}, {@code :roleId}, {@code :cursorAt}, {@code :cursorId}.
   */
  static String sql(UserListFilter filter, boolean withCursor) {
    StringBuilder sql = new StringBuilder("""
        SELECT u.id, u.email, u.display_name, u.status, u.primary_tenant_id, u.last_login_at, u.created_at
        FROM app_user u
        WHERE u.account_id = :accountId
        """);
    if (filter.status() != null) {
      sql.append("  AND u.status = :status\n");
    }
    if (filter.tenantId() != null) {
      sql.append("  AND EXISTS (SELECT 1 FROM user_tenant_membership m WHERE m.app_user = u.id AND m.tenant_id = :tenantId)\n");
    }
    if (filter.roleId() != null) {
      sql.append("""
            AND EXISTS (SELECT 1 FROM role_assignment ra
                        WHERE ra.user_id = u.id AND ra.role_id = :roleId
                          AND (ra.expires_at IS NULL OR ra.expires_at > now())
          """);
      if (filter.tenantId() != null) {
        sql.append("""
                            AND ((ra.scope_type = 'TENANT' AND ra.scope_id = :tenantId)
                              OR (ra.scope_type = 'ACCOUNT' AND ra.scope_id = :accountId))
            """);
      }
      sql.append("            )\n");
    }
    if (withCursor) {
      sql.append("  AND (u.created_at, u.id) < (:cursorAt, :cursorId)\n");
    }
    sql.append("ORDER BY u.created_at DESC, u.id DESC\nLIMIT :limit");
    return sql.toString();
  }

  private static UserSummary map(ResultSet rs) throws SQLException {
    OffsetDateTime lastLogin = rs.getObject("last_login_at", OffsetDateTime.class);
    return new UserSummary(
        rs.getObject("id", UUID.class),
        rs.getString("email"),
        rs.getString("display_name"),
        UserStatus.valueOf(rs.getString("status")),
        rs.getObject("primary_tenant_id", UUID.class),
        lastLogin == null ? null : lastLogin.toInstant(),
        rs.getObject("created_at", OffsetDateTime.class).toInstant());
  }
}
