package com.acme.iam.auth;

import com.acme.iam.assignment.PermissionResolver;
import com.acme.iam.audit.AuditEvent.Outcome;
import com.acme.iam.common.security.AccessTokenClaims;
import com.acme.iam.common.security.IssuedJwt;
import com.acme.iam.common.security.JwtIssuer;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.time.Clock;
import java.time.Instant;
import java.util.Base64;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import org.springframework.stereotype.Service;

/**
 * Login sessions (P1-5.3 – P1-5.5): open, refresh with rotation and reuse detection, idle/absolute timeout, tenant
 * switch, logout and logout-all.
 *
 * <p><b>Refresh token:</b> 32 random bytes, base64url without padding (43 chars), returned once; the session stores
 * {@code SHA-256} over the token string's US-ASCII bytes. Every refresh and tenant switch rotates it; the previous hash
 * stays in {@code prev_refresh_hash}.
 *
 * <p><b>Reuse detection (R22):</b> presenting a previous refresh token revokes that session ({@code revoked_at}),
 * revokes the user's access tokens ({@code RevocationService.revokeUsers([user], "refresh_reuse")}), audits
 * {@value AuthAuditService#REFRESH_REUSE_DETECTED} and answers 401 {@code invalid_refresh_token}. Two concurrent
 * refreshes with the same token count as reuse: the second waits for the first's row lock and then finds only the
 * previous hash (R30: strict reuse). A previous token of an already revoked session is audited but revokes nothing
 * again. <b>Limitation (deferred):</b> only the immediately previous token is remembered; a token two or more
 * rotations old is merely unknown (401 {@code invalid_refresh_token}, {@value AuthAuditService#REFRESH_FAILED}) and
 * does not revoke the session.
 *
 * <p><b>Re-checks (R17):</b> refresh re-checks user, account, active tenant and membership; switch-tenant re-checks
 * user and account (failure ends the session: {@code revoked_at}, 401 {@code session_invalid}) and requires an ACTIVE
 * membership in an ACTIVE target tenant of the account (403 {@code tenant_not_accessible}, session kept). Both
 * re-resolve permissions ({@code PermissionResolver.resolve}) and read the current {@code session_version}.
 *
 * <p><b>Logout (R22):</b> revokes the session and calls {@code revokeUsers([sub], reason)} as the transaction's last
 * write, so the presented access token is rejected on the next request once the revocation feed is polled.
 */
@Service
public class SessionService {

  public static final String REASON_REUSE = "refresh_reuse";
  public static final String REASON_LOGOUT = "logout";
  public static final String REASON_LOGOUT_ALL = "logout_all";

  private static final int REFRESH_TOKEN_BYTES = 32;
  private static final SecureRandom RANDOM = new SecureRandom();

  record OpenedSession(UUID sessionId, String refreshToken, Instant refreshExpiresAt) {
    @Override
    public String toString() {
      return "OpenedSession[sessionId=" + sessionId + ", refreshExpiresAt=" + refreshExpiresAt + "]";
    }
  }

  private final UserSessionRepository sessions;
  private final AccessStateQuery access;
  private final PermissionResolver permissions;
  private final JwtIssuer jwtIssuer;
  private final RevocationService revocations;
  private final AuthAuditService audit;
  private final AuthTransactions tx;
  private final AuthProperties properties;
  private final Clock clock;

  public SessionService(UserSessionRepository sessions, AccessStateQuery access, PermissionResolver permissions,
                        JwtIssuer jwtIssuer, RevocationService revocations, AuthAuditService audit,
                        AuthTransactions tx, AuthProperties properties, Clock clock) {
    this.sessions = sessions;
    this.access = access;
    this.permissions = permissions;
    this.jwtIssuer = jwtIssuer;
    this.revocations = revocations;
    this.audit = audit;
    this.tx = tx;
    this.properties = properties;
    this.clock = clock;
  }

  // ------------------------------------------------------------------------------------------------ refresh

  /**
   * Rotates the refresh token and issues a new access token.
   *
   * @throws com.acme.iam.common.error.ApiException 401 {@code invalid_refresh_token} (unknown, reused, revoked,
   *     expired, idle) or 401 {@code session_invalid} (R17 re-check failed; the session is revoked)
   */
  public AuthTokens refresh(String rawRefreshToken, ClientInfo client) {
    byte[] hash = hash(rawRefreshToken);
    return tx.<AuthTransactions.Outcome<AuthTokens>>write(() -> {
      Instant now = clock.instant();
      Optional<UserSession> found = sessions.lockByRefreshHash(hash);
      if (found.isEmpty()) {
        return sessions.lockByPrevRefreshHash(hash)
            .map(reused -> reuseDetected(reused, now, client))
            .orElseGet(() -> refreshFailed(null, "unknown_token", client));
      }
      UserSession session = found.get();
      if (session.revokedAt() != null) {
        return refreshFailed(session, "session_revoked", client);
      }
      Optional<AccessState> loaded = access.load(session.user(), session.activeTenant());
      if (loaded.isEmpty()) {
        return refreshFailed(session, "user_not_found", client);
      }
      AccessState state = loaded.get();
      SessionTtl ttl = ttl(state);
      if (!session.expiresAt().isAfter(now)) {
        return refreshFailed(session, "session_expired", client);
      }
      if (ttl.isIdle(session.lastSeenAt(), now)) {
        return refreshFailed(session, "session_idle", client);
      }
      Optional<String> denial = state.denial();
      if (denial.isPresent()) {
        return invalidate(session, state, denial.get(), client, now);
      }
      String refreshToken = newRefreshToken();
      sessions.rotate(session.id(), hash(refreshToken), now);
      audit.event(AuthAuditService.REFRESH, client)
          .user(state.userId(), state.accountId(), session.activeTenant(), session.id()).write();
      return AuthTransactions.Outcome.ok(issue(state.userId(), state.accountId(), session.activeTenant(), session.id(),
          state.sessionVersion(), refreshToken, ttl.refreshExpiresAt(session.expiresAt(), now)));
    }).get();
  }

  private AuthTransactions.Outcome<AuthTokens> reuseDetected(UserSession reused, Instant now, ClientInfo client) {
    boolean wasActive = reused.revokedAt() == null;
    if (wasActive) {
      sessions.revoke(reused.id(), now);
    }
    UUID accountId = access.load(reused.user(), reused.activeTenant()).map(AccessState::accountId).orElse(null);
    audit.event(AuthAuditService.REFRESH_REUSE_DETECTED, client)
        .subject(reused.user(), accountId)
        .tenant(reused.activeTenant())
        .session(reused.id())
        .outcome(Outcome.DENIED)
        .meta("session_was_active", wasActive)
        .write();
    if (wasActive) {
      revocations.revokeUsers(List.of(reused.user()), REASON_REUSE); // last write
    }
    return AuthTransactions.Outcome.fail(AuthErrors.invalidRefreshToken());
  }

  private AuthTransactions.Outcome<AuthTokens> refreshFailed(UserSession session, String reason, ClientInfo client) {
    AuthAuditService.Entry event = audit.event(AuthAuditService.REFRESH_FAILED, client)
        .outcome(Outcome.FAILURE).meta("reason", reason);
    if (session != null) {
      event.subject(session.user(), null).session(session.id()).tenant(session.activeTenant());
    }
    event.write();
    return AuthTransactions.Outcome.fail(AuthErrors.invalidRefreshToken());
  }

  /** R17: ends the session because the user/account/tenant/membership is no longer active. */
  private <T> AuthTransactions.Outcome<T> invalidate(UserSession session, AccessState state, String reason,
                                                     ClientInfo client, Instant now) {
    sessions.revoke(session.id(), now);
    audit.event(AuthAuditService.SESSION_INVALIDATED, client)
        .subject(state.userId(), state.accountId())
        .tenant(session.activeTenant())
        .session(session.id())
        .outcome(Outcome.DENIED)
        .meta("reason", reason)
        .write();
    return AuthTransactions.Outcome.fail(AuthErrors.sessionInvalid());
  }

  // ------------------------------------------------------------------------------------------- switch tenant

  /**
   * Moves the caller's session to {@code targetTenantId} and returns new tokens (refresh token rotated).
   *
   * @throws com.acme.iam.common.error.ApiException 401 {@code session_invalid}, 403 {@code tenant_not_accessible}
   */
  public AuthTokens switchTenant(Caller caller, UUID targetTenantId, ClientInfo client) {
    return tx.<AuthTransactions.Outcome<AuthTokens>>write(() -> {
      Instant now = clock.instant();
      Optional<UserSession> found = sessions.lockOwned(caller.sessionId(), caller.userId());
      Optional<AccessState> loaded = access.load(caller.userId(), targetTenantId);
      if (found.isEmpty() || loaded.isEmpty() || !found.get().isActive(now)) {
        audit.event(AuthAuditService.SESSION_INVALIDATED, client).user(caller).outcome(Outcome.DENIED)
            .meta("reason", "session_ended").write();
        return AuthTransactions.Outcome.<AuthTokens>fail(AuthErrors.sessionInvalid());
      }
      UserSession session = found.get();
      AccessState state = loaded.get();
      SessionTtl ttl = ttl(state);
      Optional<String> userDenial = state.userDenial();
      if (userDenial.isPresent()) {
        return this.<AuthTokens>invalidate(session, state, userDenial.get(), client, now);
      }
      if (ttl.isIdle(session.lastSeenAt(), now)) {
        audit.event(AuthAuditService.SESSION_INVALIDATED, client).user(caller).outcome(Outcome.DENIED)
            .meta("reason", "session_idle").write();
        return AuthTransactions.Outcome.<AuthTokens>fail(AuthErrors.sessionInvalid());
      }
      Optional<String> tenantDenial = state.tenantDenial();
      if (tenantDenial.isPresent()) {
        audit.event(AuthAuditService.TENANT_SWITCHED, client).user(caller).outcome(Outcome.DENIED)
            .meta("reason", tenantDenial.get()).meta("to_tenant", targetTenantId).write();
        return AuthTransactions.Outcome.<AuthTokens>fail(AuthErrors.tenantNotAccessible());
      }
      String refreshToken = newRefreshToken();
      sessions.rotateAndSwitch(session.id(), hash(refreshToken), targetTenantId, now);
      audit.event(AuthAuditService.TENANT_SWITCHED, client)
          .user(caller.userId(), caller.accountId(), targetTenantId, session.id())
          .meta("from_tenant", session.activeTenant())
          .write();
      return AuthTransactions.Outcome.ok(issue(caller.userId(), state.accountId(), targetTenantId, session.id(),
          state.sessionVersion(), refreshToken, ttl.refreshExpiresAt(session.expiresAt(), now)));
    }).get();
  }

  // ------------------------------------------------------------------------------------------------ logout

  /** Revokes the caller's session and the user's outstanding access tokens. */
  public void logout(Caller caller, ClientInfo client) {
    tx.write(() -> {
      int revoked = sessions.revoke(caller.sessionId(), clock.instant());
      audit.event(AuthAuditService.LOGOUT, client).user(caller).meta("sessions_revoked", revoked).write();
      revocations.revokeUsers(List.of(caller.userId()), REASON_LOGOUT); // last write
      return null;
    });
  }

  /** Revokes every session of the caller and the user's outstanding access tokens. @return sessions revoked */
  public int logoutAll(Caller caller, ClientInfo client) {
    return tx.write(() -> {
      int revoked = sessions.revokeAllOfUser(caller.userId(), clock.instant());
      audit.event(AuthAuditService.LOGOUT_ALL, client).user(caller).meta("sessions_revoked", revoked).write();
      revocations.revokeUsers(List.of(caller.userId()), REASON_LOGOUT_ALL); // last write
      return revoked;
    });
  }

  // ------------------------------------------------------------------------- building blocks for other flows

  /** Opens a session in {@code tenantId}; call it inside the caller's transaction. */
  OpenedSession open(UUID userId, UUID tenantId, SessionTtl ttl, ClientInfo client) {
    Instant now = clock.instant();
    String refreshToken = newRefreshToken();
    Instant expiresAt = now.plus(ttl.absolute());
    UserSession saved = sessions.save(UserSession.open(userId, tenantId, hash(refreshToken), client.ip(),
        client.userAgent(), now, expiresAt));
    return new OpenedSession(saved.id(), refreshToken, ttl.refreshExpiresAt(expiresAt, now));
  }

  /** Lifetimes for the user's account. */
  SessionTtl ttl(AccessState state) {
    return SessionTtl.from(state.accountSettings(), properties.session());
  }

  /** Resolves the permissions in {@code tenantId} and signs the access token. */
  AuthTokens issue(UUID userId, UUID accountId, UUID tenantId, UUID sessionId, int sessionVersion,
                   String refreshToken, Instant refreshExpiresAt) {
    IssuedJwt jwt = jwtIssuer.issueAccessToken(new AccessTokenClaims(userId, accountId, tenantId, sessionId,
        sessionVersion, permissions.resolve(userId, tenantId)));
    return new AuthTokens(jwt.tokenValue(), AuthTokens.BEARER, jwt.expiresInSeconds(), refreshToken,
        refreshExpiresAt, tenantId);
  }

  static String newRefreshToken() {
    byte[] random = new byte[REFRESH_TOKEN_BYTES];
    RANDOM.nextBytes(random);
    return Base64.getUrlEncoder().withoutPadding().encodeToString(random);
  }

  /** {@code SHA-256(token as US-ASCII)}; any input can be hashed (unknown tokens simply match nothing). */
  static byte[] hash(String rawToken) {
    try {
      return MessageDigest.getInstance("SHA-256")
          .digest((rawToken == null ? "" : rawToken).getBytes(StandardCharsets.US_ASCII));
    } catch (NoSuchAlgorithmException e) {
      throw new IllegalStateException("SHA-256 unavailable", e);
    }
  }
}
