package com.acme.iam.common.jdbc;

import java.util.Arrays;
import java.util.Set;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.env.EnvironmentPostProcessor;
import org.springframework.core.env.ConfigurableEnvironment;

/**
 * Fails startup when a database password is missing or one of the well-known local defaults (Task 9 security review).
 * The shipped {@code application.yml} has no password defaults; {@code application-dev.yml} supplies
 * {@code iam_app}/{@code iam_migrator} for docker compose. Outside the {@value #PROFILES} profiles a start with a
 * missing or default password (for example {@code IAM_DB_APP_PASSWORD=iam_app} copied into production) stops before
 * any connection is opened.
 *
 * <p>Registered in {@code META-INF/spring.factories}; runs after the configuration files are loaded.
 */
public class DatabaseCredentialsGuard implements EnvironmentPostProcessor {

  static final String PROFILES = "dev, local, test";
  private static final Set<String> LOCAL_PROFILES = Set.of("dev", "local", "test");
  private static final Set<String> WELL_KNOWN = Set.of("iam_app", "iam_migrator", "iam_app_test", "iam_migrator_test",
      "postgres", "password", "changeme", "secret");

  @Override
  public void postProcessEnvironment(ConfigurableEnvironment environment, SpringApplication application) {
    if (Arrays.stream(environment.getActiveProfiles()).anyMatch(LOCAL_PROFILES::contains)) {
      return;
    }
    check(environment, "spring.datasource.password", "IAM_DB_APP_PASSWORD");
    check(environment, "spring.flyway.password", "IAM_DB_MIGRATOR_PASSWORD");
  }

  private static void check(ConfigurableEnvironment environment, String property, String variable) {
    String value;
    try {
      value = environment.getProperty(property);
    } catch (IllegalArgumentException unresolved) { // ${VAR} without a default and without the variable
      value = null;
    }
    if (value == null || value.isBlank()) {
      throw new IllegalStateException(property + " is not set: provide " + variable + " (only the " + PROFILES
          + " profiles have a local default)");
    }
    if (WELL_KNOWN.contains(value)) {
      throw new IllegalStateException(property + " is a well-known default password; set a real " + variable
          + " (well-known passwords are accepted only in the " + PROFILES + " profiles)");
    }
  }
}
