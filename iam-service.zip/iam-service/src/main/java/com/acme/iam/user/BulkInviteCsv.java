package com.acme.iam.user;

import com.acme.iam.common.error.BadRequestException;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import org.springframework.lang.Nullable;

/**
 * Parser for the bulk invite CSV (P1-8.4): UTF-8 (a BOM is ignored), RFC 4180 quoting ({@code ""} escapes a quote,
 * quoted fields may contain commas and line breaks), columns {@code email,displayName,roleName} where the last two are
 * optional. An optional header row is recognised by its first cell being {@code email}. Blank lines are skipped.
 *
 * <p>Only structural problems are rejected here (400): {@code invalid_csv}, {@code empty_file}, {@code too_many_rows}.
 * Row content is validated by {@link BulkInviteService}.
 */
final class BulkInviteCsv {

  /**
   * One data row.
   *
   * @param line 1-based line of the file where the row starts (the header is line 1)
   * @param columns number of cells in the row (more than 3 is a row error)
   */
  record Row(int line, String email, @Nullable String displayName, @Nullable String roleName, int columns) {}

  private BulkInviteCsv() {}

  static List<Row> parse(InputStream in, int maxRows) {
    String text;
    try {
      text = new String(in.readAllBytes(), StandardCharsets.UTF_8);
    } catch (IOException e) {
      throw new BadRequestException("invalid_csv", "The file could not be read");
    }
    if (text.startsWith("﻿")) {
      text = text.substring(1);
    }
    List<Row> rows = new ArrayList<>();
    boolean first = true;
    Parser parser = new Parser(text);
    while (parser.hasMore()) {
      int line = parser.line();
      List<String> cells = parser.nextRecord();
      if (cells.stream().allMatch(String::isBlank)) {
        continue;
      }
      if (first && cells.get(0).strip().equalsIgnoreCase("email")) {
        first = false;
        continue;
      }
      first = false;
      if (rows.size() == maxRows) {
        throw new BadRequestException("too_many_rows", "A bulk invite accepts at most " + maxRows + " rows",
            Map.of("maxRows", maxRows));
      }
      rows.add(new Row(line, cells.get(0).strip(), cell(cells, 1), cell(cells, 2), cells.size()));
    }
    if (rows.isEmpty()) {
      throw new BadRequestException("empty_file", "The file contains no rows");
    }
    return rows;
  }

  @Nullable
  private static String cell(List<String> cells, int index) {
    if (index >= cells.size()) {
      return null;
    }
    String value = cells.get(index).strip();
    return value.isEmpty() ? null : value;
  }

  /** RFC 4180 record reader that tracks line numbers. */
  private static final class Parser {
    private final String text;
    private int pos;
    private int line = 1;

    Parser(String text) {
      this.text = text;
    }

    boolean hasMore() {
      return pos < text.length();
    }

    int line() {
      return line;
    }

    List<String> nextRecord() {
      List<String> cells = new ArrayList<>();
      StringBuilder cell = new StringBuilder();
      boolean quoted = false;
      int quoteLine = line;
      while (pos < text.length()) {
        char c = text.charAt(pos++);
        if (quoted) {
          if (c == '"') {
            if (pos < text.length() && text.charAt(pos) == '"') {
              cell.append('"');
              pos++;
            } else {
              quoted = false;
            }
          } else {
            if (c == '\n') {
              line++;
            }
            cell.append(c);
          }
        } else if (c == '"' && cell.toString().isBlank()) {
          cell.setLength(0);
          quoted = true;
          quoteLine = line;
        } else if (c == ',') {
          cells.add(cell.toString());
          cell.setLength(0);
        } else if (c == '\n') {
          line++;
          break;
        } else if (c != '\r') {
          cell.append(c);
        }
      }
      if (quoted) {
        throw new BadRequestException("invalid_csv", "Unterminated quoted field starting on line " + quoteLine,
            Map.of("line", quoteLine));
      }
      cells.add(cell.toString());
      return cells;
    }
  }
}
