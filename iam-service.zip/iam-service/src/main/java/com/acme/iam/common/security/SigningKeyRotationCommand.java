package com.acme.iam.common.security;

import java.util.function.IntConsumer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.stereotype.Component;

/**
 * Operator entry point for P1-4.2 ("rotation command"): starting the application with
 * {@code --iam.rotate-signing-key} publishes a new signing key ({@link SigningKeyService#rotateNow()}) and exits
 * (code 0, or 1 on failure). The new key becomes ACTIVE after {@code iam.security.key-publish-lead} through the
 * rotation job on the running instances. Without the option this runner does nothing.
 *
 * <pre>{@code
 * java -jar iam-service.jar --iam.rotate-signing-key
 * ./gradlew :iam-service:bootRun --args='--iam.rotate-signing-key'
 * }</pre>
 */
@Component
public class SigningKeyRotationCommand implements ApplicationRunner {

  public static final String OPTION = "iam.rotate-signing-key";
  private static final Logger log = LoggerFactory.getLogger(SigningKeyRotationCommand.class);

  private final SigningKeyService keys;
  private final IntConsumer exit;

  @Autowired
  public SigningKeyRotationCommand(SigningKeyService keys, ConfigurableApplicationContext context) {
    this(keys, code -> System.exit(SpringApplication.exit(context, () -> code)));
  }

  /** For tests: {@code exit} receives the exit code instead of terminating the JVM. */
  SigningKeyRotationCommand(SigningKeyService keys, IntConsumer exit) {
    this.keys = keys;
    this.exit = exit;
  }

  @Override
  public void run(ApplicationArguments args) {
    if (!args.containsOption(OPTION)) {
      return;
    }
    int code;
    try {
      String kid = keys.rotateNow();
      log.info("Signing key rotation requested: published {}; exiting", kid);
      code = 0;
    } catch (RuntimeException e) {
      log.error("Signing key rotation failed", e);
      code = 1;
    }
    exit.accept(code);
  }
}
