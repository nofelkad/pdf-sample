package com.acme.iam.account;

import com.acme.iam.assignment.AssignmentService;
import com.acme.iam.assignment.ScopeType;
import com.acme.iam.auth.RevocationService;
import com.acme.iam.common.RequestActor;
import com.acme.iam.common.error.ApiException;
import com.acme.iam.common.error.BadRequestException;
import com.acme.iam.common.error.ConflictException;
import com.acme.iam.common.error.NotFoundException;
import com.acme.iam.common.paging.KeysetCursor;
import com.acme.iam.common.paging.KeysetPage;
import com.acme.iam.product.Product;
import com.acme.iam.product.ProductService;
import com.acme.iam.role.Role;
import com.acme.iam.role.RoleService;
import com.acme.iam.tenant.Tenant;
import com.acme.iam.tenant.TenantAdminService;
import com.acme.iam.tenant.TenantAdminService.ProductSwitch;
import com.acme.iam.tenant.TenantAdminService.TenantView;
import com.acme.iam.user.Activation;
import com.acme.iam.user.ActivationLinks;
import com.acme.iam.user.InvitationService;
import com.acme.iam.user.InvitationService.InvitedUser;
import com.acme.iam.user.InvitationService.PendingInvitation;
import com.acme.iam.user.UserStatus;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.time.Clock;
import java.time.Instant;
import java.time.LocalDate;
import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.util.Comparator;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import org.springframework.http.HttpStatus;
import org.springframework.jdbc.core.simple.JdbcClient;
import org.springframework.lang.Nullable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * Platform administration of customer accounts (P1-6.1) and account bootstrap (P1-6.2). Callers are platform operators
 * ({@code platform.account.manage} in the PLATFORM account; checked by {@link PlatformAccountController}).
 *
 * <ul>
 *   <li><b>Bootstrap</b> ({@link #create}): one transaction creates the account and its subscriptions, the requested
 *       default tenant with every entitled product switched on, the requested default user (INVITED) with its primary
 *       membership, the {@value Role#ACCOUNT_ADMIN} assignment at ACCOUNT scope ({@link AssignmentService#grantAsSystem},
 *       granted by the operator) and the INVITE token; the activation link is returned ({@link ActivationLinks},
 *       ruling R46) and the email goes out after commit.
 *   <li><b>Status:</b> ACTIVE ⇄ SUSPENDED, → CLOSED (terminal, {@code account_closed}). The PLATFORM account cannot be
 *       suspended or closed ({@code platform_account_protected}).
 *   <li><b>Revocation:</b> suspend, close and shrinking entitlements call
 *       {@link RevocationService#revokeAccountUsers} once, as the last write.
 * </ul>
 */
@Service
public class AccountAdminService {

  /** A subscription in a request, by product code. */
  public record SubscriptionRequest(String code, SubscriptionStatus status, LocalDate startsAt,
                                    @Nullable LocalDate endsAt) {}

  public record SubscriptionView(UUID productId, String productCode, SubscriptionStatus status, LocalDate startsAt,
                                 @Nullable LocalDate endsAt) {}

  public record AccountView(UUID id, String name, String slug, AccountKind kind, AccountStatus status,
      Map<String, Object> settings, List<SubscriptionView> products, Instant createdAt, Instant updatedAt) {}

  public record AccountSummary(UUID id, String name, String slug, AccountKind kind, AccountStatus status,
                               Instant createdAt) {}

  /** The default tenant of a new account, as requested (R46). */
  public record DefaultTenant(String name, String slug) {}

  /** The default user (first Account Admin) of a new account, as requested (R46). */
  public record DefaultUser(String email, @Nullable String displayName) {}

  public record TenantRef(UUID id, String name, String slug) {}

  public record UserRef(UUID id, String email, UserStatus status) {}

  /**
   * Result of {@link #create}: the account, its default tenant, the invited default user and (unless
   * {@code iam.notification.expose-activation-link=false}) the activation link.
   */
  @JsonInclude(JsonInclude.Include.NON_NULL)
  public record CreatedAccount(AccountView account, TenantRef defaultTenant, UserRef defaultUser,
                               @Nullable Activation activation) {}

  private final AccountRepository accounts;
  private final ProductService products;
  private final TenantAdminService tenantAdmin;
  private final InvitationService invitations;
  private final AssignmentService assignments;
  private final RoleService roles;
  private final RevocationService revocations;
  private final JdbcClient jdbc;
  private final ObjectMapper objectMapper;
  private final Clock clock;
  private final ActivationLinks activationLinks;

  public AccountAdminService(AccountRepository accounts, ProductService products, TenantAdminService tenantAdmin,
      InvitationService invitations, AssignmentService assignments, RoleService roles,
      RevocationService revocations, JdbcClient jdbc, ObjectMapper objectMapper,
      Clock clock, ActivationLinks activationLinks) {
    this.accounts = accounts;
    this.products = products;
    this.tenantAdmin = tenantAdmin;
    this.invitations = invitations;
    this.assignments = assignments;
    this.roles = roles;
    this.revocations = revocations;
    this.jdbc = jdbc;
    this.objectMapper = objectMapper;
    this.clock = clock;
    this.activationLinks = activationLinks;
  }

  // ------------------------------------------------------------------------------------------- bootstrap

  /**
   * P1-6.2 / R46: creates a CUSTOMER account with the requested default tenant and invites the requested default user
   * as its first Account Admin.
   *
   * @throws ConflictException {@code slug_taken}
   * @throws BadRequestException {@code unknown_product}, {@code duplicate_product}, {@code invalid_subscription}
   * @throws ApiException 500 {@code system_role_missing} when the IAM system roles are not loaded
   */
  @Transactional
  public CreatedAccount create(String name, String slug, DefaultTenant defaultTenant, DefaultUser defaultUser,
      List<SubscriptionRequest> subscriptions) {
    UUID operator = RequestActor.current().userUuid();
    slug = slug.toLowerCase(Locale.ROOT);
    if (accounts.findBySlug(slug).isPresent()) {
      throw slugTaken();
    }
    Set<AccountProduct> requested = resolve(subscriptions);
    Role adminRole = roles.findSystemRole(Product.IAM_ID, Role.ACCOUNT_ADMIN)
        .orElseThrow(() -> new ApiException(HttpStatus.INTERNAL_SERVER_ERROR, "system_role_missing",
            "The " + Role.ACCOUNT_ADMIN + " system role is not loaded"));

    Account account = accounts.save(Account.create(name, slug, AccountKind.CUSTOMER).withProducts(requested));
    Tenant tenant = tenantAdmin.createWithProducts(account.id(), defaultTenant.name(), defaultTenant.slug(),
        account.entitledProductIds(today()));
    InvitedUser admin = invitations.createInvitedUser(account.id(), tenant.id(), defaultUser.email(),
        defaultUser.displayName(), operator);
    assignments.grantAsSystem(admin.user().id(), adminRole.id(), ScopeType.ACCOUNT, account.id(), operator, null);
    Activation activation = activationLinks.issue(admin.token(), account.id(), tenant.id(), admin.user().id(),
        ActivationLinks.Via.ACCOUNT_CREATE);
    invitations.notifyAfterCommit(List.of(new PendingInvitation(admin.user().email(), account.name(),
        admin.token().rawToken())));
    return new CreatedAccount(view(account), new TenantRef(tenant.id(), tenant.name(), tenant.slug()),
        new UserRef(admin.user().id(), admin.user().email(), admin.user().status()), activation);
  }

  // ------------------------------------------------------------------------------------------------ reads

  /** Keyset page of all accounts, newest first. */
  public KeysetPage<AccountSummary> list(@Nullable AccountStatus status, @Nullable String cursor,
      @Nullable Integer limit) {
    int size = KeysetPage.limit(limit);
    Optional<KeysetCursor> after = KeysetCursor.decode(cursor);
    StringBuilder sql = new StringBuilder("SELECT id, name, slug, kind, status, created_at FROM account WHERE true\n");
    if (status != null) {
      sql.append("  AND status = :status\n");
    }
    if (after.isPresent()) {
      sql.append("  AND (created_at, id) < (:cursorAt, :cursorId)\n");
    }
    sql.append("ORDER BY created_at DESC, id DESC LIMIT :limit");
    JdbcClient.StatementSpec spec = jdbc.sql(sql.toString()).param("limit", size + 1);
    if (status != null) {
      spec = spec.param("status", status.name());
    }
    if (after.isPresent()) {
      spec = spec.param("cursorAt", after.get().createdAtParam()).param("cursorId", after.get().id());
    }
    List<AccountSummary> rows = spec.query((rs, i) -> new AccountSummary(
        rs.getObject("id", UUID.class), rs.getString("name"), rs.getString("slug"),
        AccountKind.valueOf(rs.getString("kind")), AccountStatus.valueOf(rs.getString("status")),
        rs.getObject("created_at", OffsetDateTime.class).toInstant())).list();
    return KeysetPage.of(rows, size, AccountSummary::createdAt, AccountSummary::id);
  }

  public AccountView get(UUID accountId) {
    return view(load(accountId));
  }

  // ----------------------------------------------------------------------------------------------- writes

  @Transactional
  public AccountView update(UUID accountId, @Nullable String name, @Nullable Map<String, Object> settings) {
    Account account = load(accountId);
    requireNotClosed(account);
    if (name == null && settings == null) {
      return view(account);
    }
    jdbc.sql("""
            UPDATE account SET name = COALESCE(CAST(:name AS text), name),
                               settings = COALESCE(CAST(:settings AS jsonb), settings),
                               version = version + 1, updated_at = :now
            WHERE id = :id""")
        .param("name", name).param("settings", settings == null ? null : json(settings))
        .param("now", now()).param("id", accountId)
        .update();
    return view(load(accountId));
  }

  /**
   * R46: tenants are created by platform operators only, in any ACTIVE account (the PLATFORM account included). No user
   * is created; the account's admins invite users into the new tenant.
   *
   * @throws NotFoundException {@code account_not_found}
   * @throws ConflictException {@code account_not_active} (SUSPENDED or CLOSED), {@code slug_taken}
   * @throws BadRequestException {@code unknown_product}, {@code product_not_subscribed}
   */
  @Transactional
  public TenantView createTenant(UUID accountId, String name, String slug, List<ProductSwitch> switches) {
    Account account = load(accountId);
    if (!account.isActive()) {
      throw new ConflictException("account_not_active", "The account is " + account.status());
    }
    return tenantAdmin.create(accountId, name, slug, switches);
  }

  /** ACTIVE → SUSPENDED and revokes every user of the account; no-op when already suspended. */
  @Transactional
  public AccountView suspend(UUID accountId) {
    Account account = load(accountId);
    requireCustomer(account);
    requireNotClosed(account);
    if (account.status() == AccountStatus.SUSPENDED) {
      return view(account);
    }
    setStatus(accountId, AccountStatus.SUSPENDED);
    revocations.revokeAccountUsers(accountId, "account.suspended");
    return view(load(accountId));
  }

  /** SUSPENDED → ACTIVE; no-op when already active. */
  @Transactional
  public AccountView reactivate(UUID accountId) {
    Account account = load(accountId);
    requireNotClosed(account);
    if (account.isActive()) {
      return view(account);
    }
    setStatus(accountId, AccountStatus.ACTIVE);
    return view(load(accountId));
  }

  /** → CLOSED (terminal) and revokes every user of the account; no-op when already closed. */
  @Transactional
  public AccountView close(UUID accountId) {
    Account account = load(accountId);
    requireCustomer(account);
    if (account.status() == AccountStatus.CLOSED) {
      return view(account);
    }
    setStatus(accountId, AccountStatus.CLOSED);
    revocations.revokeAccountUsers(accountId, "account.closed");
    return view(load(accountId));
  }

  /**
   * Replaces the account's subscriptions ({@code account_product}). When a product the account was entitled to is no
   * longer entitled, its tenant switches are turned off (I5) and every user of the account is revoked.
   */
  @Transactional
  public AccountView setProducts(UUID accountId, List<SubscriptionRequest> subscriptions) {
    Account account = load(accountId);
    requireNotClosed(account);
    Set<AccountProduct> requested = resolve(subscriptions);
    Set<UUID> before = account.entitledProductIds(today());
    Account saved = accounts.save(account.withProducts(requested));
    Set<UUID> after = saved.entitledProductIds(today());
    tenantAdmin.disableProductsNotEntitled(accountId, after);
    Set<UUID> lost = new HashSet<>(before);
    lost.removeAll(after);
    if (!lost.isEmpty()) {
      revocations.revokeAccountUsers(accountId, "account.products.reduced");
    }
    return view(saved);
  }

  // ------------------------------------------------------------------------------------------- internals

  /**
   * Final review M6: status, name and settings changes are targeted UPDATEs of the account row. Saving the aggregate
   * rewrote (delete + insert) every {@code account_product} row, and the trigger audited each as a change.
   */
  private void setStatus(UUID accountId, AccountStatus status) {
    jdbc.sql("UPDATE account SET status = :status, version = version + 1, updated_at = :now WHERE id = :id")
        .param("status", status.name()).param("now", now()).param("id", accountId)
        .update();
  }

  private String json(Map<String, Object> settings) {
    try {
      return objectMapper.writeValueAsString(settings);
    } catch (JsonProcessingException e) {
      throw new BadRequestException("invalid_settings", "settings must be a JSON object");
    }
  }

  private OffsetDateTime now() {
    return OffsetDateTime.ofInstant(clock.instant(), ZoneOffset.UTC);
  }

  private Account load(UUID accountId) {
    return accounts.findById(accountId)
        .orElseThrow(() -> new NotFoundException("account_not_found", "Account not found"));
  }

  private Set<AccountProduct> resolve(@Nullable List<SubscriptionRequest> subscriptions) {
    Set<AccountProduct> result = new LinkedHashSet<>();
    if (subscriptions == null) {
      return result;
    }
    Set<UUID> seen = new HashSet<>();
    for (SubscriptionRequest s : subscriptions) {
      Product product = products.findByCode(s.code()).orElseThrow(() -> new BadRequestException("unknown_product",
          "Unknown product " + s.code(), Map.of("products", List.of(s.code()))));
      if (!seen.add(product.id())) {
        throw new BadRequestException("duplicate_product", "Product listed twice: " + s.code(),
            Map.of("products", List.of(s.code())));
      }
      if (s.endsAt() != null && s.endsAt().isBefore(s.startsAt())) {
        throw new BadRequestException("invalid_subscription", "endsAt is before startsAt for " + s.code(),
            Map.of("products", List.of(s.code())));
      }
      result.add(new AccountProduct(product.id(), s.status(), s.startsAt(), s.endsAt()));
    }
    return result;
  }

  private static void requireCustomer(Account account) {
    if (account.isPlatform()) {
      throw new ConflictException("platform_account_protected", "The platform account cannot be suspended or closed");
    }
  }

  private static void requireNotClosed(Account account) {
    if (account.status() == AccountStatus.CLOSED) {
      throw new ConflictException("account_closed", "The account is closed");
    }
  }

  private static ConflictException slugTaken() {
    return new ConflictException("slug_taken", "An account with this slug already exists");
  }

  private LocalDate today() {
    return LocalDate.now(clock);
  }

  private AccountView view(Account a) {
    List<SubscriptionView> subscriptions = a.products().stream()
        .map(p -> new SubscriptionView(p.productId(), products.getById(p.productId()).code(), p.status(),
            p.startsAt(), p.endsAt()))
        .sorted(Comparator.comparing(SubscriptionView::productCode))
        .toList();
    return new AccountView(a.id(), a.name(), a.slug(), a.kind(), a.status(), a.settings(), subscriptions,
        a.createdAt(), a.updatedAt());
  }
}
