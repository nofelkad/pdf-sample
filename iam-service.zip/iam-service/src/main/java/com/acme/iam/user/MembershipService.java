package com.acme.iam.user;

import com.acme.iam.auth.RevocationService;
import com.acme.iam.common.error.ConflictException;
import com.acme.iam.common.error.NotFoundException;
import com.acme.iam.common.jdbc.RetryOnDeadlock;
import com.acme.iam.tenant.Tenant;
import com.acme.iam.tenant.TenantService;
import java.time.Clock;
import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import org.springframework.jdbc.core.simple.JdbcClient;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

/**
 * Tenant memberships (P1-8.3): share a user into another tenant of the same account, remove a membership, change the
 * primary tenant. Targeted SQL only, never {@code AppUser.save()} (which rewrites every membership).
 *
 * <ul>
 *   <li><b>I2:</b> removing a membership deletes the user's TENANT-scope assignments for that tenant in the same
 *       transaction, then revokes the user. The membership row is deleted <em>first</em>: a concurrent
 *       {@code AssignmentService.assign} holds it {@code FOR SHARE} until it commits, so the delete waits and the
 *       following assignment delete also removes the assignment just inserted.
 *   <li><b>I4:</b> the primary membership cannot be removed ({@code primary_membership}); the primary tenant can only
 *       change to a tenant with an ACTIVE membership ({@code membership_required}).
 *   <li><b>Locking:</b> every write first locks the user row ({@code FOR NO KEY UPDATE}), so removal and primary
 *       changes of the same user serialise and I4 cannot be raced.
 * </ul>
 */
@Service
public class MembershipService {

  private record LockedUser(UserStatus status, UUID primaryTenantId) {}

  private final AppUserRepository users;
  private final TenantService tenants;
  private final RevocationService revocations;
  private final JdbcClient jdbc;
  private final Clock clock;

  public MembershipService(AppUserRepository users, TenantService tenants, RevocationService revocations,
      JdbcClient jdbc, Clock clock) {
    this.users = users;
    this.tenants = tenants;
    this.revocations = revocations;
    this.jdbc = jdbc;
    this.clock = clock;
  }

  /**
   * Adds an ACTIVE membership (or re-activates a SUSPENDED one). Access only grows, so nothing is revoked.
   *
   * @throws NotFoundException {@code user_not_found}, {@code tenant_not_found}
   * @throws ConflictException {@code user_deprovisioned}, {@code tenant_not_active}, {@code membership_exists}
   */
  @RetryOnDeadlock
  @Transactional
  public UserView add(UUID accountId, UUID userId, UUID tenantId) {
    LockedUser user = lockUser(accountId, userId);
    requireNotDeprovisioned(user);
    requireActiveTenant(accountId, tenantId);
    Optional<String> existing = jdbc.sql("""
            SELECT status FROM user_tenant_membership WHERE app_user = :u AND tenant_id = :t""")
        .param("u", userId).param("t", tenantId).query(String.class).optional();
    if (existing.filter(MembershipStatus.ACTIVE.name()::equals).isPresent()) {
      throw new ConflictException("membership_exists", "The user is already a member of this tenant");
    }
    jdbc.sql("""
            INSERT INTO user_tenant_membership (app_user, tenant_id, status, added_at)
            VALUES (:u, :t, 'ACTIVE', :now)
            ON CONFLICT (app_user, tenant_id) DO UPDATE SET status = 'ACTIVE'""")
        .param("u", userId).param("t", tenantId).param("now", now())
        .update();
    return view(accountId, userId);
  }

  /**
   * Removes a non-primary membership, deletes the user's TENANT-scope assignments there (I2) and revokes the user.
   *
   * @throws NotFoundException {@code user_not_found}, {@code membership_not_found}
   * @throws ConflictException {@code primary_membership} (I4)
   */
  @RetryOnDeadlock
  @Transactional
  public void remove(UUID accountId, UUID userId, UUID tenantId) {
    LockedUser user = lockUser(accountId, userId);
    if (user.primaryTenantId().equals(tenantId)) {
      throw new ConflictException("primary_membership",
          "The primary membership cannot be removed; change the primary tenant first");
    }
    int deleted = jdbc.sql("DELETE FROM user_tenant_membership WHERE app_user = :u AND tenant_id = :t")
        .param("u", userId).param("t", tenantId).update();
    if (deleted == 0) {
      throw new NotFoundException("membership_not_found", "The user is not a member of this tenant");
    }
    jdbc.sql("DELETE FROM role_assignment WHERE user_id = :u AND scope_type = 'TENANT' AND scope_id = :t")
        .param("u", userId).param("t", tenantId).update();
    revocations.revokeUsers(List.of(userId), "membership.removed");
  }

  /**
   * Moves the primary tenant to a tenant where the user has an ACTIVE membership (I4).
   *
   * @throws NotFoundException {@code user_not_found}, {@code tenant_not_found}
   * @throws ConflictException {@code user_deprovisioned}, {@code tenant_not_active}, {@code membership_required}
   */
  @RetryOnDeadlock
  @Transactional
  public UserView changePrimary(UUID accountId, UUID userId, UUID tenantId) {
    LockedUser user = lockUser(accountId, userId);
    requireNotDeprovisioned(user);
    if (user.primaryTenantId().equals(tenantId)) {
      return view(accountId, userId);
    }
    requireActiveTenant(accountId, tenantId);
    boolean member = jdbc.sql("""
            SELECT 1 FROM user_tenant_membership
            WHERE app_user = :u AND tenant_id = :t AND status = 'ACTIVE' FOR SHARE""")
        .param("u", userId).param("t", tenantId).query(Integer.class).optional().isPresent();
    if (!member) {
      throw new ConflictException("membership_required",
          "The primary tenant must be a tenant the user is an active member of");
    }
    jdbc.sql("""
            UPDATE app_user SET primary_tenant_id = :t, version = version + 1, updated_at = :now
            WHERE id = :u AND account_id = :a""")
        .param("t", tenantId).param("now", now()).param("u", userId).param("a", accountId)
        .update();
    return view(accountId, userId);
  }

  /**
   * Ruling R43 (platform admin recovery): gives the user an ACTIVE membership in {@code tenantId} (inserted, or a
   * SUSPENDED one re-activated) and, when the user's primary tenant cannot be used to log in (tenant not ACTIVE or the
   * primary membership not ACTIVE), makes {@code tenantId} the primary tenant. Joins the caller's transaction; locks the
   * user row first ({@code FOR NO KEY UPDATE}). The caller checks that the tenant is ACTIVE.
   *
   * @return {@code true} when the primary tenant moved to {@code tenantId}
   * @throws NotFoundException {@code user_not_found}
   * @throws ConflictException {@code user_deprovisioned}
   */
  @Transactional(propagation = Propagation.MANDATORY)
  public boolean ensureUsableMembership(UUID accountId, UUID userId, UUID tenantId) {
    LockedUser user = lockUser(accountId, userId);
    requireNotDeprovisioned(user);
    jdbc.sql("""
            INSERT INTO user_tenant_membership (app_user, tenant_id, status, added_at)
            VALUES (:u, :t, 'ACTIVE', :now)
            ON CONFLICT (app_user, tenant_id) DO UPDATE SET status = 'ACTIVE'
            WHERE user_tenant_membership.status <> 'ACTIVE'""")
        .param("u", userId).param("t", tenantId).param("now", now())
        .update();
    if (user.primaryTenantId().equals(tenantId)) {
      return false;
    }
    boolean primaryUsable = jdbc.sql("""
            SELECT EXISTS (SELECT 1 FROM tenant t JOIN user_tenant_membership m ON m.tenant_id = t.id
                           WHERE t.id = :p AND t.status = 'ACTIVE' AND m.app_user = :u AND m.status = 'ACTIVE')""")
        .param("p", user.primaryTenantId()).param("u", userId).query(Boolean.class).single();
    if (primaryUsable) {
      return false;
    }
    jdbc.sql("""
            UPDATE app_user SET primary_tenant_id = :t, version = version + 1, updated_at = :now
            WHERE id = :u AND account_id = :a""")
        .param("t", tenantId).param("now", now()).param("u", userId).param("a", accountId)
        .update();
    return true;
  }

  // ---------------------------------------------------------------------------------------------- internals

  private LockedUser lockUser(UUID accountId, UUID userId) {
    return jdbc.sql("""
            SELECT status, primary_tenant_id FROM app_user WHERE id = :id AND account_id = :a FOR NO KEY UPDATE""")
        .param("id", userId).param("a", accountId)
        .query((rs, i) -> new LockedUser(UserStatus.valueOf(rs.getString("status")),
            rs.getObject("primary_tenant_id", UUID.class)))
        .optional()
        .orElseThrow(() -> new NotFoundException("user_not_found", "User not found"));
  }

  private void requireActiveTenant(UUID accountId, UUID tenantId) {
    Tenant tenant = tenants.findByIdInAccount(tenantId, accountId)
        .orElseThrow(() -> new NotFoundException("tenant_not_found", "Tenant not found"));
    if (!tenant.isActive()) {
      throw new ConflictException("tenant_not_active", "The tenant is " + tenant.status(),
          Map.of("tenantId", tenantId.toString()));
    }
  }

  private static void requireNotDeprovisioned(LockedUser user) {
    if (user.status() == UserStatus.DEPROVISIONED) {
      throw new ConflictException("user_deprovisioned", "The user is deprovisioned");
    }
  }

  private UserView view(UUID accountId, UUID userId) {
    return UserView.of(users.findByIdInAccount(userId, accountId)
        .orElseThrow(() -> new NotFoundException("user_not_found", "User not found")));
  }

  private OffsetDateTime now() {
    return OffsetDateTime.ofInstant(clock.instant(), ZoneOffset.UTC);
  }
}
