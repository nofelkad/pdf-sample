package com.acme.iam.assignment;

import com.acme.iam.auth.RevocationService;
import java.time.Clock;
import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.util.List;
import java.util.Set;
import java.util.UUID;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.simple.JdbcClient;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * Deletes expired role assignments (P1-10.5), one batch per transaction. Each batch deletes at most
 * {@code iam.assignment.expiry.batch-size} (5,000) rows whose {@code expires_at} has passed, then calls
 * {@link RevocationService#revokeUsers} once for the distinct users of that batch as the transaction's last write, so
 * their tokens (which may still carry the expired role's permissions) stop working within the poll interval.
 *
 * <p>Rows are claimed with {@code FOR UPDATE SKIP LOCKED}, so a concurrent revoke or role delete is never blocked
 * and never deadlocks with the job. The invariant I7 needs no check: an expired assignment no longer counts as an
 * admin in {@link LastAdminService}.
 */
@Service
public class AssignmentExpiryService {

  public static final String REVOKE_REASON = "assignment.expired";

  private static final String DELETE_BATCH_SQL = """
      WITH expired AS (
        SELECT id FROM role_assignment
        WHERE expires_at IS NOT NULL AND expires_at <= :now
        ORDER BY expires_at, id
        LIMIT :batch
        FOR UPDATE SKIP LOCKED)
      DELETE FROM role_assignment ra USING expired e WHERE ra.id = e.id
      RETURNING ra.user_id
      """;

  private final JdbcClient jdbc;
  private final RevocationService revocations;
  private final Clock clock;
  private final int batchSize;

  public AssignmentExpiryService(JdbcClient jdbc, RevocationService revocations, Clock clock,
      @Value("${iam.assignment.expiry.batch-size:5000}") int batchSize) {
    if (batchSize < 1) {
      throw new IllegalArgumentException("batch size must be positive");
    }
    this.jdbc = jdbc;
    this.revocations = revocations;
    this.clock = clock;
    this.batchSize = batchSize;
  }

  /** One transaction: delete up to a batch of expired rows and revoke their users. @return rows deleted */
  @Transactional
  public int deleteExpiredBatch() {
    List<UUID> users = jdbc.sql(DELETE_BATCH_SQL)
        .param("now", OffsetDateTime.ofInstant(clock.instant(), ZoneOffset.UTC))
        .param("batch", batchSize)
        .query(UUID.class).list();
    if (!users.isEmpty()) {
      revocations.revokeUsers(Set.copyOf(users), REVOKE_REASON); // last write
    }
    return users.size();
  }

  /** Rows per batch; a batch that returns this many may have left more behind. */
  public int batchSize() {
    return batchSize;
  }
}
