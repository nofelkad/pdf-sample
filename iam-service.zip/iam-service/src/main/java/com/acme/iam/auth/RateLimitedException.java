package com.acme.iam.auth;

import com.acme.iam.common.error.ApiException;
import java.util.Map;
import org.springframework.http.HttpStatus;

/** 429 {@code rate_limited}; {@code AuthController} adds the {@code Retry-After} header (seconds). */
public class RateLimitedException extends ApiException {

  private final long retryAfterSeconds;

  public RateLimitedException(long retryAfterSeconds) {
    super(HttpStatus.TOO_MANY_REQUESTS, AuthErrors.RATE_LIMITED, "Too many requests; try again later",
        Map.of("retryAfter", retryAfterSeconds));
    this.retryAfterSeconds = retryAfterSeconds;
  }

  public long retryAfterSeconds() {
    return retryAfterSeconds;
  }
}
