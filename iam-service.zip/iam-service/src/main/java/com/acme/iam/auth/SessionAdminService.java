package com.acme.iam.auth;

import com.acme.iam.audit.AuditEvent;
import com.acme.iam.audit.AuditWriter;
import com.acme.iam.common.error.NotFoundException;
import com.acme.iam.common.jdbc.RetryOnDeadlock;
import java.time.Clock;
import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.util.List;
import java.util.UUID;
import org.springframework.jdbc.core.simple.JdbcClient;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * Administrative force logout (Task 9, ruling R37; permission {@code iam.session.revoke}, platform:
 * {@code platform.account.manage}). Every open session of the user (or of every user of the account) gets
 * {@code revoked_at}, so refresh tokens stop working at once, and the users' access tokens are revoked through the
 * revocation feed as the transaction's last write (reason {@value #REASON}). Each call writes one
 * {@value #ACTION} event; {@code RevocationService} adds its {@code auth.sessions.revoked} summary.
 *
 * <p>Authorisation (R28 for the user variant, {@code PlatformGuard} for the account variant) is the controller's job.
 */
@Service
public class SessionAdminService {

  public static final String ACTION = "auth.sessions.force_logout";
  public static final String REASON = "admin_force_logout";

  public record UserSessionsRevoked(UUID userId, int sessionsRevoked) {}

  public record AccountSessionsRevoked(UUID accountId, int sessionsRevoked, int usersRevoked) {}

  private final JdbcClient jdbc;
  private final RevocationService revocations;
  private final AuditWriter audit;
  private final Clock clock;

  public SessionAdminService(JdbcClient jdbc, RevocationService revocations, AuditWriter audit, Clock clock) {
    this.jdbc = jdbc;
    this.revocations = revocations;
    this.audit = audit;
    this.clock = clock;
  }

  /** Logs one user of the account out everywhere. @throws NotFoundException {@code user_not_found} */
  @RetryOnDeadlock
  @Transactional
  public UserSessionsRevoked revokeUser(UUID accountId, UUID userId) {
    UUID primaryTenant = jdbc.sql("SELECT primary_tenant_id FROM app_user WHERE id = :u AND account_id = :a")
        .param("u", userId).param("a", accountId).query(UUID.class).optional()
        .orElseThrow(() -> new NotFoundException("user_not_found", "User not found"));
    int sessions = jdbc.sql("""
            UPDATE user_session s SET revoked_at = :now, version = s.version + 1
            FROM app_user u
            WHERE s.user_id = u.id AND u.id = :u AND u.account_id = :a AND s.revoked_at IS NULL""")
        .param("now", now()).param("u", userId).param("a", accountId).update();
    audit.write(AuditEvent.forCurrentActor(ACTION).affecting(accountId, primaryTenant) // C1: the user's tenant
        .target("app_user", userId.toString())
        .metadata("scope", "user").metadata("sessions_revoked", sessions).build());
    revocations.revokeUsers(List.of(userId), REASON); // last write
    return new UserSessionsRevoked(userId, sessions);
  }

  /** Logs every user of the account out everywhere. @throws NotFoundException {@code account_not_found} */
  @RetryOnDeadlock
  @Transactional
  public AccountSessionsRevoked revokeAccount(UUID accountId) {
    boolean exists = jdbc.sql("SELECT EXISTS (SELECT 1 FROM account WHERE id = :a)").param("a", accountId)
        .query(Boolean.class).single();
    if (!exists) {
      throw new NotFoundException("account_not_found", "Account not found");
    }
    int sessions = jdbc.sql("""
            UPDATE user_session s SET revoked_at = :now, version = s.version + 1
            FROM app_user u
            WHERE s.user_id = u.id AND u.account_id = :a AND s.revoked_at IS NULL""")
        .param("now", now()).param("a", accountId).update();
    audit.write(AuditEvent.forCurrentActor(ACTION).affecting(accountId, null) // C1: filed under the target account
        .target("account", accountId.toString())
        .metadata("scope", "account").metadata("target_account_id", accountId.toString())
        .metadata("sessions_revoked", sessions).build());
    int users = revocations.revokeAccountUsers(accountId, REASON); // last write
    return new AccountSessionsRevoked(accountId, sessions, users);
  }

  private OffsetDateTime now() {
    return OffsetDateTime.ofInstant(clock.instant(), ZoneOffset.UTC);
  }
}
