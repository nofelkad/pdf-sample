package com.acme.iam.common.security;

import java.nio.ByteBuffer;
import java.security.GeneralSecurityException;
import java.security.SecureRandom;
import java.util.Arrays;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import org.springframework.lang.Nullable;

/**
 * AES-256-GCM with the master key ({@code iam.security.master-key}). Output layout: {@code iv (12 bytes) ||
 * ciphertext || tag (16 bytes)}, with a fresh random IV per call. Callers pass associated data (the key id) so a
 * ciphertext cannot be swapped onto another row.
 */
public final class MasterKeyCipher {

  public static final int IV_BYTES = 12;
  public static final int TAG_BYTES = 16;
  private static final int KEY_BYTES = 32;
  private static final String TRANSFORMATION = "AES/GCM/NoPadding";

  private final SecretKeySpec key;
  private final SecureRandom random = new SecureRandom();

  private MasterKeyCipher(byte[] key) {
    this.key = new SecretKeySpec(key, "AES");
  }

  /** Fails fast (startup) unless {@code base64} decodes to exactly 32 bytes. Accepts standard and URL-safe base64. */
  public static MasterKeyCipher fromBase64(@Nullable String base64) {
    if (base64 == null || base64.isBlank()) {
      throw new IllegalStateException(
          "iam.security.master-key (env IAM_MASTER_KEY) is required: base64 of 32 random bytes");
    }
    byte[] raw;
    try {
      String trimmed = base64.trim();
      raw = trimmed.contains("-") || trimmed.contains("_")
          ? Base64.getUrlDecoder().decode(trimmed)
          : Base64.getDecoder().decode(trimmed);
    } catch (IllegalArgumentException e) {
      throw new IllegalStateException("iam.security.master-key is not valid base64");
    }
    if (raw.length != KEY_BYTES) {
      throw new IllegalStateException("iam.security.master-key must decode to 32 bytes, got " + raw.length);
    }
    try {
      return new MasterKeyCipher(raw);
    } finally {
      Arrays.fill(raw, (byte) 0);
    }
  }

  public byte[] encrypt(byte[] plaintext, byte[] associatedData) {
    byte[] iv = new byte[IV_BYTES];
    random.nextBytes(iv);
    try {
      Cipher cipher = Cipher.getInstance(TRANSFORMATION);
      cipher.init(Cipher.ENCRYPT_MODE, key, new GCMParameterSpec(TAG_BYTES * 8, iv));
      cipher.updateAAD(associatedData);
      byte[] sealed = cipher.doFinal(plaintext);
      return ByteBuffer.allocate(IV_BYTES + sealed.length).put(iv).put(sealed).array();
    } catch (GeneralSecurityException e) {
      throw new IllegalStateException("AES-GCM encryption failed", e);
    }
  }

  public byte[] decrypt(byte[] ivAndCiphertext, byte[] associatedData) {
    if (ivAndCiphertext.length < IV_BYTES + TAG_BYTES) {
      throw new IllegalStateException("Ciphertext too short");
    }
    try {
      Cipher cipher = Cipher.getInstance(TRANSFORMATION);
      cipher.init(Cipher.DECRYPT_MODE, key, new GCMParameterSpec(TAG_BYTES * 8, ivAndCiphertext, 0, IV_BYTES));
      cipher.updateAAD(associatedData);
      return cipher.doFinal(ivAndCiphertext, IV_BYTES, ivAndCiphertext.length - IV_BYTES);
    } catch (GeneralSecurityException e) {
      throw new IllegalStateException("AES-GCM decryption failed (wrong master key or tampered data)", e);
    }
  }
}
