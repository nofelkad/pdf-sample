package com.acme.iam.auth;

import java.time.Clock;
import java.time.Duration;
import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import net.javacrumbs.shedlock.spring.annotation.SchedulerLock;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.simple.JdbcClient;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

/**
 * Final review M2: deletes ended credentials older than {@code iam.tokens.purge.retention} (default 30 days), on one
 * instance (ShedLock), every {@code iam.tokens.purge.interval} (default 1 h):
 *
 * <ul>
 *   <li>{@code user_token} rows (invitation and password-reset tokens) that were used, or expired, before the cutoff;
 *   <li>{@code user_session} rows that were revoked, or expired, before the cutoff.
 * </ul>
 * Live tokens and open sessions are never touched. {@code iam.tokens.purge.enabled=false} stops the schedule (the test
 * profile does, so a background run never deletes other tests' fixtures; {@link #runOnce} still works). Rows are
 * deleted in batches of {@value #BATCH} (each its own statement), so a large backlog never holds long locks. Neither table has an audit trigger (spec section 2: auth events
 * are written explicitly), so the purge writes no audit rows; the authentication events about those tokens and sessions
 * stay in {@code audit_event} for the audit retention.
 */
@Component
public class CredentialPurgeJob {

  public static final String LOCK_NAME = "credential-purge";
  static final int BATCH = 5000;

  private static final Logger log = LoggerFactory.getLogger(CredentialPurgeJob.class);

  private static final String PURGE_TOKENS = """
      DELETE FROM user_token WHERE id IN (
        SELECT id FROM user_token
        WHERE expires_at < :cutoff OR (used_at IS NOT NULL AND used_at < :cutoff)
        LIMIT :batch)""";

  private static final String PURGE_SESSIONS = """
      DELETE FROM user_session WHERE id IN (
        SELECT id FROM user_session
        WHERE expires_at < :cutoff OR (revoked_at IS NOT NULL AND revoked_at < :cutoff)
        LIMIT :batch)""";

  /** Rows deleted by one run. */
  public record Purged(int tokens, int sessions) {}

  private final JdbcClient jdbc;
  private final Clock clock;
  private final Duration retention;
  private final boolean enabled;

  public CredentialPurgeJob(JdbcClient jdbc, Clock clock,
      @Value("${iam.tokens.purge.retention:P30D}") Duration retention,
      @Value("${iam.tokens.purge.enabled:true}") boolean enabled) {
    if (retention.isNegative() || retention.isZero()) {
      throw new IllegalArgumentException("iam.tokens.purge.retention must be positive");
    }
    this.jdbc = jdbc;
    this.clock = clock;
    this.retention = retention;
    this.enabled = enabled;
  }

  @Scheduled(fixedDelayString = "${iam.tokens.purge.interval:PT1H}", initialDelayString = "PT1M")
  @SchedulerLock(name = LOCK_NAME, lockAtMostFor = "PT30M")
  public void run() {
    if (!enabled) {
      return;
    }
    try {
      Purged purged = runOnce();
      if (purged.tokens() + purged.sessions() > 0) {
        log.info("Purged {} user tokens and {} sessions that ended before {} ago", purged.tokens(),
            purged.sessions(), retention);
      }
    } catch (RuntimeException e) {
      log.error("Credential purge failed", e);
    }
  }

  /** One full pass (every batch); also the test hook. */
  public Purged runOnce() {
    OffsetDateTime cutoff = OffsetDateTime.ofInstant(clock.instant().minus(retention), ZoneOffset.UTC);
    return new Purged(drain(PURGE_TOKENS, cutoff), drain(PURGE_SESSIONS, cutoff));
  }

  private int drain(String sql, OffsetDateTime cutoff) {
    int total = 0;
    while (true) {
      int deleted = jdbc.sql(sql).param("cutoff", cutoff).param("batch", BATCH).update();
      total += deleted;
      if (deleted < BATCH) {
        return total;
      }
    }
  }
}
