package com.acme.iam.tenant;

import java.util.Objects;
import java.util.UUID;
import org.springframework.data.relational.core.mapping.Table;

/**
 * A product switched on (or off) for a tenant ({@code tenant_product}), owned by {@link Tenant}. Must be a subset of
 * the account's active subscriptions (I5, enforced by the tenant write path).
 */
@Table("tenant_product")
public record TenantProduct(UUID productId, boolean enabled) {

  public TenantProduct {
    Objects.requireNonNull(productId, "productId");
  }
}
