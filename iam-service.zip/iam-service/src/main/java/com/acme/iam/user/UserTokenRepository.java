package com.acme.iam.user;

import java.time.Instant;
import java.util.Optional;
import java.util.UUID;
import org.springframework.data.jdbc.repository.query.Modifying;
import org.springframework.data.jdbc.repository.query.Query;
import org.springframework.data.repository.ListCrudRepository;

/** Persistence of {@link UserToken}. Private to the {@code user} feature; use {@link UserTokenService}. */
public interface UserTokenRepository extends ListCrudRepository<UserToken, UUID> {

  @Query("SELECT * FROM user_token WHERE token_hash = :tokenHash")
  Optional<UserToken> findByTokenHash(byte[] tokenHash);

  /**
   * Atomically marks a usable token as used. Returns 1 when this call consumed it, 0 when it is unknown, of another
   * purpose, already used or expired (a concurrent consumer loses the race and gets 0).
   */
  @Modifying
  @Query("""
      UPDATE user_token SET used_at = :now
      WHERE token_hash = :tokenHash AND purpose = :purpose AND used_at IS NULL AND expires_at > :now""")
  int markUsed(byte[] tokenHash, String purpose, Instant now);

  /** Marks every outstanding (unused) token of the user and purpose as used; returns how many. */
  @Modifying
  @Query("UPDATE user_token SET used_at = :now WHERE user_id = :userId AND purpose = :purpose AND used_at IS NULL")
  int invalidateOutstanding(UUID userId, String purpose, Instant now);
}
