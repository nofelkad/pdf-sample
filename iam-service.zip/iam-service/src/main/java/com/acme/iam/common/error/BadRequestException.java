package com.acme.iam.common.error;

import java.util.Map;
import org.springframework.http.HttpStatus;

/** 400 Bad Request. Default code {@value #DEFAULT_CODE}. */
public class BadRequestException extends ApiException {

  public static final String DEFAULT_CODE = "bad_request";

  public BadRequestException(String detail) {
    this(DEFAULT_CODE, detail);
  }

  public BadRequestException(String code, String detail) {
    super(HttpStatus.BAD_REQUEST, code, detail);
  }

  public BadRequestException(String code, String detail, Map<String, Object> properties) {
    super(HttpStatus.BAD_REQUEST, code, detail, properties);
  }
}
