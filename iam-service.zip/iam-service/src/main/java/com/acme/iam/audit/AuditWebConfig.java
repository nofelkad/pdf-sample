package com.acme.iam.audit;

import java.time.Duration;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.AsyncSupportConfigurer;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

/**
 * A streamed export runs as an MVC async request, whose default timeout (30 s in Tomcat) would cut off a large
 * download. {@code iam.audit.export.timeout} (ISO-8601, default {@code PT30M}) replaces it for the whole application;
 * no other endpoint is async.
 */
@Configuration(proxyBeanMethods = false)
class AuditWebConfig implements WebMvcConfigurer {

  private final Duration exportTimeout;

  AuditWebConfig(@Value("${iam.audit.export.timeout:PT30M}") Duration exportTimeout) {
    this.exportTimeout = exportTimeout;
  }

  @Override
  public void configureAsyncSupport(AsyncSupportConfigurer configurer) {
    configurer.setDefaultTimeout(exportTimeout.toMillis());
    // final review M8: a streamed export whose body never ran (rejected, timed out first) releases its permit
    configurer.registerCallableInterceptors(new AuditExportService.PermitReleasingInterceptor());
  }
}
