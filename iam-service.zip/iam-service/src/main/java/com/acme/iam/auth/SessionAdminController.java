package com.acme.iam.auth;

import com.acme.iam.auth.SessionAdminService.AccountSessionsRevoked;
import com.acme.iam.auth.SessionAdminService.UserSessionsRevoked;
import com.acme.iam.common.security.CurrentUser;
import com.acme.iam.common.security.PlatformGuard;
import com.acme.iam.user.UserAdminService;
import java.util.UUID;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * Force logout (Task 9, ruling R37).
 *
 * <ul>
 *   <li>{@code POST /api/users/{id}/sessions/revoke} ({@code iam.session.revoke}, R28: ACCOUNT-scope holder, or a
 *       tenant-local target; 403 {@code account_scope_required} otherwise, 404 {@code user_not_found} for users of other
 *       accounts) → 200 {@code {userId, sessionsRevoked}}.
 *   <li>{@code POST /api/platform/accounts/{id}/sessions/revoke} ({@code platform.account.manage}, platform operators
 *       only) → 200 {@code {accountId, sessionsRevoked, usersRevoked}}; 404 {@code account_not_found}.
 * </ul>
 */
@RestController
public class SessionAdminController {

  public static final String PERMISSION = "iam.session.revoke";

  private final SessionAdminService sessions;
  private final UserAdminService users;
  private final PlatformGuard platformGuard;
  private final CurrentUser currentUser;

  public SessionAdminController(SessionAdminService sessions, UserAdminService users, PlatformGuard platformGuard,
      CurrentUser currentUser) {
    this.sessions = sessions;
    this.users = users;
    this.platformGuard = platformGuard;
    this.currentUser = currentUser;
  }

  @PostMapping("/api/users/{id}/sessions/revoke")
  @PreAuthorize("hasAuthority('iam.session.revoke')")
  public UserSessionsRevoked revokeUser(@PathVariable UUID id) {
    users.requireManageable(id, PERMISSION, false);
    return sessions.revokeUser(currentUser.accountId(), id);
  }

  @PostMapping("/api/platform/accounts/{id}/sessions/revoke")
  @PreAuthorize("hasAuthority('platform.account.manage')")
  public AccountSessionsRevoked revokeAccount(@PathVariable UUID id) {
    platformGuard.requireOperator();
    return sessions.revokeAccount(id);
  }
}
