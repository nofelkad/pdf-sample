package com.acme.iam.common.paging;

import com.acme.iam.common.error.BadRequestException;
import java.time.Instant;
import java.util.List;
import java.util.UUID;
import java.util.function.Function;
import org.springframework.lang.Nullable;

/**
 * One page of a keyset-paginated list. {@code nextCursor} is {@code null} on the last page.
 *
 * <p>Typical query: fetch {@code limit + 1} rows ordered by {@code created_at DESC, id DESC}, then call
 * {@link #of(List, int, Function, Function)}.
 */
public record KeysetPage<T>(List<T> items, @Nullable String nextCursor) {

  public static final int DEFAULT_LIMIT = 50;
  public static final int MAX_LIMIT = 200;

  public KeysetPage {
    items = List.copyOf(items);
  }

  /**
   * Effective page size: {@value #DEFAULT_LIMIT} when {@code null}, capped at {@value #MAX_LIMIT}.
   *
   * @throws BadRequestException {@code invalid_limit} when below 1
   */
  public static int limit(@Nullable Integer requested) {
    if (requested == null) {
      return DEFAULT_LIMIT;
    }
    if (requested < 1) {
      throw new BadRequestException("invalid_limit", "limit must be at least 1");
    }
    return Math.min(requested, MAX_LIMIT);
  }

  /**
   * Builds a page from up to {@code limit + 1} fetched rows: if more than {@code limit} were fetched, the extra row is
   * dropped and the cursor points at the last returned row.
   */
  public static <T> KeysetPage<T> of(List<T> fetched, int limit, Function<T, Instant> createdAt, Function<T, UUID> id) {
    if (fetched.size() <= limit) {
      return new KeysetPage<>(fetched, null);
    }
    List<T> items = fetched.subList(0, limit);
    T last = items.getLast();
    return new KeysetPage<>(items, new KeysetCursor(createdAt.apply(last), id.apply(last)).encode());
  }
}
