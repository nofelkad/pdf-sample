package com.acme.iam.audit;

import net.javacrumbs.shedlock.spring.annotation.SchedulerLock;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

/**
 * Daily partition maintenance on one instance (ShedLock {@value #LOCK_NAME}); see {@link AuditPartitionService}.
 * Schedule: {@code iam.audit.partition-cron} (default 01:10 UTC).
 */
@Component
public class AuditPartitionJob {

  public static final String LOCK_NAME = "audit-partitions";

  private final AuditPartitionService partitions;

  public AuditPartitionJob(AuditPartitionService partitions) {
    this.partitions = partitions;
  }

  @Scheduled(cron = "${iam.audit.partition-cron:0 10 1 * * *}", zone = "UTC")
  @SchedulerLock(name = LOCK_NAME, lockAtMostFor = "PT10M", lockAtLeastFor = "PT1M")
  public void run() {
    partitions.ensurePartitions();
  }
}
