package com.acme.iam.role;

/** {@code role.type}: SYSTEM roles come from product manifests and are read-only (I8); CUSTOM roles belong to one account. */
public enum RoleType {
  SYSTEM,
  CUSTOM
}
