package com.acme.iam.user;

import com.acme.iam.common.error.BadRequestException;
import com.acme.iam.common.security.CurrentUser;
import com.acme.iam.common.security.TenantGuard;
import com.acme.iam.user.BulkInviteService.JobView;
import java.io.IOException;
import java.io.InputStream;
import java.net.URI;
import java.util.Map;
import java.util.UUID;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

/**
 * Bulk invite (P1-8.4): {@code POST /api/tenants/{tenantId}/users/bulk} (multipart part {@code file}, CSV
 * {@code email,displayName,roleName}, at most 5,000 rows) answers 202 {@code {jobId}};
 * {@code GET /api/bulk-invites/{jobId}} reports status, counts and per-row errors. Both need {@code iam.user.manage}
 * and pass {@link TenantGuard#requireActive} for the job's tenant.
 */
@RestController
public class BulkInviteController {

  private static final String MANAGE = "iam.user.manage";

  public record Submitted(UUID jobId) {}

  private final BulkInviteService service;
  private final TenantGuard tenantGuard;
  private final CurrentUser currentUser;

  public BulkInviteController(BulkInviteService service, TenantGuard tenantGuard, CurrentUser currentUser) {
    this.service = service;
    this.tenantGuard = tenantGuard;
    this.currentUser = currentUser;
  }

  @PostMapping(path = "/api/tenants/{tenantId}/users/bulk", consumes = "multipart/form-data")
  @PreAuthorize("hasAuthority('iam.user.manage')")
  public ResponseEntity<Submitted> submit(@PathVariable UUID tenantId, @RequestParam("file") MultipartFile file) {
    tenantGuard.requireActive(tenantId, MANAGE);
    UUID jobId;
    try (InputStream csv = file.getInputStream()) {
      jobId = service.submit(currentUser.accountId(), tenantId, csv);
    } catch (IOException e) {
      throw new BadRequestException("invalid_csv", "The file could not be read", Map.of());
    }
    return ResponseEntity.accepted().location(URI.create("/api/bulk-invites/" + jobId)).body(new Submitted(jobId));
  }

  @GetMapping("/api/bulk-invites/{jobId}")
  @PreAuthorize("hasAuthority('iam.user.manage')")
  public JobView get(@PathVariable UUID jobId) {
    JobView job = service.get(currentUser.accountId(), jobId);
    tenantGuard.requireActive(job.tenantId(), MANAGE);
    return job;
  }
}
