package com.acme.iam.audit;

import net.javacrumbs.shedlock.spring.annotation.SchedulerLock;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

/**
 * Daily retention run on one instance (ShedLock {@value #LOCK_NAME}); see {@link AuditRetentionService}.
 * Schedule: {@code iam.audit.retention-cron} (default 02:40 UTC).
 */
@Component
public class AuditRetentionJob {

  public static final String LOCK_NAME = "audit-retention";
  private static final Logger log = LoggerFactory.getLogger(AuditRetentionJob.class);

  private final AuditRetentionService retention;

  public AuditRetentionJob(AuditRetentionService retention) {
    this.retention = retention;
  }

  @Scheduled(cron = "${iam.audit.retention-cron:0 40 2 * * *}", zone = "UTC")
  @SchedulerLock(name = LOCK_NAME, lockAtMostFor = "PT30M", lockAtLeastFor = "PT1M")
  public void run() {
    try {
      retention.enforce();
    } catch (RuntimeException e) {
      log.error("Audit retention run failed", e);
    }
  }
}
