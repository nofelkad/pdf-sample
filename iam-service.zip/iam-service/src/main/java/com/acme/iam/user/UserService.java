package com.acme.iam.user;

import com.acme.iam.common.error.NotFoundException;
import java.util.Optional;
import java.util.UUID;
import org.springframework.jdbc.core.simple.JdbcClient;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

/**
 * User lookups used by other features. Task 2 provides only the reads the authorization kernel needs; the user
 * administration API (Wave 2) extends this class.
 */
@Service
public class UserService {

  private final AppUserRepository users;
  private final JdbcClient jdbc;

  public UserService(AppUserRepository users, JdbcClient jdbc) {
    this.users = users;
    this.jdbc = jdbc;
  }

  public Optional<AppUser> findById(UUID userId) {
    return users.findById(userId);
  }

  /** @throws NotFoundException {@code user_not_found} */
  public AppUser getById(UUID userId) {
    return users.findById(userId).orElseThrow(() -> new NotFoundException("user_not_found", "User not found"));
  }

  /** The user of the account with this email (case-insensitive, CITEXT); empty otherwise. */
  public Optional<AppUser> findByAccountAndEmail(UUID accountId, String email) {
    return users.findByAccountAndEmail(accountId, email);
  }

  /** The user if it belongs to {@code accountId} (I10-safe lookup); empty otherwise. */
  public Optional<AppUser> findByIdInAccount(UUID userId, UUID accountId) {
    return users.findByIdInAccount(userId, accountId);
  }

  /**
   * Locks the user row {@code FOR SHARE} until the caller's transaction ends (Task 5, Ruling R28). Role grants take it
   * first, so they serialise with the user administration writes that lock the row {@code FOR NO KEY UPDATE}
   * (disable/enable/deprovision re-check the target's scope under that lock; sharing and membership removal lock it
   * too), while concurrent grants to the same user do not block each other.
   *
   * @return the user's status as committed when the lock was taken (empty for an unknown user)
   */
  @Transactional(propagation = Propagation.MANDATORY)
  public Optional<UserStatus> lockForGrant(UUID userId) {
    return jdbc.sql("SELECT status FROM app_user WHERE id = :id FOR SHARE").param("id", userId)
        .query(String.class).optional().map(UserStatus::valueOf);
  }

  /**
   * {@code true} when the user has an ACTIVE membership in the tenant. Must run inside the caller's transaction: the
   * membership row is locked {@code FOR SHARE} until commit, so a concurrent membership removal (I2) waits and then
   * also deletes whatever TENANT-scope assignment the caller inserted.
   */
  @Transactional(propagation = Propagation.MANDATORY)
  public boolean lockActiveMembership(UUID userId, UUID tenantId) {
    return jdbc.sql("""
            SELECT 1 FROM user_tenant_membership
            WHERE app_user = :userId AND tenant_id = :tenantId AND status = 'ACTIVE'
            FOR SHARE""")
        .param("userId", userId)
        .param("tenantId", tenantId)
        .query(Integer.class)
        .optional()
        .isPresent();
  }
}
