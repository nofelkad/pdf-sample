package com.acme.iam.audit;

import com.acme.iam.audit.AuditEvent.Outcome;
import jakarta.servlet.http.HttpServletRequest;
import java.nio.charset.StandardCharsets;
import java.time.Clock;
import java.time.Instant;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.UUID;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.lang.Nullable;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.mvc.method.annotation.StreamingResponseBody;

/**
 * {@code GET /api/audit/exports.csv?from&to[&tenantId&actorUserId&action&targetType&targetId&outcome&accountId]}
 * (permission {@code iam.audit.export}): the same filters and account scope as the search ({@link AuditController}),
 * streamed as an attachment. Validation and access checks happen before streaming starts, so a bad request is a
 * normal 4xx problem response; see {@link AuditExportService} for memory behaviour and the audit trail.
 */
@RestController
public class AuditExportController {

  public static final String PATH = "/api/audit/exports.csv";
  private static final DateTimeFormatter STAMP = DateTimeFormatter.ofPattern("yyyyMMdd'T'HHmmss'Z'").withZone(ZoneOffset.UTC);

  private final AuditQueryService queries;
  private final AuditExportService exports;
  private final Clock clock;

  public AuditExportController(AuditQueryService queries, AuditExportService exports, Clock clock) {
    this.queries = queries;
    this.exports = exports;
    this.clock = clock;
  }

  @GetMapping(PATH)
  @PreAuthorize("hasAuthority('iam.audit.export')")
  public ResponseEntity<StreamingResponseBody> export(
      @RequestParam(required = false) @Nullable UUID accountId,
      @RequestParam(required = false) @Nullable UUID tenantId,
      @RequestParam(required = false) @Nullable UUID actorUserId,
      @RequestParam(required = false) @Nullable String action,
      @RequestParam(required = false) @Nullable String targetType,
      @RequestParam(required = false) @Nullable String targetId,
      @RequestParam(required = false) @Nullable Outcome outcome,
      @RequestParam(required = false) @Nullable Instant from,
      @RequestParam(required = false) @Nullable Instant to,
      HttpServletRequest request) {
    AuditSearchCriteria criteria = queries.criteria(
        new AuditFilter(accountId, tenantId, actorUserId, action, targetType, targetId, outcome, from, to, null, null),
        true, AuditQueryService.PERM_EXPORT);
    AuditExportService.Export export = exports.begin(criteria);
    // M8: lets AuditExportService.PermitReleasingInterceptor give the permit back if the body never runs
    request.setAttribute(AuditExportService.EXPORT_ATTRIBUTE, export);
    return ResponseEntity.ok()
        .contentType(new MediaType("text", "csv", StandardCharsets.UTF_8))
        .header(HttpHeaders.CONTENT_DISPOSITION,
            "attachment; filename=\"audit-export-" + STAMP.format(clock.instant()) + ".csv\"")
        .header(HttpHeaders.CACHE_CONTROL, "no-store")
        .body(export::stream);
  }
}
