package com.acme.iam.auth;

import java.time.Instant;
import java.util.Objects;
import java.util.UUID;

/**
 * One previous password hash of a user ({@code password_history}). The table has no primary key, so it is not a
 * Spring Data aggregate; {@link PasswordHistoryRepository} reads and writes it with plain SQL.
 */
public record PasswordHistory(UUID userId, String passwordHash, Instant changedAt) {

  public PasswordHistory {
    Objects.requireNonNull(userId, "userId");
    Objects.requireNonNull(passwordHash, "passwordHash");
    Objects.requireNonNull(changedAt, "changedAt");
  }

  @Override
  public String toString() {
    return "PasswordHistory[userId=" + userId + ", changedAt=" + changedAt + "]";
  }
}
