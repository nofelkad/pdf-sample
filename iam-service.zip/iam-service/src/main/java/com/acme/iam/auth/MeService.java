package com.acme.iam.auth;

import com.acme.iam.account.Account;
import com.acme.iam.account.AccountService;
import com.acme.iam.common.error.NotFoundException;
import com.acme.iam.common.security.CurrentUser;
import com.acme.iam.tenant.Tenant;
import com.acme.iam.tenant.TenantService;
import com.acme.iam.user.AppUser;
import com.acme.iam.user.Membership;
import com.acme.iam.user.UserService;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.function.Function;
import java.util.stream.Collectors;
import org.springframework.lang.Nullable;
import org.springframework.stereotype.Service;

/**
 * {@code GET /api/me} (P1-5.9): the caller's profile, account, active tenant (the token's {@code tid}), memberships
 * and permissions. Permissions are the access token's {@code perms} (sorted), i.e. exactly what other endpoints
 * enforce for this token — not re-resolved from the database.
 */
@Service
public class MeService {

  public record Me(UserView user, AccountView account, TenantView activeTenant, List<MembershipView> memberships,
                   List<String> permissions) {}

  public record UserView(UUID id, String email, @Nullable String displayName, String status) {}

  public record AccountView(UUID id, String name, String slug) {}

  public record TenantView(UUID id, String name, String slug) {}

  public record MembershipView(UUID tenantId, String name, String slug, boolean primary, String status) {}

  private final CurrentUser currentUser;
  private final UserService users;
  private final AccountService accounts;
  private final TenantService tenants;

  public MeService(CurrentUser currentUser, UserService users, AccountService accounts, TenantService tenants) {
    this.currentUser = currentUser;
    this.users = users;
    this.accounts = accounts;
    this.tenants = tenants;
  }

  public Me me() {
    UUID userId = currentUser.userId();
    UUID accountId = currentUser.accountId();
    UUID tenantId = currentUser.tenantId();
    AppUser user = users.findByIdInAccount(userId, accountId)
        .orElseThrow(() -> new NotFoundException("user_not_found", "User not found"));
    Account account = accounts.getById(accountId);
    Map<UUID, Tenant> accountTenants = tenants.findAllByAccount(accountId).stream()
        .collect(Collectors.toMap(Tenant::id, Function.identity()));
    Tenant active = accountTenants.get(tenantId);
    List<MembershipView> memberships = user.memberships().stream()
        .filter(m -> accountTenants.containsKey(m.tenantId()))
        .map(m -> membership(m, accountTenants.get(m.tenantId()), user.primaryTenant()))
        .sorted(Comparator.comparing(MembershipView::slug))
        .toList();
    return new Me(
        new UserView(user.id(), user.email(), user.displayName(), user.status().name()),
        new AccountView(account.id(), account.name(), account.slug()),
        active == null ? null : new TenantView(active.id(), active.name(), active.slug()),
        memberships,
        currentUser.permissions().stream().sorted().toList());
  }

  private static MembershipView membership(Membership m, Tenant tenant, UUID primaryTenant) {
    return new MembershipView(m.tenantId(), tenant.name(), tenant.slug(), m.tenantId().equals(primaryTenant),
        m.status().name());
  }
}
