package com.acme.iam.assignment;

import com.acme.iam.role.Role;
import com.acme.iam.user.AppUser;
import java.time.Instant;
import java.util.UUID;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.Id;
import org.springframework.data.annotation.Version;
import org.springframework.data.jdbc.core.mapping.AggregateReference;
import org.springframework.data.relational.core.mapping.Table;
import org.springframework.lang.Nullable;

/**
 * Role assignment aggregate root: user U holds role R at scope (ACCOUNT a | TENANT t), optionally until
 * {@code expiresAt}. Its own aggregate because it is queried by scope and by role, not only by user. Create it through
 * {@link AssignmentService}, which enforces I1, I3, I6 and I8.
 */
@Table("role_assignment")
public record RoleAssignment(
    @Id UUID id,
    AggregateReference<AppUser, UUID> userId,
    AggregateReference<Role, UUID> roleId,
    ScopeType scopeType,
    UUID scopeId,
    @Nullable AggregateReference<AppUser, UUID> grantedBy,
    @CreatedDate Instant grantedAt,
    @Nullable Instant expiresAt,
    @Version Long version) {

  static RoleAssignment create(UUID userId, UUID roleId, ScopeType scopeType, UUID scopeId, @Nullable UUID grantedBy,
      @Nullable Instant expiresAt) {
    return new RoleAssignment(null, AggregateReference.to(userId), AggregateReference.to(roleId), scopeType, scopeId,
        grantedBy == null ? null : AggregateReference.to(grantedBy), null, expiresAt, null);
  }

  public UUID user() {
    return userId.getId();
  }

  public UUID role() {
    return roleId.getId();
  }

  @Nullable
  public UUID grantor() {
    return grantedBy == null ? null : grantedBy.getId();
  }

  public boolean isExpired(Instant now) {
    return expiresAt != null && !expiresAt.isAfter(now);
  }
}
