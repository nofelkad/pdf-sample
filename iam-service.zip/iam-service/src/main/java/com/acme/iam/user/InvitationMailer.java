package com.acme.iam.user;

import com.acme.iam.user.InvitationService.PendingInvitation;
import io.micrometer.core.instrument.Counter;
import io.micrometer.core.instrument.Gauge;
import io.micrometer.core.instrument.MeterRegistry;
import io.micrometer.core.instrument.simple.SimpleMeterRegistry;
import java.time.Duration;
import java.util.List;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.Future;
import java.util.concurrent.RejectedExecutionException;
import java.util.concurrent.RejectedExecutionHandler;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import java.util.concurrent.atomic.AtomicInteger;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * Sends invitation emails off the request thread (final review I2). Until this class, {@code afterCommit} called the
 * {@link NotificationPort} synchronously, still holding the request thread and its pooled JDBC connection (Spring
 * releases the connection only after the synchronizations ran): an SMTP brownout exhausted the Hikari pool and every
 * request answered 503, and a 5,000-row bulk invite sent 5,000 mails in a row on one connection.
 *
 * <p>{@link #submit} only enqueues: every invitation is one task on a private, bounded executor
 * ({@code iam.notification.executor.threads}, queue {@code queue-capacity}). A full queue drops the invitation
 * (counted in {@value #DROPPED_METRIC}, WARN logged without the token); the invited user stays INVITED and an admin can
 * re-send. Each send runs on a separate pool bounded by {@code send-timeout}, so a hung mail server cannot pin a worker
 * (counted in {@value #TIMEOUT_METRIC}). Failures are counted in {@value #FAILED_METRIC} and logged without the token;
 * successes in {@value #SENT_METRIC}; the queue length is the gauge {@value #QUEUED_METRIC}. Nothing here touches the
 * database. Same design as the password-reset mailer (ruling R31).
 *
 * <p>Delivery is at most once and in-memory: invitations queued when the instance stops are lost (logged at shutdown);
 * see {@code docs/failure-modes.md}.
 */
@Component
public class InvitationMailer implements DisposableBean {

  public static final String SENT_METRIC = "iam.notification.invitations.sent";
  public static final String FAILED_METRIC = "iam.notification.invitations.failed";
  public static final String TIMEOUT_METRIC = "iam.notification.invitations.send_timeouts";
  public static final String DROPPED_METRIC = "iam.notification.invitations.dropped";
  public static final String QUEUED_METRIC = "iam.notification.invitations.queued";

  private static final Logger log = LoggerFactory.getLogger(InvitationMailer.class);

  private final NotificationPort notifications;
  private final Duration sendTimeout;
  private final Counter sent;
  private final Counter failed;
  private final Counter timeouts;
  private final Counter dropped;
  private final ThreadPoolExecutor worker;
  private final ThreadPoolExecutor sender;

  @Autowired
  public InvitationMailer(NotificationPort notifications, InvitationMailerProperties properties,
      ObjectProvider<MeterRegistry> meterRegistry) {
    this(notifications, properties, meterRegistry.getIfAvailable(SimpleMeterRegistry::new));
  }

  InvitationMailer(NotificationPort notifications, InvitationMailerProperties properties, MeterRegistry registry) {
    this.notifications = notifications;
    this.sendTimeout = properties.sendTimeout();
    this.sent = Counter.builder(SENT_METRIC).description("Invitation emails handed to the notification adapter")
        .register(registry);
    this.failed = Counter.builder(FAILED_METRIC).description("Invitation emails whose send failed")
        .register(registry);
    this.timeouts = Counter.builder(TIMEOUT_METRIC).description("Invitation emails whose send hit the send timeout")
        .register(registry);
    this.dropped = Counter.builder(DROPPED_METRIC)
        .description("Invitation emails dropped because the send queue was full").register(registry);
    this.worker = pool("invite-mail-", properties.threads(), properties.queueCapacity(), (runnable, pool) -> {
      dropped.increment();
      log.warn("invitation.notification_dropped reason=queue_full");
    });
    // a timed-out send keeps its thread until the interrupt is honoured; twice the workers leaves headroom
    this.sender = pool("invite-mail-send-", properties.threads() * 2, properties.threads() * 2,
        new ThreadPoolExecutor.AbortPolicy());
    Gauge.builder(QUEUED_METRIC, worker, w -> w.getQueue().size())
        .description("Invitation emails waiting to be sent").register(registry);
  }

  /** Enqueues one task per invitation and returns at once. Call it after commit. */
  public void submit(List<PendingInvitation> invitations) {
    for (PendingInvitation invitation : invitations) {
      worker.execute(() -> send(invitation));
    }
  }

  private void send(PendingInvitation invitation) {
    Future<?> sending = null;
    try {
      sending = sender.submit(() -> notifications.sendInvitation(invitation.email(), invitation.accountName(),
          invitation.rawToken()));
      sending.get(sendTimeout.toMillis(), TimeUnit.MILLISECONDS);
      sent.increment();
    } catch (TimeoutException e) {
      sending.cancel(true);
      timeouts.increment();
      log.warn("invitation.notification_failed account={} error=send_timeout after={}", invitation.accountName(),
          sendTimeout);
    } catch (InterruptedException e) {
      Thread.currentThread().interrupt();
    } catch (RejectedExecutionException e) {
      dropped.increment();
      log.warn("invitation.notification_dropped reason=sender_saturated");
    } catch (Exception e) {
      Throwable cause = e.getCause() == null ? e : e.getCause();
      failed.increment();
      log.warn("invitation.notification_failed account={} error={}", invitation.accountName(),
          cause.getClass().getSimpleName());
    }
  }

  private static ThreadPoolExecutor pool(String prefix, int threads, int queueCapacity,
      RejectedExecutionHandler onFull) {
    AtomicInteger count = new AtomicInteger();
    return new ThreadPoolExecutor(threads, threads, 60, TimeUnit.SECONDS, new ArrayBlockingQueue<>(queueCapacity),
        runnable -> {
          Thread thread = new Thread(runnable, prefix + count.incrementAndGet());
          thread.setDaemon(true);
          return thread;
        },
        onFull);
  }

  @Override
  public void destroy() throws InterruptedException {
    worker.shutdown();
    if (!worker.awaitTermination(10, TimeUnit.SECONDS)) {
      int lost = worker.shutdownNow().size();
      log.warn("invitation.notification_dropped reason=shutdown count={}", lost);
    }
    sender.shutdownNow();
  }
}
