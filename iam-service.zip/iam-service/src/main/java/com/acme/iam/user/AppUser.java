package com.acme.iam.user;

import com.acme.iam.account.Account;
import com.acme.iam.tenant.Tenant;
import java.time.Instant;
import java.util.HashSet;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.Id;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.annotation.Version;
import org.springframework.data.jdbc.core.mapping.AggregateReference;
import org.springframework.data.relational.core.mapping.MappedCollection;
import org.springframework.data.relational.core.mapping.Table;
import org.springframework.lang.Nullable;

/**
 * User aggregate root ({@code app_user}). Owns its tenant memberships.
 *
 * <p><b>Saving rewrites the memberships</b> (Spring Data JDBC deletes and re-inserts owned rows on every update), and
 * the audit trigger records each of those rows. Hot-path bookkeeping (login counters, {@code last_login_at},
 * {@code session_version}) should therefore use targeted {@code UPDATE} statements instead of {@code save}.
 */
@Table("app_user")
public record AppUser(
    @Id UUID id,
    AggregateReference<Account, UUID> accountId,
    String email,
    @Nullable String displayName,
    UserStatus status,
    AggregateReference<Tenant, UUID> primaryTenantId,
    @Nullable String passwordHash,
    @Nullable Instant passwordChangedAt,
    int failedLogins,
    @Nullable Instant lockedUntil,
    int sessionVersion,
    @Nullable Instant lastLoginAt,
    @MappedCollection(idColumn = "app_user") Set<Membership> memberships,
    @Version Long version,
    @CreatedDate Instant createdAt,
    @LastModifiedDate Instant updatedAt) {

  public AppUser {
    memberships = memberships == null ? Set.of() : Set.copyOf(memberships);
  }

  /**
   * A new INVITED user (no password yet) with an ACTIVE membership in {@code primaryTenantId} (I4).
   *
   * @param now the membership's {@code added_at}
   */
  public static AppUser invite(UUID accountId, UUID primaryTenantId, String email, @Nullable String displayName,
      Instant now) {
    return new AppUser(null, AggregateReference.to(accountId), email, displayName, UserStatus.INVITED,
        AggregateReference.to(primaryTenantId), null, null, 0, null, 1, null,
        Set.of(Membership.active(primaryTenantId, now)), null, null, null);
  }

  /** The owning account id (never {@code null}). */
  public UUID account() {
    return accountId.getId();
  }

  /** The primary tenant id (never {@code null}). */
  public UUID primaryTenant() {
    return primaryTenantId.getId();
  }

  public Optional<Membership> membership(UUID tenantId) {
    return memberships.stream().filter(m -> m.tenantId().equals(tenantId)).findFirst();
  }

  public boolean hasActiveMembership(UUID tenantId) {
    return membership(tenantId).map(Membership::isActive).orElse(false);
  }

  public AppUser withStatus(UserStatus newStatus) {
    return new AppUser(id, accountId, email, displayName, newStatus, primaryTenantId, passwordHash, passwordChangedAt,
        failedLogins, lockedUntil, sessionVersion, lastLoginAt, memberships, version, createdAt, updatedAt);
  }

  public AppUser withDisplayName(@Nullable String newDisplayName) {
    return new AppUser(id, accountId, email, newDisplayName, status, primaryTenantId, passwordHash, passwordChangedAt,
        failedLogins, lockedUntil, sessionVersion, lastLoginAt, memberships, version, createdAt, updatedAt);
  }

  public AppUser withPassword(String newPasswordHash, Instant changedAt) {
    return new AppUser(id, accountId, email, displayName, status, primaryTenantId, newPasswordHash, changedAt,
        failedLogins, lockedUntil, sessionVersion, lastLoginAt, memberships, version, createdAt, updatedAt);
  }

  public AppUser withPrimaryTenant(UUID tenantId) {
    return new AppUser(id, accountId, email, displayName, status, AggregateReference.to(tenantId), passwordHash,
        passwordChangedAt, failedLogins, lockedUntil, sessionVersion, lastLoginAt, memberships, version, createdAt,
        updatedAt);
  }

  public AppUser withMemberships(Set<Membership> newMemberships) {
    return new AppUser(id, accountId, email, displayName, status, primaryTenantId, passwordHash, passwordChangedAt,
        failedLogins, lockedUntil, sessionVersion, lastLoginAt, newMemberships, version, createdAt, updatedAt);
  }

  /** Adds (or replaces) the membership for {@code membership.tenantId()}. */
  public AppUser withMembership(Membership membership) {
    Set<Membership> next = new HashSet<>(memberships);
    next.removeIf(m -> m.tenantId().equals(membership.tenantId()));
    next.add(membership);
    return withMemberships(next);
  }

  /** Removes the membership for {@code tenantId} (I2/I4 are the caller's responsibility). */
  public AppUser withoutMembership(UUID tenantId) {
    Set<Membership> next = new HashSet<>(memberships);
    next.removeIf(m -> m.tenantId().equals(tenantId));
    return withMemberships(next);
  }
}
