package com.acme.iam.role;

import com.acme.iam.common.error.BadRequestException;
import com.acme.iam.common.error.NotFoundException;
import com.acme.iam.product.Permission;
import com.acme.iam.product.ProductService;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import java.util.stream.Collectors;
import org.springframework.jdbc.core.simple.JdbcClient;
import org.springframework.lang.Nullable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

/**
 * Role lookups and kernel rules used by other features. Task 2 provides the reads the authorization kernel needs and
 * the I3 content rule; the role administration API (Task 6) extends this class.
 */
@Service
public class RoleService {

  private final RoleRepository roles;
  private final ProductService products;
  private final JdbcClient jdbc;

  public RoleService(RoleRepository roles, ProductService products, JdbcClient jdbc) {
    this.roles = roles;
    this.products = products;
    this.jdbc = jdbc;
  }

  /** What {@link #replacePermissions} changed. */
  public record PermissionDiff(Set<UUID> added, Set<UUID> removed) {
    public boolean isEmpty() {
      return added.isEmpty() && removed.isEmpty();
    }
  }

  /** Creates a SYSTEM role (registry use; the aggregate insert writes the role and its permissions once). */
  @Transactional
  public Role createSystemRole(UUID productId, String name, @Nullable String description,
      Collection<UUID> permissionIds) {
    return roles.save(Role.system(productId, name, description, permissionIds));
  }

  /** Names of the SYSTEM roles of a product (case as stored). */
  public List<String> systemRoleNames(UUID productId) {
    return roles.findSystemRoleNames(productId);
  }

  /**
   * Makes {@code role_permission} of the role exactly {@code desired} with targeted {@code INSERT}/{@code DELETE}
   * statements for the difference only, so an unchanged role writes (and audits) nothing. ({@code Role.save} would
   * delete and re-insert every row.) The caller decides about revocation.
   */
  @Transactional(propagation = Propagation.MANDATORY)
  public PermissionDiff replacePermissions(UUID roleId, Collection<UUID> desired) {
    Set<UUID> want = new HashSet<>(desired);
    Set<UUID> current = new HashSet<>(jdbc.sql("SELECT permission_id FROM role_permission WHERE role = :role")
        .param("role", roleId).query(UUID.class).list());
    Set<UUID> removed = new HashSet<>(current);
    removed.removeAll(want);
    Set<UUID> added = new HashSet<>(want);
    added.removeAll(current);
    if (!removed.isEmpty()) {
      jdbc.sql("DELETE FROM role_permission WHERE role = :role AND permission_id IN (:ids)")
          .param("role", roleId).param("ids", removed).update();
    }
    for (UUID permissionId : added) {
      jdbc.sql("INSERT INTO role_permission (role, permission_id) VALUES (:role, :perm)")
          .param("role", roleId).param("perm", permissionId).update();
    }
    return new PermissionDiff(Set.copyOf(added), Set.copyOf(removed));
  }

  /** Ids of every role (SYSTEM or CUSTOM) that contains at least one of the permissions. */
  public Set<UUID> rolesContainingAny(Collection<UUID> permissionIds) {
    if (permissionIds.isEmpty()) {
      return Set.of();
    }
    return new HashSet<>(jdbc.sql("SELECT DISTINCT role FROM role_permission WHERE permission_id IN (:ids)")
        .param("ids", permissionIds).query(UUID.class).list());
  }

  public Optional<Role> findById(UUID roleId) {
    return roles.findById(roleId);
  }

  /** @throws NotFoundException {@code role_not_found} */
  public Role getById(UUID roleId) {
    return roles.findById(roleId).orElseThrow(() -> new NotFoundException("role_not_found", "Role not found"));
  }

  /** The SYSTEM role of a product with this (case-insensitive) name. */
  public Optional<Role> findSystemRole(UUID productId, String name) {
    return roles.findSystemRole(productId, name);
  }

  /**
   * The codes of the role's permissions that can actually be granted, i.e. not deprecated. This is what a grantor must
   * hold to assign the role (I6): deprecated permissions are never resolved, so they are neither required nor granted.
   */
  public Set<String> grantablePermissionCodes(Role role) {
    return products.findPermissions(role.permissionIds()).stream()
        .filter(p -> !p.deprecated())
        .map(Permission::code)
        .collect(Collectors.toUnmodifiableSet());
  }

  /**
   * The grantable permission codes of the role that belong to <em>another</em> product than the role's own (ruling
   * R40: those are never covered by the product-system-role exemption from I6).
   */
  public Set<String> grantablePermissionCodesOfOtherProducts(Role role) {
    return products.findPermissions(role.permissionIds()).stream()
        .filter(p -> !p.deprecated())
        .filter(p -> !role.product().equals(p.productId().getId()))
        .map(Permission::code)
        .collect(Collectors.toUnmodifiableSet());
  }

  /**
   * I3 (content half): a CUSTOM role may only contain existing permissions of its own product. Call it on every CUSTOM
   * role create/update before saving.
   *
   * @throws BadRequestException {@code unknown_permission} (property {@code permissionIds}) when an id does not exist;
   *     {@code permission_product_mismatch} (property {@code permissionIds}) when a permission belongs to another
   *     product
   */
  public void validateCustomRolePermissions(UUID productId, Collection<UUID> permissionIds) {
    Set<UUID> requested = new HashSet<>(permissionIds);
    List<Permission> found = products.findPermissions(requested);

    Set<UUID> unknown = new HashSet<>(requested);
    found.forEach(p -> unknown.remove(p.id()));
    if (!unknown.isEmpty()) {
      throw new BadRequestException("unknown_permission", "Unknown permission ids",
          Map.of("permissionIds", sorted(unknown)));
    }

    Set<UUID> foreign = found.stream().filter(p -> !p.product().equals(productId)).map(Permission::id)
        .collect(Collectors.toSet());
    if (!foreign.isEmpty()) {
      throw new BadRequestException("permission_product_mismatch",
          "A custom role may only contain permissions of its own product", Map.of("permissionIds", sorted(foreign)));
    }
  }

  private static List<String> sorted(Set<UUID> ids) {
    return ids.stream().map(UUID::toString).sorted().toList();
  }
}
