package com.acme.iam.account;

import com.acme.iam.common.error.NotFoundException;
import java.util.Optional;
import java.util.UUID;
import org.springframework.stereotype.Service;

/**
 * Account lookups used by other features. Task 2 provides only the reads the authorization kernel needs; the account
 * administration API (Wave 2) extends this class.
 */
@Service
public class AccountService {

  private final AccountRepository accounts;

  public AccountService(AccountRepository accounts) {
    this.accounts = accounts;
  }

  public Optional<Account> findById(UUID accountId) {
    return accounts.findById(accountId);
  }

  /** @throws NotFoundException {@code account_not_found} */
  public Account getById(UUID accountId) {
    return accounts.findById(accountId)
        .orElseThrow(() -> new NotFoundException("account_not_found", "Account not found"));
  }

  /** Case-insensitive lookup by slug. */
  public Optional<Account> findBySlug(String slug) {
    return accounts.findBySlug(slug);
  }
}
