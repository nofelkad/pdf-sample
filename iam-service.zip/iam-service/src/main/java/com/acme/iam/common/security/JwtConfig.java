package com.acme.iam.common.security;

import com.acme.iam.core.revocation.RevocationRegistry;
import com.nimbusds.jose.JWSAlgorithm;
import com.nimbusds.jose.proc.JWSVerificationKeySelector;
import com.nimbusds.jose.proc.SecurityContext;
import com.nimbusds.jwt.proc.DefaultJWTProcessor;
import java.time.Clock;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.crypto.argon2.Argon2PasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.oauth2.core.DelegatingOAuth2TokenValidator;
import org.springframework.security.oauth2.jwt.JwtDecoder;
import org.springframework.security.oauth2.jwt.JwtEncoder;
import org.springframework.security.oauth2.jwt.JwtIssuerValidator;
import org.springframework.security.oauth2.jwt.JwtTimestampValidator;
import org.springframework.security.oauth2.jwt.NimbusJwtDecoder;
import org.springframework.security.oauth2.jwt.NimbusJwtEncoder;

/** JWT encoder/decoder over {@link SigningKeyService}, the in-memory revocation registry and the password encoder. */
@Configuration(proxyBeanMethods = false)
@EnableConfigurationProperties(SecurityProperties.class)
public class JwtConfig {

  /** Signs with the ACTIVE key only. */
  @Bean
  JwtEncoder jwtEncoder(SigningKeyService keys) {
    return new NimbusJwtEncoder(keys.signingJwkSource());
  }

  /**
   * RS256 only (any other {@code alg}, including {@code none} and HMAC, is rejected), keys = ACTIVE + PUBLISHED,
   * validates {@code exp}/{@code nbf} with {@code iam.security.clock-skew}, {@code iss} = {@code iam.security.issuer}
   * and the IAM claim structure ({@link IamTokenValidator}).
   */
  @Bean
  JwtDecoder jwtDecoder(SigningKeyService keys, SecurityProperties properties, Clock clock) {
    DefaultJWTProcessor<SecurityContext> processor = new DefaultJWTProcessor<>();
    processor.setJWSKeySelector(new JWSVerificationKeySelector<>(JWSAlgorithm.RS256, keys.verificationJwkSource()));
    processor.setJWTClaimsSetVerifier((claims, context) -> { }); // claims are validated by the Spring validators below
    NimbusJwtDecoder decoder = new NimbusJwtDecoder(processor);
    JwtTimestampValidator timestamps = new JwtTimestampValidator(properties.clockSkew());
    timestamps.setClock(clock);
    decoder.setJwtValidator(new DelegatingOAuth2TokenValidator<>(
        timestamps, new JwtIssuerValidator(properties.issuer()), new IamTokenValidator()));
    return decoder;
  }

  /** {@code userId -> minSv}, fed by {@code auth.RevocationPoller}, read by {@link RevocationFilter}. */
  @Bean
  RevocationRegistry revocationRegistry(Clock clock) {
    return new RevocationRegistry(clock);
  }

  /** Argon2id (spec section 4) for user passwords. */
  @Bean
  PasswordEncoder passwordEncoder() {
    return Argon2PasswordEncoder.defaultsForSpringSecurity_v5_8();
  }
}
