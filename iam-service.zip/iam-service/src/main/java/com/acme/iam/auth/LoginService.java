package com.acme.iam.auth;

import com.acme.iam.audit.AuditEvent.Outcome;
import com.acme.iam.user.LoginCandidate;
import com.acme.iam.user.UserCredentialService;
import java.time.Clock;
import java.time.Instant;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import org.springframework.lang.Nullable;
import org.springframework.stereotype.Service;

/**
 * Password login (spec section 4 flow, P1-5.2). Rate limiting (step 1) happens before, in the controller.
 *
 * <ol>
 *   <li>Candidates: ACTIVE users with the email, optionally only in the account with the given slug.
 *   <li>One Argon2 verification per candidate, and exactly one against a dummy hash when there is none, so an unknown
 *       email costs the same as a wrong password. A locked candidate ({@code locked_until > now}) is verified too
 *       (same cost) but never matches. An email in several accounts therefore costs one verification per account,
 *       capped at {@value UserCredentialService#MAX_CANDIDATES} candidates (accepted: the number of accounts an email
 *       belongs to is the only thing the timing reveals).
 *   <li>No match: 401 {@code invalid_credentials} "Invalid email or password"; every unlocked candidate's
 *       {@code failed_logins} is incremented and the {@code iam.auth.lockout.max-attempts}-th failure locks it for
 *       {@code iam.auth.lockout.duration} (audited {@value AuthAuditService#LOCKED} once, when applied). A locked user
 *       gets the same 401 even with the right password. Several matches: 409 {@code account_selection_required}
 *       with {@code accounts: [{slug, name}]}.
 *   <li>One match: account, primary tenant and membership must be ACTIVE and the user must still be unlocked
 *       (re-checked inside the final transaction, and again by the conditional bookkeeping {@code UPDATE}, which
 *       waits for and re-evaluates against a concurrent uncommitted lock), otherwise the same 401 (the reason is only in the audit event).
 *       Then failures are reset, {@code last_login_at} set, a session opened, permissions resolved for the primary
 *       tenant and the access token issued.
 * </ol>
 * Every outcome is audited ({@value AuthAuditService#LOGIN_SUCCESS} / {@value AuthAuditService#LOGIN_FAILED}).
 * Argon2 runs outside any transaction so no connection is held while hashing.
 */
@Service
public class LoginService {

  private final UserCredentialService credentials;
  private final PasswordService passwords;
  private final AccessStateQuery access;
  private final SessionService sessions;
  private final AuthAuditService audit;
  private final AuthTransactions tx;
  private final AuthProperties properties;
  private final Clock clock;

  public LoginService(UserCredentialService credentials, PasswordService passwords, AccessStateQuery access,
                      SessionService sessions, AuthAuditService audit, AuthTransactions tx,
                      AuthProperties properties, Clock clock) {
    this.credentials = credentials;
    this.passwords = passwords;
    this.access = access;
    this.sessions = sessions;
    this.audit = audit;
    this.tx = tx;
    this.properties = properties;
    this.clock = clock;
  }

  /**
   * @throws com.acme.iam.common.error.ApiException 401 {@code invalid_credentials}, 409
   *     {@code account_selection_required}
   */
  public AuthTokens login(LoginCommand command, ClientInfo client) {
    String email = command.email().trim();
    String slug = blankToNull(command.account());
    List<LoginCandidate> candidates = credentials.findLoginCandidates(email, slug);
    if (candidates.isEmpty()) {
      passwords.matches(command.password(), null); // timing equality with a wrong password
      audit.event(AuthAuditService.LOGIN_FAILED, client).outcome(Outcome.FAILURE)
          .meta("email", email).meta("account", slug).meta("reason", "unknown_user").write();
      throw AuthErrors.invalidCredentials();
    }

    Instant now = clock.instant();
    List<LoginCandidate> matched = new ArrayList<>();
    List<LoginCandidate> wrong = new ArrayList<>();
    List<LoginCandidate> locked = new ArrayList<>();
    for (LoginCandidate candidate : candidates) {
      boolean ok = passwords.matches(command.password(), candidate.passwordHash());
      if (candidate.isLocked(now)) {
        locked.add(candidate);
      } else if (ok) {
        matched.add(candidate);
      } else {
        wrong.add(candidate);
      }
    }

    if (matched.isEmpty()) {
      tx.write(() -> {
        recordFailures(email, wrong, locked, client);
        return null;
      });
      throw AuthErrors.invalidCredentials();
    }
    if (matched.size() > 1) {
      List<Map<String, String>> accounts = new ArrayList<>();
      for (LoginCandidate candidate : matched) {
        Map<String, String> account = new LinkedHashMap<>();
        account.put("slug", candidate.accountSlug());
        account.put("name", candidate.accountName());
        accounts.add(account);
      }
      tx.write(() -> {
        matched.forEach(c -> audit.event(AuthAuditService.LOGIN_FAILED, client).subject(c.userId(), c.accountId())
            .outcome(Outcome.FAILURE).meta("email", email).meta("reason", "account_selection_required").write());
        return null;
      });
      throw AuthErrors.accountSelectionRequired(accounts);
    }
    return complete(matched.get(0), email, client);
  }

  private void recordFailures(String email, List<LoginCandidate> wrong, List<LoginCandidate> locked,
                              ClientInfo client) {
    AuthProperties.Lockout lockout = properties.lockout();
    for (LoginCandidate candidate : wrong) {
      boolean lockedNow = credentials.recordFailedLogin(candidate.userId(), lockout.maxAttempts(), lockout.duration());
      audit.event(AuthAuditService.LOGIN_FAILED, client).subject(candidate.userId(), candidate.accountId())
          .outcome(Outcome.FAILURE).meta("email", email).meta("reason", "invalid_password").write();
      if (lockedNow) {
        audit.event(AuthAuditService.LOCKED, client).subject(candidate.userId(), candidate.accountId())
            .outcome(Outcome.DENIED).meta("email", email)
            .meta("max_attempts", lockout.maxAttempts()).meta("lock_duration", lockout.duration().toString())
            .write();
      }
    }
    for (LoginCandidate candidate : locked) {
      audit.event(AuthAuditService.LOGIN_FAILED, client).subject(candidate.userId(), candidate.accountId())
          .outcome(Outcome.FAILURE).meta("email", email).meta("reason", "locked").write();
    }
  }

  private AuthTokens complete(LoginCandidate user, String email, ClientInfo client) {
    return tx.<AuthTransactions.Outcome<AuthTokens>>write(() -> {
      Optional<AccessState> loaded = access.load(user.userId(), null);
      Optional<String> denial = loaded.map(AccessState::denial).orElse(Optional.of(AccessState.USER_INACTIVE));
      if (denial.isEmpty() && loaded.get().isLocked(clock.instant())) {
        denial = Optional.of("locked"); // locked by a concurrent attempt since the candidates were read
      }
      if (denial.isPresent()) {
        audit.event(AuthAuditService.LOGIN_FAILED, client).subject(user.userId(), user.accountId())
            .outcome(Outcome.FAILURE).meta("email", email).meta("reason", denial.get()).write();
        return AuthTransactions.Outcome.<AuthTokens>fail(AuthErrors.invalidCredentials());
      }
      AccessState state = loaded.get();
      if (!credentials.recordSuccessfulLogin(user.userId())) { // locked meanwhile (re-evaluated under the row lock)
        audit.event(AuthAuditService.LOGIN_FAILED, client).subject(user.userId(), user.accountId())
            .outcome(Outcome.FAILURE).meta("email", email).meta("reason", "locked").write();
        return AuthTransactions.Outcome.<AuthTokens>fail(AuthErrors.invalidCredentials());
      }
      SessionService.OpenedSession session = sessions.open(user.userId(), state.primaryTenantId(),
          sessions.ttl(state), client);
      audit.event(AuthAuditService.LOGIN_SUCCESS, client)
          .user(user.userId(), state.accountId(), state.primaryTenantId(), session.sessionId())
          .meta("email", email)
          .write();
      return AuthTransactions.Outcome.ok(sessions.issue(user.userId(), state.accountId(), state.primaryTenantId(),
          session.sessionId(), state.sessionVersion(), session.refreshToken(), session.refreshExpiresAt()));
    }).get();
  }

  @Nullable
  private static String blankToNull(@Nullable String value) {
    return value == null || value.isBlank() ? null : value.trim();
  }
}
