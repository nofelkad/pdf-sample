package com.acme.iam.common.security;

import java.time.Duration;
import java.util.Map;
import org.springframework.http.CacheControl;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

/** {@code GET /.well-known/jwks.json}: public keys of every ACTIVE and PUBLISHED signing key (public endpoint). */
@RestController
public class JwksController {

  private final SigningKeyService keys;

  public JwksController(SigningKeyService keys) {
    this.keys = keys;
  }

  @GetMapping(SecurityConfig.JWKS_PATH)
  public ResponseEntity<Map<String, Object>> jwks() {
    return ResponseEntity.ok()
        .cacheControl(CacheControl.maxAge(Duration.ofSeconds(60)).cachePublic())
        .body(keys.jwks());
  }
}
