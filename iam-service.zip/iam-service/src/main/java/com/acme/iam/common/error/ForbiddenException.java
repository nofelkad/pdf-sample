package com.acme.iam.common.error;

import java.util.Map;
import org.springframework.http.HttpStatus;

/**
 * 403 Forbidden. Default code {@value #DEFAULT_CODE}.
 *
 * <p>Final review I1: {@link GlobalExceptionHandler} audits every 403 {@link ApiException} as {@code authz.denied}
 * (spec section 6, "every denial"). Flows that already write their own audit event for the denial (the {@code /auth}
 * endpoints write {@code auth.*} events) throw {@link #alreadyAudited} instead, so the denial is not recorded twice.
 */
public class ForbiddenException extends ApiException {

  public static final String DEFAULT_CODE = "forbidden";

  private final boolean alreadyAudited;

  public ForbiddenException(String detail) {
    this(DEFAULT_CODE, detail);
  }

  public ForbiddenException(String code, String detail) {
    this(code, detail, Map.of());
  }

  public ForbiddenException(String code, String detail, Map<String, Object> properties) {
    this(code, detail, properties, false);
  }

  private ForbiddenException(String code, String detail, Map<String, Object> properties, boolean alreadyAudited) {
    super(HttpStatus.FORBIDDEN, code, detail, properties);
    this.alreadyAudited = alreadyAudited;
  }

  /** A 403 whose denial the throwing flow has already audited (not repeated as {@code authz.denied}). */
  public static ForbiddenException alreadyAudited(String code, String detail) {
    return new ForbiddenException(code, detail, Map.of(), true);
  }

  public boolean isAlreadyAudited() {
    return alreadyAudited;
  }
}
