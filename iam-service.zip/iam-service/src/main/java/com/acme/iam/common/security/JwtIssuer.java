package com.acme.iam.common.security;

import com.acme.iam.common.Ids;
import com.acme.iam.core.Claims;
import java.time.Clock;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.Objects;
import org.springframework.security.oauth2.jose.jws.SignatureAlgorithm;
import org.springframework.security.oauth2.jwt.JwsHeader;
import org.springframework.security.oauth2.jwt.JwtClaimsSet;
import org.springframework.security.oauth2.jwt.JwtEncoder;
import org.springframework.security.oauth2.jwt.JwtEncoderParameters;
import org.springframework.stereotype.Component;

/**
 * Signs IAM tokens with the ACTIVE key (RS256, {@code kid} header). Claims follow spec section 4 exactly; names in
 * {@link Claims}.
 */
@Component
public class JwtIssuer {

  private final JwtEncoder encoder;
  private final SecurityProperties properties;
  private final Clock clock;

  public JwtIssuer(JwtEncoder encoder, SecurityProperties properties, Clock clock) {
    this.encoder = encoder;
    this.properties = properties;
    this.clock = clock;
  }

  /**
   * User access token: {@code iss, sub, acc, tid, sid, sv, perms, iat, exp, jti}, lifetime
   * {@code iam.security.access-token-ttl} (15 min).
   */
  public IssuedJwt issueAccessToken(AccessTokenClaims claims) {
    Objects.requireNonNull(claims, "claims");
    Instant now = clock.instant().truncatedTo(ChronoUnit.SECONDS);
    JwtClaimsSet.Builder set = base(now, now.plus(properties.accessTokenTtl()))
        .subject(claims.userId().toString())
        .claim(Claims.ACCOUNT, claims.accountId().toString())
        .claim(Claims.TENANT, claims.tenantId().toString())
        .claim(Claims.SESSION, claims.sessionId().toString())
        .claim(Claims.SESSION_VERSION, claims.sessionVersion())
        .claim(Claims.PERMISSIONS, claims.permissions());
    return encode(set.build());
  }

  /**
   * Application client token for {@code /internal/*}: {@code sub = "app:<clientId>"}, {@code typ = "app"},
   * {@code prd = productCode}, {@code perms} = {@link Claims#APP_PERMISSIONS}, lifetime
   * {@code iam.security.app-token-ttl} (10 min).
   */
  public IssuedJwt issueAppToken(String clientId, String productCode) {
    Objects.requireNonNull(clientId, "clientId");
    Objects.requireNonNull(productCode, "productCode");
    Instant now = clock.instant().truncatedTo(ChronoUnit.SECONDS);
    JwtClaimsSet.Builder set = base(now, now.plus(properties.appTokenTtl()))
        .subject(Claims.APP_SUBJECT_PREFIX + clientId)
        .claim(Claims.TYPE, Claims.TYPE_APP)
        .claim(Claims.PRODUCT, productCode)
        .claim(Claims.PERMISSIONS, Claims.APP_PERMISSIONS);
    return encode(set.build());
  }

  private JwtClaimsSet.Builder base(Instant now, Instant expiresAt) {
    return JwtClaimsSet.builder()
        .issuer(properties.issuer())
        .issuedAt(now)
        .expiresAt(expiresAt)
        .id(Ids.newId().toString());
  }

  private IssuedJwt encode(JwtClaimsSet claims) {
    JwsHeader header = JwsHeader.with(SignatureAlgorithm.RS256).build();
    String value = encoder.encode(JwtEncoderParameters.from(header, claims)).getTokenValue();
    return new IssuedJwt(value, claims.getId(), claims.getIssuedAt(), claims.getExpiresAt());
  }
}
