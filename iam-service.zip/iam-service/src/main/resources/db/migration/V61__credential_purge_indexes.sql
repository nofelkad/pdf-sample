-- V61 (final review M2): indexes for user_token / user_session housekeeping.
-- user_token(user_id): invalidateOutstanding (resend, reset), deprovisioning and the purge look tokens up by user; V1
-- had no index, so each of those scanned the whole table.
CREATE INDEX user_token_user_idx ON user_token (user_id);
-- CredentialPurgeJob deletes used/expired tokens and revoked/expired sessions older than the retention (30 days). Every
-- used token and revoked session also expired by then (tokens live at most 7 days, sessions 12 hours), so the
-- expires_at ranges find them without a full scan.
CREATE INDEX user_token_expires_idx ON user_token (expires_at);
CREATE INDEX user_session_expires_idx ON user_session (expires_at);
