-- V4: privileges for the DML-only application role (P1-2.3).
-- The roles themselves are environment setup (docker/postgres/init/01-roles.sh, test init script), not Flyway.
-- This migration runs as iam_migrator, which owns every object it creates.

GRANT USAGE ON SCHEMA public TO iam_app;

GRANT SELECT, INSERT, UPDATE, DELETE ON ALL TABLES IN SCHEMA public TO iam_app;
GRANT USAGE, SELECT ON ALL SEQUENCES IN SCHEMA public TO iam_app;

-- audit_event is append-only for the app: INSERT and SELECT only, on the parent and on every existing partition
-- (audit_ensure_partitions applies the same revoke to partitions it creates later).
REVOKE UPDATE, DELETE, TRUNCATE ON audit_event FROM iam_app;
DO $$ DECLARE p regclass; BEGIN
  FOR p IN SELECT inhrelid::regclass FROM pg_inherits WHERE inhparent = 'audit_event'::regclass LOOP
    EXECUTE format('REVOKE UPDATE, DELETE, TRUNCATE ON %s FROM iam_app', p);
  END LOOP;
END $$;

-- Flyway bookkeeping is not the app's business
REVOKE ALL ON "${flyway:table}" FROM iam_app;

-- Runtime DDL goes through SECURITY DEFINER functions owned by the migrator (Ruling R3)
GRANT EXECUTE ON FUNCTION audit_ensure_partitions(int) TO iam_app;

-- Objects created by later migrations (also run as iam_migrator) get the same privileges automatically.
-- A later table that must be append-only for the app has to REVOKE explicitly in its own migration.
ALTER DEFAULT PRIVILEGES FOR ROLE iam_migrator IN SCHEMA public
  GRANT SELECT, INSERT, UPDATE, DELETE ON TABLES TO iam_app;
ALTER DEFAULT PRIVILEGES FOR ROLE iam_migrator IN SCHEMA public
  GRANT USAGE, SELECT ON SEQUENCES TO iam_app;
-- Functions (notably SECURITY DEFINER ones) are executable by the app role only, not by PUBLIC
ALTER DEFAULT PRIVILEGES FOR ROLE iam_migrator
  REVOKE EXECUTE ON FUNCTIONS FROM PUBLIC;
ALTER DEFAULT PRIVILEGES FOR ROLE iam_migrator IN SCHEMA public
  GRANT EXECUTE ON FUNCTIONS TO iam_app;
