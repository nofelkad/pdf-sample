-- V60 (final review C1): a trigger row's account_id/tenant_id belong to the AFFECTED RESOURCE, not to the actor's
-- token. Until V6 they came from app.account_id/app.tenant_id (the JWT acc/tid), so an Account Admin active in T2
-- inviting into T3 filed the rows under T2, and platform operations on account X were filed under PLATFORM. Tenant-scoped
-- audit search (ruling R25) filters on tenant_id and account search on account_id, so those rows were shown to the wrong
-- tenant and hidden from the right account.
--
-- Resolution, per row (r = NEW for INSERT/UPDATE, OLD for DELETE). Row columns first; the transaction settings only
-- fill what the row cannot tell:
--
--   table                    account_id                                   tenant_id
--   account                  id                                           (fallback)
--   account_product          account                                      (fallback)
--   tenant                   account_id                                   id
--   tenant_product           tenant -> tenant.account_id (PK lookup)      tenant
--   app_user                 account_id                                   primary_tenant_id
--   user_tenant_membership   tenant_id -> tenant.account_id (PK lookup)   tenant_id
--   role                     account_id (CUSTOM; NULL for SYSTEM)         (fallback)
--   role_permission          role -> role.account_id (PK lookup)          (fallback)
--   role_assignment          scope_id when scope_type = 'ACCOUNT',        scope_id when scope_type = 'TENANT'
--                            else scope_id -> tenant.account_id (PK)
--   product, permission,     (fallback: not account data)                 (fallback)
--   signing_key, app_client
--
-- Fallbacks: account_id falls back to app.account_id only when the row resolves none (global tables, SYSTEM roles,
-- a lookup whose parent row is gone in the same statement). tenant_id falls back to app.tenant_id only when the row
-- resolves no tenant AND the resolved account is the actor's own account (or none): an account-level change made from
-- inside the account stays visible to the actor's active tenant as before, but a platform operator's PLATFORM tenant is
-- never stamped on a customer account's row (that row then carries tenant_id NULL: an account-level row, visible to the
-- account's ACCOUNT-scope auditors only, R25).
--
-- Lookups are single primary-key probes (tenant.id, role.id), at most one per row, and deterministic: the same row in
-- the same database state always resolves to the same account. Everything else is identical to V6: source from
-- app.source, metadata.client_id from app.client_id, the stripped secret columns, action/target naming.
CREATE OR REPLACE FUNCTION iam_audit() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE b JSONB; a JSONB; r JSONB; client TEXT; acc UUID; ten UUID; ctx_acc UUID;
BEGIN
  IF TG_OP <> 'INSERT' THEN b := to_jsonb(OLD) - 'password_hash' - 'refresh_hash' - 'prev_refresh_hash' - 'token_hash' - 'private_enc' - 'secret_hash'; END IF;
  IF TG_OP <> 'DELETE' THEN a := to_jsonb(NEW) - 'password_hash' - 'refresh_hash' - 'prev_refresh_hash' - 'token_hash' - 'private_enc' - 'secret_hash'; END IF;
  r := COALESCE(a, b);
  client := NULLIF(current_setting('app.client_id', true), '');
  ctx_acc := NULLIF(current_setting('app.account_id', true), '')::uuid;

  -- 1. what the row itself says
  acc := CASE TG_TABLE_NAME
           WHEN 'account'         THEN (r->>'id')::uuid
           WHEN 'account_product' THEN (r->>'account')::uuid
           WHEN 'tenant'          THEN (r->>'account_id')::uuid
           WHEN 'app_user'        THEN (r->>'account_id')::uuid
           WHEN 'role'            THEN (r->>'account_id')::uuid
           WHEN 'role_assignment' THEN CASE WHEN r->>'scope_type' = 'ACCOUNT' THEN (r->>'scope_id')::uuid END
         END;
  ten := CASE TG_TABLE_NAME
           WHEN 'tenant'                 THEN (r->>'id')::uuid
           WHEN 'tenant_product'         THEN (r->>'tenant')::uuid
           WHEN 'app_user'               THEN (r->>'primary_tenant_id')::uuid
           WHEN 'user_tenant_membership' THEN (r->>'tenant_id')::uuid
           WHEN 'role_assignment'        THEN CASE WHEN r->>'scope_type' = 'TENANT' THEN (r->>'scope_id')::uuid END
         END;

  -- 2. one primary-key lookup for child tables that carry no account_id
  IF acc IS NULL AND ten IS NOT NULL THEN
    SELECT t.account_id INTO acc FROM tenant t WHERE t.id = ten;
  ELSIF acc IS NULL AND TG_TABLE_NAME = 'role_permission' THEN
    SELECT ro.account_id INTO acc FROM role ro WHERE ro.id = (r->>'role')::uuid;
  END IF;

  -- 3. the transaction settings fill the gaps (tenant only inside the actor's own account)
  IF ten IS NULL AND (acc IS NULL OR acc = ctx_acc) THEN
    ten := NULLIF(current_setting('app.tenant_id', true), '')::uuid;
  END IF;
  IF acc IS NULL THEN
    acc := ctx_acc;
  END IF;

  INSERT INTO audit_event (event_id, occurred_at, account_id, tenant_id, source, actor_user_id, actor_type,
                           request_id, session_id, action, target_type, target_id, outcome, before_state, after_state,
                           metadata)
  VALUES (gen_random_uuid(), clock_timestamp(),
          acc,
          ten,
          COALESCE(NULLIF(current_setting('app.source', true), ''), 'IAM'),
          NULLIF(current_setting('app.user_id', true), '')::uuid,
          CASE WHEN COALESCE(current_setting('app.user_id', true), '') = '' THEN 'SYSTEM' ELSE 'USER' END,
          NULLIF(current_setting('app.request_id', true), ''),
          NULLIF(current_setting('app.session_id', true), '')::uuid,
          'iam.' || TG_TABLE_NAME || '.' || lower(TG_OP),
          TG_TABLE_NAME,
          COALESCE(r->>'id', r->>'kid', concat_ws(':', r->>'app_user', r->>'role', r->>'tenant', r->>'account', r->>'tenant_id', r->>'permission_id', r->>'product_id')),
          'SUCCESS', b, a,
          CASE WHEN client IS NOT NULL THEN jsonb_build_object('client_id', client) END);
  RETURN NULL;
END $$;
