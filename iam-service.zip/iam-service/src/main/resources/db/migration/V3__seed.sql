-- V3: seed data. Copied verbatim from 01-phase-1.md section 2 (V3__seed.sql).

INSERT INTO product (id, code, name, version) VALUES ('00000000-0000-7000-8000-000000000001', 'IAM', 'Identity & Access', 0);

-- The platform operator account (your company); its admins can create customer accounts
INSERT INTO account (id, name, slug, kind, status, version) VALUES
  ('00000000-0000-7000-8000-0000000000a1', 'Platform', 'platform', 'PLATFORM', 'ACTIVE', 0);
-- tenant + first operator user created by a bootstrap CLI command (task P1-6.4), not by SQL
