-- V10 (Task 2): indexes for the keyset-paginated read models (P1-3.4).
-- The permission resolver (spec section 5) needs no new index: EXPLAIN shows primary/unique key lookups only
-- (see PermissionResolverPlanIT).

-- User list: WHERE account_id = ? [AND status = ?] ORDER BY created_at DESC, id DESC
CREATE INDEX app_user_account_created_idx        ON app_user (account_id, created_at DESC, id DESC);
CREATE INDEX app_user_account_status_created_idx ON app_user (account_id, status, created_at DESC, id DESC);

-- Role list assignment counts: per role, count unexpired assignments at the account scope and at its tenants.
-- INCLUDE (expires_at) lets the count run as an index-only scan. The leading column serves every former use of
-- ra_role_idx (role_id), which is dropped to save write cost.
CREATE INDEX ra_role_scope_idx ON role_assignment (role_id, scope_type, scope_id) INCLUDE (expires_at);
DROP INDEX ra_role_idx;

-- Role list: "account_id IS NULL OR account_id = ?" -> BitmapOr of this and role_account_idx.
CREATE INDEX role_system_idx ON role (product_id) WHERE account_id IS NULL;
