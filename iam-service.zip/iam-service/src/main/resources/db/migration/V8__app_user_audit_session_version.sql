-- V8 (Task 3, Ruling R15): a session_version bump alone is not an app_user data change worth one audit row per user.
-- RevocationService writes one auth.sessions.revoked summary event per revocation instead.
-- Same trigger as V2, with session_version added to the ignored columns on both sides of the WHEN clause.
DROP TRIGGER app_user_audit_upd ON app_user;
CREATE TRIGGER app_user_audit_upd AFTER UPDATE ON app_user
  FOR EACH ROW
  WHEN ((to_jsonb(OLD) - 'last_login_at' - 'failed_logins' - 'locked_until' - 'updated_at' - 'version' - 'session_version')
        IS DISTINCT FROM
        (to_jsonb(NEW) - 'last_login_at' - 'failed_logins' - 'locked_until' - 'updated_at' - 'version' - 'session_version'))
  EXECUTE FUNCTION iam_audit();
