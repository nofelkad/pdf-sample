-- V50 (Task 7): runtime partition operations for the audit log (P1-9.2, P1-9.3, Ruling R3).
-- Both functions are owned by iam_migrator (the role running this migration), run SECURITY DEFINER with a pinned
-- search_path and are executable by iam_app only, so the DML-only application role can run the ShedLock jobs without
-- DDL rights.

-- 1. audit_ensure_partitions: same behaviour as V2, plus a transaction-level advisory lock so that concurrent callers
--    (two instances starting together, the startup run racing the daily job) queue instead of failing with
--    "relation already exists" on CREATE TABLE ... PARTITION OF (which takes ACCESS EXCLUSIVE on the parent).
CREATE OR REPLACE FUNCTION audit_ensure_partitions(months_ahead int) RETURNS int
  LANGUAGE plpgsql SECURITY DEFINER SET search_path = public, pg_temp AS $$
DECLARE
  base    timestamp;
  m_start timestamp;
  part    text;
  created int := 0;
BEGIN
  IF months_ahead IS NULL OR months_ahead < 0 OR months_ahead > 24 THEN
    RAISE EXCEPTION 'months_ahead must be between 0 and 24, got %', months_ahead;
  END IF;
  PERFORM pg_advisory_xact_lock(hashtext('iam.audit.partition_ddl'));
  base := date_trunc('month', now() AT TIME ZONE 'UTC');
  FOR i IN 0..months_ahead LOOP
    m_start := base + make_interval(months => i);
    part := format('audit_event_y%sm%s', to_char(m_start, 'YYYY'), to_char(m_start, 'MM'));
    IF to_regclass(format('public.%I', part)) IS NULL THEN
      EXECUTE format('CREATE TABLE IF NOT EXISTS public.%I PARTITION OF public.audit_event FOR VALUES FROM (%L) TO (%L)',
                     part, m_start AT TIME ZONE 'UTC', (m_start + interval '1 month') AT TIME ZONE 'UTC');
      -- partitions inherit the default DML grants of their owner; keep them append-only for the app role
      EXECUTE format('REVOKE UPDATE, DELETE, TRUNCATE ON public.%I FROM iam_app', part);
      created := created + 1;
    END IF;
  END LOOP;
  RETURN created;
END $$;
REVOKE ALL ON FUNCTION audit_ensure_partitions(int) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION audit_ensure_partitions(int) TO iam_app;

-- 2. audit_detach_partition: DETACH PARTITION + DROP TABLE of one monthly partition, in one transaction.
--    Design: a single function. The application calls it only AFTER the archive hook has archived the partition while
--    it is still attached (and therefore still readable through audit_event), so there is no state in which data is
--    detached but not yet archived. Guards, all enforced here and not only in Java:
--      * the name must be audit_event_yYYYYmMM (month 01-12) and the table must be a real child of audit_event
--        (an existing table with that name that is not a child, for example one detached by hand, raises an error and
--        is never dropped); an unknown name returns false, so a second instance running the same job is a no-op;
--      * the partition must have ended at least 90 days ago: a bug or a misconfigured retention must not be able to
--        drop recent audit data;
--      * lock_timeout 10 s: DETACH needs a brief ACCESS EXCLUSIVE lock on audit_event; on contention the call fails
--        (and is retried by the next run) instead of queueing ingest behind it.
--    Returns true when the partition was detached and dropped.
CREATE FUNCTION audit_detach_partition(partition_name text) RETURNS boolean
  LANGUAGE plpgsql SECURITY DEFINER SET search_path = public, pg_temp SET lock_timeout = '10s' AS $$
DECLARE
  part      regclass;
  y         int;
  m         int;
  range_end timestamptz;
BEGIN
  IF partition_name IS NULL OR partition_name !~ '^audit_event_y[0-9]{4}m(0[1-9]|1[0-2])$' THEN
    RAISE EXCEPTION 'invalid audit partition name: %', partition_name USING ERRCODE = '22023';
  END IF;
  y := substr(partition_name, 14, 4)::int;
  m := substr(partition_name, 19, 2)::int;
  range_end := (make_timestamp(y, m, 1, 0, 0, 0) + interval '1 month') AT TIME ZONE 'UTC';
  IF range_end > now() - interval '90 days' THEN
    RAISE EXCEPTION 'audit partition % ends at %, less than 90 days ago: refusing to drop it', partition_name, range_end
      USING ERRCODE = '22023';
  END IF;

  PERFORM pg_advisory_xact_lock(hashtext('iam.audit.partition_ddl'));
  part := to_regclass(format('public.%I', partition_name));
  IF part IS NULL THEN
    RETURN false;
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_inherits WHERE inhparent = 'public.audit_event'::regclass AND inhrelid = part) THEN
    RAISE EXCEPTION '% is not a partition of audit_event', partition_name USING ERRCODE = '22023';
  END IF;

  EXECUTE format('ALTER TABLE public.audit_event DETACH PARTITION public.%I', partition_name);
  EXECUTE format('DROP TABLE public.%I', partition_name);
  RETURN true;
END $$;
REVOKE ALL ON FUNCTION audit_detach_partition(text) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION audit_detach_partition(text) TO iam_app;
