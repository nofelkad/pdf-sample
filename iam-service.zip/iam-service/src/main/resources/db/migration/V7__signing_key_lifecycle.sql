-- V7 (Task 3, P1-4.2): key rotation bookkeeping.
-- A key is created PUBLISHED, promoted to ACTIVE after iam.security.key-publish-lead, demoted back to PUBLISHED when
-- its successor is promoted, and RETIRED once every token it signed has expired. Retirement is measured from the
-- demotion, not from creation, hence demoted_at.
ALTER TABLE signing_key
  ADD COLUMN activated_at TIMESTAMPTZ,
  ADD COLUMN demoted_at   TIMESTAMPTZ;

-- At most one signing key at a time.
CREATE UNIQUE INDEX signing_key_one_active_uq ON signing_key ((true)) WHERE status = 'ACTIVE';
