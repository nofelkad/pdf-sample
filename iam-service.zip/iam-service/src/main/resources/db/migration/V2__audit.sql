-- V2: audit log. Section 2 text (V2__audit.sql) copied verbatim, followed by the partition bootstrap (Ruling R3).

CREATE TABLE audit_event (
  event_id       UUID NOT NULL,
  occurred_at    TIMESTAMPTZ NOT NULL,
  received_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
  account_id     UUID,
  tenant_id      UUID,
  source         TEXT NOT NULL,                       -- 'IAM' or calling application code
  actor_user_id  UUID,
  actor_type     TEXT NOT NULL CHECK (actor_type IN ('USER','SYSTEM','ANONYMOUS')),
  actor_ip       INET,
  user_agent     TEXT,
  session_id     UUID,
  request_id     TEXT,
  action         TEXT NOT NULL,                       -- noun.verb, e.g. iam.role_assignment.insert, auth.login.failed
  target_type    TEXT,
  target_id      TEXT,
  outcome        TEXT NOT NULL CHECK (outcome IN ('SUCCESS','DENIED','FAILURE')),
  before_state   JSONB,
  after_state    JSONB,
  metadata       JSONB,
  PRIMARY KEY (occurred_at, event_id)
) PARTITION BY RANGE (occurred_at);

CREATE INDEX ae_tenant_time_idx  ON audit_event (tenant_id, occurred_at DESC);
CREATE INDEX ae_account_time_idx ON audit_event (account_id, occurred_at DESC);
CREATE INDEX ae_actor_idx        ON audit_event (actor_user_id, occurred_at DESC);
CREATE INDEX ae_target_idx       ON audit_event (target_type, target_id, occurred_at DESC);
CREATE INDEX ae_action_idx       ON audit_event (action, occurred_at DESC);

-- append-only
CREATE FUNCTION audit_immutable() RETURNS trigger LANGUAGE plpgsql AS
$$ BEGIN RAISE EXCEPTION 'audit_event is append-only'; END $$;
CREATE TRIGGER audit_event_immutable BEFORE UPDATE OR DELETE ON audit_event
  FOR EACH ROW EXECUTE FUNCTION audit_immutable();
-- app DB role gets INSERT, SELECT only on audit_event

-- Row-change capture for every IAM table. Actor/request come from transaction-local settings.
CREATE FUNCTION iam_audit() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE b JSONB; a JSONB; r JSONB;
BEGIN
  IF TG_OP <> 'INSERT' THEN b := to_jsonb(OLD) - 'password_hash' - 'refresh_hash' - 'prev_refresh_hash' - 'token_hash' - 'private_enc'; END IF;
  IF TG_OP <> 'DELETE' THEN a := to_jsonb(NEW) - 'password_hash' - 'refresh_hash' - 'prev_refresh_hash' - 'token_hash' - 'private_enc'; END IF;
  r := COALESCE(a, b);
  INSERT INTO audit_event (event_id, occurred_at, account_id, tenant_id, source, actor_user_id, actor_type,
                           request_id, session_id, action, target_type, target_id, outcome, before_state, after_state)
  VALUES (gen_random_uuid(), clock_timestamp(),
          NULLIF(current_setting('app.account_id', true), '')::uuid,
          NULLIF(current_setting('app.tenant_id',  true), '')::uuid,
          'IAM',
          NULLIF(current_setting('app.user_id', true), '')::uuid,
          CASE WHEN COALESCE(current_setting('app.user_id', true), '') = '' THEN 'SYSTEM' ELSE 'USER' END,
          NULLIF(current_setting('app.request_id', true), ''),
          NULLIF(current_setting('app.session_id', true), '')::uuid,
          'iam.' || TG_TABLE_NAME || '.' || lower(TG_OP),
          TG_TABLE_NAME,
          COALESCE(r->>'id', r->>'kid', concat_ws(':', r->>'app_user', r->>'role', r->>'tenant', r->>'account', r->>'tenant_id', r->>'permission_id', r->>'product_id')),
          'SUCCESS', b, a);
  RETURN NULL;
END $$;

DO $$ DECLARE t TEXT; BEGIN
  FOREACH t IN ARRAY ARRAY['account','account_product','tenant','tenant_product','product','permission',
                           'user_tenant_membership','role','role_permission','role_assignment','signing_key'] LOOP
    EXECUTE format('CREATE TRIGGER %1$s_audit AFTER INSERT OR UPDATE OR DELETE ON %1$s
                    FOR EACH ROW EXECUTE FUNCTION iam_audit()', t);
  END LOOP;
END $$;

-- app_user: skip updates that only touch login bookkeeping (last_login_at, failed_logins); those are auth.* events
CREATE TRIGGER app_user_audit_ins_del AFTER INSERT OR DELETE ON app_user
  FOR EACH ROW EXECUTE FUNCTION iam_audit();
CREATE TRIGGER app_user_audit_upd AFTER UPDATE ON app_user
  FOR EACH ROW
  WHEN ((to_jsonb(OLD) - 'last_login_at' - 'failed_logins' - 'locked_until' - 'updated_at' - 'version')
        IS DISTINCT FROM
        (to_jsonb(NEW) - 'last_login_at' - 'failed_logins' - 'locked_until' - 'updated_at' - 'version'))
  EXECUTE FUNCTION iam_audit();

-- No triggers on user_session, user_token, password_history, revocation:
-- AuthAuditService writes explicit auth.* events for those (cleaner, no secrets, no noise).

-- ===== Monthly partitions (Ruling R3) =====
-- Partitions are named audit_event_yYYYYmMM and cover [first day of the month 00:00 UTC, first day of next month).
-- SECURITY DEFINER: owned by iam_migrator (the role running this migration) so that the DML-only app role can run
-- the ShedLock partition job (Task 7) without DDL rights. EXECUTE is granted to iam_app in V4.
CREATE FUNCTION audit_ensure_partitions(months_ahead int) RETURNS int
  LANGUAGE plpgsql SECURITY DEFINER SET search_path = public, pg_temp AS $$
DECLARE
  base    timestamp := date_trunc('month', now() AT TIME ZONE 'UTC');
  m_start timestamp;
  part    text;
  created int := 0;
BEGIN
  IF months_ahead IS NULL OR months_ahead < 0 OR months_ahead > 24 THEN
    RAISE EXCEPTION 'months_ahead must be between 0 and 24, got %', months_ahead;
  END IF;
  FOR i IN 0..months_ahead LOOP
    m_start := base + make_interval(months => i);
    part := format('audit_event_y%sm%s', to_char(m_start, 'YYYY'), to_char(m_start, 'MM'));
    IF to_regclass(part) IS NULL THEN
      EXECUTE format('CREATE TABLE IF NOT EXISTS %I PARTITION OF audit_event FOR VALUES FROM (%L) TO (%L)',
                     part, m_start AT TIME ZONE 'UTC', (m_start + interval '1 month') AT TIME ZONE 'UTC');
      -- partitions inherit the default DML grants of their owner; keep them append-only for the app role
      EXECUTE format('REVOKE UPDATE, DELETE, TRUNCATE ON %I FROM iam_app', part);
      created := created + 1;
    END IF;
  END LOOP;
  RETURN created;
END $$;
REVOKE ALL ON FUNCTION audit_ensure_partitions(int) FROM PUBLIC;

-- initial partitions: the current month + 3 ahead
SELECT audit_ensure_partitions(3);
