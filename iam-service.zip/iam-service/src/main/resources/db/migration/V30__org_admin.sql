-- V30 (Task 5): bulk invite jobs (P1-8.4) and indexes for the account/tenant admin lists (P1-6.1, P1-6.3).

-- One CSV bulk invite. Rows are validated first; a job with any invalid row ends FAILED with every error and inserts
-- nothing. errors = [{"row": <line in file>, "email": "...", "code": "snake_case", "message": "..."}].
-- No audit trigger: the users, memberships and assignments it creates are audited by their own triggers, and the job
-- writes one iam.bulk_invite.completed / .failed event.
CREATE TABLE bulk_invite_job (
  id            UUID PRIMARY KEY,
  account_id    UUID NOT NULL REFERENCES account(id),
  tenant_id     UUID NOT NULL REFERENCES tenant(id),
  created_by    UUID REFERENCES app_user(id),
  status        TEXT NOT NULL CHECK (status IN ('PENDING','RUNNING','COMPLETED','FAILED')),
  total_rows    INT  NOT NULL,
  created_count INT  NOT NULL DEFAULT 0,
  error_count   INT  NOT NULL DEFAULT 0,
  errors        JSONB NOT NULL DEFAULT '[]',
  created_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
  started_at    TIMESTAMPTZ,
  finished_at   TIMESTAMPTZ
);
CREATE INDEX bulk_invite_job_account_idx ON bulk_invite_job (account_id, created_at DESC);

-- Tenant list: WHERE account_id = ? [AND status = ?] ORDER BY created_at DESC, id DESC
CREATE INDEX tenant_account_created_idx ON tenant (account_id, created_at DESC, id DESC);
-- Platform account list: ORDER BY created_at DESC, id DESC
CREATE INDEX account_created_idx ON account (created_at DESC, id DESC);
