-- V5 (Task 3, P1-12.1): registered application clients for service-to-service calls to /internal/*.
-- A client authenticates with HTTP Basic clientId:secret at POST /internal/token and receives a short-lived JWT.
-- The secret is 32 random bytes (base64url), shown once; only its SHA-256 is stored (secret_hash).
CREATE TABLE app_client (
  id            UUID PRIMARY KEY,
  client_id     TEXT  NOT NULL UNIQUE CHECK (client_id ~ '^[a-z0-9][a-z0-9._-]{2,63}$'),
  product_code  TEXT  NOT NULL,                       -- no FK: the product may first appear with the app's manifest
  secret_hash   BYTEA NOT NULL,
  status        TEXT  NOT NULL CHECK (status IN ('ACTIVE','DISABLED')),
  created_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
  version       BIGINT NOT NULL
);

-- Registration changes are IAM data changes: audited by the row trigger (V6 strips secret_hash from the snapshots).
CREATE TRIGGER app_client_audit AFTER INSERT OR UPDATE OR DELETE ON app_client
  FOR EACH ROW EXECUTE FUNCTION iam_audit();
