-- V6 (Task 3, Ruling R9): attribute row changes made by application clients.
-- AuditContextTransactionManager sets two more transaction-local settings when the caller is an application token
-- (typ=app): app.source = 'app:<clientId>' and app.client_id = '<clientId>' ('' otherwise).
-- Changes from V2: source comes from app.source (default 'IAM'); metadata carries {client_id} when app.client_id is
-- set; secret_hash (app_client, V5) is stripped like the other secret columns. actor_type stays SYSTEM for app
-- callers because app.user_id is empty for them. Everything else is identical to V2.
CREATE OR REPLACE FUNCTION iam_audit() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE b JSONB; a JSONB; r JSONB; client TEXT;
BEGIN
  IF TG_OP <> 'INSERT' THEN b := to_jsonb(OLD) - 'password_hash' - 'refresh_hash' - 'prev_refresh_hash' - 'token_hash' - 'private_enc' - 'secret_hash'; END IF;
  IF TG_OP <> 'DELETE' THEN a := to_jsonb(NEW) - 'password_hash' - 'refresh_hash' - 'prev_refresh_hash' - 'token_hash' - 'private_enc' - 'secret_hash'; END IF;
  r := COALESCE(a, b);
  client := NULLIF(current_setting('app.client_id', true), '');
  INSERT INTO audit_event (event_id, occurred_at, account_id, tenant_id, source, actor_user_id, actor_type,
                           request_id, session_id, action, target_type, target_id, outcome, before_state, after_state,
                           metadata)
  VALUES (gen_random_uuid(), clock_timestamp(),
          NULLIF(current_setting('app.account_id', true), '')::uuid,
          NULLIF(current_setting('app.tenant_id',  true), '')::uuid,
          COALESCE(NULLIF(current_setting('app.source', true), ''), 'IAM'),
          NULLIF(current_setting('app.user_id', true), '')::uuid,
          CASE WHEN COALESCE(current_setting('app.user_id', true), '') = '' THEN 'SYSTEM' ELSE 'USER' END,
          NULLIF(current_setting('app.request_id', true), ''),
          NULLIF(current_setting('app.session_id', true), '')::uuid,
          'iam.' || TG_TABLE_NAME || '.' || lower(TG_OP),
          TG_TABLE_NAME,
          COALESCE(r->>'id', r->>'kid', concat_ws(':', r->>'app_user', r->>'role', r->>'tenant', r->>'account', r->>'tenant_id', r->>'permission_id', r->>'product_id')),
          'SUCCESS', b, a,
          CASE WHEN client IS NOT NULL THEN jsonb_build_object('client_id', client) END);
  RETURN NULL;
END $$;
