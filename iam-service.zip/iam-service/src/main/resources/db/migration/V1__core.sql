-- V1: core schema. Copied verbatim from 01-phase-1.md section 2 (V1__core.sql).

CREATE EXTENSION IF NOT EXISTS citext;

-- ===== Commercial & isolation =====
CREATE TABLE account (
  id          UUID PRIMARY KEY,
  name        TEXT   NOT NULL,
  slug        CITEXT NOT NULL UNIQUE,                 -- used in login when an email exists in >1 account
  kind        TEXT   NOT NULL DEFAULT 'CUSTOMER' CHECK (kind IN ('CUSTOMER','PLATFORM')),
  status      TEXT   NOT NULL CHECK (status IN ('ACTIVE','SUSPENDED','CLOSED')),
  settings    JSONB  NOT NULL DEFAULT '{}',           -- password policy, token lifetimes
  version     BIGINT NOT NULL,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE product (
  id          UUID PRIMARY KEY,
  code        TEXT UNIQUE NOT NULL,                   -- IAM, BILLING, CRM …
  name        TEXT NOT NULL,
  version     BIGINT NOT NULL
);

CREATE TABLE account_product (
  account     UUID NOT NULL REFERENCES account(id) ON DELETE CASCADE,
  product_id  UUID NOT NULL REFERENCES product(id),
  status      TEXT NOT NULL CHECK (status IN ('ACTIVE','TRIAL','SUSPENDED','EXPIRED')),
  starts_at   DATE NOT NULL,
  ends_at     DATE,
  PRIMARY KEY (account, product_id)
);

CREATE TABLE tenant (
  id          UUID PRIMARY KEY,
  account_id  UUID   NOT NULL REFERENCES account(id),
  name        TEXT   NOT NULL,
  slug        CITEXT NOT NULL,
  status      TEXT   NOT NULL CHECK (status IN ('ACTIVE','SUSPENDED','ARCHIVED')),
  settings    JSONB  NOT NULL DEFAULT '{}',
  version     BIGINT NOT NULL,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (account_id, slug)
);
CREATE INDEX tenant_account_idx ON tenant(account_id);

CREATE TABLE tenant_product (
  tenant      UUID NOT NULL REFERENCES tenant(id) ON DELETE CASCADE,
  product_id  UUID NOT NULL REFERENCES product(id),
  enabled     BOOLEAN NOT NULL DEFAULT true,
  PRIMARY KEY (tenant, product_id)
);

-- ===== Identity =====
CREATE TABLE app_user (
  id                  UUID PRIMARY KEY,
  account_id          UUID   NOT NULL REFERENCES account(id),
  email               CITEXT NOT NULL,
  display_name        TEXT,
  status              TEXT   NOT NULL CHECK (status IN ('INVITED','ACTIVE','DISABLED','DEPROVISIONED')),
  primary_tenant_id   UUID   NOT NULL REFERENCES tenant(id),
  password_hash       TEXT,                           -- Argon2id, NULL until invitation accepted
  password_changed_at TIMESTAMPTZ,
  failed_logins       INT    NOT NULL DEFAULT 0,
  locked_until        TIMESTAMPTZ,
  session_version     INT    NOT NULL DEFAULT 1,
  last_login_at       TIMESTAMPTZ,
  version             BIGINT NOT NULL,
  created_at          TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at          TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (account_id, email)
);
CREATE INDEX app_user_email_idx ON app_user(email);

CREATE TABLE user_tenant_membership (                 -- owned by AppUser aggregate
  app_user    UUID NOT NULL REFERENCES app_user(id) ON DELETE CASCADE,
  tenant_id   UUID NOT NULL REFERENCES tenant(id),
  status      TEXT NOT NULL DEFAULT 'ACTIVE' CHECK (status IN ('ACTIVE','SUSPENDED')),
  added_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
  PRIMARY KEY (app_user, tenant_id)
);
CREATE INDEX utm_tenant_idx ON user_tenant_membership(tenant_id);

CREATE TABLE password_history (
  user_id       UUID NOT NULL REFERENCES app_user(id),
  password_hash TEXT NOT NULL,
  changed_at    TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX password_history_user_idx ON password_history(user_id, changed_at DESC);

CREATE TABLE user_token (                             -- invitation & password reset
  id          UUID PRIMARY KEY,
  user_id     UUID  NOT NULL REFERENCES app_user(id),
  purpose     TEXT  NOT NULL CHECK (purpose IN ('INVITE','PASSWORD_RESET')),
  token_hash  BYTEA NOT NULL UNIQUE,                  -- SHA-256 of a 256-bit random token
  expires_at  TIMESTAMPTZ NOT NULL,
  used_at     TIMESTAMPTZ,
  created_by  UUID REFERENCES app_user(id),
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE user_session (
  id                UUID PRIMARY KEY,
  user_id           UUID  NOT NULL REFERENCES app_user(id),
  active_tenant_id  UUID  NOT NULL REFERENCES tenant(id),
  refresh_hash      BYTEA NOT NULL UNIQUE,
  prev_refresh_hash BYTEA,                            -- refresh-token reuse detection
  ip                INET,
  user_agent        TEXT,
  created_at        TIMESTAMPTZ NOT NULL DEFAULT now(),
  last_seen_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
  expires_at        TIMESTAMPTZ NOT NULL,             -- absolute lifetime
  revoked_at        TIMESTAMPTZ,
  version           BIGINT NOT NULL
);
CREATE INDEX user_session_user_idx ON user_session(user_id) WHERE revoked_at IS NULL;
CREATE INDEX user_session_prev_idx ON user_session(prev_refresh_hash) WHERE prev_refresh_hash IS NOT NULL;

-- ===== Authorization =====
CREATE TABLE permission (
  id           UUID PRIMARY KEY,
  product_id   UUID NOT NULL REFERENCES product(id),
  code         TEXT UNIQUE NOT NULL,                  -- billing.invoice.approve, billing.invoice.read.tenant
  kind         TEXT NOT NULL CHECK (kind IN ('FEATURE','DATA')),
  description  TEXT NOT NULL,
  sensitive    BOOLEAN NOT NULL DEFAULT false,        -- Phase 2 approval workflow
  audit_read   BOOLEAN NOT NULL DEFAULT false,        -- reads must be audited
  deprecated   BOOLEAN NOT NULL DEFAULT false,
  version      BIGINT NOT NULL
);
CREATE INDEX permission_product_idx ON permission(product_id);

CREATE TABLE role (
  id           UUID PRIMARY KEY,
  product_id   UUID NOT NULL REFERENCES product(id),
  name         TEXT NOT NULL,
  description  TEXT,
  type         TEXT NOT NULL CHECK (type IN ('SYSTEM','CUSTOM')),
  account_id   UUID REFERENCES account(id),
  version      BIGINT NOT NULL,
  created_at   TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at   TIMESTAMPTZ NOT NULL DEFAULT now(),
  CHECK ((type = 'SYSTEM' AND account_id IS NULL) OR (type = 'CUSTOM' AND account_id IS NOT NULL))
);
CREATE UNIQUE INDEX role_name_uq ON role
  (product_id, COALESCE(account_id, '00000000-0000-0000-0000-000000000000'::uuid), lower(name));
CREATE INDEX role_account_idx ON role(account_id) WHERE account_id IS NOT NULL;

CREATE TABLE role_permission (                        -- owned by Role aggregate
  role          UUID NOT NULL REFERENCES role(id) ON DELETE CASCADE,
  permission_id UUID NOT NULL REFERENCES permission(id),
  PRIMARY KEY (role, permission_id)
);

CREATE TABLE role_assignment (
  id          UUID PRIMARY KEY,
  user_id     UUID NOT NULL REFERENCES app_user(id),
  role_id     UUID NOT NULL REFERENCES role(id),
  scope_type  TEXT NOT NULL CHECK (scope_type IN ('ACCOUNT','TENANT')),
  scope_id    UUID NOT NULL,
  granted_by  UUID REFERENCES app_user(id),
  granted_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
  expires_at  TIMESTAMPTZ,
  version     BIGINT NOT NULL,
  UNIQUE (user_id, role_id, scope_type, scope_id)
);
CREATE INDEX ra_user_idx  ON role_assignment(user_id);
CREATE INDEX ra_scope_idx ON role_assignment(scope_type, scope_id);
CREATE INDEX ra_role_idx  ON role_assignment(role_id);
CREATE INDEX ra_expiry_idx ON role_assignment(expires_at) WHERE expires_at IS NOT NULL;

-- ===== Revocation feed =====
CREATE TABLE revocation (
  id          BIGSERIAL PRIMARY KEY,                  -- cursor for pollers
  user_id     UUID NOT NULL,
  min_sv      INT  NOT NULL,                          -- tokens with sv < min_sv are rejected
  reason      TEXT NOT NULL,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX revocation_created_idx ON revocation(created_at);   -- purge rows older than max token lifetime

-- ===== JWT signing keys =====
CREATE TABLE signing_key (
  kid           TEXT PRIMARY KEY,
  public_jwk    JSONB NOT NULL,
  private_enc   BYTEA NOT NULL,                       -- AES-GCM with master key from env/secrets manager
  status        TEXT  NOT NULL CHECK (status IN ('ACTIVE','PUBLISHED','RETIRED')),
  created_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
  retired_at    TIMESTAMPTZ
);

-- ===== Infra tables =====
CREATE TABLE shedlock (
  name VARCHAR(64) PRIMARY KEY, lock_until TIMESTAMP NOT NULL,
  locked_at TIMESTAMP NOT NULL, locked_by VARCHAR(255) NOT NULL
);
CREATE TABLE bucket (                                  -- Bucket4j PostgreSQL proxy manager
  id VARCHAR(255) PRIMARY KEY, state BYTEA, expires_at BIGINT
);
