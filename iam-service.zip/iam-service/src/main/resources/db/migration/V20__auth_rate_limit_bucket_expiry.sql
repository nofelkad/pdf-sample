-- V20 (Task 4): the Bucket4j PostgreSQL proxy manager uses the V1 bucket table as is (id VARCHAR key, state BYTEA,
-- expires_at BIGINT epoch millis written with expire-after-write). RateLimitBucketPurgeJob deletes expired buckets
-- with "WHERE expires_at < ?", which needs this index once many client IPs/emails have buckets.
CREATE INDEX bucket_expires_at_idx ON bucket (expires_at);
