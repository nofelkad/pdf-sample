plugins {
    alias(libs.plugins.spring.boot)
}

description = "IAM service (Spring Boot application)"

dependencies {
    implementation(project(":iam-core"))

    implementation(libs.spring.boot.starter.web)
    implementation(libs.spring.boot.starter.data.jdbc)
    implementation(libs.spring.boot.starter.security)
    implementation(libs.spring.boot.starter.oauth2.resource.server)
    implementation(libs.spring.security.oauth2.jose)
    implementation(libs.spring.boot.starter.validation)
    implementation(libs.spring.boot.starter.actuator)
    implementation(libs.spring.boot.starter.mail)
    implementation(libs.spring.boot.starter.aop)

    implementation(libs.flyway.core)
    implementation(libs.flyway.database.postgresql)
    implementation(libs.postgresql)

    implementation(libs.shedlock.spring)
    implementation(libs.shedlock.provider.jdbc.template)
    implementation(libs.bucket4j.core)
    implementation(libs.bucket4j.postgresql)

    implementation(libs.uuid.creator)
    implementation(libs.bouncycastle.bcprov)
    implementation(libs.springdoc.openapi.webmvc.ui)
    implementation(libs.jackson.databind)
    implementation(libs.jackson.datatype.jsr310)
    implementation(libs.jackson.dataformat.yaml)
    runtimeOnly(libs.micrometer.registry.prometheus)
    implementation(libs.logstash.logback.encoder) // compile scope: common.logging.SensitiveFieldMasker (Task 9)

    annotationProcessor(libs.spring.boot.configuration.processor)

    testImplementation(libs.spring.security.test)
    testImplementation(libs.spring.boot.testcontainers)
    testImplementation(libs.bundles.testcontainers)
    testImplementation(libs.archunit)
    testImplementation(libs.awaitility)
}

tasks.named<org.springframework.boot.gradle.tasks.bundling.BootBuildImage>("bootBuildImage") {
    imageName.set(providers.gradleProperty("imageName").orElse("iam-service:${project.version}"))
}

// OpenApiSpecIT compares the generated OpenAPI document with the committed docs/openapi.json (P1-11.6): changing
// that file must re-run the test, so it is a declared input (IAM_OPENAPI_UPDATE=true regenerates it).
tasks.withType<Test>().configureEach {
    inputs.files(rootProject.layout.projectDirectory.file("docs/openapi.json"))
        .withPropertyName("committedOpenApi")
        .optional()
}

// Ruling R45 (final review M1): wall-clock timing comparisons (@Tag("timing"), e.g. LoginTimingIT) are sensitive to
// machine load, so `test`/`build` exclude them and the separate `timingTest` task runs only them.
val timingTag = "timing"
tasks.named<Test>("test") {
    useJUnitPlatform { excludeTags(timingTag) }
}
val testSourceSet = the<SourceSetContainer>()["test"]
tasks.register<Test>("timingTest") {
    description = "Runs the @Tag(\"timing\") tests (excluded from test/build, Ruling R45)."
    group = LifecycleBasePlugin.VERIFICATION_GROUP
    testClassesDirs = testSourceSet.output.classesDirs
    classpath = testSourceSet.runtimeClasspath
    useJUnitPlatform { includeTags(timingTag) }
    shouldRunAfter(tasks.named("test"))
}
