package com.acme.iam.core;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

import com.acme.iam.core.DataScope.Scope;
import java.util.Arrays;
import java.util.List;
import java.util.Set;
import org.junit.jupiter.api.Test;

class DataScopeTest {

  private static final String BASE = "billing.invoice.read";

  @Test
  void ownOnly() {
    assertThat(DataScope.of(List.of("billing.invoice.read.own"), BASE)).isEqualTo(Scope.OWN);
  }

  @Test
  void tenantOnly() {
    assertThat(DataScope.of(List.of("billing.invoice.read.tenant"), BASE)).isEqualTo(Scope.TENANT);
  }

  @Test
  void accountOnly() {
    assertThat(DataScope.of(List.of("billing.invoice.read.account"), BASE)).isEqualTo(Scope.ACCOUNT);
  }

  @Test
  void broadestWins() {
    assertThat(DataScope.of(List.of("billing.invoice.read.own", "billing.invoice.read.tenant"), BASE))
        .isEqualTo(Scope.TENANT);
    assertThat(DataScope.of(List.of("billing.invoice.read.tenant", "billing.invoice.read.account"), BASE))
        .isEqualTo(Scope.ACCOUNT);
    assertThat(DataScope.of(
            List.of("billing.invoice.read.account", "billing.invoice.read.own", "billing.invoice.read.tenant"), BASE))
        .isEqualTo(Scope.ACCOUNT);
  }

  @Test
  void orderOfAuthoritiesDoesNotMatter() {
    assertThat(DataScope.of(List.of("billing.invoice.read.account", "billing.invoice.read.own"), BASE))
        .isEqualTo(Scope.ACCOUNT);
    assertThat(DataScope.of(List.of("billing.invoice.read.own", "billing.invoice.read.account"), BASE))
        .isEqualTo(Scope.ACCOUNT);
  }

  @Test
  void acceptsAnyCollectionType() {
    assertThat(DataScope.of(Set.of("x", "billing.invoice.read.tenant"), BASE)).isEqualTo(Scope.TENANT);
  }

  @Test
  void throwsWhenNoScopedPermissionIsHeld() {
    assertThatThrownBy(() -> DataScope.of(List.of("billing.invoice.approve", "iam.user.manage"), BASE))
        .isInstanceOf(NoDataScopeException.class)
        .hasMessageContaining(BASE);
    assertThatThrownBy(() -> DataScope.of(List.of(), BASE)).isInstanceOf(NoDataScopeException.class);
  }

  @Test
  void unsuffixedBasePermissionGivesNoScope() {
    assertThatThrownBy(() -> DataScope.of(List.of(BASE), BASE)).isInstanceOf(NoDataScopeException.class);
  }

  @Test
  void otherPermissionFamiliesAreIgnored() {
    assertThatThrownBy(() -> DataScope.of(List.of("billing.invoice.write.account", "billing.payment.read.tenant"), BASE))
        .isInstanceOf(NoDataScopeException.class);
    // a longer code that merely starts with the base is not a scope of the base
    assertThatThrownBy(() -> DataScope.of(List.of("billing.invoice.read.own.extra", "billing.invoice.readx.tenant"), BASE))
        .isInstanceOf(NoDataScopeException.class);
  }

  @Test
  void matchingIsCaseSensitiveLikeAuthorities() {
    assertThatThrownBy(() -> DataScope.of(List.of("BILLING.INVOICE.READ.TENANT"), BASE))
        .isInstanceOf(NoDataScopeException.class);
  }

  @Test
  void nullAuthoritiesAreIgnored() {
    assertThat(DataScope.of(Arrays.asList(null, "billing.invoice.read.own"), BASE)).isEqualTo(Scope.OWN);
  }

  @Test
  void rejectsInvalidArguments() {
    assertThatThrownBy(() -> DataScope.of(null, BASE)).isInstanceOf(NullPointerException.class);
    assertThatThrownBy(() -> DataScope.of(List.of(), null)).isInstanceOf(NullPointerException.class);
    assertThatThrownBy(() -> DataScope.of(List.of(), " ")).isInstanceOf(IllegalArgumentException.class);
  }

  @Test
  void scopeBreadthIsOrdered() {
    assertThat(Scope.OWN.isBroaderThan(Scope.OWN)).isFalse();
    assertThat(Scope.TENANT.isBroaderThan(Scope.OWN)).isTrue();
    assertThat(Scope.ACCOUNT.isBroaderThan(Scope.TENANT)).isTrue();
    assertThat(Scope.OWN.isBroaderThan(Scope.ACCOUNT)).isFalse();
    assertThat(Scope.ACCOUNT.suffix()).isEqualTo("account");
    assertThat(Scope.OWN.permission(BASE)).isEqualTo("billing.invoice.read.own");
  }
}
