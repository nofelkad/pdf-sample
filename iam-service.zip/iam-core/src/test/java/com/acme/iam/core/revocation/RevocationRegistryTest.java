package com.acme.iam.core.revocation;

import static org.assertj.core.api.Assertions.assertThat;

import java.time.Clock;
import java.time.Duration;
import java.time.Instant;
import java.time.ZoneOffset;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicReference;
import org.junit.jupiter.api.Test;

class RevocationRegistryTest {

  private final UUID alice = UUID.randomUUID();
  private final UUID bob = UUID.randomUUID();

  @Test
  void unknownUserIsNeverRevoked() {
    RevocationRegistry registry = new RevocationRegistry();

    assertThat(registry.isRevoked(alice, 1)).isFalse();
    assertThat(registry.lastCursor()).isZero();
  }

  @Test
  void tokenBelowMinSessionVersionIsRevoked() {
    RevocationRegistry registry = new RevocationRegistry();

    registry.apply(List.of(new RevocationEntry(7, alice, 3)));

    assertThat(registry.isRevoked(alice, 2)).isTrue();
    assertThat(registry.isRevoked(alice, 3)).isFalse();
    assertThat(registry.isRevoked(alice, 4)).isFalse();
    assertThat(registry.isRevoked(bob, 1)).isFalse();
    assertThat(registry.lastCursor()).isEqualTo(7);
  }

  @Test
  void keepsTheHighestMinSessionVersionRegardlessOfOrder() {
    RevocationRegistry registry = new RevocationRegistry();

    registry.apply(List.of(new RevocationEntry(10, alice, 5), new RevocationEntry(9, alice, 4)));
    registry.apply(List.of(new RevocationEntry(8, alice, 2)));

    assertThat(registry.minSessionVersion(alice)).isEqualTo(5);
    assertThat(registry.lastCursor()).isEqualTo(10);
  }

  @Test
  void cursorNeverMovesBackwards() {
    RevocationRegistry registry = new RevocationRegistry();

    registry.apply(List.of(new RevocationEntry(20, alice, 2)), 25);
    registry.apply(List.of(), 3);
    registry.advanceCursor(4);

    assertThat(registry.lastCursor()).isEqualTo(25);
  }

  @Test
  void applyWithServerCursorAdvancesEvenWithoutEntries() {
    RevocationRegistry registry = new RevocationRegistry();

    registry.apply(List.of(), 42);

    assertThat(registry.lastCursor()).isEqualTo(42);
    assertThat(registry.size()).isZero();
  }

  @Test
  void evictsEntriesOlderThanTheCutoff() {
    AtomicReference<Instant> now = new AtomicReference<>(Instant.parse("2026-01-01T00:00:00Z"));
    Clock clock = new Clock() {
      @Override public ZoneOffset getZone() { return ZoneOffset.UTC; }
      @Override public Clock withZone(java.time.ZoneId zone) { return this; }
      @Override public Instant instant() { return now.get(); }
    };
    RevocationRegistry registry = new RevocationRegistry(clock);
    registry.apply(List.of(new RevocationEntry(1, alice, 2)));
    now.set(now.get().plus(Duration.ofMinutes(30)));
    registry.apply(List.of(new RevocationEntry(2, bob, 2)));

    int evicted = registry.evictOlderThan(now.get().minus(Duration.ofMinutes(20)));

    assertThat(evicted).isEqualTo(1);
    assertThat(registry.isRevoked(alice, 1)).isFalse();
    assertThat(registry.isRevoked(bob, 1)).isTrue();
  }
}
