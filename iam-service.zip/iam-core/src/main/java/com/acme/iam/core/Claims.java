package com.acme.iam.core;

import java.util.List;

/**
 * JWT claim names and fixed values issued by iam-service (spec section 4) and read by iam-client (Ruling R1).
 *
 * <p>User access token: {@code iss, sub (user id), acc, tid, sid, sv, perms, iat, exp, jti}.
 * <br>Application token ({@code POST /internal/token}): {@code iss, sub = "app:<clientId>", typ = "app", prd, perms,
 * iat, exp, jti}.
 */
public final class Claims {

  public static final String ISSUER = "iss";
  public static final String SUBJECT = "sub";
  /** Account id (UUID). */
  public static final String ACCOUNT = "acc";
  /** Active tenant id (UUID). */
  public static final String TENANT = "tid";
  /** Session id (UUID, {@code user_session.id}). */
  public static final String SESSION = "sid";
  /** Session version ({@code app_user.session_version} at issue time); compared with the revocation feed. */
  public static final String SESSION_VERSION = "sv";
  /** Permission codes, a JSON array of strings; mapped 1:1 to Spring authorities. */
  public static final String PERMISSIONS = "perms";
  public static final String ISSUED_AT = "iat";
  public static final String EXPIRES_AT = "exp";
  public static final String NOT_BEFORE = "nbf";
  public static final String JWT_ID = "jti";
  /** Token type; only present on application tokens ({@value #TYPE_APP}). */
  public static final String TYPE = "typ";
  /** Product code of an application client token. */
  public static final String PRODUCT = "prd";

  /** {@code typ} value of application (client-credentials) tokens. */
  public static final String TYPE_APP = "app";
  /** Prefix of the {@code sub} claim of application tokens: {@code app:<clientId>}. */
  public static final String APP_SUBJECT_PREFIX = "app:";

  /** Only signature algorithm IAM issues and accepts. */
  public static final String ALGORITHM = "RS256";

  /** Permissions every application token carries. */
  public static final String PERM_INTERNAL_REVOCATIONS_READ = "internal.revocations.read";
  public static final String PERM_INTERNAL_AUDIT_WRITE = "internal.audit.write";
  public static final String PERM_INTERNAL_MANIFEST_WRITE = "internal.manifest.write";
  public static final List<String> APP_PERMISSIONS = List.of(
      PERM_INTERNAL_REVOCATIONS_READ, PERM_INTERNAL_AUDIT_WRITE, PERM_INTERNAL_MANIFEST_WRITE);
  /** Permission prefix reserved for application tokens; stripped from user tokens. */
  public static final String INTERNAL_PERMISSION_PREFIX = "internal.";

  private Claims() {}
}
