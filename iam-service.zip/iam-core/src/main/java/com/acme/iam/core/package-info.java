/**
 * Plain-Java shared kernel used by both {@code iam-service} and the {@code iam-client} starter (Ruling R1).
 *
 * <p>Holds framework-free code such as the revocation registry, data-scope evaluation and JWT claim-name constants.
 * Must not depend on Spring.
 */
package com.acme.iam.core;
