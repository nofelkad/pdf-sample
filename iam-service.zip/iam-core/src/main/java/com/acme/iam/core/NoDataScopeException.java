package com.acme.iam.core;

/**
 * Thrown by {@link DataScope#of} when the caller holds none of {@code base.own}, {@code base.tenant},
 * {@code base.account}. The iam-client starter translates it to Spring's {@code AccessDeniedException} (HTTP 403).
 */
public class NoDataScopeException extends RuntimeException {

  private static final long serialVersionUID = 1L;

  private final String basePermission;

  public NoDataScopeException(String basePermission) {
    super("No data scope held for permission '" + basePermission + "' (expected one of ." + "own, .tenant, .account)");
    this.basePermission = basePermission;
  }

  public String basePermission() {
    return basePermission;
  }
}
