package com.acme.iam.core.revocation;

import java.util.Objects;
import java.util.UUID;

/**
 * One row of the revocation feed ({@code GET /internal/revocations}): tokens of {@code userId} whose {@code sv} claim
 * is lower than {@code minSv} must be rejected.
 *
 * @param id feed cursor (monotonic, commit-ordered)
 * @param userId the user whose older tokens are revoked
 * @param minSv minimum session version still accepted
 */
public record RevocationEntry(long id, UUID userId, int minSv) {

  public RevocationEntry {
    Objects.requireNonNull(userId, "userId");
  }
}
