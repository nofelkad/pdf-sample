package com.acme.iam.core;

import java.util.Collection;
import java.util.Objects;

/**
 * Turns the scoped permissions of a token into one data scope (spec section 5, Data scope). Plain Java, no Spring
 * (Ruling R1); the {@code iam-client} starter adds an {@code Authentication} overload.
 *
 * <table>
 *   <caption>Scoped permissions</caption>
 *   <tr><th>Permission held</th><th>Scope</th><th>Applied as</th></tr>
 *   <tr><td>{@code x.read.own}</td><td>{@link Scope#OWN}</td><td>{@code AND owner_id = :sub}</td></tr>
 *   <tr><td>{@code x.read.tenant}</td><td>{@link Scope#TENANT}</td><td>{@code AND tenant_id = :tid}</td></tr>
 *   <tr><td>{@code x.read.account}</td><td>{@link Scope#ACCOUNT}</td><td>{@code AND account_id = :acc}</td></tr>
 * </table>
 *
 * <p>{@code DataScope.of(authorities, "x.read")} returns the broadest scope held, or throws
 * {@link NoDataScopeException} when none is held. Matching is exact and case-sensitive (like Spring authorities); a
 * bare {@code x.read} without a suffix grants no scope.
 */
public final class DataScope {

  /** Data scopes ordered from narrowest to broadest. */
  public enum Scope {
    /** Records the user owns or created. */
    OWN("own"),
    /** All records of the active tenant. */
    TENANT("tenant"),
    /** All records across the account. */
    ACCOUNT("account");

    private final String suffix;

    Scope(String suffix) {
      this.suffix = suffix;
    }

    /** The permission suffix of this scope: {@code own}, {@code tenant} or {@code account}. */
    public String suffix() {
      return suffix;
    }

    /** The permission code of this scope for {@code basePermission}, e.g. {@code billing.invoice.read.tenant}. */
    public String permission(String basePermission) {
      return basePermission + "." + suffix;
    }

    /** {@code true} when this scope covers strictly more records than {@code other}. */
    public boolean isBroaderThan(Scope other) {
      return compareTo(other) > 0;
    }
  }

  private DataScope() {}

  /**
   * The broadest scope among {@code base.own}, {@code base.tenant} and {@code base.account} in {@code authorities}.
   *
   * @throws NoDataScopeException when none of the three is held
   * @throws IllegalArgumentException when {@code basePermission} is blank
   */
  public static Scope of(Collection<String> authorities, String basePermission) {
    Objects.requireNonNull(authorities, "authorities");
    Objects.requireNonNull(basePermission, "basePermission");
    if (basePermission.isBlank()) {
      throw new IllegalArgumentException("basePermission must not be blank");
    }
    Scope[] scopes = Scope.values();
    for (int i = scopes.length - 1; i >= 0; i--) { // broadest first
      String wanted = scopes[i].permission(basePermission);
      if (authorities.contains(wanted)) {
        return scopes[i];
      }
    }
    throw new NoDataScopeException(basePermission);
  }
}
