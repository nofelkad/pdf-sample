package com.acme.iam.core.revocation;

import java.time.Clock;
import java.time.Instant;
import java.util.Collection;
import java.util.Map;
import java.util.Objects;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicLong;

/**
 * In-memory view of the revocation feed: {@code userId -> minimum session version} (spec section 5, Revocation).
 * Shared by iam-service and the iam-client starter (Ruling R1).
 *
 * <p>Thread-safe. {@link #apply} is idempotent (the highest {@code minSv} wins, the cursor never moves backwards), so
 * re-reading overlapping feed pages is harmless. {@link #isRevoked} is a single map lookup and is meant to be called on
 * every request.
 *
 * <p>Entries only matter while tokens issued before the revocation can still be alive (at most the access token
 * lifetime); {@link #evictOlderThan(Instant)} drops older entries so the map does not grow without bound.
 */
public final class RevocationRegistry {

  private record MinVersion(int minSv, Instant appliedAt) {}

  private final Map<UUID, MinVersion> minVersions = new ConcurrentHashMap<>();
  private final AtomicLong cursor = new AtomicLong();
  private final Clock clock;

  public RevocationRegistry() {
    this(Clock.systemUTC());
  }

  public RevocationRegistry(Clock clock) {
    this.clock = Objects.requireNonNull(clock, "clock");
  }

  /** Merges feed entries and advances the cursor to the highest entry id seen. */
  public void apply(Collection<RevocationEntry> entries) {
    Instant now = clock.instant();
    long max = 0;
    for (RevocationEntry e : entries) {
      minVersions.merge(e.userId(), new MinVersion(e.minSv(), now),
          (old, neu) -> neu.minSv() > old.minSv() ? neu : new MinVersion(old.minSv(), now));
      max = Math.max(max, e.id());
    }
    advanceCursor(max);
  }

  /** Merges feed entries and advances the cursor to {@code serverCursor} (the {@code cursor} of a feed response). */
  public void apply(Collection<RevocationEntry> entries, long serverCursor) {
    apply(entries);
    advanceCursor(serverCursor);
  }

  /** Moves the cursor forward to {@code newCursor}; a lower value is ignored. */
  public void advanceCursor(long newCursor) {
    cursor.accumulateAndGet(newCursor, Math::max);
  }

  /** {@code true} when a token of {@code userId} carrying session version {@code sv} has been revoked. */
  public boolean isRevoked(UUID userId, int sv) {
    MinVersion min = minVersions.get(userId);
    return min != null && sv < min.minSv();
  }

  /** The current minimum session version of {@code userId}, or {@code 0} when none is known. */
  public int minSessionVersion(UUID userId) {
    MinVersion min = minVersions.get(userId);
    return min == null ? 0 : min.minSv();
  }

  /** The id of the last feed row applied; pass it as {@code since} on the next poll. */
  public long lastCursor() {
    return cursor.get();
  }

  /** Number of users currently tracked. */
  public int size() {
    return minVersions.size();
  }

  /**
   * Removes entries last updated before {@code cutoff}. Use a cutoff of at least the maximum access-token lifetime
   * plus clock skew, so every token an evicted entry could reject has already expired.
   *
   * @return the number of entries removed
   */
  public int evictOlderThan(Instant cutoff) {
    int before = minVersions.size();
    minVersions.values().removeIf(v -> v.appliedAt().isBefore(cutoff));
    return before - minVersions.size();
  }
}
