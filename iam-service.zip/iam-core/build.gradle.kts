// Plain Java library shared by iam-service and iam-client (Ruling R1): no Spring, minimal dependencies.
description = "IAM shared kernel (revocation registry, data scope, claim names)"
