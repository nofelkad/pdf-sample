Verdant is the design system for an enterprise ERP built on **Mantine 9** (React 19.2+). It is a theme, a short set of conventions and a handful of composite components over Mantine — not a parallel component library. Use Mantine components directly; reach for a Verdant component only where this document names one.

## Principles

- **Calm over clever.** One green, sage-tinted neutrals, borders instead of shadows, no gradients or decoration. The data is the interface.
- **Dense but breathable.** 14px body, 40px table rows, 4px grid. Group with whitespace and `Section` panels, not with lines and boxes inside boxes.
- **Familiar words.** Say *Save*, *Cancel*, *Delete*, *Approve*, *Void*, *Export*. Name things the way the business does (Sales order, Purchase order, Journal, Customer) — never *entity*, *record type* or *submit*.
- **Progressive disclosure.** A screen shows what people use daily. Advanced fields sit under *Show advanced options*; rare filters sit under *More filters*; rare actions sit in an `ActionMenu`. Nothing is removed, only deferred.
- **Everything reachable by keyboard** with a visible 2px `border-focus` ring, and every colour paired with a word or icon.

## Setup

```tsx
import '@mantine/core/styles.css';
import '@mantine/notifications/styles.css';
import { VerdantProvider } from '@verdant/ui';

<VerdantProvider defaultColorScheme="light">
  <App />
</VerdantProvider>
```

`VerdantProvider` is `MantineProvider` with `theme`, `cssVariablesResolver` and a mounted `<Notifications />`. The theme is built in `components/src/theme.ts` from `components/src/tokens.ts` with `createTheme` and `Component.extend({ defaultProps, styles })` only — no global CSS beyond the 8-line `verdant.css`. Load IBM Plex Sans and IBM Plex Mono (400, 500, 600) from Google Fonts or self-host them; the stack falls back to Segoe UI / system-ui.

## Colour

Light and dark are both first-class; every component preview in this system renders in both.

- Pages sit on `surface-page`; cards, tables, inputs and overlays on `surface-raised`; table headers and filter trays on `surface-sunken`. Use Mantine `Paper` for raised surfaces — it is `withBorder` by default and never shadowed.
- Text is `text-primary` for content and `text-secondary` (Mantine `c="dimmed"`) for labels, captions and table headers. Never set text in a grey lighter than `text-secondary` except input placeholders (`text-placeholder`).
- Green means **action and selection**: `action-primary` for the one primary button per view, checked controls, the active nav item and links (`text-link`). Do not use green as decoration or as a page background.
- Status colours live only in `StatusBadge`, `Alert`, `Notification` and the error state of inputs. Success is green, warning amber, danger red, info blue, neutral grey — each carries a label, and success/danger also differ in lightness so they never rely on hue alone.
- Dark mode lightens the accent (`green-4`) and puts dark text on it (`on-action-primary`), rather than white text on a bright fill. `autoContrast` is on in the theme with `luminanceThreshold: 0.22`, so filled Buttons and Badges pick the readable text colour automatically.
- Primary shade is `green-6` in light and `green-4` in dark. Mantine's derived `light`/`outline` variants assume shade 8 in dark, so `cssVariablesResolver` re-pins them (tint = shade 5 at 18%, text = shade 2); do not override `--mantine-color-*-light*` elsewhere.

## Typography

IBM Plex Sans throughout; IBM Plex Mono only for identifiers in audit views and code. Styles: `h1` 28/600 for the page title (exactly one per page, in `PageHeader`), `h3` 18/600 for section titles, `body` 14/400 for everything readable, `small` 13 in tables, badges and breadcrumbs, `caption` 12 for timestamps and helper text, `label-caps` for detail-list labels and nav section headings. Sentence case for all labels, titles and buttons; no title case, no all-caps outside `label-caps`.

Numbers: right-align amounts and quantities, format with the locale (`Intl.NumberFormat('en-IN')` for ₹), and use `font-variant-numeric: tabular-nums` (`DataTable` numeric columns, `StatCard` and the `.verdant-tabular` class do this). Show empty values as an em dash (`—`), never blank.

## Spacing, radius, elevation

The 4px grid: `space-2` (8px) between buttons, `space-4` (16px) inside cards and between fields, `space-6` (24px) between sections and as the page gutter. Mantine's `xs/sm/md/lg/xl` are 8/12/16/24/32.

Radius: `radius-md` (6px) is the default for controls; `radius-lg` (8px) for Paper, Card, Modal and Drawer; `radius-sm` (4px) for badges and pills. Nothing is a pill except avatars and status dots.

Elevation is borders: `border-default` on every surface. Shadows mark floating layers only — `shadow-md` on menus and dropdowns, `shadow-lg` on modals, drawers and toasts.

## Iconography

Tabler Icons (`@tabler/icons-react`), outline style, `stroke={1.75}`, 16px inside buttons and inputs, 18px for icon-only buttons and navigation. Icons accompany labels; an icon-only `ActionIcon` always has an `aria-label`. No emoji, no filled icon variants, no custom illustrations.

## Layout patterns

- **Application frame** — `AppFrame`: 248px left navigation (collapsible to 64px icons), 52px top bar with global search, notifications and the account menu. One level of nesting in the nav; section labels in `label-caps`.
- **List page** — `PageHeader` (title, count subtitle, Export + primary New button) → `FilterBar` (search first, 2–4 everyday filters, *More filters*) → `SelectionBar` when rows are selected → `DataTable` → footer with count and `Pagination`. Rows open the detail page on click.
- **Detail page** — `PageHeader` with breadcrumbs, record title, `StatusBadge` as `meta`, the primary workflow action (Approve, Confirm, Post), one or two secondaries and an `ActionMenu`; optional `Tabs`. Body in `DetailLayout`: main column of `Section` panels (summary `DetailList`, line-item `DataTable`), side column for totals, status, activity `Timeline`.
- **Form page / create flow** — `Section` per topic with a one-line description, two-column `SimpleGrid` of inputs, labels above inputs, help as `description`, errors inline. `FormActions` at the end (primary right, cancel beside it, destructive far left), sticky on long forms. Quick edits of a few fields use a `Drawer` instead of a page.
- **Dashboard** — a row of at most four `StatCard`s, then charts and a short `DataTable` of items needing attention. KPI first, detail below.

## Feedback

- `notify.success` for completed actions (auto-dismiss 4s); `notify.error` stays until closed and says what to do next. Toasts never contain the only copy of an error — the form also shows it.
- `Alert` for page-level conditions that persist (credit limit reached, period closed). `ConfirmDialog` for irreversible actions only — never to confirm a save. Loading: `Skeleton` rows in tables, `loading` on the button that was pressed, never a full-page spinner for a partial update.
- `EmptyState` says what the area is for and offers the one action that fills it.

## Accessibility

- Contrast: every text/ground pair in `tokens.json` names its grounds and meets 4.5:1 in both themes (`text-placeholder` and `text-disabled` are the deliberate exceptions, used only where the WCAG exemption applies). Focus ring `border-focus` meets 3:1 on every surface.
- Keyboard: all Mantine components are keyboard-operable; `DataTable` rows with `onRowClick` are focusable and activate on Enter; `ActionMenu` traps focus and closes on Escape.
- Every input has a visible label (use `aria-label` only on search boxes whose placeholder is the label). Status is never colour alone: `StatusBadge` always shows text, errors show a message, deltas show a sign.
- Responsive: `AppFrame` collapses the nav behind a burger below `sm`; two-column grids stack below `sm`; `DataTable` scrolls horizontally with `minWidth` and hides secondary columns via `visibleFrom`.
- `respectReducedMotion` is on; transitions are Mantine defaults only.

## Do / Don't

- Do use `Button variant="default"` for secondary actions and `variant="subtle"` for tertiary; don't use `outline` or `gradient`.
- Do keep one filled primary button per view; don't put two green buttons side by side.
- Do put rare actions in `ActionMenu`; don't render a row of five icon buttons per table row.
- Do use `Section` to group; don't nest Paper inside Paper.
- Do write labels as nouns and buttons as verbs; don't use *OK* or *Submit*.
