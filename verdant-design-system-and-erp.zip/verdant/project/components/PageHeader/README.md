The top of every page: breadcrumbs, the single `h1`, an optional `StatusBadge`, a one-line subtitle, right-aligned actions and optional `Tabs`. List pages use title + count subtitle + actions; detail pages add breadcrumbs, `meta` and tabs.

**Consumer provides:** `title`, `subtitle`, `breadcrumbs` (`{label, href|onClick}`; the last crumb is plain text), `meta`, `actions` (one filled `Button`, up to two `default` buttons, then an `ActionMenu`), `tabs` (a Mantine `Tabs` element), or `onBack` for a back link instead of breadcrumbs.

**Do:** make the primary action the record's next workflow step (*Confirm order*, *Post journal*); include the record id in the title (*Sales order SO-10482*).

**Don't:** render more than one `PageHeader`; add a description paragraph (use the first `Section`); put filters here (use `FilterBar`).
