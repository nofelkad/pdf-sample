Dashboard KPI tile on Mantine `Paper`: `text-secondary` label, 26px tabular value, optional delta (`up` green, `down` red, `neutral` grey) with a short hint, optional 18px icon, optional `onClick` to drill into the list.

**Consumer provides:** `label`, formatted `value` (abbreviate large amounts: *₹1.84 Cr*), `delta` with its sign, `deltaTone`, `hint` (the comparison period), `icon`, `onClick`.

**Do:** show at most four per row in a `SimpleGrid cols={{ base: 2, md: 4 }}`; choose `deltaTone` by whether the change is good, not by its sign (overdue receivables rising is `down`).

**Don't:** put sparklines or charts inside; use more than one value per card; colour the whole card.
