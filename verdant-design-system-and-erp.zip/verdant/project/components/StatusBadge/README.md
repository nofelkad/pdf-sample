Shows a record's state as a tinted Mantine `Badge` with a dot and a label. The tone comes from the `status` text via `statusTones` (Approved → success, Overdue → warning, Rejected → danger, In review → info, Draft → neutral, Pending → hollow dot) or from an explicit `tone`.

**Consumer provides:** `status` (the exact label users know, sentence case), optional `tone`, optional `size` (`md` default, `sm` in dense tables, `lg` in page headers). Extend the vocabulary with `tone` per module instead of editing `statusTones` ad hoc.

**Do:** place it in the Status column of a `DataTable` and as `meta` in `PageHeader`; keep labels under 16 characters.

**Don't:** use colour without the label (`withDot={false}` is fine, hiding the text is not); use it for counts or categories — plain `Badge` (`variant="outline"`, `color="gray"`) does that; use `filled` for status.
