Not a component — the form pattern, built from Mantine inputs plus Verdant `Section` and `FormActions`. Inputs are size `sm`, labels above (weight 500), help as `description` under the input, errors inline in `error-text`, required marked with the asterisk only.

**Consumer provides:** a `Section` per topic with a one-line `description`; a two-column `SimpleGrid` (`cols={{ base: 1, sm: 2 }}`) for short fields, full width for long text; a *Show advanced options* `Anchor` + `Collapse` for rarely used fields; `FormActions` with `primary` (the verb: *Create order*), `secondary` (*Save as draft*, *Cancel*) and `start` for *Discard*/*Delete*; `sticky` on forms longer than a screen.

**Do:** use `Select` with `searchable` for lists over seven items, `NumberInput` with thousand separators for amounts, `Radio.Group` for two to four exclusive choices, `Switch` only for settings that apply immediately.

**Don't:** place labels beside inputs; use placeholders as labels; show every field the data model has — hide what the role does not use; validate on every keystroke (validate on blur and on submit).
