// Verdant — type reference (documentation). Bundle global: window.Verdant. Re-exports all of @mantine/core (9.x) plus the types below.
import type * as React from 'react';
import type { BadgeProps, MenuProps, TableProps, TextInputProps, ModalProps, PaperProps, MantineProviderProps } from '@mantine/core';

// ---- StatusBadge
export type StatusTone = 'success' | 'warning' | 'danger' | 'info' | 'neutral' | 'pending';
/**
 * Common ERP record states mapped to a tone. Extend per module via the `tone` prop
 * rather than adding to this map.
 */
export declare const statusTones: Record<string, StatusTone>;
export interface StatusBadgeProps extends Omit<BadgeProps, 'color' | 'children'> {
    /** Status label shown to the user, e.g. "Approved". Always visible — colour never carries meaning alone. */
    status: string;
    /** Override the tone; defaults to a lookup of `status` in `statusTones`, else neutral. */
    tone?: StatusTone;
    /** Show a small dot before the label (default true). */
    withDot?: boolean;
}
export declare function StatusBadge({ status, tone, withDot, ...rest }: StatusBadgeProps): React.JSX.Element;

// ---- ActionMenu
export interface ActionMenuItem {
    label: string;
    onClick?: () => void;
    icon?: React.ReactNode;
    /** Destructive items are red and placed after a divider when `dividerBefore` is set. */
    danger?: boolean;
    disabled?: boolean;
    dividerBefore?: boolean;
}
export interface ActionMenuProps extends Omit<MenuProps, 'children' | 'trigger'> {
    items: ActionMenuItem[];
    /** Custom trigger element; defaults to a "more" icon button. */
    target?: React.ReactNode;
    /** Accessible name for the default trigger. */
    label?: string;
}
/** Row-level or header-level overflow actions. Keep the primary action outside the menu. */
export declare function ActionMenu({ items, target, label, ...rest }: ActionMenuProps): React.JSX.Element;

// ---- PageHeader
export interface Crumb {
    label: string;
    href?: string;
    onClick?: () => void;
}
export interface PageHeaderProps {
    title: React.ReactNode;
    /** One line of context under the title: record id, owner, last updated. */
    subtitle?: React.ReactNode;
    breadcrumbs?: Crumb[];
    /** Status badge or similar, shown inline after the title. */
    meta?: React.ReactNode;
    /** Right-aligned actions: one primary Button, at most two secondary, the rest in an ActionMenu. */
    actions?: React.ReactNode;
    /** Optional Tabs rendered flush under the header. */
    tabs?: React.ReactNode;
    /** Back link for detail pages. */
    backLabel?: string;
    onBack?: () => void;
}
/**
 * Consistent top of every page: breadcrumbs, title (h1), subtitle, actions.
 * Only one PageHeader per page; section headings inside the page use Title order 2/3.
 */
export declare function PageHeader({ title, subtitle, breadcrumbs, meta, actions, tabs, backLabel, onBack }: PageHeaderProps): React.JSX.Element;

// ---- DataTable
export interface DataTableColumn<T> {
    key: string;
    header: React.ReactNode;
    /** Right-align numbers and amounts; they also get tabular figures. */
    numeric?: boolean;
    width?: number | string;
    sortable?: boolean;
    render?: (row: T) => React.ReactNode;
    /** Hidden below this breakpoint via Mantine's visibleFrom. */
    visibleFrom?: 'xs' | 'sm' | 'md' | 'lg' | 'xl';
}
export interface SortState {
    key: string;
    direction: 'asc' | 'desc';
}
export interface DataTableProps<T> extends Omit<TableProps, 'data' | 'children'> {
    columns: DataTableColumn<T>[];
    rows: T[];
    rowKey: (row: T) => string;
    loading?: boolean;
    /** Rendered inside the table when rows is empty and not loading. Usually an <EmptyState>. */
    empty?: React.ReactNode;
    onRowClick?: (row: T) => void;
    /** Controlled selection. */
    selected?: string[];
    onSelectedChange?: (keys: string[]) => void;
    sort?: SortState;
    onSortChange?: (sort: SortState) => void;
    /** 32px rows instead of 40px. */
    dense?: boolean;
    /** Trailing per-row actions (ActionMenu). Column is sticky-right friendly and narrow. */
    rowActions?: (row: T) => React.ReactNode;
    minWidth?: number;
}
/**
 * The list-page table. Wraps Mantine Table with the Verdant conventions:
 * sticky muted header, 40px rows, right-aligned numerics, optional selection, sort and row actions.
 */
export declare function DataTable<T>({ columns, rows, rowKey, loading, empty, onRowClick, selected, onSelectedChange, sort, onSortChange, dense, rowActions, minWidth, ...tableProps }: DataTableProps<T>): React.JSX.Element;

// ---- FilterBar
export interface SearchInputProps extends Omit<TextInputProps, 'onChange' | 'value'> {
    value?: string;
    /** Fires after `debounce` ms of inactivity (default 300). */
    onSearch: (query: string) => void;
    debounce?: number;
}
/** Text search with icon, clear button and debounce. Place it first in a FilterBar. */
export declare function SearchInput({ value: valueProp, onSearch, debounce, placeholder, ...rest }: SearchInputProps): React.JSX.Element;
export interface AppliedFilter {
    key: string;
    label: string;
}
export interface FilterBarProps {
    /** Usually a SearchInput. */
    search?: React.ReactNode;
    /** Two to four primary filters shown always (Select, SegmentedControl, date range). */
    children?: React.ReactNode;
    /** Rarely used filters, hidden behind "More filters". */
    advanced?: React.ReactNode;
    applied?: AppliedFilter[];
    onRemove?: (key: string) => void;
    onClearAll?: () => void;
    /** Right-aligned slot: result count, view switch, export. */
    trailing?: React.ReactNode;
}
/**
 * The row above every list. Shows the few filters people use daily; everything else
 * sits behind "More filters". Applied filters appear as removable pills.
 */
export declare function FilterBar({ search, children, advanced, applied, onRemove, onClearAll, trailing }: FilterBarProps): React.JSX.Element;

// ---- Feedback
export interface ConfirmDialogProps extends Omit<ModalProps, 'children' | 'title'> {
    title: string;
    /** One or two plain sentences: what will happen and whether it can be undone. */
    message: React.ReactNode;
    confirmLabel?: string;
    cancelLabel?: string;
    /** Red confirm button for irreversible actions (delete, void, cancel order). */
    danger?: boolean;
    loading?: boolean;
    onConfirm: () => void;
}
/** Short decision dialog. Use for irreversible or costly actions only; never to confirm a save. */
export declare function ConfirmDialog({ title, message, confirmLabel, cancelLabel, danger, loading, onConfirm, onClose, ...rest }: ConfirmDialogProps): React.JSX.Element;
type NotifyInput = string | (Partial<NotificationData> & {
    message: React.ReactNode;
});
/**
 * Toast helpers over @mantine/notifications. Success auto-dismisses; errors stay until closed.
 * Mount <Notifications /> once (VerdantProvider does this).
 */
export declare const notify: {
    success: (n: NotifyInput) => string;
    error: (n: NotifyInput) => string;
    warning: (n: NotifyInput) => string;
    info: (n: NotifyInput) => string;
};
export interface EmptyStateProps {
    icon?: React.ReactNode;
    title: string;
    description?: React.ReactNode;
    /** One primary action, e.g. "New purchase order". */
    action?: React.ReactNode;
    compact?: boolean;
}
/** Empty tables, empty sections and "no results" states. Say what the area is for and how to fill it. */
export declare function EmptyState({ icon, title, description, action, compact }: EmptyStateProps): React.JSX.Element;
export {};

// ---- Layout
export interface SectionProps extends PaperProps {
    title?: React.ReactNode;
    description?: React.ReactNode;
    /** Small actions in the section header (e.g. "Edit"). */
    actions?: React.ReactNode;
    children: React.ReactNode;
}
/** A bordered content block with an optional heading row. Used for form groups and detail-page panels. */
export declare function Section({ title, description, actions, children, ...rest }: SectionProps): React.JSX.Element;
export interface FormActionsProps {
    /** Primary submit button. */
    primary: React.ReactNode;
    /** Cancel / secondary buttons. */
    secondary?: React.ReactNode;
    /** Left-aligned destructive or tertiary action. */
    start?: React.ReactNode;
    /** Stick to the viewport bottom on long forms. */
    sticky?: boolean;
}
/** The action row at the end of a form: primary on the right, cancel beside it, destructive far left. */
export declare function FormActions({ primary, secondary, start, sticky }: FormActionsProps): React.JSX.Element;
export interface DetailItem {
    label: string;
    value: React.ReactNode; /** span both columns */
    wide?: boolean;
}
/** Label/value pairs for read-only detail panels. Values that are empty show an em dash, never blank. */
export declare function DetailList({ items, columns }: {
    items: DetailItem[];
    columns?: 1 | 2 | 3;
}): React.JSX.Element;
export interface StatCardProps extends PaperProps {
    label: string;
    value: React.ReactNode;
    /** e.g. "+4.2% vs last month". Tone colours the delta text. */
    delta?: React.ReactNode;
    deltaTone?: 'up' | 'down' | 'neutral';
    hint?: React.ReactNode;
    icon?: React.ReactNode;
    onClick?: () => void;
}
/** Dashboard KPI tile: label, large tabular number, small delta. Four per row at most. */
export declare function StatCard({ label, value, delta, deltaTone, hint, icon, onClick, ...rest }: StatCardProps): React.JSX.Element;
/** Two-column detail layout: main content 8/12, side panel 4/12; stacks below md. */
export declare function DetailLayout({ main, aside }: {
    main: React.ReactNode;
    aside: React.ReactNode;
}): React.JSX.Element;
/** Bulk-action bar shown when table rows are selected. */
export declare function SelectionBar({ count, actions, onClear }: {
    count: number;
    actions: React.ReactNode;
    onClear: () => void;
}): React.JSX.Element | null;

// ---- AppFrame
export interface NavItem {
    label: string;
    icon?: React.ReactNode;
    href?: string;
    onClick?: () => void;
    active?: boolean;
    /** Second level; keep to one level of nesting. */
    children?: Omit<NavItem, 'children' | 'icon'>[];
    badge?: React.ReactNode;
}
export interface NavSection {
    label?: string;
    items: NavItem[];
}
export interface AppFrameProps {
    /** Product name or logo, top-left. */
    brand: React.ReactNode;
    sections: NavSection[];
    user: {
        name: string;
        role?: string;
        initials?: string;
    };
    onUserAction?: (action: 'profile' | 'settings' | 'help' | 'logout') => void;
    /** Global search handler; omit to hide the search box. */
    onGlobalSearch?: (q: string) => void;
    notificationsCount?: number;
    onNotifications?: () => void;
    /** Optional slot in the header, right of search (e.g. company/branch switcher). */
    headerExtra?: React.ReactNode;
    children: React.ReactNode;
    /** Start collapsed on desktop. */
    defaultCollapsed?: boolean;
}
/**
 * The application chrome: left navigation (collapsible to icons), slim top bar with global search,
 * notifications and the user menu. Pages render in `children` with their own PageHeader.
 */
export declare function AppFrame({ brand, sections, user, onUserAction, onGlobalSearch, notificationsCount, onNotifications, headerExtra, children, defaultCollapsed }: AppFrameProps): React.JSX.Element;

// ---- VerdantProvider
export interface VerdantProviderProps extends Omit<MantineProviderProps, 'theme' | 'cssVariablesResolver'> {
    children: React.ReactNode;
}
/**
 * Wrap the application root once. Supplies the Verdant theme, semantic CSS variables and the
 * notifications outlet. Pass `defaultColorScheme="auto"` to follow the OS, or `forceColorScheme`.
 *
 *   import '@mantine/core/styles.css';
 *   import '@mantine/notifications/styles.css';
 *   <VerdantProvider defaultColorScheme="light"><App /></VerdantProvider>
 */
export declare function VerdantProvider({ children, ...rest }: VerdantProviderProps): React.JSX.Element;

// ---- tokens
/**
 * Verdant design tokens — the single source of truth.
 * theme.ts builds the Mantine theme from this file; tokens.json in the
 * design-system artifact is generated from it (scripts/tokens-json.mjs).
 * Never hard-code a colour, size or radius in a component: reference these.
 */
export type Shade10 = [string, string, string, string, string, string, string, string, string, string];
/** Primary brand green. Shade 6 is the primary action colour (4.5:1+ with white). */
export declare const green: Shade10;
/** Sage-tinted neutral scale: surfaces, borders, text. */
export declare const gray: Shade10;
/** Status hues. Pairs with success (green) differ in lightness and always carry a label or icon. */
export declare const red: Shade10;
export declare const amber: Shade10;
export declare const blue: Shade10;
export declare const colors: {
    green: Shade10;
    gray: Shade10;
    red: Shade10;
    amber: Shade10;
    blue: Shade10;
};
export declare const primaryShade: {
    readonly light: 6;
    readonly dark: 4;
};
/** Font stacks. IBM Plex is served from Google Fonts; system faces are the fallback. */
export declare const fontFamily = "\"IBM Plex Sans\", \"Segoe UI\", system-ui, -apple-system, sans-serif";
export declare const fontFamilyMonospace = "\"IBM Plex Mono\", ui-monospace, \"SFMono-Regular\", Menlo, monospace";
/** Type scale (px). Body is 14px — ERP screens are dense. */
export declare const fontSizes: {
    xs: string;
    sm: string;
    md: string;
    lg: string;
    xl: string;
};
export declare const lineHeights: {
    xs: string;
    sm: string;
    md: string;
    lg: string;
    xl: string;
};
export declare const headings: {
    fontWeight: string;
    sizes: {
        h1: {
            fontSize: string;
            lineHeight: string;
        };
        h2: {
            fontSize: string;
            lineHeight: string;
        };
        h3: {
            fontSize: string;
            lineHeight: string;
        };
        h4: {
            fontSize: string;
            lineHeight: string;
        };
        h5: {
            fontSize: string;
            lineHeight: string;
        };
        h6: {
            fontSize: string;
            lineHeight: string;
        };
    };
};
/** 4px grid. */
export declare const spacing: {
    xs: string;
    sm: string;
    md: string;
    lg: string;
    xl: string;
};
export declare const space: {
    1: string;
    2: string;
    3: string;
    4: string;
    5: string;
    6: string;
    8: string;
    10: string;
    12: string;
};
export declare const radius: {
    xs: string;
    sm: string;
    md: string;
    lg: string;
    xl: string;
};
export declare const defaultRadius = "md";
/** Soft, low-saturation shadows — elevation is mostly borders in Verdant. */
export declare const shadows: {
    xs: string;
    sm: string;
    md: string;
    lg: string;
};
/** Layout constants shared by AppShell, page headers and tables. */
export declare const layout: {
    navbarWidth: number;
    navbarCollapsedWidth: number;
    headerHeight: number;
    contentMaxWidth: number;
    pagePadding: string;
    tableRowHeight: number;
    tableDenseRowHeight: number;
};
export declare const focusRing: {
    width: string;
    offset: string;
};
