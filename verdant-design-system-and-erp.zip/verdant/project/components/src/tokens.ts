/**
 * Verdant design tokens — the single source of truth.
 * theme.ts builds the Mantine theme from this file; tokens.json in the
 * design-system artifact is generated from it (scripts/tokens-json.mjs).
 * Never hard-code a colour, size or radius in a component: reference these.
 */

export type Shade10 = [string, string, string, string, string, string, string, string, string, string];

/** Primary brand green. Shade 6 is the primary action colour (4.5:1+ with white). */
export const green: Shade10 = [
  '#eef7f1', // 0  tinted surface, selected rows, light badges
  '#d8ecdf', // 1  hover on tinted surface
  '#b5d9c3', // 2  borders of tinted elements
  '#8dc4a4', // 3
  '#64ae85', // 4  dark-theme primary (text on it: ink)
  '#3f9568', // 5
  '#277a52', // 6  PRIMARY — buttons, links, active nav (white text 5.1:1)
  '#1f6343', // 7  hover
  '#184d35', // 8  pressed
  '#113828', // 9
];

/** Sage-tinted neutral scale: surfaces, borders, text. */
export const gray: Shade10 = [
  '#f6f8f7', // 0  app background
  '#eef1ef', // 1  subtle fill, table header
  '#e1e6e3', // 2  borders
  '#cdd5d0', // 3  strong borders, dividers on tinted
  '#a7b2ab', // 4  disabled text
  '#808d85', // 5  placeholder
  '#5f6c65', // 6  secondary text (6.3:1 on white)
  '#45504a', // 7  body text alternative
  '#2e3733', // 8  dark surface-raised
  '#1b211e', // 9  dark app background
];

/** Status hues. Pairs with success (green) differ in lightness and always carry a label or icon. */
export const red: Shade10 = ['#fdf1ef', '#f9d9d4', '#f2b4ab', '#e98b7e', '#dc6555', '#c94434', '#b42318', '#931c13', '#75170f', '#58120c'];
export const amber: Shade10 = ['#fdf6e7', '#fae8c0', '#f5d286', '#eeb94d', '#e09f1f', '#c48306', '#8f5d05', '#744a04', '#653f05', '#4a2e04'];
export const blue: Shade10 = ['#eef4fc', '#d6e4f8', '#b0c9f0', '#85aae6', '#5c8bda', '#3a6fcb', '#2559b1', '#1c4791', '#163773', '#102a58'];

export const colors = { green, gray, red, amber, blue };

export const primaryShade = { light: 6, dark: 4 } as const;

/** Font stacks. IBM Plex is served from Google Fonts; system faces are the fallback. */
export const fontFamily = '"IBM Plex Sans", "Segoe UI", system-ui, -apple-system, sans-serif';
export const fontFamilyMonospace = '"IBM Plex Mono", ui-monospace, "SFMono-Regular", Menlo, monospace';

/** Type scale (px). Body is 14px — ERP screens are dense. */
export const fontSizes = { xs: '12px', sm: '13px', md: '14px', lg: '16px', xl: '18px' };
export const lineHeights = { xs: '1.35', sm: '1.45', md: '1.45', lg: '1.5', xl: '1.5' };
export const headings = {
  fontWeight: '600',
  sizes: {
    h1: { fontSize: '28px', lineHeight: '1.25' }, // page title
    h2: { fontSize: '22px', lineHeight: '1.3' },  // section title
    h3: { fontSize: '18px', lineHeight: '1.35' }, // card title
    h4: { fontSize: '16px', lineHeight: '1.4' },  // group label
    h5: { fontSize: '14px', lineHeight: '1.45' },
    h6: { fontSize: '13px', lineHeight: '1.45' },
  },
};

/** 4px grid. */
export const spacing = { xs: '8px', sm: '12px', md: '16px', lg: '24px', xl: '32px' };
export const space = { 1: '4px', 2: '8px', 3: '12px', 4: '16px', 5: '20px', 6: '24px', 8: '32px', 10: '40px', 12: '48px' };

export const radius = { xs: '3px', sm: '4px', md: '6px', lg: '8px', xl: '12px' };
export const defaultRadius = 'md';

/** Soft, low-saturation shadows — elevation is mostly borders in Verdant. */
export const shadows = {
  xs: '0 1px 2px rgba(27, 33, 30, 0.06)',
  sm: '0 1px 3px rgba(27, 33, 30, 0.08), 0 1px 2px rgba(27, 33, 30, 0.04)',
  md: '0 4px 12px rgba(27, 33, 30, 0.10), 0 1px 3px rgba(27, 33, 30, 0.06)',
  lg: '0 12px 32px rgba(27, 33, 30, 0.14), 0 2px 6px rgba(27, 33, 30, 0.06)',
};

/** Layout constants shared by AppShell, page headers and tables. */
export const layout = {
  navbarWidth: 248,
  navbarCollapsedWidth: 64,
  headerHeight: 52,
  contentMaxWidth: 1440,
  pagePadding: 'lg',
  tableRowHeight: 40,
  tableDenseRowHeight: 32,
};

export const focusRing = { width: '2px', offset: '2px' };
