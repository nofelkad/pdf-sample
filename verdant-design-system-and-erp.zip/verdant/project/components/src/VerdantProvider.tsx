import { MantineProvider, type MantineProviderProps } from '@mantine/core';
import { Notifications } from '@mantine/notifications';
import * as React from 'react';
import { cssVariablesResolver, theme } from './theme';

export interface VerdantProviderProps extends Omit<MantineProviderProps, 'theme' | 'cssVariablesResolver'> {
  children: React.ReactNode;
}

/**
 * Wrap the application root once. Supplies the Verdant theme, semantic CSS variables and the
 * notifications outlet. Pass `defaultColorScheme="auto"` to follow the OS, or `forceColorScheme`.
 *
 *   import '@mantine/core/styles.css';
 *   import '@mantine/notifications/styles.css';
 *   <VerdantProvider defaultColorScheme="light"><App /></VerdantProvider>
 */
export function VerdantProvider({ children, ...rest }: VerdantProviderProps) {
  return (
    <MantineProvider theme={theme} cssVariablesResolver={cssVariablesResolver} defaultColorScheme="light" {...rest}>
      <Notifications position="top-right" limit={4} />
      {children}
    </MantineProvider>
  );
}
