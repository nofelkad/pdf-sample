import { Badge, type BadgeProps } from '@mantine/core';
import * as React from 'react';

export type StatusTone = 'success' | 'warning' | 'danger' | 'info' | 'neutral' | 'pending';

const toneColor: Record<StatusTone, string> = {
  success: 'green',
  warning: 'amber',
  danger: 'red',
  info: 'blue',
  neutral: 'gray',
  pending: 'gray',
};

/**
 * Common ERP record states mapped to a tone. Extend per module via the `tone` prop
 * rather than adding to this map.
 */
export const statusTones: Record<string, StatusTone> = {
  active: 'success', approved: 'success', paid: 'success', completed: 'success', posted: 'success', shipped: 'success',
  pending: 'pending', draft: 'neutral', 'on hold': 'warning', overdue: 'warning', 'partially paid': 'warning', 'in review': 'info',
  rejected: 'danger', cancelled: 'danger', failed: 'danger', blocked: 'danger', inactive: 'neutral', archived: 'neutral',
  open: 'info', submitted: 'info', processing: 'info',
};

export interface StatusBadgeProps extends Omit<BadgeProps, 'color' | 'children'> {
  /** Status label shown to the user, e.g. "Approved". Always visible — colour never carries meaning alone. */
  status: string;
  /** Override the tone; defaults to a lookup of `status` in `statusTones`, else neutral. */
  tone?: StatusTone;
  /** Show a small dot before the label (default true). */
  withDot?: boolean;
}

export function StatusBadge({ status, tone, withDot = true, ...rest }: StatusBadgeProps) {
  const resolved = tone ?? statusTones[status.toLowerCase()] ?? 'neutral';
  const color = toneColor[resolved];
  const dotStyle: React.CSSProperties =
    resolved === 'pending'
      ? { width: 7, height: 7, borderRadius: 7, border: '1.5px solid currentColor', boxSizing: 'border-box' }
      : { width: 7, height: 7, borderRadius: 7, background: 'currentColor' };
  return (
    <Badge color={color} leftSection={withDot ? <span aria-hidden style={dotStyle} /> : undefined} {...rest}>
      {status}
    </Badge>
  );
}
