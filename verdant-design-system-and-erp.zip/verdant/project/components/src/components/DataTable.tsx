import { Checkbox, Group, Loader, Skeleton, Table, Text, UnstyledButton, type TableProps } from '@mantine/core';
import { IconArrowDown, IconArrowUp, IconArrowsSort } from '@tabler/icons-react';
import * as React from 'react';

export interface DataTableColumn<T> {
  key: string;
  header: React.ReactNode;
  /** Right-align numbers and amounts; they also get tabular figures. */
  numeric?: boolean;
  width?: number | string;
  sortable?: boolean;
  render?: (row: T) => React.ReactNode;
  /** Hidden below this breakpoint via Mantine's visibleFrom. */
  visibleFrom?: 'xs' | 'sm' | 'md' | 'lg' | 'xl';
}

export interface SortState { key: string; direction: 'asc' | 'desc' }

export interface DataTableProps<T> extends Omit<TableProps, 'data' | 'children'> {
  columns: DataTableColumn<T>[];
  rows: T[];
  rowKey: (row: T) => string;
  loading?: boolean;
  /** Rendered inside the table when rows is empty and not loading. Usually an <EmptyState>. */
  empty?: React.ReactNode;
  onRowClick?: (row: T) => void;
  /** Controlled selection. */
  selected?: string[];
  onSelectedChange?: (keys: string[]) => void;
  sort?: SortState;
  onSortChange?: (sort: SortState) => void;
  /** 32px rows instead of 40px. */
  dense?: boolean;
  /** Trailing per-row actions (ActionMenu). Column is sticky-right friendly and narrow. */
  rowActions?: (row: T) => React.ReactNode;
  minWidth?: number;
}

function SortButton({ label, active, direction, onClick }: { label: React.ReactNode; active: boolean; direction?: 'asc' | 'desc'; onClick: () => void }) {
  const Icon = !active ? IconArrowsSort : direction === 'asc' ? IconArrowUp : IconArrowDown;
  return (
    <UnstyledButton onClick={onClick} aria-sort={active ? (direction === 'asc' ? 'ascending' : 'descending') : 'none'}
      style={{ display: 'inline-flex', alignItems: 'center', gap: 4, font: 'inherit', color: active ? 'var(--mantine-color-text)' : 'inherit' }}>
      {label}
      <Icon size={14} stroke={1.75} style={{ opacity: active ? 1 : 0.5 }} />
    </UnstyledButton>
  );
}

/**
 * The list-page table. Wraps Mantine Table with the Verdant conventions:
 * sticky muted header, 40px rows, right-aligned numerics, optional selection, sort and row actions.
 */
export function DataTable<T>({
  columns, rows, rowKey, loading, empty, onRowClick, selected, onSelectedChange, sort, onSortChange,
  dense, rowActions, minWidth = 640, ...tableProps
}: DataTableProps<T>) {
  const selectable = !!onSelectedChange;
  const allKeys = rows.map(rowKey);
  const allSelected = selectable && rows.length > 0 && allKeys.every((k) => selected?.includes(k));
  const someSelected = selectable && !allSelected && allKeys.some((k) => selected?.includes(k));
  const rowH = dense ? 32 : 40;
  const colCount = columns.length + (selectable ? 1 : 0) + (rowActions ? 1 : 0);

  const toggleAll = () => onSelectedChange?.(allSelected ? [] : allKeys);
  const toggleOne = (k: string) =>
    onSelectedChange?.(selected?.includes(k) ? selected.filter((x) => x !== k) : [...(selected ?? []), k]);

  return (
    <Table.ScrollContainer minWidth={minWidth}>
      <Table verticalSpacing={dense ? 2 : 'xs'} {...tableProps}>
        <Table.Thead>
          <Table.Tr style={{ height: rowH }}>
            {selectable && (
              <Table.Th w={40}>
                <Checkbox aria-label="Select all rows" checked={allSelected} indeterminate={someSelected} onChange={toggleAll} />
              </Table.Th>
            )}
            {columns.map((c) => (
              <Table.Th key={c.key} w={c.width} ta={c.numeric ? 'right' : 'left'} visibleFrom={c.visibleFrom}>
                {c.sortable && onSortChange ? (
                  <SortButton label={c.header} active={sort?.key === c.key} direction={sort?.direction}
                    onClick={() => onSortChange({ key: c.key, direction: sort?.key === c.key && sort.direction === 'asc' ? 'desc' : 'asc' })} />
                ) : c.header}
              </Table.Th>
            ))}
            {rowActions && <Table.Th w={48} aria-label="Actions" />}
          </Table.Tr>
        </Table.Thead>
        <Table.Tbody>
          {loading && rows.length === 0 &&
            Array.from({ length: 5 }).map((_, i) => (
              <Table.Tr key={i} style={{ height: rowH }}>
                <Table.Td colSpan={colCount}><Skeleton h={12} radius="sm" w={`${55 + (i * 17) % 40}%`} /></Table.Td>
              </Table.Tr>
            ))}
          {!loading && rows.length === 0 && (
            <Table.Tr>
              <Table.Td colSpan={colCount} py="xl">
                {empty ?? <Text c="dimmed" ta="center" fz="sm">No records</Text>}
              </Table.Td>
            </Table.Tr>
          )}
          {rows.map((row) => {
            const k = rowKey(row);
            const isSel = selected?.includes(k);
            return (
              <Table.Tr key={k} style={{ height: rowH, cursor: onRowClick ? 'pointer' : undefined }}
                bg={isSel ? 'var(--verdant-surface-selected)' : undefined}
                onClick={onRowClick ? () => onRowClick(row) : undefined}
                tabIndex={onRowClick ? 0 : undefined}
                onKeyDown={onRowClick ? (e) => { if (e.key === 'Enter') onRowClick(row); } : undefined}>
                {selectable && (
                  <Table.Td onClick={(e) => e.stopPropagation()}>
                    <Checkbox aria-label="Select row" checked={!!isSel} onChange={() => toggleOne(k)} />
                  </Table.Td>
                )}
                {columns.map((c) => (
                  <Table.Td key={c.key} ta={c.numeric ? 'right' : 'left'} visibleFrom={c.visibleFrom}
                    style={c.numeric ? { fontVariantNumeric: 'tabular-nums' } : undefined}>
                    {c.render ? c.render(row) : String((row as any)[c.key] ?? '')}
                  </Table.Td>
                ))}
                {rowActions && <Table.Td ta="right" py={0}>{rowActions(row)}</Table.Td>}
              </Table.Tr>
            );
          })}
        </Table.Tbody>
      </Table>
      {loading && rows.length > 0 && (
        <Group justify="center" py="xs"><Loader size="xs" /><Text fz="xs" c="dimmed">Updating…</Text></Group>
      )}
    </Table.ScrollContainer>
  );
}
