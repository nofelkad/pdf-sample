import { Anchor, Box, Breadcrumbs, Group, Stack, Text, Title } from '@mantine/core';
import { IconChevronRight } from '@tabler/icons-react';
import * as React from 'react';

export interface Crumb { label: string; href?: string; onClick?: () => void }

export interface PageHeaderProps {
  title: React.ReactNode;
  /** One line of context under the title: record id, owner, last updated. */
  subtitle?: React.ReactNode;
  breadcrumbs?: Crumb[];
  /** Status badge or similar, shown inline after the title. */
  meta?: React.ReactNode;
  /** Right-aligned actions: one primary Button, at most two secondary, the rest in an ActionMenu. */
  actions?: React.ReactNode;
  /** Optional Tabs rendered flush under the header. */
  tabs?: React.ReactNode;
  /** Back link for detail pages. */
  backLabel?: string;
  onBack?: () => void;
}

/**
 * Consistent top of every page: breadcrumbs, title (h1), subtitle, actions.
 * Only one PageHeader per page; section headings inside the page use Title order 2/3.
 */
export function PageHeader({ title, subtitle, breadcrumbs, meta, actions, tabs, backLabel, onBack }: PageHeaderProps) {
  return (
    <Box component="header" mb={tabs ? 0 : 'lg'}>
      <Stack gap={4}>
        {breadcrumbs && breadcrumbs.length > 0 && (
          <Breadcrumbs separator={<IconChevronRight size={14} stroke={1.75} />} separatorMargin={6} fz="sm">
            {breadcrumbs.map((c, i) =>
              i === breadcrumbs.length - 1 || (!c.href && !c.onClick) ? (
                <Text key={i} fz="sm" c="dimmed" fw={400}>{c.label}</Text>
              ) : (
                <Anchor key={i} fz="sm" fw={400} href={c.href} onClick={c.onClick}>{c.label}</Anchor>
              ),
            )}
          </Breadcrumbs>
        )}
        {onBack && (
          <Anchor fz="sm" fw={400} onClick={onBack} component="button" type="button" style={{ alignSelf: 'flex-start' }}>
            ← {backLabel ?? 'Back'}
          </Anchor>
        )}
        <Group justify="space-between" align="flex-start" wrap="wrap" gap="sm">
          <Stack gap={2} style={{ minWidth: 0 }}>
            <Group gap="sm" align="center" wrap="nowrap">
              <Title order={1} lineClamp={1}>{title}</Title>
              {meta}
            </Group>
            {subtitle && <Text c="dimmed" fz="sm">{subtitle}</Text>}
          </Stack>
          {actions && <Group gap="xs" wrap="nowrap">{actions}</Group>}
        </Group>
      </Stack>
      {tabs && <Box mt="md">{tabs}</Box>}
    </Box>
  );
}
