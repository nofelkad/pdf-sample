import { ActionIcon, Menu, type MenuProps } from '@mantine/core';
import { IconDotsVertical } from '@tabler/icons-react';
import * as React from 'react';

export interface ActionMenuItem {
  label: string;
  onClick?: () => void;
  icon?: React.ReactNode;
  /** Destructive items are red and placed after a divider when `dividerBefore` is set. */
  danger?: boolean;
  disabled?: boolean;
  dividerBefore?: boolean;
}

export interface ActionMenuProps extends Omit<MenuProps, 'children' | 'trigger'> {
  items: ActionMenuItem[];

  /** Custom trigger element; defaults to a "more" icon button. */
  target?: React.ReactNode;
  /** Accessible name for the default trigger. */
  label?: string;
}

/** Row-level or header-level overflow actions. Keep the primary action outside the menu. */
export function ActionMenu({ items, target, label = 'More actions', ...rest }: ActionMenuProps) {
  return (
    <Menu {...rest}>
      <Menu.Target>
        {target ?? (
          <ActionIcon aria-label={label} onClick={(e) => e.stopPropagation()}>
            <IconDotsVertical size={18} stroke={1.75} />
          </ActionIcon>
        )}
      </Menu.Target>
      <Menu.Dropdown>
        {items.map((item, i) => (
          <React.Fragment key={item.label + i}>
            {item.dividerBefore && <Menu.Divider />}
            <Menu.Item
              leftSection={item.icon}
              color={item.danger ? 'red' : undefined}
              disabled={item.disabled}
              onClick={(e) => { e.stopPropagation(); item.onClick?.(); }}
            >
              {item.label}
            </Menu.Item>
          </React.Fragment>
        ))}
      </Menu.Dropdown>
    </Menu>
  );
}
