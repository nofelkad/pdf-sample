import { Button, Group, Modal, Stack, Text, ThemeIcon, Title, type ModalProps } from '@mantine/core';
import { notifications, type NotificationData } from '@mantine/notifications';
import { IconAlertTriangle, IconCheck, IconInfoCircle, IconX } from '@tabler/icons-react';
import * as React from 'react';

/* ---------------------------------------------------------------- ConfirmDialog */

export interface ConfirmDialogProps extends Omit<ModalProps, 'children' | 'title'> {
  title: string;
  /** One or two plain sentences: what will happen and whether it can be undone. */
  message: React.ReactNode;
  confirmLabel?: string;
  cancelLabel?: string;
  /** Red confirm button for irreversible actions (delete, void, cancel order). */
  danger?: boolean;
  loading?: boolean;
  onConfirm: () => void;
}

/** Short decision dialog. Use for irreversible or costly actions only; never to confirm a save. */
export function ConfirmDialog({ title, message, confirmLabel = 'Confirm', cancelLabel = 'Cancel', danger, loading, onConfirm, onClose, ...rest }: ConfirmDialogProps) {
  return (
    <Modal title={title} onClose={onClose} size="sm" {...rest}>
      <Stack gap="lg">
        <Text fz="sm">{message}</Text>
        <Group justify="flex-end" gap="xs">
          <Button variant="default" onClick={onClose} disabled={loading}>{cancelLabel}</Button>
          <Button color={danger ? 'red' : undefined} onClick={onConfirm} loading={loading} data-autofocus>{confirmLabel}</Button>
        </Group>
      </Stack>
    </Modal>
  );
}

/* ---------------------------------------------------------------- notify */

type NotifyInput = string | (Partial<NotificationData> & { message: React.ReactNode });
const norm = (n: NotifyInput): Partial<NotificationData> & { message: React.ReactNode } => (typeof n === 'string' ? { message: n } : n);

/**
 * Toast helpers over @mantine/notifications. Success auto-dismisses; errors stay until closed.
 * Mount <Notifications /> once (VerdantProvider does this).
 */
export const notify = {
  success: (n: NotifyInput) => notifications.show({ color: 'green', icon: <IconCheck size={16} />, autoClose: 4000, ...norm(n) }),
  error: (n: NotifyInput) => notifications.show({ color: 'red', icon: <IconX size={16} />, autoClose: false, ...norm(n) }),
  warning: (n: NotifyInput) => notifications.show({ color: 'amber', icon: <IconAlertTriangle size={16} />, autoClose: 6000, ...norm(n) }),
  info: (n: NotifyInput) => notifications.show({ color: 'blue', icon: <IconInfoCircle size={16} />, autoClose: 5000, ...norm(n) }),
};

/* ---------------------------------------------------------------- EmptyState */

export interface EmptyStateProps {
  icon?: React.ReactNode;
  title: string;
  description?: React.ReactNode;
  /** One primary action, e.g. "New purchase order". */
  action?: React.ReactNode;
  compact?: boolean;
}

/** Empty tables, empty sections and "no results" states. Say what the area is for and how to fill it. */
export function EmptyState({ icon, title, description, action, compact }: EmptyStateProps) {
  return (
    <Stack align="center" gap="xs" py={compact ? 'md' : 'xl'} px="md" ta="center">
      {icon && <ThemeIcon variant="light" color="gray" size={compact ? 36 : 44} radius="xl">{icon}</ThemeIcon>}
      <Title order={4} fw={600}>{title}</Title>
      {description && <Text c="dimmed" fz="sm" maw={420}>{description}</Text>}
      {action && <div style={{ marginTop: 4 }}>{action}</div>}
    </Stack>
  );
}
