import {
  ActionIcon, AppShell, Avatar, Box, Burger, Group, Menu, NavLink, ScrollArea, Text, TextInput, Tooltip, UnstyledButton,
} from '@mantine/core';
import { IconBell, IconChevronDown, IconHelpCircle, IconLayoutSidebarLeftCollapse, IconLayoutSidebarLeftExpand, IconLogout, IconSearch, IconSettings, IconUser } from '@tabler/icons-react';
import * as React from 'react';
import { layout } from '../tokens';

export interface NavItem {
  label: string;
  icon?: React.ReactNode;
  href?: string;
  onClick?: () => void;
  active?: boolean;
  /** Second level; keep to one level of nesting. */
  children?: Omit<NavItem, 'children' | 'icon'>[];
  badge?: React.ReactNode;
}

export interface NavSection { label?: string; items: NavItem[] }

export interface AppFrameProps {
  /** Product name or logo, top-left. */
  brand: React.ReactNode;
  sections: NavSection[];
  user: { name: string; role?: string; initials?: string };
  onUserAction?: (action: 'profile' | 'settings' | 'help' | 'logout') => void;
  /** Global search handler; omit to hide the search box. */
  onGlobalSearch?: (q: string) => void;
  notificationsCount?: number;
  onNotifications?: () => void;
  /** Optional slot in the header, right of search (e.g. company/branch switcher). */
  headerExtra?: React.ReactNode;
  children: React.ReactNode;
  /** Start collapsed on desktop. */
  defaultCollapsed?: boolean;
}

/**
 * The application chrome: left navigation (collapsible to icons), slim top bar with global search,
 * notifications and the user menu. Pages render in `children` with their own PageHeader.
 */
export function AppFrame({ brand, sections, user, onUserAction, onGlobalSearch, notificationsCount, onNotifications, headerExtra, children, defaultCollapsed }: AppFrameProps) {
  const [mobileOpen, setMobileOpen] = React.useState(false);
  const [collapsed, setCollapsed] = React.useState(!!defaultCollapsed);
  const initials = user.initials ?? user.name.split(' ').map((p) => p[0]).slice(0, 2).join('').toUpperCase();

  const renderItem = (item: NavItem) => {
    const link = (
      <NavLink
        key={item.label}
        label={collapsed ? undefined : item.label}
        leftSection={item.icon}
        rightSection={collapsed ? undefined : item.badge}
        href={item.href}
        onClick={item.onClick}
        active={item.active}
        aria-label={collapsed ? item.label : undefined}
        childrenOffset={28}
        defaultOpened={item.children?.some((c) => c.active)}
        style={{ borderRadius: 'var(--mantine-radius-md)', justifyContent: collapsed ? 'center' : undefined }}
        styles={collapsed ? { section: { marginInlineEnd: 0 }, body: { display: 'none' } } : undefined}
      >
        {!collapsed && item.children?.map((c) => (
          <NavLink key={c.label} label={c.label} href={c.href} onClick={c.onClick} active={c.active}
            rightSection={c.badge} style={{ borderRadius: 'var(--mantine-radius-md)' }} />
        ))}
      </NavLink>
    );
    return collapsed ? <Tooltip key={item.label} label={item.label} position="right">{link}</Tooltip> : link;
  };

  return (
    <AppShell
      header={{ height: layout.headerHeight }}
      navbar={{ width: collapsed ? layout.navbarCollapsedWidth : layout.navbarWidth, breakpoint: 'sm', collapsed: { mobile: !mobileOpen } }}
      padding="lg"
    >
      <AppShell.Header>
        <Group h="100%" px="md" justify="space-between" wrap="nowrap">
          <Group gap="sm" wrap="nowrap">
            <Burger opened={mobileOpen} onClick={() => setMobileOpen((o) => !o)} hiddenFrom="sm" size="sm" aria-label="Toggle navigation" />
            <Text fw={600} fz="md" style={{ whiteSpace: 'nowrap' }}>{brand}</Text>
            {headerExtra}
          </Group>
          {onGlobalSearch && (
            <TextInput
              aria-label="Search everything"
              placeholder="Search orders, customers, items…"
              leftSection={<IconSearch size={16} stroke={1.75} />}
              w={{ base: 0, sm: 320, lg: 400 }} visibleFrom="sm"
              onKeyDown={(e) => { if (e.key === 'Enter') onGlobalSearch(e.currentTarget.value); }}
            />
          )}
          <Group gap={4} wrap="nowrap">
            <Tooltip label="Notifications">
              <ActionIcon aria-label={`Notifications${notificationsCount ? `, ${notificationsCount} unread` : ''}`} onClick={onNotifications} pos="relative">
                <IconBell size={18} stroke={1.75} />
                {!!notificationsCount && (
                  <Box aria-hidden pos="absolute" top={6} right={6} w={7} h={7} bg="red.6" style={{ borderRadius: 7 }} />
                )}
              </ActionIcon>
            </Tooltip>
            <Menu width={200}>
              <Menu.Target>
                <UnstyledButton aria-label="Account menu" px={6} py={4} style={{ borderRadius: 'var(--mantine-radius-md)' }}>
                  <Group gap={8} wrap="nowrap">
                    <Avatar size={28} radius="xl" color="green" variant="filled">{initials}</Avatar>
                    <Box visibleFrom="md" style={{ lineHeight: 1.1 }}>
                      <Text fz="sm" fw={500}>{user.name}</Text>
                      {user.role && <Text fz="xs" c="dimmed">{user.role}</Text>}
                    </Box>
                    <IconChevronDown size={14} stroke={1.75} />
                  </Group>
                </UnstyledButton>
              </Menu.Target>
              <Menu.Dropdown>
                <Menu.Item leftSection={<IconUser size={16} />} onClick={() => onUserAction?.('profile')}>Profile</Menu.Item>
                <Menu.Item leftSection={<IconSettings size={16} />} onClick={() => onUserAction?.('settings')}>Settings</Menu.Item>
                <Menu.Item leftSection={<IconHelpCircle size={16} />} onClick={() => onUserAction?.('help')}>Help</Menu.Item>
                <Menu.Divider />
                <Menu.Item leftSection={<IconLogout size={16} />} onClick={() => onUserAction?.('logout')}>Sign out</Menu.Item>
              </Menu.Dropdown>
            </Menu>
          </Group>
        </Group>
      </AppShell.Header>

      <AppShell.Navbar p="xs">
        <AppShell.Section grow component={ScrollArea} scrollbars="y">
          {sections.map((s, i) => (
            <Box key={i} mb="sm">
              {s.label && !collapsed && (
                <Text fz="xs" fw={600} c="dimmed" tt="uppercase" px="sm" py={6} style={{ letterSpacing: 0.4 }}>{s.label}</Text>
              )}
              {s.items.map(renderItem)}
            </Box>
          ))}
        </AppShell.Section>
        <AppShell.Section visibleFrom="sm">
          <Tooltip label={collapsed ? 'Expand navigation' : 'Collapse navigation'} position="right">
            <ActionIcon aria-label={collapsed ? 'Expand navigation' : 'Collapse navigation'} onClick={() => setCollapsed((c) => !c)} w={collapsed ? '100%' : undefined}>
              {collapsed ? <IconLayoutSidebarLeftExpand size={18} stroke={1.75} /> : <IconLayoutSidebarLeftCollapse size={18} stroke={1.75} />}
            </ActionIcon>
          </Tooltip>
        </AppShell.Section>
      </AppShell.Navbar>

      <AppShell.Main>
        <Box maw={layout.contentMaxWidth} mx="auto">{children}</Box>
      </AppShell.Main>
    </AppShell>
  );
}
