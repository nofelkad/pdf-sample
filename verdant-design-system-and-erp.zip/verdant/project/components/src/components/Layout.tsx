import {
  Box, Button, Divider, Grid, Group, Paper, SimpleGrid, Stack, Text, Title, type PaperProps,
} from '@mantine/core';
import * as React from 'react';

/* ---------------------------------------------------------------- Section */

export interface SectionProps extends PaperProps {
  title?: React.ReactNode;
  description?: React.ReactNode;
  /** Small actions in the section header (e.g. "Edit"). */
  actions?: React.ReactNode;
  children: React.ReactNode;
}

/** A bordered content block with an optional heading row. Used for form groups and detail-page panels. */
export function Section({ title, description, actions, children, ...rest }: SectionProps) {
  return (
    <Paper p="lg" {...rest}>
      {(title || actions) && (
        <Group justify="space-between" align="flex-start" mb="md" wrap="nowrap">
          <Stack gap={2}>
            {title && <Title order={3}>{title}</Title>}
            {description && <Text c="dimmed" fz="sm">{description}</Text>}
          </Stack>
          {actions}
        </Group>
      )}
      {children}
    </Paper>
  );
}

/* ---------------------------------------------------------------- FormActions */

export interface FormActionsProps {
  /** Primary submit button. */
  primary: React.ReactNode;
  /** Cancel / secondary buttons. */
  secondary?: React.ReactNode;
  /** Left-aligned destructive or tertiary action. */
  start?: React.ReactNode;
  /** Stick to the viewport bottom on long forms. */
  sticky?: boolean;
}

/** The action row at the end of a form: primary on the right, cancel beside it, destructive far left. */
export function FormActions({ primary, secondary, start, sticky }: FormActionsProps) {
  return (
    <Box
      mt="lg" py="sm"
      style={sticky ? {
        position: 'sticky', bottom: 0, background: 'var(--mantine-color-body)',
        borderTop: '1px solid var(--mantine-color-default-border)', zIndex: 2,
      } : undefined}
    >
      <Group justify="space-between">
        <div>{start}</div>
        <Group gap="xs">{secondary}{primary}</Group>
      </Group>
    </Box>
  );
}

/* ---------------------------------------------------------------- DetailList */

export interface DetailItem { label: string; value: React.ReactNode; /** span both columns */ wide?: boolean }

/** Label/value pairs for read-only detail panels. Values that are empty show an em dash, never blank. */
export function DetailList({ items, columns = 2 }: { items: DetailItem[]; columns?: 1 | 2 | 3 }) {
  return (
    <SimpleGrid cols={{ base: 1, sm: columns }} spacing="md" verticalSpacing="sm">
      {items.map((it) => (
        <Stack key={it.label} gap={2} style={it.wide ? { gridColumn: '1 / -1' } : undefined}>
          <Text fz="xs" c="dimmed" fw={500} tt="uppercase" style={{ letterSpacing: 0.3 }}>{it.label}</Text>
          <Text fz="sm">{it.value === null || it.value === undefined || it.value === '' ? '—' : it.value}</Text>
        </Stack>
      ))}
    </SimpleGrid>
  );
}

/* ---------------------------------------------------------------- StatCard */

export interface StatCardProps extends PaperProps {
  label: string;
  value: React.ReactNode;
  /** e.g. "+4.2% vs last month". Tone colours the delta text. */
  delta?: React.ReactNode;
  deltaTone?: 'up' | 'down' | 'neutral';
  hint?: React.ReactNode;
  icon?: React.ReactNode;
  onClick?: () => void;
}

/** Dashboard KPI tile: label, large tabular number, small delta. Four per row at most. */
export function StatCard({ label, value, delta, deltaTone = 'neutral', hint, icon, onClick, ...rest }: StatCardProps) {
  const deltaColor = deltaTone === 'up' ? 'green.7' : deltaTone === 'down' ? 'red.7' : 'dimmed';
  return (
    <Paper p="md" component={onClick ? 'button' : 'div'} onClick={onClick}
      style={onClick ? { cursor: 'pointer', textAlign: 'left', font: 'inherit' } : undefined} {...rest}>
      <Group justify="space-between" align="flex-start" wrap="nowrap">
        <Text fz="sm" c="dimmed" fw={500}>{label}</Text>
        {icon && <Box c="dimmed" style={{ display: 'flex' }}>{icon}</Box>}
      </Group>
      <Text fz={26} fw={600} lh={1.2} mt={6} style={{ fontVariantNumeric: 'tabular-nums' }}>{value}</Text>
      {(delta || hint) && (
        <Group gap={6} mt={6}>
          {delta && <Text fz="xs" fw={500} c={deltaColor}>{delta}</Text>}
          {hint && <Text fz="xs" c="dimmed">{hint}</Text>}
        </Group>
      )}
    </Paper>
  );
}

/* ---------------------------------------------------------------- Page layouts */

/** Two-column detail layout: main content 8/12, side panel 4/12; stacks below md. */
export function DetailLayout({ main, aside }: { main: React.ReactNode; aside: React.ReactNode }) {
  return (
    <Grid gap="lg">
      <Grid.Col span={{ base: 12, md: 8 }}><Stack gap="lg">{main}</Stack></Grid.Col>
      <Grid.Col span={{ base: 12, md: 4 }}><Stack gap="lg">{aside}</Stack></Grid.Col>
    </Grid>
  );
}

/** Bulk-action bar shown when table rows are selected. */
export function SelectionBar({ count, actions, onClear }: { count: number; actions: React.ReactNode; onClear: () => void }) {
  if (count === 0) return null;
  return (
    <Paper px="md" py={6} mb="xs" bg="var(--verdant-surface-selected)" style={{ borderColor: 'var(--mantine-color-green-2)' }}>
      <Group justify="space-between">
        <Group gap="xs">
          <Text fz="sm" fw={500}>{count} selected</Text>
          <Divider orientation="vertical" />
          {actions}
        </Group>
        <Button variant="subtle" size="compact-sm" onClick={onClear}>Clear</Button>
      </Group>
    </Paper>
  );
}
