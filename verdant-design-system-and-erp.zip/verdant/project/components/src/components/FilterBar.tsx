import { Button, Collapse, Group, Pill, Stack, Text, TextInput, type TextInputProps } from '@mantine/core';
import { IconAdjustmentsHorizontal, IconSearch, IconX } from '@tabler/icons-react';
import * as React from 'react';

/* ---------------------------------------------------------------- SearchInput */

export interface SearchInputProps extends Omit<TextInputProps, 'onChange' | 'value'> {
  value?: string;
  /** Fires after `debounce` ms of inactivity (default 300). */
  onSearch: (query: string) => void;
  debounce?: number;
}

/** Text search with icon, clear button and debounce. Place it first in a FilterBar. */
export function SearchInput({ value: valueProp, onSearch, debounce = 300, placeholder = 'Search', ...rest }: SearchInputProps) {
  const [value, setValue] = React.useState(valueProp ?? '');
  React.useEffect(() => { if (valueProp !== undefined) setValue(valueProp); }, [valueProp]);
  React.useEffect(() => {
    const t = setTimeout(() => onSearch(value), debounce);
    return () => clearTimeout(t);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [value]);
  return (
    <TextInput
      aria-label={placeholder}
      placeholder={placeholder}
      value={value}
      onChange={(e) => setValue(e.currentTarget.value)}
      leftSection={<IconSearch size={16} stroke={1.75} />}
      rightSection={value ? (
        <button type="button" aria-label="Clear search" onClick={() => setValue('')}
          style={{ all: 'unset', cursor: 'pointer', display: 'flex', color: 'var(--mantine-color-dimmed)' }}>
          <IconX size={14} stroke={1.75} />
        </button>
      ) : null}
      w={{ base: '100%', sm: 280 }}
      {...rest}
    />
  );
}

/* ---------------------------------------------------------------- FilterBar */

export interface AppliedFilter { key: string; label: string }

export interface FilterBarProps {
  /** Usually a SearchInput. */
  search?: React.ReactNode;
  /** Two to four primary filters shown always (Select, SegmentedControl, date range). */
  children?: React.ReactNode;
  /** Rarely used filters, hidden behind "More filters". */
  advanced?: React.ReactNode;
  applied?: AppliedFilter[];
  onRemove?: (key: string) => void;
  onClearAll?: () => void;
  /** Right-aligned slot: result count, view switch, export. */
  trailing?: React.ReactNode;
}

/**
 * The row above every list. Shows the few filters people use daily; everything else
 * sits behind "More filters". Applied filters appear as removable pills.
 */
export function FilterBar({ search, children, advanced, applied = [], onRemove, onClearAll, trailing }: FilterBarProps) {
  const [open, setOpen] = React.useState(false);
  return (
    <Stack gap="xs" mb="md">
      <Group justify="space-between" align="flex-end" wrap="wrap" gap="sm">
        <Group gap="xs" align="flex-end" wrap="wrap">
          {search}
          {children}
          {advanced && (
            <Button variant={open ? 'light' : 'default'} leftSection={<IconAdjustmentsHorizontal size={16} stroke={1.75} />}
              onClick={() => setOpen((o) => !o)} aria-expanded={open}>
              More filters
            </Button>
          )}
        </Group>
        {trailing && <Group gap="xs">{trailing}</Group>}
      </Group>
      {advanced && (
        <Collapse expanded={open}>
          <Group gap="xs" align="flex-end" wrap="wrap" p="sm"
            style={{ background: 'var(--verdant-surface-sunken)', borderRadius: 'var(--mantine-radius-md)' }}>
            {advanced}
          </Group>
        </Collapse>
      )}
      {applied.length > 0 && (
        <Group gap={6} align="center">
          <Text fz="xs" c="dimmed">Filters:</Text>
          {applied.map((f) => (
            <Pill key={f.key} withRemoveButton={!!onRemove} onRemove={() => onRemove?.(f.key)} removeButtonProps={{ 'aria-label': `Remove ${f.label}` }}>
              {f.label}
            </Pill>
          ))}
          {onClearAll && <Button variant="subtle" size="compact-xs" onClick={onClearAll}>Clear all</Button>}
        </Group>
      )}
    </Stack>
  );
}
