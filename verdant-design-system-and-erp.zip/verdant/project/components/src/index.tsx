/**
 * Verdant — bundle entry.
 * In the app, import from this package; in the design-system previews it is exposed as window.Verdant.
 */
import * as React from 'react';
import * as ReactDOM from 'react-dom/client';

export * from '@mantine/core';
export { Notifications, notifications } from '@mantine/notifications';
export * as tokens from './tokens';
export { theme, cssVariablesResolver } from './theme';
export { VerdantProvider } from './VerdantProvider';
export { StatusBadge, statusTones, type StatusTone, type StatusBadgeProps } from './components/StatusBadge';
export { ActionMenu, type ActionMenuItem, type ActionMenuProps } from './components/ActionMenu';
export { PageHeader, type PageHeaderProps, type Crumb } from './components/PageHeader';
export { DataTable, type DataTableColumn, type DataTableProps, type SortState } from './components/DataTable';
export { FilterBar, SearchInput, type FilterBarProps, type SearchInputProps, type AppliedFilter } from './components/FilterBar';
export { ConfirmDialog, EmptyState, notify, type ConfirmDialogProps, type EmptyStateProps } from './components/Feedback';
export { Section, FormActions, DetailList, StatCard, DetailLayout, SelectionBar, type SectionProps, type StatCardProps, type DetailItem } from './components/Layout';
export { AppFrame, type AppFrameProps, type NavItem, type NavSection } from './components/AppFrame';

/** The icon subset the system ships with (Tabler Icons, 1.75 stroke). Apps import @tabler/icons-react directly. */
export {
  IconPlus, IconDownload, IconUpload, IconFilter, IconEdit, IconTrash, IconCopy, IconFileInvoice, IconShoppingCart, IconUsers,
  IconPackage, IconChartBar, IconSettings, IconHome, IconReceipt, IconTruck, IconBuildingWarehouse, IconSearch, IconCheck, IconX,
  IconAlertTriangle, IconInfoCircle, IconRefresh, IconPrinter, IconSend, IconArrowUpRight, IconArrowDownRight, IconInbox,
  IconDotsVertical, IconChevronRight, IconCalendar, IconCreditCard, IconClipboardList, IconBell, IconExternalLink, IconEye,
} from '@tabler/icons-react';

import { VerdantProvider } from './VerdantProvider';

/**
 * Preview helper: mounts `node` inside VerdantProvider and follows the host document's
 * `data-theme` attribute (light | dark) live. Used only by the design-system previews.
 */
export function mountPreview(el: HTMLElement, node: React.ReactNode | (() => React.ReactNode)) {
  const read = () => (document.documentElement.getAttribute('data-theme') === 'dark' ? 'dark' : 'light');
  function Host() {
    const [scheme, setScheme] = React.useState<'light' | 'dark'>(read);
    React.useEffect(() => {
      const mo = new MutationObserver(() => setScheme(read()));
      mo.observe(document.documentElement, { attributes: true, attributeFilter: ['data-theme'] });
      return () => mo.disconnect();
    }, []);
    return (
      <VerdantProvider forceColorScheme={scheme} key={scheme}>
        {typeof node === 'function' ? React.createElement(node as any) : node}
      </VerdantProvider>
    );
  }
  ReactDOM.createRoot(el).render(<Host />);
}

export { React };
