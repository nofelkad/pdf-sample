# Verdant sources

Drop-in for a Mantine 9 project (React 19.2+, TypeScript).

- `tokens.ts` — the only place values live. `theme.ts` builds the Mantine theme from it; `build/tokens-json.mjs` regenerates the design system's `tokens.json` from it.
- `theme.ts` — `createTheme` + `Component.extend` defaults + `cssVariablesResolver` (semantic surface/text variables, dark-mode variant re-pinning).
- `VerdantProvider.tsx` — MantineProvider + Notifications. Wrap the app once.
- `components/` — the composite components documented in this system. Each is plain Mantine; copy only what you use.
- `verdant.css` — eight lines of global CSS; import after Mantine's stylesheets.
- `index.tsx` — the package entry. `mountPreview` is used only by the design-system previews and can be dropped in the app.
- `build/` — how the design-system bundle is produced: esbuild IIFE with React mapped to `window.React` (`shims/`), Mantine CSS concatenated into `bundle.css`, a headless render check in both themes and a WCAG contrast check over `tokens.json`.

Dependencies: `@mantine/core`, `@mantine/hooks`, `@mantine/notifications` (9.x — tested on 9.7.2), `@tabler/icons-react` (3.x), React 19.2+. Nothing else.

Install into an app:

```
src/ui/verdant/            ← copy tokens.ts, theme.ts, VerdantProvider.tsx, verdant.css, components/
main.tsx                   ← import '@mantine/core/styles.css'; import '@mantine/notifications/styles.css'; import './ui/verdant/verdant.css';
```

Mantine 8 note: the same files work on 8.x with two prop renames back — `Collapse expanded` → `in`, `Grid gap` → `gutter` — and React 18 is then allowed. In 9, `--mantine-color-error` is derived from shade 8, so `theme.ts` pins it per scheme.