/**
 * Verdant — Mantine 9 theme (React 19.2+).
 * Everything visual is expressed through Mantine's native theming API:
 * palette, scale and component defaults. No global CSS overrides.
 */
import {
  ActionIcon, Anchor, Badge, Button, Card, Checkbox, Chip, Combobox, createTheme, Divider,
  Drawer, Fieldset, Input, InputWrapper, Menu, Modal, MultiSelect, NavLink, NumberInput,
  Pagination, Paper, PasswordInput, Pill, Popover, Radio, SegmentedControl, Select, Switch,
  Table, Tabs, Textarea, TextInput, Tooltip, type CSSVariablesResolver, type MantineColorsTuple,
} from '@mantine/core';
import {
  colors, defaultRadius, fontFamily, fontFamilyMonospace, fontSizes, headings, lineHeights,
  primaryShade, radius, shadows, spacing,
} from './tokens';

/** Mantine's dark scale: 0 = lightest text … 7 = body background. Built from the sage gray scale. */
const dark: MantineColorsTuple = [
  colors.gray[0], colors.gray[3], colors.gray[4], colors.gray[5],
  colors.gray[7], '#3a443f', colors.gray[8], colors.gray[9], '#161b18', '#111513',
];

export const theme = createTheme({
  primaryColor: 'green',
  primaryShade,
  colors: { green: colors.green, gray: colors.gray, red: colors.red, amber: colors.amber, blue: colors.blue, dark },
  white: '#ffffff',
  black: colors.gray[9],

  fontFamily,
  fontFamilyMonospace,
  fontSizes,
  lineHeights,
  headings: { fontFamily, ...headings },
  spacing,
  radius,
  defaultRadius,
  shadows,

  cursorType: 'pointer',
  focusRing: 'auto',
  autoContrast: true,
  luminanceThreshold: 0.22,
  respectReducedMotion: true,

  components: {
    // ---- Actions ----------------------------------------------------------
    Button: Button.extend({
      defaultProps: { size: 'sm', fw: 500 },
    }),
    ActionIcon: ActionIcon.extend({
      defaultProps: { variant: 'subtle', color: 'gray', size: 'lg' },
    }),
    Anchor: Anchor.extend({ defaultProps: { underline: 'hover', fw: 500 } }),
    Menu: Menu.extend({
      defaultProps: { shadow: 'md', radius: 'md', width: 220, position: 'bottom-end', withinPortal: true },
    }),
    Tooltip: Tooltip.extend({ defaultProps: { withArrow: true, openDelay: 300, fz: 'xs' } }),

    // ---- Inputs -----------------------------------------------------------
    Input: Input.extend({ defaultProps: { size: 'sm' } }),
    InputWrapper: InputWrapper.extend({
      defaultProps: { inputWrapperOrder: ['label', 'input', 'description', 'error'] },
      styles: { label: { fontWeight: 500, marginBottom: 4 }, description: { marginTop: 4 } },
    }),
    TextInput: TextInput.extend({ defaultProps: { size: 'sm' } }),
    NumberInput: NumberInput.extend({ defaultProps: { size: 'sm', thousandSeparator: ',', hideControls: true } }),
    PasswordInput: PasswordInput.extend({ defaultProps: { size: 'sm' } }),
    Textarea: Textarea.extend({ defaultProps: { size: 'sm', autosize: true, minRows: 3 } }),
    Select: Select.extend({
      defaultProps: { size: 'sm', searchable: true, checkIconPosition: 'right', comboboxProps: { shadow: 'md' } },
    }),
    MultiSelect: MultiSelect.extend({
      defaultProps: { size: 'sm', searchable: true, checkIconPosition: 'right', comboboxProps: { shadow: 'md' } },
    }),
    Combobox: Combobox.extend({ defaultProps: { shadow: 'md' } }),
    Checkbox: Checkbox.extend({ defaultProps: { size: 'sm', radius: 'sm' } }),
    Radio: Radio.extend({ defaultProps: { size: 'sm' } }),
    Switch: Switch.extend({ defaultProps: { size: 'sm' } }),
    Chip: Chip.extend({ defaultProps: { size: 'sm', variant: 'light' } }),
    SegmentedControl: SegmentedControl.extend({ defaultProps: { size: 'sm', radius: 'md' } }),
    Fieldset: Fieldset.extend({ defaultProps: { variant: 'unstyled' } }),
    Pill: Pill.extend({ defaultProps: { size: 'sm', radius: 'sm' } }),

    // ---- Surfaces ---------------------------------------------------------
    Paper: Paper.extend({ defaultProps: { withBorder: true, shadow: 'none', radius: 'lg' } }),
    Card: Card.extend({ defaultProps: { withBorder: true, shadow: 'none', radius: 'lg', padding: 'md' } }),
    Divider: Divider.extend({ defaultProps: { color: 'var(--mantine-color-default-border)' } }),
    Popover: Popover.extend({ defaultProps: { shadow: 'md', radius: 'md', withinPortal: true } }),

    // ---- Overlays ---------------------------------------------------------
    Modal: Modal.extend({
      defaultProps: {
        centered: true, radius: 'lg', size: 'md', padding: 'lg',
        overlayProps: { backgroundOpacity: 0.4, blur: 2 },
      },
      styles: { title: { fontWeight: 600, fontSize: 'var(--mantine-font-size-lg)' } },
    }),
    Drawer: Drawer.extend({
      defaultProps: { position: 'right', size: 'md', padding: 'lg', overlayProps: { backgroundOpacity: 0.4, blur: 2 } },
      styles: { title: { fontWeight: 600, fontSize: 'var(--mantine-font-size-lg)' } },
    }),

    // ---- Data display -----------------------------------------------------
    Table: Table.extend({
      defaultProps: {
        highlightOnHover: true, withTableBorder: true, verticalSpacing: 'xs', horizontalSpacing: 'md',
        stickyHeader: true, layout: 'auto',
      },
      styles: {
        th: { fontWeight: 600, fontSize: 'var(--mantine-font-size-sm)', color: 'var(--mantine-color-dimmed)', whiteSpace: 'nowrap' },
        thead: { backgroundColor: 'var(--mantine-color-gray-1)' },
        td: { fontSize: 'var(--mantine-font-size-sm)' },
      },
    }),
    Badge: Badge.extend({
      defaultProps: { variant: 'light', radius: 'sm', size: 'md', tt: 'none', fw: 500 },
      styles: { root: { letterSpacing: 0 } },
    }),
    Pagination: Pagination.extend({ defaultProps: { size: 'sm', radius: 'md', withEdges: false } }),
    Tabs: Tabs.extend({ defaultProps: { radius: 'md' } }),
    NavLink: NavLink.extend({ defaultProps: { variant: 'light' } }),
  },
});

/**
 * Semantic CSS variables. Mantine resolves body/paper/text/border per colour scheme;
 * these pin them to Verdant's tinted neutrals so light mode is sage-white, not blue-gray.
 */
/**
 * Mantine derives dark-mode light/outline variants and `--mantine-color-error` assuming primaryShade.dark = 8.
 * Verdant uses shade 4 in dark (a lighter green that keeps dark text readable), so the
 * derived variants are re-pinned here: tint = shade 5 at 18%, text = shade 2, outline = shade 3.
 */
function darkVariantVars(t: Parameters<CSSVariablesResolver>[0]) {
  const out: Record<string, string> = {};
  for (const name of ['green', 'gray', 'red', 'amber', 'blue'] as const) {
    const c = t.colors[name];
    const [r, g, b] = [1, 3, 5].map((i) => parseInt(c[5].slice(i, i + 2), 16));
    out[`--mantine-color-${name}-light`] = `rgba(${r}, ${g}, ${b}, 0.18)`;
    out[`--mantine-color-${name}-light-hover`] = `rgba(${r}, ${g}, ${b}, 0.26)`;
    out[`--mantine-color-${name}-light-color`] = c[2];
    out[`--mantine-color-${name}-outline`] = c[3];
    out[`--mantine-color-${name}-outline-hover`] = `rgba(${r}, ${g}, ${b}, 0.12)`;
    out[`--mantine-color-${name}-text`] = c[3];
  }
  return out;
}

export const cssVariablesResolver: CSSVariablesResolver = (t) => ({
  variables: {
    '--verdant-nav-width': '248px',
    '--verdant-header-height': '52px',
    '--verdant-content-max': '1440px',
  },
  light: {
    '--mantine-color-body': t.colors.gray[0],
    '--mantine-color-text': t.colors.gray[9],
    '--mantine-color-dimmed': t.colors.gray[6],
    '--mantine-color-placeholder': t.colors.gray[5],
    '--mantine-color-default-border': t.colors.gray[2],
    '--mantine-color-anchor': t.colors.green[6],
    '--mantine-color-error': t.colors.red[6],
    '--mantine-primary-color-contrast': '#ffffff',
    '--verdant-surface-sunken': t.colors.gray[1],
    '--verdant-surface-selected': t.colors.green[0],
  },
  dark: {
    ...darkVariantVars(t),
    '--mantine-color-body': t.colors.gray[9],
    '--mantine-color-text': t.colors.gray[0],
    '--mantine-color-dimmed': t.colors.gray[4],
    '--mantine-color-placeholder': t.colors.gray[5],
    '--mantine-color-default-border': t.colors.gray[7],
    '--mantine-color-anchor': t.colors.green[3],
    '--mantine-color-error': t.colors.red[3],
    '--mantine-primary-color-contrast': t.colors.gray[9],
    '--verdant-surface-sunken': '#161b18',
    '--verdant-surface-selected': 'rgba(100, 174, 133, 0.14)',
  },
});
