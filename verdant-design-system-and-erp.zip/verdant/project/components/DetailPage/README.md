The record page pattern: `DetailLayout` (main 8/12, aside 4/12, stacking below `md`), `Section` panels and `DetailList` label/value pairs. The main column holds the summary `DetailList`, line items in a `dense` `DataTable` and related records; the aside holds totals, approvals and an activity `Timeline`.

**Consumer provides:** `DetailLayout` — `main` and `aside` arrays of `Section`s. `Section` — `title`, `description`, `actions` (a `subtle` *Edit* button), children. `DetailList` — `items` (`{ label, value, wide? }`), `columns` 1–3; empty values render as an em dash.

**Do:** order fields as the business reads them; put the next workflow action in the `PageHeader`, not in a panel; keep each `Section` to one topic.

**Don't:** nest `Paper` inside `Section`; mix editable inputs into a read-only `DetailList` (switch the whole section to edit mode or use a `Drawer`); exceed two columns in the aside.
