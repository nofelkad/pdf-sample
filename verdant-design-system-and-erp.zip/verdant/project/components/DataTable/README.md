The list table. Wraps Mantine `Table` inside `Table.ScrollContainer` with the Verdant conventions: sticky `surface-sunken` header, 40px rows (32px `dense`), right-aligned tabular numerics, hover highlight, `surface-selected` rows, sortable headers, selection checkboxes and a trailing row-actions column.

**Consumer provides:** `columns` (`{ key, header, numeric?, width?, sortable?, render?, visibleFrom? }`), `rows`, `rowKey`, and the state it owns: `selected`/`onSelectedChange`, `sort`/`onSortChange`, `loading`, `onRowClick`, `rowActions` (returns an `ActionMenu`), `empty` (an `EmptyState`). Pagination is rendered by the page below the table (`Pagination` + "Showing 1–25 of 248").

**Do:** make the first column the record link (`Anchor`, 13px); format amounts in the row's currency; cap visible columns at eight and hide the rest with `visibleFrom`; pair with `SelectionBar` for bulk actions.

**Don't:** use `striped`; put inputs in cells except in line-item editors; show more than one badge per row; colour whole rows by status.
