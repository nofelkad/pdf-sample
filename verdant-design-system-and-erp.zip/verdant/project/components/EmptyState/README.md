Empty and no-results states inside a `Paper`, table or section: an optional grey `ThemeIcon`, an `h4` title, one sentence of explanation and at most one action. `compact` for inline/no-results use.

**Consumer provides:** `title` (what is missing: *No purchase orders yet*), `description` (what this area is for), `action` (the button that fills it), `icon` (Tabler, 20–22px).

**Do:** pass it as `DataTable`'s `empty`; for filtered-empty results offer *Clear filters* instead of *Create*.

**Don't:** use illustrations or emoji; show it while loading (use `Skeleton`); write apologetic copy.
