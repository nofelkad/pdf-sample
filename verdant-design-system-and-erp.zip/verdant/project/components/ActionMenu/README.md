Overflow menu for secondary actions, on a table row or next to the primary button in a `PageHeader`. Wraps Mantine `Menu` with a "more" `ActionIcon` target, 220px dropdown, `shadow-md`, bottom-end placement.

**Consumer provides:** `items` — `{ label, onClick, icon?, danger?, disabled?, dividerBefore? }` in the order people need them, with the destructive item last behind `dividerBefore`; optional `target` (a `Button` with a chevron) and `label` for the trigger's accessible name.

**Do:** keep three to seven items; clicks stop propagation so the menu works inside clickable rows.

**Don't:** put the primary action in the menu; nest submenus; use icons on some items but not others.
