The application chrome on Mantine `AppShell`: a 248px left navigation of `NavLink`s grouped under `label-caps` section labels (collapsible to 64px icons with tooltips), a 52px top bar with the product name, global search, notification bell and account `Menu`, and a `Main` area capped at 1440px. Below `sm` the nav collapses behind a `Burger`.

**Consumer provides:** `brand`, `sections` (`{ label?, items: { label, icon, href|onClick, active, badge?, children? } }`, one level of nesting), `user` (`{ name, role }`), `onGlobalSearch`, `notificationsCount`, `onNotifications`, `onUserAction`, `headerExtra` (company or branch switcher), and the page as `children` starting with a `PageHeader`.

**Do:** order modules by daily use (Home, then the department's main objects); keep to seven top-level items per section; mark the current page `active` and open its parent.

**Don't:** put actions in the top bar other than search, notifications and account; use a second sidebar; brand the header with a coloured background.
