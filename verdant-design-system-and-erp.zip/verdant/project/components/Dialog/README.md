Two overlays. `ConfirmDialog` is a small Mantine `Modal` for irreversible actions: title as a question (*Void invoice INV-20927?*), one or two plain sentences saying what happens and whether it can be undone, *Cancel* + the verb as the confirm button (red when `danger`). `Drawer` (right, `md`, `radius-lg`) is for editing a few fields or viewing a related record without leaving the list.

**Consumer provides:** `ConfirmDialog` — `opened`, `onClose`, `onConfirm`, `title`, `message`, `confirmLabel`, `danger`, `loading`. `Drawer` — Mantine props plus the form inside and its own action row.

**Do:** keep modals to `sm`/`md`; return focus to the trigger; close on Escape and overlay click (Mantine default) unless the form has unsaved changes.

**Don't:** confirm saves or navigation; stack modals; use a modal for anything with more than six fields (use a Drawer or a page).
