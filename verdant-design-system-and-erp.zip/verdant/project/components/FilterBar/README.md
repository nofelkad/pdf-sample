The filter row above a list: `SearchInput` first, two to four everyday filters (`Select`, `SegmentedControl`, a date range), a *More filters* toggle that reveals the rest in a `surface-sunken` tray, applied filters as removable `Pill`s with *Clear all*, and a trailing slot for the result count and Export.

**Consumer provides:** `search` (a `SearchInput` with `onSearch`, debounced 300ms), filter controls as children, `advanced` controls, `applied` (`{key, label}` such as *Status: Overdue*), `onRemove`, `onClearAll`, `trailing`.

**Do:** give every control an `aria-label` when it has no visible label; keep filter state in the URL so lists are shareable; default the date range to what people check daily.

**Don't:** show more than four controls outside *More filters*; require pressing Apply for the everyday filters (apply on change); hide the search box.
