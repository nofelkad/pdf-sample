Feedback after an action. `notify.success | error | warning | info` show a toast (top-right, `limit 4`) through `@mantine/notifications`; success auto-dismisses in 4s, errors stay until closed. Mantine `Alert` is for conditions that persist on the page; `Notification` rendered inline is for activity feeds.

**Consumer provides:** a message string or `{ title, message }`; for errors, what to do next (*Reopen the period or change the posting date*). `VerdantProvider` mounts `<Notifications />` once.

**Do:** name the record in the title (*Order SO-10482 confirmed*); use `Alert` with an icon and a title for page-level warnings; keep toasts under two lines.

**Don't:** toast for every keystroke-level save; put the only copy of a validation error in a toast; use `notify.info` for marketing or tips.
