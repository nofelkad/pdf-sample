Mantine `Button` and `ActionIcon` with Verdant defaults: size `sm` (34px), weight 500, radius `md`. One `filled` primary per view; `default` for secondary; `subtle` for tertiary and in-table actions; `light` with `color="red"` for destructive actions that are not yet confirmed, `filled` red only on the confirm button of a `ConfirmDialog`.

**Consumer provides:** label (a verb: *Create order*, *Approve*), optional `leftSection` icon at 16px/1.75 stroke, `loading` while the request is in flight, `disabled` only with a tooltip or helper text that explains why.

**Do:** keep labels to one to three words; use `ActionIcon` (`variant="subtle"`, `color="gray"` by default) with an `aria-label` for icon-only actions; use `size="compact-sm"` inside `SelectionBar` and table footers.

**Don't:** use `outline`, `gradient` or `white` variants; stack two filled buttons; use `xl` sizes; put icons on the right except a chevron for a dropdown trigger.
