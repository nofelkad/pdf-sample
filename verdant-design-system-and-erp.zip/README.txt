Verdant Design System + ERP (all pages) - full export
Exported 2026-10-20

verdant/  Verdant design system, all 73 files (tokens, components, previews, React source, bundle, brand book README, runtime files).
          Start with verdant/project/README.md and verdant/project/tokens.json.
erp/      ERP design canvas, all 42 files: every page (*.dc.html under erp/project/), canvas.json layout, Verdant tokens, runtime/reference files.
          Pages: Main, SideNav, TopBar, Parties, NewParty, PartyDetail, PartyContact, PartyAccess, PartyActivity, PartyMore, PartyNotes,
          PartyPayments, PartyRelationships, RecordHeader, MergeParty, Classifications, Communications, Dialogs, ImportExport, Security.

Live (interactive) versions:
  Verdant: https://claude.ai/artifact/PsfoEWZAswJcbyCnqrJKPw
  ERP:     https://claude.ai/artifact/S12c71GNAGJaUNmaPAr1Lo
Note: the ERP .dc.html pages are Design Component source files; they render in the live artifact (or its runtime), not by double-clicking in a browser.
